"""THE LOOK'S NOISE FLOOR: how much the look disagrees with ITSELF, field by field, on the same pictures.

    python -m geometry_agent.learn.look_floor <part.step> [<part.step> ...] [--repeats 2] [--out DIR]

WHY THIS EXISTS. The agent has a noise floor and the look does not. The corpus panel of 2026-09-09 measured the
agent at pass flip 0.033 and risk-kind set identical 0.59, and standing rule P1 forbids a single-run comparison
because of it. The look has no such number anywhere it can be read, so **a look that is WRONG and a look that is
UNSTABLE are the same reading today** - and they need opposite fixes. A wrong field wants a better prompt, a
better picture or demotion out of `relied_on`; an unstable field wants repeats, or a decision rule that only
fires on the stable part of it. Without a floor every disagreement between the look and the measurement, and
every `look_disagreed_with_the_customer` the platform's counterfactual reports, is unattributable.

WHAT IS HELD FIXED, AND WHY THAT IS THE WHOLE EXPERIMENT. The renders are shared: `vision.render.render_views`
caches by the file's sha256 under `cache_root_dir`, so the second call is answered from the same PNGs, byte for
byte, with the same prompt and the same labels. `vision.look` caches no reply, so each call is a fresh request
to the reader. What is measured is therefore the READER's own variance on one input, not the renderer's and not
the measurement's. A floor measured on freshly drawn pictures each time would pool two sources of variance and
could not tell them apart.

THE CHECK THAT CAN FAIL DIFFERENTLY FROM WHAT IT CHECKS. The failure that would make this instrument worthless
is a cache or a stub answering the second call, because then every field agrees with itself perfectly and the
floor is 1.00 by construction - a number that lies, and one that would look exactly like a very stable reader.
So the harness counts the calls the client actually makes (`_Counted`) and `floor` REFUSES a part whose call
count is not the number of repeats asked for. The count comes from a wrapper around the client; the agreement
comes from the replies. Neither can fake the other.

WHAT IS NOT SCORED, said first: `notes` and `openings_seen[].why` are free prose written for a person, and
`vision/trust.py` tiers both away from anything that decides. A "Jaccard on the wording" over them would move
the headline without measuring a decision, so they are listed in `NOT_SCORED` and reported as excluded rather
than quietly left out.

This module reads and writes nothing in the learning loop: no record, no ledger, no calibration table, no
feature bank. Its output is `eval/look_floor/`.
"""
from __future__ import annotations

import json
import statistics
import time
from collections import Counter
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from geometry_agent.learn import store

FLOOR_SCHEMA = "geometry_agent.learn.look_floor.v1"

#: Where a run's raw pairs and its summary land. Regenerated, and a reading of a sample rather than a corpus
#: artefact, so it is gitignored like the other regenerated eval directories.
FLOOR_DIR = store.EVAL / "look_floor"

#: How many times one part is looked at. Two is the floor's definition: one pair per part per field.
DEFAULT_REPEATS = 2

#: The impression's scalar fields: one word or one short phrase, compared for exact equality after
#: normalisation. `looks_like` and `confidence` are the two that decide anything (`vision/trust.py`:
#: `confidence` is relied_on as a trigger, `looks_like` is a candidate the customer confirms).
SCALAR_FIELDS: tuple[str, ...] = ("looks_like", "confidence", "orientation", "symmetry")

#: The list-of-phrase fields (`vision.prompt.PHRASE_FIELDS`). Compared as SETS with Jaccard, because the finding
#: is the set and the wording is not: trust.py measures `internal_features` at "Jaccard 0.31 to 0.46 from one
#: call: the finding repeats, the wording does not". `walk` is in the list for completeness and is prose-heavy,
#: so its Jaccard is expected near zero and is reported rather than hidden.
SET_FIELDS: tuple[str, ...] = ("internal_features", "could_not_check", "sharp_edges", "attachments",
                              "thin_parts", "defects", "cannot_tell", "marks_seen", "stops_seen", "walk")

#: The per-opening fields. `openings_seen` itself is scored as the SET of ids, and each field inside an entry is
#: scored per mouth over the mouths BOTH calls named - which is the only denominator that is about the field
#: rather than about recall.
OPENING_FIELDS: tuple[str, ...] = ("looks_like", "mouth", "likely_role")

#: Free prose, excluded by name and reported as excluded. See the module docstring.
NOT_SCORED: tuple[str, ...] = ("notes", "openings_seen[].why")

#: `likely_role`'s abstention words. An abstention is a real answer for this field - it is the product of it -
#: so the pair is scored twice: once for whether the WORD is the same, and once for whether the call abstained
#: at all. A reader that only had the first could not tell a stable guesser from a stable abstainer.
ABSTENTIONS: frozenset[str] = frozenset({"unsure", "", "none", "unknown"})


def _norm(value: Any) -> str:
    return " ".join(str(value if value is not None else "").strip().lower().split())


def _phrases(value: Any) -> set[str]:
    if not isinstance(value, list):
        return set()
    return {_norm(v) for v in value if _norm(v)}


def _jaccard(a: set[str], b: set[str]) -> float | None:
    """None on two empty sets, because two calls that both said nothing have no overlap to measure and a 1.0
    there would report perfect agreement on a field neither call used."""
    if not a and not b:
        return None
    return round(len(a & b) / len(a | b), 4)


def _entries(impression: dict[str, Any]) -> dict[str, dict[str, Any]]:
    out: dict[str, dict[str, Any]] = {}
    for e in impression.get("openings_seen") or []:
        if isinstance(e, dict):
            out[str(e.get("id") or "unlabelled")] = e
    return out


def compare(a: dict[str, Any], b: dict[str, Any]) -> dict[str, Any]:
    """Two impressions of the same pictures, field by field.

    Every row carries its own denominator: `n` is what was comparable and `agreed` is what matched, so a field
    neither call used contributes nothing rather than contributing agreement.
    """
    rows: dict[str, Any] = {}
    for name in SCALAR_FIELDS:
        x, y = _norm(a.get(name)), _norm(b.get(name))
        rows[name] = {"kind": "scalar", "n": 1 if (x or y) else 0, "agreed": int(bool(x or y) and x == y),
                      "first": x or None, "second": y or None}
    for name in SET_FIELDS:
        x, y = _phrases(a.get(name)), _phrases(b.get(name))
        rows[name] = {"kind": "set", "n": 1 if (x or y) else 0,
                      "agreed": int(bool(x or y) and x == y), "jaccard": _jaccard(x, y),
                      "first_n": len(x), "second_n": len(y)}
    ea, eb = _entries(a), _entries(b)
    ids_a, ids_b = set(ea), set(eb)
    rows["openings_seen"] = {"kind": "id_set", "n": 1 if (ids_a or ids_b) else 0,
                             "agreed": int(bool(ids_a or ids_b) and ids_a == ids_b),
                             "jaccard": _jaccard(ids_a, ids_b),
                             "first_n": len(ids_a), "second_n": len(ids_b),
                             "only_first": sorted(ids_a - ids_b), "only_second": sorted(ids_b - ids_a)}
    shared = sorted(ids_a & ids_b)
    for name in OPENING_FIELDS:
        agreed = sum(1 for oid in shared if _norm(ea[oid].get(name)) == _norm(eb[oid].get(name)))
        rows[f"openings_seen[].{name}"] = {"kind": "per_opening", "n": len(shared), "agreed": agreed}
    # THE ABSTENTION, SCORED ON ITS OWN. `likely_role` abstains on six of every seven declared mouths
    # (`vision/trust.py`), so a word-agreement rate on this field is mostly two calls agreeing to say nothing.
    # This row is whether the call abstained AT ALL, and `claims` below is the denominator of the other one.
    flips = sum(1 for oid in shared
                if (_norm(ea[oid].get("likely_role")) in ABSTENTIONS)
                != (_norm(eb[oid].get("likely_role")) in ABSTENTIONS))
    both_claim = [oid for oid in shared if _norm(ea[oid].get("likely_role")) not in ABSTENTIONS
                  and _norm(eb[oid].get("likely_role")) not in ABSTENTIONS]
    rows["openings_seen[].likely_role#abstention"] = {"kind": "per_opening", "n": len(shared),
                                                      "agreed": len(shared) - flips, "flips": flips}
    rows["openings_seen[].likely_role#both_guessed"] = {
        "kind": "per_opening", "n": len(both_claim),
        "agreed": sum(1 for oid in both_claim
                      if _norm(ea[oid].get("likely_role")) == _norm(eb[oid].get("likely_role")))}
    return rows


def floor(pairs: list[dict[str, Any]], repeats: int = DEFAULT_REPEATS) -> dict[str, Any]:
    """The measured floor over a sample: per field, how often two calls on one part's own pictures agree.

    A part whose recorded `model_calls` is not `repeats` is REFUSED and named, not averaged in. That is the one
    way this instrument could report a floor of 1.00 without having measured anything (a cache or a stub
    answering the second call), and the refusal is the check.
    """
    used, refused = [], {}
    for pair in pairs:
        calls = pair.get("model_calls")
        if pair.get("status") != "ok":
            refused[str(pair.get("part"))] = str(pair.get("why") or "the pair is not two ok looks")
        elif calls != repeats:
            refused[str(pair.get("part"))] = (f"the client made {calls} calls for {repeats} looks, so at least "
                                              f"one reply did not come from the reader")
        else:
            used.append(pair)
    names: list[str] = []
    for pair in used:
        for name in pair["fields"]:
            if name not in names:
                names.append(name)
    rows = []
    for name in names:
        cells = [p["fields"][name] for p in used if name in p["fields"]]
        n = sum(int(c.get("n") or 0) for c in cells)
        agreed = sum(int(c.get("agreed") or 0) for c in cells)
        js = [c["jaccard"] for c in cells if c.get("jaccard") is not None]
        rows.append({"field": name, "kind": cells[0].get("kind") if cells else None,
                     "parts": sum(1 for c in cells if (c.get("n") or 0) > 0),
                     "n": n, "agreed": agreed,
                     "identical_rate": round(agreed / n, 4) if n else None,
                     "mean_jaccard": round(statistics.mean(js), 4) if js else None,
                     "min_jaccard": min(js) if js else None})
    return {
        "schema": FLOOR_SCHEMA,
        "measured_at": datetime.now(UTC).isoformat(timespec="seconds"),
        "repeats": repeats,
        "parts": len(used),
        "parts_refused": refused,
        "excluded_fields": list(NOT_SCORED),
        #: R2 and the protocol's section 7: a floor measured under one reader and one prompt is not a floor for
        #: another. Every stamp that decides what the reader saw and answered travels with the number.
        "stamps": dict(Counter(f"{p.get('model')}/{p.get('provider')}/prompt {str(p.get('prompt_sha256'))[:12]}/"
                               f"{p.get('variant')}" for p in used)),
        "seconds": {"total": round(sum(float(p.get("seconds") or 0) for p in used), 1),
                    "per_look": round(statistics.mean([float(s) for p in used for s in p.get("look_seconds")
                                                       or []]), 1) if used else None},
        "fields": rows,
    }


def floor_table(doc: dict[str, Any]) -> str:
    lines = [f"the look against itself: {doc['parts']} parts, {doc['repeats']} looks each, "
             f"{len(doc['parts_refused'])} refused",
             f"stamps: {doc['stamps']}",
             "", "| field | kind | parts | n | identical | identical rate | mean jaccard | min jaccard |",
             "|---|---|---|---|---|---|---|---|"]
    for r in doc["fields"]:
        rate = "-" if r["identical_rate"] is None else f"{r['identical_rate']:.3g}"
        mj = "-" if r["mean_jaccard"] is None else f"{r['mean_jaccard']:.3g}"
        mn = "-" if r["min_jaccard"] is None else f"{r['min_jaccard']:.3g}"
        lines.append(f"| {r['field']} | {r['kind']} | {r['parts']} | {r['n']} | {r['agreed']} | {rate} | "
                     f"{mj} | {mn} |")
    for part, why in sorted(doc["parts_refused"].items()):
        lines.append(f"refused {part}: {why}")
    lines.append(f"not scored: {', '.join(doc['excluded_fields'])} (free prose, see the module docstring)")
    return "\n".join(lines)


# -------------------------------------------------------------------------------------------------
# taking the looks
# -------------------------------------------------------------------------------------------------

@dataclass
class _Counted:
    """The env's vision client with a call counter on it. The counter is the floor's own check: see the module
    docstring. It wraps rather than reimplements, so the request that goes out is the one the platform sends."""
    inner: Any
    calls: int = 0
    models: list[str] = field(default_factory=list)

    def describe(self, paths: Any, user: str, system: str = "") -> Any:
        self.calls += 1
        reply = self.inner.describe(paths, user, system=system)
        self.models.append(str(getattr(reply, "model", "") or ""))
        return reply


def pair_for_part(path: Path, *, repeats: int = DEFAULT_REPEATS, client: Any = None,
                  cache_root_dir: Path | None = None, purpose: str = "internal_cfd",
                  log=print) -> dict[str, Any]:
    """One part looked at `repeats` times on ONE set of pictures, and the pairwise comparison of the first two.

    Never raises: a part that cannot be measured or looked at comes back with `status` and `why`, and `floor`
    refuses it by name.
    """
    from geometry_agent.facts import measure as facts_measure
    from geometry_agent.vision import client as vision_client
    from geometry_agent.vision import look as vision_look

    started = time.perf_counter()
    out: dict[str, Any] = {"part": path.name, "path": str(path), "status": "failed", "why": "",
                           "repeats": repeats, "model_calls": 0, "look_seconds": [], "impressions": [],
                           "fields": {}, "seconds": None}
    try:
        facts = facts_measure.measure(str(path))
    except Exception as exc:                       # noqa: BLE001 - a part that will not measure is named
        out["why"] = f"the part could not be measured ({type(exc).__name__}: {exc})"[:200]
        return out
    out["sha256"] = facts.sha256
    out["openings"] = len(facts.openings)
    if client is None:
        try:
            client = vision_client.vision_client_from_env()
        except Exception as exc:                   # noqa: BLE001
            out["why"] = f"no vision client ({type(exc).__name__}: {exc})"[:200]
            return out
    if client is None:
        out["why"] = vision_look.NO_CLIENT
        return out
    counted = _Counted(client)
    blocks = []
    for i in range(repeats):
        block = vision_look.look_at_geometry(str(path), facts, client=counted, purpose=purpose,
                                            cache_root_dir=cache_root_dir)
        blocks.append(block)
        out["look_seconds"].append(block.get("seconds"))
        log(f"  look {i + 1}/{repeats} on {path.name}: {block.get('status')} "
            f"({block.get('seconds')}s, {counted.calls} model calls)")
    out["model_calls"] = counted.calls
    out["seconds"] = round(time.perf_counter() - started, 1)
    bad = [b for b in blocks if b.get("status") != "ok"]
    if bad:
        out["why"] = f"{len(bad)} of {repeats} looks did not come back ok: {bad[0].get('reason')}"[:250]
        return out
    imps = [b.get("impression") or {} for b in blocks]
    first = blocks[0]
    #: `look._asked` writes the prompt's identity under `prompt`, not `asked`. Read off the key the block
    #: actually has: a stamp read from the wrong key is None on every row, and R2 cannot be checked against
    #: None - the first run of this harness reported `prompt None` for all 14 parts for exactly that reason.
    asked = first.get("prompt") if isinstance(first.get("prompt"), dict) else {}
    out.update({
        "status": "ok",
        "model": first.get("model"), "provider": first.get("provider"),
        "prompt_sha256": asked.get("system_sha256"), "variant": asked.get("variant"),
        #: the WHOLE impression of each call, so a number in the summary can be traced to the two replies it
        #: came from and a later field can be scored without paying for the looks again
        "impressions": imps,
        "fields": compare(imps[0], imps[1]),
    })
    return out


def run(parts: list[Path], *, repeats: int = DEFAULT_REPEATS, out_dir: Path | None = None,
        cache_root_dir: Path | None = None, client: Any = None, log=print) -> dict[str, Any]:
    """Look at every part `repeats` times, write the pairs and the floor, and return the summary document."""
    out_dir = Path(out_dir or FLOOR_DIR)
    pairs = []
    for i, path in enumerate(parts, 1):
        log(f"[{i}/{len(parts)}] {path.name}")
        pair = pair_for_part(Path(path), repeats=repeats, client=client, cache_root_dir=cache_root_dir, log=log)
        pairs.append(pair)
        store.write_json(out_dir / "pairs" / f"{Path(path).stem}.json", pair)
    doc = floor(pairs, repeats)
    summary = out_dir / f"floor_{datetime.now(UTC).date().isoformat()}.json"
    store.write_json(summary, doc)
    log(floor_table(doc))
    log(f"look floor -> {summary}")
    return doc


def main(argv: list[str] | None = None) -> int:
    import argparse
    ap = argparse.ArgumentParser(prog="python -m geometry_agent.learn.look_floor",
                                 description="How much the look disagrees with itself on one set of pictures.")
    ap.add_argument("parts", nargs="+", help="CAD files, or directories to take every CAD file from")
    ap.add_argument("--repeats", type=int, default=DEFAULT_REPEATS)
    ap.add_argument("--out", default=str(FLOOR_DIR))
    ap.add_argument("--render-cache", default=None,
                    help="where the shared render cache lives; the default is the renderer's own")
    a = ap.parse_args(argv)
    paths: list[Path] = []
    for raw in a.parts:
        p = Path(raw)
        if p.is_dir():
            paths.extend(sorted(q for q in p.iterdir()
                                if q.suffix.lower() in (".step", ".stp", ".stl", ".obj", ".ply", ".iges")))
        else:
            paths.append(p)
    if not paths:
        print("no parts")
        return 2
    if a.repeats < 2:
        print("a floor needs at least two looks")
        return 2
    doc = run(paths, repeats=a.repeats, out_dir=Path(a.out),
              cache_root_dir=None if a.render_cache is None else Path(a.render_cache))
    print(json.dumps({k: v for k, v in doc.items() if k != "fields"}, indent=1))
    return 0 if doc["parts"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
