"""Vision model access behind one Protocol: an OpenAI-compatible adapter (DeepInfra; DeepSeek only once it
has proved it can see), an Anthropic adapter over raw httpx, a stub for tests, a capability probe, and
`vision_client_from_env`. Every request goes through `agent.client.post_json`, so the hermetic tests' loopback
guard on httpx.post covers vision too and the retry behaviour matches the text client."""
from __future__ import annotations

import base64
import copy
import dataclasses
import os
import tempfile
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Protocol

from geometry_agent.agent import client as text_client
from geometry_agent.agent.client import ModelError

PROVIDER_ENV = "GEOMETRY_AGENT_VISION_PROVIDER"
MODEL_ENV = "GEOMETRY_AGENT_VISION_MODEL"
TIMEOUT_ENV = "GEOMETRY_AGENT_VISION_TIMEOUT"
DEEPINFRA_MODEL_ENV = "DEEPINFRA_VISION_MODEL"
PROVIDERS = ("auto", "anthropic", "openai", "deepinfra", "deepseek", "off")
#: Output budget added for a reasoning model, on top of what the answer itself needs (see describe()).
REASONING_HEADROOM = 8000
DEFAULT_OPENAI_BASE = "https://api.openai.com/v1"
#: The vision-capable default. GEOMETRY_AGENT_VISION_MODEL or OPENAI_VISION_MODEL overrides it, which is how a
#: comparison run pins one model without touching the code.
#:
#: It was `gpt-5`, then `gpt-5.6-luna` (Rehaan's choice, 2026-09-15, astra kept for escalation), then
#: `gpt-6-astra` from 2026-09-16 on an agent's measurement, and it is `gpt-5.6-luna` again from 2026-09-17.
#:
#: WHY IT MOVED TO ASTRA, AND WHAT OF THAT WAS THE RULER. The held-out number that moved it (luna 102 to 108 of
#: 142, astra 125 to 130) was read by a ruler whose negation check fired on the "no" in "goes no further". With
#: the ruler reading the prompt's own words (`GEOMETRY_AGENT_VISION_DIALECT=prompt`), the row that decided it,
#: the manifold's closed header end, reads luna 13, 13, 12, 13 against astra 13, 13, 13, 13.
#:
#: THE TRADE, ON EVERY COLUMN, not only the eleven held-out rows. Four luna draws taken on work/z-vision against
#: astra's four committed `combo_sa` draws, same prompt sha (2be3323138a23ad4), same seventeen views, prompt
#: dialect; `eval/vision/results/z_look/reports/reader_prompt.md`. Every draw quoted, astra first:
#:
#:   the failure this project is named after, a passage called plain where the brief puts something in it,
#:   of 26 held out: astra 12, 10, 10, 9 against luna 9, 13, 9, 14. A TIE.
#:   astra leads, clean four-against-four sweeps: the eleven held-out rows 121, 119, 122, 117 against 107, 110,
#:   108, 107, all of it the volute scroll (11, 11, 11, 10 against 2, 0, 2, 1), the S-duct (11 x4 against 2,
#:   5, 5, 3) and the conical diffuser inlet stub (2, 3, 3, 2 against 0 x4); true "plain" on a plain passage,
#:   139 to 141 against 123 to 130 of 152; the right thing named inside, 15 or 16 against 12 or 13 of 44;
#:   labelled mouths left unnamed, 40 to 43 against 121 to 153 of 1,595; the catch-all identity, 8 to 13
#:   against 85 to 93; ports guessed on non-ports, 0 or 1 against 15 to 19 (recorded, never reaches a builder).
#:   luna leads: the venturi throat (10 x4 against 5 to 7), the cross-section morph (17, 18 against 14 x4), the
#:   collector (9 x4 against 6 to 8), and `denial.py`'s false denials held out (2 to 6 against 7 to 11).
#:
#: WHAT IT COSTS. luna $5.30 a thousand cold jobs; astra $135.71 on an ASSUMED rate (luna's times
#: `score.ASTRA_RATE_MULTIPLE`), about 25 times more. astra buys identity and mouth-naming, and it buys nothing
#: on the named failure. That is the trade Rehaan took on 2026-09-15 and the one this default takes again.
#:
#: `OPENAI_VISION_MODEL=gpt-6-astra` puts the dearer reader back without touching the code, and every
#: benchmark arm pins its reader that way.
DEFAULT_OPENAI_MODEL = "gpt-5.6-luna"
#: The reader worth escalating one part to, and the three held-out families where it still leads luna on every
#: draw. Nothing calls it yet: it is the name `with_model` would be handed when the cheap reader's identity is in
#: doubt on a part that could be one of these.
ESCALATION_OPENAI_MODEL = "gpt-6-astra"
ESCALATION_BUYS = ("volute scroll", "S-duct", "conical diffuser inlet stub")
OPENAI_MODEL_ENV = "OPENAI_VISION_MODEL"
DEFAULT_DEEPINFRA_BASE = "https://api.deepinfra.com/v1/openai"
DEFAULT_DEEPINFRA_MODEL = "Qwen/Qwen3-VL-235B-A22B-Instruct"
DEFAULT_DEEPSEEK_BASE = "https://api.deepseek.com/v1"
DEFAULT_DEEPSEEK_MODEL = "deepseek-v4-pro"
DEFAULT_ANTHROPIC_BASE = "https://api.anthropic.com"
DEFAULT_ANTHROPIC_MODEL = "claude-opus-5"
ANTHROPIC_VERSION = "2023-06-01"
#: The ceiling on the ANSWER, not a target: a provider stops here and bills what it wrote. It was 2,048 and a
#: reply that reached it was cut mid-object, parsed as far as it went and came back mostly "unsure". Measured
#: on the cached replies, 2,576 luna (eight full draws) and 1,288 astra (four), seventeen views: the answer is
#: about 500 tokens at the median and 1,728 at the largest, on a part with 24 labelled mouths, which is
#: `render.MAX_LABELS`. On parts that list fifteen or more mouths the answer costs 45 to 85 tokens a mouth,
#: so 2,048 held between about 20 and 40 entries and a crowded part could reach it. 4,096 holds about 44 at the
#: dearest rate measured and about 60 at the usual one; a reply that still reaches it is refused
#: (`VisionTruncated`), never read. On OpenAI the cap sent is this plus `REASONING_HEADROOM`.
DEFAULT_MAX_TOKENS = 4096
#: The finish reasons that mean the provider stopped at the ceiling rather than at the end of the answer:
#: OpenAI and every OpenAI-compatible provider say `length`, Anthropic says `max_tokens`.
TRUNCATED = ("length", "max_tokens")
#: The finish reasons that mean the provider withheld the answer: OpenAI's filter, Anthropic's refusal.
WITHHELD = ("content_filter", "refusal")
DEFAULT_TIMEOUT = 180.0
#: More patience than the text client's two. The look is no longer something the model chooses to spend a round
#: on: it happens on every run, so a provider that is briefly busy must not cost the run its description. Five
#: concurrent looks at DeepInfra's Qwen3-VL returned HTTP 429 "Model busy, retry later" on all five and gave up
#: inside four seconds; at four retries the backoff runs 1, 2, 4 and 8 seconds, which is the shape of that outage.
DEFAULT_MAX_RETRIES = 4
#: A 1 x 1 white PNG: the capability probe sends it and asks for one word.
PROBE_PNG = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+ip1sAAAAASUVORK5CYII=")
PROBE_PROMPT = "Reply with the single word ok."


class VisionError(ModelError):
    pass


class VisionTruncated(VisionError):
    """The reply stopped at the output ceiling. What came back is the front of an answer, and the parser would
    have read it as far as it went and filled the rest with "unsure" and empty lists, and an empty
    `internal_features` is the one value the builder relies on to mean the passage is plain. So it is refused
    here, loudly, and never read."""


@dataclass
class VisionReply:
    text: str
    usage: dict
    model: str
    provider: str
    #: Why the provider stopped: `stop` or `end_turn` at the end of the answer, `length` or `max_tokens` at the
    #: ceiling. None when the provider does not say. Carried so a caller that did not build the reply through
    #: an adapter below can still refuse a cut-off one (`refusal`).
    finish_reason: str | None = None

    @property
    def truncated(self) -> bool:
        return str(self.finish_reason or "").lower() in TRUNCATED


def refusal(reply) -> str | None:
    """Why this reply must not be read, or None when it may be. Duck-typed, so a client someone else wrote is
    held to the same rule as the adapters here: a reply cut off at the ceiling, or withheld by the provider."""
    why = str(getattr(reply, "finish_reason", None) or "").lower()
    if why in TRUNCATED:
        usage = getattr(reply, "usage", None)
        spent = (usage.get("completion_tokens") or usage.get("output_tokens")) if isinstance(usage, dict) else None
        return (f"the reply stopped at the output ceiling (finish_reason {why}"
                + (f", {spent} tokens" if spent else "") + ") and was refused rather than read part-written")
    if why in WITHHELD:
        return f"the provider withheld the reply (finish_reason {why})"
    return None


def checked(reply: VisionReply) -> VisionReply:
    """The reply, or `VisionTruncated` / `VisionError` when `refusal` says it must not be read."""
    why = refusal(reply)
    if why is None:
        return reply
    if reply.truncated:
        raise VisionTruncated(why)
    raise VisionError(why)


class VisionClient(Protocol):
    model: str
    provider: str

    def describe(self, images: list[Path], prompt: str, system: str | None = None) -> VisionReply: ...


def _png_base64(path: str | Path) -> str:
    data = Path(path).read_bytes()
    if not data.startswith(b"\x89PNG"):
        raise VisionError(f"{Path(path).name}: not a PNG")
    return base64.b64encode(data).decode("ascii")


def _content_text(content) -> str:
    """The text of an OpenAI-style message content, whether it is a string or a list of typed parts."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "".join(str(p.get("text", "")) for p in content if isinstance(p, dict) and p.get("type", "text") == "text")
    return ""


@dataclass
class OpenAICompatibleVision:
    """Chat completions with `image_url` data URLs (PNG base64) followed by the text: the shape DeepInfra
    serves the platform's own mesh reviewer with."""
    base_url: str
    #: Never in a repr. A dataclass prints every field, so an f-string in a log line, a pytest assertion
    #: that shows the client, or any traceback whose frame holds one puts the key in clear into a file
    #: someone may paste into a report. It was doing exactly that; seen in a real transcript 2026-09-15.
    api_key: str | None = field(repr=False)
    model: str
    timeout: float = DEFAULT_TIMEOUT
    max_tokens: int = DEFAULT_MAX_TOKENS
    temperature: float = 0.0
    provider: str = "openai"
    max_retries: int = DEFAULT_MAX_RETRIES

    def describe(self, images: list[Path], prompt: str, system: str | None = None) -> VisionReply:
        content = [{"type": "image_url", "image_url": {"url": f"data:image/png;base64,{_png_base64(p)}"}} for p in images]
        content.append({"type": "text", "text": prompt})
        messages = ([{"role": "system", "content": system}] if system else []) + [{"role": "user", "content": content}]
        # OpenAI's newer models renamed the output cap and refuse the old name, and they refuse a temperature
        # other than the default. DeepInfra and the rest still take both, so the shape is chosen by provider
        # rather than guessed from an error.
        if self.provider == "openai":
            # Reasoning tokens are spent from the same budget before a single character of the answer is written:
            # on one part the model burned 3,776 of them and the 2,048 cap truncated the reply to nothing, which
            # reads downstream as "unsure" on every field. The cap is raised by REASONING_HEADROOM so the answer
            # itself has room. Measured 2026-09-15 on annular_007: 3,776 reasoning, 298 answer.
            body = {"model": self.model, "messages": messages,
                    "max_completion_tokens": self.max_tokens + REASONING_HEADROOM}
        else:
            body = {"model": self.model, "messages": messages, "max_tokens": self.max_tokens,
                    "temperature": self.temperature}
        headers = {"content-type": "application/json"}
        if self.api_key:
            headers["authorization"] = f"Bearer {self.api_key}"
        try:
            data = text_client.post_json(f"{self.base_url.rstrip('/')}/chat/completions", body, headers, self.timeout, self.max_retries)
        except ModelError as exc:
            raise VisionError(str(exc)) from exc
        try:
            choice = data["choices"][0]
            msg = choice["message"]
        except (KeyError, IndexError, TypeError) as exc:
            raise VisionError(f"malformed response: {str(data)[:300]}") from exc
        if not isinstance(msg, dict):
            raise VisionError(f"malformed response: {str(data)[:300]}")
        finish = choice.get("finish_reason") if isinstance(choice, dict) else None
        return checked(VisionReply(text=_content_text(msg.get("content")), usage=data.get("usage") or {},
                                   model=str(data.get("model") or self.model), provider=self.provider,
                                   finish_reason=str(finish) if finish else None))


@dataclass
class AnthropicVision:
    """The Messages API with base64 image blocks followed by the text block. No sampling parameters: the
    current models reject temperature, and the default (adaptive) thinking is what a look at a part wants."""
    api_key: str = field(repr=False)
    model: str = DEFAULT_ANTHROPIC_MODEL
    base_url: str = DEFAULT_ANTHROPIC_BASE
    timeout: float = DEFAULT_TIMEOUT
    max_tokens: int = DEFAULT_MAX_TOKENS
    provider: str = "anthropic"
    max_retries: int = DEFAULT_MAX_RETRIES

    def describe(self, images: list[Path], prompt: str, system: str | None = None) -> VisionReply:
        content = [{"type": "image", "source": {"type": "base64", "media_type": "image/png", "data": _png_base64(p)}} for p in images]
        content.append({"type": "text", "text": prompt})
        body: dict = {"model": self.model, "max_tokens": self.max_tokens, "messages": [{"role": "user", "content": content}]}
        if system:
            body["system"] = system
        headers = {"content-type": "application/json", "anthropic-version": ANTHROPIC_VERSION, "x-api-key": self.api_key}
        try:
            data = text_client.post_json(f"{self.base_url.rstrip('/')}/v1/messages", body, headers, self.timeout, self.max_retries)
        except ModelError as exc:
            raise VisionError(str(exc)) from exc
        if not isinstance(data, dict):
            raise VisionError(f"malformed response: {str(data)[:300]}")
        if data.get("stop_reason") == "refusal":
            raise VisionError("the vision model declined to describe the images")
        blocks = data.get("content") or []
        text = "".join(str(b.get("text", "")) for b in blocks if isinstance(b, dict) and b.get("type") == "text")
        stop = data.get("stop_reason")
        return checked(VisionReply(text=text, usage=data.get("usage") or {}, model=str(data.get("model") or self.model),
                                   provider=self.provider, finish_reason=str(stop) if stop else None))


@dataclass
class StubVision:
    """A fixed reply, or a callable of (images, prompt) that makes one. Records every call so a test can
    assert what was sent and how often. `finish_reason` is what the stub says it stopped for, and it goes
    through the same `checked` the real adapters do, so `length` raises `VisionTruncated` here too."""
    reply: str | Callable[[list[Path], str], str] = "{}"
    model: str = "stub"
    provider: str = "stub"
    calls: list[dict] = field(default_factory=list)
    finish_reason: str | None = "stop"

    def describe(self, images: list[Path], prompt: str, system: str | None = None) -> VisionReply:
        paths = [Path(p) for p in images]
        self.calls.append({"images": paths, "prompt": prompt, "system": system})
        text = self.reply(paths, prompt) if callable(self.reply) else self.reply
        return checked(VisionReply(text=text, usage={}, model=self.model, provider=self.provider,
                                   finish_reason=self.finish_reason))


def with_model(client: VisionClient, model: str) -> VisionClient:
    """The same client pointed at another model of the same provider: same key, same base URL, same timeout.

    This is what escalation is made of. A second, dearer reader is worth calling on the small fraction of parts
    the first one got wrong, and the alternative to this function is building a second client from the
    environment, which reads the env again and can silently pick a different provider, a different base URL or
    a different timeout from the one the run has been using. A copy cannot drift.

    Non-dataclass clients (a stub, or anything a caller passes in) are copied shallowly and their `model` set,
    which is the same promise without `dataclasses.replace`."""
    name = str(model or "").strip()
    if not name:
        raise ValueError("with_model needs a model name")
    if dataclasses.is_dataclass(client) and not isinstance(client, type):
        return dataclasses.replace(client, model=name)
    clone = copy.copy(client)
    clone.model = name
    return clone


def probe_vision_capability(client: VisionClient) -> bool:
    """True when the model answers a one-pixel image with any text: the only evidence that a text provider
    (DeepSeek) accepts images at all. Any error, including a 4xx, is a False, never an exception."""
    fd, name = tempfile.mkstemp(suffix=".png", prefix="vision_probe_")
    path = Path(name)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(PROBE_PNG)
        reply = client.describe([path], PROBE_PROMPT)
        return bool(reply.text.strip())
    except (ModelError, OSError, ValueError):
        return False
    finally:
        try:
            path.unlink()
        except OSError:
            pass


def _timeout(env) -> float:
    try:
        return float(env.get(TIMEOUT_ENV) or DEFAULT_TIMEOUT)
    except ValueError:
        return DEFAULT_TIMEOUT


def _key(env, name: str) -> str:
    """A reader's API key, with surrounding whitespace taken off. Empty when there is none.

    Whitespace is never part of a credential and may not be part of a header. `docker run --env-file` does not
    trim a value (`docker compose env_file` does), so a .env line written with a space after the `=` reached the
    process with it, and `Bearer  <key> ` is not a legal header value: httpx raises `LocalProtocolError` on every
    attempt, and a correct key looks like a dead provider. `agent/client._key` is the same fix on the text half.
    """
    value = env.get(name)
    return value.strip() if isinstance(value, str) else ""


def _anthropic(env) -> VisionClient | None:
    key = _key(env, "ANTHROPIC_API_KEY")
    if not key:
        return None
    return AnthropicVision(api_key=key, model=env.get(MODEL_ENV) or DEFAULT_ANTHROPIC_MODEL,
                           base_url=(env.get("ANTHROPIC_BASE_URL") or DEFAULT_ANTHROPIC_BASE).rstrip("/"), timeout=_timeout(env))


def _openai(env) -> VisionClient | None:
    """OpenAI's own endpoint. The same wire shape as DeepInfra, so the same client: OpenAI is the original
    of the format DeepInfra imitates. Only the base URL, the key and the model differ."""
    key = _key(env, "OPENAI_API_KEY")
    if not key:
        return None
    return OpenAICompatibleVision(base_url=(env.get("OPENAI_BASE_URL") or DEFAULT_OPENAI_BASE).rstrip("/"),
                                  api_key=key,
                                  model=env.get(MODEL_ENV) or env.get(OPENAI_MODEL_ENV) or DEFAULT_OPENAI_MODEL,
                                  timeout=_timeout(env), provider="openai")


def _deepinfra(env) -> VisionClient | None:
    key = _key(env, "DEEPINFRA_API_KEY")
    if not key:
        return None
    model = env.get(MODEL_ENV) or env.get(DEEPINFRA_MODEL_ENV) or DEFAULT_DEEPINFRA_MODEL
    return OpenAICompatibleVision(base_url=(env.get("DEEPINFRA_BASE_URL") or DEFAULT_DEEPINFRA_BASE).rstrip("/"), api_key=key,
                                  model=model, timeout=_timeout(env), provider="deepinfra")


def _deepseek(env) -> VisionClient | None:
    key = _key(env, "DEEPSEEK_API_KEY")
    if not key:
        return None
    model = env.get(MODEL_ENV) or env.get("DEEPSEEK_MODEL") or DEFAULT_DEEPSEEK_MODEL
    return OpenAICompatibleVision(base_url=(env.get("DEEPSEEK_BASE_URL") or DEFAULT_DEEPSEEK_BASE).rstrip("/"), api_key=key,
                                  model=model, timeout=_timeout(env), provider="deepseek")


#: The order `auto` tries the keys in. OpenAI FIRST, because it is the only provider whose reader every tier in
#: `trust.py` was measured on (322 parts, file name hidden, gpt-5.6-luna). Anthropic used to come first, which
#: meant any environment holding both keys (a platform whose other agents run on Claude is exactly that) sent
#: the look to a reader this bench has never scored, under tiers written for a different one.
AUTO_ORDER = ("openai", "anthropic", "deepinfra")


def vision_client_from_env(provider: str = "auto") -> VisionClient | None:
    """The vision model for this environment, or None when there is none: `auto` honours
    GEOMETRY_AGENT_VISION_PROVIDER (anthropic | openai | deepinfra | deepseek | off), then takes the first
    provider in `AUTO_ORDER` whose key is set: OpenAI, then Anthropic, then DeepInfra. DeepSeek is used only when
    asked for by name and only after the probe shows it accepts an image; image support there is never assumed.
    GEOMETRY_AGENT_VISION_MODEL overrides the model for whichever provider is chosen. The same dotenv files the
    text client reads are loaded first, so the CLI and the eval find .env.local the same way."""
    text_client.load_dotenv_files()
    env = os.environ
    provider = (provider or "auto").strip().lower()
    if provider == "auto":
        provider = (env.get(PROVIDER_ENV) or "auto").strip().lower() or "auto"
    if provider not in PROVIDERS:
        raise ValueError(f"unknown vision provider {provider!r}; one of {PROVIDERS}")
    if provider == "off":
        return None
    if provider == "anthropic":
        return _anthropic(env)
    if provider == "openai":
        return _openai(env)
    if provider == "deepinfra":
        return _deepinfra(env)
    if provider == "deepseek":
        client = _deepseek(env)
        return client if client is not None and probe_vision_capability(client) else None
    build = {"openai": _openai, "anthropic": _anthropic, "deepinfra": _deepinfra}
    for name in AUTO_ORDER:
        client = build[name](env)
        if client is not None:
            return client
    return None
