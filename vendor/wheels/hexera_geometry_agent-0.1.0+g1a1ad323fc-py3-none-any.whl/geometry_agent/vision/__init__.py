"""The vision tool: eight cached renders of a part and a words-only impression of them from a vision model.

`render.render_views` draws the views (one mesh load, openings labelled once, decimation above a face cap,
cached by the file's content hash); `client` holds the provider adapters and `vision_client_from_env`;
`prompt` holds the prompts and the number scrub. Nothing in this package is a measurement: the agent's
`look_at_views` tool returns words, and the checker rejects any number that exists only here."""
