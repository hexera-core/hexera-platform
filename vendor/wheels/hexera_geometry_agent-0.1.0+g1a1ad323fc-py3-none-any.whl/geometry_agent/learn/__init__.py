"""The learning loop (docs/dev_plan.md, section 3b): outcome records, the feature bank, the post-mortem ledger,
rule cards and calibration, plus the threshold-governance builder's replay_regression and rules.json.

One idempotent command does the ingest, the calibration tables, the feature bank, the post-mortem, the ledgers
and the rule cards; nothing else writes those files:

    python -m geometry_agent.learn.ingest eval/corpus_export_cases --source corpus_export

A locked record and the locked ledger are read by the post-mortem (which writes them) and the look script only;
tests/test_learn_isolation.py holds the feature bank, the sweep and the rule cards to that.

A THIRD POPULATION, added 2026-09-25 (docs/learning_loop.md section 10): finished jobs on the real platform,
exported by `meshpipeline.application.learning_export` and ingested by `learn/ingest_platform.py`:

    python -m geometry_agent.learn.ingest <exports dir> --source platform

They carry the one label the corpus cannot produce - what the customer said when we proposed something - and
they are on the `platform` side of the split, which nothing that calibrates reads. That command writes the
records and one summary and touches no ledger, no calibration table, no bank, no sweep and no card.
"""
