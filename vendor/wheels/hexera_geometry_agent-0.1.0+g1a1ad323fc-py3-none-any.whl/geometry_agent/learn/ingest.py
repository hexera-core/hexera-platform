"""The one learning-loop command (docs/dev_plan.md, section 3b).

    python -m geometry_agent.learn.ingest <path> --source corpus_export [--cache-dir DIR] [--outcomes DIR]
                                          [--split FILE] [--labels FILE] [--skip-postmortem] [--skip-sweeps]
    python -m geometry_agent.learn.ingest <results_dir> --source live --recordings <dir> [--cache-dir DIR]
    python -m geometry_agent.learn.ingest <exports_dir> --source platform [--platform-outcomes DIR]

In order: the records (idempotent), the calibration tables from learning records (cell correction, minutes
bins), the feature bank (learning and locked tables apart), the post-mortem into the two ledgers, the sweeps
on learning rows, and the rule cards. Every step prints what it wrote. Source live (learn/ingest_live.py) reads
a recorded live run's per-case results: its records go under eval/outcomes_live/<run>, the post-mortem scores
the agent's own warnings into the two ledgers by split, and the cards are regenerated; the calibration tables,
the bank and the sweeps are the export's and are not touched.

Source platform (learn/ingest_platform.py, docs/learning_loop.md section 10) reads a directory of job envelopes
written by `meshpipeline.application.learning_export`: its records go under eval/outcomes_platform/ on the
`platform` side of the split, and it writes ONE file besides them, eval/platform/summary_<date>.json. It runs no
post-mortem, no calibration, no bank and no sweep, and touches no ledger and no card: those are the corpus
export's and the learning half's, and a real customer job is a third population that may not move them.

Sources sample_export, harness, dose and blind arrive with their own steps of the plan (P3 and P5, P10, the end)
and are refused here by name until then.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from geometry_agent.learn import calibration, features, postmortem, rule_cards, store
from geometry_agent.learn.ingest_corpus_export import ingest as ingest_corpus_export
from geometry_agent.learn.schema import OutcomeRecord

SOURCES = ("corpus_export", "live", "platform", "sample_export", "harness", "dose", "blind")


def learning_records(outcomes_dir: Path, split_file: Path) -> list[OutcomeRecord]:
    out = []
    for p in store.record_paths(outcomes_dir, split_file, "learning"):
        rec = OutcomeRecord.model_validate_json(p.read_text(encoding="utf-8"))
        if rec.split == "learning":
            out.append(rec)
    return out


def calibrate(outcomes_dir: Path = store.OUTCOMES_DIR, split_file: Path = store.SPLIT_FILE,
              cell_correction_path: Path = store.CELL_CORRECTION, minutes_path: Path = store.MINUTES_BINS,
              labels_json: Path = store.LABELS_JSON) -> dict[str, Any]:
    """The two calibration tables from learning records, written with provenance."""
    records = learning_records(outcomes_dir, split_file)
    sha = store.read_split(split_file).get("sha256")
    label_version = store.labels_meta(labels_json).get("label_version") if Path(labels_json).exists() else None
    cc = calibration.fit_cell_correction(records, sha, label_version)
    store.write_json(cell_correction_path, cc)
    mb = calibration.fit_minutes_bins(records, sha)
    store.write_json(minutes_path, mb)
    calibration.reload()
    return {"learning_records": len(records), "cell_correction": {k: v["multiplier"] for k, v in cc["by_representation"].items()},
            "cell_correction_n": {k: v["n"] for k, v in cc["by_representation"].items()},
            "minutes_bins_engines": sorted(mb["table"]), "cell_correction_file": str(cell_correction_path), "minutes_file": str(minutes_path)}


def run(path: Path, source: str = "corpus_export", cache_dir: Path = store.DEFAULT_CACHE_DIR, outcomes_dir: Path = store.OUTCOMES_DIR,
        split_file: Path = store.SPLIT_FILE, labels_json: Path = store.LABELS_JSON, kind_labels_path: Path = store.KIND_LABELS,
        ledger: Path = store.LEDGER, ledger_locked: Path = store.LEDGER_LOCKED, features_csv: Path = store.FEATURES_CSV,
        features_locked_csv: Path = store.FEATURES_LOCKED_CSV, sweeps_dir: Path = store.SWEEPS_DIR,
        cell_correction_path: Path = store.CELL_CORRECTION, minutes_path: Path = store.MINUTES_BINS,
        rule_cards_json: Path = store.RULE_CARDS_JSON, rule_cards_md: Path = store.RULE_CARDS_MD,
        skip_postmortem: bool = False, skip_sweeps: bool = False, log=print, recordings_dir: Path | None = None,
        live_outcomes_dir: Path | None = None, platform_outcomes_dir: Path | None = None,
        platform_dir: Path = store.PLATFORM_DIR) -> dict[str, Any]:
    if source == "platform":
        from geometry_agent.learn import ingest_platform
        return ingest_platform.run(Path(path), platform_outcomes_dir, split_file, platform_dir, log=log)
    if source == "live":
        from geometry_agent.learn import ingest_live
        if not Path(path).is_dir():
            raise FileNotFoundError(f"no results directory at {path}")
        return ingest_live.run(Path(path), recordings_dir, store.CASES_DIR, labels_json, split_file, cache_dir, live_outcomes_dir,
                               kind_labels_path, ledger, ledger_locked, sweeps_dir, rule_cards_json, rule_cards_md,
                               skip_postmortem=skip_postmortem, log=log)
    if source != "corpus_export":
        raise NotImplementedError(f"source {source!r} is not ingestible yet: sample_export and harness land with P3/P5, "
                                  "dose with P10, blind at the end (docs/dev_plan.md, 3b)")
    if not Path(path).is_dir():
        raise FileNotFoundError(f"no case directory at {path}")
    out: dict[str, Any] = {}
    report = ingest_corpus_export(Path(path), labels_json, split_file, cache_dir, outcomes_dir)
    out["ingest"] = report.summary()
    log(f"records: {report.summary()}")

    out["calibration"] = calibrate(outcomes_dir, split_file, cell_correction_path, minutes_path, labels_json)
    log(f"calibration: cell correction {out['calibration']['cell_correction']} (n {out['calibration']['cell_correction_n']}); "
        f"minutes bins for {out['calibration']['minutes_bins_engines']}")

    # the bank reads the correction just written; the module cache was cleared by calibrate()
    bank = features.write_bank(Path(path), cache_dir, split_file, features_csv, features_locked_csv)
    out["features"] = bank
    log(f"features: {bank['learning_rows']} learning rows -> {bank['csv']}; {bank['locked_rows']} locked rows -> {bank['locked_csv']}; "
        f"bank v{bank['features_version']} {bank['features_hash']}" + (f"; no facts for {bank['missing_facts']}" if bank["missing_facts"] else ""))

    if not skip_postmortem:
        pm = postmortem.run(outcomes_dir, split_file, cache_dir, kind_labels_path, ledger, ledger_locked)
        out["postmortem"] = pm
        for side, s in pm["sides"].items():
            log(f"post-mortem {side}: {s['records']} records, {s['rows']} rows -> {s['ledger']} ({s['ledger_rows']} rows)")
        if pm.get("skipped"):
            log(f"post-mortem skipped records on neither side: {pm['skipped']}")

    if not skip_sweeps:
        sweep = store.load_eval_script("eval/calib/sweep.py")
        rows = sweep.load_learning_table(features_csv, labels_json)
        written = sweep.run_all(sweep.RULES, sweeps_dir, rows) if rows else {}
        out["sweeps"] = {k: str(v) for k, v in written.items()}
        for p in written.values():
            log("sweep " + sweep.summary_line(json.loads(Path(p).read_text(encoding="utf-8"))))

    cards = rule_cards.write_cards(ledger, sweeps_dir, kind_labels_path, rule_cards_json, rule_cards_md)
    out["rule_cards"] = cards
    log(f"rule cards: {cards['cards']} kinds from {cards['ledger_rows']} ledger rows -> {cards['md']}, {cards['json']}")
    return out


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="python -m geometry_agent.learn.ingest", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("path", help="the keyed case directory (eval/corpus_export_cases), a live run's results "
                                 "directory with --source live, or a directory of platform job envelopes with "
                                 "--source platform")
    ap.add_argument("--source", choices=SOURCES, default="corpus_export")
    ap.add_argument("--cache-dir", default=str(store.DEFAULT_CACHE_DIR), help="the facts cache the corpus was measured into (read-only)")
    ap.add_argument("--outcomes", default=str(store.OUTCOMES_DIR))
    ap.add_argument("--recordings", default=None, help="source live: the run's recordings (default: the matching directory under "
                                                       "$GEOMETRY_AGENT_RECORDINGS_DIR or eval/recordings)")
    ap.add_argument("--live-outcomes", default=None, help="source live: where the run's records go (default eval/outcomes_live/<run>)")
    ap.add_argument("--platform-outcomes", default=None, help="source platform: where the job records go "
                                                             "(default eval/outcomes_platform)")
    ap.add_argument("--split", default=str(store.SPLIT_FILE))
    ap.add_argument("--labels", default=str(store.LABELS_JSON))
    ap.add_argument("--skip-postmortem", action="store_true")
    ap.add_argument("--skip-sweeps", action="store_true")
    a = ap.parse_args(argv)
    try:
        run(Path(a.path), a.source, Path(a.cache_dir), Path(a.outcomes), Path(a.split), Path(a.labels),
            skip_postmortem=a.skip_postmortem, skip_sweeps=a.skip_sweeps,
            recordings_dir=Path(a.recordings) if a.recordings else None,
            live_outcomes_dir=Path(a.live_outcomes) if a.live_outcomes else None,
            platform_outcomes_dir=Path(a.platform_outcomes) if a.platform_outcomes else None)
    except (NotImplementedError, FileNotFoundError) as exc:
        print(str(exc), file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
