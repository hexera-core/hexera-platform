"""STEP 4. The measurement and the look describe the same part. This decides what happens when they disagree.

Steps 1 to 3 are built. The measurement sizes the file, the measurement decides what to draw, and the look
reads the pictures. Nothing between step 3 and step 5 has ever noticed that the two halves describe the same
object, so a look that says the passage is clear over a measured restriction reaches the builder unopposed and
tells it to stop looking. That is the failure this module exists to stop.

FOUR ACTIONS, and the third one is the whole argument.

    CONFIRMED   the measurement agrees. The claim goes through marked confirmed and a consumer may act on it.
                A candidate that has been confirmed is not a candidate any more: that is what the tier means
                (`vision.trust`: "the measurement sizes it, and until then nothing downstream may turn on it").
    SUPPRESSED  the measurement contradicts and HAS STANDING on this claim. The claim does not reach the
                builder and the disagreement is recorded in its place.
    DISPUTED    the measurement contradicts and does NOT have standing. The claim goes through at whatever tier
                the ledger already gives it, the disagreement is recorded, and it becomes a question with a
                default. This is the action that stops a contradiction silently becoming "the look is wrong".
    PASSED      the measurement has nothing to say. The claim goes through at its ledger tier, unchanged.

WHY DISPUTED HAD TO EXIST, and the number that forced it. `eval/vision/results/inventory/fault.md` judged every
contradiction on the headline claim against the corpus answer key. Where the look called a passage plain and
the profile found a restriction, THE MEASUREMENT was the one at fault on 11 of 14, 11 of 14, 11 of 13 and 11 of
14 across four draws. Where the look named something inside and the profile called the passage clear, the
measurement was at fault on 30 of 33, 31 of 32, 31 of 34 and 30 of 31. A reconciler that reads CONTRADICT as
"drop the look" would, on the commoner of the two directions, throw away about thirty true look statements a
draw to catch one to three false ones. Suppression is a real cost and this module is built to pay it only
where the measurement has earned the right to charge it.

THE NULL-FINDING RULE, which is where most of that cost goes.

    A CHANNEL'S ABSENCE OF A FINDING IS NEVER EVIDENCE AGAINST THE LOOK. ONLY A POSITIVE FINDING IS.

`inventory.py` registers every claim with a `cannot` line saying what that channel is blind to, written off the
code and not off any answer key. Read those lines and the asymmetry is plain. The profile "cannot read a
passage whose bore leaves the cut plane"; the mark channel "cannot see anything that touches the wall". So a
profile that reports `clear` and a mark channel that nominated no body have produced two things that look
identical in a boolean and are not: "I looked and there is nothing" and "I cannot see that kind of thing". The
inventory scores both as CONTRADICT because a claim function has to return one of three words. This module
re-reads the null side as SILENT and says so per claim in `NULL_SIDE`.

That single rule is what takes `named_over_clear` out of the suppression path, which is where 30 of every 33
measurement-at-fault contradictions live. It is not a tuning constant and nothing was fitted to reach it: the
`cannot` lines were written before this file existed and they are quoted in `NULL_SIDE` verbatim.

WHAT STANDING IS MADE OF. Two inputs and both are readable on a file nobody has seen.

  1. ENTITLEMENT, static, per claim, in `STANDING` below. It is a calibration constant in the same sense as
     `profile.DIP_FRACTION` and the `vision.trust` tiers: measured once against the corpus, written down with
     its number, and read at run time without touching a brief. Its source is named in every `why`.
  2. READABILITY, dynamic, per case. The channel's own report that it could see this part at all:
     `FlowProfile.usable`, `axis_trusted`, the representation, whether any letter was drawn. The measurement
     already computes all of it and `restriction_verdict` already returns `unreadable` loudly.

WHAT THIS FILE DOES NOT READ. No brief, no family, no case name, no expected answer, no answer key of any kind.
`tests/test_reconcile_verdict.py::test_the_reconciler_cannot_see_the_answer` pins that the way
`test_a_mark_cannot_see_the_answer` pins the mark nominator, and it is the test that makes every other number
here mean anything, because a reconciler that reads the brief is a demo.

WHAT THIS FILE IS NOT FOR. It never predicts how the mesh will turn out and it names no builder setting. It
describes places. The one thing it adds to the description is a place the measurement already had and dropped.
"""
from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Any

from geometry_agent.reconcile.inventory import CONFIRM, CONTRADICT, SILENT, Finding, Measured
from geometry_agent.vision import trust

RECONCILE_SCHEMA = "geometry_agent.reconciled_look.v1"

CONFIRMED = "confirmed"
SUPPRESSED = "suppressed"
DISPUTED = "disputed"
PASSED = "passed"
ACTIONS = (CONFIRMED, SUPPRESSED, DISPUTED, PASSED)

ACTION_MEANING = {
    CONFIRMED: "the measurement agrees: act on it, and do not treat it as a candidate any longer",
    SUPPRESSED: "the measurement contradicts it and is entitled to: it does not reach the builder",
    DISPUTED: "the measurement contradicts it and is not entitled to overrule: both are on the record and the "
              "customer is asked",
    PASSED: "the measurement has nothing to say: the ledger tier stands",
}

#: What a contradiction from this channel licenses.
OVERRULES = "overrules"
DISPUTES = "disputes"
RECORDS = "records"
LICENCES = (OVERRULES, DISPUTES, RECORDS)

LICENCE_MEANING = {
    OVERRULES: "a positive measured finding the channel is entitled to make: the look's claim is suppressed",
    DISPUTES: "a real disagreement between two sources of comparable standing: both are kept and a question "
              "is raised",
    RECORDS: "the disagreement is written down and acts on nothing, because neither side is worth acting on",
}

# ---------------------------------------------------------------------------------------------------------------
# the null-finding rule
# ---------------------------------------------------------------------------------------------------------------

#: PER CLAIM, WHICH SIDE OF A CONTRADICTION IS AN ABSENCE, and the `cannot` line that makes it one. The key is
#: the claim id; the value is (which_side, the quoted reason). `which_side` is the `Finding.said` shape that
#: means "the look asserted and the measurement found nothing", or the subject the inventory already stamps
#: for the same purpose.
#:
#: The quoted reasons are `inventory.py`'s own `cannot=` strings, cut to the clause that does the work. They
#: were written against the code before this module existed, which is the only reason they can be used here:
#: they are a statement about what a channel can see, not a statement about how often it is right.
NULL_SIDE: dict[str, dict[str, str]] = {
    "passage_plain_vs_profile": {
        "side": "names_over_clear",
        "why": "cannot read a passage whose bore leaves the cut plane (an s-duct, a tee branch). Those are "
               "SILENT and they are a third of the corpus",
        "measured": "the profile calls the passage clear on all 10 annular, all 12 blade-row-passage and 9 of "
                    "10 static-mixer parts, every one of which the brief says has something in it "
                    "(results/inventory/fault.md, by family)",
    },
    "passage_plain_vs_body_marks": {
        "side": "names_over_no_body",
        "why": "cannot see anything that touches the wall. A mixer element welded to the bore wall is not "
               "enclosed in that plane and nominates nothing",
        "measured": "0 of 12 blade-row-passage and 0 of 10 static-mixer parts carry a body mark "
                    "(results/inventory/fault.md, by family)",
    },
    "taper_named_vs_profile": {
        "side": "named_no_taper",
        "why": "a passage that narrows and widens back to the same size reads as no taper at all",
    },
    "sharp_edges_vs_counts": {
        "side": "knife:look_silent_measured",
        "why": "the look naming none rests only on the prompt's `empty when none`, so its silence is not an "
               "assertion to contradict",
    },
    "thin_parts_vs_clusters": {
        "side": "look_silent_measured",
        "why": "the look naming none rests only on the prompt's `empty when none`",
    },
    "attachment_flange_vs_ring": {
        "side": "no_ring_face",
        "why": "a boss, a bracket, a lug, a stem or a mounting pad: none of them is measured. The look is 25 "
               "of 25 on this field and the measurement cannot check a single one of those 25",
    },
}


# ---------------------------------------------------------------------------------------------------------------
# entitlement
# ---------------------------------------------------------------------------------------------------------------

#: WHAT A CONTRADICTION FROM EACH CLAIM LICENSES, with the measurement behind it.
#:
#: Read the `why` lines together and there is one pattern under them: the measurement overrules exactly where
#: it OWNS the quantity, and disputes everywhere it is a detector with a threshold in it. `vision.trust` already
#: wrote most of this down field by field in `measurement_has_it`, so where that key is present and the
#: measurement's side of the disagreement is a positive finding, this table agrees with the ledger rather than
#: inventing a second opinion.
#:
#: FOUR ENTRIES SAY `demoted` AND THEY ARE THE MOST IMPORTANT THING IN THIS FILE. I wrote this table from the
#: ledger and from the inventory's `cannot` lines, and then measured what each licence actually does to the
#: document. Four of them destroy more true statements than false ones, and one of those four is the claim this
#: whole round was named after.
#:
#: THE PROTOCOL, fixed before the numbers were read. `eval/vision/reconcile.py` splits the corpus by FAMILY,
#: dealt alternately from a sorted list, into a tuning half of 11 families and a held-out half of 11. Each
#: claim suppresses ALONE, every other claim switched off, over four draws. The rule is: a licence to overrule
#: SURVIVES only if, on the TUNING half, it kills at least as many false statements as true ones on EVERY draw.
#: A claim that never fires on the tuning half cannot be decided by it and keeps the standing the ledger gives
#: it, which is said in its entry rather than left to be assumed.
#:
#: What the rule cost me, said because a protocol you abandon when it is inconvenient is not a protocol:
#: `orientation_long_axis` pays on every draw of the HELD-OUT half (0 true to 3, 6, 4 and 3 false) and I
#: demoted it anyway, because on the tuning half it killed 2 true and 0 false on two draws of four. Choosing it
#: on the strength of the half it was not chosen on is the thing the split exists to prevent.
#:
#: A demoted claim is NOT switched off. It becomes DISPUTED: the disagreement is recorded from both sides, it
#: is what the customer's one question is about, and nothing the look said is destroyed. For the headline claim
#: that is the better product answer anyway, and it took the measurement to see it: the builder still learns
#: the profile found a valley, because `supplies()` puts the throat in the block as a measured place.
STANDING: dict[str, dict[str, Any]] = {
    "looks_like_kind_of_file": {
        "licence": OVERRULES,
        "why": "the representation is `catalog.representation`'s answer, not a detector's: a file either has a "
               "passage modelled in it or it does not, and the look calling a fluid domain a wing is checkable "
               "against that with nothing in between",
        "cost": "0 contradictions on all four draws (results/inventory/claim_table.md), so this licence has "
                "never yet been exercised. It fires on neither half of the ablation, so the metric could "
                "not test it and it keeps the standing the representation gives it",
        "untested": True,
    },
    "orientation_long_axis": {
        "licence": DISPUTES,
        "demoted": True,
        "why": "trust.FIELDS['orientation'] says `the measurement has this exactly, and the picture is the "
               "weaker of the two`, so this had the ledger behind it. It was demoted by the protocol and not "
               "by the evidence about the axis: on the tuning half it killed 2 true statements and 0 false on "
               "two draws of four, which fails the rule, and on the held-out half it kills 0 true and 3, 6, 4 "
               "and 3 false, which is a clean sweep I am not allowed to claim. This is the one row where I "
               "think the answer is probably OVERRULES and the discipline says I may not say so yet. The way "
               "to settle it is a second family split, not a re-read of this one",
        "cost": "18 to 20 contradictions a draw. Demoting it forgoes 3 to 6 false statements a draw",
    },
    "opening_id_exists": {
        "licence": OVERRULES,
        "why": "the measurement OWNS this namespace by construction. The ids come from `facts.openings`, the "
               "renderer draws those ids on the picture, and `vision/prompt.py` keeps an id only when it "
               "matches one. An id that is not in the list was not on the paper. This is the one place where "
               "the measurement's null IS positive, and it is positive by definition rather than by measurement",
        "cost": "0 contradictions on all four draws. It fires on neither half of the ablation, so the "
                "metric could not test it and it keeps its standing by construction, not by measurement",
        "untested": True,
    },
    "opening_looks_like_vs_class": {
        "licence": DISPUTES,
        "demoted": True,
        "why": "trust.FIELDS['openings_seen[].looks_like'] is RECORDED because `opening class is a thing the "
               "measurement has exactly`, which is why this started at OVERRULES. Measured alone on the "
               "tuning half it kills 2 true statements and 0 false on every one of four draws, and on the "
               "held-out half it never fires at all, so the hold-out cannot confirm the demotion and I say so "
               "rather than reporting a clean result. What it removes is `opening_kind` statements the judge "
               "calls true: the look's word for a mouth and the measurement's classification disagree without "
               "the look being wrong about the mouth",
        "cost": "30 to 34 contradictions a draw, now recorded and questioned instead of removed",
    },
    "opening_mouth_vs_bbox": {
        "licence": DISPUTES,
        "why": "trust.FIELDS['openings_seen[].mouth'] is a candidate that was NEVER SCORED, and its `why` says "
               "in terms that `no measurement reports whether a mouth stands proud, sits flush in the wall or "
               "sits down in a pocket`. What this claim reads is a bounding-box proxy, and the inventory's own "
               "record of building it lists 86 false contradictions from `on_bbox_face` and 101 more from a "
               "tube behind a face before it was narrowed to what it now checks",
        "cost": "4 to 6 contradictions a draw, none of them suppressed",
    },
    "opening_role_not_a_port": {
        "licence": DISPUTES,
        "demoted": True,
        "why": "narrow on purpose: it fires only where the representation says there is no passage at all, so "
               "its side is a structural fact rather than a judgement about a role, and that is why it started "
               "at OVERRULES. On the tuning half it kills 1 true statement and 0 false on every one of four "
               "draws, and never fires on the held-out half. One statement a draw is a small cost and the rule "
               "does not have a size threshold in it, because a threshold is where a protocol starts being "
               "negotiated",
        "cost": "1 contradiction a draw",
    },
    "passage_plain_vs_profile": {
        "licence": DISPUTES,
        "demoted": True,
        "scope": "a change of section, never an object",
        "measured": "THE RESULT OF THIS ROUND. Suppressing on this claim alone kills 68, 70, 71 and 71 TRUE "
                    "statements on the held-out half and 20, 15, 11 and 19 false ones. On the tuning half it "
                    "kills 4 true and 0 false on every draw. It costs on every draw of both halves and it is "
                    "the claim the round was named after. The reason is already in the inventory's fault "
                    "table and I did not believe it hard enough: the measurement is the one at fault on 11 of "
                    "14 of these, and the judge agrees, scoring `the passage is plain` TRUE on the parts where "
                    "the section narrows and recovers with nothing standing in it. So the look is right there "
                    "and the profile's valley is a throat, not an obstruction. Suppression is the wrong "
                    "instrument for a definitional split and DISPUTED is the right one",
        "why": "THE HEADLINE. The profile's positive finding is a valley with prominence: the section narrows "
               "to a measured fraction of its own peak and RECOVERS, at a measured place. `dip` fires on 20 of "
               "20 venturi and orifice runs and 0 of 25 straight reducers, so it is not measuring `does the "
               "section change` and the finding is real. What it is NOT is evidence that an object stands in "
               "the bore, and `the passage is plain` is a claim about an object. Two true statements about the "
               "same geometry in two vocabularies is a disagreement to put in front of a person, not one to "
               "settle by deleting a sentence. The builder still learns about the valley, because `supplies()` "
               "puts the throat in the block as a measured place with its depth and where it is",
        "cost": "13 to 14 contradictions a draw in this direction. The other direction is null and is not "
                "here. Nothing is suppressed; all 13 to 14 are recorded and questioned",
    },
    "passage_plain_vs_body_marks": {
        "licence": OVERRULES,
        "why": "the strongest positive finding in the table and the only one that is a place rather than a "
               "number. A body mark is a piece of material the bore closes around, nominated from the cut "
               "image the model was shown, lettered on that image, and asked about by name in the prompt. So "
               "the look denied a thing while looking at a letter drawn on it. `obstruction_marks` reads the "
               "kind through the representation, which is the sign error that cost the inventory 444 false "
               "contradictions before it was fixed and is pinned by name in its tests",
        "cost": "0 to 3 contradictions a draw on 259 eligible parts. It almost never fires, and when it does "
                "it is over a picture that shows the thing plainly",
        "measured": "THE ONE SUPPRESSION THAT PAYS. Alone on the tuning half it kills 5 true statements "
                    "against 11 false, then 5 against 6, then 0 against 0, then 0 against 0; on the "
                    "held-out half 0 against 3, 0 against 0, 0 against 0, 0 against 6. It never loses on "
                    "any draw of either half. It is also the narrowest claim in the table, which is the "
                    "lesson: what survived is the one channel that points at a place rather than at a "
                    "quantity",
    },
    "taper_named_vs_profile": {
        "licence": OVERRULES,
        "supplies": True,
        "scope": "a change of section between the two ends, never a cone and never a step",
        "why": "the diffuser row is 2 or 3 of 13 to the look and the measurement has the ratio to three "
               "decimals in an array `render.choose_stations` computes and throws away. Where this contradicts "
               "because the look named a taper the profile cannot see, the measurement's side is null (the "
               "profile reads the two ends) and NULL_SIDE takes it out of the suppression path. Where it "
               "contradicts because the profile measured a taper and the look named none, there is nothing to "
               "suppress: the look asserted nothing. So this claim's licence is spent on SUPPLYING the "
               "measured ratio rather than on removing anything",
        "cost": "no suppression in either direction",
    },
    "insert_named_vs_bodies": {
        "licence": OVERRULES,
        "why": "a second body in the file, or a region whose `contains` is non-empty, is a count and a "
               "containment test rather than a detector. The claim already stands down on a one-body file, "
               "which is 306 of 316",
        "cost": "it fires on 10 of 316 parts at all. Alone it kills 0 true and 3 false on one half-draw "
                "and 0 and 0 on the other seven, so it has never yet cost a true statement",
    },
    "sharp_edges_vs_counts": {
        "licence": OVERRULES,
        "why": "`sharp_edge_count` and `knife_edge_count` are dihedral-angle counts over every edge of the "
               "mesh. A count of zero positively establishes that there is no such edge ANYWHERE, which is the "
               "one thing about this field the measurement can settle; the claim is already written to fire "
               "only on that extreme, and its `cannot` is about WHERE and not about whether",
        "cost": "39 to 41 contradictions a draw. Alone it removes no statement the judge can read, on "
                "either half of any draw: what the look calls a sharp edge is prose the statement reader "
                "does not turn into a claim, so the metric cannot see this licence at all",
        "untested": True,
    },
    "attachment_flange_vs_ring": {
        "licence": DISPUTES,
        "why": "the look's best field and the measurement's worst. trust.FIELDS['attachments'] is RELIED_ON at "
               "25 of 25 with `no measurement reports one at all`, and this claim can only look for a ring "
               "face concentric with a port. It has no business overruling the one field the look outright "
               "owns",
        "cost": "0 contradictions on all four draws: the claim is silent on 322 of 322",
    },
    "thin_parts_vs_clusters": {
        "licence": DISPUTES,
        "why": "`thin_clusters` is a clustering over a thickness field with a threshold in it, and the "
               "inventory's own record of building this claim is a warning: `thickness_p05` over "
               "`thickness_median` was tried as a second signal and dropped after 20 false contradictions, "
               "most of them fluid domains where the thickness field is the passage width. A part just under "
               "the threshold is a disagreement about where the line is, which is exactly what DISPUTED is for",
        "cost": "60 to 67 contradictions a draw, the largest column in the whole inventory, none of them "
                "suppressed",
    },
    "defects_vs_file_health": {
        "licence": RECORDS,
        "why": "trust.FIELDS['defects'] is RECORDED because the field `has never once been right`: 3 to 5 "
               "false alarms on clean files and 0 catches on the two with a real defect. The measurement is "
               "the better source here and the ledger already keeps the field away from every model and every "
               "customer, so there is nothing for a suppression to protect. Recording the disagreement is the "
               "whole of the available action",
        "cost": "2 to 3 contradictions a draw",
    },
    "symmetry_vs_axes": {
        "licence": DISPUTES,
        "why": "the one row where I distrust both sides and say so rather than picking. The inventory reported "
               "93 to 98 contradictions a draw, split 42-50 rotational against 43-50 mirror, wrote that "
               "`symmetry_scores` is a thresholded score and the look's prose is loose, that the families "
               "involved are the nearly-symmetric ones, and that IT DID NOT HAND-CHECK IT. Suppressing 95 "
               "statements a draw on an unchecked comparison is exactly the move this project has made seven "
               "times and had to undo",
        "cost": "93 to 98 contradictions a draw, none suppressed",
    },
    "mark_material_vs_kind": {
        "licence": DISPUTES,
        "why": "the mark kind comes off the same cut image the letter was drawn on, which should make it "
               "strong, and its column is not stable: the inventory measured 5, 10, 8 and 24 contradictions "
               "across four byte-identical-configuration draws and recorded that it did not chase the fourth. "
               "A column whose last draw is four times its first three is not a column to suppress on until "
               "somebody has found out why",
        "cost": "5 to 24 contradictions a draw, none suppressed",
    },
    "stop_panel_vs_detector": {
        "licence": OVERRULES,
        "why": "`find_stops` is this project's one real win: the closed-header row went 0,0,0,0 to 12,12,13,12 "
               "of 13, ruler-neutral. The detector decides which faces are stops and the renderer draws a "
               "sealed-end panel at each, so the look is being asked about a panel the measurement built",
        "cost": "0 to 3 contradictions a draw. It fires on neither half of the ablation",
        "untested": True,
    },
}

#: Claims that can only ever be SILENT. Listed so that a reader can see the size of the silence rather than
#: inferring it from an absence, which is the habit this whole module is about.
ALWAYS_SILENT = ("looks_like_the_name_itself", "confidence_is_about_the_model", "opening_why_is_prose",
                 "notes_is_prose", "abstention_makes_no_claim")

#: The default for a claim this table has never heard of, which is what a claim added tomorrow gets. It is
#: DISPUTES and not OVERRULES on purpose: a new channel has no measured standing, and the cost of a wrong
#: DISPUTED is a question nobody needed, while the cost of a wrong SUPPRESSED is a true statement destroyed.
UNKNOWN_CLAIM_LICENCE = DISPUTES

#: Which disagreement is worth the customer's one question, most valuable first. This is a WHITELIST: a field
#: that is not in it is recorded and never asked about, however plausible the disagreement.
#:
#: Ordered from the research agent's driver list (`gd_research/docs/joint_research.md`). What is in the passage
#: is driver 6 and is the only driver the measurement document scores ZERO on without the look, so a dispute
#: there is the dispute worth a customer's attention. Thin regions and the mouths come next because both change
#: what has to be resolved.
#:
#: WHAT IS DELIBERATELY NOT HERE, and it is the commonest disagreement of all. `symmetry` disputes 93 to 98
#: times a draw and `orientation` 18 to 20, and asking about either was the first thing this function did.
#: Both are RECORDED in `vision.trust` because the measurement has them exactly, so a customer's answer would
#: change nothing that is allowed to act on it: it is a question whose answer has nowhere to go. The same goes
#: for `defects` and for the per-opening class. Measured on four draws, the whitelist takes the parts asked
#: anything from 147, 140, 145 and 145 down to a number in which every question is about something that
#: changes the mesh. A form with a question on it that changes nothing is how a form stops being filled in.
QUESTION_ORDER = ("internal_features", "marks_seen[]", "marks_seen", "stops_seen[]", "stops_seen",
                  "thin_parts", "openings_seen[].mouth", "attachments", "sharp_edges")


@dataclass
class Verdict:
    """One claim, after reconciliation: what was decided, why, and what it costs the block."""
    claim: str
    look_field: str
    action: str
    licence: str
    #: the inventory's own verdict before this module re-read it
    raw: str = CONFIRM
    subject: str = ""
    said: str = ""
    measured: str = ""
    why: str = ""
    #: a claim whose null side took it out of the suppression path says so here rather than silently passing
    downgraded_from: str = ""
    #: the tier this claim's field ends at, after any promotion
    tier: str = trust.CANDIDATE
    #: what the measurement supplies in place of, or in addition to, what was removed
    supplies: str = ""


@dataclass
class Reconciliation:
    """Everything step 4 decided about one part."""
    case: str
    verdicts: list[Verdict] = field(default_factory=list)
    #: `stance.stance()['denied']`, carried through so `block.py` can remove the sentence that denies rather
    #: than the field it happened to be written in. Never re-derived here: see `reconcile`.
    denied: list[tuple[str, str]] = field(default_factory=list)
    #: what the measurement had all along and the document never said
    supplied: list[dict[str, Any]] = field(default_factory=list)
    readable: dict[str, Any] = field(default_factory=dict)

    def of(self, action: str) -> list[Verdict]:
        return [v for v in self.verdicts if v.action == action]

    @property
    def counts(self) -> dict[str, int]:
        return {a: len(self.of(a)) for a in ACTIONS}

    @property
    def contradictions(self) -> int:
        """Every disagreement, suppressed or not. THE QUALITY SIGNAL: this number needs no answer key, so it
        is the only one in this project that survives a customer's file."""
        return len(self.of(SUPPRESSED)) + len(self.of(DISPUTED))


# ---------------------------------------------------------------------------------------------------------------
# readability: can this channel see this part at all
# ---------------------------------------------------------------------------------------------------------------

def readability(m: Measured) -> dict[str, Any]:
    """The measurement's own report on whether it could see this part, per channel.

    This is the second half of standing and it is the half that varies by file. Every value here is already
    computed by the measurement for its own purposes; none of it is a new detector.
    """
    return {
        "representation": m.representation,
        "has_passage": m.has_passage,
        "profile_usable": bool(m.profile.usable),
        "profile_why_not": m.profile.why_not,
        "axis_trusted": bool(m.profile.axis_trusted),
        "axis_note": m.profile.axis_note,
        # None, NOT 0, when nobody recorded what the renderer drew. A reader that sees 0 concludes the renderer
        # drew nothing, which is a different fact: that conflation cost about 1,550 false suppressions a draw on
        # `openings_labelled` before `Measured` could tell the two apart. All three records travel together and
        # go missing together, so all three report the same way.
        "marks_drawn": len(m.mark_places) if m.knows_marks else None,
        "stops_drawn": len(m.stopped) if m.knows_stops else None,
        "openings_labelled": len(m.labelled) if m.knows_labels else None,
        "renderer_record": {"marks": m.knows_marks, "stops": m.knows_stops, "labels": m.knows_labels},
    }


#: Which readability key each channel needs true before its contradiction counts for anything. A claim whose
#: channel cannot see the part is SILENT here even when the inventory returned a verdict, because a verdict
#: from a blind channel is the seventh instance of this project's recurring failure.
CHANNEL_NEEDS: dict[str, tuple[str, ...]] = {
    "passage_plain_vs_profile": ("profile_usable", "axis_trusted"),
    "taper_named_vs_profile": ("profile_usable", "axis_trusted"),
    "passage_plain_vs_body_marks": ("has_passage",),
    "mark_material_vs_kind": ("has_passage",),
}


def channel_can_see(claim_id: str, read: dict[str, Any]) -> tuple[bool, str]:
    """Whether the channel behind this claim reports that it could read this part."""
    for key in CHANNEL_NEEDS.get(claim_id, ()):
        if not read.get(key):
            note = read.get("profile_why_not") or read.get("axis_note") or ""
            return False, f"{key} is false" + (f": {note}" if note else "")
    return True, ""


# ---------------------------------------------------------------------------------------------------------------
# the null side
# ---------------------------------------------------------------------------------------------------------------

def is_null_side(f: Finding, m: Measured) -> tuple[bool, str]:
    """Whether the measurement's half of this contradiction is an absence rather than a finding.

    The shapes are read off `Finding.said`, `Finding.subject` and `Finding.measured`, which are the inventory's
    own fields, and off nothing else at all. Each branch quotes the `cannot` line that makes it an absence.
    """
    entry = NULL_SIDE.get(f.claim)
    if entry is None:
        return False, ""
    side = entry["side"]
    reason = entry["why"]
    if f.claim == "passage_plain_vs_profile":
        # the look named something and the profile found no valley. "clear" here is the channel reporting that
        # it saw no dip in ONE cut plane, which is not the same as there being nothing in the passage.
        if side == "names_over_clear" and str(f.said).startswith("names"):
            return True, reason
        return False, ""
    if f.claim == "passage_plain_vs_body_marks":
        if "names" in str(f.said) and "no mark" in str(f.measured):
            return True, reason
        return False, ""
    if f.claim == "taper_named_vs_profile":
        if "names a change of section" in str(f.said) and "within the taper ratio" in str(f.measured):
            return True, reason
        return False, ""
    if f.claim in ("sharp_edges_vs_counts", "thin_parts_vs_clusters"):
        if f.subject == side:
            return True, reason
        return False, ""
    if f.claim == "attachment_flange_vs_ring":
        if "no ring face" in str(f.note):
            return True, reason
        return False, ""
    return False, ""


# ---------------------------------------------------------------------------------------------------------------
# the decision
# ---------------------------------------------------------------------------------------------------------------

#: The `Finding.said` shapes that mean the look asserted nothing at all. A contradiction against a silence is
#: the measurement finding something the look missed, which is a gap and not a false statement, and the two
#: want opposite actions.
_SAID_NOTHING = ("no change of section named", "none named", "no knife edge named", "0 named")


def _look_asserted(f: Finding) -> bool:
    return str(f.said).strip() not in _SAID_NOTHING


def licence_of(claim_id: str) -> tuple[str, str]:
    entry = STANDING.get(claim_id)
    if entry is None:
        return UNKNOWN_CLAIM_LICENCE, ("this claim is not in STANDING, so it has no measured entitlement and "
                                       "gets the cautious default")
    return str(entry["licence"]), str(entry.get("why") or "")


#: WHICH CONFIRMATIONS MAY MOVE A FIELD'S TIER, and the list is two long on purpose.
#:
#: A CONFIRMATION PROMOTES ONLY WHAT IT CHECKED. `looks_like_kind_of_file` agreeing tells you the look named
#: a thing of the right kind, a part with a passage rather than a body in a stream. It does not tell you the
#: NAME is right, and its own `cannot` says so: "the part's actual name. The measurement holds no vocabulary
#: of parts and never will." Promoting `looks_like` to relied_on off that check would say a consumer may act
#: on a part name that `vision.trust` measures as flipping on 7 to 11 of 40 identical repeats, and would
#: undercut `IDENTITY_CONFIDENCE_MAX` from a module that has no business touching it. The same goes for
#: `sharp_edges_vs_counts` and `thin_parts_vs_clusters`, which check whether any such feature exists and
#: never which one, while the field is a list of which ones.
#:
#: What is left is the pair that answers its field's actual question. `internal_features` asks whether
#: anything is across the passage, and both passage claims answer exactly that, from the profile and from the
#: cut image. Even they answer the yes and no and not the what, which is why the promotion is to relied_on
#: for the field and never a statement that the named feature is the right one.
PROMOTES_ITS_FIELD = ("passage_plain_vs_profile", "passage_plain_vs_body_marks")


def _tier_after(f: Finding, action: str, impression: dict) -> str:
    """The tier a field ends at. Confirmation is the only thing that moves one, and it only ever moves it up.

    A candidate the measurement has confirmed is not a candidate: `vision.trust` defines the tier as `a place
    to measure, never an answer: the measurement confirms it or it does not count`, so confirming it is the
    condition the tier itself names. A RECORDED field is not promoted by confirmation, because it is recorded
    for reasons a single agreement does not answer (`defects` agreeing once does not make it right: it has
    never once been right).
    """
    base = trust.tier_of(f.look_field, impression)
    if action == CONFIRMED and base == trust.CANDIDATE and f.claim in PROMOTES_ITS_FIELD:
        return trust.RELIED_ON
    return base


def decide(f: Finding, m: Measured, impression: dict) -> Verdict:
    """One finding, one decision. The whole of step 4's logic for a single claim."""
    licence, why = licence_of(f.claim)
    read = readability(m)
    v = Verdict(claim=f.claim, look_field=f.look_field, raw=f.verdict, licence=licence,
                subject=f.subject, said=f.said, measured=f.measured, action=PASSED, why=why)

    if f.verdict == SILENT:
        v.action = PASSED
        v.why = f.note or "the measurement has nothing to say about this claim"
        v.tier = _tier_after(f, PASSED, impression)
        return v

    can_see, blind = channel_can_see(f.claim, read)
    if not can_see:
        v.action = PASSED
        v.downgraded_from = f.verdict
        v.why = f"the channel reports it could not read this part ({blind}), so its verdict is not evidence"
        v.tier = _tier_after(f, PASSED, impression)
        return v

    if f.verdict == CONFIRM:
        v.action = CONFIRMED
        v.tier = _tier_after(f, CONFIRMED, impression)
        v.why = f"the measurement agrees: {f.measured}" if f.measured else "the measurement agrees"
        return v

    null, reason = is_null_side(f, m)
    if null:
        v.action = PASSED
        v.downgraded_from = CONTRADICT
        v.licence = RECORDS
        v.why = ("the measurement's side of this disagreement is an absence, not a finding: " + reason)
        v.tier = _tier_after(f, PASSED, impression)
        return v

    if licence == OVERRULES and STANDING.get(f.claim, {}).get("supplies") and not _look_asserted(f):
        # the measurement found something and the look said NOTHING. There is no statement to suppress, and
        # counting this as a suppression would be this module reporting an action it did not take. The whole
        # of the available action is to supply what the measurement measured, which `supplies()` does.
        v.action = PASSED
        v.downgraded_from = CONTRADICT
        v.why = ("the look asserted nothing here, so there is nothing to suppress: the measurement supplies "
                 "the finding instead of removing one")
        v.supplies = str(STANDING[f.claim].get("scope") or "")
        v.tier = _tier_after(f, PASSED, impression)
        return v

    if licence == OVERRULES:
        v.action = SUPPRESSED
        v.supplies = str(STANDING.get(f.claim, {}).get("scope") or "")
    elif licence == DISPUTES:
        v.action = DISPUTED
    else:
        v.action = DISPUTED if trust.tier_of(f.look_field, impression) != trust.RECORDED else PASSED
        v.why = why + " (recorded only: the ledger already keeps this field from deciding anything)"
    v.tier = _tier_after(f, v.action, impression)
    return v


def reconcile(findings: Sequence[Finding], m: Measured, impression: dict,
              denied: Sequence[tuple[str, str]] = ()) -> Reconciliation:
    """Step 4 over one part.

    `denied` is `stance.stance()['denied']`, the (kind, clause) pairs of every sentence in this reply that
    asserts the passage is empty. It is INJECTED for the reason the inventory injects the stance: that question
    has a format-neutral, hand-checked answer scored against 151 replies read by hand, and writing a second one
    here would be a new blind spot with no hand check behind it.
    """
    r = Reconciliation(case=m.case, readable=readability(m), denied=[(str(k), str(c)) for k, c in denied])
    r.verdicts = [decide(f, m, impression) for f in findings]
    r.supplied = supplies(findings, m)
    return r


# ---------------------------------------------------------------------------------------------------------------
# what the measurement had all along
# ---------------------------------------------------------------------------------------------------------------

def supplies(findings: Sequence[Finding], m: Measured) -> list[dict[str, Any]]:
    """The places the measurement measured and the document never said.

    This is the other half of a reconciler and it is the half nobody has built. `render.choose_stations` builds
    a 41-station cross-section area profile to decide where to cut and then keeps only the positions. A taper
    in that profile is a passage that opens out; a valley in it is a throat. Both are in the array to three
    decimals, both are gone by the time anything is written down, and the look has been asked to find them in a
    picture for four rounds.

    NOTHING HERE IS PREDICTED AND NOTHING HERE IS A BUILDER SETTING. Each entry is a PLACE along the flow axis
    with what the measurement found there, which is what the agent is for.

    THE NUMBER AND THE SENTENCE ARE KEPT APART, and the split is not cosmetic. `said` is the sentence and it
    carries NO DIGIT, because the look block's one hard invariant is that every digit was scrubbed before the
    model saw it and a reader of that block must be able to keep relying on it. The magnitudes live in `sizes`,
    typed, where a consumer that wants them reads them as numbers rather than parsing them out of prose. The
    right home for these is the MEASURED half of the report and not the look block at all
    (`gd_research/docs/joint_research.md` puts a measured taper at `_DROP_RANK` 2 or 5, not at the impression's
    rank 6); the look block is where `eval/vision/document.py` gives a hook, so that is where the scoring arm
    injects them, and the write-up says so rather than leaving it to be discovered.
    """
    out: list[dict[str, Any]] = []
    if not m.profile.readable:
        return out
    tp = m.profile.taper()
    if tp:
        # THE RATIO IS A MEASUREMENT AND THE WAY ROUND IS AN ANSWER. Both ends differ by the same amount
        # whichever end you start at, so `end_to_end_area_ratio` always stands; `opens_towards_end` is a
        # direction, the profile has one only when a person gave it (`FlowProfile.direction`), and a row that
        # named a way round off the fitted line's sign was naming the order the mouths were measured in.
        oriented = tp["opens_towards_end"] is not None
        way = ("opening out" if tp["opens_towards_end"] else "closing down") if oriented else ""
        said = (f"the passage tapers along its length, {way} towards the far end" if oriented else
                "the two ends of the passage are different sizes; which way round is not the measurement's to "
                "say, because nobody has said which way the flow runs")
        sizes: dict[str, Any] = {"end_to_end_area_ratio": round(float(tp["ratio"]), 3), "oriented": oriented}
        if oriented:
            sizes["opens_towards_end"] = bool(tp["opens_towards_end"])
            sizes["flow_direction"] = str(tp["direction"])
        out.append({"what": "change_of_section", "where": "along the whole length of the passage",
                    "said": said, "sizes": sizes,
                    "from": "the 41-station cross-section profile render.choose_stations already computes"})
    hit = m.profile.dip()
    if hit:
        # `at_fraction_of_axis` is a distance along the fitted line and is reported either way, because the
        # throat is that far along the part whichever end you count from. `oriented` says whether counting
        # from the low end means counting from the inlet: while it is false, 0.2 and 0.8 are the same place.
        out.append({"what": "narrowing", "where": "partway along the passage",
                    "said": "there is a throat partway along the passage, where the section narrows and then "
                            "opens out again",
                    "sizes": {"at_fraction_of_axis": round(float(hit["at"]), 3),
                              "open_fraction_of_widest": round(float(hit["open_fraction"]), 3),
                              "prominence": round(float(hit["depth"]), 3),
                              "oriented": bool(hit["oriented"])},
                    "from": "the same profile: the valley's prominence, not its depth"})
    return out


# ---------------------------------------------------------------------------------------------------------------
# the same verdicts, per place
# ---------------------------------------------------------------------------------------------------------------

#: What the pair did at one place. `NOTHING_COMPARABLE` is the one that is easy to spend wrongly: it means no
#: claim about this place survived to be checked either way, and reading it as agreement is the same fault
#: `Joint.readers` exists to stop - a channel with no reader finds no disagreement and its nought is
#: indistinguishable from the two sources agreeing.
AGREED, DISAGREED, NOTHING_COMPARABLE = "agreed", "disagreed", "nothing_comparable"
PLACE_VERDICTS = (AGREED, DISAGREED, NOTHING_COMPARABLE)


@dataclass
class Place:
    """One place, with the claims the two sources agreed and disagreed about there.

    A REGROUPING AND NEVER A SECOND OPINION. Every entry here is a `Verdict` this reconciliation already
    decided; nothing is re-derived, no threshold is read again and no claim is judged here. That matters
    because two readings of the same pair that can reach different answers is this codebase's signature
    defect, and `question` below ranks the same `DISPUTED` list this calls `disagreed`.
    """
    subject: str
    agreed: list[Verdict] = field(default_factory=list)
    disagreed: list[Verdict] = field(default_factory=list)
    silent: list[Verdict] = field(default_factory=list)

    @property
    def verdict(self) -> str:
        """`agreed`, `disagreed` or `nothing_comparable`. DISAGREEMENT WINS: one contradiction at a place is
        the thing worth a person's attention, and averaging it against three agreements would bury it."""
        if self.disagreed:
            return DISAGREED
        return AGREED if self.agreed else NOTHING_COMPARABLE

    @property
    def fields(self) -> list[str]:
        """The look fields that were comparable here at all, agreed or not, in the order they were claimed."""
        seen: list[str] = []
        for v in (*self.agreed, *self.disagreed):
            if v.look_field not in seen:
                seen.append(v.look_field)
        return seen

    @property
    def measured(self) -> str:
        """The MEASUREMENT's own side of the first disagreement here, or `""`.

        The measurement's side and not the look's, and that is not a style choice. Every field a per-opening
        claim reads on the look side (`openings_seen[].looks_like`, `.mouth`, `.likely_role`) is RECORDED in
        `vision.trust`, which means it may not reach anything a model is shown; the measured half is arithmetic
        on the customer's own bytes. So a consumer that wants to name a disagreement in a sentence can say
        WHERE it is and what the MEASUREMENT has there, and cannot accidentally publish the look's word.
        """
        return next((v.measured for v in self.disagreed if v.measured), "")


def by_place(r: Reconciliation) -> dict[str, Place]:
    """This reconciliation's verdicts grouped by the place they are about. THE ONE PER-PLACE READING.

    A verdict with no `subject` is about the whole part and is not here: `internal_features`, `confidence` and
    `notes` have no place to be at. Everything that does have one is, whatever kind of place it is - an opening
    id, a mark letter, `knife`, `mirror`, an axis letter - because the set of subjects is the claims' own and
    inventing a whitelist here would need updating the day a claim is added. A caller that only has one kind of
    place in front of a person (the platform's panel shows measured mouths) filters to the ids it can name.

    WHY THIS IS HERE AND NOT WRITTEN AGAIN BY EACH READER. Three readers want it: the question finder, so it
    asks about a mouth the two sources read differently rather than about every mouth alike; the platform's
    Surveyor panel, so an agreement is STATED to the customer instead of being silently spent; and the
    per-place record the ledger keys an answer on. Three spellings of "do these two agree here" that can
    disagree with each other is exactly the defect this package keeps finding in itself, so there is one.

    WHAT IT IS AND IS NOT EVIDENCE OF. `agreed` is a reading of pictures that a measurement of the same bytes
    did not contradict. It is not proof of anything: `STANDING` says in as many words that on the commoner
    direction of contradiction THE MEASUREMENT was at fault 30 times in 33, so a claim that survived is a claim
    nothing was entitled to remove rather than a claim shown true. And `NOTHING_COMPARABLE` is not agreement.
    """
    out: dict[str, Place] = {}
    for v in r.verdicts:
        if not v.subject:
            continue
        place = out.setdefault(str(v.subject), Place(subject=str(v.subject)))
        if v.action == CONFIRMED:
            place.agreed.append(v)
        elif v.action in (DISPUTED, SUPPRESSED):
            place.disagreed.append(v)
        else:
            place.silent.append(v)
    return out


# ---------------------------------------------------------------------------------------------------------------
# the question with a default
# ---------------------------------------------------------------------------------------------------------------

def question(r: Reconciliation) -> dict[str, Any] | None:
    """THE ONE QUESTION. A recorded disagreement is worth as much as a suppression, and this is why.

    A DISPUTED claim is two plausible readings of the same part from two sources of comparable standing, which
    is precisely the shape of a thing worth asking a customer about: it cannot be settled by measuring harder,
    it changes what gets meshed, and it has an obvious default. One question, because a form with eleven
    questions on it is a form nobody fills in.

    THE DEFAULT IS ALWAYS THE MORE CAUTIOUS READING, which on every field in `QUESTION_ORDER` is the side that
    says there is something there. A mesher who resolves a feature that turns out not to exist has spent
    cells; one who does not resolve a feature that does exist has a wrong answer.
    """
    rank = {name: i for i, name in enumerate(QUESTION_ORDER)}
    disputes = [v for v in r.of(DISPUTED) if v.look_field in rank]
    if not disputes:
        return None
    top = min(disputes, key=lambda v: (rank[v.look_field], v.claim))
    return {
        "about": top.look_field,
        "ask": f"the picture and the measurement disagree about {_plain(top.look_field)}. "
               f"The look says {top.said or 'one thing'}; the measurement says {top.measured or 'another'}. "
               f"Which should the mesh be built for?",
        "default": "treat it as present and resolve it",
        "because": "neither source outranks the other here, and under-resolving a feature that is there costs "
                   "a wrong answer while over-resolving one that is not costs cells",
        # the short reason, not `Verdict.why`. That field carries the developer's paragraph out of `STANDING`,
        # complete with draw counts and file names, and a question put to a customer is not the place for it.
        "why_not_settled": LICENCE_MEANING[top.licence],
        "claim": top.claim,
        "others_on_the_record": len(disputes) - 1,
    }


#: Every field in `QUESTION_ORDER` has an entry, said the way a customer would say it and not the way the
#: schema does. A question printed with a field name in it is a question written for the wrong reader.
_PLAIN = {
    "internal_features": "what is inside the passage",
    "marks_seen[]": "what is at a lettered place in the passage",
    "marks_seen": "what is at a lettered place in the passage",
    "stops_seen[]": "where the passage ends",
    "stops_seen": "where the passage ends",
    "thin_parts": "the thin regions",
    "openings_seen[].mouth": "how a mouth sits in the wall",
    "attachments": "what is attached to the outside",
    "sharp_edges": "the sharp edges",
    #: NOT IN `QUESTION_ORDER`, and here anyway, because `by_place` needs a word for every per-opening claim it
    #: can call a disagreement, not only for the ones worth their own question. A place a sentence names is a
    #: place the sentence has to be able to say something about.
    "openings_seen[].looks_like": "what kind of opening a mouth is",
    "openings_seen[].likely_role": "whether a mouth is a port at all",
    "openings_seen[].id": "whether a mouth is there at all",
}


def _plain(look_field: str) -> str:
    return _PLAIN.get(look_field, look_field)


def plain(look_field: str) -> str:
    """One look field said the way a customer would say it. THE ONE TABLE, so a question and a panel that name
    the same disagreement cannot call it two different things."""
    return _plain(look_field)


__all__ = ["ACTIONS", "ACTION_MEANING", "AGREED", "ALWAYS_SILENT", "CHANNEL_NEEDS", "CONFIRMED", "DISAGREED",
           "DISPUTED", "DISPUTES",
           "LICENCES", "LICENCE_MEANING", "NOTHING_COMPARABLE", "NULL_SIDE", "OVERRULES", "PASSED",
           "PLACE_VERDICTS", "QUESTION_ORDER",
           "RECONCILE_SCHEMA", "RECORDS", "STANDING", "SUPPRESSED", "UNKNOWN_CLAIM_LICENCE", "Place",
           "Reconciliation",
           "Verdict", "by_place", "channel_can_see", "decide", "is_null_side", "licence_of", "plain",
           "question", "readability", "reconcile", "supplies"]
