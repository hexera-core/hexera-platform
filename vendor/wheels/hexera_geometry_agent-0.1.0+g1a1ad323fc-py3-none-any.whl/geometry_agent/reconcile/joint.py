"""THE JOINT PIPELINE: step 1 to step 5 in one call, with the four channels' worth of work in one object.

Six branches built six halves of this and none of them joined up. `inventory` says what the measurement is
entitled to say about each look field; `verdict` decides confirmed / suppressed / disputed / passed and recovers
the profile the renderer discards; `block` performs the surgery and writes the typed block; `entry` and `say`
measure the passage shape from each mouth and put it into words; `monitor` reads the reply for the signals that
need no answer key. This file runs them in the order the pipeline runs them and hands back ONE result.

WHAT THIS FILE PUTS DOWN THE TYPED CHANNEL, and it is still only measurements. `hexera.planner_block` is the
typed dict the platform reads out of `metrics["geometry_agent"]`. When this file was written it was
BYTE-IDENTICAL with the look and without it on 322 of 322 parts, and the round that followed closed that:
`planner_block` now composes its own `look` key from `vision.trust.for_model`, with the findings
`vision.place` could join to a measured place. That is the look's channel and it is owned there.

What THIS file adds to the same block is unchanged and is still measurement only: `measured_places` below, the
throat and the taper the profile sized, which contain no word the model wrote. A look statement carries no
coordinate of its own, because every digit is scrubbed before the model sees the picture, so anything located
here is located by the measurement.

THE ORDER IS REHAAN'S AND IS NOT NEGOTIATED HERE. measure, decide what to draw, look, reconcile, deliver. The
one thing this file adds is that the fourth step now has an output and the fifth step has somewhere to put it.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from geometry_agent.reconcile import block as rblock
from geometry_agent.reconcile import inventory as inv
from geometry_agent.reconcile import monitor as rmon
from geometry_agent.reconcile import phrasing
from geometry_agent.reconcile import say as rsay
from geometry_agent.reconcile import verdict as rv

JOINT_SCHEMA = "geometry_agent.joint.v1"

#: `supplies` reports where a throat or a taper is as a fraction of the flow axis, because that is the unit the
#: 41-station profile is computed in and converting it to metres here would invent a precision the station
#: spacing does not have. A consumer that wants metres multiplies by the bbox extent along the flow axis, which
#: is in the same document. The key says so in its name.
PLACE_KIND = {"change_of_section": "measured_taper", "narrowing": "measured_throat"}


@dataclass
class Joint:
    """One part, both sources, everything either of them is entitled to say."""
    case: str
    representation: str
    reconciliation: rv.Reconciliation
    #: the reply as it arrived, never modified
    raw: dict[str, Any] = field(default_factory=dict)
    #: the reply after the surgery `block.reconciled` performs
    reconciled: dict[str, Any] = field(default_factory=dict)
    #: `say.block(...)`: the measured passage shape, or None when the measurement found nothing to say
    shape: dict[str, Any] | None = None
    #: `monitor.run_signals(...)`: the quality signals that need no answer key
    report: Any = None
    #: `profile.FlowProfile`, THE ONE THE CLAIMS AND SIGNALS ACTUALLY READ, or None when this Joint was built by
    #: `run` from a `Measured` a caller assembled itself.
    #:
    #: IT IS HERE SO THE REFUSAL CAN BE FOLLOWED RATHER THAN RECOMPUTED. Four claims and three signals abstain
    #: when the profile is refused, and `contradictions` counts disagreements FOUND, so a reader who cannot see
    #: the refusal cannot tell an abstention from an agreement. It is also the only way a test of the LIVE path
    #: can check which gate refused: recomputing the profile beside the run would be a second call proving
    #: nothing about the first.
    profile: Any = None
    #: WHICH LOOK-SIDE READERS WERE ACTUALLY AVAILABLE ON THIS RUN, by name, and this is not decoration.
    #:
    #: `contradictions` is a count of disagreements FOUND. A channel with no reader finds none, and the number
    #: it produces is indistinguishable from agreement. On the shipping path the stance reader is missing (see
    #: `for_job`), so 14 interior disputes a draw are not found, and a reader of `contradictions: 0` who does
    #: not know that has been told the two sources agreed about the inside when in fact nobody asked. A fact
    #: that lies is worse than a missing one, so the block carries the list and `record_block` ships it.
    readers: dict[str, bool] = field(default_factory=dict)

    @property
    def alerts(self) -> list[Any]:
        return list(getattr(self.report, "alerts", []) or [])

    @property
    def contradictions(self) -> int:
        return self.reconciliation.contradictions

    @property
    def agreement(self) -> dict[str, Any]:
        """`{place: verdict.Place}`: what the pair did at each place, from `verdict.by_place` and nowhere else.

        It is a property and not a stored field because it is a regrouping of `reconciliation.verdicts` with
        nothing added: storing it would be a second copy of one fact, which is the thing this package's
        docstrings keep catching. `contradictions` counts the same disagreements this groups, so a reader can
        check the two against each other and they can fail differently - that is what
        `tests/test_reconcile_places.py` does.
        """
        return rv.by_place(self.reconciliation)

    def typed_block(self, *, rationale: bool = False) -> dict[str, Any]:
        """The typed block step 5 carries, with the measured shape beside the reconciled look and not inside.

        `rationale=False` by default here and True in `block.block`, and the difference is deliberate: that
        function's caller is a developer reading a record, this one's is the document that leaves the agent.
        `block.disagreements` says what travelled into a customer document the one time it was not left out.
        """
        out = rblock.block(self.raw, self.reconciliation, rationale=rationale)
        out["schema"] = JOINT_SCHEMA
        out["measured_passage_shape"] = self.shape
        out["alerts"] = [{"signal": a.signal, "kind": a.kind, "subject": a.subject,
                          "says": a.says, "measured": a.measured} for a in self.alerts]
        if self.readers:
            out["channels_not_read"] = sorted(k for k, ok in self.readers.items() if not ok)
        return out

    def measured_places(self) -> list[dict[str, Any]]:
        """The recovered profile as PLACES, in the shape `hexera.planner_block` states a place in.

        Every one of these is a measurement. None of them is a builder setting, none predicts anything about
        the mesh, and none carries a word the model wrote: `said` is written by `verdict.supplies` from the
        array, and the array is `render.choose_stations`'s own.
        """
        out: list[dict[str, Any]] = []
        for s in self.reconciliation.supplied:
            kind = PLACE_KIND.get(str(s.get("what") or ""))
            if kind is None:
                continue
            sizes = dict(s.get("sizes") or {})
            out.append({
                "id": kind, "kind": kind, "what": str(s.get("said") or ""),
                "where_fraction_of_flow_axis": sizes.get("at_fraction_of_axis"),
                "measurement": sizes,
                "from": str(s.get("from") or ""),
            })
        return out


def run(m: inv.Measured, impression: dict[str, Any], *, stance: dict[str, Any] | None = None,
        says_solid: bool = False, segments: Any = phrasing.segments, runs: Any = None,
        taper: dict[str, Any] | None = None, phrasing: str = "plain",
        only: set[str] | None = None, costs: tuple[str, ...] = ("free", "measured", "profile"),
        not_asked: tuple[str, ...] = ()) -> Joint:
    """Steps 3 to 5 over one part: reconcile the reply against the measurement and deliver what survives.

    `m` is the measurement (`inventory.Measured`), `impression` the reply as it arrived. `stance` is
    `vision.stance.stance(impression)` and is INJECTED for the reason `verdict.reconcile` states: that question
    has a hand-checked answer against 151 replies read by eye and a second copy of it here would be a second
    blind spot with no hand check behind it. `runs` is `entry.mouth_runs(...)`, the per-mouth march, and is
    optional because it needs the mesh and the reconciliation does not.
    """
    st = stance or {"verdict": "silent", "named": [], "denied": []}
    look = inv.Look(case=m.case, impression=impression, stance=st, says_solid=says_solid, segments=segments,
                    not_asked=tuple(not_asked or ()))
    findings = [f for f in inv.run_claims(m, look) if only is None or f.claim in only]
    r = rv.reconcile(findings, m, impression, denied=st.get("denied") or [])
    shape = rsay.block(runs or [], verdict=_verdict_of(m), taper=taper if taper is not None else _taper_of(m),
                       phrasing=phrasing, representation=m.representation)
    report = rmon.run_signals(m, look, costs=costs)
    return Joint(case=m.case, representation=m.representation, reconciliation=r, raw=impression,
                 reconciled=rblock.reconciled(impression, r), shape=shape, report=report)


# ---------------------------------------------------------------------------------------------------------------
# THE LIVE PATH: building step 4's inputs out of what a job actually has in its hands
# ---------------------------------------------------------------------------------------------------------------
#
# WHY THIS SECTION IS THE WHOLE REASON STEP 4 NEVER RAN. `run` above has been complete since it was written. What
# did not exist anywhere under `src/` was a way to build its first argument. `inventory.Measured` was only ever
# constructed by `eval/vision/inventory.measured_of`, out of a cached bench row that already held the recovered
# profile, the renderer's mark places, its stop panels and its label list as JSON. A customer job has none of
# those as JSON: it has a file, a `GeometryFacts`, a representation and a look block. Everything below turns the
# second set into the first, and nothing below reads a brief, a family, a case row or a corpus file.

#: Reading `drawn` off a look block. `hexera.look_block` writes `{"marks": [...], "stops": [...]}` and does NOT
#: write `labelled`, so `_labelled_from` returns None on today's blocks and every reader abstains rather than
#: contradicting. The key is read here so that the day `vision/look.py` adds it (NEEDS FROM OTHERS) this file
#: needs no change.
def _drawn_of(look_block: dict[str, Any] | None) -> dict[str, Any]:
    d = (look_block or {}).get("drawn")
    return dict(d) if isinstance(d, dict) else {}


def _labelled_from(drawn: dict[str, Any]) -> list[str] | None:
    """The renderer's own list of the openings it labelled, or None when the block does not carry one.

    None is NOT recomputed from the facts. The list that matters is the one belonging to the SAME render the
    model was shown, and deriving a second one here from `facts.openings` would be a claim about a picture this
    file never saw: exactly the shape of failure the rest of this package refuses. See `Measured.labelled`.
    """
    v = drawn.get("labelled")
    return [str(x) for x in v] if isinstance(v, (list, tuple)) else None


#: Empty arrays, so the no-passage branch of `measured_for_job` can ask `flow_profile` for its own refusal rather
#: than composing a second one here. The representation branch of that function returns before either is read.
_NO_VERTICES: Any = ()
_NO_FACES: Any = ()


def _records_of(drawn: dict[str, Any]) -> dict[str, Any]:
    """THE THREE RENDERER RECORDS, EACH ABSENT RATHER THAN EMPTY WHEN THE BLOCK DID NOT CARRY IT.

    A look block with no `drawn` table at all (a stored look taken before that table existed, or one from a
    `look_fn`) leaves all three unknown, and three claims holding OVERRULES would otherwise read the absence as
    a finding. See `inventory.Measured.labelled`.
    """
    marks, stops = drawn.get("marks"), drawn.get("stops")
    return {"mark_places": ([dict(p) for p in marks if isinstance(p, dict)]
                            if isinstance(marks, (list, tuple)) else None),
            "stopped": [str(x) for x in stops] if isinstance(stops, (list, tuple)) else None,
            "labelled": _labelled_from(drawn)}


def _mouth_arrays(facts: Any) -> tuple[Any, Any, int | None]:
    """The mouth centroids, the mouth normals and the worst ring bore count, for the profile's own gate.

    All three come off `facts.openings`, which is the measurement. `eval/vision/inventory.measured_of` takes the
    centroids off the case row instead, because that is what its cache holds; the facts' own centroids are the
    same measurement and are what a job has.
    """
    openings = list(getattr(facts, "openings", None) or [])
    if not openings:
        return None, None, None
    import numpy as np
    pts = np.asarray([[float(c) for c in o.centroid] for o in openings], dtype=float)
    nrm = np.asarray([[float(c) for c in o.normal] for o in openings], dtype=float)
    rings = [int(getattr(o, "bore_count", None) or 1) for o in openings if str(o.kind) == "ring"]
    return pts, nrm, (max(rings) if rings else None)


#: WHAT STEP 4 COSTS PER JOB IN SECONDS, measured on 12 real corpus parts, one per family, four repeats each,
#: after the no-passage short circuit below.
#:
#: Step 4's OWN work is 0.088 s median, 0.001 to 0.275 s: every claim, every signal and the 41-station cut, with
#: the triangles already in hand. Handed a path instead it is 0.21 s median, and 11 of the 12 parts stay under
#: 0.67 s. The exception is `static_mixer_001` at 17.9 s, and 17.6 s of that is `load_mesh` alone: a helical
#: mixer is expensive to tessellate and step 4 is tessellating it for the third time in one job.
#:
#: NOBODY ON THIS PATH HAS THE TRIANGLES TO HAND OVER, which is why `mesh` exists and is usually unused.
#: `agent.run.measured_facts` tessellates in a CHILD PROCESS, because a native tessellation cannot be
#: interrupted from inside this one, and only the `GeometryFacts` come back. `vision.render.render_views`
#: tessellates again, in process, and returns pictures. So a job that reaches step 4 has paid for the triangles
#: twice and holds neither. Closing that is a change to `agent/run.py` or `vision/look.py` and is listed as a
#: NEEDS FROM OTHERS; when it lands, the caller passes `mesh` and the first number below is what it pays.
STEP4_SECONDS_WITH_THE_MESH_IN_HAND = 0.088
STEP4_SECONDS_WITH_A_SECOND_LOAD = 0.21


def measured_for_job(facts: Any, representation: str, look_block: dict[str, Any] | None = None, *,
                     case: str = "", mesh: Any = None, path: Any = None,
                     stated_axis: Any = None) -> inv.Measured:
    """`inventory.Measured` for one live job. No cache, no case row, no brief.

    THE PROFILE REFUSES RATHER THAN GUESSING. It needs the triangles, which `GeometryFacts` does not carry, so
    with neither `mesh` nor `path`, and with a file this machine cannot load, this returns a `FlowProfile` whose
    `why_not` says exactly which of those it was, and every claim and signal behind the axial channel goes
    SILENT. That is the honest state: a profile invented from the facts alone would be a fact that lies, and the
    four claims and three signals that read it cannot tell the difference.
    """
    from geometry_agent.reconcile import profile as rprofile
    drawn = _drawn_of(look_block)
    why_no_mesh = "the triangles were not handed to step 4 and no file was named, so the 41-station profile " \
                  "could not be cut"
    if (representation or "unknown") in rprofile.NO_PASSAGE_REPRESENTATIONS:
        # DON'T PAY FOR A PROFILE THAT IS REFUSED BEFORE IT IS CUT. `flow_profile` returns a refusal on its first
        # line for these representations, and loading the triangles to get there is a whole tessellation spent on
        # an answer already known: 4.67 s on `blade_row_rotor_001`, 1.13 s on `freeform_nacelle_001` and 0.14 s
        # on `ahmed_variant_001`, all three now 0.001 s, against 0.001 to 0.005 s of actual work. Measured on 12
        # real corpus parts, four repeats each. The refusal and its wording are `flow_profile`'s own, asked for
        # with empty arrays, so the profile a caller gets here is the profile it would have got after the load.
        return inv.Measured(case=case or str(getattr(facts, "sha256", "") or ""),
                            representation=representation or "unknown", facts=facts,
                            profile=rprofile.flow_profile(_NO_VERTICES, _NO_FACES, representation or "unknown"),
                            **_records_of(drawn))
    if mesh is None and path is not None:
        from pathlib import Path

        from geometry_agent.facts.load import load_mesh
        try:
            mesh = load_mesh(Path(path))
        except Exception as exc:  # noqa: BLE001 - a file this machine cannot load is a profile that did not run
            why_no_mesh = f"the triangles could not be loaded for step 4: {type(exc).__name__}: {str(exc)[:120]}"
    if mesh is None:
        prof = rprofile.FlowProfile(representation or "unknown", refused_by="no_mesh", why_not=why_no_mesh)
    else:
        pts, nrm, bores = _mouth_arrays(facts)
        # THE CUSTOMER'S FLOW DIRECTION REACHES THE GATE HERE, and this is the only place it can. The gate
        # (`profile.trust`) judged an axis fitted through the mouths and nothing else, so on a part where the
        # customer had said which way the flow runs the refusal was decided about a direction they never saw.
        # It does not move the stations: see `profile.stated_trust`.
        prof = rprofile.flow_profile(mesh.vertices, mesh.faces, representation or "unknown", pts, nrm,
                                     ring_bores=bores, stated_axis=stated_axis)
    return inv.Measured(case=case or str(getattr(facts, "sha256", "") or ""),
                        representation=representation or "unknown", facts=facts, profile=prof,
                        **_records_of(drawn))


def impression_of(look_block: dict[str, Any] | None) -> dict[str, Any] | None:
    """The reply out of a look block, or None when there is no reply to reconcile.

    A `failed` look has an empty impression and is NOT the same thing as a look that saw a plain passage:
    `hexera.look_block` keeps them apart on `status` for that exact reason, and reading a failed look as a reply
    would have step 4 reconcile the measurement against silence and report the result as agreement.
    """
    block = look_block or {}
    if str(block.get("status") or "") != "ok":
        return None
    imp = block.get("impression")
    return dict(imp) if isinstance(imp, dict) and imp else None


def not_asked_of(look_block: dict[str, Any] | None) -> tuple[str, ...]:
    """The record fields the prompt behind this look never asked (`vision.prompt.not_asked`), off the block.

    Without it an unasked field's empty value reads as the look's answer, which is reading silence as a finding.
    `inventory.run_claims` makes no claim about any field named here.
    """
    prompt = (look_block or {}).get("prompt")
    if isinstance(prompt, dict) and isinstance(prompt.get("not_asked"), (list, tuple)):
        return tuple(str(f) for f in prompt["not_asked"])
    return ()


def for_job(facts: Any, representation: str, look_block: dict[str, Any] | None, *, case: str = "",
            path: Any = None, mesh: Any = None, stance: dict[str, Any] | None = None,
            says_solid: bool = False, runs: Any = None, phrasing: str = "plain",
            stated_axis: Any = None) -> Joint | None:
    """STEP 4 OVER ONE LIVE JOB, or None when there is no pair to reconcile.

    None when the look failed or produced no reply: there is then one source and nothing to reconcile, and the
    caller passes `reconciliation=None` onward exactly as it did before step 4 existed.

    `representation` IS THE ONE THE LOOK WAS TAKEN WITH, and that is the only self-consistent choice rather than
    a preference. It decides whether material area is flow area and whether a lettered `void` means solid
    (`profile.mark_is_solid`), and the model was prompted with it and shown a stops panel drawn under it.
    Reconciling those answers against a DIFFERENT representation would invert the mark readings relative to the
    picture the reply is about, which is the fault `monitor.the_letters_say_the_representation_is_wrong` exists
    to catch, manufactured on purpose. This function never computes a representation and never reads a brief to
    get one; it is handed the job's own.

    `stated_axis` IS THE CUSTOMER'S OWN FLOW DIRECTION, a signed axis letter or None, and it is the one thing
    on this path that is not a measurement. It reaches `profile.trust` and nothing else: it cannot move a station,
    it cannot become a claim, and None refuses nothing. `chain.job.run_job` reads it with `flow_axis_of`, which
    returns a direction only when a person gave one and never a default that stood.

    `stance` IS NOT AVAILABLE ON THIS PATH TODAY and the absence is recorded rather than papered over. The
    format-neutral, hand-checked reader for "does this reply assert the passage is plain" is
    `eval/vision/stance.py`, which `src/` cannot import and which this branch does not own (NEEDS FROM OTHERS).
    Three claims and five signals are gated on it, and all eight ABSTAIN rather than guessing without it, which
    is the half that matters: measured over the 322-part corpus and four cached draws, with today's prompt, the
    full pipeline finds 132, 130, 130 and 142 contradictions and this path finds 114, 115, 117 and 127, and every
    single finding on this path is one the full pipeline also makes, with the same count. Nothing is invented.
    What is lost is the interior channel: 14 of the 72 questions a draw, 4 of the 22 suppressions, and the alerts
    on 34 fewer parts. `Joint.readers` carries the absence into the block so nobody reads the remaining count as
    agreement about the inside.
    """
    imp = impression_of(look_block)
    if imp is None:
        return None
    m = measured_for_job(facts, representation, look_block, case=case, mesh=mesh, path=path,
                         stated_axis=stated_axis)
    jt = run(m, imp, stance=stance, says_solid=says_solid, runs=runs, phrasing=phrasing,
             not_asked=not_asked_of(look_block))
    # `mouth_march` IS THE SAME KIND OF ABSENCE AS `stance`, and it had to be recorded for the same reason.
    # `say.mouth_lines([])` is `[]` and `say.block` then omits `at_each_mouth`, so a `measured_passage_shape`
    # carrying only `along_the_flow` is byte for byte what the per-mouth march looks like when it RAN and found
    # nothing at any mouth. `entry.mouth_runs` is not called here: it cuts a plane per station per region and
    # its own docstring puts that at seconds to minutes on a large part, and nothing has measured it on four
    # draws, so wiring it on a guess is the thing this project keeps getting wrong. Until somebody measures it,
    # the document says the channel did not run rather than implying it found nothing.
    # `axial_profile` IS THE THIRD ABSENCE OF THE SAME KIND. Four claims and three signals read the 41-station
    # profile and every one of them abstains when it is refused, so a run whose profile refused finds fewer
    # disagreements for a reason that has nothing to do with the two sources agreeing. On the platform's own path
    # the profile is ALWAYS refused, for want of the triangles (`application/geometry_survey._reconciled`), so
    # without this row a platform block would say `channels_not_read: [mouth_march, stance]` while a third
    # channel was silent too.
    jt.readers = {"stance": stance is not None, "segmenter": True, "mouth_march": runs is not None,
                  "axial_profile": bool(getattr(m.profile, "readable", False))}
    jt.profile = m.profile
    return jt


def _verdict_of(m: inv.Measured) -> str:
    """The axial channel's own word for this part, or `unreadable` when it is not entitled to speak."""
    if not m.profile.readable:
        return "unreadable"
    return "restricted" if m.profile.dip() else "clear"


def _taper_of(m: inv.Measured) -> dict[str, Any] | None:
    if not m.profile.readable:
        return None
    return m.profile.taper()


#: HOW MUCH OF STEP 4's OWN WORKING TRAVELS WITH THE DOCUMENT.
#:
#:   `full`     every key of the typed block, including `disagreements`, which QUOTES the suppressed sentence
#:   `counts`   the numbers, the question, the confirmed fields, the tiers, and the monitor's firings as
#:              signal ids with no quoted words
#:   `none`     nothing: the surgery happened and the document does not say so
#:
#: WHY THIS IS A SWITCH. `block.disagreements` quotes a suppressed claim in full on purpose, so that a person
#: reading the record can see what was taken out. That is right for a record and wrong for a document, and the
#: difference is measurable: `reconciled` removes "the passage is plain" from the look block and `full` writes
#: it back two keys later, where `document.walk_strings` reads it as prose and `truth.judge` charges it exactly
#: as it charged the original. The reconciler's whole measured win is 14, 6, 0 and 6 false statements a draw and
#: `full` hands most of it back. `counts` keeps the part of the record that is a number about the pair and drops
#: the part that is a re-assertion of what was removed. The quotes are not lost: `block.disagreements(r)` still
#: returns them for the arm that scores the reconciler and for anyone auditing a suppression.
RECORD_MODES = ("full", "counts", "none")
RECORD_DEFAULT = "counts"

#: The keys of the typed block that are about the PAIR rather than about the part: numbers, a question with a
#: default, the fields a consumer may now act on, and the tiers it branches on. None of them restates a claim.
RECORD_COUNTS_KEYS = ("schema", "counts", "contradictions", "confirmed", "question", "tiers", "readable",
                      # travels in every mode, because it is what stops `contradictions` being read as
                      # agreement on a channel that had no reader. See `Joint.readers`.
                      "channels_not_read")
RECORD_FULL_KEYS = (*RECORD_COUNTS_KEYS, "disagreements", "alerts")

#: WHAT A MONITOR FIRING MAY SAY IN A DOCUMENT, and it is three typed fields and no prose.
#:
#: `monitor.Alert` carries `says` and `measured`, which are the two sides in the words each side used, and
#: those are the same re-assertion `disagreements` is: quoted into a document they are read as the document's
#: own claims. `signal`, `kind` and `subject` are an id, an enum and a PLACE (an opening id or a mark letter),
#: and none of them is a sentence about the part.
#:
#: The firings have to travel at all because of what the monitor turned out to be for. `gd_monitor` measured
#: `representation_disagrees_with_the_marks` catching a WRONG REPRESENTATION on 25 of 25, with zero false
#: alarms, on four draws, using only the look's lettered answers and no answer key. A wrong representation
#: inverts every lettered mark at once, so it is the one thing in this pipeline a reader most needs told and
#: it is not a statement about the geometry at all. Dropping the alerts with the quotes would have thrown that
#: away to protect against a fault the quotes carry and the ids do not.
ALERT_FIELDS = ("signal", "kind", "subject")


def alert_rows(joint: Joint, quotes: bool = False) -> list[dict[str, Any]]:
    fields = (*ALERT_FIELDS, "says", "measured") if quotes else ALERT_FIELDS
    return [{f: getattr(a, f, "") for f in fields} for a in joint.alerts]


def record_block(joint: Joint, mode: str = RECORD_DEFAULT) -> dict[str, Any] | None:
    if mode not in RECORD_MODES:
        raise ValueError(f"record mode must be one of {RECORD_MODES}, not {mode!r}")
    if mode == "none":
        return None
    keys = RECORD_FULL_KEYS if mode == "full" else RECORD_COUNTS_KEYS
    out = {k: v for k, v in joint.typed_block().items() if k in keys}
    out["alerts"] = alert_rows(joint, quotes=(mode == "full"))
    return out


def document(facts: Any, joint: Joint, *, purpose: str = "internal_cfd", engine: str = "snappy",
             unit: str | None = None, brief: str | None = None, declared: Any = None,
             cell_cap: int | None = None, include_facts: bool = False,
             look_meta: dict[str, Any] | None = None, carry_look: bool = True,
             surgery: bool = True, shape: bool = True, places: bool = True,
             record: str = RECORD_DEFAULT) -> dict[str, Any]:
    """THE DOCUMENT THAT LEAVES THE AGENT: `report_measured` with the reconciled look and the measured shape.

    `carry_look=False` builds the same document with no look at all, which is the control arm every number in
    this round is quoted against. Nothing else differs between the two calls.

    The shape block and the recovered places are written into the MEASURED half, not into the look block. That
    is `gd_research/docs/joint_research.md`'s R2 and it is the whole reason they survive a budget the look does
    not: a measured place is ranked with the measurements and an impression is ranked last.

    `record` decides how much of step 4's own working travels with the document, and it is a switch rather than
    a constant because MEASURING IT CHANGED THE ANSWER. See `RECORD_MODES`.
    """
    from geometry_agent.agent import hexera
    meta = look_meta or {}
    look = None
    if carry_look:
        imp = joint.reconciled if surgery else joint.raw
        look = hexera.look_block(imp, model=str(meta.get("model") or ""),
                                 provider=str(meta.get("provider") or ""), seconds=meta.get("seconds"),
                                 views=list(meta.get("views") or []),
                                 # the renderer's own record of where it drew the letters and which openings
                                 # it drew a stops panel for. It rides with the look because `planner_block`
                                 # cannot place a finding at a letter without the table that says where the
                                 # letter is, and the two halves are useless apart
                                 drawn=meta.get("drawn") or None)
    doc = hexera.report_measured(facts, unit, brief, purpose=purpose, engine=engine, declared=declared,
                                 cell_cap=cell_cap, look=look, include_facts=include_facts)
    into_document(doc, joint, shape=shape, places=places, record=record)
    doc["planner_block"] = planner_block(doc)
    return doc


def into_document(doc: dict[str, Any], joint: Joint, *, shape: bool = True, places: bool = True,
                  record: str = RECORD_DEFAULT) -> dict[str, Any]:
    """Write step 4's three keys into a document somebody else built. ONE WRITER, and it used to be none.

    `document` above builds its own document and this is the half of it that is about the Joint; `chain/job.py`
    has a document already (`survey_document`, against the brief) and calls this. Both write the same three keys
    the same way, so the arm the metric scored and the document a customer gets cannot drift apart.

    `measured_places` IS WHY THIS FUNCTION EXISTS RATHER THAN THREE LINES AT THE CALL SITE. `hexera._planner_places`
    reads that key off the document and ranks the rows with every other place, and `hexera.py` says in as many
    words that they are the only throat and section-change places there are. Nothing on the shipping path wrote
    it, so the planner has never been given one: another consumer built and waiting on a producer that did not
    exist. It is worth +77 places over 322 parts, 76 parts gaining one, 24 throats and 53 tapers, and identical
    on all four draws by construction, because a place recovered from the 41-station array is a measurement and
    contains no word the model wrote.
    """
    if shape:
        doc["measured_passage_shape"] = joint.shape
    if places:
        doc["measured_places"] = joint.measured_places()
    rec = record_block(joint, record)
    if rec is not None:
        doc["reconciliation"] = rec
    return doc


def planner_block(doc: dict[str, Any], *, intake: Any = None) -> dict[str, Any] | None:
    """`hexera.planner_block`, with the contradiction count inside its look.

    `intake` is passed straight through to `hexera.planner_block`, which is how the chain's step 7 calls it: the
    customer's answers ride in `survey.confirmed` and that half is not this file's business.

    The measured throat and taper (`doc["measured_places"]`) are NOT appended here any more: `hexera.planner_block`
    reads them itself and ranks them with every other place (work/z-deliver), so an append would list them twice,
    at the tail, behind the wall-side places they rank ahead of. `contradictions` rides in the look because it is
    the one quality number in this pipeline that survives a file nobody has seen, and a planner that gets a
    document with no answer key still gets to know how much the two sources disagreed about it.
    """
    from geometry_agent.agent import hexera
    base = hexera.planner_block(doc, intake=intake)
    if base is None:
        return None
    rec = doc.get("reconciliation")
    if isinstance(rec, dict) and isinstance(base.get("look"), dict):
        # INSIDE `look`, NOT BESIDE IT, and the reason is the boundary rather than taste.
        # `meshpipeline.engines.snappy.planner.GEOMETRY_AGENT_BLOCK_KEYS` is an ALLOWLIST of the keys the
        # planner will put in front of a model, and it names `status`, `places`, `look` and eleven others. A
        # new top-level key is not refused, it is silently dropped, so `look_contradictions` was composed on
        # every joint run and reached nothing. It is the one quality number in this pipeline that survives a
        # file nobody has seen, and a count of how far the two sources disagreed belongs with the source it is
        # about anyway.
        add: dict[str, Any] = {
            "contradictions": rec.get("contradictions"),
            "contradictions_read_as":
                "how many claims the measurement and the picture disagreed about on this part. It needs no "
                "answer key, so it is the one quality signal here that survives a file nobody has seen. High is "
                "a part to look at, not a part to refuse.",
        }
        # AND THE FIRINGS, AS IDS, BESIDE THE COUNT. The count says HOW MANY and never WHICH, and on the one
        # signal that matters most that is the whole of the information. `gd_monitor` measured
        # `representation_disagrees_with_the_marks` catching a WRONG REPRESENTATION on 25 of 25 with zero false
        # alarms on four draws, using only the look's lettered answers and no answer key. A wrong representation
        # inverts every lettered mark at once, which is the one thing a reader of this block most needs told, and
        # it does not raise a contradiction: it is an alert. `record_block` put the firings in the DOCUMENT and
        # the builder is handed the planner block, so until now they reached nothing at all.
        #
        # IDS AND NOTHING ELSE, which is `ALERT_FIELDS` and the argument written on it: `signal` is an id, `kind`
        # an enum and `subject` a place (an opening id or a mark letter). `says` and `measured` are the two sides
        # in the words each side used, and quoted into a block a model reads they are read as the block's own
        # claims, which is the same fault `RECORD_MODES` measured on `disagreements`.
        rows = [{f: r.get(f, "") for f in ALERT_FIELDS} for r in (rec.get("alerts") or []) if isinstance(r, dict)]
        if rows:
            add["alerts"] = rows
            add["alerts_read_as"] = ("signals that fired on the pair, by id, with no answer key. `kind` is the "
                                     "class of disagreement and `subject` is where: an opening id or a mark "
                                     "letter. None of these is a statement about the geometry.")
        base = {**base, "look": {**base["look"], **add}}
    return base


__all__ = ["ALERT_FIELDS", "JOINT_SCHEMA", "RECORD_DEFAULT", "RECORD_MODES", "Joint", "alert_rows",
           "document", "for_job", "impression_of", "into_document", "measured_for_job", "not_asked_of",
           "planner_block", "record_block", "run"]
