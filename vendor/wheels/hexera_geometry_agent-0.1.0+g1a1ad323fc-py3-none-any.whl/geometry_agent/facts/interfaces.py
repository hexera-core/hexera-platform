"""Faces two bodies have in common: where a solid meets a fluid in CHT, where one part sits on another.

Two passes. The exact pass matches triangle centroids across bodies (opposite normals, equal areas): a glued
multi-solid STEP gives the solid and the fluid the same triangles for the surface between them, and those are
`shared` interfaces a multi-region mesher can make conformal. The coincident pass takes the faces left over and
asks whether they lie on another body's surface: a plain compound export gives each body its own tessellation
of the common surface (different triangles, zero gap), and an STL assembly stacks parts face on face; those are
`coincident` interfaces, an interface only once the bodies are glued in CAD. Faces of either kind go into the
mask that turns a planar candidate into class 'interface' instead of a port.

The coincidence question is put to the other body's own ray scene (embree, the engine the thickness rays use):
a probe runs along the face's outward normal from `tol` behind the point to `tol` ahead of it, and the point is
on the other surface when the probe meets a face looking back at it. The distance along the normal bounds the
distance to the surface from above, so a probe never reports a point that is not within `tol`; it misses only
where the foot of the normal falls off the other surface's edge, which the covered-fraction sampling absorbs.
The body's own faces are not in the scene it is probed against, so a mating face at exactly the same depth (a
tube end on a nose cone's base) is the first hit, never hidden behind the face it belongs to. The work is one
probe per candidate face plus the sampling of the faces found, linear in faces; no point cloud stands in for a
surface and nothing is allocated per point x triangle."""
from __future__ import annotations

import warnings

import numpy as np
import trimesh
from scipy.spatial import cKDTree

from geometry_agent.facts.openings import _region_of_faces
from geometry_agent.facts.schema import Interface

#: Exact pass: centroids closer than this fraction of the diagonal are the same triangle (round-off only).
CENTROID_TOL_OF_DIAG = 1e-6
#: Interface faces look at each other: the fluid's outward normal is the solid's inward normal.
NORMAL_DOT_MAX = -0.99
AREA_REL_TOL = 0.05
#: Coincident pass: a point is on the other body's surface within this fraction of the diagonal. One order
#: below the loader's linear deflection (1e-3 of the diagonal), so two copies of one B-rep surface match while
#: a 0.5 mm bolt clearance in a 230 mm bracket (2e-3) and the 0.2 mm fluid/solid gap of nested_cht (5e-4)
#: stay gaps. Two independent tessellations of the same curved face can differ by the chordal sag, which for
#: large radii exceeds this; such a pair is reported as a gap of that size, never as an interface.
COINCIDENT_TOL_OF_DIAG = 1e-4
#: A face enters the interface mask when at least this fraction of it lies on the other surface; its area
#: counts in proportion, so a strip crossing the edge of the overlap contributes its covered part.
COINCIDENT_FACE_FRACTION = 0.5
#: Seeded area-uniform samples for a face only partly on the other surface (one of its vertices, edge midpoints
#: or centroid probed off it): the covered fraction is then known to about 9% per face and is unbiased over an
#: interface, where the fixed points, which can sit exactly on the other tessellation's edges, are not.
FACE_SAMPLES_REFINE = 32
#: A probe that meets a face within tolerance but looking the same way (the near wall of a sheet thinner than
#: the tolerance, a duplicated patch) is cast again from just past it, at most this many casts in all.
PROBE_CASTS = 2
#: How far past such a hit the next cast starts, as a fraction of the tolerance: above embree's float32
#: resolution (about 1e-7 of the scene after its scaling to a unit box) so the same face is not hit twice, and
#: far below any sheet thickness that would matter.
PROBE_STEP_OF_TOL = 0.05
#: Region pairs whose bounding boxes touch are probed in order of the smaller body's area (the contact area is
#: bounded by it), and past this many pairs the rest are skipped with a warning. A 402-body vehicle structure
#: has about 1500 touching pairs; this is a 2000-part assembly with every part touching ten others.
MAX_COINCIDENT_PAIRS = 20_000
#: mesh.metadata key under which the number of skipped pairs is left when the cap is hit.
PAIRS_SKIPPED_META = "interface_pairs_skipped"


def detect_interfaces(mesh: trimesh.Trimesh, region_of: np.ndarray | None = None, seed: int = 0) -> tuple[list[Interface], np.ndarray]:
    """Returns the interfaces and a boolean mask over faces marking every face that belongs to one."""
    region_of = _region_of_faces(mesh) if region_of is None else region_of
    mask = np.zeros(len(mesh.faces), dtype=bool)
    if len(region_of) == 0 or int(region_of.max()) < 1:
        return [], mask
    centers = np.asarray(mesh.triangles_center)
    normals = np.asarray(mesh.face_normals)
    areas = np.asarray(mesh.area_faces)
    diag = float(np.linalg.norm(mesh.extents))
    out = _shared(region_of, centers, normals, areas, diag, mask)
    out += _coincident(mesh, region_of, centers, normals, areas, diag, mask, seed)
    return out, mask


def _shared(region_of, centers, normals, areas, diag, mask) -> list[Interface]:
    tol = CENTROID_TOL_OF_DIAG * diag + 1e-12
    pairs = cKDTree(centers).query_pairs(r=tol, output_type="ndarray")
    if len(pairs) == 0:
        return []
    i, j = pairs[:, 0], pairs[:, 1]
    keep = (region_of[i] != region_of[j])
    keep &= np.einsum("ij,ij->i", normals[i], normals[j]) < NORMAL_DOT_MAX
    keep &= np.abs(areas[i] - areas[j]) <= AREA_REL_TOL * np.maximum(areas[i], areas[j])
    i, j = i[keep], j[keep]
    if len(i) == 0:
        return []
    mask[i] = True
    mask[j] = True
    lo = np.minimum(region_of[i], region_of[j])
    hi = np.maximum(region_of[i], region_of[j])
    out = []
    for a, b in sorted({(int(x), int(y)) for x, y in zip(lo, hi)}):
        sel = (lo == a) & (hi == b)
        out.append(Interface(region_a=f"r{a + 1}", region_b=f"r{b + 1}", area=float(areas[i[sel]].sum()), faces=int(sel.sum())))
    return out


def _parts(mesh: trimesh.Trimesh, region_of: np.ndarray, n: int) -> list[trimesh.Trimesh]:
    """One sub-mesh per region in the region's face order (the loader's cached ones when they line up)."""
    from geometry_agent.facts.regions import region_meshes
    parts = region_meshes(mesh)
    if len(parts) == n and all(len(p.faces) == c for p, c in zip(parts, np.bincount(region_of, minlength=n))):
        return parts
    return [mesh.submesh([np.where(region_of == k)[0]], append=True) for k in range(n)]


def _probe(part: trimesh.Trimesh, pts: np.ndarray, dirs: np.ndarray, tol: float) -> np.ndarray:
    """Whether each point lies on `part`'s surface within tol, looking along dirs (the outward normal of the face
    the point belongs to). A segment from tol behind the point to tol ahead of it is traced through the part's
    ray scene; the point is on the surface when the segment meets a face looking back along dirs. The distance
    to a hit is recomputed in float64 from the face's plane, so the tolerance test is not embree's float32."""
    n = len(pts)
    on = np.zeros(n, dtype=bool)
    if n == 0:
        return on
    normals = np.asarray(part.face_normals)
    centers = np.asarray(part.triangles_center)
    origins = pts - dirs * tol
    travel = np.zeros(n)
    live = np.arange(n)
    for _ in range(PROBE_CASTS):
        start = origins[live] + dirs[live] * travel[live, None]
        tri = np.asarray(part.ray.intersects_first(start, dirs[live]))
        got = tri >= 0
        if not got.any():
            break
        li, tri, start = live[got], tri[got], start[got]
        facing = np.einsum("ij,ij->i", dirs[li], normals[tri])
        denom = np.where(np.abs(facing) > 1e-12, facing, 1e-12)
        t = travel[li] + np.einsum("ij,ij->i", centers[tri] - start, normals[tri]) / denom
        within = t <= 2.0 * tol
        valid = within & (facing < NORMAL_DOT_MAX)
        on[li[valid]] = True
        again = within & ~valid
        travel[li[again]] = t[again] + PROBE_STEP_OF_TOL * tol
        live = li[again]
        if len(live) == 0:
            break
    return on


def _covered_fraction(mesh: trimesh.Trimesh, faces: np.ndarray, part: trimesh.Trimesh, tol: float,
                      rng: np.random.Generator) -> np.ndarray:
    """Fraction of each face (whose centroid is already known to be on `part`) that lies on it. A face whose
    vertices and edge midpoints all probe on is fully covered; any other gets FACE_SAMPLES_REFINE seeded
    interior samples, and its fraction is the share of those (with the centroid) that probe on."""
    tri = np.asarray(mesh.triangles)[faces]
    normals = np.asarray(mesh.face_normals)[faces]
    n = len(faces)
    fixed = np.concatenate([tri[:, 0], tri[:, 1], tri[:, 2], (tri[:, 0] + tri[:, 1]) / 2, (tri[:, 1] + tri[:, 2]) / 2,
                            (tri[:, 2] + tri[:, 0]) / 2], axis=0)
    on_fixed = _probe(part, fixed, np.tile(normals, (6, 1)), tol).reshape(6, n).all(axis=0)
    frac = np.ones(n)
    partial = np.nonzero(~on_fixed)[0]
    if len(partial):
        uv = rng.random((len(partial), FACE_SAMPLES_REFINE, 2))
        fold = uv.sum(axis=2) > 1.0
        uv[fold] = 1.0 - uv[fold]
        t = tri[partial]
        pts = t[:, None, 0] + uv[:, :, 0:1] * (t[:, None, 1] - t[:, None, 0]) + uv[:, :, 1:2] * (t[:, None, 2] - t[:, None, 0])
        dirs = np.repeat(normals[partial], FACE_SAMPLES_REFINE, axis=0)
        hits = _probe(part, pts.reshape(-1, 3), dirs, tol).reshape(len(partial), FACE_SAMPLES_REFINE).sum(axis=1)
        frac[partial] = (1.0 + hits) / (1.0 + FACE_SAMPLES_REFINE)
    return frac


def _coincident(mesh, region_of, centers, normals, areas, diag, mask, seed) -> list[Interface]:
    n = int(region_of.max()) + 1
    tol = COINCIDENT_TOL_OF_DIAG * diag + 1e-12
    parts = _parts(mesh, region_of, n)
    bounds = [np.asarray(p.bounds) for p in parts]
    lo_all = np.array([b[0] for b in bounds])
    hi_all = np.array([b[1] for b in bounds])
    overlap = np.all(lo_all[:, None, :] <= hi_all[None, :, :] + tol, axis=2)
    overlap &= overlap.T
    pairs = np.argwhere(np.triu(overlap, k=1))
    if len(pairs) == 0:
        return []
    region_area = np.bincount(region_of, weights=areas, minlength=n)
    smaller = np.minimum(region_area[pairs[:, 0]], region_area[pairs[:, 1]])
    pairs = pairs[np.argsort(-smaller, kind="stable")]
    if len(pairs) > MAX_COINCIDENT_PAIRS:
        skipped = len(pairs) - MAX_COINCIDENT_PAIRS
        warnings.warn(f"{len(pairs)} touching region pairs; coincident interfaces searched for the {MAX_COINCIDENT_PAIRS} "
                      f"largest only, {skipped} pairs of the smallest bodies skipped", RuntimeWarning, stacklevel=2)
        try:
            mesh.metadata[PAIRS_SKIPPED_META] = skipped
        except (AttributeError, TypeError):
            pass
        pairs = pairs[:MAX_COINCIDENT_PAIRS]
    order = np.argsort(region_of, kind="stable")
    starts = np.searchsorted(region_of[order], np.arange(n + 1))
    faces_of = [order[starts[k]:starts[k + 1]] for k in range(n)]
    rng = np.random.default_rng(seed)
    center_trees: dict[int, cKDTree] = {}

    def faces_in_box(src: int, lo: np.ndarray, hi: np.ndarray) -> np.ndarray:
        """Faces of src whose centroid lies in the box, through a k-d tree over the region's centroids and the
        box's circumsphere, so a 1.3M-face frame member is not rescanned for each of its 300 neighbours."""
        if src not in center_trees:
            center_trees[src] = cKDTree(centers[faces_of[src]])
        mid = (lo + hi) / 2
        local = np.asarray(center_trees[src].query_ball_point(mid, float(np.linalg.norm(hi - mid))), dtype=int)
        cand = faces_of[src][local]
        cand = cand[~mask[cand]]
        return cand[np.all((centers[cand] >= lo) & (centers[cand] <= hi), axis=1)]

    out = []
    for a, b in pairs:
        a, b = int(a), int(b)
        cands: dict[int, np.ndarray] = {}
        for src, dst in ((a, b), (b, a)):
            cands[src] = faces_in_box(src, bounds[dst][0] - tol, bounds[dst][1] + tol)
        covered: list[tuple[float, float, int]] = []
        # both directions are probed: a contact patch can be smaller than every face of the smaller body (a
        # booster's flat side glued to a fin), so the side whose centroids land on the other is not predictable
        for src, dst in ((a, b), (b, a)):
            cand = cands[src]
            if len(cand) == 0:
                continue
            cand = cand[_probe(parts[dst], centers[cand], normals[cand], tol)]
            if len(cand) == 0:
                continue
            frac = _covered_fraction(mesh, cand, parts[dst], tol, rng)
            keep = frac >= COINCIDENT_FACE_FRACTION
            mask[cand[keep]] = True
            area = float((frac * areas[cand]).sum())
            covered.append((float(areas[cand][frac < 1.0].sum()) / max(area, 1e-300), area, int(keep.sum())))
        faces = sum(c[2] for c in covered)
        if faces == 0:
            continue
        # a side whose faces all lie inside the overlap measures its area exactly (the sum of their areas); a
        # side with faces running past it only estimates the covered part by sampling, so the side with the
        # smaller share of partly covered area is the one reported
        area = min(covered, key=lambda c: (c[0], -c[1]))[1]
        out.append(Interface(region_a=f"r{a + 1}", region_b=f"r{b + 1}", area=area, faces=faces, kind="coincident"))
    out.sort(key=lambda i: (int(i.region_a[1:]), int(i.region_b[1:])))
    return out
