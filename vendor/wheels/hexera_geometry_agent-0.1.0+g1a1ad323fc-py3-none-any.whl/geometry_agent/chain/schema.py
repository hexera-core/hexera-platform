"""The job record: one file through the whole chain, in one row, keyed so a later pass can join it.

THE CHAIN, in Rehaan's words and in the order the record is written.

    SURVEY      the measurement is the instrument and the look is the eyes. It describes the geometry. It
                names places and measurements, never builder settings, and it never predicts the mesh.
    UNCERTAINTY what the survey could NOT settle. This is not a failure list. The look abstains on most
                opening roles by design, and an abstention is the input to the next stage.
    INTAKE      the questions put to the customer, and how each one came back: answered, or defaulted.
    PLAN        what the geometry agent decided to DO, given the confirmations. It decides where the cells
                go. It does NOT re-decide what the geometry IS.
    MESH        how it came out, which arrives later and from the builder, not from us.

WHAT MAKES THIS A LEDGER RATHER THAN A LOG. Three things:

  1. THE KEYS JOIN. `part_key` is the file's facts sha, so every job ever run on the same file joins. `topic`
     is the question's kind with the part-specific subject stripped, so the same question across a thousand
     customers joins. `question_id` ties a resolution back to the uncertainty that raised it and to the
     survey evidence under that. Nothing in `learn/` can do this: an `OutcomeRecord` has no question in it.
  2. A DEFAULT IS NOT A CONFIRMATION, by type. See `chain/resolution.py`.
  3. THE STAGES ARRIVE SEPARATELY AND THE RECORD SURVIVES IT. The mesh lands hours after the plan and
     sometimes never. `chain/store.py` writes one event per stage and folds them, so a half-finished job is a
     record with `mesh: None`, not a missing row.

THE ARCHITECTURAL RULE, and it is Rehaan's: the surveyor's measurements arrive at the geometry agent as
AUTHORITATIVE FACTS. `Survey.authoritative` names the fields the plan may not re-decide and
`plan_drift(survey, plan)` reports every one it restated differently. It is a report, not a veto: this package
records, it does not gate. What it stops is the two halves drifting with nobody noticing.

NO PYDANTIC IN THIS PACKAGE, on purpose. Pydantic coerces, and the one thing this schema exists to prevent is
one shape being read as another. Plain frozen dataclasses with explicit codecs cannot coerce a default into an
answer, and `resolution.py` depends on that.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any

from geometry_agent.chain.resolution import (
    Resolution,
    is_answer,
    now,
    tally,
)
from geometry_agent.chain.resolution import (
    from_json as resolution_from_json,
)
from geometry_agent.chain.resolution import (
    to_json as resolution_to_json,
)

JOB_SCHEMA = "geometry_agent.chain.job.v1"

#: The stage names, in chain order. A store event carries one of these.
#:
#: `brief` is FIRST and that is Rehaan's order, not a convenience: the brief changes the representation decision
#: (wall shell against fluid domain), so the survey is measured against it and records which brief it was measured
#: against. `trade` is the third intake, which exists only for a question that did not exist at the second.
#: `handover` is what the builder was given. A record with only some of these is still a record.
STAGES = ("brief", "survey", "look", "uncertainty", "intake", "plan", "trade", "handover", "mesh")

# ---------------------------------------------------------------------------------------------------------------
# the kind vocabulary: one union, and the three packages' names for each kind mapped onto it
# ---------------------------------------------------------------------------------------------------------------

#: THE NINE KINDS (docs/synthesis.md appendix B), and a tenth since work/z-next, `fluid_side`. No package had all nine: `ask/` had seven, this ledger six,
#: `contract/` five plus one in prose. The ledger's own names are kept where it had one, because `topic_of` and
#: every rule in `recalibrate.py` count topics by these words and a rename would split one topic's history in two.
KINDS: tuple[str, ...] = (
    "dispatch_refusal",    # the platform's own pre-mesh rules would refuse the file as declared
    "role",                # what a mouth is for
    "opening_unmeasured",  # a mouth only the LOOK saw
    "opening_unseen",      # a mouth only the MEASUREMENT found. Recorded, never asked
    "flow_direction",      # which way the flow comes at an external body
    "unit",                # the length unit
    "fluid_side",          # which side of the surface is the fluid, where the geometry reads both ways
    "budget",              # the cell envelope against the customer's stated cap
    "dispute",             # the look and the measurement disagree at one place
    "identity",            # a name resting on the picture alone, capped at 0.6. Advisory, never asked
)

#: Every other package's word for a kind, onto the one above. `canonical_kind` is the only reader.
KIND_ALIASES: dict[str, str] = {
    # ask/schema.KINDS
    "port_role": "role", "unlabelled_mouth": "opening_unmeasured", "budget_envelope": "budget",
    "look_dispute": "dispute",
    # contract/survey.Uncertainty.about
    "opening.role": "role", "cell_budget": "budget", "contradiction_resolution": "dispute",
    "identity.name": "identity", "dispatch": "dispatch_refusal", "opening_ids": "opening_unseen",
    "representation": "fluid_side",
}


def canonical_kind(kind: str) -> str:
    """The union's word for any package's kind. Raises on a word none of the three packages uses, because a
    kind nobody can name is a question nobody can join across jobs."""
    k = str(kind)
    if k in KINDS:
        return k
    if k in KIND_ALIASES:
        return KIND_ALIASES[k]
    raise ValueError(f"{kind!r} is not a kind: one of {KINDS} or an alias in KIND_ALIASES")


def job_key(part_key: str, job_id: str) -> str:
    """The row's identity: the file, then the job on it. Twelve characters of sha is what `learn/store.py`
    already uses for a record file name, so a reader of both sees the same prefix."""
    return f"{str(part_key)[:12]}__{job_id}"


def question_id(key: str, uncertainty_id: str) -> str:
    """One question, once, on one job. The `#` is what a later join splits on."""
    return f"{key}#{uncertainty_id}"


def topic_of(uncertainty_id: str) -> str:
    """The kind with the part-specific subject stripped: `role:o3` becomes `role`.

    THIS IS THE JOIN THAT MAKES THE LEDGER WORTH KEEPING. `role:o3` on this housing and `role:o7` on somebody
    else's manifold are the same question asked twice, and the retirement rule counts topics, never ids.
    """
    return str(uncertainty_id).split(":", 1)[0]


# ---------------------------------------------------------------------------------------------------------------
# what the survey measured
# ---------------------------------------------------------------------------------------------------------------

#: The fields the geometry agent may NOT re-decide. Every one of them is a statement about what the geometry
#: IS, measured by the instrument, and a second answer to any of them is two answers to one question with no
#: way to choose. The list is short on purpose: everything else is the agent's to decide.
AUTHORITATIVE_FIELDS = ("representation", "openings", "unit", "bbox_extent", "bodies", "watertight")


@dataclass(frozen=True, slots=True)
class MeasuredOpening:
    """One opening as the instrument has it. No role: a role comes from the customer or from nowhere."""

    id: str
    kind: str = ""
    shape: str = ""
    classification: str = ""
    area: float | None = None
    hydraulic_diameter: float | None = None
    bore_diameter: float | None = None
    tilt_deg: float | None = None
    on_bbox_face: bool | None = None
    centroid: tuple[float, float, float] | None = None
    region_id: str = ""


@dataclass(frozen=True, slots=True)
class Survey:
    """What the instrument and the eyes together know about the file, before anybody was asked anything.

    Sourced from `hexera.report_measured(...)`: `facts_sha256` is its `source_sha256`, `representation` its
    `representation`, `openings` its `openings`, `forecast_cells` its `forecast.cells_high` (the builder
    emulator, never `cell_estimate_refined`), and `planner_block_status` the block's own `status`.
    """

    facts_sha256: str
    representation: str = ""
    purpose: str = ""
    engine: str = ""
    unit: str = ""
    unit_basis: str = ""
    #: `ok` or `degraded`. Degraded means a length has no confirmed scale, which is the commonest reason a
    #: job cannot be planned at all, and it is a fact about the record, not about the part.
    planner_block_status: str = ""
    openings: tuple[MeasuredOpening, ...] = ()
    bbox_extent: tuple[float, float, float] | None = None
    bodies: int | None = None
    watertight: bool | None = None
    #: The envelope, from `tools.estimate_builder_cells` through `hexera.forecast`. Never the refinement-ball
    #: figure: median 1.86x, max 576x (hexera.PLANNER_BLOCK_WITHHELD).
    forecast_cells: int | None = None
    forecast_basis: tuple[str, ...] = ()
    #: What the customer already said their budget was, read off the brief. None when they said nothing.
    stated_cell_cap: int | None = None
    measurement_schema: str = ""
    #: Named here so a consumer never has to have read this module. See AUTHORITATIVE_FIELDS.
    authoritative: tuple[str, ...] = AUTHORITATIVE_FIELDS
    #: The brief this survey was measured against. EMPTY means it was measured before intake, which is the order
    #: the upload hook runs in and the order Rehaan's design refuses: the brief changes the representation.
    brief_sha256: str = ""
    #: What the catalog reads the same file as with no brief and no port rows. Recorded beside `representation`
    #: so the dependency is a fact in the row rather than an accident of when the upload hook fired.
    representation_without_brief: str = ""

    @property
    def opening_ids(self) -> tuple[str, ...]:
        return tuple(o.id for o in self.openings)


@dataclass(frozen=True, slots=True)
class Brief:
    """Stage 1: what the customer stated before anything was measured. Purpose, budget, boundary conditions.

    Nothing here is a confirmation. The brief is the customer's words with nobody asked, which is `Stated` in
    `resolution.py`, and a budget read out of it is a stated budget until a question confirms it.
    """

    sha256: str
    purpose: str = ""
    engine: str = ""
    fidelity: str = ""
    text: str = ""
    #: The budget and the sentence it was read out of. None when the brief states none, which is a real answer.
    cell_cap: int | None = None
    cell_cap_quote: str = ""
    #: The customer's port rows as intake parsed them: name, role, near (file units), bore. Their own words.
    declared: tuple[dict[str, Any], ...] = ()


# ---------------------------------------------------------------------------------------------------------------
# what the look observed, and with what confidence
# ---------------------------------------------------------------------------------------------------------------

@dataclass(frozen=True, slots=True)
class SeenOpening:
    """One opening as the look reports it. `role_said` is kept verbatim including 'unsure'.

    THE ABSTENTION IS THE PRODUCT. `vision/trust.py` puts `likely_role` in the recorded tier precisely
    because it abstains on most mouths and is a coin where it does not, so this field never decides anything.
    It is here because the abstention is what the next stage turns into a question.
    """

    id: str
    role_said: str = ""
    looks_like: str = ""
    mouth: str = ""
    why: str = ""

    @property
    def abstained(self) -> bool:
        """True when the look declined to call a role. 'not a port' is an assertion and is not an abstention."""
        return str(self.role_said or "").strip().lower() in ("", "unsure", "unknown", "cannot tell")


@dataclass(frozen=True, slots=True)
class Look:
    """What the eyes said, with the trust tier each field carries, so a consumer branches on a value.

    `tiers` is `{field: relied_on | candidate | recorded}` from `vision.trust.fields_for(impression)`, copied
    into the record rather than referenced, because the tiers move as rounds measure more and a record has to
    stay readable against the tiers that were in force when it was written.
    """

    #: WHICH OF THE THREE STATES THIS LOOK WAS IN (`contract.survey.LOOK_STATES`), because without it the ledger
    #: could not tell them apart: a look that FAILED and a look nobody took both arrive here as a record with no
    #: words, an empty `tiers` and an empty `model`, and a reader of the ledger then counts "nothing looked" and
    #: "the reader did not answer" as one thing. Empty means the record does not say, which is what a row written
    #: before this field existed says.
    status: str = ""
    model: str = ""
    provider: str = ""
    #: The look's own word, not a number. `vision/trust.py`: a trigger, not a score.
    confidence: str = ""
    looks_like: str = ""
    openings_seen: tuple[SeenOpening, ...] = ()
    #: RELIED ON, and the reason the look is in the chain at all: 25 of 25 recall at 93 to 100 per cent
    #: precision, stable in every arm, and NO measurement in this pipeline reports an attachment.
    attachments: tuple[str, ...] = ()
    #: CANDIDATE when it has entries, RELIED ON when it is empty: 0 false obstructions on 103 plain-passage
    #: cases. The empty list is the stronger statement, so `inside_is_plain` carries it as its own key rather
    #: than leaving a consumer to infer a finding from an absence.
    internal_features: tuple[str, ...] = ()
    inside_is_plain: bool | None = None
    tiers: dict[str, str] = field(default_factory=dict)
    #: How many positive assertions the reply made, so a later pass can read a contradiction count as a rate.
    assertions: int | None = None
    #: `reconcile/verdict.Reconciliation.contradictions`: the one quality signal that needs no answer key.
    contradictions: int | None = None
    identity_confidence_max: float | None = None
    prompt_sha256: str = ""

    @property
    def abstentions(self) -> tuple[str, ...]:
        return tuple(o.id for o in self.openings_seen if o.abstained)

    @property
    def role_calls(self) -> tuple[str, ...]:
        return tuple(o.id for o in self.openings_seen if not o.abstained)


# ---------------------------------------------------------------------------------------------------------------
# what the survey could not settle
# ---------------------------------------------------------------------------------------------------------------

@dataclass(frozen=True, slots=True)
class Uncertainty:
    """One thing the survey could not settle, with what it CAN say beside what it cannot.

    THE LEDGER ROW, one of the three `Uncertainty` types in this tree, and here is why there are three rather
    than one. They are not three spellings of one record: they have three CARDINALITIES and three readers, and
    `ask/` is the source of all three.

      ask/schema.Uncertainty       what the Surveyor declined to settle. ONE PER ABSTENTION. It is the only one
                                   that carries `measurement`, which is what `ask.consequence` branches to
                                   decide whether the question is worth putting at all. Nothing downstream can
                                   recompute that, so nothing downstream is the source.
      chain/schema.Uncertainty     this one. ONE PER PLACE, because the learning joins on `role:o3` while the
                                   question that asked about it may name four mouths. It carries `teaches`,
                                   `rank` and `raised_at`, which are about a row's worth across JOBS and mean
                                   nothing inside one.
      contract/survey.Uncertainty  what the BUILDER is told. ONE PER QUESTION, and only for a question nobody
                                   answered, because an answered one is not an uncertainty any more.

    ONE VOCABULARY, and that is the part that has to hold: all three name the same ten kinds in their own words
    and `canonical_kind` is the only join. `tests/test_chain_ledger.py` asserts every word of all three maps onto
    `KINDS` one to one and that nothing in `KINDS` is unreachable, so a kind added to one package and not the
    others fails there rather than splitting a topic's history in two.

    THE TWO CONVERTERS, both in `chain/job.py` and both from the ask objects: `merged_records` builds these, and
    `contract_uncertainties` builds the handoff's. The fields the first version of this record had are kept with
    their meanings, so every stored row still loads.

    `teaches` is the field that makes this package worth building: it names what an answer here would be
    ground truth FOR. An uncertainty that teaches nothing is still worth asking about if it changes the mesh,
    but it is not worth a row in a learning report, and the difference has to be in the record rather than in
    somebody's head.
    """

    id: str
    #: One of `KINDS`. Written through `canonical_kind` on the live path.
    kind: str
    subject: str = ""
    #: What the survey positively knows about the subject. MEASURED VALUES ONLY. Appendix B keeps one of
    #: `known` and `evidence`, not both; this is the JSONL form, and `contract.marks` is the typed form it is
    #: converted into at the boundary, by one function.
    known: dict[str, Any] = field(default_factory=dict)
    #: Why it is not settled, in one line, in the customer's language.
    unsettled_because: str = ""
    #: The question, written for a customer and not for a schema. Empty means it is never asked whatever the
    #: budget, which is how `opening_unseen` stays a record rather than a question.
    ask: str = ""
    #: What we do if nobody answers, and where that default comes from.
    default: str = ""
    default_from: str = ""
    #: What an answer here would be a labelled example of. Empty when an answer teaches nothing.
    teaches: str = ""
    #: Does answering change the mesh, the boundary conditions, or nothing? A question that changes nothing
    #: is how a form stops being filled in (reconcile/verdict.QUESTION_ORDER's own argument).
    effect: str = "advisory"
    #: Lower sorts first. Never shown to anybody: it is an ORDER, and there is no measurement behind the
    #: exchange rate between kinds, exactly as `hexera._planner_places` says of its own severity.
    rank: float = 0.0
    # --- appendix B, added for the merge ---------------------------------------------------------------------
    #: Every measured id this one answer settles. Four unassigned mouths are one question naming four.
    places: tuple[str, ...] = ()
    #: Why nobody here can settle it, in the SURVEYOR's terms. `unsettled_because` is the customer's; both are
    #: kept because they are two audiences.
    why: str = ""
    #: What a person may answer. Every option comes from the measurement or the customer's own words, never the
    #: look's guess.
    options: tuple[str, ...] = ()
    options_from: str = ""
    #: `ask.schema.TIERS`, lexicographic: dispatch, boundary, domain, resolution, none. Computed by branching
    #: the emulator (`ask.consequence`), never set by hand. Replaces `rank` as the order on the live path.
    tier: str = ""
    #: Whether `tier` was computed or asserted from `ask.consequence.DECLARED_TIER`. An uncomputable consequence
    #: is never read as no consequence. None on a row written before the merge.
    computed: bool | None = None
    #: Which intake raised it: `second` (armed with the survey) or `third` (only a question that did not exist
    #: at the second; the budget trade is the canonical one).
    raised_at: str = "second"
    #: Whether it was put to the customer, and if not, what settled it or why it was held
    #: (`ask.schema.SETTLED_BY`). None on a row written before the merge.
    asked: bool | None = None
    settled_by: str = ""

    @property
    def topic(self) -> str:
        return self.kind


# ---------------------------------------------------------------------------------------------------------------
# what intake asked and what came back
# ---------------------------------------------------------------------------------------------------------------

@dataclass(frozen=True, slots=True)
class Question:
    """One question as it was put. Joined to its uncertainty by `uncertainty_id` and to every other asking of
    the same question, on every other job, by `topic`."""

    id: str
    uncertainty_id: str
    topic: str
    ask: str = ""
    options: tuple[str, ...] = ()
    default: str = ""
    default_from: str = ""
    effect: str = "advisory"
    asked_at: str = ""


@dataclass(frozen=True, slots=True)
class Intake:
    """The conversation. `asked` is what went out; `resolutions` is what came back, one per question.

    The two lists are separate because they can disagree in the one direction that matters: a question with no
    resolution is a job still open, and a resolution with no question is a bug.
    """

    asked: tuple[Question, ...] = ()
    resolutions: tuple[Resolution, ...] = ()
    #: How the conversation ran, for the record: turns, seconds, who was on the other end.
    turns: int | None = None
    #: Intake's own write-up, the text that goes to the builder beside the geometry agent's.
    write_up: str = ""

    @property
    def counts(self) -> dict[str, int]:
        return tally(list(self.resolutions))

    @property
    def answered(self) -> tuple[Resolution, ...]:
        """The only resolutions the learning path may read. One accessor, so no caller filters by hand."""
        return tuple(r for r in self.resolutions if is_answer(r))


# ---------------------------------------------------------------------------------------------------------------
# what the geometry agent planned, and how it came out
# ---------------------------------------------------------------------------------------------------------------

@dataclass(frozen=True, slots=True)
class Plan:
    """What the agent decided to DO. Where the cells go, not what the geometry is.

    `restates` is the drift check: any authoritative field the plan wrote a different value for. It is filled
    by `plan_drift`, never by the agent, because a thing that reports its own compliance reports compliance.
    """

    accepted: bool | None = None
    schema_version: int | None = None
    fidelity: str = ""
    engine: str = ""
    cell_estimate: int | None = None
    refinement_regions: int | None = None
    #: The ids intake confirmed that the plan actually used. A plan that ignored a confirmation is the whole
    #: reason the chain is worth recording.
    used_confirmations: tuple[str, ...] = ()
    #: `{field: what the plan said}` for any authoritative field the plan restated differently.
    restates: dict[str, Any] = field(default_factory=dict)
    risks: int | None = None
    questions_asked: int | None = None
    #: The agent's own write-up, which travels to the builder with the survey's information inside it.
    write_up: str = ""
    policy: str = ""
    model: str = ""
    prompt_sha256: str = ""


@dataclass(frozen=True, slots=True)
class Mesh:
    """How it came out. Arrives from the builder, hours later, and is None until it does."""

    status: str = ""
    cells: int | None = None
    max_skewness: float | None = None
    max_non_orthogonality_deg: float | None = None
    attempts: int | None = None
    engine: str = ""
    minutes: float | None = None
    #: The label file's own components where one exists, copied not recomputed.
    labels: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------------------------------------------
# the record
# ---------------------------------------------------------------------------------------------------------------

@dataclass(frozen=True, slots=True)
class JobRecord:
    """One job, whole. Any stage may be None; a record with only a survey is a real record."""

    key: str
    part_key: str
    job_id: str
    schema: str = JOB_SCHEMA
    #: `live` for a real job, `simulation` for a replay, `heuristic` for a stand-in. A number quoted from a
    #: record whose provenance is `simulation` is a simulated number and the reports say so in the headline.
    provenance: str = "live"
    #: The corpus case name where there is one. EMPTY ON A CUSTOMER FILE, and every consumer must work with
    #: it empty: this is the field that would let a metric read the answer key.
    case: str = ""
    created_at: str = ""
    updated_at: str = ""
    survey: Survey | None = None
    look: Look | None = None
    uncertainties: tuple[Uncertainty, ...] = ()
    intake: Intake | None = None
    plan: Plan | None = None
    mesh: Mesh | None = None
    brief: Brief | None = None
    #: The third intake. None when no question arose that did not exist at the second, which is the common case
    #: and is a real state, not a missing stage.
    trade: Intake | None = None
    #: What the builder was handed, whole: both write-ups and the typed block. Stored so a later reader can see
    #: exactly what crossed the last boundary rather than recomputing it.
    handover: dict[str, Any] | None = None

    @property
    def complete(self) -> bool:
        return all(x is not None for x in (self.survey, self.intake, self.plan, self.mesh))

    @property
    def stages_present(self) -> tuple[str, ...]:
        got = {"brief": self.brief, "survey": self.survey, "look": self.look,
               "uncertainty": self.uncertainties or None, "intake": self.intake, "plan": self.plan,
               "trade": self.trade, "handover": self.handover, "mesh": self.mesh}
        return tuple(name for name in STAGES if got.get(name) is not None)


# ---------------------------------------------------------------------------------------------------------------
# the drift check
# ---------------------------------------------------------------------------------------------------------------

def plan_drift(survey: Survey | None, restated: dict[str, Any] | None) -> dict[str, Any]:
    """Every authoritative field the plan wrote a different value for.

    `restated` is whatever the plan said about the geometry, as a plain dict. The check is equality on the
    fields in `AUTHORITATIVE_FIELDS` and nothing cleverer, because a tolerant comparison is how the two halves
    drift a little at a time. Returns `{field: {"survey": ..., "plan": ...}}`, empty when they agree.

    THIS REPORTS, IT DOES NOT VETO. The agent owns the plan. What it may not own is a second answer to what
    the geometry is, and a second answer nobody can see is the failure mode.
    """
    out: dict[str, Any] = {}
    if survey is None or not restated:
        return out
    for name in survey.authoritative or AUTHORITATIVE_FIELDS:
        if name not in restated:
            continue
        mine = getattr(survey, name, None)
        if name == "openings":
            mine = list(survey.opening_ids)
        theirs = restated[name]
        if isinstance(mine, tuple):
            mine = list(mine)
        if isinstance(theirs, tuple):
            theirs = list(theirs)
        if mine != theirs:
            out[name] = {"survey": mine, "plan": theirs}
    return out


# ---------------------------------------------------------------------------------------------------------------
# codecs. Explicit, because a generic one would coerce, and coercion is the thing.
# ---------------------------------------------------------------------------------------------------------------

_SIMPLE = {"survey": Survey, "look": Look, "plan": Plan, "mesh": Mesh}


def _openings_from(rows: Any) -> tuple[MeasuredOpening, ...]:
    return tuple(MeasuredOpening(**{k: v for k, v in r.items() if k in _names(MeasuredOpening)})
                 for r in (rows or []) if isinstance(r, dict))


def _names(cls: type) -> set[str]:
    from dataclasses import fields as _f
    return {f.name for f in _f(cls)}  # type: ignore[arg-type]


def to_json(record: JobRecord) -> dict[str, Any]:
    out: dict[str, Any] = {"schema": record.schema, "key": record.key, "part_key": record.part_key,
                           "job_id": record.job_id, "provenance": record.provenance, "case": record.case,
                           "created_at": record.created_at, "updated_at": record.updated_at}
    out["brief"] = asdict(record.brief) if record.brief else None
    out["survey"] = asdict(record.survey) if record.survey else None
    out["look"] = asdict(record.look) if record.look else None
    out["uncertainties"] = [asdict(u) for u in record.uncertainties]
    out["intake"] = intake_to_json(record.intake)
    out["plan"] = asdict(record.plan) if record.plan else None
    out["trade"] = intake_to_json(record.trade)
    out["handover"] = record.handover
    out["mesh"] = asdict(record.mesh) if record.mesh else None
    return out


def intake_to_json(intake: Intake | None) -> dict[str, Any] | None:
    """One intake, second or third, in the wire form. The resolutions go through their own tagged codec."""
    if intake is None:
        return None
    return {"asked": [asdict(q) for q in intake.asked],
            "resolutions": [resolution_to_json(r) for r in intake.resolutions],
            "turns": intake.turns, "write_up": intake.write_up}


def intake_from_json(raw: Any) -> Intake | None:
    if not raw:
        return None
    asked = tuple(Question(**{**{k: v for k, v in q.items() if k in _names(Question)},
                              "options": tuple(q.get("options") or ())})
                  for q in (raw.get("asked") or []) if isinstance(q, dict))
    return Intake(asked=asked,
                  resolutions=tuple(resolution_from_json(r) for r in (raw.get("resolutions") or [])),
                  turns=raw.get("turns"), write_up=raw.get("write_up") or "")


def uncertainty_from_json(u: dict[str, Any]) -> Uncertainty:
    raw = {k: v for k, v in u.items() if k in _names(Uncertainty)}
    for k in ("places", "options"):
        if isinstance(raw.get(k), list):
            raw[k] = tuple(raw[k])
    return Uncertainty(**raw)


def from_json(payload: dict[str, Any]) -> JobRecord:
    brief = None
    if payload.get("brief"):
        raw = dict(payload["brief"])
        raw["declared"] = tuple(d for d in (raw.get("declared") or ()) if isinstance(d, dict))
        brief = Brief(**{k: v for k, v in raw.items() if k in _names(Brief)})
    survey = None
    if payload.get("survey"):
        raw = dict(payload["survey"])
        raw["openings"] = _openings_from(raw.get("openings"))
        for k in ("bbox_extent", "forecast_basis", "authoritative"):
            if isinstance(raw.get(k), list):
                raw[k] = tuple(raw[k])
        survey = Survey(**{k: v for k, v in raw.items() if k in _names(Survey)})
    look = None
    if payload.get("look"):
        raw = dict(payload["look"])
        raw["openings_seen"] = tuple(SeenOpening(**{k: v for k, v in o.items() if k in _names(SeenOpening)})
                                     for o in (raw.get("openings_seen") or []) if isinstance(o, dict))
        for k in ("attachments", "internal_features"):
            raw[k] = tuple(raw.get(k) or ())
        look = Look(**{k: v for k, v in raw.items() if k in _names(Look)})
    uncertainties = tuple(uncertainty_from_json(u)
                          for u in (payload.get("uncertainties") or []) if isinstance(u, dict))
    intake = intake_from_json(payload.get("intake"))
    trade = intake_from_json(payload.get("trade"))
    plan = None
    if payload.get("plan"):
        raw = dict(payload["plan"])
        raw["used_confirmations"] = tuple(raw.get("used_confirmations") or ())
        plan = Plan(**{k: v for k, v in raw.items() if k in _names(Plan)})
    mesh = Mesh(**{k: v for k, v in payload["mesh"].items() if k in _names(Mesh)}) if payload.get("mesh") else None
    return JobRecord(key=payload["key"], part_key=payload["part_key"], job_id=payload["job_id"],
                     schema=payload.get("schema") or JOB_SCHEMA, provenance=payload.get("provenance") or "live",
                     case=payload.get("case") or "", created_at=payload.get("created_at") or now(),
                     updated_at=payload.get("updated_at") or "", survey=survey, look=look,
                     uncertainties=uncertainties, intake=intake, plan=plan, mesh=mesh, brief=brief,
                     trade=trade, handover=payload.get("handover") or None)


__all__ = ["AUTHORITATIVE_FIELDS", "JOB_SCHEMA", "KINDS", "KIND_ALIASES", "STAGES", "Brief", "Intake", "JobRecord",
           "Look", "MeasuredOpening", "Mesh", "Plan", "Question", "SeenOpening", "Survey", "Uncertainty",
           "canonical_kind", "from_json", "intake_from_json", "intake_to_json", "job_key", "plan_drift",
           "question_id", "to_json", "topic_of", "uncertainty_from_json"]
