"""One bounded loop: model <-> tools until a grounded plan is submitted or a truthful exit is reached.

Loop v3 (dev plan P4.1): a rejected submission is fixed with amend_geometry_plan (JSON-pointer edits to the plan
the model last submitted, re-checked exactly as a submission), the prose guard drops a long text-only turn and
nudges the model back to a tool call, and every tool result says which round of the nominal four this is.

Loop v3b (P4.3, docs/plan_v3_rules.md section 9): the cost of a round, not what a round produces. A turn that made
a single probe is told the calls of one turn run together; a probe the opening message already answered is answered
from that packet (tools.packet_answer) instead of measured again; a rejection after the first carries the hints
that moved, not the same table again, and none of the second look's explanation prose an ok row does not need
(lean_hints); and a turn's deliberation past `max_assistant_chars` does not travel into every later round.

Loop v3c (P4.3, docs/plan_v3_rules.md section 11): the submission accounting. A plan closed off mid-JSON
(`salvage_json`) reaches the checker as a plan short of its tail, and the rejection that comes back is nothing but
the required fields the cut took. That is a serialisation fault, not the model's judgement, so it is counted and
capped on its own (`max_salvage_rejections`) instead of spending one of the three content submissions, it says
which field belongs where and asks for all of them in one amend, and it names where the cut fell.

Loop v3e (P4.3, docs/plan_v3_rules.md section 14): a plan that closed and then closed again is not a cut plan.
45 of the 54 unparseable submissions of the learning-half run were a whole plan followed by one surplus `}`
(`surplus_json`), so the salvage recovered them intact and then told the model its plan had lost its tail. They
are read whole, said so in one line, and never counted as a salvage."""
from __future__ import annotations

import json
import re
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path

from geometry_agent import observe
from geometry_agent.agent import catalog, grounding, prompt, tools
from geometry_agent.agent.client import ModelClient, ModelError
from geometry_agent.agent.schema import AnalysisResult, GeometryPlan
from geometry_agent.agent.tools import SUBMIT, ToolContext

#: The wall-clock budget for one case's reasoning loop, in seconds, and the variable that moves it
#: (`off` removes it). The loop bounded rounds and nothing bounded time: the httpx timeout is per read, so a
#: provider that trickles bytes never trips it, and in the one full 322-case run two cases sat inside a single
#: model call for 9.8 hours each and then exited `submitted`. Over the clean pair of learning-half runs
#: (learning_v3_r1 and r2, 315 scored cases) the median case took 85 s and the p90 125 s; 1200 s is ten times
#: that p90, and over all 1,264 stored live case-runs it is above every case that ever reached an exit of its own
#: (the slowest is 1,020.6 s) and below all eight runaways. docs/eval_protocol.md section 9.
CASE_BUDGET_ENV = "GEOMETRY_AGENT_CASE_BUDGET_S"
DEFAULT_CASE_BUDGET_S = 1200.0


def case_budget_s(env: dict | None = None) -> float | None:
    """The loop's wall-clock budget in force: the default, what the environment says, or None for no budget."""
    return observe.setting(CASE_BUDGET_ENV, DEFAULT_CASE_BUDGET_S, env) or None


class TimeBudgetExceeded(Exception):
    """A model call was still waiting when the case's wall-clock budget ran out."""


def call_with_deadline(client: ModelClient, messages: list[dict], tool_list: list[dict], force_tool: str | None,
                       seconds: float | None):
    """`client.complete(...)`, bounded by the wall clock.

    With no budget the call is made here, on this thread, exactly as it always was. With one it is made on a
    daemon thread and waited for: httpx's timeout is per read, so a provider that answers slowly enough never
    trips it, and waiting on a thread is the only way to stop waiting. The thread is abandoned rather than
    killed, because a blocking socket read cannot be interrupted from outside: it holds one connection until the
    provider answers or the process ends, and whatever it finally returns is discarded."""
    if not seconds or seconds <= 0:
        return client.complete(messages, tool_list, force_tool)
    box: dict = {}

    def work() -> None:
        try:
            box["resp"] = client.complete(messages, tool_list, force_tool)
        except BaseException as exc:  # noqa: BLE001 - re-raised on the calling thread, unchanged
            box["exc"] = exc

    worker = threading.Thread(target=work, name="geometry-agent-model-call", daemon=True)
    worker.start()
    worker.join(seconds)
    if worker.is_alive():
        raise TimeBudgetExceeded(f"the model call was still open after {seconds:.0f}s")
    if "exc" in box:
        raise box["exc"]
    return box["resp"]


@dataclass
class LoopConfig:
    #: The hard stop, sized for the giant-file path (summary plus detail tools); the nominal path is `nominal_rounds`.
    max_rounds: int = 14
    #: Submissions the checker rejected on their content. A rejection that is nothing but the required fields a
    #: salvage lost is not one of these (`max_salvage_rejections`).
    max_grounding_rejections: int = 3
    #: Rejections of a salvaged plan that is still short of its required fields. The serialisation cut the plan, so
    #: the model is not charged a content submission for finishing it, but a salvage that never completes must still
    #: end the run: 2 leaves room for one failed attempt at a completion the live run made in one amend 27 times
    #: out of 27 (docs/plan_v3_rules.md section 11).
    max_salvage_rejections: int = 2
    #: The pre-P4.3d accounting, kept so the measurement can run the same script both ways: every salvage rejection
    #: charged against `max_grounding_rejections` as if the truncation had been the model's judgement.
    charge_salvage_rejections: bool = False
    no_progress_limit: int = 3
    #: A tool result is shortened past this, lists first. 250 compact opening rows fit; a plan needs every one.
    max_tool_result_chars: int = 80_000
    #: Put every measurement in the opening message when it fits, so the first model turn can already probe or
    #: assign roles. Above this size the message carries the summary only and the detail tools do the rest.
    inline_facts_chars: int = 60_000
    #: Every tool result says "round r of nominal_rounds": round 1 probes and list_risks, round 2 the submission,
    #: rounds 3 and 4 amendments. max_rounds stays the hard stop; past the nominal budget the line says so.
    nominal_rounds: int = 4
    #: From this round on, a run that has not submitted yet is told in every tool result to submit with what it has.
    submit_nudge_round: int = 3
    #: From this round on, a run that has not submitted is offered only the tools that write a plan. The nudge is
    #: advice the model can decline: on the cyclone and the bend elbow it declined seventeen of them and probed to
    #: the hard stop with nothing to show. Past the cutoff the probes are withdrawn, so a plan is what comes back.
    #: 9 sits above the p90 of 7 rounds measured over the 322-case run, and leaves five rounds for amendments.
    probe_cutoff_round: int = 9
    #: The prose guard: an assistant turn longer than this with no tool call is dropped and the model is nudged.
    prose_guard_chars: int = 1500
    #: The same number for a turn that did call a tool: the call is executed and kept, and only this much of the
    #: deliberation around it is carried forward, so a 90,000-character amend turn is not resent every round after.
    max_assistant_chars: int = 1500
    #: A rejection after the first carries the hints that moved, not the whole table again (`thin_hints`). Off
    #: measures what the thinning is worth on the same script.
    thin_rejection_hints: bool = True
    #: The wall-clock budget for the whole loop, in seconds; None runs with no deadline. Read from the
    #: environment when the config is made, so a harness sets it once for a run (CASE_BUDGET_ENV).
    wall_budget_s: float | None = field(default_factory=case_budget_s)


#: A string longer than this inside a list entry is prose: a sentence about the entry rather than the entry's
#: identity. Above it the string may be shortened; at or below it nothing is touched.
PROSE_MIN_CHARS = 200
#: What prose is cut back to, tried in turn, before any entry is dropped (R43, docs/plan_v3_rules.md section 24).
PROSE_CAPS = (600, 400, 260, PROSE_MIN_CHARS)
PROSE_CUT = " ... [sentence shortened to fit]"
#: What the result says when an entry had to go after that.
TRUNCATED_NOTE = "lists shortened to fit; ask a narrower tool (get_opening, probe_section) for the rest"


def _shorten_prose(obj: dict, cap: int) -> tuple[dict, int]:
    """Every string over `cap` characters inside a list entry, cut back to `cap`, and how many were cut. The
    entry's short fields (its id, its kind, the ids it names) are never touched: they are what identifies it."""
    out, n = dict(obj), 0
    for k, v in obj.items():
        if not (isinstance(v, list) and len(v) > 1 and all(isinstance(e, dict) for e in v)):
            continue
        rows = []
        for e in v:
            row = dict(e)
            for f, text in e.items():
                if isinstance(text, str) and len(text) > max(cap, PROSE_MIN_CHARS):
                    row[f], n = text[:cap].rstrip() + PROSE_CUT, n + 1
            rows.append(row)
        out[k] = rows
    return out, n


def _clip(obj, limit: int) -> str:
    """Serialise a tool result within `limit` characters and keep it valid JSON: prose inside a list entry is
    shortened first, then whole entries are dropped, largest list first, and `_shortened` and `_truncated` record
    what happened. A result cut mid-string is unreadable to the model and crashes any policy that parses it.

    R43: prose goes before an entry does. An entry dropped from `list_risks` is a risk id the analyst is never
    shown and is then rejected for not deciding (`missing catalog risk`), and there is no narrower tool to ask for
    the rest of that list the way `get_opening` answers for an opening. A sentence shortened costs it nothing it
    has to write: since R34 a catalog risk in a plan is its id and its decision, and `consequence` and
    `recommendation` are the customer's sentences, which `_fill_catalog_risks` writes from the catalog itself.
    Found when the customer-facing rewrite of section 22 took `showerhead_61_hex`'s 68 risks from 75,944
    characters to 109,074 and 21 of them, k47 upward, stopped arriving."""
    s = json.dumps(obj, default=str)
    if len(s) <= limit or not isinstance(obj, dict):
        return s if len(s) <= limit else s[:limit] + f'... [truncated {len(s) - limit} chars; ask for a narrower tool]'
    trimmed = dict(obj)
    for cap in PROSE_CAPS:
        shorter, n = _shorten_prose(obj, cap)
        if not n:
            # nothing in this result is longer than that cap; a smaller one may still have something to cut
            continue
        shorter["_shortened"] = {"strings": n, "to_chars": cap,
                                 "note": "sentences inside the entries were shortened so that every entry is still here; "
                                         "what a plan carries of a catalog risk is its id and your decision, and the "
                                         "checker writes the rest from the catalog"}
        trimmed = shorter
        s = json.dumps(trimmed, default=str)
        if len(s) <= limit:
            return s
    dropped: dict[str, int] = {}
    keys = sorted((k for k, v in trimmed.items() if isinstance(v, list) and len(v) > 1),
                  key=lambda k: -len(json.dumps(trimmed[k], default=str)))
    for k in keys:
        lst = trimmed[k]

        def fits(n: int, k=k, lst=lst) -> bool:
            # the note is measured too: the final serialisation carries it, and a fit that leaves no room for it
            # falls through to the scalars-only branch and loses the list entirely
            trunc = {**dropped, k: len(lst) - n, "note": TRUNCATED_NOTE} if n < len(lst) else dict(dropped)
            return len(json.dumps({**trimmed, k: lst[:n], **({"_truncated": trunc} if trunc else {})}, default=str)) <= limit
        # the most entries that fit, by bisection. A prefix only grows, so this is monotonic, and the geometric
        # backoff this replaced (keep *= 0.7) landed on a step of the ladder rather than on the answer: on the
        # 156-risk `real_parts_on_disk__hybrid_engine` it kept 76 either way, shortening the prose first or not
        keep = len(lst)
        if not fits(keep):
            lo, hi = 1, len(lst)
            while lo < hi:
                mid = (lo + hi + 1) // 2
                lo, hi = (mid, hi) if fits(mid) else (lo, mid - 1)
            keep = lo
        if keep < len(lst):
            dropped[k] = len(lst) - keep
            trimmed[k] = lst[:keep]
        if len(json.dumps({**trimmed, "_truncated": {**dropped, "note": TRUNCATED_NOTE}}, default=str)) <= limit:
            break
    if dropped:
        trimmed["_truncated"] = {**dropped, "note": TRUNCATED_NOTE}
    s = json.dumps(trimmed, default=str)
    if len(s) <= limit:
        return s
    # still too large after every list was cut to one entry: keep the small scalar fields, name what was dropped,
    # and stay valid JSON (a result cut mid-string is unreadable to the model and crashes any policy that parses it)
    small = {k: v for k, v in trimmed.items() if not isinstance(v, (list, dict)) and len(json.dumps(v, default=str)) < 200}
    small["_truncated"] = {"note": f"result of {len(s):,} characters exceeds the {limit:,} limit; ask a narrower tool",
                          "dropped_keys": [k for k in trimmed if k not in small]}
    s = json.dumps(small, default=str)
    return s if len(s) <= limit else json.dumps({"_truncated": {"note": "result too large; ask a narrower tool"}})


def _sig(name: str, args: dict) -> str:
    return name + ":" + json.dumps(args, sort_keys=True, default=str)


#: The one sentence of the opening message (prompt v3): it names the identity hypotheses the first turn opens
#: with and the two lists the plan carries, and nothing else; the tool schemas describe the tools.
INLINE_NOTE = ("The measurements below are what the tools would return, so do not re-fetch them: open with two or three "
               "identity hypotheses, each with its refuting test, and submit one plan whose simulation_warnings are for "
               "the user and whose mesh_warnings are for the builder.")
SUMMARY_ONLY_NOTE = ("The summary below was measured by code and the detail tools hold the rest: open with two or three "
                     "identity hypotheses, each with its refuting test, and submit one plan whose simulation_warnings are "
                     "for the user and whose mesh_warnings are for the builder.")


def attach_memory(ctx: ToolContext) -> dict | None:
    """The memory block for this part, or None (dev plan P7).

    The provider on the context decides: off, no index or nothing similar enough all return None, and silence is
    the common answer for an unusual part. What comes back is kept on the context for the trace and its numbers
    go into `ctx.memory_numbers`, never into `ctx.ledger.numbers`: they are measurements of other parts, so they
    stay untraceable and the checker refuses any that reaches the plan.
    """
    provider = getattr(ctx, "memory", None)
    if provider is None:
        return None
    try:
        block = provider.block_for(ctx)
    except Exception:  # noqa: BLE001 - memory is an extra; a run never fails because it could not remember
        return None
    if not block or not block.get("text"):
        return None
    ctx.memory_block = block
    ctx.memory_numbers = {float(v) for v in block.get("numbers", ())}
    return block


#: The share of the case's wall-clock budget the opening look may spend. A look that has not answered in a
#: quarter of the case's time is not going to save the case: the run goes on without it and the message says so.
#: With no case budget there is no bound here either, which is the rule the model call already follows.
LOOK_BUDGET_SHARE = 0.25
LOOK_TIMED_OUT = "the look was still open after {seconds:.0f}s of the case's budget and was abandoned"


def attach_look(ctx: ToolContext, seconds: float | None = None) -> dict | None:
    """The look the run opens with, or None when no vision model is attached (dev plan P9).

    The tool was offered on 159 of 159 cases of the last learning-half run and called on none of them, because
    every corpus brief opens by saying what the part is, so identity was never in doubt and the round was never
    worth spending. A customer does not write that sentence. So the look is not offered here, it is taken: once,
    as the run starts, before the first message is built, and what it saw rides in that message beside the
    measurements. It costs the analyst no round at all, and `look_at_views` stays in the tool list for the
    follow-up a standing description cannot answer.

    Nothing here can end a run. A provider that fails, a file this machine cannot render, a part with no
    openings and a look that outlives `seconds` all come back as a result the message reports in one line; only
    a missing vision client is silent, and then the message is byte for byte what it is without vision."""
    if getattr(ctx, "vision", None) is None:
        return None
    if not seconds or seconds <= 0:
        return tools.look_at_views(ctx)
    box: dict = {}

    def work() -> None:
        try:
            box["result"] = tools.look_at_views(ctx)
        except BaseException as exc:  # noqa: BLE001 - a look never ends a case, whatever it raises
            box["exc"] = exc

    worker = threading.Thread(target=work, name="geometry-agent-look", daemon=True)
    worker.start()
    worker.join(seconds)
    if worker.is_alive():
        observe.warning("look.deadline", seconds=seconds)
        return tools.look_abandoned(ctx, LOOK_TIMED_OUT.format(seconds=seconds))
    if "exc" in box:
        exc = box["exc"]
        return tools.look_abandoned(ctx, f"{type(exc).__name__}: {str(exc)[:200]}")
    return box["result"]


def look_block(result: dict) -> str:
    """What the opening message says about the look: the impression under its own heading with its rule, or one
    line naming why there is none. The analyst is told either way, so a failed look does not cost it a round to
    discover."""
    from geometry_agent.vision import prompt as vprompt
    if result.get("error"):
        return vprompt.failed_block(result["error"])
    impression = result.get("impression") or {}
    # THE PROMPT THE LOOK WAS TAKEN WITH (work/z-vision NEEDS 3): a line is printed only for a field that prompt
    # asked, so a per-part prompt that dropped a field is not printed as having searched for it. And the
    # impression is the model-safe one (`tools.look_at_views`), so a recorded field is absent and prints nothing
    text = vprompt.impression_block(impression, views=len(result.get("views") or ()) or 9,
                                    model=result.get("model"), provider=result.get("provider"),
                                    system=result.get("system"))
    if result.get("render_warning"):
        text += f"\nrender warning: {result['render_warning']}"
    return text + "\n" + vprompt.VISION_RULE.format(cap=f"{grounding.VISION_ONLY_CONFIDENCE_MAX:g}")


@dataclass(frozen=True)
class ChainGiven:
    """What the chain hands the geometry agent: the survey's facts and the customer's confirmations, resolved.

    REHAAN'S RULE: the geometry agent decides what to DO, where the cells go and which flow patches to cut where
    nobody has spoken. It must NEVER re-decide what the geometry IS. On the chain path (`chain/job.py`) the loop
    therefore takes three things it did not take before, and a run with no `ChainGiven` is byte for byte the run
    it always was:

      representation  the survey's, resolved once with the brief. The loop's own tools and checker recompute it
                      from the context in fifteen places (`catalog.representation(ctx.facts, ctx.purpose,
                      ctx.brief, declared=ctx.declared)`), so the loop REFUSES to start when the context it was
                      handed reads the part differently from the survey. It is the one check that closes every
                      one of those sites at once without editing them.
      text            the block appended to the opening message: what was measured and may not be re-decided,
                      what the customer confirmed, what the brief states, and what is only a default.
      check           `contract.given.check_plan` over the submitted plan. A plan the grounding checker accepted
                      and this refuses is sent back like any rejection, counted like one, and named as its own
                      kind (`GIVEN_KIND`) so the trace says which boundary refused it.
    """
    representation: str
    text: str
    check: Callable[[dict], list[str]]


#: The rejection kind a `ChainGiven` refusal carries in the trace and in the tool result.
GIVEN_KIND = "given"
GIVEN_INSTRUCTION = ("the survey measured what the part IS and the customer confirmed what they said; the plan may "
                     "decide what to do about both and may not contradict either. Amend the paths named in the "
                     "errors so the plan agrees with the GIVEN block, then submit again.")
GIVEN_REFUSED = ("the loop's context reads this part as {got!r} and the survey measured {want!r}: the chain resolves "
                 "the representation once, with the brief, and the geometry agent does not re-decide it. No model "
                 "was called.")


def given_mismatch(ctx: ToolContext, given: ChainGiven | None) -> str | None:
    """Why the context disagrees with the survey about what the part is, or None when it agrees."""
    if given is None:
        return None
    got = str(catalog.representation(ctx.facts, ctx.purpose, ctx.brief, declared=ctx.declared,
                                     fluid_side=ctx.fluid_side))
    if got != given.representation:
        return GIVEN_REFUSED.format(got=got, want=given.representation)
    return None


def builder_keys(ctx: ToolContext) -> str:
    """The request's `BUILDER KEYS` row for this case: the keys a renderer consumes on the regime this part runs
    under, from `catalog.DIRECTIVE_KEYS`.

    The regime is read exactly as the checker reads it (`grounding._channel_of`): the engine off the brief and the
    purpose, the representation off the facts. Both are settled before the first turn, so the legal set is in
    front of the model where it decides instead of being discovered from a rejection. It rides here rather than in
    the system prompt because there is no one row: the system prompt named two of snappy_internal's seven keys and
    none of snappy_external's six, and 24% of the draws in the 176-draw run ended with no plan, almost all of them
    on a target the renderer cannot read."""
    from geometry_agent.agent import catalog, tools
    rep = catalog.representation(ctx.facts, ctx.purpose, ctx.brief, declared=ctx.declared, fluid_side=ctx.fluid_side)
    regime = catalog.regime_of(catalog.engine_from_brief(ctx.brief, ctx.purpose), rep)
    return prompt.builder_keys_block(regime, tools.PLATFORM_SHA)


def opening_messages(ctx: ToolContext, cfg: LoopConfig, given: ChainGiven | None = None) -> list[dict]:
    """System prompt plus the user's request with the measurements attached. Every number in the attachment is
    recorded in the ledger exactly as a tool result would be, so the plan may cite it.

    A memory block, when there is one, is appended after the measurements with its rule: it is the one part of
    the message whose numbers are not in the ledger and may not be cited. The look at the part is appended after
    that, under its own heading and its own rule, and its numbers are not in the ledger either: there are none
    left in it to be."""
    packet = tools.facts_packet(ctx)
    text = json.dumps(packet, default=str)
    if len(text) > cfg.inline_facts_chars:
        packet = tools.get_facts_summary(ctx)
        text = json.dumps(packet, default=str)
        inline_note = SUMMARY_ONLY_NOTE
        # only the summary reached the model, so only a summary probe may be answered from the packet; the detail
        # tools have to measure for real, which is the whole point of the summary-only path
        ctx.packet_answers = {k: v for k, v in ctx.packet_answers.items() if k == "get_facts_summary"}
        # and the ledger's call log says the same: a reading the model never saw is not a test it has run
        tools.keep_packet_calls(ctx, ctx.packet_answers)
    else:
        inline_note = INLINE_NOTE
    ctx.ledger.record(tools._round(packet))
    ctx.ledger.calls.append("facts_packet")
    user = (prompt.user_prompt(ctx.purpose, ctx.brief, ctx.fidelity, ctx.cell_cap, ctx.declared)
            + "\n\n" + builder_keys(ctx)
            + "\n\n" + inline_note + "\n\nMEASUREMENTS:\n" + text)
    block = attach_memory(ctx)
    if block is not None:
        user += "\n\n" + block["text"] + "\n" + prompt.MEMORY_RULE
    look = attach_look(ctx, (cfg.wall_budget_s or 0.0) * LOOK_BUDGET_SHARE or None)
    if look is not None:
        user += "\n\n" + look_block(look)
    if given is not None and given.text:
        user += "\n\n" + given.text
    return [
        {"role": "system", "content": prompt.system_prompt()},
        {"role": "user", "content": user},
    ]


TRUNCATED_NUDGE = ("Your previous turn hit the output limit before any tool call was made and its content was "
                   "discarded. Keep deliberation short and act: call the next tool now, or submit_geometry_plan.")
PROSE_NUDGE = ("Your previous turn was prose with no tool call and was discarded. Write at most 150 words between "
               "tool calls and put your reasoning in the plan's structured fields (analysis, evidence, derivation, "
               "reason). Call a tool now: the next probe, list_risks with your roles, submit_geometry_plan, or "
               "amend_geometry_plan after a rejection.")
IDLE_NUDGE = "Continue with a tool call. Submit with submit_geometry_plan when the plan is grounded."
SUBMIT_NUDGE = "submit with what you have now"
#: What the round line says once the measurement tools have been withdrawn (`LoopConfig.probe_cutoff_round`).
PROBES_CLOSED = "the measurement tools are closed for this run; submit the plan with what you have"
#: What a measurement call gets back once they are closed. The model may still emit one: the calls are in its own
#: history, and neither withdrawing the schema nor naming the tool in `tool_choice` binds every provider.
PROBES_CLOSED_ERROR = ("{name} is closed for this run: the measurement budget is spent and every number you need is "
                       "already in the packet, the ledger and the risks. Call submit_geometry_plan now with the plan "
                       "you have; the checker will fill what it can and tell you what to amend.")
#: A turn that made one probe and nothing else spent a whole round on it. The tool calls of one turn are executed
#: together, so the rest of the round-1 work fits in the same turn: this is the clause that says so.
PARALLEL_NUDGE = "send the remaining probes and list_risks with your roles together in one turn"
PARALLEL_NUDGE_AFTER_RISKS = "send the remaining probes together in one turn"
ROLES_FIRST = "call list_risks with your assigned roles before submitting"
NOTHING_TO_AMEND = ("nothing to amend: no plan has been submitted in this run; call submit_geometry_plan with the "
                    "full plan first")
#: What a turn's deliberation is replaced by once it is over `max_assistant_chars` and its tool call has run.
TRIMMED_NOTE = " ... [{n:,} more characters of this turn's text are not carried forward; its tool call was executed]"


def round_line(rnd: int, cfg: LoopConfig, submitted: bool, one_probe: bool = False, risks_done: bool = False,
               probes_closed: bool = False) -> str:
    """The "round r of N" line every tool result carries, with the submit nudge once the run is at
    `submit_nudge_round` without a submission, the parallel nudge on a turn that made a single probe before the
    plan was submitted, and a note once the nominal budget is spent. At most one clause: a run that should be
    submitting is not told to go on probing."""
    line = f"round {rnd} of {cfg.nominal_rounds}"
    if rnd > cfg.nominal_rounds:
        line += f" (past the nominal budget; hard stop at round {cfg.max_rounds})"
    if probes_closed and not submitted:
        line += "; " + PROBES_CLOSED
    elif rnd >= cfg.submit_nudge_round and not submitted:
        line += "; " + SUBMIT_NUDGE
    elif one_probe and not submitted:
        line += "; " + (PARALLEL_NUDGE_AFTER_RISKS if risks_done else PARALLEL_NUDGE)
    return line


#: The rejection hints that repeat verbatim from one rejection to the next: the checker's recomputed second look,
#: the repairs it logged, the catalog risks the plan is missing. An amend fixes a pointer, not the whole plan, so
#: its rejection should carry what changed, not the same table again.
THINNED_HINTS = ("second_look", "warnings", "missing_catalog_risks", "stale_catalog_risks", "note")
UNCHANGED_KEY = "unchanged_since_the_last_rejection"
#: The second look's two explanation fields (grounding._second_look_table, P4.3b R19 and R24). `why` is the clause
#: R19's own log line quotes back when it repairs a cautious no, and `fix` is the sentence R10's rejection message
#: already carries for the row it rejects. On a row the checker computes as ok neither is news, and the whole table
#: rides in every rejection and is resent every round after it: on the pipe they are 1,484 of the table's 2,348
#: characters. They stay in `hints` for the ledger and the trace; only the copy the model gets drops them.
SECOND_LOOK_PROSE = ("why", "fix")


def lean_hints(hints: dict) -> dict:
    """The hints as the model gets them: the second look without the explanation fields of a row that is already
    ok (`fix` stays on a row that is not, which is the row the model has to act on)."""
    rows = hints.get("second_look")
    if not isinstance(rows, list):
        return dict(hints)
    lean = [{k: v for k, v in r.items() if k not in SECOND_LOOK_PROSE or (k == "fix" and v and not r.get("ok"))}
            if isinstance(r, dict) else r for r in rows]
    return {**hints, "second_look": lean}


def thin_hints(hints: dict, last: dict) -> dict:
    """The hints of a rejection after the first, carrying only what moved since the one before it. `second_look`
    is diffed row by row (matched on `item`); the other hints are dropped whole when they are identical. What was
    left out is named in `unchanged_since_the_last_rejection`, so nothing goes missing silently."""
    if not last:
        return dict(hints)
    out = dict(hints)
    omitted: list[str] = []
    rows, prev = out.get("second_look"), last.get("second_look")
    if isinstance(rows, list) and isinstance(prev, list) and prev:
        seen = {r.get("item"): r for r in prev if isinstance(r, dict)}
        changed = [r for r in rows if not (isinstance(r, dict) and seen.get(r.get("item")) == r)]
        if len(changed) < len(rows):
            omitted.append(f"second_look: {len(rows) - len(changed)} of {len(rows)} rows")
            if changed:
                out["second_look"] = changed
            else:
                out.pop("second_look")
    for key in THINNED_HINTS:
        if key != "second_look" and key in out and key in last and out[key] == last[key]:
            out.pop(key)
            omitted.append(key)
    if omitted:
        out[UNCHANGED_KEY] = omitted
    return out


MALFORMED = "arguments were not valid JSON; nothing was executed"
#: Prepended to the errors of a plan that had to be closed off before it could be read (`salvage_json`). The model
#: is told what was lost and to add it back by pointer, which is a few hundred characters rather than another
#: whole plan: resubmitting is what cost the cyclone ten rounds.
SALVAGED_NOTE = ("your plan ended mid-JSON and was closed off at the last complete value, so anything after that "
                 "point is missing. Do not resubmit the whole plan: add what is missing with amend_geometry_plan.")
#: Appended to that note: where the cut fell. A field the cut landed inside is still there and still parses, so the
#: checker cannot ask for it back: bend_elbow_029_fluid's plan kept an empty patches list, the rejection named the
#: five fields that had vanished, the amend added those five, and the openings-without-a-patch arrived a submission
#: later. The pointer says which field to look at.
SALVAGED_TAIL = (" The last value that survived is {tail}, so that is where the cut fell: check that field for "
                 "entries it lost, because a list cut to nothing still parses.")
#: What the result calls a rejection, so the run says which kind each one was: a serialisation fault that is not
#: charged, or the checker on the plan's content.
SALVAGE_KIND = "salvage_incomplete"
CHECKER_KIND = "checker"
#: The exit of a salvage that never completed. `AnalysisResult.exit` has no literal of its own for it (the schema is
#: not this change's to edit), so the exit stays grounding_rejected and the reason says what actually happened.
SALVAGE_EXIT = ("{n} salvaged submissions still short of required plan fields ({fields}); the plan was never "
                "completed, so there is nothing to hand over")
#: What the accepted run's reason adds when a salvage was completed: the submission the model was not charged for.
SALVAGE_NOTE_DONE = " ({n} salvaged submission(s) not charged: the serialisation lost the plan's tail)"
#: Appended to an amend's edit errors while the plan is still short of the fields the cut took: the path failed
#: because the field it points into is not there yet.
STILL_MISSING = (" The plan is still missing {fields}, so a path inside one of them does not exist yet: set each "
                 "whole field in this same call.")
#: What a rejected plan is told when its arguments were a whole plan followed by surplus closing brackets (P4.3e).
#: It is one line, because nothing was lost and there is nothing to add back: the plan was read exactly as written.
SURPLUS_NOTE = ("your arguments closed the plan and then wrote {n} surplus closing bracket(s); the plan itself was "
                "whole and was read exactly as you wrote it. Stop at the bracket that closes `plan`.")
#: A submission whose arguments were cut off mid-JSON is the output limit, not a typo: retyping the same plan
#: costs the same round again, so the message says which end to cut.
#: What a plan that will not parse gets back when not even its prefix can be read. It quotes the parser, because
#: the old message blamed the output limit and the cyclone's 18,235 characters were not truncated at all: they
#: carried `"target": {"sphere at the cone wall, radius one bore"}`, an object holding a bare string with no key,
#: and the model spent nine rounds shortening a plan whose length was never the problem.
MALFORMED_TRUNCATED = (MALFORMED + ". Of the {n:,} characters sent, the parser stopped at character {pos:,}: {msg}. "
                       "Near there you wrote: {near}. Fix that one field and send it again, or fix the last "
                       "rejection with amend_geometry_plan instead of resubmitting the whole plan.")


def _malformed_error(raw) -> str:
    text = raw if isinstance(raw, str) else ""
    if len(text) > 1000 and text.lstrip().startswith(("{", "[")):
        try:
            json.loads(text)
        except json.JSONDecodeError as exc:
            near = " ".join(text[max(0, exc.pos - 70):exc.pos + 30].split())
            return MALFORMED_TRUNCATED.format(n=len(text), pos=exc.pos, msg=exc.msg, near=f"...{near}...")
    return MALFORMED


#: A member whose key was written and whose value never came: the cut has to retreat past it.
DANGLING_KEY = re.compile(r',?\s*"[A-Za-z0-9_.-]*"\s*:?$')


def salvage_json(text: str, max_retreats: int = 6) -> dict | None:
    """The largest valid prefix of a JSON object that will not parse, closed off, or None.

    A live run lost ten rounds to this. The cyclone's plan came back at 18,235 characters and would not parse,
    and the loop's answer was "invalid JSON, nothing was executed", so the model rewrote the whole plan, nine
    times, a few hundred characters shorter each round, and never got under the wire. The break was one field:
    `"target": {"sphere at the cone wall, radius one bore"}`, an object holding a bare string with no key. Every
    one of the 9,394 characters before it was a good plan, and the checker could have said what was wrong with
    the rest far more usefully than the parser did.

    So the parser's own error position is used to retreat: scan once, remembering every point where a value
    finished and what was open there, then cut at the last such point before the break, close the open strings,
    arrays and objects, and parse. If the shortened text breaks again further back, repeat, up to `max_retreats`
    times. What comes back is a partial plan the checker rejects by pointer, which the model fixes with an amend
    instead of another eighteen thousand characters."""
    text = (text or "").strip()
    if not text.startswith("{"):
        return None
    try:
        whole = json.loads(text)
        return whole if isinstance(whole, dict) and whole else None
    except json.JSONDecodeError as first:
        broke_at = first.pos
    marks: list[tuple[int, tuple[str, ...]]] = []
    stack: list[str] = []
    in_string = escaped = False
    for i, ch in enumerate(text):
        if in_string:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == '"':
                in_string = False
                marks.append((i + 1, tuple(stack)))
            continue
        if ch == '"':
            in_string = True
        elif ch in "{[":
            stack.append("}" if ch == "{" else "]")
        elif ch in "}]":
            if not stack:
                break
            stack.pop()
            marks.append((i + 1, tuple(stack)))
        elif ch == ",":
            marks.append((i, tuple(stack)))
        elif ch.isdigit() or ch in "eE.+-truefalsn":
            marks.append((i + 1, tuple(stack)))
    for _ in range(max_retreats):
        usable = [m for m in marks if m[0] < broke_at]
        if not usable:
            return None
        cut, open_at = usable[-1]
        head = DANGLING_KEY.sub("", text[:cut].rstrip().rstrip(",").rstrip())
        if not head or head == "{":
            return None
        try:
            out = json.loads(head + "".join(reversed(open_at)))
        except json.JSONDecodeError as again:
            broke_at = min(cut, again.pos)
            continue
        return out if isinstance(out, dict) and out else None
    return None


#: What the arguments of a plan call turned out to be: read whole, read whole once surplus closing brackets were
#: dropped (nothing lost), or recovered from the largest valid prefix of a submission that ended mid-JSON.
WHOLE, SURPLUS, SALVAGED = "whole", "surplus", "salvaged"
#: The characters that may follow a complete plan and still leave it complete: closing brackets the model wrote
#: one too many of, and the whitespace and commas between them.
SURPLUS_CHARS = "}] \t\r\n,"


def surplus_json(text: str) -> tuple[dict | None, int]:
    """The object a text holds when it is a complete JSON object followed by nothing but surplus closing brackets,
    with how many of them there were; `(None, 0)` otherwise.

    This is not a truncation and it must not be called one. 45 of the 54 unparseable submissions of the live
    learning-half run (learning_v3_r2) were a whole plan followed by one `}` too many, the same fault every time
    at temperature 0. The salvage recovered every one of them intact, and then told the model its plan "ended
    mid-JSON ... anything after that point is missing" and pointed it at a field that had lost nothing."""
    raw = (text if isinstance(text, str) else "").strip()
    if not raw.startswith("{"):
        return None, 0
    try:
        json.loads(raw)
    except json.JSONDecodeError as exc:
        if exc.msg != "Extra data":
            return None, 0
        head, rest = raw[:exc.pos], raw[exc.pos:]
        if not rest.strip() or rest.strip(SURPLUS_CHARS):
            return None, 0
        try:
            obj = json.loads(head)
        except json.JSONDecodeError:
            return None, 0
        return (obj, len(rest.strip())) if isinstance(obj, dict) and obj else (None, 0)
    return None, 0


def read_plan_arguments(text: str) -> tuple[dict | None, str, int]:
    """The arguments of a plan call that would not parse, as `(object, kind, surplus)`: SURPLUS when only
    closing brackets had to go and the plan is whole, SALVAGED when the text ended mid-JSON and the largest valid
    prefix was closed off, `(None, "", 0)` when nothing can be read. The caller charges and words the two
    differently, because one lost nothing and the other lost its tail."""
    obj, n = surplus_json(text)
    if obj is not None:
        return obj, SURPLUS, n
    obj = salvage_json(text)
    return (obj, SALVAGED, 0) if obj is not None else (None, "", 0)


def salvage_tail(obj) -> str:
    """The JSON pointer of the last value a salvaged object holds: where the text ran out.

    The cut takes everything after it, but the value it landed inside is kept as far as it got, so a list it
    emptied parses and no "Field required" line can name it. This pointer is the one thing the rejection can say
    about that half of the loss."""
    path = ""
    node = obj
    for _ in range(24):  # the plan nests six deep at most; the bound is only against a cycle
        if isinstance(node, dict) and node:
            key = list(node)[-1]
            path, node = f"{path}/{key}", node[key]
        elif isinstance(node, list) and node:
            path, node = f"{path}/{len(node) - 1}", node[-1]
        else:
            return path
    return path


def assistant_message(resp, cfg: LoopConfig) -> dict:
    """The turn as it goes into the conversation. A turn that called a tool is kept whatever it says, but only
    `max_assistant_chars` of its text travels on: the call carries the result, and the deliberation around it
    would otherwise be resent in full on every later round (one smoke-test amend turn wrote 88,847 characters)."""
    msg = resp.to_message()
    content = msg.get("content") or ""
    if resp.tool_calls and len(content) > cfg.max_assistant_chars:
        msg["content"] = content[:cfg.max_assistant_chars] + TRIMMED_NOTE.format(n=len(content) - cfg.max_assistant_chars)
    return msg


def merge_stray_plan_fields(args: dict) -> tuple[dict, list[str]]:
    """A submission whose plan closed one field early: the fields that fell out of it are siblings of `plan` in
    the arguments, and they belong inside it. Returns the repaired arguments and the names moved.

    submit_geometry_plan takes one argument, so a top-level key that names a field of the plan and nothing the
    tool asks for is a field of the plan: bend_elbow_011 and volute_scroll_010 each closed `plan` after `risks`
    and wrote six more fields beside it, and each was rejected for six required fields it had written. Nothing is
    overwritten: a key the plan already carries stays as the plan wrote it."""
    if not isinstance(args, dict) or not isinstance(args.get("plan"), dict):
        return args, []
    plan = args["plan"]
    moved = [k for k in args if k != "plan" and k in GeometryPlan.model_fields and k not in plan]
    if not moved:
        return args, []
    return {**args, "plan": {**plan, **{k: args[k] for k in moved}}}, moved


#: What a submission is told when the fields that fell out of its plan were put back into it.
STRAY_FIELDS_NOTE = ("your plan closed before {fields}, so {n} field(s) you wrote arrived beside `plan` instead of "
                     "inside it and were put back. Nothing was lost; close `plan` once, at the end.")


def _plan_for_call(ctx: ToolContext, name: str, args: dict) -> tuple[dict | None, list[str], bool]:
    """The plan object a submit or amend call asks the checker to judge: (plan, errors, counts_as_rejection).
    A submit carries the whole plan; an amend applies its edits to the plan the model last submitted. An amend
    whose edits name a path the plan does not have is a rejection naming that pointer with nothing applied; an
    amend before any submission is a refusal, not a rejection."""
    if name == SUBMIT:
        plan_obj = args.get("plan")
        if not isinstance(plan_obj, dict):
            return None, ["plan must be an object"], False
        return plan_obj, [], False
    if ctx.last_plan is None:
        return None, [NOTHING_TO_AMEND], False
    plan_obj, errors = tools.apply_plan_edits(ctx.last_plan, args.get("edits"))
    if errors:
        return None, errors, True
    return plan_obj, [], False


#: What a run that spent its wall-clock budget says. It is not `budget_exhausted`: that one means the rounds ran
#: out, and the two failures need different answers (more rounds against a slower provider or a bigger file).
TIME_EXIT_BEFORE = ("the case's wall-clock budget of {budget:.0f}s was spent after {spent:.0f}s and "
                    "{rounds} round(s); no plan was submitted")
TIME_EXIT_INSIDE = ("the case's wall-clock budget of {budget:.0f}s was spent waiting for the model in round "
                    "{rnd} ({spent:.0f}s in); no plan was submitted")


#: What a run says when the agent itself broke. It names the fault, where it broke and the round, because the
#: caller has no transcript and the platform's own log line ("no plan for this submission") never said which.
AGENT_FAILED = ("the geometry agent broke in round {rnd} and submitted no plan: {why} (at {where}). This is a "
                "fault in OUR code rather than a refusal or a model error the client could name, and the frame "
                "says where: no plan was made and nothing about this part was decided")


def run_loop(client: ModelClient, ctx: ToolContext, cfg: LoopConfig | None = None, *,
             given: ChainGiven | None = None) -> AnalysisResult:
    """The model loop, as an `AnalysisResult` in every case. NEVER RAISES.

    EVERY EXIT IS TRUTHFUL AND A CRASH IS NOT AN EXIT (non-negotiable 5). Until this net existed, an exception
    anywhere in the loop - a tool, the checker, the reader of a provider's answer - left through here, through
    `chain.job.plan`, and into `application/geometry_step.plan_the_part`, which caught everything, logged one
    warning and handed the builder a job with no plan in it. Three separate faults were fixed one at a time
    inside `agent/client.py` for exactly this reason (see its own comments at `_as_text`, `_post` and
    `retry_after_seconds`: each "ended the case as a crash" because this function caught `ModelError` only).
    The class is closed here: an unexpected fault is `exit="agent_failed"` with the reason, and every caller
    already branches on `plan is None`.

    It is NOT a catch that lets a broken agent look like a working one. `ok` is False, the exit is its own word,
    `observe.warning` records it under `run.crashed`, and `KeyboardInterrupt` and `SystemExit` are not caught
    because neither is a fault of ours.

    The round and the tool calls are kept; `grounding_rejections` is 0 on this exit because the count lives
    inside the loop and nothing out here can read it. The reason is what a reader acts on: the fault, the frame
    and the round.
    """
    at: dict[str, int] = {"round": 0}
    try:
        return _run_loop(client, ctx, cfg, given, at)
    except Exception as exc:  # noqa: BLE001 - the net: a fault in the agent is an exit, not the caller's problem
        last = exc.__traceback__
        while last is not None and last.tb_next is not None:
            last = last.tb_next
        where = (f"{Path(last.tb_frame.f_code.co_filename).name}:{last.tb_lineno} "
                 f"in {last.tb_frame.f_code.co_name}") if last is not None else "an unknown frame"
        observe.warning("run.crashed", error=type(exc).__name__, round=at["round"], where=where)
        return AnalysisResult(ok=False, exit="agent_failed", plan=None,
                              reason=AGENT_FAILED.format(rnd=at["round"], where=where,
                                                         why=f"{type(exc).__name__}: {str(exc)[:200]}"),
                              rounds=at["round"], tool_calls=len(ctx.ledger.calls), grounding_rejections=0)


def _run_loop(client: ModelClient, ctx: ToolContext, cfg: LoopConfig | None, given: ChainGiven | None,
              at: dict[str, int]) -> AnalysisResult:
    cfg = cfg or LoopConfig()
    started = time.perf_counter()
    deadline = started + cfg.wall_budget_s if cfg.wall_budget_s else None
    if given is not None:
        # the chain is attached: the budget is the third intake's, costed on the builder emulator, and the
        # refinement-ball estimate stands down in the tools and the checker (tools.ToolContext.chain_attached)
        ctx.chain_attached = True
    refused = given_mismatch(ctx, given)
    if refused is not None:
        observe.warning("run.refused", why="given")
        return AnalysisResult(ok=False, exit="refused", plan=None, reason=refused, rounds=0, tool_calls=0,
                              grounding_rejections=0)
    # what the run was configured to do, and nothing measured from the part: an opening count is the customer's
    # geometry, and a log line is the wrong place for it
    observe.info("run.start", purpose=ctx.purpose, max_rounds=cfg.max_rounds, wall_budget_s=cfg.wall_budget_s,
                 vision="offered" if ctx.vision is not None else "off")
    messages = opening_messages(ctx, cfg, given)
    trace: list[dict] = []
    if ctx.memory_block is not None:
        # round 0: what memory showed, without its text (the text is in the opening message the recording keeps).
        # The ingester reads this to say which neighbours a plan was written beside.
        block = ctx.memory_block
        trace.append({"round": 0, "memory": {k: block.get(k) for k in
                                             ("mode", "neighbours", "paired", "index_sha256", "distance_cap",
                                              "candidates_inside_cap", "n_neighbours")},
                      "memory_numbers": len(ctx.memory_numbers)})
    if ctx.vision is not None:
        # round 0: that the run looked, and what came back. A reader of the result should never have to guess
        # whether a look happened, which is the whole complaint section 9.5 of the eval protocol records.
        opening = tools.opening_look(ctx)
        trace.append({"round": 0, "vision": {"looked": not opening.get("error"), "error": opening.get("error"),
                                             "model": opening.get("model"), "provider": opening.get("provider"),
                                             "views": len(opening.get("views") or ()),
                                             "looks_like": (opening.get("impression") or {}).get("looks_like"),
                                             "confidence": (opening.get("impression") or {}).get("confidence")}})
    tool_calls = 0
    rejections = 0
    #: Rejections that were nothing but the required fields a salvaged plan lost, and the pointers of the ones the
    #: plan on the context is still short of (so an amend into one of them is told why its path is not there).
    salvage_rejections = 0
    salvage_missing: list[str] = []
    prose_hits = 0
    refused_after_cutoff = 0
    last_sigs: list[str] = []
    idle_rounds = 0
    risks_with_roles_called = False
    submitted = False
    last_hints: dict = {}

    def guard_note() -> str:
        note = f" ({prose_hits} prose turn(s) dropped by the guard)" if prose_hits else ""
        if salvage_rejections and not cfg.charge_salvage_rejections:
            note += SALVAGE_NOTE_DONE.format(n=salvage_rejections)
        return note

    def done(ok: bool, exit: str, plan: GeometryPlan | None, reason: str, rnd: int) -> AnalysisResult:
        observe.info("run.end", exit=exit, rounds=rnd, tool_calls=tool_calls, rejections=rejections,
                     vision_calls=ctx.vision_calls, seconds=time.perf_counter() - started)
        return AnalysisResult(ok=ok, exit=exit, plan=plan, reason=reason + guard_note(), rounds=rnd,
                              tool_calls=tool_calls, grounding_rejections=rejections, trace=trace)

    for rnd in range(1, cfg.max_rounds + 1):
        # the one thing the net outside this function cannot see for itself: which round was open when a fault hit
        at["round"] = rnd
        left = None if deadline is None else deadline - time.perf_counter()
        if left is not None and left <= 0:
            spent = time.perf_counter() - started
            observe.warning("run.deadline", where="between rounds", round=rnd, seconds=spent)
            return done(False, "time_exhausted", None,
                        TIME_EXIT_BEFORE.format(budget=cfg.wall_budget_s, spent=spent, rounds=rnd - 1), rnd - 1)
        try:
            probes_closed = rnd >= cfg.probe_cutoff_round and not submitted
            # Past the cutoff the submission is mandatory, not merely the only tool on offer: a live run answered
            # a one-tool list with prose and ran on to the hard stop with nothing to show.
            resp = call_with_deadline(client, messages, tools.schemas_for(ctx, plan_only=probes_closed),
                                      tools.SUBMIT if probes_closed else None, left)
        except TimeBudgetExceeded:
            spent = time.perf_counter() - started
            observe.warning("run.deadline", where="inside a model call", round=rnd, seconds=spent)
            return done(False, "time_exhausted", None,
                        TIME_EXIT_INSIDE.format(budget=cfg.wall_budget_s, rnd=rnd, spent=spent), rnd)
        except ModelError as exc:
            return done(False, "model_error", None, str(exc), rnd)

        if not resp.tool_calls:
            idle_rounds += 1
            content = resp.content or ""
            long_prose = not resp.truncated and len(content) > cfg.prose_guard_chars
            entry = {"round": rnd, "text": content[:300], "truncated": resp.truncated, "usage": resp.usage}
            if long_prose:
                prose_hits += 1
                entry["prose_guard"] = True
                entry["chars"] = len(content)
            trace.append(entry)
            if idle_rounds >= 2:
                if not (resp.truncated or long_prose):
                    messages.append(resp.to_message())
                return done(False, "no_progress", None, "model stopped calling tools without submitting a plan", rnd)
            if resp.truncated:
                # A cut-off deliberation is worthless context: drop it rather than replay it into the next call.
                messages.append({"role": "user", "content": TRUNCATED_NUDGE})
            elif long_prose:
                # The same path: a wall of prose is dropped, not replayed, and the model is told to call a tool.
                messages.append({"role": "user", "content": PROSE_NUDGE})
            else:
                messages.append(resp.to_message())
                messages.append({"role": "user", "content": IDLE_NUDGE})
            continue
        idle_rounds = 0
        messages.append(assistant_message(resp, cfg))
        # a turn that made a single probe spent a whole round on it; the tool result says so (round_line)
        one_probe = len(resp.tool_calls) == 1 and resp.tool_calls[0].name not in tools.PLAN_TOOLS

        for tc in resp.tool_calls:
            tool_calls += 1
            sig = _sig(tc.name, tc.arguments)
            last_sigs.append(sig)
            if len(last_sigs) >= cfg.no_progress_limit and len(set(last_sigs[-cfg.no_progress_limit:])) == 1 and tc.name not in tools.PLAN_TOOLS:
                return done(False, "no_progress", None, f"same call repeated {cfg.no_progress_limit} times: {tc.name}", rnd)

            if probes_closed and tc.name not in tools.PLAN_TOOLS:
                # Withdrawing the schema and naming the tool in `tool_choice` are both requests, and a provider
                # can decline them: a live run kept calling derived_geometry through five closed rounds because
                # the calls were in its own history. So the call is refused here, where the refusal is ours.
                refused_after_cutoff += 1
                if refused_after_cutoff > cfg.no_progress_limit:
                    return done(False, "no_progress", None,
                                f"{refused_after_cutoff} measurement calls after the probe cutoff without a "
                                f"submission (round {cfg.probe_cutoff_round} onward offers the plan tools only)", rnd)
                result: dict = {"error": PROBES_CLOSED_ERROR.format(name=tc.name)}
            elif "__malformed__" in tc.arguments and (
                    tc.name not in tools.PLAN_TOOLS
                    or read_plan_arguments(tc.arguments.get("__malformed__"))[0] is None):
                result = {"error": _malformed_error(tc.arguments.get("__malformed__"))}
            elif tc.name in tools.PLAN_TOOLS:
                args = tc.arguments
                salvaged = ""
                if "__malformed__" in args:
                    read, kind, surplus = read_plan_arguments(args["__malformed__"])
                    args = read or {}
                    # a plan closed and then closed again lost nothing: it is not a salvage, it is not charged as
                    # one, and it is not told to add back a tail it still has (P4.3e)
                    salvaged = SURPLUS_NOTE.format(n=surplus) if kind == SURPLUS else SALVAGED_NOTE
                    cut_short = kind == SALVAGED
                else:
                    cut_short, surplus = False, 0
                repairs: dict = {"surplus_brackets": surplus} if surplus else {}
                if tc.name == SUBMIT:
                    # a plan that closed one field early: the fields beside it belong in it (P4.3e)
                    args, moved = merge_stray_plan_fields(args)
                    if moved:
                        repairs["stray_plan_fields"] = moved
                        salvaged = (salvaged + " " if salvaged else "") + STRAY_FIELDS_NOTE.format(
                            fields=", ".join(moved[:3]) + (", ..." if len(moved) > 3 else ""), n=len(moved))
                plan_obj, edit_errors, counts = _plan_for_call(ctx, tc.name, args)
                if tc.name == SUBMIT:
                    submitted = True
                if cut_short and tc.name == SUBMIT and isinstance(plan_obj, dict):
                    # only on a submission: there the recovered object is the plan itself, so its last value is
                    # where the text ran out. On a salvaged amend the cut fell in the edits list, not in the plan.
                    tail = salvage_tail(plan_obj)
                    if tail:
                        salvaged += SALVAGED_TAIL.format(tail=tail)
                if plan_obj is None:
                    if counts:
                        rejections += 1
                    paths = [e.split(":")[0].removeprefix("edit ").strip("'") for e in edit_errors if e.startswith("edit /")]
                    if counts and salvage_missing:
                        # the path is inside a field the cut took: say so rather than leave R17's listing to imply it
                        edit_errors = edit_errors[:-1] + [edit_errors[-1] + STILL_MISSING.format(fields=", ".join(salvage_missing))]
                    result = {"accepted": False, "errors": ([salvaged] if salvaged else []) + edit_errors}
                    if counts:
                        result["rejection_kind"] = CHECKER_KIND
                        result["amend_paths"] = paths
                        result["instruction"] = tools.amend_instruction(paths, applied=False, plan_obj=ctx.last_plan)
                    trace.append({"round": rnd, "tool": tc.name, "accepted": False, "errors": edit_errors[:12], "usage": resp.usage})
                elif not risks_with_roles_called:
                    ctx.last_plan = plan_obj
                    result = {"accepted": False, "errors": [ROLES_FIRST]}
                    trace.append({"round": rnd, "tool": tc.name, "accepted": False, "errors": result["errors"], "usage": resp.usage})
                else:
                    if tc.name == SUBMIT:
                        # the plan on the context carries its provenance: the checker words R32's list of the
                        # schema 3 fields as the cut it was, on this call and on the amends that finish the plan
                        ctx.last_plan_salvaged = cut_short
                    plan, errors, hints = grounding.check_with_hints(plan_obj, ctx, salvaged=cut_short)
                    # the chain's boundary, after the checker's: a grounded plan that contradicts the survey or a
                    # confirmation is sent back like any rejection (ChainGiven)
                    given_errors = given.check(plan.model_dump(mode="json")) if (plan is not None and given) else []
                    if given_errors:
                        rejections += 1
                        ctx.last_plan = plan_obj
                        result = {"accepted": False, "rejection_kind": GIVEN_KIND, "errors": given_errors,
                                  "instruction": GIVEN_INSTRUCTION}
                        trace.append({"round": rnd, "tool": tc.name, "accepted": False, "errors": given_errors[:12],
                                      "rejection_kind": GIVEN_KIND, "usage": resp.usage, **repairs})
                    elif plan is not None:
                        entry = {"round": rnd, "tool": tc.name, "accepted": True, "usage": resp.usage, **repairs}
                        if cut_short:
                            entry["salvaged"] = True
                        if hints.get("warnings"):
                            # the checker's info notes on an accepted plan (a missing counterfactual): kept in the trace
                            entry["warnings"] = hints["warnings"]
                        trace.append(entry)
                        return done(True, "submitted", plan, "grounded plan accepted", rnd)
                    else:
                        # What the cut took is not a judgement of the model's: pydantic stops at the structure, so a
                        # rejection that is nothing but "Field required" lines on a plan the salvage closed off says only
                        # that the submission was truncated. It is counted and capped on its own, and named as its own
                        # kind, so finishing the plan costs none of the content submissions.
                        # `hints["truncated"]` is the checker's own mark on a salvaged submission that would not parse
                        # (R32); `missing_fields_only` reads the errors, for the cut that lost nothing else.
                        tail_lost = tools.missing_fields_only(errors) or bool(hints.get("truncated"))
                        incomplete = tail_lost and bool(cut_short or salvage_missing) and not cfg.charge_salvage_rejections
                        if incomplete:
                            salvage_rejections += 1
                        else:
                            rejections += 1
                        ctx.last_plan = plan_obj
                        paths = tools.error_pointers(errors, plan_obj)
                        # R32's list travels with the paths, not only in the hints: pydantic cannot report an optional
                        # field, so the schema 3 tail the same cut took would otherwise be named nowhere the amend
                        # instruction reads, and the model would be told all four paths are all there is to add and
                        # then rejected a second time for the other three. One cut, one amend, one round.
                        paths += [p for p in tools.tail_pointers(hints.get("missing_v3_tail")) if p not in paths]
                        salvage_missing = paths if tail_lost and (cut_short or salvage_missing) else []
                        # the amend cycle carries what changed: the errors in full, the hints only where they moved,
                        # and the second look without the prose an ok row does not need (lean_hints)
                        lean = lean_hints(hints)
                        sent = thin_hints(lean, last_hints) if cfg.thin_rejection_hints else lean
                        last_hints = lean
                        shown = tools.missing_field_notes(errors, plan_obj)[:25]
                        result = {"accepted": False, "rejection_kind": SALVAGE_KIND if incomplete else CHECKER_KIND,
                                  "errors": ([salvaged] if salvaged else []) + shown, **sent, "amend_paths": paths,
                                  "instruction": tools.salvage_instruction(paths) if tail_lost else tools.amend_instruction(paths)}
                        if hints.get("missing_catalog_risks"):
                            ctx.ledger.record(tools._round(hints["missing_catalog_risks"]))
                        entry = {"round": rnd, "tool": tc.name, "accepted": False, "errors": errors[:12],
                                 "amend_paths": paths, "usage": resp.usage,
                                 "rejection_kind": SALVAGE_KIND if incomplete else CHECKER_KIND, **repairs}
                        if cut_short:
                            entry["salvaged"] = True
                        if sent.get(UNCHANGED_KEY):
                            entry[UNCHANGED_KEY] = sent[UNCHANGED_KEY]
                        trace.append(entry)
                spent = rejections >= cfg.max_grounding_rejections
                if spent or salvage_rejections >= cfg.max_salvage_rejections:
                    result["_round"] = round_line(rnd, cfg, submitted, probes_closed=probes_closed)
                    messages.append({"role": "tool", "tool_call_id": tc.id, "content": _clip(result, cfg.max_tool_result_chars)})
                    last = result.get("errors", [])
                    if spent:
                        return done(False, "grounding_rejected", None,
                                    f"{rejections} submissions rejected; last errors: {last[:5]}", rnd)
                    return done(False, "grounding_rejected", None,
                                SALVAGE_EXIT.format(n=salvage_rejections, fields=", ".join(salvage_missing)), rnd)
            else:
                result = tools.run_tool(ctx, tc.name, tc.arguments)
                if tc.name == "list_risks" and tc.arguments.get("roles") is not None:
                    # an empty roles dict is a valid assignment for a body with no openings (a sphere, a fin plate)
                    risks_with_roles_called = True
                entry = {"round": rnd, "tool": tc.name, "args": tc.arguments,
                         "result_keys": sorted(result.keys()) if isinstance(result, dict) else None, "usage": resp.usage}
                if isinstance(result, dict) and "from_facts_packet" in result:
                    # answered from the opening message's packet: no measurement ran (tools.packet_answer)
                    entry["from_facts_packet"] = True
                if isinstance(result, dict) and result.get("repeated"):
                    # the tool answered from what it had already fetched and did nothing again (look_at_views
                    # holds one impression per run): the trace says so, so a count of calls is a count of work
                    entry["repeated"] = True
                trace.append(entry)
            if isinstance(result, dict):
                result["_round"] = round_line(rnd, cfg, submitted, one_probe=one_probe,
                                              risks_done=risks_with_roles_called, probes_closed=probes_closed)
            messages.append({"role": "tool", "tool_call_id": tc.id, "content": _clip(result, cfg.max_tool_result_chars)})

    return done(False, "budget_exhausted", None, f"no grounded plan after {cfg.max_rounds} rounds", cfg.max_rounds)


def plan_to_json(plan: GeometryPlan) -> str:
    return plan.model_dump_json(indent=1)
