"""Model access behind one Protocol. OpenAI-compatible over httpx; scripted and replay clients for tests."""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Protocol

import httpx

from geometry_agent import observe


@dataclass
class ToolCall:
    id: str
    name: str
    arguments: dict[str, Any]


@dataclass
class ModelResponse:
    content: str
    tool_calls: list[ToolCall] = field(default_factory=list)
    usage: dict[str, int] = field(default_factory=dict)
    reasoning_content: str | None = None
    finish_reason: str | None = None

    @property
    def truncated(self) -> bool:
        return self.finish_reason in ("length", "max_tokens")

    def to_message(self) -> dict:
        msg: dict[str, Any] = {"role": "assistant", "content": self.content or ""}
        if self.reasoning_content:
            msg["reasoning_content"] = self.reasoning_content
        if self.tool_calls:
            msg["tool_calls"] = [
                {"id": tc.id, "type": "function",
                 "function": {"name": tc.name, "arguments": json.dumps(tc.arguments)}}
                for tc in self.tool_calls
            ]
        return msg


class ModelClient(Protocol):
    def complete(self, messages: list[dict], tools: list[dict], force_tool: str | None = None) -> ModelResponse: ...


class ModelError(Exception):
    pass


# --- reading a provider's answer ---------------------------------------------------------------------------------
# Every field below was read as if the provider's JSON had the shape the API documents. It usually does, and when
# it does not (a CDN's error page, a proxy that wraps the body in a list, a model that puts a bare string where an
# object belongs) the reader raised AttributeError or TypeError, which `run_loop` does not catch: the case died as
# a crash rather than as a truthful `model_error`, and a crash is what a corpus run reports at 3 a.m. with no
# transcript. So each of these coerces or raises ModelError, and nothing else.

def _as_text(value: Any) -> str:
    """A content field as a string. Anthropic-style block lists and stray objects become their text, not a raise."""
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        return "".join(b.get("text", "") if isinstance(b, dict) else str(b) for b in value)
    return str(value)


def _as_dict(value: Any) -> dict:
    """A usage block as a dict. A provider that reports usage as a list once cost a whole case: `_UsageMeter`
    read `.get` off it and the AttributeError left the run with no result at all."""
    return value if isinstance(value, dict) else {}


def read_tool_calls(raw: Any) -> list[ToolCall]:
    """The tool calls of a message, however the provider shaped them.

    A call whose arguments will not parse, or parse to something that is not an object, keeps the raw text under
    `__malformed__`: the loop already knows how to salvage a plan from that and how to tell the model what broke,
    and a list where an object belongs must not reach `args.get(...)` inside the loop."""
    calls: list[ToolCall] = []
    if not isinstance(raw, list):
        return calls
    for tc in raw:
        if not isinstance(tc, dict):
            continue
        fn = tc.get("function")
        fn = fn if isinstance(fn, dict) else {}
        text = fn.get("arguments")
        try:
            args = json.loads(text or "{}")
        except (json.JSONDecodeError, TypeError):
            args = {"__malformed__": text}
        if not isinstance(args, dict):
            args = {"__malformed__": text if isinstance(text, str) else json.dumps(args, default=str)}
        name = fn.get("name") or tc.get("name") or ""
        calls.append(ToolCall(id=str(tc.get("id") or f"call_{len(calls)}"), name=str(name), arguments=args))
    return calls


def load_dotenv_files(start: Path | None = None) -> list[Path]:
    """Load KEY=VALUE lines from .env files without overriding what the shell already set.

    Looks in: $GEOMETRY_AGENT_ENV, ./.env.local, ./.env, the parent's, the grandparent's, and the package's
    own repo root. Running from hexera-platform-v2/geometry_agent picks up both its .env.local and the
    platform's .env."""
    here = (start or Path.cwd()).resolve()
    pkg_root = Path(__file__).resolve().parents[3]
    candidates: list[Path] = []
    if os.environ.get("GEOMETRY_AGENT_ENV"):
        candidates.append(Path(os.environ["GEOMETRY_AGENT_ENV"]))
    for base in (here, here.parent, here.parent.parent, pkg_root, pkg_root.parent):
        for name in (".env.local", ".env"):
            candidates.append(base / name)
    loaded: list[Path] = []
    seen: set[Path] = set()
    for c in candidates:
        try:
            c = c.resolve()
        except OSError:
            continue
        if c in seen or not c.is_file():
            continue
        seen.add(c)
        for line in c.read_text(errors="ignore").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            if line.startswith("export "):
                line = line[7:]
            k, v = line.split("=", 1)
            k, v = k.strip(), v.strip().strip('"').strip("'")
            if k and v and k not in os.environ:
                os.environ[k] = v
        loaded.append(c)
    return loaded


#: A plan submission is 5k to 8k tokens of JSON, and a thinking model deliberates for as much again before writing
#: it. At 8192 the submit turn was cut off mid-thought in every live case, costing a whole round each time.
DEFAULT_MAX_TOKENS = 32768
THINKING_ENV = "GEOMETRY_AGENT_THINKING"


def thinking_setting(env: dict | None = None) -> str:
    """'on', 'off', or 'default' (leave the provider's own behaviour alone). Off unless asked: on the devious set
    DeepSeek v4 pro reached the same plan with deliberation off in 81 s and 5 rounds against 289 s and 3 rounds
    with it on, and the platform's own intake runs it off too."""
    v = (env or os.environ).get(THINKING_ENV, "off").strip().lower()
    return {"1": "on", "true": "on", "on": "on", "0": "off", "false": "off", "off": "off"}.get(v, "default")


def _thinking_body(setting: str) -> dict[str, Any]:
    # The DeepSeek API's switch; the platform's intake sends the same shape (adapters/model_inference/deepseek.py).
    if setting == "off":
        return {"thinking": {"type": "disabled"}}
    if setting == "on":
        return {"thinking": {"type": "enabled"}}
    return {}


def _key(value: str | None) -> str | None:
    """An API key with surrounding whitespace taken off. A token never contains it and a header may not.

    MEASURED: `docker run --env-file` does NOT trim a value (`docker compose env_file` does), so a .env line
    written as `DEEPSEEK_API_KEY= sk-... ` reached the process with the space, `Bearer  sk-...  ` is not a legal
    header value, and httpx raised `LocalProtocolError` on every attempt - five failed calls and no plan, for a
    key that was correct. Whitespace is not part of a credential, so it is taken off where the credential is
    read rather than argued about at the header.
    """
    return value.strip() if isinstance(value, str) else value


@dataclass
class OpenAICompatibleClient:
    model: str
    base_url: str = "https://api.openai.com/v1"
    api_key: str | None = None
    temperature: float = 0.0
    timeout: float = 300.0
    extra: dict[str, Any] = field(default_factory=dict)
    max_retries: int = 4
    max_tokens: int | None = DEFAULT_MAX_TOKENS

    @classmethod
    def from_env(cls, provider: str = "auto") -> OpenAICompatibleClient:
        """Resolve a client from the environment.

        provider: "auto" (GEOMETRY_AGENT_* first, then the stack's DeepSeek, then DeepInfra), "deepseek",
        "deepinfra", or "generic" (GEOMETRY_AGENT_* only). The variable names are the ones hexera-platform-v2
        already declares in settings/providers.py, so a shell that runs the platform runs this.
        GEOMETRY_AGENT_THINKING=on|off toggles the model's deliberation where the API has a switch (DeepSeek);
        GEOMETRY_AGENT_MAX_TOKENS overrides the output budget."""
        load_dotenv_files()
        env = os.environ
        # through observe.setting, so a typo in a number is a warning and the default rather than a ValueError
        # out of a resolver that runs before the loop has any way to report it
        max_tokens = int(observe.setting("GEOMETRY_AGENT_MAX_TOKENS", float(DEFAULT_MAX_TOKENS), env))
        extra = _thinking_body(thinking_setting(env))
        if provider in ("auto", "generic") and env.get("GEOMETRY_AGENT_MODEL"):
            return cls(model=env["GEOMETRY_AGENT_MODEL"],
                       base_url=env.get("GEOMETRY_AGENT_BASE_URL", "https://api.openai.com/v1").rstrip("/"),
                       api_key=_key(env.get("GEOMETRY_AGENT_API_KEY") or env.get("OPENAI_API_KEY")),
                       max_tokens=max_tokens)
        if provider in ("auto", "deepseek") and env.get("DEEPSEEK_API_KEY"):
            return cls(model=env.get("DEEPSEEK_MODEL", "deepseek-v4-pro"),
                       base_url=env.get("DEEPSEEK_BASE_URL", "https://api.deepseek.com/v1").rstrip("/"),
                       api_key=_key(env["DEEPSEEK_API_KEY"]), max_tokens=max_tokens, extra=extra)
        if provider in ("auto", "deepinfra") and env.get("DEEPINFRA_API_KEY"):
            return cls(model=env.get("GEOMETRY_AGENT_VISION_MODEL") or env.get("REVIEWER_MODEL", "Qwen/Qwen3-VL-235B-A22B-Thinking"),
                       base_url=env.get("DEEPINFRA_BASE_URL", "https://api.deepinfra.com/v1/openai").rstrip("/"),
                       api_key=_key(env["DEEPINFRA_API_KEY"]),
                       timeout=observe.setting("DEEPINFRA_CALL_TIMEOUT", 1800.0, env) or 1800.0,
                       max_tokens=max_tokens)
        raise ModelError(
            f"no model configured for provider={provider!r}: set GEOMETRY_AGENT_MODEL (+BASE_URL, +API_KEY), "
            "or DEEPSEEK_API_KEY (+DEEPSEEK_MODEL), or DEEPINFRA_API_KEY (+REVIEWER_MODEL)")

    def complete(self, messages: list[dict], tools: list[dict], force_tool: str | None = None) -> ModelResponse:
        body: dict[str, Any] = {"model": self.model, "messages": messages, "temperature": self.temperature, **self.extra}
        if self.max_tokens:
            body["max_tokens"] = self.max_tokens
        if tools:
            body["tools"] = tools
            # `force_tool` is the loop's probe cutoff. Offering one tool is not enough: a model that does not want
            # to submit answers with prose instead, so past the cutoff the call itself is made mandatory.
            body["tool_choice"] = ({"type": "function", "function": {"name": force_tool}} if force_tool else "auto")
        headers = {"content-type": "application/json"}
        if self.api_key:
            headers["authorization"] = f"Bearer {self.api_key}"
        data = self._post(body, headers)
        try:
            choice = data["choices"][0]
            msg = choice["message"]
        except (KeyError, IndexError, TypeError) as exc:
            # TypeError as well as the other two: a provider that answers with a list, or with a string where an
            # object belongs, raised out of run_loop (which catches ModelError only) and ended the case as a crash
            raise ModelError(f"malformed response: {data!r}"[:500]) from exc
        if not isinstance(msg, dict):
            raise ModelError(f"malformed response: message is {type(msg).__name__}, not an object: {msg!r}"[:500])
        return ModelResponse(content=_as_text(msg.get("content")), tool_calls=read_tool_calls(msg.get("tool_calls")),
                             usage=_as_dict(data.get("usage")),
                             reasoning_content=_as_text(msg.get("reasoning_content")) or None,
                             finish_reason=(_as_text(choice.get("finish_reason")) or None) if isinstance(choice, dict) else None)

    def _post(self, body: dict, headers: dict) -> dict:
        return post_json(f"{self.base_url}/chat/completions", body, headers, self.timeout, self.max_retries)


#: Statuses worth another attempt: timeouts, conflicts, rate limits, server errors, Anthropic's overloaded 529.
RETRY_STATUSES = frozenset({408, 409, 425, 429, 500, 502, 503, 504, 529})
#: The longest a retry-after is honoured. A CDN that asks for an hour is asking for more than a case's budget.
MAX_RETRY_AFTER_S = 60.0


def retry_after_seconds(value: str | None, now: float | None = None) -> float | None:
    """The seconds a `Retry-After` header asks for, or None when it asks for nothing readable.

    RFC 7231 gives the header two forms and a CDN in front of a 429 sends the second: `120`, and
    `Wed, 21 Oct 2015 07:28:00 GMT`. `float()` on the date form raises ValueError, and `run_loop` catches only
    ModelError, so that one header took a case out of a run as a crash instead of a truthful model_error. Both
    forms are read here; a date already in the past is no wait at all, and anything unreadable is None, which
    leaves the caller backing off on its own schedule."""
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    try:
        return max(0.0, float(text))
    except ValueError:
        pass
    try:
        from email.utils import parsedate_to_datetime
        when = parsedate_to_datetime(text)
    except (TypeError, ValueError):
        return None
    if when is None:
        return None
    if when.tzinfo is None:
        when = when.replace(tzinfo=UTC)
    seconds = when.timestamp() - (now if now is not None else datetime.now(UTC).timestamp())
    return max(0.0, seconds)


#: Header names whose VALUE is a credential. Matched as a substring of the lowercased name, so a provider
#: header this package has not met yet is covered by the shape of its name rather than by being listed.
SECRET_HEADERS = ("authorization", "api-key", "api_key", "token", "secret", "cookie")

#: What a credential is replaced by. Long enough to be obvious in a log, and it says what to look at.
REDACTED = "<redacted credential>"


def without_secrets(text: str, headers: dict | None) -> str:
    """`text` with every credential in `headers` taken out of it. Never raises.

    A PROVIDER ERROR IS STORED, LOGGED AND HANDED TO THE BUILDER, so a credential inside one does not stay in
    the process that made the call. MEASURED, walking a real part through the platform in the image built from
    this commit: `DEEPSEEK_API_KEY` reached the container with a leading space (`docker run --env-file` does not
    trim, and a hand-edited .env had one), httpx refused the header, and the exception text was
    `Illegal header value b'Bearer  sk-<the whole key> '`. That string became `ModelError`, then
    `AnalysisResult.reason`, then the platform's stored `geometry_step.reason`, then the job's record, then a
    log line - and, since `contract.deliver.with_no_plan`, a row in the block the BUILDER reads. One provider
    error wrote the account's key into five durable places.

    IT IS DONE HERE BECAUSE THIS IS THE ONLY PLACE THAT KNOWS THE SECRET. `post_json` is handed the headers and
    is shared by the text clients and the vision adapters, so one scrub covers every provider, every error shape
    and both halves of the product. Scrubbing downstream would need each reader to guess what a key looks like.
    """
    out = str(text)
    for name, value in (headers or {}).items():
        raw = str(value or "")
        if len(raw) < 8 or not any(s in str(name).lower() for s in SECRET_HEADERS):
            continue
        for secret in (raw, raw.strip(), raw.split()[-1] if raw.split() else ""):
            if len(secret) >= 8:
                out = out.replace(secret, REDACTED)
    return out


def post_json(url: str, body: dict, headers: dict, timeout: float, max_retries: int) -> dict:
    """POST a JSON body and return the JSON reply, retrying transport errors and RETRY_STATUSES with backoff
    (retry-after honoured in both RFC 7231 forms, capped at MAX_RETRY_AFTER_S). Shared by the text clients and
    the vision adapters so every provider call has the same failure behaviour and the hermetic tests guard one
    entry point (httpx.post).

    EVERY ERROR IT RAISES IS SCRUBBED OF THE CREDENTIALS IT WAS HANDED (`without_secrets`), because the text of
    a `ModelError` from here is stored on the job, written to the record and read by the builder.
    """
    import time
    last: Exception | None = None
    for attempt in range(max_retries + 1):
        try:
            r = httpx.post(url, json=body, headers=headers, timeout=timeout)
        except httpx.HTTPError as exc:
            last = exc
            if attempt < max_retries:
                observe.warning("model.retry", attempt=attempt + 1, of=max_retries, error=type(exc).__name__)
                time.sleep(min(2**attempt, 20))
                continue
            observe.warning("model.failed", attempts=attempt + 1, error=type(exc).__name__)
            raise ModelError(without_secrets(f"{type(exc).__name__}: {exc}", headers)) from exc
        if r.status_code in RETRY_STATUSES and attempt < max_retries:
            asked = retry_after_seconds(r.headers.get("retry-after"))
            wait = min(asked if asked is not None else min(2**attempt, 20), MAX_RETRY_AFTER_S)
            observe.warning("model.retry", attempt=attempt + 1, of=max_retries, status=r.status_code,
                            retry_after=asked, waiting=wait)
            time.sleep(wait)
            last = ModelError(without_secrets(f"HTTP {r.status_code}: {_body_text(r)[:200]}", headers))
            continue
        if r.status_code >= 400:
            observe.warning("model.failed", attempts=attempt + 1, status=r.status_code)
            raise ModelError(without_secrets(f"HTTP {r.status_code}: {_body_text(r)[:500]}", headers))
        try:
            return r.json()
        except ValueError as exc:
            raise ModelError(without_secrets(f"non-JSON response: {_body_text(r)[:200]}", headers)) from exc
    observe.warning("model.failed", attempts=max_retries + 1)
    raise ModelError(without_secrets(str(last), headers))


def _body_text(r: Any) -> str:
    """The response body as text for an error message. A body that will not decode is not a reason to raise
    something the loop does not catch."""
    try:
        return r.text or ""
    except Exception as exc:  # noqa: BLE001 - any decoding failure; the message is all this is for
        return f"<undecodable body: {type(exc).__name__}>"


@dataclass
class AnthropicClient:
    """Anthropic Messages API behind the same ModelClient protocol. Tool calls map to tool_use / tool_result blocks."""
    model: str = "claude-sonnet-4-5"
    api_key: str | None = None
    base_url: str = "https://api.anthropic.com"
    max_tokens: int = 16384
    temperature: float = 0.0
    timeout: float = 300.0
    max_retries: int = 4
    thinking_budget: int | None = None

    @classmethod
    def from_env(cls) -> AnthropicClient:
        load_dotenv_files()
        key = os.environ.get("ANTHROPIC_API_KEY")
        if not key:
            raise ModelError("ANTHROPIC_API_KEY is not set")
        return cls(model=os.environ.get("GEOMETRY_AGENT_ANTHROPIC_MODEL", "claude-sonnet-4-5"), api_key=key,
                   base_url=os.environ.get("ANTHROPIC_BASE_URL", "https://api.anthropic.com").rstrip("/"))

    def complete(self, messages: list[dict], tools: list[dict], force_tool: str | None = None) -> ModelResponse:
        system = "\n\n".join(m["content"] for m in messages if m["role"] == "system")
        body: dict[str, Any] = {"model": self.model, "max_tokens": self.max_tokens, "messages": _to_anthropic(messages)}
        if system:
            # The system prompt and the tool schemas are identical on every call of a run; cache them.
            body["system"] = [{"type": "text", "text": system, "cache_control": {"type": "ephemeral"}}]
        if self.thinking_budget:
            body["thinking"] = {"type": "enabled", "budget_tokens": self.thinking_budget}
        else:
            body["temperature"] = self.temperature
        if tools:
            body["tools"] = [{"name": t["function"]["name"], "description": t["function"].get("description", ""),
                              "input_schema": t["function"].get("parameters") or {"type": "object", "properties": {}}}
                             for t in tools]
            body["tools"][-1]["cache_control"] = {"type": "ephemeral"}
            if force_tool:
                body["tool_choice"] = {"type": "tool", "name": force_tool}
        headers = {"content-type": "application/json", "anthropic-version": "2023-06-01", "x-api-key": self.api_key or ""}
        data = self._post(body, headers)
        if not isinstance(data, dict):
            raise ModelError(f"malformed response: {type(data).__name__}, not an object: {data!r}"[:500])
        content = data.get("content")
        blocks = [b for b in content if isinstance(b, dict)] if isinstance(content, list) else []
        text = "".join(_as_text(b.get("text")) for b in blocks if b.get("type") == "text")
        # id and name were read with [] and a block without them is not this loop's to die on
        calls = [ToolCall(id=str(b.get("id") or f"call_{i}"), name=str(b.get("name") or ""),
                          arguments=b.get("input") if isinstance(b.get("input"), dict) else {})
                 for i, b in enumerate(blocks) if b.get("type") == "tool_use"]
        return ModelResponse(content=text, tool_calls=calls, usage=_as_dict(data.get("usage")),
                             finish_reason=_as_text(data.get("stop_reason")) or None)

    def _post(self, body: dict, headers: dict) -> dict:
        return post_json(f"{self.base_url}/v1/messages", body, headers, self.timeout, self.max_retries)


def _to_anthropic(messages: list[dict]) -> list[dict]:
    """OpenAI-style transcript -> Anthropic messages. Assistant tool_calls become tool_use blocks; the tool
    results that follow are folded into ONE user message of tool_result blocks."""
    out: list[dict] = []
    pending_results: list[dict] = []

    def flush():
        nonlocal pending_results
        if pending_results:
            out.append({"role": "user", "content": pending_results})
            pending_results = []

    for m in messages:
        role = m["role"]
        if role == "system":
            continue
        if role == "tool":
            pending_results.append({"type": "tool_result", "tool_use_id": m["tool_call_id"], "content": str(m.get("content") or "")})
            continue
        flush()
        if role == "assistant":
            blocks: list[dict] = []
            if m.get("content"):
                blocks.append({"type": "text", "text": str(m["content"])})
            for tc in m.get("tool_calls") or []:
                fn = tc["function"]
                try:
                    args = json.loads(fn.get("arguments") or "{}")
                except json.JSONDecodeError:
                    args = {}
                blocks.append({"type": "tool_use", "id": tc["id"], "name": fn["name"], "input": args})
            out.append({"role": "assistant", "content": blocks or [{"type": "text", "text": ""}]})
        else:
            out.append({"role": "user", "content": str(m.get("content") or "")})
    flush()
    return out


def client_from_env(provider: str = "auto") -> ModelClient:
    """Resolve the model. `auto` honours GEOMETRY_AGENT_PROVIDER, then prefers the stack's DeepSeek, then DeepInfra,
    then Anthropic, then GEOMETRY_AGENT_*. DeepSeek first because it is Hexera's production model and the cheap one."""
    load_dotenv_files()
    env = os.environ
    if provider == "auto":
        provider = env.get("GEOMETRY_AGENT_PROVIDER", "auto").strip().lower() or "auto"
    if provider == "anthropic":
        return AnthropicClient.from_env()
    if provider in ("deepseek", "deepinfra", "generic"):
        return OpenAICompatibleClient.from_env(provider)
    if env.get("DEEPSEEK_API_KEY"):
        return OpenAICompatibleClient.from_env("deepseek")
    if env.get("DEEPINFRA_API_KEY"):
        return OpenAICompatibleClient.from_env("deepinfra")
    if env.get("ANTHROPIC_API_KEY"):
        return AnthropicClient.from_env()
    return OpenAICompatibleClient.from_env("generic")


@dataclass
class ScriptedClient:
    """Plays back a fixed list of responses. Raises when the script runs out, so an over-long loop fails loudly."""
    responses: list[ModelResponse]
    calls: list[list[dict]] = field(default_factory=list)
    #: The tool list offered on each turn, so a test can assert what the model could reach (the probe cutoff).
    tools_seen: list[list[dict]] = field(default_factory=list)
    #: The tool the loop made mandatory on each turn, or None. Same length as `tools_seen`.
    forced: list[str | None] = field(default_factory=list)

    def complete(self, messages: list[dict], tools: list[dict], force_tool: str | None = None) -> ModelResponse:
        self.calls.append(messages)
        self.tools_seen.append(tools)
        self.forced.append(force_tool)
        if not self.responses:
            raise ModelError("scripted client exhausted")
        return self.responses.pop(0)


def tool_call(name: str, **arguments) -> ModelResponse:
    return ModelResponse(content="", tool_calls=[ToolCall(id=f"call_{name}_{abs(hash(json.dumps(arguments, sort_keys=True, default=str))) % 10_000}", name=name, arguments=arguments)])


def text(content: str) -> ModelResponse:
    return ModelResponse(content=content)


@dataclass
class RecordingClient:
    """Writes every model turn to `path` as it happens, so a run cut off midway still leaves its partial transcript.

    File format: {"model": ..., "exit": ..., <extra>, "turns": [{content, tool_calls, usage}, ...]}. `exit` and the
    extras are written by finish() once the loop has returned; a file without `exit` is a run that never finished."""
    inner: ModelClient
    path: Path
    records: list[dict] = field(default_factory=list)
    meta: dict[str, Any] = field(default_factory=dict)
    transcript: list[dict] = field(default_factory=list)
    tools: list[dict] = field(default_factory=list)

    def complete(self, messages: list[dict], tools: list[dict], force_tool: str | None = None) -> ModelResponse:
        import time
        t0 = time.perf_counter()
        resp = self.inner.complete(messages, tools, force_tool)
        self.records.append({
            "content": resp.content,
            "tool_calls": [{"id": tc.id, "name": tc.name, "arguments": tc.arguments} for tc in resp.tool_calls],
            "usage": resp.usage, "finish_reason": resp.finish_reason, "reasoning_content": resp.reasoning_content,
            "seconds": round(time.perf_counter() - t0, 2),
        })
        # the full conversation as the model saw it: system, user (with the measurements), assistant, tool results
        self.transcript = list(messages) + [resp.to_message()]
        self.tools = tools
        self._write()
        return resp

    def finish(self, exit: str, **extra: Any) -> None:
        self.meta.update({"exit": exit, **extra})
        self._write(final=True)

    def _write(self, final: bool = False) -> None:
        # A run stopped at its wall-clock budget leaves its last model call on an abandoned thread, and that
        # thread answers eventually: whatever it writes then is not part of the run and must not land on top of
        # the finished transcript. Once `exit` is written the file is closed.
        if self.meta.get("exit") and not final:
            return
        from geometry_agent.agent.schema import PLAN_SCHEMA_VERSION
        self.path.parent.mkdir(parents=True, exist_ok=True)
        params = {k: getattr(self.inner, k) for k in ("temperature", "max_tokens", "extra", "thinking_budget") if hasattr(self.inner, k)}
        # plan_schema_version is the version the run's submit tool advertised, so a replay judges a plan that
        # writes no schema_version under the rules of its own day; a recording without the stamp predates schema 3
        doc = {"model": getattr(self.inner, "model", None), "params": params, "plan_schema_version": PLAN_SCHEMA_VERSION,
               **self.meta, "turns": self.records,
               "transcript": self.transcript, "tools": [t.get("function", {}).get("name") for t in self.tools]}
        self.path.write_text(json.dumps(doc, indent=1, default=str))


class ReplayClient:
    """Plays a recording back. Accepts the current dict format and the original bare list of turns."""

    def __init__(self, path: Path):
        data = json.loads(Path(path).read_text())
        turns = data if isinstance(data, list) else data.get("turns", [])
        self.meta: dict[str, Any] = {} if isinstance(data, list) else {k: v for k, v in data.items() if k != "turns"}
        self.exit: str | None = self.meta.get("exit")
        self.turns = len(turns)
        self._responses = [
            ModelResponse(content=r["content"],
                          tool_calls=[ToolCall(**tc) for tc in r["tool_calls"]],
                          usage=r.get("usage") or {})
            for r in turns
        ]

    def complete(self, messages: list[dict], tools: list[dict], force_tool: str | None = None) -> ModelResponse:
        if not self._responses:
            raise ModelError("replay exhausted")
        return self._responses.pop(0)
