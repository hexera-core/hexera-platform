"""What the agent produces: a plan the builder can execute, questions the user must answer, risks with decisions.

Plan schema 3 (dev plan P4.2, docs/plan_v3_rules.md) adds the two outputs: `simulation_warnings` for the user
(one question each, with a default and an effect) and `mesh_warnings` for the builder (in the builder's own
frame). Every field added for schema 3 is optional at the type level so a schema 2 plan still parses; the
checker enforces presence on schema 3 plans and `grounding._normalise` synthesises what it can for both."""
from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator
from pydantic.json_schema import SkipJsonSchema

from geometry_agent.facts.schema import Fidelity, Purpose, Vec3


def _as_list(v: Any) -> Any:
    """Models write a lone id where a list is asked for ("patch_ids": "o3"); the meaning is not in doubt."""
    if isinstance(v, str):
        return [s.strip() for s in v.split(",") if s.strip()]
    return v

PLAN_SCHEMA_VERSION = 3
#: The versions the checker accepts: 2 (the P4.1 plan, judged by the v2 rules plus the synthesised lists) and 3
#: (docs/plan_v3_rules.md, rules R2 to R12 applied). A plan that writes no version is the current one.
ACCEPTED_SCHEMA_VERSIONS = (2, 3)

Role = Literal["inlet", "outlet", "wall", "farfield", "symmetry", "interface", "opening_unknown", "closed_end"]
Severity = Literal["blocking", "high", "medium", "low", "info"]
#: What a builder item is (docs/builder_directives.md 6.1, docs/plan_v3_rules.md section 20). A `directive` sets
#: one platform key now; a `conditional` sets one on a named measured failure; a `note` is a location and a size
#: with no key, for a feature no key reaches. There is no fourth class, and none of the three predicts a mesh.
ItemClass = Literal["directive", "conditional", "note"]
#: How a directive is ranked. T0 a guard that costs nothing and loses the run when wrong; T1 a floor, a measured
#: feature under a stated minimum that the key delivers; T2 a margin, a feature already over its floor that the
#: key improves and that pays `catalog.price_admits`. The tier follows the unmet floor, never the key.
DirectiveTier = Literal["T0", "T1", "T2"]
Decision = Literal["continue", "fix", "change_purpose", "abort", "pending"]
#: What each connected body is for the simulation. `obstacle` is a solid inside the fluid meshed as wall (a car,
#: a wheel, a centre body, a bubble the flow goes around); `void` is a sealed cavity meshed as nothing;
#: `wall_shell` is the solid wall of a pipe or vessel with open ring ports: the mesher carves the fluid cavity
#: inside it from a seed point (Hexera's body-surface input); `not_a_fluid_body` says the file is the wall and
#: nothing can be carved (no open port, or the user says the file is the fluid and it is not).
RegionRoleName = Literal["fluid", "solid", "void", "obstacle", "rotating_zone", "wall_shell", "not_a_fluid_body"]
UnitBasis = Literal["file", "brief", "user", "guess"]
#: The physical or meshing mechanism a risk names (schema 3). `other` needs a refuting test like every mechanism.
Mechanism = Literal["separation", "recirculation_at_outlet", "dean_secondary_flow", "jet_impingement",
                    "dead_leg_stagnation", "tilted_mouth_skew", "layer_collision", "cell_starvation",
                    "swirl_no_symmetry", "wake", "ground_effect", "tip_gap", "thermal_interface_unshared", "other"]
MECHANISMS: tuple[str, ...] = ("separation", "recirculation_at_outlet", "dean_secondary_flow", "jet_impingement",
                               "dead_leg_stagnation", "tilted_mouth_skew", "layer_collision", "cell_starvation",
                               "swirl_no_symmetry", "wake", "ground_effect", "tip_gap", "thermal_interface_unshared", "other")
#: What answering a question, or acting on a warning, does: nobody is shown a default that silently does nothing.
Effect = Literal["changes_mesh", "changes_bc", "advisory"]
EFFECTS: tuple[str, ...] = ("changes_mesh", "changes_bc", "advisory")


class Patch(BaseModel):
    id: str
    name: str
    role: Role
    #: Measured fields (packet v2): the checker fills them from the facts when the plan omits them, so the model
    #: never retypes a measurement; a value the model does write is checked against the measurement as before.
    area: float | None = None
    centroid: Vec3 | None = None
    normal: Vec3 | None = None
    hydraulic_diameter: float | None = None
    confidence: float = Field(ge=0, le=1)
    evidence: list[str] = Field(default_factory=list)
    confirmed_by_user: bool = False


class Counterfactual(BaseModel):
    """The other role assignment and what breaks under it (checker R11): `swap` names the roles the other way
    round, `what_breaks` says what changes and cites a number from compare_roles or derived_geometry (or its
    derivation id). Optional under plan schema 2; required on schema 3 when role_assumed fires or any port role
    is under 0.9 with no declared ports."""
    swap: str
    what_breaks: str


class Flow(BaseModel):
    axis: Vec3 | None
    #: +1 along `axis`, -1 against it, 0 when no flow is posed. axis * direction_sign points from the inlets
    #: toward the outlets (internal flow) or along the freestream, nose to tail (external flow).
    direction_sign: int = Field(ge=-1, le=1)
    inlet_ids: list[str]
    outlet_ids: list[str]
    confidence: float = Field(ge=0, le=1)
    evidence: list[str] = Field(default_factory=list)
    #: The roles the other way round and what breaks, with a ledger number (see Counterfactual).
    counterfactual: Counterfactual | None = None


# A catalog risk in a submitted plan is a reference, not a copy (R34, docs/plan_v3_rules.md section 14): the id
# and the decision, plus the reason when the decision overrides the catalog's, the question that settles it, and
# the `derived` and `refuted_by` R4 asks for on the entry rather than in a second risk. Everything else is filled
# by `grounding._fill_catalog_risks` from the catalog run the checker makes anyway, matched by id, and a full
# entry written anyway is accepted with its text overwritten by the catalog's, the way a patch's measured numbers
# are (R22). The class docstring is the field description the submit tool shows the model, so it says the rule in
# one sentence and this comment carries the rest.
class Risk(BaseModel):
    """A catalog risk (write only id, user_decision, and derivation when you override it: the checker fills kind,
    severity, measurement, consequence and recommendation from the catalog by id) or one of your own
    (detected_by 'agent', id k101 up, every field yours to write)."""
    id: str
    kind: str = ""
    severity: Severity = "medium"
    measurement: dict[str, Any] = Field(default_factory=dict)
    consequence: str = ""
    recommendation: str = ""
    requires_user_decision: bool = False
    user_decision: Decision = "pending"
    #: The question that settles this risk, when the plan writes one (the inverse of `UserQuestion.relates_to`).
    question_id: str | None = None
    detected_by: Literal["catalog", "agent"] = "catalog"
    derived: dict[str, Any] = Field(default_factory=dict)
    #: The formula, its inputs and the assumptions behind every `derived` value; also the reason for overriding
    #: a catalog decision (user_decision set by the analyst rather than left pending).
    derivation: str = ""
    #: Schema 3: the mechanism the risk names (catalog.KIND_MECHANISM fills it for catalog risks; an agent risk
    #: must carry one), what acting on it does, the builder-frame target when the effect changes the mesh, and
    #: one sentence naming the tool and the number that would refute it.
    mechanism: Mechanism | None = None
    effect: Effect | None = None
    target: dict[str, Any] | None = None
    refuted_by: str = ""


class RefinementRegion(BaseModel):
    where: str
    target_size: float
    reason: str
    #: sphere: anchor + radius (a junction, a gap, a thin cluster). box: box_min + box_max (a wake, a plenum).
    #: surface: patch_ids, the whole surface of a small bore or a blade. feature_edges: the edges named in
    #: preserve_features.
    kind: Literal["sphere", "box", "surface", "feature_edges"] = "sphere"
    anchor: Vec3 | None = None
    radius: float | None = None
    box_min: Vec3 | None = None
    box_max: Vec3 | None = None
    patch_ids: list[str] = Field(default_factory=list)

    _patch_ids_list = field_validator("patch_ids", mode="before")(_as_list)


class LayerTarget(BaseModel):
    patch_id: str
    n_layers: int
    first_cell_height: float
    reason: str


class PortExtension(BaseModel):
    """A stub the builder must extend before meshing: the patch, the absolute length to add, and why."""
    patch_id: str
    length: float
    reason: str


class RegionRole(BaseModel):
    id: str
    role: RegionRoleName
    reason: str


class MeshPlan(BaseModel):
    fidelity: Fidelity
    #: The chosen tier's estimate values, unchanged; the checker fills both from the tier when the plan omits them.
    base_size: float | None = None
    cell_estimate: int | None = None
    refinement_regions: list[RefinementRegion]
    layer_targets: list[LayerTarget]
    preserve_features: list[str]
    #: External flow only: upstream, downstream, lateral, vertical, each an absolute length. Internal cases
    #: leave it empty and put every stub extension in `port_extensions`.
    required_extents: dict[str, float]
    port_extensions: list[PortExtension] = Field(default_factory=list)
    #: One entry per measured region (r1..rn) when the file has few bodies; what each is for the simulation.
    regions: list[RegionRole] = Field(default_factory=list)
    #: Operating conditions and modelling choices the plan assumes because the brief did not give them. Schema 3:
    #: a missing operating point (velocity, fluid, loads) lives here and in the layer target's reason, never as
    #: a risk.
    assumptions: list[str] = Field(default_factory=list)
    #: The tier estimate plus what the refinement regions add; filled by the checker from the plan itself.
    cell_estimate_refined: int | None = None
    #: A point inside the fluid (snappy's locationInMesh): inside the cavity a wall shell is carved from, or inside
    #: a fluid body; within half a bore of a port centroid along its inward normal.
    seed_point: Vec3 | None = None
    notes: list[str] = Field(default_factory=list)


class RefutingTest(BaseModel):
    """The test that would refute an identity hypothesis: a tool, its arguments and the reading that refutes."""
    tool: str
    args: dict[str, Any] = Field(default_factory=dict)
    would_refute_if: str


class IdentityHypothesis(BaseModel):
    """One of the two or three first-turn hypotheses (schema 3, checker R2)."""
    type: str
    prior: float = Field(ge=0, le=1)
    refuting_test: RefutingTest | None = None


class IdentityTest(BaseModel):
    """A test the run made for the identity verdict: the tool, the ledger number it produced, and whether the
    number supports or refutes the chosen type."""
    tool: str
    result_number: float | None = None
    verdict: Literal["supports", "refutes"]


class Identity(BaseModel):
    """The identity verdict (schema 3): carried as `object.identity` (not inside `analysis`, which is prose).
    `confidence` when written must equal `object.confidence`; `tests_run` is what R2 reads."""
    type: str
    confidence: float | None = Field(default=None, ge=0, le=1)
    tests_run: list[IdentityTest] = Field(default_factory=list)
    refuted: list[str] = Field(default_factory=list)

    _refuted_list = field_validator("refuted", mode="before")(_as_list)


class ObjectIdentity(BaseModel):
    type: str
    simulation_intent: str
    confidence: float = Field(ge=0, le=1)
    evidence: list[str]
    #: Schema 3: the verdict with the tests run (checker R2).
    identity: Identity | None = None


class UserQuestion(BaseModel):
    id: str
    text: str
    options: list[str]
    relates_to: str
    default: str | None = None
    #: Other risk ids this one answer settles: four unassigned legs, five short stubs, a set of seams are one
    #: question naming the openings, not one question each.
    also_settles: list[str] = Field(default_factory=list)
    #: Schema 3: what the answer does. A question exists only when its effect is not advisory (checker R8); the
    #: checker fills it from the risk's kind when the plan omits it.
    effect: Effect | None = None

    _also_settles_list = field_validator("also_settles", mode="before")(_as_list)


class UnitCall(BaseModel):
    """The unit every size in the plan is in. `declared` is what the file says (None for STL); `assumed` is the
    unit the plan uses; `basis` says who decided: the file, a dimension in the brief, the user, or a guess
    that a question must carry."""
    declared: str | None
    assumed: str
    basis: UnitBasis


class SimulationWarning(BaseModel):
    """A warning for the user (schema 3): the measurement behind it, the threshold it crossed, one question with
    options and a default, and what the answer does (`effect`). `also_settles` lists the other risk ids the same
    answer settles. `provenance` carries the rule class, the threshold key, the risk and question ids and, once
    answered, `answer` and `settled_by` (a question id, or "brief: <phrase>" when the brief settled it).

    P4.4: this is where a question the brief answered goes. The checker takes it out of `questions` so nobody is
    asked twice, and writes it here with its options, the decision as `answer` and the brief phrase as
    `settled_by`; `provenance.asked` is False for those. Nothing is deleted, so the user summary can name the
    assumption and `confirm.apply_answers` can take an answer to it and overrule the brief's reading. An advisory
    warning that never carried a question also has `asked` False and `question` None: what marks a settled
    question is both, a `question` and `asked` False (`confirm.overrulable`)."""
    id: str
    kind: str
    measurement: dict[str, Any] = Field(default_factory=dict)
    threshold: dict[str, Any] | None = None
    question: str | None = None
    options: list[str] = Field(default_factory=list)
    default: str | None = None
    effect: Effect | None = None
    also_settles: list[str] = Field(default_factory=list)
    provenance: dict[str, Any] = Field(default_factory=dict)
    answer: str | None = None
    settled_by: str | None = None

    _also_settles_list = field_validator("also_settles", mode="before")(_as_list)


class MeshLocation(BaseModel):
    patch_ids: list[str] = Field(default_factory=list)
    point: Vec3 | None = None
    region_id: str | None = None

    _patch_ids_list = field_validator("patch_ids", mode="before")(_as_list)


#: This class carried no description at all until 2026-09-23, and the seven fields were bare numbers, while
#: prompt section 4 listed the four fields a mesh warning answers and the checker (R25) required five. 104 of the
#: 321 rejected submissions in the 176-draw grounding run were told `size` was missing, and 128 of the 309 mesh
#: warnings written carried none. The docstring and the field descriptions below are what the model reads in the
#: submit tool's schema (`tools.plan_parameters_schema`), so they are written for it and not for this file.
class MeshSize(BaseModel):
    """HOW BIG the feature at `location` measures: whichever of these the feature has, in the file's own unit and
    off the opening, cluster or section that was measured. Required on an item of your own kind: a place with no
    extent tells the builder where to look and nothing about what to do there."""
    bore: float | None = Field(None, description="a port's hydraulic diameter or bore")
    min_dim: float | None = Field(None, description="the feature's smallest dimension (a slot's width, a port's minor axis)")
    thickness: float | None = Field(None, description="wall or web thickness, off a thin cluster")
    gap: float | None = Field(None, description="the clearance between two surfaces or two regions")
    tilt_deg: float | None = Field(None, description="a mouth's tilt off its grid axis, in degrees")
    angle_deg: float | None = Field(None, description="a taper, diffuser or edge angle, in degrees")
    length: float | None = Field(None, description="a run, an extension or a box side")


class BuilderCells(BaseModel):
    """The feature in the builder's frame: the wall cell (the inlet bore over cells_across_diameter) and how many
    of them span the feature."""
    wall_cell: float | None = None
    cells_across: float | None = None


class SphereTarget(BaseModel):
    anchor: Vec3
    radius: float


class BoxTarget(BaseModel):
    box_min: Vec3
    box_max: Vec3


class LayersTarget(BaseModel):
    n: int
    first_rel: float


class MeshTarget(BaseModel):
    """What the builder should do. `key` and `value` are the instruction: ONE platform key, spelled as the planner
    declares it, and the value to set it to. The keys with a reader depend on the engine and the representation of
    this part, so the request lists the ones in force under BUILDER KEYS with the range each keeps; that row and
    `catalog.DIRECTIVE_KEYS` are the same table.

    Every field BELOW `key` and `value` is where and how big, and a target carrying only those reaches no reader
    at `tools.PLATFORM_SHA`, so the item is a note and not an instruction: a level delta at the feature, a sphere
    or box, an extension length, the seed point, a layer spec, a gmsh size value, a cells_across_diameter floor,
    a max_cells budget. They are FIELDS of this object and never values of `key`. All optional; the kind's remedy
    table fills the ones it has and `catalog.directive_of` fills `key` and `value` when the kind reaches one.

    (283 of 361 targets in the live run of 2026-09-08 named a field no reader consumes, which is what put the
    sentence above here; 93 of the 197 keys written across the 176-draw grounding run were one of those field
    names put in the `key` slot, which is what put the sentence about the slot here.)"""
    #: The one platform key this item sets, and its value. The value's shape follows the key (a number for
    #: `cells_across_diameter`, one of two words for `quality`, four body lengths for `domain_margin`), so the
    #: type here is open and `catalog.directive_problem` is what holds it to the key's own row: that keeps one
    #: definition of what the renderer accepts instead of two that can disagree, and keeps the submit schema
    #: free of a five-way union the model would have to read. An item with no key is a note.
    key: str | None = None
    value: Any = None
    level_delta: int | None = None
    sphere: SphereTarget | None = None
    box: BoxTarget | None = None
    extension_length: float | None = None
    seed_point: Vec3 | None = None
    layers: LayersTarget | None = None
    gmsh_size_value: float | None = None
    cells_across: int | None = None
    max_cells: int | None = None


class IfItFails(BaseModel):
    """A remedy learned from recorded retries: present only when tried is at least 5 and fixed exceeds made_worse."""
    remedy: str
    tried: int = 0
    fixed: int = 0
    made_worse: int = 0
    platform_revs: list[str] = Field(default_factory=list)


class MeshWarning(BaseModel):
    """One item the builder reads, and it answers five questions and nothing else: WHERE (`location`, a patch id
    or a measured point), HOW BIG (`size`, the feature's own measurement off that place), WHAT TO DO
    (`target.key` and `target.value`, one platform key in the builder's own controls, from the row the request
    carries under BUILDER KEYS), WHAT IT COSTS (`cost_cells` against the cap, and `forecast_cells` with it
    applied), and WHY (`why`, the measurement that makes it worth doing). It never says how the mesh will turn
    out: a prediction is something the builder can only disagree with, an instruction is something it can carry
    out (docs/builder_directives.md, docs/plan_v3_rules.md section 20).

    `item_class` says which of the three it is. A `directive` sets its key now and carries a `tier`; a
    `conditional` sets its key only when the critique says `trigger`, verbatim from the classifier's own words
    (`catalog.CONDITIONAL_TRIGGERS`); a `note` reaches no key at all and carries a location and a size so the
    builder still knows the feature is there.

    `severity` is how much attention the item is owed, not how bad the outcome is (`catalog.ATTENTION`): `high` a
    guard or an unmet floor, set the key before anything else; `medium` a margin the budget allows, or an action
    that applies only on a named measured failure; `low` a note with nothing to set. `blocking` and `info` are
    not attention levels on this channel and the checker rejects them here.

    `detected_by` says whose item it is (P4.3d, docs/plan_v3_rules.md). A catalog item names a kind the catalog
    can measure and calibrate (`catalog.MESH_WARNING_KINDS`). An agent item is one the analyst derived itself and
    may name any snake_case kind, and in exchange it carries the structured fields the builder acts on and no
    claim to a calibrated threshold. The checker fills what a plan omits."""
    id: str
    kind: str
    detected_by: Literal["catalog", "agent"] = "catalog"
    severity: Severity = "medium"
    #: Which of the three classes this is, and the tier that ranks a directive. The checker fills both from the
    #: target and the kind, and rejects a severity that disagrees with them.
    item_class: ItemClass | None = None
    tier: DirectiveTier | None = None
    #: A conditional only: the phrase the critique will carry, from `catalog.CONDITIONAL_TRIGGERS`.
    trigger: str | None = None
    location: MeshLocation = Field(default_factory=MeshLocation)
    size: MeshSize = Field(default_factory=MeshSize)
    builder_cells: BuilderCells | None = None
    target: MeshTarget = Field(default_factory=MeshTarget)
    cost_cells: int | None = None
    #: The emulator's total with this item applied, to be read against `provenance["cell_cap"]`.
    forecast_cells: int | None = None
    why: str = ""
    provenance: dict[str, Any] = Field(default_factory=dict)
    if_it_fails: IfItFails | None = None


class RiskConsidered(BaseModel):
    """A mechanism the analyst considered and dismissed, with the number that dismissed it (checker R5)."""
    mechanism: str
    measurement: dict[str, Any] = Field(default_factory=dict)
    why_not: str = ""


class SecondLookLine(BaseModel):
    """One line of the second look (checker R10): the item, yes or no, the number, a note."""
    item: str
    ok: bool
    number: float | None = None
    note: str = ""


class VisualImpression(BaseModel):
    """What the look returned, carried with the plan: a vision model's words about nine rendered views, and
    never a measurement.

    It is the analyst's own to read and nobody's to write. The checker fills it from the run
    (`grounding._fill_visual_impression`) and replaces anything a plan wrote there, the way it replaces a
    patch's measured numbers; `SkipJsonSchema` keeps it out of the schema the submit tool advertises, so the
    model is never invited to compose one. `impression` is the fixed record
    `vision.prompt.normalise_impression` makes, scrubbed of every digit, held as a mapping so a change to that
    record's fields cannot break a plan that parsed yesterday.

    Its own key and its own label, never mixed into a field that carries measurements: that is the whole point
    of it, and `hexera.report`, `hexera.handover` and `hexera.builder_block` pass it on under the same label."""
    impression: dict[str, Any] = Field(default_factory=dict)
    model: str = ""
    provider: str = ""
    caveat: str = ""
    #: WHERE THE PICTURES POINTED, and the one thing in this model that IS a measurement. The renderer's own
    #: record of which letters it drew and where, and which openings got a stops panel. It rides here because
    #: `marks_seen` and `stops_seen` are the two look fields that carry a subject and a subject is worth
    #: nothing to a consumer without the table that says where it is. Filled by the checker from the run like
    #: everything else here, empty on a plan loaded from a recording written before it existed, and empty is
    #: simply a line with no placed clauses in it.
    drawn: dict[str, Any] = Field(default_factory=dict)


class GeometryPlan(BaseModel):
    schema_version: int = PLAN_SCHEMA_VERSION
    #: The measurements' hash; the checker fills it when the plan omits it and rejects any other value.
    facts_sha256: str = ""
    purpose: Purpose
    object: ObjectIdentity
    unit: UnitCall
    patches: list[Patch]
    flow: Flow
    risks: list[Risk]
    mesh_plan: MeshPlan
    questions: list[UserQuestion]
    analysis: str
    brief_conflicts: list[str] = Field(default_factory=list)
    summary_for_user: str
    summary_for_builder: str
    #: Schema 3, the two outputs. None means the model did not write the list and the checker synthesised it
    #: from the catalog risks; a list the model wrote is kept and checked.
    simulation_warnings: list[SimulationWarning] | None = None
    mesh_warnings: list[MeshWarning] | None = None
    #: Schema 3: the mechanisms considered and dismissed, each with a number (R5); the two or three first-turn
    #: identity hypotheses with their refuting tests (R2); the second look, one line per item (R10).
    agent_risks_considered: list[RiskConsidered] = Field(default_factory=list)
    identity_hypotheses: list[IdentityHypothesis] = Field(default_factory=list)
    second_look: list[SecondLookLine] = Field(default_factory=list)
    #: The look, filled by the checker from the run and never by the model (see VisualImpression). None on a run
    #: that did not look, or whose look failed.
    visual_impression: SkipJsonSchema[VisualImpression | None] = None


class AnalysisResult(BaseModel):
    ok: bool
    #: `time_exhausted` is the wall clock, `budget_exhausted` the rounds, and they are separate because the
    #: answers are: one wants a longer deadline or a faster provider, the other more rounds. `refused` is the
    #: agent declining before any model call (the kill switch, the file-size ceiling, the measurement deadline),
    #: which a caller must be able to tell from a model failure and from a measurement that tried and broke.
    #: `agent_failed` is a fault in OUR code (`loop.run_loop`'s net): it is not the model's failure, not a
    #: refusal and not a measurement that broke, and it is the one exit that is a bug report.
    exit: Literal["submitted", "budget_exhausted", "time_exhausted", "no_progress", "model_error",
                  "grounding_rejected", "measurement_failed", "refused", "agent_failed"]
    plan: GeometryPlan | None
    reason: str
    rounds: int
    tool_calls: int
    grounding_rejections: int
    trace: list[dict[str, Any]] = Field(default_factory=list)
