"""Deterministic failure prediction. Each rule maps a measured fact and a purpose to a risk the user must hear about."""
from __future__ import annotations

import json
import math
import operator
import re
from pathlib import Path
from typing import Any, Literal

from geometry_agent.agent.schema import Risk, Severity
from geometry_agent.agent.thresholds import Thresholds
from geometry_agent.agent.thresholds import current as current_thresholds
from geometry_agent.facts.schema import Fidelity, GeometryFacts, Purpose

# The module constants below are the defaults. The values in force come from agent/thresholds.json through
# `thresholds.current()`; every rule reads `T.<name>` (docs/thresholds.md), and a hermetic test asserts the
# three agree until a value is shipped.
STUB_OK_OVER_D = 5.0
STUB_BLOCKING_OVER_D = 2.0
PORT_TUBULARITY = 0.85
VELOCITY_RATIO_MAX = 2.0
THIN_CELLS_MIN = 3.0
GAP_CELLS_MIN = 3.0
SIZE_BAND = 0.25
AREA_MATCH_BAND = 0.25
NEAR_MATCH_OVER_D = 1.5
MANY_CANDIDATES = 6

FLOW_PURPOSES = {"internal_cfd", "external_cfd", "conjugate_heat_transfer"}
_TERMINATED = {"junction": "a junction", "area_change": "a change in cross-section", "drift": "a bend",
               "end_of_body": "the end of the body", "exit": "an exit", "max_march": "the march limit"}
INTERNAL_PURPOSES = {"internal_cfd", "conjugate_heat_transfer"}


def _risk(idx: int, kind: str, severity: Severity, measurement: dict[str, Any], consequence: str,
          recommendation: str, decision: bool, target: dict[str, Any] | None = None, derivation: str = "") -> Risk:
    """A catalog risk with its schema 3 mechanism and effect filled from the kind tables (a schema 2 reader
    ignores them; the checker's catalog comparison reads severity and the measured numbers only)."""
    return Risk(id=f"k{idx}", kind=kind, severity=severity, measurement=measurement, consequence=consequence,
                recommendation=recommendation, requires_user_decision=decision,
                mechanism=KIND_MECHANISM.get(kind, "other"), effect=KIND_EFFECT.get(kind, "advisory"),
                target=target, derivation=derivation)


# --- schema 3: who each kind is for, which mechanism it names, what acting on it does ---------------------------
#: user: a simulation warning (one question with a default that does something); builder: a mesh warning in the
#: builder's frame; info: reported, never a question and never a builder target. thin_feature is builder on the
#: fluid side and info on a wall shell's metal (`audience_of`). Everything not listed is info.
KIND_AUDIENCE: dict[str, str] = {
    "short_stub": "user", "short_inlet_run": "user", "diffuser_angle": "user", "role_assumed": "user", "tiny_port": "user",
    "cell_cap": "user", "unit_unknown": "user", "undeclared_opening": "user", "declared_port_unmatched": "user",
    "ambiguous_openings": "user",
    "tilted_circular_mouth": "builder", "port_resolution": "builder", "gap_resolution": "builder", "near_touching": "builder",
    "thin_feature": "builder", "budget_forecast": "builder", "seed_point": "builder", "gmsh_size": "builder",
    "skew_repair": "builder", "carve_leak_repair": "builder",
}
#: The kinds the builder list carries (KIND_AUDIENCE builder). The four new ones (tilted_circular_mouth,
#: budget_forecast, seed_point, gmsh_size) are carried by `mesh_warnings`: the checker never demands them from a
#: plan's `risks` list, so a schema 2 transcript is judged exactly as before and the builder still gets them.
MESH_WARNING_KINDS: frozenset[str] = frozenset(k for k, a in KIND_AUDIENCE.items() if a == "builder")
NEW_BUILDER_KINDS: frozenset[str] = frozenset({"tilted_circular_mouth", "budget_forecast", "seed_point", "gmsh_size",
                                               "skew_repair", "carve_leak_repair"})
#: The two conditional kinds: a key to move on a phrase the classifier says, never a claim about this mesh.
CONDITIONAL_KINDS: frozenset[str] = frozenset({"skew_repair", "carve_leak_repair"})
#: A kind the analyst derived itself may be any snake_case word (P4.3d, docs/plan_v3_rules.md section 12). The
#: closed vocabulary above is the CALIBRATED one: a kind enters it when a sweep earns it a threshold, and the
#: warnings the model writes under its own kinds are the evidence for which kind to calibrate next
#: (`grounding.agent_warning_kinds`). The structured fields are what a warning outside the vocabulary is held to,
#: not the name.
AGENT_WARNING_KIND = re.compile(r"^[a-z][a-z0-9]*(?:_[a-z0-9]+)*$")


def agent_warning_kind_ok(kind: str) -> bool:
    """A kind an agent-detected mesh warning may carry: snake_case, at most 60 characters, not a bare number."""
    k = (kind or "").strip()
    return bool(k) and len(k) <= 60 and bool(AGENT_WARNING_KIND.match(k)) and not k.isdigit()


#: A word is the same word in the singular and the plural. The rule is English noun morphology applied to the
#: CATALOG's own words, and it is deliberately nothing else: no table of synonyms, and above all no list of the
#: words some model happened to write, which is how `agent/prompt.py`'s vision accept lists once ended up able to
#: flatter only the model they were read from. It runs on both sides of every comparison, so the two sides can
#: never disagree about a word, and a name that says the term by a DIFFERENT word (a blade tip is not a knife
#: edge) still does not say it. `tests/test_fold.py` pins both halves of that on a kind no model has ever seen.
def _singular(word: str) -> str:
    if len(word) > 4 and word.endswith("ies"):
        return word[:-3] + "y"
    if len(word) > 4 and word.endswith(("ses", "xes", "zes", "ches", "shes")):
        return word[:-2]
    if len(word) > 3 and word.endswith("s") and not word.endswith("ss"):
        return word[:-1]
    return word


def _words(name: str) -> frozenset[str]:
    return frozenset(_singular(w) for w in str(name or "").lower().split("_") if w)


def kind_terms(kind: str) -> dict[str, frozenset[str]]:
    """The words the catalog itself uses for a kind: the kind's own name, and the mechanism it carries.

    Read from `KIND_MECHANISM` and the kind's own spelling, never typed out here, so it grows when the catalog
    does. `schema.MECHANISMS` is the same list prompt section 3 is generated from, so these are words the model
    was handed rather than words invented for this test."""
    out = {"kind": _words(kind)}
    mech = KIND_MECHANISM.get(kind)
    if mech and mech != "other":
        out["mechanism"] = _words(mech)
    return out


def restates(name: str, kind: str) -> str:
    """"kind" when `name` says the catalog's own kind, "mechanism" when it says the mechanism that kind carries,
    "" when it says neither.

    A name says a term when every word of the term is a word of the name (`short_stub_extension` and
    `short_outlet_stub` both say `short_stub`; `wake_refinement` says `external_domain`'s mechanism `wake`). The
    test is on words, not on a table of synonyms: the vocabulary is the catalog's own. A word counts in the
    singular or the plural (`_singular`), so `preserve_knife_edges` says `knife_edge` and one `s` is not a new
    concept; nothing else is folded, because a table of near-words would be a table of the words one model
    wrote."""
    mine = _words(name)
    if not mine:
        return ""
    for route, term in kind_terms(kind).items():
        if term and term <= mine:
            return route
    return ""


#: The mechanism each catalog kind names (schema.MECHANISMS); `other` never counts as "the same mechanism" in R4.
KIND_MECHANISM: dict[str, str] = {
    "short_stub": "recirculation_at_outlet", "diffuser_angle": "separation", "tilted_circular_mouth": "tilted_mouth_skew",
    "port_resolution": "cell_starvation", "thin_feature": "cell_starvation", "gmsh_size": "cell_starvation",
    "gap_resolution": "layer_collision", "near_touching": "layer_collision", "knife_edge": "layer_collision",
    "symmetry_opportunity": "swirl_no_symmetry", "rotor_topology": "swirl_no_symmetry", "external_domain": "wake",
    "multi_body_external": "tip_gap", "unshared_interface": "thermal_interface_unshared",
    "no_shared_interface": "thermal_interface_unshared", "solid_fluid_pair": "thermal_interface_unshared",
    "skew_repair": "tilted_mouth_skew", "carve_leak_repair": "cell_starvation",
}
#: What acting on the kind does: changes_mesh for extensions, tier drops, repairs and representation choices;
#: changes_bc for role and unit decisions; advisory otherwise (dev plan P4.2: no default that silently does nothing).
KIND_EFFECT: dict[str, str] = {
    "short_stub": "changes_mesh", "tiny_port": "changes_mesh", "cell_cap": "changes_mesh",
    "role_assumed": "changes_bc", "undeclared_opening": "changes_bc", "declared_port_unmatched": "changes_bc",
    "ambiguous_openings": "changes_bc", "unit_unknown": "changes_bc", "unit_implausible": "changes_bc",
    "not_watertight": "changes_mesh", "surface_holes": "changes_mesh", "region_purpose_mismatch": "changes_mesh",
    "nested_bodies": "changes_mesh", "solid_fluid_pair": "changes_mesh", "no_shared_interface": "changes_mesh",
    "unshared_interface": "changes_mesh", "rotor_topology": "changes_mesh", "solid_wall_representation": "changes_mesh",
    "non_manifold_surface": "changes_mesh",
    "tilted_circular_mouth": "changes_mesh", "port_resolution": "changes_mesh", "gap_resolution": "changes_mesh",
    "near_touching": "changes_mesh", "thin_feature": "changes_mesh", "budget_forecast": "changes_mesh",
    "seed_point": "changes_mesh", "gmsh_size": "changes_mesh", "velocity_spread": "changes_mesh", "knife_edge": "changes_mesh",
    "skew_repair": "changes_mesh", "carve_leak_repair": "changes_mesh",
}
#: The thresholds key behind a kind, for provenance; kinds without one are measured facts.
KIND_THRESHOLD: dict[str, str] = {
    "short_stub": "STUB_OK_OVER_D", "short_inlet_run": "STUB_OK_OVER_D", "inlet_run_developing": "INLET_DEVELOPED_OVER_D",
    "tiny_port": "TINY_PORT_FRACTION", "velocity_spread": "VELOCITY_RATIO_MAX", "port_resolution": "PORT_CELLS_MIN",
    "diffuser_angle": "DIFFUSER_ANGLE_MAX_DEG", "role_assumed": "SAME_BORE_BAND", "thin_feature": "THIN_CELLS_MIN",
    "gap_resolution": "GAP_CELLS_MIN", "near_touching": "GAP_CELLS_MIN", "ambiguous_openings": "MANY_CANDIDATES",
    "declared_port_unmatched": "AREA_MATCH_BAND", "non_manifold_surface": "NON_MANIFOLD_EDGES_MIN",
    "rotor_topology": "ROTOR_MIN_BLADES", "tilted_circular_mouth": "TILTED_MOUTH_DEG", "gmsh_size": "PORT_CELLS_MIN",
    "seed_point": "SEED_INSET_OVER_BORE", "unit_unknown": "UNIT_MATCH_BAND", "external_domain": "EXTERNAL_DOWNSTREAM_OVER_L",
}
#: The kinds whose value is calibrated on the corpus rather than a textbook rule (docs/learning_loop.md, 4.3).
CALIBRATED_KINDS: frozenset[str] = frozenset({"tilted_circular_mouth", "budget_forecast", "seed_point", "gmsh_size"})
#: The port_tilt sweep the tilted-mouth rule is proposed from (docs/thresholds.md, section 6).
TILTED_MOUTH_SWEEP: dict[str, Any] = {"source": "eval/calib/sweep.py", "corpus_version": "export learning half, labels v1, split ac3997d4",
                                      "sweep_file": "eval/calib/sweeps/port_tilt_2026-09-09.json", "n": 71, "fires": 32,
                                      "lift": 2.023, "mcc_cv": 0.888, "fitted_at": "2026-09-09", "status": "proposed"}
#: The builder's own budget margin (engines/snappy/planner.py:69, hexera.BUILDER_MARGIN) the budget_forecast target keeps.
#: `budget_margin()` is how the rest of the package reads it: admission 3 of the directive design needs it from
#: outside this module (docs/builder_directives.md 6.3) and a bare public number here is a governed threshold.
_BUDGET_MARGIN = 0.15
#: The sphere a thin cluster's remedy covers, in thicknesses (the reference policy's own radius).
_THIN_SPHERE_OVER_THICKNESS = 20.0


def audience_of(kind: str, representation: str | None = None) -> str:
    """user, builder or info for a kind under a representation: thin_feature on a wall shell's metal is a cost
    note (info), on the fluid side a mesh warning."""
    if kind == "thin_feature" and representation == "wall_shell":
        return "info"
    return KIND_AUDIENCE.get(kind, "info")


def rule_class_of(kind: str) -> str:
    if kind in CALIBRATED_KINDS:
        return "calibrated"
    return "physics_rule" if kind in KIND_THRESHOLD else "measured_fact"


def threshold_of(kind: str, thresholds: Thresholds | None = None) -> dict[str, Any] | None:
    """{key, value} of the threshold behind a kind, None for a measured fact."""
    key = KIND_THRESHOLD.get(kind)
    if not key:
        return None
    return {"key": key, "value": getattr(_T(thresholds), key, None)}


# --- the builder channel: what the platform can be told, in what band, and what an item may claim ----------------
# Read from the platform at `tools.PLATFORM_SHA` and recorded field by field in docs/handover_consumers.md
# section 1; the argument is docs/builder_directives.md. For snappy there is no builder tool loop
# (engines/snappy/spec.py:259 declares a build driver, so agents/builder/invoke.py:112-116 never runs one): the
# only model call on the build path is the planner, and the renderer consumes seven keys from its reply on the
# internal path, six on the external and two on gmsh. An item naming anything else cannot be carried out however
# well it is phrased, so it is a note (a location and a size) and never an instruction.

#: regime -> key -> {band, renderer, default}. `band` is the range the planner's own prompt declares
#: (engines/snappy/planner.py:38 external, :63 internal); `renderer` is the range the renderer does not clamp
#: away (drivers.py:578 floors cells_across_diameter at 8, which is the range a cap-forced value lives in);
#: `default` is what is rendered when the plan says nothing (drivers.py:576-582, snappy_runner.py:500-501,
#: gmsh/driver.py:258-265). The number of keys in a row is the cap on the list for that regime: there are seven
#: knobs, so there are at most seven instructions.
DIRECTIVE_KEYS: dict[str, dict[str, dict[str, Any]]] = {
    "snappy_internal": {
        "cells_across_diameter": {"band": (16, 40), "renderer": (8, 40), "default": 24},
        "surface_level": {"band": (1, 3), "renderer": (1, 10), "default": 2},
        "feature_level": {"band": (1, 4), "renderer": (1, 10), "default": 3},
        "n_layers": {"band": (3, 6), "renderer": (0, 10), "default": 3},
        "first_layer_rel": {"band": (0.2, 0.4), "renderer": (0.2, 0.4), "default": 0.3},
        "quality": {"band": ("balanced", "strict"), "renderer": ("balanced", "strict"), "default": "balanced"},
        "max_cells": {"band": (1, 8_000_000), "renderer": (1, 8_000_000), "default": 4_000_000},
    },
    "snappy_external": {
        "domain_margin": {"band": (0, 50), "renderer": (0, 50), "default": {"up": 2, "down": 4, "side": 2, "vert": 2},
                          "shape": "margins"},
        "reference_length_m": {"band": (1e-6, 1e6), "renderer": (1e-6, 1e6), "default": None},
        # THE TWO KEYS THIS ROW OMITTED. `render_snappy_case` is the external renderer and it reads both:
        # `strategy["surface_level"]` at snappy_runner.py:448 and `strategy["feature_level"]` at :451. The row
        # said no reader consumed them, so `directive_problem` rejected every correct item naming one and
        # `builder_keys_block`'s "every setting the builder reads" was false on this regime.
        #
        # SURFACE LEVEL IS A SEQUENCE HERE and it is not one on the internal path. External reads
        # `int(so[-1])`, so a bare number raises TypeError in the renderer and only the last entry of the pair
        # is the level; internal reads `int(_sl[-1] if isinstance(_sl, (list, tuple)) else _sl)`
        # (drivers.py:665), which takes either. The shape is checked, not assumed: `authoring.py:24` declares
        # `[min, max]` and `snappy_runner.py:550` returns one.
        #
        # NEITHER HAS A DEFAULT AND NEITHER HAS A DECLARED BAND. The level the renderer uses when the plan says
        # nothing is the recommender's own body-sealing floor (`rec["surface_level"][0]`), which is a number
        # about this part and not a constant, so `default` is None and the roster says "no default". The
        # external planner prompt (planner.py:28-43) lists neither key, so there is no band to declare: `band`
        # is (None, None) and `in_declared_band` is False for every value, which is the truth (the value is one
        # the renderer reads and no prompt declared). The renderer range is the hard level cap,
        # `_HARD_MAX_LEVEL = 10`; the case's own floor and afford-level narrow it per part and neither is a
        # constant either.
        "surface_level": {"band": (None, None), "renderer": (1, 10), "default": None, "shape": "level_pair"},
        "feature_level": {"band": (None, None), "renderer": (1, 10), "default": None},
        "n_layers": {"band": (3, 5), "renderer": (0, 10), "default": 3},
        "first_layer_rel": {"band": (0.25, 0.5), "renderer": (0.25, 0.5), "default": 0.35},
        "quality": {"band": ("balanced", "strict"), "renderer": ("balanced", "strict"), "default": "balanced"},
        "max_cells": {"band": (1, 8_000_000), "renderer": (1, 8_000_000), "default": 4_000_000},
    },
    "gmsh": {
        # `size` IS A {mode, value} OBJECT at the driver (engines/gmsh/driver.py:78-90 validates it and rejects
        # anything else; :258-261 reads it), and the band here is the FACTOR band, which is why the mode is part
        # of the check: in `absolute` mode the value is a length in the file's own unit and the factor band says
        # nothing about it. A bare number is admitted as the factor it plainly is, because that is the shape
        # this package's own writer produces (`directive_of`) and the shape `hexera.renderer_default` states
        # the default in.
        "size": {"band": (1e-6, 1.0), "renderer": (1e-6, 1.0), "default": 0.04, "shape": "size_spec"},
        "curvature_nodes": {"band": (8, 64), "renderer": (1, 360), "default": 24},
    },
}
#: The modes `engines/gmsh/driver.py:19` accepts for `size`, and the field names it accepts inside it (:18).
#: `factor` multiplies the bounding diagonal; `absolute` is a length in the file's own unit.
GMSH_SIZE_MODES: tuple[str, ...] = ("factor", "absolute")
GMSH_SIZE_FIELDS: frozenset[str] = frozenset({"mode", "value"})
#: The three classes an item may be, and nothing else (docs/builder_directives.md 6.1). A directive sets one key
#: now; a conditional sets one on a named measured failure; a note is a location and a size with no key.
ITEM_CLASSES: tuple[str, ...] = ("directive", "conditional", "note")
#: The ranking tiers a directive may sit in. T0 is a guard that costs nothing and loses the run when wrong; T1 is
#: a floor, a measured feature under a stated minimum that the key delivers; T2 is a margin, a feature already
#: over its floor that the key improves. A tier is decided by whether the item names an unmet floor, never by
#: which key it uses: `surface_level 1` on a tilted mouth is T1 because the port cap sits under the wall level,
#: while raising `surface_level` for its own sake is T2 and pays the price rule.
DIRECTIVE_TIERS: tuple[str, ...] = ("T0", "T1", "T2")
#: The tier each calibrated builder kind sits in, so a list the model wrote itself is ranked the same way the
#: checker's own is. `budget_forecast` is the guard that loses the run when it is wrong; the other three name a
#: measured feature under a stated minimum. A kind that is not here is a margin and pays the price rule.
DIRECTIVE_TIER_BY_KIND: dict[str, str] = {"budget_forecast": "T0", "port_resolution": "T1", "gmsh_size": "T1",
                                          "tilted_circular_mouth": "T1"}
#: The words the classifier hands the planner as its critique (engines/snappy/judge.py:24-67 `_repair_message`,
#: engines/snappy/flow_gates.py:88). `planner.py:42` and `:65` are the only place either planner prompt instructs
#: obedience, and they are triggered by this text, so a conditional keyed on anything else is keyed on nothing.
CONDITIONAL_TRIGGERS: tuple[str, ...] = ("TIMEOUT", "snappyHexMesh FAILED", "CARVE LEAKED",
                                         "prism LAYERS are inverting cells", "WIDESPREAD skewness",
                                         "exceeds the compute budget")
#: Words that turn a sentence into a prediction about the finished mesh instead of a measurement of the part. A
#: prediction is something the builder can only disagree with; a measurement is the argument for an instruction it
#: can carry out. The builder-facing text carries no outcome and no subject that is the finished mesh.
OUTCOME_WORDS: tuple[str, ...] = ("will", "wont", "would", "fail", "fails", "failed", "failing", "failure",
                                  "poor", "poorly", "badly", "collide", "collides", "diverge", "diverges",
                                  "unmeshable", "degenerate")
OUTCOME_PHRASES: tuple[str, ...] = ("cannot be meshed", "not be meshed", "the mesh comes back", "ends up")
_OUTCOME_WORD = re.compile(r"\b(" + "|".join(OUTCOME_WORDS) + r")\b", re.I)
#: What `MeshWarning.severity` means on this channel: how much of the builder's attention the item is owed, not
#: how bad the mesh will be. Nothing here predicts a mesh. high: a guard or an unmet floor, set the key before
#: anything else. medium: a margin the budget allows, or an action that applies only on a named measured failure.
#: low: a note, a location and a size with nothing to set.
ATTENTION: dict[str, str] = {"T0": "high", "T1": "high", "T2": "medium", "conditional": "medium", "note": "low"}
#: A margin is worth its cells only when it spends a tenth of what is left (docs/builder_directives.md 6.4): an
#: item that costs more cells than it is worth does not belong on a list the builder reads in order. Neither this
#: nor the margin is a governed threshold: `_BUDGET_MARGIN` is read from the platform (planner.py:69) and this one
#: is the agent's own policy, so neither is a physics rule nor a value a sweep fits, which are the two rule
#: classes thresholds.json admits. `budget_margin()` and `price_fraction()` are how the rest of the package reads
#: them (tests/test_thresholds.py holds catalog.py to exactly the governed numbers and nothing else).
_DIRECTIVE_PRICE_FRACTION = 0.10


def budget_margin() -> float:
    """The builder's own budget margin (engines/snappy/planner.py:69): a plan aims to land this far under the cap."""
    return _BUDGET_MARGIN


def price_fraction() -> float:
    """The share of what is left under the cap that a T2 margin may spend (docs/builder_directives.md 6.4)."""
    return _DIRECTIVE_PRICE_FRACTION


def regime_of(engine: str | None, representation: str | None) -> str:
    """The row of DIRECTIVE_KEYS this case reads: gmsh, external snappy or internal snappy. The two snappy paths
    are opposites (on the internal path `surface_level` does not move the wall cell at all, drivers.py:584 with
    snappy_runner.py:634), so a key is never reachable "on snappy": it is reachable on one of the two."""
    if (engine or "snappy") == "gmsh":
        return "gmsh"
    return "snappy_external" if representation == "external" else "snappy_internal"


#: The keys whose value is a COUNT or a REFINEMENT LEVEL, so it is never a length, an angle or a fraction of
#: one. This is a fact about the platform's own keys and their units, not a judgement about any wording: a
#: `MeshSize` field is a bore, a gap, a thickness, a tilt or a run, so an item whose `size` equals the value it
#: sets one of these to has answered HOW BIG with the instruction. `reference_length_m` and gmsh's `size` are
#: deliberately NOT here: the reference length IS the body's own length, and equality there is agreement rather
#: than restatement. `tests/test_directives.py` holds every key in `DIRECTIVE_KEYS` to one side or the other.
COUNT_KEYS: frozenset[str] = frozenset({"n_layers", "max_cells", "surface_level", "feature_level",
                                        "cells_across_diameter", "curvature_nodes"})


def counted_key(key: str | None) -> bool:
    """Does this key take a count or a level, so a length equal to its value is a restatement and not a size?"""
    return bool(key) and key in COUNT_KEYS


def target_field_names() -> frozenset[str]:
    """The names of `MeshTarget`'s own fields, minus the two that are the instruction. A name in here written as
    `target.key` is a field in the wrong slot, not an unknown key."""
    from geometry_agent.agent.schema import MeshTarget
    return frozenset(MeshTarget.model_fields) - {"key", "value"}


def key_row(regime: str) -> list[dict[str, Any]]:
    """The keys a renderer consumes on this regime, each with the range the checker holds a value to and what the
    renderer does when the plan says nothing: one row, read straight off `DIRECTIVE_KEYS`.

    The range printed is `renderer` and not the planner's declared `band`, because `renderer` is the range
    `directive_problem` enforces, and the prompt and the checker say the same thing or one of them is lying
    (CLAUDE.md non-negotiable 8). A cap-forced `cells_across_diameter` lives between the two."""
    return [{"key": k, "renderer": v["renderer"], "default": v["default"], "shape": v.get("shape")}
            for k, v in sorted((DIRECTIVE_KEYS.get(regime) or {}).items())]


#: What each non-scalar shape takes, in the words `directive_problem` refuses in. A key whose value is not a
#: plain number has to say so where the roster is read, or the roster names a setting and hides its shape.
SHAPE_WORDS: dict[str, str] = {
    "margins": "{{up, down, side, vert}}, each {lo} to {hi} body lengths",
    "level_pair": "[min, max] levels, each {lo} to {hi}",
    "size_spec": "{{mode, value}}, mode factor or absolute, a factor {lo} to {hi} (a bare number is the factor)",
}


def shape_words(key: str, regime: str) -> str:
    """How this key's value is shaped, in one clause, or "" for a plain number in a range."""
    row = (DIRECTIVE_KEYS.get(regime) or {}).get(key) or {}
    template = SHAPE_WORDS.get(str(row.get("shape") or ""))
    if not template:
        return ""
    lo, hi = row["renderer"]
    return template.format(lo=lo, hi=hi)


def directive_key_readable(key: str | None, regime: str) -> bool:
    """Does this key have a reader at all on this regime? Admission 1, and the one admission whose failure is a
    demotion rather than a rejection: the model wrote a real measurement about a feature the platform gives it no
    control over, so the item keeps its location and loses its instruction."""
    return bool(key) and key in (DIRECTIVE_KEYS.get(regime) or {})


def directive_problem(key: str | None, value: Any, regime: str) -> str:
    """"" when the builder can carry this key and value out on this regime; the reason it cannot otherwise.

    Admission 1 and 2 of docs/builder_directives.md 6.3: the key is one the renderer reads for this engine and
    regime, and the value is one the renderer does not clamp away. A value inside `renderer` but outside the
    planner's declared `band` is admitted, because that is where a cap-forced `cells_across_diameter` lives
    (14 on bend_elbow_013), and the item states the cap that forced it."""
    row = DIRECTIVE_KEYS.get(regime) or {}
    if not key:
        return "names no platform key"
    if key not in row:
        if key in target_field_names():
            # `level_delta`, `gmsh_size_value`, `layers`, `extension_length` and `cells_across` are FIELDS of
            # `MeshTarget`, and the rejection used to offer them in the same clause as the platform keys, joined
            # by "or": 93 of the 197 keys written in the 176-draw run were one of these five, `level_delta` 45 of
            # them on its own. Naming the slot is the whole correction, so the sentence names it.
            return (f"names {key!r} as its KEY, and {key} is a FIELD of target, not a platform key: write it as "
                    f"target.{key} and the item is a note, a place and a size the builder reads and nothing it "
                    f"sets. The keys a reader consumes on {regime} at platform {_platform_sha()[:8]} are "
                    f"{', '.join(sorted(row))}")
        return (f"names {key!r}, which no reader consumes on {regime} at platform {_platform_sha()[:8]}; the keys that "
                f"have one are {', '.join(sorted(row))}")
    if value is None:
        return f"names {key} with no value"
    lo, hi = row[key]["renderer"]
    shape = row[key].get("shape")
    if key == "quality":
        return "" if value in (lo, hi) else f"{key}={value!r} is not {lo!r} or {hi!r}"
    if shape == "margins":
        if not isinstance(value, dict) or not value:
            return f"{key} takes {{up, down, side, vert}} in body lengths, not {value!r}"
        bad = [k for k, v in value.items() if not isinstance(v, (int, float)) or isinstance(v, bool) or not lo <= v <= hi]
        return f"{key} entries {sorted(bad)} are outside {lo} to {hi} body lengths" if bad else ""
    if shape == "level_pair":
        return _level_pair_problem(key, value, lo, hi)
    if shape == "size_spec":
        return _size_spec_problem(key, value, lo, hi)
    if isinstance(value, str) or isinstance(value, bool) or not isinstance(value, (int, float)):
        return f"{key}={value!r} is not a number"
    return "" if lo <= value <= hi else f"{key}={value:g} is outside the range the renderer reads, {lo} to {hi}"


def _level_pair_problem(key: str, value: Any, lo: float, hi: float) -> str:
    """`surface_level` on the external path, where the renderer reads `int(so[-1])` (snappy_runner.py:448).

    A bare number is not readable there: `so[-1]` on an int raises, so the value would take the renderer down
    rather than be clamped away, and that is a harder refusal than an out-of-range number and not a softer one.
    One entry or two are both read (the last is the level); two out of order are not a range."""
    if isinstance(value, bool) or isinstance(value, (int, float)) or isinstance(value, (str, bytes)):
        return (f"{key}={value!r} is a bare value and on this regime the renderer reads {key}[-1] "
                f"(snappy_runner.py:448), so write it as [min, max] levels, each {lo} to {hi}")
    if not isinstance(value, (list, tuple)) or not 1 <= len(value) <= 2:
        return f"{key} takes [min, max] levels here, one entry or two, not {value!r}"
    bad = [v for v in value if isinstance(v, bool) or not isinstance(v, (int, float)) or not lo <= v <= hi]
    if bad:
        return f"{key} entries {bad!r} are outside the range the renderer reads, {lo} to {hi}"
    if len(value) == 2 and value[1] < value[0]:
        return f"{key}={list(value)!r} is not [min, max]: the second level is below the first"
    return ""


def _size_spec_problem(key: str, value: Any, lo: float, hi: float) -> str:
    """gmsh `size`, which the driver validates as {mode, value} (engines/gmsh/driver.py:78-90).

    The band is the FACTOR band, so it is applied only in factor mode; in `absolute` mode the value is a length
    in the file's own unit and the only thing that can be said about it here is that it is positive. A bare
    number is the factor, which is the shape the gmsh driver reads its own default as; this package's own
    writer (`directive_of`) and `hexera.renderer_default` both state it as {mode, value}, because the emulator
    reads the mode."""
    if isinstance(value, dict):
        unknown = sorted(set(value) - GMSH_SIZE_FIELDS)
        if unknown:
            return f"{key} has unknown field(s) {unknown}; it takes {{mode, value}} and nothing else"
        mode = value.get("mode", GMSH_SIZE_MODES[0])
        if mode not in GMSH_SIZE_MODES:
            return f"{key}.mode={mode!r} is not one of {list(GMSH_SIZE_MODES)}"
        inner = value.get("value")
        if inner is None or isinstance(inner, bool) or not isinstance(inner, (int, float)):
            return f"{key}.value={inner!r} is not a number"
        if mode == "absolute":
            return "" if inner > 0 else f"{key}.value={inner:g} is not a positive length"
        return "" if lo <= inner <= hi else f"{key}.value={inner:g} is outside the factor range the renderer reads, {lo} to {hi}"
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return f"{key}={value!r} is neither a factor nor {{mode, value}}"
    return "" if lo <= value <= hi else f"{key}={value:g} is outside the factor range the renderer reads, {lo} to {hi}"


def in_declared_band(key: str, value: Any, regime: str) -> bool:
    """Is the value inside the band the planner's own prompt states, as opposed to the wider range the renderer
    reads? A cap-forced value sits outside it and says so.

    False for a key whose prompt declares no band at all (`band` is (None, None)): the value is one the renderer
    reads and no prompt declared, and saying it is inside a band nobody wrote would be the lie."""
    row = (DIRECTIVE_KEYS.get(regime) or {}).get(key)
    if not row:
        return False
    lo, hi = row["band"]
    if lo is None or hi is None:
        return False
    if key == "quality":
        return value in (lo, hi)
    shape = row.get("shape")
    if shape == "margins":
        return isinstance(value, dict) and all(isinstance(v, (int, float)) and lo <= v <= hi for v in value.values())
    if shape == "size_spec" and isinstance(value, dict):
        value = value.get("value") if value.get("mode", GMSH_SIZE_MODES[0]) == "factor" else None
    if shape == "level_pair":
        return (isinstance(value, (list, tuple)) and bool(value)
                and all(isinstance(v, (int, float)) and not isinstance(v, bool) and lo <= v <= hi for v in value))
    return isinstance(value, (int, float)) and not isinstance(value, bool) and lo <= value <= hi


def trigger_problem(trigger: str | None) -> str:
    """"" when a conditional keys on words the classifier actually uses; the reason it does not otherwise."""
    if not (trigger or "").strip():
        return "carries no trigger; a conditional names the phrase the critique will use"
    if not any(p.lower() in trigger.lower() for p in CONDITIONAL_TRIGGERS):
        return (f"keys on {trigger!r}, which the classifier never says; the phrases it hands the planner are "
                + "; ".join(CONDITIONAL_TRIGGERS))
    return ""


def outcome_claim(text: str) -> str:
    """The word that makes `text` a prediction about the finished mesh, "" when it reports a measurement."""
    low = (text or "").lower()
    for phrase in OUTCOME_PHRASES:
        if phrase in low:
            return phrase
    m = _OUTCOME_WORD.search(text or "")
    return m.group(0).lower() if m else ""


def attention_of(item_class: str, tier: str | None = None) -> str:
    """The severity a builder item carries: how much attention it needs (ATTENTION), never how bad it will be."""
    if item_class == "directive":
        return ATTENTION.get(tier or "T2", "medium")
    return ATTENTION.get(item_class, "low")


def price_admits(cost_cells: int | float | None, forecast_without: int | float | None, cell_cap: int | None,
                 tier: str | None = None, margin: float = _BUDGET_MARGIN) -> bool | None:
    """Is a margin worth its cells? `cost_cells <= 0.10 x (0.85 x cap - forecast_without_it)`. None when the cost
    or the cap is unknown, which is not a pass: an item whose cost nobody knows is demoted to a note. T0 and T1
    are not priced - a guard and a floor may spend the whole headroom - but they still have to fit under the
    margin, which is admission 3 and is checked with the forecast, not here."""
    if cost_cells is None or not cell_cap:
        return None
    if tier in ("T0", "T1"):
        return True
    if cost_cells <= 0:
        return True
    headroom = (1.0 - margin) * float(cell_cap) - float(forecast_without or 0.0)
    return float(cost_cells) <= _DIRECTIVE_PRICE_FRACTION * headroom


def _platform_sha() -> str:
    from geometry_agent.agent.tools import PLATFORM_SHA
    return PLATFORM_SHA


def default_engine_for(purpose: str) -> str:
    """The engine a purpose runs on when none is named: gmsh for structural, snappy otherwise (hexera.default_engine)."""
    return "gmsh" if purpose == "structural" else "snappy"


#: The engine words a spec writes ("Engine: gmsh", "snappyHexMesh"); cfmesh is framed like snappy (a hex mesher).
ENGINE_IN_BRIEF = re.compile(r"\bgmsh\b|snappy\s*hex\s*mesh|\bsnappy\b|\bcfmesh\b", re.I)


def engine_from_brief(brief: str | None, purpose: str) -> str:
    """The engine the builder kinds are framed for: the one the brief names, else the purpose's default."""
    m = ENGINE_IN_BRIEF.search(brief or "")
    if m:
        return "gmsh" if m.group(0).lower() == "gmsh" else "snappy"
    return default_engine_for(purpose)


def remedy_target(kind: str, measurement: dict[str, Any], frame: dict[str, Any] | None,
                  thresholds: Thresholds | None = None) -> dict[str, Any]:
    """The kind's remedy in the builder's knobs (schema 3 MeshWarning.target): tilted mouth -> level_delta 0 and a
    one-bore sphere at the mouth; port_resolution -> the cells_across_diameter floor that gives the port
    PORT_CELLS_MIN builder cells; gap_resolution and near_touching -> the level delta that puts GAP_CELLS_MIN wall
    cells across the gap; thin_feature -> the level delta for THIN_CELLS_MIN cells across the thickness and a
    sphere of _THIN_SPHERE_OVER_THICKNESS thicknesses; seed_point -> the seed; budget_forecast -> max_cells and the
    cells_across that fits; gmsh_size -> the size value. Empty for a kind with no builder remedy."""
    T = _T(thresholds)
    from geometry_agent.agent import tools
    m = measurement or {}
    frame = frame or {}
    wall_cell = float(frame.get("wall_cell") or 0.0)
    inlet_bore = float(frame.get("bore") or 0.0)

    def level_for(feature: float | None, cells_min: float) -> int | None:
        if not feature or feature <= 0 or wall_cell <= 0:
            return None
        need = cells_min * wall_cell / feature
        return max(0, int(math.ceil(math.log2(need)))) if need > 1.0 else 0

    out: dict[str, Any] = {}
    if kind == "tilted_circular_mouth":
        out["level_delta"] = 0
        bore = m.get("bore")
        centroid = m.get("centroid")
        if bore and centroid:
            out["sphere"] = {"anchor": [float(c) for c in centroid], "radius": float(bore)}
    elif kind == "port_resolution":
        feature = m.get("min_dimension") or m.get("hydraulic_diameter")
        if feature and inlet_bore > 0:
            need = int(math.ceil(T.PORT_CELLS_MIN * inlet_bore / float(feature)))
            out["cells_across"] = max(tools.BUILDER_CELLS_ACROSS_DEFAULT, need)
    elif kind in ("gap_resolution", "near_touching"):
        gap = m.get("min_gap_between_regions") if kind == "gap_resolution" else m.get("min_gap")
        delta = level_for(gap, T.GAP_CELLS_MIN)
        if delta is not None:
            out["level_delta"] = delta
    elif kind == "thin_feature":
        t = m.get("thickness_min")
        delta = level_for(t, T.THIN_CELLS_MIN)
        if delta is not None:
            out["level_delta"] = delta
        if t and m.get("centroid"):
            out["sphere"] = {"anchor": [float(c) for c in m["centroid"]], "radius": float(t) * _THIN_SPHERE_OVER_THICKNESS}
    elif kind == "seed_point" and m.get("seed_point"):
        out["seed_point"] = [float(c) for c in m["seed_point"]]
    elif kind == "budget_forecast":
        if m.get("cell_cap"):
            out["max_cells"] = int(m["cell_cap"])
        if m.get("fits_at_cells_across"):
            out["cells_across"] = int(m["fits_at_cells_across"])
    elif kind == "gmsh_size":
        diag, feature = m.get("diagonal"), m.get("min_dimension")
        if diag and feature:
            out["gmsh_size_value"] = round(min(tools.GMSH_SIZE_FACTOR, float(feature) / T.PORT_CELLS_MIN / float(diag)), 6)
    return out


#: `budget_fit` results per (file, representation, engine, inlet, cap): the walk is arithmetic, and both the
#: builder rules and the checker's channel ask for the same answer on the same part.
_BUDGET_FIT: dict[tuple, dict[str, Any]] = {}


def budget_fit(facts: GeometryFacts, rep: Representation, engine: str, inlet_id: str | None,
               cell_cap: int | None) -> dict[str, Any]:
    """The strategy the customer's cap forces before anything else is decided: `{}` when the renderer's own
    defaults already fit, else `{"cells_across_diameter": n}`, the largest value that lands under the cap by the
    builder's own margin.

    This is the T0 guard, and it is the baseline every other item is priced against. Pricing a margin against the
    renderer's default instead would refuse every margin on a part whose default is over the cap, which is the
    part that needs them most: `mini_housing_001` forecasts 2.29M against a 2M cap at the default and 1.63M at
    the value the cap forces, and `quality strict` costs nothing in either."""
    from geometry_agent.agent import tools
    key = (getattr(facts, "sha256", ""), rep, engine, inlet_id, int(cell_cap or 0))
    if key in _BUDGET_FIT:
        return dict(_BUDGET_FIT[key])
    out: dict[str, Any] = {}
    if engine == "snappy" and cell_cap and rep != "external":
        try:
            high = int(tools.estimate_builder_cells(facts, None, rep, engine, inlet_id)["cells_high"])
            across = tools.BUILDER_CELLS_ACROSS_DEFAULT
            while high > (1.0 - _BUDGET_MARGIN) * cell_cap and across > tools.BUILDER_CELLS_ACROSS_MIN:
                across = max(tools.BUILDER_CELLS_ACROSS_MIN, min(across - 1, int(across * 0.9)))
                high = int(tools.estimate_builder_cells(facts, {"cells_across_diameter": across}, rep, engine,
                                                        inlet_id)["cells_high"])
            if across != tools.BUILDER_CELLS_ACROSS_DEFAULT:
                out["cells_across_diameter"] = across
        except (ValueError, ZeroDivisionError, KeyError, AttributeError, TypeError, StopIteration):
            out = {}
    _BUDGET_FIT[key] = dict(out)
    return out


def directive_of(kind: str, measurement: dict[str, Any], frame: dict[str, Any] | None, regime: str,
                 thresholds: Thresholds | None = None) -> dict[str, Any] | None:
    """The kind's remedy as ONE key the platform reads on this regime, with the tier that ranks it; None when the
    kind has no reachable key here and the item is therefore a note.

    This is `remedy_target` said in the builder's own controls rather than in the schema's wish list. The four
    that land: `port_resolution` and `budget_forecast` both move `cells_across_diameter` (a floor and a
    cap-forced ceiling, and they can disagree - the cap wins, and the residual is the user's `cell_cap`
    question); `gmsh_size` moves `size`; `tilted_circular_mouth` moves `surface_level` to 1, which is the
    reachable form of the `level_delta 0` the schema asks for, because `port_level = max(1, smin - 1)`
    (snappy_runner.py:636) puts the port cap at the wall level there. That last one holds only while the
    emulator reports `deficit == 0` (102 of 102 measured internal cases), so the measurement carries the deficit
    and the directive is withheld when it is not zero.

    Everything else - a sphere, a box, an extension, a seed point, a level delta - names a field no reader
    consumes at this platform sha (283 of 361 targets in the last run did), so it stays where it is measured and
    the item is a note."""
    T = _T(thresholds)
    m = measurement or {}
    legacy = remedy_target(kind, m, frame, T)

    def reachable(d: dict[str, Any] | None) -> dict[str, Any] | None:
        """None when the value the floor asks for is one the renderer would clamp away.

        A floor that cannot be met inside the key's own range is not an instruction, it is the measurement and
        the cell-cap question: `pipe_with_drain`'s drain needs `cells_across_diameter` 81 against a range that
        stops at 40. Withholding it here is what keeps the checker from writing a value it would then reject,
        which on that part cost the stand-in two rejections and the plan."""
        return d if d and not directive_problem(d["key"], d["value"], regime) else None

    if kind == "port_resolution" and legacy.get("cells_across") and regime == "snappy_internal":
        return reachable({"key": "cells_across_diameter", "value": int(legacy["cells_across"]),
                          "tier": DIRECTIVE_TIER_BY_KIND["port_resolution"]})
    if kind == "budget_forecast" and regime in ("snappy_internal", "snappy_external"):
        across = legacy.get("cells_across")
        if across and regime == "snappy_internal":
            return reachable({"key": "cells_across_diameter", "value": int(across), "tier": DIRECTIVE_TIER_BY_KIND[kind]})
        return None
    if kind == "gmsh_size" and legacy.get("gmsh_size_value") and regime == "gmsh":
        return reachable({"key": "size", "value": float(legacy["gmsh_size_value"]), "tier": DIRECTIVE_TIER_BY_KIND[kind]})
    if kind == "tilted_circular_mouth" and regime == "snappy_internal" and m.get("deficit") == 0:
        return reachable({"key": "surface_level", "value": 1, "tier": DIRECTIVE_TIER_BY_KIND[kind]})
    return None


def _T(thresholds: Thresholds | None) -> Thresholds:
    """The thresholds a rule reads: the ones passed in, else the values in force."""
    return thresholds if thresholds is not None else current_thresholds()


_WORDS = {0: "zero", 1: "one", 2: "two", 3: "three", 4: "four", 5: "five", 6: "six", 7: "seven", 8: "eight", 9: "nine",
          10: "ten", 11: "eleven", 12: "twelve"}


def _word(x: float) -> str:
    """A small whole threshold in words for the rule text ("three cells"); digits otherwise."""
    n = int(round(x))
    if abs(x - n) > 1e-9:
        return f"{x:g}"
    return _WORDS.get(n, str(n))


def _surface_cell(facts: GeometryFacts, fidelity: Fidelity) -> float:
    est = next(e for e in facts.cell_estimates if e.tier == fidelity)
    levels = {"draft": 1, "standard": 2, "max": 3}[fidelity]
    return est.base_size / (2**levels)


TINY_PORT_FRACTION = 0.15
HOLE_TUBULARITY_MAX = 0.3
ROTOR_MIN_BLADES = 3
#: An inlet run at or above STUB_OK_OVER_D but under this is still developing: stated once, never a decision.
INLET_DEVELOPED_OVER_D = 10.0
#: A port whose bore holds fewer surface cells than this is under-resolved at the tier.
PORT_CELLS_MIN = 8.0
#: A conical diffuser steeper than this half angle separates; the outlet run must contain the reattachment.
DIFFUSER_ANGLE_MAX_DEG = 7.0
#: Two ports whose bores match within this are interchangeable: an inlet/outlet assignment between them is an assumption.
SAME_BORE_BAND = 0.02
#: Non-manifold edges are a decision (a baffle, a duplicated patch) from this count, or this fraction of the faces,
#: upward; below that they are the odd seam every large real export carries.
NON_MANIFOLD_EDGES_MIN = 12
NON_MANIFOLD_EDGE_FRACTION = 1e-4
#: The highest rotational order tested; a body that passes it is axisymmetric (a pipe, a disc), not bladed.
AXISYMMETRIC_ORDER = 12
BLADE_THICKNESS_OF_DIAG = 0.05
#: A thin cluster under this many surface cells across is high severity (nothing is meshed there).
THIN_CELLS_HIGH = 1.0
#: The refinement target across a near-touching gap: the gap over this.
GAP_TARGET_DIVISOR = 4.0
#: The far-field box an external case needs, in body lengths.
EXTERNAL_UPSTREAM_OVER_L = 5.0
EXTERNAL_DOWNSTREAM_OVER_L = 15.0
EXTERNAL_LATERAL_OVER_L = 5.0
#: A circular mouth tilted this many degrees or more off the nearest coordinate axis is cut stair-stepped by
#: snappy's axis-aligned grid. Read by the facts packet (tools.facts_packet) through thresholds.current(); a
#: calibrated key, proposed from eval/calib/sweeps/port_tilt_2026-09-09.json, not yet a catalog rule.
TILTED_MOUTH_DEG = 0.5


def _ports(facts: GeometryFacts):
    return [o for o in facts.openings if o.classification == "port_candidate"]


#: A ring whose annulus is thinner than this fraction of its bore is the end of a wall (a pipe wall, a duct's
#: sheet metal); wider, it is the annular end face of a fluid passage around a hub.
WALL_SHELL_ANNULUS_FRACTION = 0.15
#: An inner body's end cap counts as sitting in a ring's plane within this fraction of the bore along the normal.
INNER_CAP_PLANE_TOL = 0.05
#: The seed point suggested for carving sits this many bores inside the inlet ring.
SEED_INSET_OVER_BORE = 0.4
BRIEF_CARVE = re.compile(r"carve (?:the|out|a)|closed wall|wall solid|body surface|solid wall|sheet[- ]metal|pipe wall|the metal", re.I)
BRIEF_FLUID = re.compile(r"fluid (?:region|domain|volume)|already carved|flow region itself|fluid-domain", re.I)

Representation = Literal["fluid_domain", "wall_shell", "annular_fluid", "external", "unknown"]


def _outer_region_ids(facts: GeometryFacts) -> set[str]:
    return {r.id for r in facts.regions if not r.nested_in}


def _annulus_fraction(o) -> float:
    """Half the difference between a ring's outer and bore diameters, over the bore: the wall's thickness for a
    pipe wall, the radial gap for an annular passage."""
    if not o.bore_diameter or o.bore_diameter <= 0:
        return 0.0
    return max(0.0, (o.hydraulic_diameter - o.bore_diameter) / 2.0) / o.bore_diameter


def inner_caps(facts: GeometryFacts, ring, thresholds: Thresholds | None = None) -> list:
    """End caps of other bodies that sit in a ring's plane inside its bore: the centre body of an annular
    passage. The port is then the bore minus those caps."""
    T = _T(thresholds)
    if ring.kind != "ring" or not ring.bore_diameter:
        return []
    r = ring.bore_diameter / 2.0
    out = []
    for o in facts.openings:
        if o.id == ring.id or o.kind != "cap" or o.region_id == ring.region_id:
            continue
        d = [a - b for a, b in zip(o.centroid, ring.centroid)]
        along = abs(sum(x * n for x, n in zip(d, ring.normal)))
        lateral = math.sqrt(max(0.0, sum(x * x for x in d) - along * along))
        if along <= T.INNER_CAP_PLANE_TOL * ring.bore_diameter and lateral <= r and abs(sum(a * b for a, b in zip(o.normal, ring.normal))) > 0.9:
            out.append(o)
    return out


def port_area(facts: GeometryFacts, o, rep: Representation | None = None, thresholds: Thresholds | None = None) -> float:
    """The area flow crosses at an opening: a cap's face; on a wall shell a ring's bore minus any inner body's
    end cap (the cavity's mouth); on an annular passage the ring face itself (the annulus between the hub and
    the outer wall; a ring's `area` is its outer disc)."""
    T = _T(thresholds)
    if o.kind == "ring" and o.bore_diameter:
        bore = math.pi / 4 * o.bore_diameter ** 2
        if rep is None:
            rep = "annular_fluid" if _annulus_fraction(o) >= T.WALL_SHELL_ANNULUS_FRACTION else "wall_shell"
        if rep == "annular_fluid":
            return max(0.0, o.area - bore)
        return max(0.0, bore - sum(c.area for c in inner_caps(facts, o, T)))
    return o.area


#: A boss's end face sits within this many of its own diameters of the plate it pierces (a plenum nozzle
#: 0.3 bores tall, a cyclone's vortex finder a diameter or two above the roof). Governed like every other
#: number here: the value in force is thresholds.json's, read as T.PIERCE_REACH_OVER_CAP_D.
PIERCE_REACH_OVER_CAP_D = 3.0
#: A cap coaxial with a ring (lateral offset under this fraction of the bore) is the closed end of the ring's
#: own passage when it sits more than one bore behind the ring; `_inner_step` reads coaxial the same way.
COAXIAL_OVER_BORE = 0.1
#: A ring whose outer boundary equals another ring's bore within this band sits inside that bore (a step).
INNER_STEP_BORE_BAND = 0.05


def _outer_diameter(o) -> float:
    """A ring's outer size as an equivalent diameter (the disc with its outer face's area), the measure
    `bore_diameter` is written in. A rectangular duct's hydraulic diameter is under its equivalent one, so a
    flange shoulder's bore compared against a hydraulic outer never lay between the end ring's bore and its
    outer (the hvac elbow's flange backs read as ports). Equal to the hydraulic diameter on a circle."""
    if o.area and o.area > 0:
        return math.sqrt(4.0 * o.area / math.pi)
    return o.hydraulic_diameter or 0.0


def _pierced_ring(facts: GeometryFacts, ring, thresholds: Thresholds | None = None) -> bool:
    """A plate pierced by a boss of its own body (a plenum's top face pierced by the inlet nozzle, a nut's face
    with the bolt end recessed in its hole): a cap of the same body, parallel to the ring, no wider than 1.25
    bores, within one ring diameter laterally and within PIERCE_REACH_OVER_CAP_D cap diameters along the
    normal. Such a ring is a pierced wall, not the end of a passage. Two rings it never names (2026-09-09, the
    four manifold export cases whose inlet ring saw its own header's closed end 2.7 to 3.2 bores behind it): a
    pipe wall's end ring, whose annulus is under WALL_SHELL_ANNULUS_FRACTION of its bore (the hole is the
    passage, whatever sits behind it), and a ring whose only boss is a coaxial cap more than one bore behind it
    (the far end of a blind header). Added 2026-09-09 for the complex self-check (plenum_box_nozzles_0p3d)."""
    if ring.kind != "ring" or not ring.bore_diameter:
        return False
    T = _T(thresholds)
    if _annulus_fraction(ring) < T.WALL_SHELL_ANNULUS_FRACTION:
        return False
    for o in facts.openings:
        if o.id == ring.id or o.kind != "cap" or o.region_id != ring.region_id or not o.hydraulic_diameter:
            continue
        if abs(sum(a * b for a, b in zip(o.normal, ring.normal))) < 0.9 or o.hydraulic_diameter > 1.25 * ring.bore_diameter:
            continue
        d = [a - b for a, b in zip(o.centroid, ring.centroid)]
        signed = sum(x * n for x, n in zip(d, ring.normal))
        along = abs(signed)
        lateral = math.sqrt(max(0.0, sum(x * x for x in d) - along * along))
        if along > T.PIERCE_REACH_OVER_CAP_D * o.hydraulic_diameter or lateral > ring.hydraulic_diameter:
            continue
        if signed < -ring.bore_diameter and lateral <= T.COAXIAL_OVER_BORE * ring.bore_diameter:
            continue  # the closed far end of the ring's own bore, behind the mouth: a blind passage, not a boss
        return True
    return False


def _flange_shoulder(ring, rings):
    """The flange shoulder behind a flanged end ring, or None: a ring of the same body facing the other way,
    coaxial, within one outer diameter behind the mouth, with the same outer diameter and a bore between this
    ring's bore and its outer diameter (the pipe's outside diameter). Outer sizes are equivalent diameters
    (`_outer_diameter`), so a rectangular flange (the hvac elbow's) is read like a round one. Added 2026-09-09
    for the complex self-check (tee_wall_flanged_filleted)."""
    if not ring.bore_diameter or not ring.hydraulic_diameter:
        return None
    outer = _outer_diameter(ring)
    if outer <= 0:
        return None
    for b in rings:
        if b.id == ring.id or b.region_id != ring.region_id or not b.bore_diameter:
            continue
        if sum(a * c for a, c in zip(b.normal, ring.normal)) > -0.9:
            continue
        d = [p - q for p, q in zip(b.centroid, ring.centroid)]
        along = -sum(x * n for x, n in zip(d, ring.normal))
        lateral = math.sqrt(max(0.0, sum(x * x for x in d) - along * along))
        if not (0.0 < along <= outer) or lateral > 0.1 * outer:
            continue
        if abs(_outer_diameter(b) / outer - 1.0) > 0.1:
            continue
        if ring.bore_diameter < b.bore_diameter < outer:
            return b
    return None


def _inner_step(ring, rings, thresholds: Thresholds | None = None):
    """The ring this ring is a step inside, or None: a ring of the same body facing the same way (toward the
    mouth: the metal is behind a step, the cavity in front of it), coaxial, whose bore is this ring's outer
    boundary (equivalent diameters within INNER_STEP_BORE_BAND), with this ring behind it, inside the passage.
    That is the shoulder where a bore steps down (tee_wye_015's run, 259.8 to 234.5 mm at x 478): a wall face
    inside the cavity, never a port. The far end ring of a thin tube faces the other way and is not one, even
    when its outside happens to equal the near end's bore. Added 2026-09-09 with the pierced-ring fix, which
    stopped reading such a step as pierced by the small faces behind it."""
    if not ring.bore_diameter:
        return None
    outer = _outer_diameter(ring)
    if outer <= 0:
        return None
    T = _T(thresholds)
    for b in rings:
        if b.id == ring.id or b.region_id != ring.region_id or not b.bore_diameter:
            continue
        if sum(p * q for p, q in zip(b.normal, ring.normal)) < 0.9:
            continue
        if abs(outer / b.bore_diameter - 1.0) > T.INNER_STEP_BORE_BAND:
            continue
        d = [p - q for p, q in zip(ring.centroid, b.centroid)]
        along = sum(x * n for x, n in zip(d, b.normal))
        lateral = math.sqrt(max(0.0, sum(x * x for x in d) - along * along))
        # behind the mouth by more than a thousandth of its bore: two concentric annuli in one plane (a face
        # split by the exporter) are the same face, not a step
        if along < -1e-3 * b.bore_diameter and lateral <= T.COAXIAL_OVER_BORE * b.bore_diameter:
            return b
    return None


def _ring_exclusions(facts: GeometryFacts, thresholds: Thresholds | None = None) -> tuple[list, dict[str, str]]:
    """The outer bodies' rings with a bore, and why the ring rules take one out of the ports: `shoulder` (a
    flange's back face, `_flange_shoulder`), `pierced` (a plate a boss passes through, `_pierced_ring`), `step`
    (a shoulder inside a bore, `_inner_step`). Rings not in the map are passage ends that can be ports."""
    outer = _outer_region_ids(facts)
    rings = [o for o in facts.openings if o.kind == "ring" and o.bore_diameter and o.region_id in outer]
    why: dict[str, str] = {}
    for o in rings:
        if _pierced_ring(facts, o, thresholds):
            why[o.id] = "pierced"
        elif _inner_step(o, rings, thresholds) is not None:
            why[o.id] = "step"
    # a flange is read among the passage ends: a pierced plate behind another (a plenum's two faces) is not one
    ends = [o for o in rings if o.id not in why]
    for o in ends:
        b = _flange_shoulder(o, ends)
        if b is not None:
            why.setdefault(b.id, "shoulder")
    return rings, why


#: Formats the CAD kernel transfers to millimetres whatever the file's header says (`hexera.OCC_TRANSFER_FORMATS`,
#: spelled again here because `hexera` imports this module).
_MM_FORMATS = ("step", "stp", "iges", "igs")
_MM_PER_UNIT = {"mm": 1.0, "cm": 10.0, "m": 1000.0, "in": 25.4, "ft": 304.8}


def mm_per_file_unit(facts: GeometryFacts, unit: str | None = None) -> float | None:
    """How many millimetres one of the file's own numbers is, or None when nobody knows. A STEP or IGES is
    transferred in millimetres; any other format is what its confirmed unit (`unit`) or its own declaration says."""
    if str(facts.source_format or "").lower().lstrip(".") in _MM_FORMATS:
        return 1.0
    for u in (unit, getattr(facts.units, "declared", None)):
        if u in _MM_PER_UNIT:
            return _MM_PER_UNIT[u]
    return None


def in_file_units(declared: list[dict] | None, facts: GeometryFacts, unit: str | None = None) -> list[dict] | None:
    """The customer's port rows with every location and size in the FILE'S OWN NUMBERS, which is what `near`,
    `area` and `bore_diameter` mean on this side (they are compared with `opening.centroid` and `opening.area`).

    WHY (work/z-chain NEEDS 4, the platform's NEEDS 8). Intake holds a row's point as `near_mm` and its size as
    `diameter_mm` or `area_mm2`, in millimetres, and this side read only `near` and `area`, so a port the customer
    declared on the platform claimed nothing here, and a row written in millimetres on a file in metres was
    compared a thousand times off. A millimetre row is converted when the file's unit is known and left without a
    location when it is not: a point in the wrong unit is worse than no point, because it still matches something."""
    if not declared:
        return declared
    scale = mm_per_file_unit(facts, unit)
    out: list[dict] = []
    for row in declared:
        if not isinstance(row, dict):
            out.append(row)
            continue
        r = dict(row)
        if scale:
            if not r.get("near") and r.get("near_mm"):
                r["near"] = [float(c) / scale for c in r["near_mm"]]
            if not r.get("area") and r.get("area_mm2"):
                r["area"] = float(r["area_mm2"]) / (scale * scale)
            if not r.get("bore_diameter") and (r.get("bore_diameter_mm") or r.get("diameter_mm")):
                r["bore_diameter"] = float(r.get("bore_diameter_mm") or r.get("diameter_mm")) / scale
            if not r.get("area") and r.get("bore_diameter"):
                r["area"] = 3.141592653589793 * float(r["bore_diameter"]) ** 2 / 4.0
        out.append(r)
    return out


def _declared_claims(facts: GeometryFacts, kept: list, excluded: list, declared: list[dict] | None,
                     rep: Representation | None, thresholds: Thresholds | None = None) -> list:
    """The excluded rings a declared port claims by size or location, through the pairing `_match` uses with
    the kept candidates offered first: a declared port that matches an opening is a port whatever the ring
    rules say (the export corpus declares every carve case's ring ports by position and bore). A declaration
    with neither `near` nor `area` claims nothing here; a row in millimetres is read through `in_file_units`."""
    located = [d for d in (in_file_units(declared, facts) or []) if d.get("near") or d.get("area")]
    if not located or not excluded:
        return []
    pairs: dict[str, dict] = {}
    _match(facts, list(kept) + list(excluded), located, rep, thresholds, pairs)
    return [o for o in excluded if o.id in pairs]


def _wall_annulus_fraction(ring, rings) -> float:
    """A ring's annulus over its bore, read behind a flange when the ring has one: a flange thickens the end
    ring but not the wall, so the wall is the shoulder's bore (the pipe's outside diameter) minus this ring's
    bore, and that is what WALL_SHELL_ANNULUS_FRACTION judges."""
    f = _annulus_fraction(ring)
    b = _flange_shoulder(ring, rings)
    if b is not None:
        f = min(f, max(0.0, (b.bore_diameter - ring.bore_diameter) / 2.0) / ring.bore_diameter)
    return f


def _read_representation(facts: GeometryFacts, purpose: Purpose, brief: str | None = None,
                         thresholds: Thresholds | None = None,
                         declared: list[dict] | None = None) -> tuple[Representation, str]:
    """`representation`'s own reading and the rule that decided it, one of `purpose`, `carve_brief`, `thin_ring`,
    `caps`, `no_rings`, `bores` and `annulus`. The last three are the readings the geometry cannot settle: which
    side of the surface is the fluid is not in the file (`side_reading`)."""
    T = _T(thresholds)
    if purpose == "external_cfd":
        return "external", "purpose"
    outer = _outer_region_ids(facts)
    caps = [o for o in facts.openings if o.classification == "port_candidate" and o.region_id in outer]
    # a brief that names the file the fluid ("the flow region itself, do not carve a cavity") is not a carve brief
    says_carve = bool(brief and BRIEF_CARVE.search(brief) and not BRIEF_FLUID.search(brief))
    # a plate pierced by a boss of its own body and a step inside a bore are walls, never a passage's end; a
    # flange's shoulder stays in the list so the wall can be read behind the flange (_wall_annulus_fraction)
    all_rings, why = _ring_exclusions(facts, T)
    rings = [o for o in all_rings if why.get(o.id) not in ("pierced", "step")]
    kept = [o for o in all_rings if o.id not in why]
    excluded = [o for o in all_rings if o.id in why]
    ids = {o.id for o in rings}
    rings += [o for o in _declared_claims(facts, kept, excluded, declared, "wall_shell" if says_carve else None, T)
              if o.id not in ids]
    # the annulus is read behind a flange (_wall_annulus_fraction): a flanged end ring is judged by its wall
    thin = [o for o in rings if _wall_annulus_fraction(o, rings) < T.WALL_SHELL_ANNULUS_FRACTION and _shell_like(facts, o, T)]
    if rings and says_carve:
        # the brief and a skin agree, and the skin settles it without the brief; without the skin it is the brief's
        return "wall_shell", ("thin_ring" if thin else "carve_brief")
    if thin:
        # thin ring ends on a body whose volume is a skin, not a bore: the wall, whatever stray caps it carries
        # and whatever the brief calls it (a brief that calls it the fluid is a conflict the catalog reports)
        return "wall_shell", "thin_ring"
    if caps:
        return "fluid_domain", "caps"
    if not rings:
        return "unknown", "no_rings"
    # an annular passage's end ring has ONE hole (the hub inside the casing). A ring with several is a body
    # pierced by several passages (a block with bores) or the end of a bundle's shell side, and which of the two
    # is the fluid is not in the geometry: the solid block would otherwise become the flow
    if any((getattr(o, "bore_count", None) or 1) > 1 for o in rings):
        return "unknown", "bores"
    return "annular_fluid", "annulus"


def representation(facts: GeometryFacts, purpose: Purpose, brief: str | None = None,
                   thresholds: Thresholds | None = None, declared: list[dict] | None = None,
                   fluid_side: str | None = None) -> Representation:
    """What the file is: a fluid body whose caps are the ports, a wall shell with open ring ports that the mesher
    carves inside from a seed point, an annular fluid passage whose end rings are the ports, or an external
    body. Read from the outer bodies' openings, with the brief as the tie-break for a thick wall. `declared`
    (the user's ports) brings back a ring the ring rules took out when a declaration claims it.

    `fluid_side` is a PERSON's answer to which side of the surface is the fluid (`FLUID_SIDES`), and it is read
    only where the geometry cannot say (`side_reading`).

    IT WAS `GEOMETRY_AGENT_FLUID_SIDE`, OFF BY DEFAULT, AND THE SWITCH IS DELETED. Flipped first and then deleted,
    in that order, because deleting a switch freezes whatever it was set to. What the flip moved, measured over 8
    fixture parts of 4 purposes by a deep diff of `hexera.report_measured_json` key path by key path: the
    `fluid_side` block itself; `representation.source`, which now names the rule that settled the side; on the 2
    parts where nothing settles it, `representation.kind` from `measured` to `assumed` with the question opened,
    which is the whole point (a default is not a confirmation) and the representation VALUE is unchanged on all 8;
    and the places that value gates, withheld as refusals on 3 parts until the side is answered. No measured
    number moved and no opening, stub or feature moved."""
    return side_reading(facts, purpose, brief, thresholds, declared, answer=fluid_side).representation  # type: ignore[return-value]


# ---------------------------------------------------------------------------------------------------------------
# which side of the surface is the fluid (work/z-next, gap B)
#
# A ring with one hole through a thick body is the end face of an annular passage (the file is the fluid, the hole
# is the hub) or the mouth of a bore through a solid block (the file is the metal, the hole is the flow). The two
# are the same triangles. So are a block pierced by two bores and the shell side of a bundle, and a part whose
# every mouth the tubularity gate refused. On the export corpus with no brief the reader lands on one of these
# three on 39 of 322 parts (`annulus` 37, `no_rings` 2). On the 37 `annulus` parts the reading asserts that the
# file is the fluid and is wrong on 25 of them, every mini_housing and every diffuser_plenum, which is the metal
# meshed as the flow; the 2 `no_rings` parts read `unknown`, which asserts nothing. On eval/hard_real it is 11 of
# 19 parts, where the reading asserts a side on four solid blocks and brackets and is wrong on all four, and those
# four carried eight confident junction places on solid metal. Measured in `eval/ask/results/fluid_side.md`, whose
# hard table is 18 of the 19 (`fluid_side.SLOW_PARTS`).
#
# The brief settles it where it says so (`BRIEF_CARVE`, `BRIEF_FLUID`), which on the corpus is all 39. A file
# with no brief is the case that matters, and there the reader REFUSES: it keeps today's value so nothing about
# the job changes, marks it open, and the question goes to intake (`ask.uncertainty.fluid_side_uncertainty`).
# Everything that depends on which side is the flow waits for the answer (`hexera.planner_places`).
# ---------------------------------------------------------------------------------------------------------------


#: The two answers. `through`: the fluid runs through the part's bores and the file is the solid around it.
#: `is_fluid`: the file is the fluid itself, the volume the flow fills.
SIDE_THROUGH = "through"
SIDE_IS_FLUID = "is_fluid"
FLUID_SIDES: tuple[str, ...] = (SIDE_THROUGH, SIDE_IS_FLUID)

#: The readings the geometry does not settle, from `_read_representation`.
OPEN_READINGS: tuple[str, ...] = ("annulus", "bores", "no_rings")

#: What settled the side, by the rule that decided the reading.
SETTLED_BY_RULE: dict[str, str] = {"purpose": "purpose", "carve_brief": "brief", "thin_ring": "geometry",
                                   "caps": "geometry"}

#: The rules under which a wall shell is a THICK SOLID and not a skin: the brief or a person said the file is the
#: wall, and no thin ring says it is a pipe's skin. Every stub march on such a file runs through the file's own
#: volume, which is the metal (`hexera._flow_path_places`).
SOLID_BODY_RULES: tuple[str, ...] = ("carve_brief", *OPEN_READINGS)


#: `fluid_side_on(env=None)` USED TO BE HERE AND RETURNED TRUE WITH NOTHING TO READ. It outlived
#: `GEOMETRY_AGENT_FLUID_SIDE` because `hexera.report_measured` still called it to decide whether to put the
#: `fluid_side` block in the document, and it went on accepting an `env` argument it ignored, which is a function
#: that looks like it reads a setting and does not. The reading is on for every run, so the call is gone and
#: `hexera.FLUID_SIDE_READING` is what the published-table replay moves instead: a named test seam rather than a
#: switch nobody can set.


class SideReading:
    """Which side of the surface is the fluid, and who settled it.

    `settled_by` is `purpose` (an external body), `geometry` (a skin, or caps with a tube behind them), `brief`
    (the customer's own words), `answer` (a person answered the question), or empty when nothing has: then
    `representation` is today's reading, kept so the job does not change, and `readings` says what each answer
    would make it."""

    __slots__ = ("representation", "settled_by", "rule", "why", "readings", "bores")

    def __init__(self, representation: str, settled_by: str, rule: str, why: str,
                 readings: dict[str, str] | None = None, bores: int = 0):
        self.representation = representation
        self.settled_by = settled_by
        self.rule = rule
        self.why = why
        self.readings = dict(readings or {})
        self.bores = bores

    @property
    def open(self) -> bool:
        return not self.settled_by

    def as_dict(self) -> dict[str, Any]:
        return {"open": self.open, "settled_by": self.settled_by or None, "rule": self.rule, "why": self.why,
                "readings": dict(self.readings), "bores": self.bores,
                "default": SIDE_IS_FLUID if self.open else None}


#: Why each open reading is open, in words about the geometry.
#:
#: AN OPEN READING'S `why` STATES THE MEASUREMENT AND THE QUESTION, AND ASSERTS NEITHER SIDE. It used to narrate
#: both conclusions instead: the `annulus` line read "the end of an annular passage (the file is the fluid) or the
#: mouth of a bore through a solid (the file is the metal)". Every word of that is true about the AMBIGUITY and
#: none of it is a claim, but the document the builder and the customer read is scanned for claims, and
#: `eval/vision/document.py:_BUILD` matched "a solid" in it and emitted `build = solid` about the whole part. So
#: the part carried two contradictory claims at once, its representation (`annular_fluid`, the fluid) and a
#: `solid` read out of the sentence explaining why the side is unknown. Measured on the export corpus: 37 of 322
#: parts, blade_row_passage 12, diffuser_plenum 10, mini_housing 15, every one of the 37 scored FALSE by the
#: answer key. `bores` missed the same fate by one word, "a solid block", which that regex's lookahead drops.
#:
#: A fact that lies is worse than a missing one and the builder cannot tell them apart, so the refusal says what
#: was MEASURED (a ring, one hole, a thick body) and that the side is not in the file. What each answer WOULD make
#: the representation stays in `SideReading.readings`, which is structured and cannot be mistaken for a claim by
#: anything that reads prose. `test_fluid_side.py` holds the invariant against catalog's own strings rather than
#: against these three spellings, so a reworded refusal that asserts a side again fails there.
OPEN_WHY: dict[str, str] = {
    "annulus": ("a ring with one hole through a thick body cuts the same triangles whichever side of the surface "
                "the flow is on, and the geometry does not say which side that is"),
    "bores": ("a ring several bores pass through cuts the same triangles whichever side of the surface the flow "
              "is on, and the geometry does not say which side that is"),
    "no_rings": ("no mouth was measured that says which side of the surface the flow is on"),
}


def _bore_count(facts: GeometryFacts) -> int:
    outer = _outer_region_ids(facts)
    counts = [int(getattr(o, "bore_count", None) or 1) for o in facts.openings
              if o.kind == "ring" and o.bore_diameter and o.region_id in outer]
    return max(counts) if counts else 0


def side_answer(readings: dict[str, str] | None, value: Any) -> str | None:
    """The `FLUID_SIDES` key an answer names, from the key itself or from the representation it sets (the value a
    contract answer carries, `contract.asking`'s `option_values`). None when it names neither, so a caller never
    turns an answer it cannot read into a side."""
    said = str(value or "").strip()
    if said in FLUID_SIDES:
        return said
    hits = [k for k, rep in (readings or {}).items() if rep == said and k in FLUID_SIDES]
    return hits[0] if len(hits) == 1 else None


def side_reading(facts: GeometryFacts, purpose: Purpose, brief: str | None = None,
                 thresholds: Thresholds | None = None, declared: list[dict] | None = None,
                 answer: str | None = None) -> SideReading:
    """Which side of the surface is the fluid, settled by the purpose, the geometry, the brief or a person, or
    open. Deterministic, reads nothing but the facts, the brief's words and the answer."""
    rep, rule = _read_representation(facts, purpose, brief, thresholds, declared)
    if rule in SETTLED_BY_RULE or purpose not in INTERNAL_PURPOSES:
        by = SETTLED_BY_RULE.get(rule, "purpose")
        why = {"purpose": "the purpose settles it", "brief": "the brief says the file is the solid wall",
               "geometry": ("the ring ends are a thin skin" if rule == "thin_ring"
                            else "the mouths are caps with a tube of their own size behind them")}[by]
        return SideReading(rep, by, rule, why)
    readings = {SIDE_THROUGH: "wall_shell", SIDE_IS_FLUID: "annular_fluid" if rule == "annulus" else "fluid_domain"}
    bores = _bore_count(facts)
    if answer is not None:
        if answer not in FLUID_SIDES:
            raise ValueError(f"fluid side {answer!r} is not one of {FLUID_SIDES}")
        return SideReading(readings[answer], "answer", rule, "a person said which side is the fluid", readings, bores)
    fluid_words = bool(brief and BRIEF_FLUID.search(brief))
    carve_words = bool(brief and BRIEF_CARVE.search(brief) and not fluid_words)
    if fluid_words:
        return SideReading(readings[SIDE_IS_FLUID], "brief", rule, "the brief says the file is the fluid", readings,
                           bores)
    if carve_words:
        return SideReading(readings[SIDE_THROUGH], "brief", rule, "the brief says the file is the solid wall",
                           readings, bores)
    return SideReading(rep, "", rule, OPEN_WHY[rule], readings, bores)


#: A body whose volume over its surface area is under this fraction of its ring's bore is a skin around a
#: cavity (a pipe wall's V/A is its thickness); a fluid pipe's V/A is a quarter of its bore.
SHELL_VOLUME_OVER_AREA_OF_BORE = 0.1


def _shell_like(facts: GeometryFacts, ring, thresholds: Thresholds | None = None) -> bool:
    """Only a closed body can be judged a skin by its volume; an open body with a thin ring (a lip inside a
    fluid domain, a seam-split shell) is not called a wall shell on the ring alone."""
    region = facts.region(ring.region_id)
    if region is None or not region.volume or not region.surface_area or not ring.bore_diameter:
        return False
    return region.volume / region.surface_area < _T(thresholds).SHELL_VOLUME_OVER_AREA_OF_BORE * ring.bore_diameter


def port_openings(facts: GeometryFacts, rep: Representation, declared: list[dict] | None = None,
                  thresholds: Thresholds | None = None) -> list:
    """The openings that can carry a port role under a representation: caps of the outer bodies for a fluid
    domain, open ring bores of the outer bodies for a wall shell or an annular passage. Inner bodies' end caps
    (a centre body) are obstacle faces, never ports; a flange's shoulder ring, a plate pierced by a boss and a
    step inside a bore are walls (`_ring_exclusions`), unless a declared port claims one (`_declared_claims`:
    declared ports win)."""
    outer = _outer_region_ids(facts)
    if rep in ("wall_shell", "annular_fluid"):
        rings, why = _ring_exclusions(facts, thresholds)
        kept = [o for o in rings if o.id not in why]
        claimed = _declared_claims(facts, kept, [o for o in rings if o.id in why], declared, rep, thresholds)
        ids = {o.id for o in kept} | {o.id for o in claimed}
        return [o for o in rings if o.id in ids]
    if rep == "external":
        return []
    caps = [o for o in facts.openings if o.classification == "port_candidate" and (o.region_id in outer or rep == "unknown")]
    # A DECLARED PORT ON A FLAT FACE IS A PORT (work/z-chain NEEDS 5). On a fluid domain a mouth can be a flat face
    # the tubularity gate calls `planar_face` rather than a port candidate (a box outlet, a filleted end), and a
    # customer row sitting on it at 0 mm was not treated as a port on 16 corpus parts. Declared ports win, as
    # they already do for the rings of a wall shell
    flat = [o for o in facts.openings if o.classification == "planar_face" and (o.region_id in outer or rep == "unknown")]
    claimed = {o.id for o in _declared_claims(facts, caps, flat, declared, rep, thresholds)} if flat else set()
    ids = {o.id for o in caps} | claimed
    return [o for o in facts.openings if o.id in ids]


def seed_point_for(facts: GeometryFacts, o, rep: Representation,
                   thresholds: Thresholds | None = None) -> tuple[float, float, float] | None:
    """A point inside the fluid just inside a port: SEED_INSET_OVER_BORE bores along the inward normal. For a
    ring the inward direction is against its outward normal; for a cap the stub's inward direction when marched."""
    bore = o.bore_diameter if (o.kind == "ring" and o.bore_diameter) else o.hydraulic_diameter
    if not bore:
        return None
    s = facts.stub(o.id)
    if s is not None and s.inward_direction:
        inward = s.inward_direction
    else:
        inward = tuple(-c for c in o.normal)
    inset = _T(thresholds).SEED_INSET_OVER_BORE
    return tuple(c + inset * bore * d for c, d in zip(o.centroid, inward))


_UNIT_WORDS = {"mm": "mm", "millimetre": "mm", "millimeter": "mm", "cm": "cm", "m": "m", "metre": "m", "meter": "m",
               "in": "in", "inch": "in", "inches": "in", "\"": "in", "ft": "ft", "foot": "ft", "feet": "ft"}
_TO_M = {"m": 1.0, "mm": 1e-3, "cm": 1e-2, "in": 0.0254, "ft": 0.3048}
UNIT_MATCH_BAND = 0.06


def unit_from_brief(facts: GeometryFacts, brief: str | None, purpose: Purpose | None = None,
                    thresholds: Thresholds | None = None) -> tuple[str | None, str]:
    """The file unit the brief settles by itself: a dimension the user wrote with a unit ("40 mm branches", "a 4.2 m
    long car") that equals a measured port bore or a bounding-box extent under exactly one candidate unit that is
    plausible for the purpose. Deterministic reading of the brief, no model. Planar faces of an external body are
    never bores (a fin thickness quoted in the brief must not "settle" feet)."""
    import re
    band = _T(thresholds).UNIT_MATCH_BAND
    if not brief:
        return None, ""
    dims = []
    for m in re.finditer(r"(\d+(?:\.\d+)?)\s*(mm|millimet(?:re|er)s?|cm|m\b|met(?:re|er)s?|in\b|inch(?:es)?|\"|ft|feet|foot)", brief, re.I):
        word = m.group(2).lower().rstrip("s") if not m.group(2).startswith("\"") else "\""
        unit = _UNIT_WORDS.get(word) or _UNIT_WORDS.get(word + "s") or ("mm" if word.startswith("millimet") else "m" if word.startswith("met") else None)
        if unit:
            dims.append((float(m.group(1)) * _TO_M[unit], m.group(0)))
    lengths = [("bore", o.hydraulic_diameter) for o in facts.openings if o.classification == "port_candidate"]
    lengths += [("extent", e) for e in facts.bbox.extent]
    if not dims:
        return None, ""
    allowed = set(facts.units.plausible_for_purpose.get(purpose, [])) if purpose else set(_TO_M)
    if not allowed:
        allowed = set(_TO_M)
    hits: dict[str, list[tuple[str, str]]] = {}
    for cand, f in _TO_M.items():
        if cand not in allowed:
            continue
        for metres, text in dims:
            for what, length in lengths:
                if length > 0 and abs(length * f / metres - 1.0) <= band:
                    hits.setdefault(cand, []).append((text, what))
                    break
    if len(hits) == 1:
        unit = next(iter(hits))
        what = "a measured bore" if any(w == "bore" for _, w in hits[unit]) else "a measured extent"
        return unit, f"the brief's {', '.join(sorted({t for t, _ in hits[unit]}))} matches {what} only if the file is in {unit}"
    return None, ""


def detect_risks(facts: GeometryFacts, purpose: Purpose, fidelity: Fidelity = "standard",
                 cell_cap: int | None = None, declared: list[dict] | None = None,
                 roles: dict[str, str] | None = None, brief: str | None = None,
                 thresholds: Thresholds | None = None, engine: str | None = None,
                 fluid_side: str | None = None) -> list[Risk]:
    """roles: opening_id -> role once assigned. Before roles are known every planar end is a possible port;
    after, stub risk applies to outlets (blocking) and inlets (development length), and unknowns are flagged.
    brief: the user's words, read deterministically for one thing only: a dimension that settles the unit.
    thresholds: the rule parameters to apply; None means the values in force (agent/thresholds.json).
    engine: the mesher the builder kinds are framed for (snappy or gmsh); None means the purpose's default
    (`default_engine_for`): gmsh_size fires on gmsh, the snappy-frame kinds on snappy."""
    T = _T(thresholds)
    # THE CELL CAP RULE PRICES THE JOB and `facts.cell_estimates` is one of the two purpose-dependent things the
    # measurement carries, computed for whatever purpose the upload named. A direct caller (the CLI, an eval) does
    # not go through `ToolContext`, so the repricing is here too; it is idempotent and it re-reads nothing
    from geometry_agent.facts import measure as facts_measure
    facts = facts_measure.priced_for(facts, purpose)
    out: list[Risk] = []
    n = 0

    def add(kind, severity, measurement, consequence, recommendation, decision=True, target=None, derivation=""):
        nonlocal n
        n += 1
        out.append(_risk(n, kind, severity, measurement, consequence, recommendation, decision, target, derivation))

    rep = representation(facts, purpose, brief, T, declared, fluid_side=fluid_side)
    candidates = port_openings(facts, rep, declared, T)
    ports = list(candidates)
    if roles is not None:
        ports = [o for o in ports if roles.get(o.id) in {"inlet", "outlet", "opening_unknown"}]
    hs = _surface_cell(facts, fidelity)
    holes = [o for o in facts.openings if o.classification == "hole"]

    flat_2d = purpose == "structural" and min(facts.bbox.extent) <= 1e-9 * max(facts.bbox.extent)
    if flat_2d:
        add("surface_2d", "info", {"bbox_extent": facts.bbox.extent},
            "The file is a flat surface (one bounding-box extent is zero): a 2D structural domain, not a closed solid, so "
            "watertightness does not apply.", "Mesh it as a planar domain.", decision=False)
    if not facts.watertight and not flat_2d:
        rims = [o.id for o in facts.openings if o.kind == "rim"]
        only_holes = bool(holes) and all(o.classification == "hole" for o in facts.openings if o.kind == "rim")
        add("not_watertight", "high",
            {"regions": len(facts.regions), "open_rims": rims, "faces": facts.faces, "holes": [o.id for o in holes]},
            f"The surface has {len(rims)} open edge{'' if len(rims) == 1 else 's'} and does not close into a solid"
            + (f" ({', '.join(rims)}). " if rims else ". ")
            + "A mesher handed a surface with holes in it either stops, or closes them wherever it decides to, and a hole "
            "closed that way becomes a wall nobody asked for in a place nobody chose."
            + (" Every open edge here is a pinhole or a seam, so the choice is put to you once, below." if only_holes else ""),
            "Closing the surface in CAD is the only choice that guarantees the volume meshed is the volume you drew. If every "
            "open edge listed is in fact an inlet or an outlet, saying so has each one closed off deliberately at the face you "
            "meant, which is as good. Stopping now costs nothing.", decision=not only_holes)

    rings = [o for o in facts.openings if o.kind == "ring"]
    ring_ports = [o for o in candidates if o.kind == "ring"]
    if rep == "wall_shell" and purpose in INTERNAL_PURPOSES:
        # `next(gen, ring_ports[0])` EVALUATED ITS DEFAULT WHETHER THE GENERATOR YIELDED OR NOT, so a wall
        # shell with no RING among its candidate ports raised IndexError right here - and nothing between this
        # line and the platform caught it, so the exception left `run_loop` and took the PLAN with it (the
        # platform then logged "no plan for this submission" and meshed the job without one).
        #
        # MEASURED on the platform's own tests/fixtures/geometry/cht_enclosing_2region.step at
        # `internal_cfd`: 18 openings, every one a CAP, no ring anywhere on the part. The part reads as a wall
        # shell the moment a customer answers the survey's fluid-side question with `through`, which is the
        # FIRST option that question offers - so this was one ordinary answer away on a real part, and it took
        # the whole plan every time. The other two answers (`is_fluid` -> fluid_domain, and no answer ->
        # unknown) go down other branches and were always fine, which is why nothing caught it.
        inlet_like = next((o for o in ring_ports if roles is None or roles.get(o.id) == "inlet"),
                          ring_ports[0] if ring_ports else None)
        # A SEED POINT IS TAKEN FROM A PORT, so with no port there is no seed and this says so rather than
        # naming a place nobody measured.
        seed = seed_point_for(facts, inlet_like, rep, T) if inlet_like is not None else None
        inner = [r.id for r in facts.regions if r.nested_in]
        if brief and BRIEF_FLUID.search(brief) and not BRIEF_CARVE.search(brief):
            add("solid_wall_representation", "high",
                {"ring_ids": [o.id for o in ring_ports], "bores": [o.bore_diameter for o in ring_ports],
                 "wall_thickness": facts.features.thickness_min, "regions": len(facts.regions)},
                "You describe this file as the fluid and it measures as the metal: a shell"
                + (f" {facts.features.thickness_min:.4g} {facts.units.declared or 'file units'} thick"
                   if facts.features.thickness_min else "")
                + " with open ends, enclosing wall rather than the passage through it. Meshed as the fluid, the solve runs "
                "inside the metal, and the answer it hands back looks like any other result.",
                "Sending the fluid body itself, the volume inside the passage, is the direct route and leaves nothing to be "
                "inferred. If the solid is all you have, the cavity inside it can be taken out in CAD and sent instead. "
                "Stopping now costs nothing: no reading of this file gives you the flow through the passage.")
        else:
            add("wall_shell_to_carve", "info",
                {"ring_ids": [o.id for o in ring_ports], "bores": [o.bore_diameter for o in ring_ports],
                 "wall_thickness": facts.features.thickness_min, "inner_bodies": inner,
                 "seed_point": [round(c, 6) for c in seed] if seed else None},
                # TWO WHOLE SENTENCES AND NOT ONE WITH CLAUSES SWAPPED IN. The ring-port wording threads
                # `inner` through the middle of itself ("...with open ring ports and 1 inner body inside it: the
                # ring bores are the ports minus the inner body's cross-section"), and the no-ring wording has
                # nothing for either clause to attach to. Interleaving them produced prose that read as an
                # ungrammatical mixture of the two, which a customer reads.
                ("The file is the solid wall of the passage with open ring ports"
                 + (f" and {len(inner)} inner body inside it" if inner else "")
                 + ": the mesher carves the fluid cavity inside it from a seed point, the ring bores are the "
                   "ports" + (" minus the inner body's cross-section" if inner else "") + "."
                 if ring_ports else
                 "The file measures as the solid wall of a passage"
                 + (f", with {len(inner)} inner body inside it" if inner else "")
                 + ", and NO RING PORT WAS FOUND on it. The mesher carves the fluid cavity inside such a part "
                   "from a seed point just inside a port, and nothing measured here says which face is a port "
                   "or where that cavity is entered."),
                ("Declare each port by its bore (or annulus area), put the seed point inside the cavity just inside "
                 "the inlet, and mesh the wall's inner surface as the wall patch."
                 if ring_ports else
                 "Say which faces are the ports and where a point inside the cavity is: this measurement found no "
                 "ring end to read either from. Sending the fluid body itself instead leaves nothing to infer."),
                decision=False)
    elif rep == "annular_fluid" and purpose in INTERNAL_PURPOSES:
        add("annular_ports", "info",
            {"ring_ids": [o.id for o in ring_ports], "bores": [o.bore_diameter for o in ring_ports],
             "outer_diameters": [o.hydraulic_diameter for o in ring_ports]},
            "The fluid passage wraps around a hub: its end faces are annular rings, which are the ports.",
            "Declare each annular port by its outer and inner diameters (or its area).", decision=False)
    elif rings and purpose in INTERNAL_PURPOSES:
        add("ring_faces_present", "info",
            {"ring_ids": [o.id for o in rings], "bores": [o.bore_diameter for o in rings]},
            "Some planar faces are rings (a face with a hole through it): shoulders at a step, or a solid wall end. "
            "They are walls, not ports.",
            "No action unless a ring was expected to be a port.", decision=False)

    if holes and not flat_2d:
        biggest_port = max((o.hydraulic_diameter for o in ports), default=facts.bbox.diagonal)
        add("surface_holes", "high",
            {"hole_ids": [o.id for o in holes], "hole_diameters": [o.hydraulic_diameter for o in holes],
             "largest_port_diameter": biggest_port, "count": len(holes)},
            f"{len(holes)} hole{' sits' if len(holes) == 1 else 's sit'} flat in the wall rather than capping a passage, the "
            f"largest {max(o.hydraulic_diameter for o in holes):.4g} across against the largest port's {biggest_port:.4g} "
            f"({facts.units.declared or 'file units'}): pinholes, "
            "slits or seams that did not stitch when the file was written. A mesher either stops on them or closes them where "
            "it decides to, and a seam closed the wrong way changes the shape you get a result for.",
            "Stitching or filling them in CAD is the only choice that guarantees a mesh of the part you drew. If one of them is "
            "a real port that the export made look like a seam, saying so keeps it open. Stopping now costs nothing.")

    if purpose in INTERNAL_PURPOSES and len(ports) >= 2:
        big = max(o.hydraulic_diameter for o in ports)
        tiny = [o for o in ports if o.hydraulic_diameter < T.TINY_PORT_FRACTION * big]
        for o in tiny:
            if roles is not None and roles.get(o.id) not in (None, "opening_unknown", "outlet", "inlet"):
                continue
            add("tiny_port", "medium",
                {"opening_id": o.id, "hydraulic_diameter": o.hydraulic_diameter, "largest_port_diameter": big,
                 "ratio": round(o.hydraulic_diameter / big, 3)},
                f"Opening {o.id} is {o.hydraulic_diameter:.4g} {facts.units.declared or 'file units'} across, "
                f"{o.hydraulic_diameter / big:.0%} of the largest port on the part: a drain, vent, bleed or pressure tap. "
                "Whether it is open changes the mass balance the run reports, and resolving it takes cells small enough to fit "
                "across it, which on a part like this is where much of the cell budget goes.",
                f"Leaving {o.id} open is right when it really carries flow, and the mesh pays for the cells that resolve it. "
                "Closing it for this run keeps those cells for the main passage and reports the balance without whatever leaves "
                "there. Taking it out of the geometry does the same and drops the small cells around its edge as well.")

    nested = [r for r in facts.regions if r.nested_in]
    glued = [i for i in facts.interfaces if getattr(i, "kind", "shared") == "shared"]
    coincident = [i for i in facts.interfaces if getattr(i, "kind", "shared") == "coincident"]
    if nested and purpose == "conjugate_heat_transfer":
        shared = sum(facts.interface_area(r.id, r.nested_in) for r in nested)
        conformal = shared > 0
        add("solid_fluid_pair", "info" if conformal else "high",
            {"nested": [(r.id, r.nested_in) for r in nested], "gap_between_regions": facts.features.min_gap_between_regions,
             "interface_area": shared, "interfaces": [(i.region_a, i.region_b, i.area) for i in facts.interfaces]},
            ("An inner body sits inside an outer one and the two share a surface exactly: the metal and the flow volume a "
             "heat-transfer run needs, joined where heat has to cross."
             if conformal else
             "The inner body sits inside the outer one with a gap"
             + (f" of {facts.features.min_gap_between_regions:.4g} {facts.units.declared or 'file units'} "
                if facts.features.min_gap_between_regions else " ")
             + "between them, not touching. Heat crosses from metal into fluid only where the two share a surface exactly; "
             "across a gap there is nothing for it to cross, so the temperatures reported on the two sides are not tied to "
             "one another."),
            ("The inner body is read as the fluid unless the brief says otherwise." if conformal else
             "Which body is the fluid still has to be settled, and the answer says where the heat is meant to go: the inner "
             "one for a passage running through a block, the outer one for a part sitting in flow. Neither answer closes the "
             "gap. Only making the two touch exactly in CAD does that, and until they do each side is solved as though the "
             "other were not there."),
            decision=not conformal)
    if purpose == "conjugate_heat_transfer" and len(facts.regions) >= 2 and coincident and not glued:
        add("unshared_interface", "high",
            {"regions": len(facts.regions), "coincident_pairs": [(i.region_a, i.region_b, i.area) for i in coincident][:12],
             "coincident_area": sum(i.area for i in coincident)},
            f"The bodies touch over {sum(i.area for i in coincident):,.0f} square "
            f"{facts.units.declared or 'file units'} with no gap, and each one carries its own separate "
            "copy of that touching surface, which is what a plain compound export gives. Two copies of one surface are two "
            "walls, not one join, so heat either leaks between them or does not cross at all.",
            "Joining the bodies in CAD so the touching face is a single face, then exporting again, is what lets heat cross "
            "where you expect it to. If heat crossing between the bodies is not what you are after, a flow-only run on the "
            "fluid body needs none of this. Stopping now costs nothing.")
    if purpose == "conjugate_heat_transfer" and len(facts.regions) >= 2 and not nested and not facts.interfaces:
        add("no_shared_interface", "high",
            {"regions": len(facts.regions), "gap_between_regions": facts.features.min_gap_between_regions,
             "closest": facts.features.closest_regions},
            "A run that carries heat from the metal into the fluid needs the two to touch. These bodies share no surface at "
            "all"
            + (f", the closest pair {facts.features.min_gap_between_regions:.4g} "
               f"{facts.units.declared or 'file units'} apart" if facts.features.min_gap_between_regions else "")
            + ", so there is nowhere for heat to cross and nothing to report about the coupling.",
            "Making the bodies share their boundary exactly in CAD, so the fluid's surface is the solid's surface, is what "
            "makes the coupled run possible. If the flow on its own is what you need, that runs on this file as it stands. "
            "Stopping now costs nothing.")
    if nested and purpose == "internal_cfd":
        add("nested_bodies", "high",
            {"nested": [(r.id, r.nested_in) for r in nested], "regions": len(facts.regions),
             "gap_between_regions": facts.features.min_gap_between_regions},
            f"The file holds one body inside another ({', '.join(f'{r.id} inside {r.nested_in}' for r in nested)}). For a "
            "flow run that is either the flow volume sitting inside the part, in which case the inner one is what gets meshed "
            "and the metal is left out, or a sealed pocket no flow reaches, which still gets cells and still spends your "
            "budget.",
            "If the inner body is the flow volume, saying so meshes it and leaves the metal out, which is what a flow run "
            "needs. If you want the metal solved too, so heat crosses between them, that is a different run, and saying so "
            "is what sets it up. If the inner body is a sealed pocket you do not care about, taking it out of the file keeps "
            "its cells out of your budget.")
    if nested and purpose == "structural":
        add("internal_void", "info",
            {"nested": [(r.id, r.nested_in) for r in nested]},
            "The part is hollow: a sealed cavity inside the outer body.",
            "Normal for a hollow part; confirm the cavity is intended.", decision=False)

    if purpose in INTERNAL_PURPOSES:
        port_ids = {o.id for o in candidates}
        # The sign of the area change into a mouth. Continuity: a mouth narrower than what feeds it accelerates the
        # flow into the exit, and reversed flow across the exit plane is not what a short run measures there. The
        # stub rule used to assert that recirculation crosses the exit plane on every short run; on the last live
        # run 97 of 179 short outlet runs contract into the mouth, 35 expand and 42 hold it within 5 percent
        # (docs/plan_v3_rules.md section 19). The reference is the declared inlet's area once roles are known, the
        # largest other port's before that.
        _areas = {o.id: float(port_area(facts, o, rep, T)) for o in candidates}
        _inlet_area = max((_areas[i] for i, r in (roles or {}).items() if r == "inlet" and i in _areas), default=0.0)
        for s in facts.stubs:
            o = facts.opening(s.opening_id)
            # a cap of the fluid, or a ring that is a port under the representation (a wall shell's open end)
            if o is None or (o.classification != "port_candidate" and o.id not in port_ids):
                continue
            role = roles.get(o.id) if roles is not None else None
            if roles is not None and role not in {"inlet", "outlet", "opening_unknown"}:
                continue
            if role == "inlet" and T.STUB_OK_OVER_D <= s.length_over_diameter < T.INLET_DEVELOPED_OVER_D:
                add("inlet_run_developing", "info",
                    {"opening_id": o.id, "length_over_diameter": round(s.length_over_diameter, 2),
                     "hydraulic_diameter": o.hydraulic_diameter, "terminated_by": s.terminated_by},
                    f"Inlet {o.id} has {s.length_over_diameter:.1f} diameters before {_TERMINATED[s.terminated_by]}; a uniform "
                    "profile is still developing there.",
                    "Prescribe a developed profile at the inlet if the first junction is sensitive to it; otherwise nothing.",
                    decision=False)
                continue
            if s.length_over_diameter < T.STUB_OK_OVER_D:
                if role == "inlet":
                    add("short_inlet_run", "medium",
                        {"opening_id": o.id, "length_over_diameter": round(s.length_over_diameter, 2),
                         "hydraulic_diameter": o.hydraulic_diameter, "terminated_by": s.terminated_by},
                        f"Inlet {o.id} reaches {_TERMINATED[s.terminated_by]} after {s.length_over_diameter:.1f} "
                        "diameters. A uniform inlet profile has no room to develop before it matters.",
                        "Prescribe a developed profile at the inlet, or extend the inlet run.", decision=False)
                    continue
                # the mesh builds either way: the harm is a silently wrong answer at a pressure outlet, so high under
                # two diameters (the user must decide) and medium up to five (the default extension can stand)
                sev: Severity = "high" if s.length_over_diameter < T.STUB_BLOCKING_OVER_D else "medium"
                ref_area = _inlet_area or max((a for i, a in _areas.items() if i != o.id), default=0.0)
                ratio = (_areas.get(o.id, 0.0) / ref_area) if ref_area > 0 else None
                basis = "declared inlet" if _inlet_area else "largest other port"
                # 0.05 is a dead band on a reported measurement, not a rule cutoff: it decides how the area change
                # is worded, never whether short_stub fires, so it is not a governed threshold.
                sign = (f"The mouth is {ratio:.2f} times the {basis}'s area, so the flow accelerates into it."
                        if ratio is not None and ratio < 0.95 else
                        f"The mouth is {ratio:.2f} times the {basis}'s area, so the flow decelerates into it, which is where "
                        "reversed flow at an exit plane is measured."
                        if ratio is not None and ratio > 1.05 else
                        f"The mouth is within 5 percent of the {basis}'s area." if ratio is not None else
                        "No other port measures an area to compare the mouth with.")
                add("short_stub", sev,
                    {"opening_id": o.id, "length_over_diameter": round(s.length_over_diameter, 2),
                     "hydraulic_diameter": o.hydraulic_diameter, "length": s.length, "terminated_by": s.terminated_by,
                     "required_over_diameter": T.STUB_OK_OVER_D, "area": _areas.get(o.id),
                     "exit_area_ratio": round(ratio, 3) if ratio is not None else None, "area_reference": basis},
                    f"If {o.id} is an outlet, the flow leaving through it has had {s.length_over_diameter:.1f} diameters "
                    f"since {_TERMINATED[s.terminated_by]}, short of the {T.STUB_OK_OVER_D:.0f} diameters it takes to "
                    f"settle. {sign} A pressure "
                    "outlet holds one static pressure across the whole face and treats the profile there as settled and "
                    "parallel; this close to the feature neither is measured to be true, so the pressure drop and the flow "
                    f"split reported at {o.id} are read off a face the flow has not settled on.",
                    f"Bringing the run at {o.id} to at least {T.STUB_OK_OVER_D:.0f} diameters means a straight length of "
                    f"{T.STUB_OK_OVER_D * o.hydraulic_diameter:.4g} {facts.units.declared or 'file units'} where the part has "
                    f"{s.length:.4g} today; nothing in the run can add it, so that is a change to the model and a second file, "
                    "and it is what makes the pressure drop and the flow split at this end worth quoting. If flow enters at "
                    f"{o.id} rather than leaving, saying so moves the condition to the far end and there is nothing to add. "
                    f"Meshing the part as it stands gets you a mesh today, and the numbers at {o.id} are the ones not to "
                    "quote.")

    if purpose in INTERNAL_PURPOSES and len(ports) >= 2:
        ds = sorted(o.hydraulic_diameter for o in ports)
        if ds[0] > 0 and ds[-1] / ds[0] > T.VELOCITY_RATIO_MAX:
            add("velocity_spread", "high",
                {"hydraulic_diameter_min": ds[0], "hydraulic_diameter_max": ds[-1], "ratio": round(ds[-1] / ds[0], 2),
                 "velocity_ratio_by_continuity": round((ds[-1] / ds[0]) ** 2, 2)},
                f"Port bores differ by more than a factor of {_word(T.VELOCITY_RATIO_MAX)}, so by continuity the local "
                f"velocity differs by more than {_word(T.VELOCITY_RATIO_MAX ** 2)}. The renderer writes one wall layer "
                "entry for the whole surface (snappy_runner.py:685), so one first-cell height is applied at both walls "
                "and the y+ it delivers scales with the local velocity.",
                "The engines take one global layer spec: size the first cell for the smallest bore whose wall shear matters "
                "and add a surface refinement region on that bore (the first layer is relative to the local surface cell, so "
                "it shrinks there automatically).", decision=False)
        small = min(ports, key=lambda o: o.hydraulic_diameter)
        if hs > 0 and small.hydraulic_diameter / hs < T.PORT_CELLS_MIN:
            add("port_resolution", "medium",
                {"opening_id": small.id, "hydraulic_diameter": small.hydraulic_diameter, "surface_cell": hs,
                 "cells_across": round(small.hydraulic_diameter / hs, 2), "cells_min": T.PORT_CELLS_MIN,
                 "cell_for_floor": small.hydraulic_diameter / T.PORT_CELLS_MIN},
                f"The smallest port {small.id} measures {small.hydraulic_diameter:.4g} across and the surface cell at "
                f"{fidelity} fidelity is {hs:.4g}: {small.hydraulic_diameter / hs:.1f} cells across the bore, against the "
                f"{T.PORT_CELLS_MIN:.0f} the floor asks for. {T.PORT_CELLS_MIN:.0f} cells across it is a cell of "
                f"{small.hydraulic_diameter / T.PORT_CELLS_MIN:.4g}.",
                f"Add a surface refinement region on that bore (target bore/{T.PORT_CELLS_MIN:g}) or raise fidelity.", decision=False)
    if purpose in INTERNAL_PURPOSES and roles is not None and not declared:
        ins = [o for o in ports if roles.get(o.id) == "inlet"]
        outs = [o for o in ports if roles.get(o.id) == "outlet"]
        if ins and outs and len(ins) + len(outs) == len(ports) and all(
                any(abs(i.hydraulic_diameter / o.hydraulic_diameter - 1) < T.SAME_BORE_BAND for o in outs if o.hydraulic_diameter) for i in ins):
            add("role_assumed", "medium",
                {"inlet_ids": [o.id for o in ins], "outlet_ids": [o.id for o in outs],
                 "hydraulic_diameters": [o.hydraulic_diameter for o in ins + outs]},
                f"Nothing in the file says which way the flow goes: {', '.join(o.id for o in ins)} and "
                f"{', '.join(o.id for o in outs)} are the same size and the same shape, so the direction this plan carries "
                f"(in at {', '.join(o.id for o in ins)}, out at {', '.join(o.id for o in outs)}) is a guess.",
                f"If flow enters at {', '.join(o.id for o in ins)}, the plan stands as written. If it enters at "
                f"{', '.join(o.id for o in outs)} instead, the cells are identical and everything else is the other way round: "
                "which face carries the supply, which carries the back pressure, and the sign of every pressure drop and flow "
                "rate you are handed.")
    if purpose in INTERNAL_PURPOSES and len(ports) == 2 and ports[0].region_id == ports[1].region_id:
        _diffuser_angle(facts, ports, roles, add, T)

    if facts.features.thin_clusters:
        worst = min(facts.features.thin_clusters, key=lambda c: c.thickness_min)
        cells_across = worst.thickness_min / hs if hs > 0 else 0
        if cells_across < T.THIN_CELLS_MIN:
            add("thin_feature", "high" if cells_across < T.THIN_CELLS_HIGH else "medium",
                {"cluster_id": worst.id, "thickness_min": worst.thickness_min, "surface_cell": hs,
                 "cells_across": round(cells_across, 2), "centroid": worst.centroid, "clusters": len(facts.features.thin_clusters)},
                f"The thinnest cluster {worst.id} measures {worst.thickness_min:.4g} across and the surface cell at "
                f"{fidelity} fidelity is {hs:.4g}: {cells_across:.1f} cells across it, against the {T.THIN_CELLS_MIN:.0f} "
                f"the floor asks for. {T.THIN_CELLS_MIN:.0f} cells across it is a cell of "
                f"{worst.thickness_min / T.THIN_CELLS_MIN:.4g}.",
                f"Add a refinement region around the thin cluster so it is at least {_word(T.THIN_CELLS_MIN)} cells across, or raise fidelity, "
                "or defeature it if it does not matter to the physics.", decision=False)

    # THE GATE IS THE KNIFE COUNT AND THE EVIDENCE CARRIED BOTH COUNTS, so `sharp_edge_count` was a number the
    # item reported and its argument never used. The two are different measurements of different edges
    # (`features.SHARP_DEG` 60 against `features.KNIFE_DEG` 150, both on the dihedral angle), and a body whose
    # edges are all blunt has sharp lines and no knife lines, so it gets no item: that is right and it is not
    # obvious, which is why the sentence now says it. Widening the gate to `sharp_edge_count` was the other way
    # to clear this and it is wrong: nearly every real export has sharp lines, so the item would fire on almost
    # every part and say nothing. The count stays and becomes part of the argument instead.
    if facts.features.knife_edge_count > 0 and purpose in FLOW_PURPOSES:
        from geometry_agent.facts import features
        knives, sharps = facts.features.knife_edge_count, facts.features.sharp_edge_count
        add("knife_edge", "medium",
            {"knife_edge_count": knives, "sharp_edge_count": sharps},
            f"A near-zero-thickness edge (trailing edge, fin tip) forces the surface mesh to a point. Layers terminate "
            f"there and skewness spikes unless the edge is treated explicitly. {knives} of this part's {sharps} sharp "
            f"feature lines fold back past {features.KNIFE_DEG:g} degrees, which is what makes them knife edges rather "
            f"than the ordinary corners the other {max(sharps - knives, 0)} are.",
            "Preserve the edge as a feature line and refine to it; accept a small blunt trailing edge if the engine "
            "cannot hold a knife edge.", decision=False)

    est = next(e for e in facts.cell_estimates if e.tier == fidelity)
    if cell_cap is not None and est.cells > cell_cap:
        fits = [e.tier for e in facts.cell_estimates if e.cells <= cell_cap]
        add("cell_cap", "high",
            {"estimate": est.cells, "cap": cell_cap, "ratio": round(est.cells / cell_cap, 2), "fidelity": fidelity,
             "tiers_that_fit": fits},
            f"Resolving this part takes about {est.cells:,} cells and the budget you set is {cell_cap:,}: "
            + (f"{est.cells / cell_cap:,.0f}" if est.cells >= 10 * cell_cap else f"{est.cells / cell_cap:.2f}")
            + " times it. Both cannot hold, and a job that ships over the budget it was given has come back at two to five "
            "times it, which is time and money nobody agreed to.",
            (f"Meshing coarser holds your {cell_cap:,}-cell budget: the cell along the wall grows from {hs:.4g} to "
             f"{_surface_cell(facts, fits[-1]):.4g} {facts.units.declared or 'file units'}, so anything thinner than that stops "
             "being resolved, and the mesh comes to about "
             f"{next(e.cells for e in facts.cell_estimates if e.tier == fits[-1]):,} cells. Raising the budget to "
             f"{est.cells:,} cells keeps the resolution and costs the run time those cells take. Stopping now costs neither."
             if fits else
             f"No coarser mesh gets under {cell_cap:,} cells and still resolves this part: the coarsest is "
             f"{min(e.cells for e in facts.cell_estimates):,}, still "
             + (f"{min(e.cells for e in facts.cell_estimates) / cell_cap:,.0f}"
                if min(e.cells for e in facts.cell_estimates) >= 10 * cell_cap else
                f"{min(e.cells for e in facts.cell_estimates) / cell_cap:.2f}")
             + f" times the budget. Raising the budget to "
             f"{min(e.cells for e in facts.cell_estimates):,} cells is what buys a mesh at all; taking small features out of "
             "the part in CAD is the other way under it. Stopping now costs neither."))

    regions = len(facts.regions)
    if purpose == "external_cfd" and regions > 1:
        add("multi_body_external", "info",
            {"regions": regions, "gap_between_regions": facts.features.min_gap_between_regions,
             "closest": facts.features.closest_regions},
            f"{regions} separate bodies in an external case (elements, wheels, hub and blades). Hexera meshes one wall "
            "patch, so all of them share it; the gap between the closest pair sets the smallest cell in the slot. Per-body "
            "forces need post-processing, not separate patches.",
            "Keep every body on the one wall patch; refine the closest gap.", decision=False)
    if purpose in {"internal_cfd", "structural"} and regions > 1 and not nested:
        add("region_purpose_mismatch", "high",
            {"regions": regions, "purpose": purpose,
             "region_volumes": [r.volume for r in facts.regions]},
            f"The file holds {regions} separate bodies that do not touch, a disconnected volume, and the run you asked for "
            "wants one connected body. Only one of them can take your inlet and your outlet; the rest get meshed as dead "
            "space you pay cells for, or the run stops at the very end, after every attempt has been paid for.",
            "If the extra bodies are the metal around the passage and you want heat crossing into it, that is a coupled run, "
            "and saying so is what sets it up. If they are stray pieces, or should be one body, joining or removing them in "
            "CAD leaves the single volume this run needs. Stopping now costs nothing.")
    if purpose == "conjugate_heat_transfer" and regions == 1:
        add("region_purpose_mismatch", "high",
            {"regions": 1, "purpose": purpose},
            "A run that carries heat between metal and fluid needs both of them in the file, as two bodies. This file holds "
            "one connected body, and nothing downstream can split it into the two the run needs.",
            "Sending the solid and the fluid as separate bodies is what makes the coupled run possible. If the flow on its own "
            "is what you need, this file runs as it stands. Stopping now costs nothing.")

    unit = facts.units
    if unit.declared and unit.declared not in unit.plausible_for_purpose.get(purpose, []):
        add("unit_implausible", "high",
            {"declared": unit.declared, "bbox_diagonal": facts.bbox.diagonal,
             "plausible": unit.plausible_for_purpose.get(purpose, [])},
            f"The file says it is drawn in {unit.declared}. Read that way the part is {facts.bbox.diagonal:.4g} "
            f"{unit.declared} corner to corner, which is not a size this kind of part comes in. "
            + (f"{' or '.join(unit.plausible_for_purpose.get(purpose, []))} puts it in range. "
               if unit.plausible_for_purpose.get(purpose) else "")
            + "Every length, every velocity and every near-wall cell is sized from this one number, so getting it wrong is "
            "wrong by a factor of ten or a thousand, everywhere, and quietly.",
            f"If {unit.declared} is right and the part really is that size, saying so settles it and nothing changes. If it is "
            "not, telling us the unit it was drawn in rescales the whole job before anything is sized from it, which is a good "
            "deal cheaper than reading it off the answer.")
    elif not unit.declared:
        settled, why = unit_from_brief(facts, brief, purpose, T)
        if settled:
            add("unit_unknown", "info",
                {"bbox_diagonal": facts.bbox.diagonal, "plausible": unit.plausible_for_purpose.get(purpose, []),
                 "best_guess": settled, "settled_by_brief": True},
                f"The file carries no unit, but {why}. Treat the file as {settled}.",
                f"Proceed in {settled}; say so in the summary so the user can object.", decision=False)
        else:
            add("unit_unknown", "medium",
                {"bbox_diagonal": facts.bbox.diagonal, "plausible": unit.plausible_for_purpose.get(purpose, []),
                 "best_guess": unit.candidates[0][0] if unit.candidates else None},
                f"The file carries no unit: the part measures {facts.bbox.diagonal:.4g} corner to corner with nothing "
                "attached to say of what. In millimetres that is a part you can hold; in metres it is the size of a room; and "
                "every length in the plan below, every cell and every near-wall height follows from which it is.",
                (f"Tell us the unit the file was drawn in. {unit.candidates[0][0]} is the reading that puts this part at a "
                 "believable size for the job, so it is what the plan assumes until you say otherwise."
                 if unit.candidates else
                 "Tell us the unit the file was drawn in. Nothing in the file narrows it down, so nothing below can be sized "
                 "until you do."))

    g = facts.features.min_gap_between_regions
    if purpose in FLOW_PURPOSES and regions > 1 and g is not None and g > 0 and hs > 0 and g / hs < T.GAP_CELLS_MIN:
        add("gap_resolution", "medium",
            {"min_gap_between_regions": g, "surface_cell": hs, "cells_across": round(g / hs, 2),
             "closest": facts.features.closest_regions},
            f"The closest pair of bodies measures {g:.4g} apart and the surface cell at {fidelity} fidelity is {hs:.4g}: "
            f"{g / hs:.1f} cells across the slot, against the {_word(T.GAP_CELLS_MIN)} the floor asks for. "
            f"{_word(T.GAP_CELLS_MIN).capitalize()} cells across it is a cell of {g / T.GAP_CELLS_MIN:.4g}.",
            f"Refine the gap to at least {_word(T.GAP_CELLS_MIN)} cells across (target gap/{T.GAP_TARGET_DIVISOR:g}), or close it in CAD.",
            decision=False)
    if facts.features.min_gap is not None and facts.features.near_touching_pairs > 0:
        gap_cells = facts.features.min_gap / hs if hs > 0 else 0
        if gap_cells < T.GAP_CELLS_MIN:
            add("near_touching", "medium",
                {"min_gap": facts.features.min_gap, "surface_cell": hs, "cells_across_gap": round(gap_cells, 2),
                 "places": facts.features.near_touching_pairs},
                f"{facts.features.near_touching_pairs} places where two surfaces face each other across as little as "
                f"{facts.features.min_gap:.4g}, and the surface cell at "
                f"{fidelity} fidelity is {hs:.4g}: {gap_cells:.1f} cells across the gap, against the "
                f"{_word(T.GAP_CELLS_MIN)} the floor asks for. The renderer adds layers from both sides of it.",
                "Refine the gap region or resolve the near-contact in CAD.", decision=False)

    if purpose in FLOW_PURPOSES and facts.axes.symmetry_planes:
        add("symmetry_opportunity", "info",
            {"symmetry_planes": facts.axes.symmetry_planes, "scores": facts.axes.symmetry_scores},
            "The geometry is mirror-symmetric. If the flow is too (steady, no swirl, aligned inflow), half the domain "
            "gives the same answer for half the cells; only snappyHexMesh takes a symmetry plane.",
            "Mesh the full body by default and note the half-model option for the builder; do not ask the user unless "
            "the cell cap cannot be met otherwise.", decision=False)

    # a port the declaration left out is reported once, by the declared-port matcher below, not twice
    left_out = {o.id for o in _match(facts, ports, declared, rep, T)[1]} if declared else set()
    if roles is not None:
        for o in candidates:
            if roles.get(o.id) in (None, "opening_unknown") and o.id not in left_out:
                add("undeclared_opening", "high",
                    {"opening_id": o.id, "area": o.area, "hydraulic_diameter": o.hydraulic_diameter,
                     "centroid": o.centroid, "shape": o.shape},
                    f"Opening {o.id} is a {o.shape} {o.hydraulic_diameter:.4g} "
                    f"{facts.units.declared or 'file units'} across and nothing says what it is. Left unsaid it is sealed and "
                    "meshed as wall, so no flow enters or leaves there, and every flow rate and pressure this run reports is "
                    "computed as though that hole were not open.",
                    f"If {o.id} is sealed on the real part, a closed end is right and nothing changes. If flow goes through it, "
                    "calling it an inlet or an outlet is what puts a condition on it; without one, whatever passes through "
                    f"{o.id} is missing from the balance you are handed.")
    nme = getattr(facts.features, "non_manifold_edge_count", 0)
    if nme and purpose in FLOW_PURPOSES:
        # a handful of such edges on a large real export is a seam the mesher's surface check reports; a baffle or a
        # duplicated patch is dozens of them on a small body, and that changes what gets meshed
        structural = nme >= T.NON_MANIFOLD_EDGES_MIN or nme / max(facts.faces, 1) >= T.NON_MANIFOLD_EDGE_FRACTION
        add("non_manifold_surface", "high" if structural else "info",
            {"non_manifold_edge_count": nme, "faces": facts.faces, "watertight": facts.watertight},
            f"{nme} of this file's edges have three or more faces meeting along them" + (
                f", out of {facts.faces}: an internal baffle, a patch written out twice, or two bodies welded along a seam. "
                "An edge like that has no single inside, so a mesher either stops there or picks a side for you, and the "
                "volume you get a result for may not be the one you drew." if structural else
                ": a few seam edges on a large export, which the mesher reports and usually heals by itself."),
            "Cleaning those edges in CAD, so every edge has two faces and no more, is what guarantees the volume meshed is the "
            "one you drew. Going ahead as it stands often works: what it risks is a run that stops partway, or a mesh of the "
            "wrong side of a baffle, and neither announces itself."
            if structural else "Nothing to decide unless the file is turned back on its surface check.", decision=structural)
    if getattr(facts, "debris_components", 0):
        add("export_debris", "info", {"debris_components": facts.debris_components},
            f"{facts.debris_components} stray fragments (single triangles, folded slivers) were dropped before measuring; "
            "they are export debris, not bodies.", "Nothing to decide; clean the export when convenient.", decision=False)
    if not getattr(facts.features, "winding_consistent", True) and purpose in FLOW_PURPOSES:
        add("inconsistent_normals", "medium", {"winding_consistent": False},
            "Part of the surface has its normals flipped: a mesher that reads inside from the winding puts cells on the "
            "wrong side of that patch.", "Re-orient the normals in CAD or let the mesher's orientation fix run first.", decision=False)

    if roles is None and purpose in INTERNAL_PURPOSES and len(candidates) > T.MANY_CANDIDATES:
        add("ambiguous_openings", "medium",
            {"candidates": len(ports), "ids": [o.id for o in ports]},
            f"{len(ports)} flat faces on this part could each be an opening, and nothing in the file says which of them "
            "carry flow. Chosen wrongly, the supply and the back pressure go on faces that are walls while the real openings "
            "are sealed, and the answer looks ordinary either way.",
            f"Name the faces flow enters and leaves through, from {', '.join(o.id for o in ports)}. Everything not named is "
            "meshed as wall, which is right when it is a wall and a silent mistake when it is not.")

    rotor_names = [x.name for x in facts.names if x.implied_role == "rotating_zone"]
    ax = facts.axes
    t_min = facts.features.thickness_min
    # THE TWO MEASURED INPUTS OF THE ROTOR RULE, AND EITHER OF THEM CAN BE ABSENT RATHER THAN NO.
    #
    # `blade_thin` is True on a measured thin cluster; with no cluster it falls back to `thickness_min`, which is
    # `float | None` and None means NOT MEASURED there as everywhere in `facts.schema` (no inward chord was
    # accepted), so `t_min is not None and t_min < ...` turned an unmeasured thickness into a measured "nothing
    # on this part is blade-like". Three states, so three values: True, False, None.
    blade_thin = True if facts.features.thin_clusters else (
        None if t_min is None else t_min < T.BLADE_THICKNESS_OF_DIAG * facts.bbox.diagonal)
    # `ax.rotational_order` is None BOTH when the symmetry stage ran and found no repeat about any axis AND when
    # the stage never ran at all, and `symmetry_measured` is the only thing that tells those apart:
    # `facts.schema.Axes` says so in as many words ("`rotational_order` None is ambiguous by itself, so read it
    # with `symmetry_measured`") and `facts.measure._axes_fallback` is what a skip leaves behind - every symmetry
    # field None rather than `[]` or a score of zero.
    #
    # THE RULE READ IT AS `(ax.rotational_order or 0)`, WHICH IS AN ABSENT MEASUREMENT READ AS A MEASURED ZERO:
    # `bladed` came out False and the rotor risk VANISHED, silently and completely, on exactly the files whose
    # measurement runs out of clock - the big ones, where symmetry is the first optional stage the budget drops
    # (`facts.measure`, "time budget of Ns exhausted after Ms: symmetry skipped"). MEASURED on
    # tests/_fixtures/rotor_in_box.stl at external_cfd: with the full clock the order is 4 and the blades are
    # 0.01 thick on a 0.398 diagonal, and the catalog raises `rotor_topology`; at `time_budget_s=0` the same file
    # produced a risk list holding `unit_unknown` and `external_domain` and NOTHING about a rotor, so a file that
    # holds one stationary volume reached the builder with no line saying rotating machinery had not been ruled
    # out. A part nobody looked at is not a part with nothing there.
    order = (ax.rotational_order or 0) if getattr(ax, "symmetry_measured", True) else None
    # The rest of the rule, none of it from a stage a budget can skip: not an internal part whose own ports carry
    # the flow (there the mouths are the story, not the blades), and the single flow volume the `if` below asks for.
    rotor_shape = not (purpose in INTERNAL_PURPOSES and ports)
    bladed = order is not None and T.ROTOR_MIN_BLADES <= order < T.AXISYMMETRIC_ORDER and blade_thin is True \
        and rotor_shape
    # Nothing MEASURED here rules a rotor out. A measured order of 1 or 2 (no repeat, or two halves) and a
    # measured order of AXISYMMETRIC_ORDER and up (a round body, not a bladed one) are both answers, and so is a
    # measured thickness with nothing blade-like anywhere on the part: each of those ends the matter, and only an
    # order or a thickness NOBODY MEASURED leaves it open.
    rotor_open = blade_thin is not False and (order is None or T.ROTOR_MIN_BLADES <= order < T.AXISYMMETRIC_ORDER)
    if (rotor_names or bladed) and regions == 1:
        add("rotor_topology", "high" if rotor_names else "medium",
            {"names": rotor_names, "regions": regions, "rotational_order": ax.rotational_order,
             "rotational_axis": ax.rotational_axis, "rotational_score": ax.rotational_score},
            ("The names in this file say rotating machinery, and it holds one flow volume." if rotor_names else
             f"The body has {ax.rotational_order}-fold rotational symmetry and thin, blade-like features, which is the "
             "shape of a rotor, and it holds one flow volume.") +
            " Rotation is carried by a separate volume around the rotor that turns; with one volume everything meshed from "
            "this file stands still, so what comes back is the flow past a set of blades that are not moving.",
            "Sending the file with a cylinder around the rotor, as a body of its own, is what lets the blades turn and is the "
            "only route to a rotating answer. If a stationary answer is what you want, say so: the run goes ahead on this file "
            "and the result means what it says.")
    # THE ROTOR RISK COULD NOT BE ASSESSED, WHICH IS NOT THE SAME AS NO ROTOR RISK, so it is said rather than
    # left out. Every condition of the branch above is spelled out again here instead of leaning on the `elif`:
    # what makes this one fire is the ABSENCE of an input, and a condition that is only true by implication is
    # how the absence went unnoticed in the first place.
    elif rotor_open and rotor_shape and regions == 1 and not rotor_names and (order is None or blade_thin is None):
        # `not_measured` is never empty on this branch - the `and` above is what guarantees it - because a refusal
        # that renders as an empty list is read as "nothing missing", which is the lie this risk exists to stop.
        absent = [(field, why) for field, why, gone in (
            ("axes.rotational_order", "the symmetry stage did not run on this file, so how many times the shape "
             "repeats about an axis was never counted: the measurement's clock ran out and that stage is the "
             "first one it drops, which its own warnings say", order is None),
            ("features.thickness_min", "not one inward chord landed on this surface, so how thin the thinnest "
             "part of it is was never measured", blade_thin is None)) if gone]
        measured = []
        if order is not None:
            measured.append(f"{order}-fold rotational symmetry about principal axis {ax.rotational_axis} "
                            f"(score {ax.rotational_score:.2f})")
        if blade_thin is True:
            measured.append(f"{len(facts.features.thin_clusters)} thin, blade-like clusters" if facts.features.thin_clusters
                            else f"a minimum thickness of {t_min:.4g}, under the {T.BLADE_THICKNESS_OF_DIAG:g} of this "
                                 f"part's {facts.bbox.diagonal:.4g} diagonal that reads as blade-like")
        add("rotational_symmetry_unmeasured", "medium",
            {"not_measured": [field for field, _ in absent], "regions": regions,
             "symmetry_measured": bool(getattr(ax, "symmetry_measured", True)),
             "rotational_order": order, "thickness_min": t_min,
             "thin_clusters": len(facts.features.thin_clusters), "rotor_min_blades": T.ROTOR_MIN_BLADES,
             "axisymmetric_order": T.AXISYMMETRIC_ORDER},
            f"Whether this part is a bladed rotor is open, because {' and '.join(w for _, w in absent)}. "
            f"{_word(T.ROTOR_MIN_BLADES).capitalize()} or more thin repeats about an axis, up to "
            f"{T.AXISYMMETRIC_ORDER} where a body is round rather than bladed, is what the rule reads as a rotor"
            + (f", and what this file does have measured is {' and '.join(measured)}. " if measured else
               " and neither half of that is measured here. ")
            + "So nothing below says this part is rotating machinery and nothing below says it is not: the "
            "silence is a measurement that was not taken. Rotation is carried by a separate volume around the "
            "rotor that turns, and with the one volume this file holds, everything meshed from it stands still.",
            "Measuring the file again with a longer clock is what settles this from the file alone: the symmetry "
            "stage is the first one a short clock drops and the inward chords are cut back with it. Saying the "
            "part is rotating machinery settles it with no second measurement, and then the cylinder around the "
            "rotor, as a body of its own, is what lets the blades turn. Until one of the two, read the plan below "
            "as a plan for a part that stands still, because that is the only thing this file on its own says.",
            decision=False)

    _builder_rules(facts, purpose, rep, candidates, roles, cell_cap, engine or engine_from_brief(brief, purpose), T, add)

    if declared:
        out.extend(_match_declared(facts, [o for o in candidates if roles is None or roles.get(o.id) != "closed_end"], declared,
                                   start=n + 1, rep=rep, thresholds=T))

    if purpose == "external_cfd":
        L = max(facts.bbox.extent)
        up, down, side = T.EXTERNAL_UPSTREAM_OVER_L, T.EXTERNAL_DOWNSTREAM_OVER_L, T.EXTERNAL_LATERAL_OVER_L
        add("external_domain", "info",
            {"body_length": L, "required_box": {"upstream": up * L, "downstream": down * L, "lateral": side * L}},
            "The file is the body only; the far-field box does not exist yet.",
            f"The builder must create a domain of roughly {up:g}L upstream, {down:g}L downstream and {side:g}L lateral (L = body length).",
            decision=False)
    return out


def _pipe_wall_shape(facts: GeometryFacts, end_rings) -> bool:
    """A pipe wall is a closed shell whose end rings have empty bores: no open rim sits inside a ring's bore (a
    plenum with flush holes has rings whose bores are the holes themselves, and it is not closed). The rings need
    not share an axis: an elbow wall's end rings are perpendicular."""
    if not facts.watertight:
        return False
    rims = [o for o in facts.openings if o.kind == "rim"]
    for ring in end_rings:
        r = (ring.bore_diameter or ring.hydraulic_diameter) / 2
        if any(sum((p - q) ** 2 for p, q in zip(o.centroid, ring.centroid)) ** 0.5 <= r for o in rims):
            return False
    return True


def _diffuser_angle(facts: GeometryFacts, ports, roles, add, thresholds: Thresholds | None = None) -> None:
    """Two ports whose stubs both end at a change of section bound a taper: its length is the distance between the
    two stub ends and its half angle follows from the two bores. A cone wider than DIFFUSER_ANGLE_MAX_DEG on the
    way to an outlet separates.

    The threshold is a HALF angle here (`thresholds.json` `unit_or_frame`, the prompt's sentence and the message
    below all say so), while the textbook figure it cites is as often quoted as a total included angle, and the
    corpus writes its tapers in included angle ("included angle 26.62 deg"). The reading is open for sign-off
    (docs/thresholds.md section 6.1); nothing here moves the value, and every message states both angles so no
    reader has to guess which convention a number is in."""
    import math
    T = _T(thresholds)
    sa, sb = facts.stub(ports[0].id), facts.stub(ports[1].id)
    if not sa or not sb or not sa.end_point or not sb.end_point:
        return
    if sa.terminated_by != "area_change" or sb.terminated_by != "area_change":
        return
    L = math.dist(sa.end_point, sb.end_point)
    if L <= 0:
        return
    da, db = ports[0].hydraulic_diameter, ports[1].hydraulic_diameter
    if not da or not db or abs(da / db - 1) < T.SAME_BORE_BAND:
        return
    half = math.degrees(math.atan(abs(da - db) / 2 / L))
    wide = ports[0] if da > db else ports[1]
    narrow = ports[1] if wide is ports[0] else ports[0]
    wide_is_outlet = roles is not None and roles.get(wide.id) == "outlet"
    steep = half > T.DIFFUSER_ANGLE_MAX_DEG
    angles = f"a half angle of {half:.1f} degrees ({2 * half:.1f} degrees included)"
    if steep and wide_is_outlet:
        text = (f"The section widens from {narrow.id} to {wide.id} over {L:.4g} file units: {angles}. "
                f"Steeper than {T.DIFFUSER_ANGLE_MAX_DEG:g} degrees HALF angle toward an outlet, the flow separates from the cone and the outlet run must contain the reattachment.")
        rec = (f"Refine the cone and the outlet run (sphere at the wide end, target bore/{T.PORT_CELLS_MIN:g}) and keep the outlet run at "
               f"{T.STUB_OK_OVER_D:g} diameters or more.")
    else:
        text = (f"The section changes from {narrow.id} to {wide.id} over {L:.4g} file units: {angles}. "
                + ("Gentle enough to stay attached." if not steep else "A steep contraction accelerates the flow; the wall shear peaks at the narrow end."))
        rec = "Size the first cell from the narrow bore."
    add("diffuser_angle", "medium" if (steep and wide_is_outlet) else "info",
        {"wide_id": wide.id, "narrow_id": narrow.id, "hydraulic_diameter_wide": wide.hydraulic_diameter,
         "hydraulic_diameter_narrow": narrow.hydraulic_diameter, "taper_length": round(L, 6),
         "half_angle_deg": round(half, 2), "included_angle_deg": round(2 * half, 2),
         "area_ratio": round((wide.hydraulic_diameter / narrow.hydraulic_diameter) ** 2, 3)},
        text, rec, decision=False)


#: hexera.seed_check results per (file hash, seed, representation): the mesh is loaded once per process.
_SEED_PARITY: dict[tuple, dict[str, Any] | None] = {}
_MESH_SUFFIXES = (".stl", ".obj", ".ply")


def _seed_parity(facts: GeometryFacts, seed, rep: str) -> dict[str, Any] | None:
    """The ray-parity check of a carve seed (hexera.seed_check) when the surface is a mesh file on disk; None
    when it cannot run here (a STEP, or cached facts whose file is elsewhere). Advisory: the platform picks
    locationInMesh itself (cad_tessellate.py:881-929)."""
    if seed is None:
        return None
    path = Path(facts.source_path)
    if path.suffix.lower() not in _MESH_SUFFIXES or not path.is_file():
        return None
    key = (facts.sha256, tuple(round(float(c), 9) for c in seed), rep)
    if key in _SEED_PARITY:
        return _SEED_PARITY[key]
    try:
        from geometry_agent.agent import hexera
        out: dict[str, Any] | None = hexera.seed_check(facts, seed, rep)
    except Exception:  # noqa: BLE001 - the check is advisory; a mesh that cannot be loaded is "not tested"
        out = None
    if len(_SEED_PARITY) > 64:
        _SEED_PARITY.clear()
    _SEED_PARITY[key] = out
    return out


def _builder_rules(facts: GeometryFacts, purpose: Purpose, rep: Representation, candidates: list, roles: dict[str, str] | None,
                   cell_cap: int | None, engine: str, T: Thresholds, add) -> None:
    """The builder-audience kinds stated in the builder's frame (dev plan P4.2, docs/plan_v3_rules.md section 19):
    tilted_circular_mouth (a circular mouth tilted TILTED_MOUTH_DEG or more off the grid on a carve, measured
    against the level the renderer caps its port at), budget_forecast (the builder emulator's high figure over the
    customer's cap, which has no reader anywhere in the platform), seed_point (the carve seed with the ray-parity
    check when the mesh is on disk), gmsh_size (the size factor that gives the smallest port PORT_CELLS_MIN
    elements on gmsh), and the two conditionals, which name one key to move on one measured failure and nothing
    else. None asks the user. Every consequence here reports a measurement of the part or an arithmetic step the
    renderer takes; none of them says how the mesh will turn out, because a prediction is something the builder
    can only disagree with (docs/builder_directives.md section 6)."""
    from geometry_agent.agent import tools

    internal = purpose in INTERNAL_PURPOSES
    external = purpose == "external_cfd"
    if not (internal or external):
        return
    ports = [o for o in candidates if roles is None or roles.get(o.id) in {"inlet", "outlet", "opening_unknown"}]
    inlet = next((o for o in candidates if roles is not None and roles.get(o.id) == "inlet"), None) or (ports[0] if ports else None)
    inlet_id = inlet.id if inlet is not None else None
    frame = tools.builder_frame(facts, rep, None, inlet_id) if (internal and ports) else None
    wall_cell = float(frame["wall_cell"]) if frame else 0.0
    inlet_bore = float(frame["bore"]) if frame else 0.0
    sweep = TILTED_MOUTH_SWEEP
    # The emulator's default-strategy run, once: the budget rule needs its count and the tilted-mouth rule needs
    # its `deficit`, because `surface_level 1` only puts the port cap at the wall level while the background
    # clamp bumps nothing (snappy_runner.py:632-636). Unknown stays unknown: -1 withholds the directive.
    est0: dict[str, Any] | None = None
    if engine == "snappy" and (external or (internal and ports)):
        try:
            est0 = tools.estimate_builder_cells(facts, None, rep, "snappy", inlet_id)
        except (ValueError, ZeroDivisionError, KeyError, AttributeError, TypeError):
            est0 = None
    deficit = int((est0 or {}).get("builder", {}).get("deficit", -1)) if est0 else -1

    tilted: list[tuple[str, float]] = []
    if internal and rep == "wall_shell" and engine == "snappy":
        rows = []
        for o in ports:
            tilt, axis = tools.mouth_tilt(o)
            if tools.mouth_shape(o, rep) != "circle" or tilt < T.TILTED_MOUTH_DEG:
                continue
            bore = tools.port_bore(o, rep)
            rows.append({"id": o.id, "tilt": tilt, "axis": axis, "bore": bore,
                         "centroid": [float(c) for c in o.centroid],
                         "cells": (bore / wall_cell) if wall_cell > 0 else None})
            tilted.append((o.id, tilt))
        # One item for every tilted mouth on the part, not one each: `surface_level` is global, so four mouths and
        # four warnings would be four copies of one instruction the builder can only carry out once.
        if rows:
            rows.sort(key=lambda r: -r["tilt"])
            w, ids = rows[0], [r["id"] for r in rows]
            span = (f"{rows[-1]['tilt']:.3g} to {w['tilt']:.3g}" if len(rows) > 1 else f"{w['tilt']:.3g}")
            add("tilted_circular_mouth", "high",
                {"opening_id": w["id"], "opening_ids": ids, "tilt_deg": round(w["tilt"], 4),
                 "tilt_deg_by_id": {r["id"]: round(r["tilt"], 4) for r in rows}, "grid_axis": w["axis"],
                 "bore": w["bore"], "mouth_shape": "circle", "centroid": w["centroid"],
                 "cutoff": T.TILTED_MOUTH_DEG, "threshold_key": "TILTED_MOUTH_DEG", "wall_cell": wall_cell or None,
                 "builder_cells_across": round(w["cells"], 3) if w["cells"] else None, "frame": "builder",
                 "deficit": deficit},
                (f"{len(ids)} circular {'mouth is' if len(ids) == 1 else 'mouths are'} tilted {span} degrees off the grid axis "
                 f"({', '.join(ids)}), over {T.TILTED_MOUTH_DEG:g}; the widest of them is "
                 + (f"{w['cells']:.1f} wall cells across at a wall cell of {wall_cell:.4g}. " if w["cells"] else "on the builder's grid. ")
                 + "The renderer caps a port at port_level = max(1, surface_level + deficit - 1) (snappy_runner.py:636) while the rim "
                 "is cut at the wall level, so at the default surface_level 2 the cap cells there are twice the size of the rim's; at "
                 "surface_level 1 they are the same size."),
                "Hand the builder surface_level 1, which is the reachable form of level_delta 0 on this path: it puts every port cap at "
                "the wall level. A rotation of the part that aligns the mouths with the grid is the platform-side remedy (dev plan P10).",
                decision=False,
                target={"level_delta": 0, "sphere": {"anchor": w["centroid"], "radius": w["bore"]},
                        **({"key": "surface_level", "value": 1} if deficit == 0 else {})},
                derivation=(f"calibrated rule tilted_circular_mouth: tilt_deg {w['tilt']:.4g} >= TILTED_MOUTH_DEG {T.TILTED_MOUTH_DEG:g} "
                            f"on {len(ids)} mouth(s) (carve, snappy); 31 of 32 such carves on the learning half were graded poor and every "
                            f"grid-aligned carve set was 3 of 39; source {sweep['source']}, corpus {sweep['corpus_version']}, sweep "
                            f"{sweep['sweep_file']}, n {sweep['n']}, fires {sweep['fires']}, lift {sweep['lift']}, mcc_cv "
                            f"{sweep['mcc_cv']}, fitted {sweep['fitted_at']}, status {sweep['status']}"))

    if engine == "snappy" and cell_cap and est0 is not None and (external or (internal and ports)):
        est = est0
        low, high = int(est["cells_low"]), int(est["cells_high"])
        if high > cell_cap:
            target: dict[str, Any] = {"max_cells": int(cell_cap)}
            fit_across, fit_high = None, high
            if internal and inlet_bore > 0:
                fit_across = budget_fit(facts, rep, "snappy", inlet_id, cell_cap).get(
                    "cells_across_diameter", tools.BUILDER_CELLS_ACROSS_DEFAULT)
                fit_high = int(tools.estimate_builder_cells(facts, {"cells_across_diameter": fit_across}, rep, "snappy",
                                                            inlet_id)["cells_high"])
                target["cells_across"] = fit_across
            fits = fit_high <= (1.0 - _BUDGET_MARGIN) * cell_cap
            add("budget_forecast", "high",
                {"cells_low": low, "cells_high": high, "cell_cap": int(cell_cap), "high_over_cap": round(high / cell_cap, 3),
                 "inlet_id": inlet_id, "bore": inlet_bore or None, "cells_across": tools.BUILDER_CELLS_ACROSS_DEFAULT,
                 "wall_cell": wall_cell or None, "fits_at_cells_across": fit_across, "cells_high_at_fit": fit_high,
                 "margin": _BUDGET_MARGIN, "frame": "builder", "engine": "snappy"},
                f"The builder's own count for its default strategy (cells_across {tools.BUILDER_CELLS_ACROSS_DEFAULT}, the 0.08 L "
                f"near band one level finer, layers) is {low:,} to {high:,} cells, {high / cell_cap:.2g}x the cap of {cell_cap:,}. "
                "The only cell gate in the platform is CELL_HARD_LIMIT 8,000,000 (settings/inventory.py:384 calls it the only "
                "cell-count gate) and the customer's cap has no reader anywhere, so this number is the agent's to hold: 36 of 131 "
                "measured deliveries in the last run were over their stated cap and every one of them passed every gate.",
                (f"Hand the builder cells_across_diameter {fit_across} (forecast {fit_high:,}, under the cap by the builder's "
                 f"{_BUDGET_MARGIN:.0%} margin) and max_cells {int(cell_cap):,}." if fits and fit_across is not None else
                 f"No cells_across at or above the driver's floor of {tools.BUILDER_CELLS_ACROSS_MIN} lands under the cap with the "
                 f"builder's {_BUDGET_MARGIN:.0%} margin; raise the cap or accept a coarser tier."),
                decision=False, target=target,
                derivation=("calibrated rule budget_forecast: estimate_builder_cells cells_high over cell_cap > 1 (snappy); the "
                            "emulator reproduces drivers.py:584 and snappy_runner.py:619-686; scored against over_budget "
                            "(docs/learning_loop.md 4.3); " + "; ".join(str(b) for b in est["basis"][:3])))

    if internal and rep == "wall_shell" and engine == "snappy" and inlet is not None:
        seed = seed_point_for(facts, inlet, rep, T)
        if seed is not None:
            bore = tools.port_bore(inlet, rep)
            parity = _seed_parity(facts, seed, rep)
            tested = bool(parity and parity.get("tested"))
            inside = bool(parity.get("inside")) if tested else None
            detail = {k: parity[k] for k in ("odd_fraction", "hit_fraction", "in_metal", "enclosed") if parity and k in parity}
            add("seed_point", "high" if (tested and inside is False) else "info",
                {"opening_id": inlet.id, "seed_point": [round(float(c), 6) for c in seed], "bore": bore,
                 "inset_over_bore": T.SEED_INSET_OVER_BORE, "ray_parity_tested": tested, "inside_cavity": inside, "parity": detail,
                 "frame": "builder"},
                (f"The carve seed (snappy's locationInMesh) is {T.SEED_INSET_OVER_BORE:g} bores inside the inlet {inlet.id} along its "
                 "inward normal. " + ("By ray parity it lies inside the carved cavity." if inside else
                                      "By ray parity it does NOT lie inside the carved cavity (in the metal or outside the shell)." if tested else
                                      "Ray parity was not run here (no mesh file on disk); the handover's seed_check runs it.")
                 + " The platform's own hollow-wall fallback walks the inlet-to-outlet chord, which on a bend is the air between "
                 "the legs (21 seedfix reruns in the export)."),
                "Use this seed as locationInMesh (the step-8 hook, dev plan 8.7); until then it is advisory.",
                decision=False, target={"seed_point": [round(float(c), 6) for c in seed]},
                derivation=("seed_point: catalog.seed_point_for (inlet centroid plus SEED_INSET_OVER_BORE bores along the inward "
                            "normal), hexera.seed_check by ray parity over the nesting directions; scored against "
                            "wall_faces_zero_or_leak once a harness bundle carries it (docs/learning_loop.md 3)"))

    if engine == "gmsh" and ports:
        from geometry_agent.agent.tools import GMSH_SIZE_FACTOR, port_min_dimension
        diag = float(facts.bbox.diagonal or 0.0)
        smallest = min(ports, key=port_min_dimension)
        feature = float(port_min_dimension(smallest))
        if diag > 0 and feature > 0:
            h = GMSH_SIZE_FACTOR * diag
            elements = feature / h
            if elements < T.PORT_CELLS_MIN:
                value = round(min(GMSH_SIZE_FACTOR, feature / T.PORT_CELLS_MIN / diag), 6)
                add("gmsh_size", "medium",
                    {"opening_id": smallest.id, "min_dimension": feature, "diagonal": diag, "h_default": h,
                     "elements_across_default": round(elements, 3), "cutoff": T.PORT_CELLS_MIN, "threshold_key": "PORT_CELLS_MIN",
                     "size_factor_default": GMSH_SIZE_FACTOR, "frame": "builder", "engine": "gmsh"},
                    f"gmsh's default size ({GMSH_SIZE_FACTOR:g} of the diagonal, {h:.4g}) puts {elements:.1f} elements across the "
                    f"smallest port {smallest.id}'s {feature:.4g} minimum dimension, against the {T.PORT_CELLS_MIN:g} the floor "
                    f"asks for; {T.PORT_CELLS_MIN:g} elements across it is h = {feature / T.PORT_CELLS_MIN:.4g}.",
                    f"Set size {{mode factor, value {value:g}}} so that port gets {T.PORT_CELLS_MIN:g} elements across "
                    f"(h = {feature / T.PORT_CELLS_MIN:.4g}).",
                    decision=False, target={"gmsh_size_value": value},
                    derivation=(f"calibrated rule gmsh_size: elements across the smallest port at the default size {elements:.3g} < "
                                f"PORT_CELLS_MIN {T.PORT_CELLS_MIN:g} (gmsh); size.value = min dimension / PORT_CELLS_MIN / diagonal "
                                "(gmsh/driver.py:258-262); every gmsh mesh the export graded poor was a coarse tet mesh and 22 of 22 "
                                "failed cases were gmsh fluid domains; scored against first_attempt_failed on gmsh "
                                "(docs/learning_loop.md 4.3)"))

    _conditionals(facts, rep, engine, internal, cell_cap, inlet_id, wall_cell, tilted, T, add)


def _conditionals(facts: GeometryFacts, rep: Representation, engine: str, internal: bool, cell_cap: int | None,
                  inlet_id: str | None, wall_cell: float, tilted: list[tuple[str, float]], T: Thresholds, add) -> None:
    """The two conditionals: one platform key to move, on one phrase the classifier actually hands the planner.

    A conditional is not a prediction. It says nothing about what this mesh comes out like; it says what to do if
    a named measurement comes back, and it exists because `engines/snappy/judge.py` is the one channel either
    planner prompt instructs the model to obey (`planner.py:42`, `:65`), so a directive written in that shape is
    house style rather than invention. Two, and no more: the list the builder reads is short by construction.

    `skew_repair` rides on a tilted mouth, which is the measured reason a skew critique can arrive on this part.
    `carve_leak_repair` exists because the CARVE LEAKED repair is regime-blind: it tells an internal carve to
    enlarge `domain_margin` (judge.py:42-48), and `render_internal_case` reads no `domain_margin` at all
    (snappy_runner.py:619 pads by `max(2 base_cell, 0.03 maxext)`). It is admitted only when there is an
    affordable value of the one key that does change the surface that seals."""
    from geometry_agent.agent import tools
    if not (internal and rep == "wall_shell" and engine == "snappy"):
        return
    if tilted:
        ids = [i for i, _ in tilted]
        worst = max(t for _, t in tilted)
        add("skew_repair", "medium",
            {"trigger": "WIDESPREAD skewness", "opening_ids": ids, "tilt_deg_max": round(worst, 4),
             "quality_default": "balanced", "frame": "builder", "engine": "snappy"},
            f"{len(ids)} circular {'mouth is' if len(ids) == 1 else 'mouths are'} over {T.TILTED_MOUTH_DEG:g} degrees off the grid "
            f"({', '.join(ids)}, worst {worst:.3g} degrees), which is the measured reason a skew critique can arrive on this part. "
            "quality strict sets minTetQuality 1e-13, maxNonOrtho 65 and nRelaxedIter 6 (snappy_runner.py:670-673); it also "
            "suppresses prism-layer inflation, which is why the planner's own prompt starts at balanced.",
            "IF the critique says WIDESPREAD skewness: quality strict, and leave n_layers where it is.",
            decision=False, target={"key": "quality", "value": "strict"},
            derivation=("conditional on engines/snappy/judge.py:64 `_repair_message('skew_fraction')`, which is the text the "
                        "planner receives as its critique; quality values from snappy_runner.py:670-673"))
    thin = min((c.thickness_min for c in facts.features.thin_clusters), default=None)
    gap = facts.features.min_gap
    seal = min([x for x in (thin, gap) if x], default=None)
    # Under ONE wall cell, not under the layer floor: the cut is arithmetic rather than a tuned threshold, and it
    # says something exact. A feature narrower than the cell is a feature the background surface has no cell
    # inside, which is what a leaked carve is made of. It holds on 69 of the 161 carves in the export corpus;
    # the layer floor of three cells would have put this line on 120 of them, which is background noise.
    if not (seal and wall_cell > 0 and cell_cap and seal / wall_cell < 1.0):
        return
    # The largest cells_across_diameter that still forecasts under the builder's own margin: a conditional whose
    # value nobody can afford is not an instruction either.
    across, best = tools.BUILDER_CELLS_ACROSS_DEFAULT, None
    for step in range(1, 9):
        trial = tools.BUILDER_CELLS_ACROSS_DEFAULT + 4 * step
        if trial > DIRECTIVE_KEYS["snappy_internal"]["cells_across_diameter"]["renderer"][1]:
            break
        try:
            cells = int(tools.estimate_builder_cells(facts, {"cells_across_diameter": trial}, rep, "snappy",
                                                     inlet_id)["cells_high"])
        except (ValueError, ZeroDivisionError, KeyError, AttributeError, TypeError):
            break
        if cells > (1.0 - _BUDGET_MARGIN) * cell_cap:
            break
        across, best = trial, cells
    if best is None:
        return
    add("carve_leak_repair", "medium",
        {"trigger": "CARVE LEAKED", "seal_feature": seal, "wall_cell": wall_cell,
         "cells_across_seal": round(seal / wall_cell, 3), "cells_across_diameter": across, "cells_high_at_value": best,
         "cell_cap": int(cell_cap), "frame": "builder", "engine": "snappy"},
        f"The thinnest feature the carve has to seal measures {seal:.4g}, {seal / wall_cell:.2f} wall cells at "
        f"cells_across_diameter {tools.BUILDER_CELLS_ACROSS_DEFAULT} and "
        f"{seal / wall_cell * across / tools.BUILDER_CELLS_ACROSS_DEFAULT:.2f} at {across}. The classifier's CARVE LEAKED repair "
        "asks for a larger domain_margin (judge.py:42-48); render_internal_case reads no domain_margin and pads by "
        f"max(2 base_cell, 0.03 maxext) (snappy_runner.py:619), so on this path cells_across_diameter is the key that changes the "
        f"surface that seals: {across} forecasts {best:,} cells of the {int(cell_cap):,} cap.",
        f"IF the critique says CARVE LEAKED: cells_across_diameter {across}, and leave domain_margin alone, which this renderer "
        "does not read.",
        decision=False, target={"key": "cells_across_diameter", "value": int(across)},
        derivation=("conditional on engines/snappy/judge.py:42-48 `_repair_message('wall_faces')` against "
                    "snappy_runner.py:619 `render_internal_case`, which authors no domain_margin; the forecast is "
                    "tools.estimate_builder_cells at that value"))


def declared_pairs(facts: GeometryFacts, ports, declared: list[dict] | None, rep: Representation | None = None,
                   thresholds: Thresholds | None = None) -> dict[str, dict]:
    """opening id -> the declaration that claims it, by the same pairing `_match` uses (checker R9: a role
    question on a declared port is a false alarm). On a wall shell or an annular passage the rings the ring
    rules took out are offered after `ports`, so a declaration that names one claims it (declared ports win)."""
    pairs: dict[str, dict] = {}
    seen = {o.id for o in ports}
    extra = [o for o in port_openings(facts, rep, declared, thresholds) if o.id not in seen] if rep in ("wall_shell", "annular_fluid") else []
    _match(facts, list(ports) + extra, declared or [], rep, thresholds, pairs)
    return pairs


def _match(facts: GeometryFacts, ports, declared: list[dict], rep: Representation | None = None,
           thresholds: Thresholds | None = None, pairs: dict[str, dict] | None = None) -> tuple[list[tuple[dict, list]], list]:
    """Pair each declared port with the closest measured candidate by area and location. Returns the declarations
    that matched nothing (each with the candidates still free at that point) and the measured ports no declaration
    claimed; `pairs`, when given, receives opening id -> declaration for every match."""
    T = _T(thresholds)
    unmatched: list[tuple[dict, list]] = []
    remaining = {o.id: o for o in ports}
    for d in declared:
        best = None
        for oid, o in remaining.items():
            score = 0.0
            area = d.get("area")
            if area:
                # a ring's port is its bore (a pierced wall end) minus any inner body's end cap (an annulus)
                o_area = port_area(facts, o, rep, T)
                if o_area <= 0 or abs(o_area / area - 1.0) > T.AREA_MATCH_BAND:
                    continue
                score += abs(o_area / area - 1.0)
            near = d.get("near")
            if near:
                dist = sum((a - b) ** 2 for a, b in zip(near, o.centroid)) ** 0.5
                if dist > T.NEAR_MATCH_OVER_D * o.hydraulic_diameter:
                    continue
                score += dist / max(o.hydraulic_diameter, 1e-9)
            if best is None or score < best[0]:
                best = (score, oid)
        if best is None:
            unmatched.append((d, list(remaining.values())))
        else:
            if pairs is not None:
                pairs[best[1]] = d
            del remaining[best[1]]
    return unmatched, list(remaining.values())


def _match_declared(facts: GeometryFacts, ports, declared: list[dict], start: int, rep: Representation | None = None,
                    thresholds: Thresholds | None = None) -> list[Risk]:
    out: list[Risk] = []
    n = start
    unmatched, remaining = _match(facts, ports, declared, rep, thresholds)
    for d, candidates in unmatched:
        out.append(_risk(n, "declared_port_unmatched", "high",
                         {"declared": d, "measured_candidates": [
                             {"id": o.id, "area": o.area, "hydraulic_diameter": o.hydraulic_diameter, "centroid": o.centroid}
                             for o in candidates]},
                         f"Your port list names {d.get('name')!r}, and no opening in this file is that size or in that "
                         "place. The file and the description of it disagree, and the file is what gets meshed, so going by "
                         "the description hands you a result for a part that is not in it.",
                         f"Point {d.get('name')!r} at one of the openings the file does have ("
                         + (", ".join(f"{o.id} at {o.hydraulic_diameter:.4g}" for o in candidates)
                            or "none close enough to offer")
                         + f" across, in {facts.units.declared or 'file units'}"
                         + ") and the run goes ahead on the part you sent. If the list is right and the file is the wrong "
                         "export, sending the right file is the other way. Nobody here can choose for you: only you know "
                         "which of the two is true.", True))
        n += 1
    for o in remaining:
        out.append(_risk(n, "undeclared_opening", "high",
                         {"opening_id": o.id, "area": o.area, "hydraulic_diameter": o.hydraulic_diameter,
                          "centroid": o.centroid, "shape": o.shape},
                         f"The part has an opening at {o.id}, a {o.shape} {o.hydraulic_diameter:.4g} "
                         f"{facts.units.declared or 'file units'} across, that your "
                         "port list does not mention. Undeclared it is sealed and meshed as wall, so nothing enters or leaves "
                         "there and the flow balance this run reports leaves it out.",
                         f"If {o.id} is sealed on the real part, a closed end is right and nothing changes. If it carries "
                         "flow, saying whether it is an inlet or an outlet is what gives it a condition.", True))
        n += 1
    return out


# --- calibrated one-feature rules as data (learn/rules.json), evaluated beside the hand-written rules -----------

RULES_FILE = Path(__file__).resolve().parents[1] / "learn" / "rules.json"
RULE_OPS = {"gt": operator.gt, ">": operator.gt, "ge": operator.ge, ">=": operator.ge,
            "lt": operator.lt, "<": operator.lt, "le": operator.le, "<=": operator.le,
            "eq": operator.eq, "==": operator.eq, "ne": operator.ne, "!=": operator.ne}
#: Feature-bank keys a rule's stratum is compared with (dev plan P5: a rule fitted in one stratum never fires outside it).
STRATUM_KEYS = ("representation", "engine", "stratum")
_RULE_SEVERITIES = {"info", "low", "medium", "high", "blocking"}


def load_rules(path: str | Path | None = None) -> list[dict]:
    """The calibrated rules on disk: {"version", "rules": [...]} or a bare list. Missing file means no rules."""
    p = Path(path) if path else RULES_FILE
    if not p.is_file():
        return []
    doc = json.loads(p.read_text(encoding="utf-8"))
    rules = doc.get("rules", []) if isinstance(doc, dict) else doc
    return [r for r in rules if isinstance(r, dict)]


class _Fill(dict):
    def __missing__(self, key):
        return "{" + key + "}"


def _rule_cutoff(rule: dict, T: Thresholds) -> float | None:
    """A number, or the name of a thresholds key whose value in force is the cutoff (so a calibrated cutoff is
    governed like every other threshold)."""
    c = rule.get("cutoff")
    if isinstance(c, str):
        c = getattr(T, c, None)
    if isinstance(c, bool) or not isinstance(c, (int, float)):
        return None
    return c


def data_rules(facts: GeometryFacts, features: dict[str, Any], thresholds: Thresholds | None = None,
               rules: list[dict] | None = None, start: int = 1, statuses: tuple[str, ...] = ("shipped",)) -> list[Risk]:
    """Evaluate calibrated one-feature rules over a feature bank row and return Risk objects shaped like the
    hand-written ones (ids k<start>.., detected_by catalog, the rule's provenance in `derivation`).

    features: the bank's row for this case: scalar features by key, per-port features as {opening_id: value},
    plus representation / engine for the stratum gate. A rule fires only when its status is in `statuses`, its
    stratum is `any` or equals the row's representation, engine or stratum, its measurement_key is present and
    numeric, and `<value> <op> <cutoff>` holds. rules None reads learn/rules.json (shipped empty)."""
    T = _T(thresholds)
    rules = load_rules() if rules is None else rules
    out: list[Risk] = []
    n = start - 1
    row_strata = {str(features.get(k)) for k in STRATUM_KEYS if features.get(k) is not None}
    for rule in rules:
        if rule.get("status", "proposed") not in statuses:
            continue
        stratum = rule.get("stratum") or "any"
        if stratum != "any" and stratum not in row_strata:
            continue
        key, kind = rule.get("measurement_key"), rule.get("kind")
        op = RULE_OPS.get(str(rule.get("op")))
        cutoff = _rule_cutoff(rule, T)
        if not key or not kind or op is None or cutoff is None or key not in features:
            continue
        value = features[key]
        subjects = list(value.items()) if isinstance(value, dict) else [(None, value)]
        severity = rule.get("severity") if rule.get("severity") in _RULE_SEVERITIES else "medium"
        prov = rule.get("provenance") or {}
        for subject, v in subjects:
            if isinstance(v, bool) or not isinstance(v, (int, float)) or not op(v, cutoff):
                continue
            n += 1
            measurement: dict[str, Any] = {key: v, "cutoff": cutoff}
            if isinstance(rule.get("cutoff"), str):
                measurement["threshold_key"] = rule["cutoff"]
            if subject is not None:
                measurement["opening_id" if facts.opening(str(subject)) is not None else "subject"] = subject
            fill = _Fill(measurement=v, cutoff=cutoff, subject=subject if subject is not None else "the case", key=key, kind=kind)
            text = str(rule.get("text_template") or "{key} is {measurement} against a cutoff of {cutoff}.").format_map(fill)
            rec = str(rule.get("recommendation") or "").format_map(fill)
            out.append(Risk(id=f"k{n}", kind=str(kind), severity=severity, measurement=measurement, consequence=text,
                            recommendation=rec, requires_user_decision=rule.get("audience") == "user", detected_by="catalog",
                            derivation=(f"calibrated rule {kind}: {key} {rule.get('op')} {cutoff} ({rule.get('stratum') or 'any'}); "
                                        f"source {prov.get('source')}, corpus {prov.get('corpus_version')}, n {prov.get('n')}, "
                                        f"lift {prov.get('lift')}, mcc_cv {prov.get('mcc_cv')}, fitted {prov.get('fitted_at')}")))
    return out
