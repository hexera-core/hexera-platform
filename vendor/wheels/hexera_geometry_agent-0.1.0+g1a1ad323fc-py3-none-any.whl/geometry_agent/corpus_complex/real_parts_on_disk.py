"""Real parts already on this machine, described by inspection rather than construction.

Each case points at a file under C:/Users/rehaa/Downloads (expected.json carries an absolute `source`; nothing is
copied). The numbers asserted come from looking at the part: an iso render of every file, direct mesh queries
where the render was not enough (edge-count histograms to tell an open shell from two closed bodies that touch,
the ring of triangles at a nozzle exit, the 120-degree fin layout from the fin bounding boxes), the STEP header
for declared units, and OCP for the solid count of the big assembly. Only what those checks made certain is
asserted; roles are left to the model."""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

from geometry_agent.corpus import Case, port

FAMILY = "real_parts_on_disk"
DL = "C:/Users/rehaa/Downloads/"
GMSH = DL + "gmsh-4.13.1-Windows64/gmsh-4.13.1-Windows64/tutorials/"

# ---- inspected dimensions (metres unless the file is in mm) --------------------------------------------------
BELL_LEN, BELL_EXIT_D, BELL_INLET_D = 0.425, 0.22, 0.16      # bbox z; exit rim = bbox x extent; inlet rim 4A/P
LV3_EXIT = (0.0, 0.0, 0.0)                                   # the one open (ring) end; the head end is closed
ENGINE_EXIT = (0.0, 0.0, 0.0)                                # 130-triangle annulus r=0.0515..0.0558 at z=0
ENGINE_FITTINGS = 3                                          # inlet fittings at 30, 150, 270 degrees
ROCKET_FINS = 3                                              # fin plates at -90, 30, 150 degrees (bbox check)
BULKHEAD_ARMS = 6
NUT_FLATS = 6
GRID_PLATES = 36                                             # 432 faces = 36 boxes of 12
REENTRY_BODIES = 7                                           # body, 2 wings, tail, ventral fin, 2 strakes
RDO_SOLIDS, RDO_FREE_FACES = 401, 178                        # OCP: TopAbs_SOLID count; faces owned by no solid
AXISYM = 12                                                  # what the facts report for a body of revolution


@dataclass
class SourceCase(Case):
    """A case whose geometry stays where it is; expected.json names it by absolute path."""
    source: str = ""

    def write(self, out: Path) -> Path:
        d = out / self.name
        d.mkdir(parents=True, exist_ok=True)
        exp = {"source": self.source, "purpose": self.purpose, "family": self.family, **self.expected}
        if self.brief:
            exp["brief"] = self.brief
        if self.note:
            exp["note"] = self.note
        (d / "expected.json").write_text(json.dumps(exp, indent=1, default=float))
        return d


def _src(name: str, source: str, purpose: str, expected: dict, brief: str, note: str = "") -> SourceCase:
    return SourceCase(name=name, family=FAMILY, purpose=purpose, build=lambda: None, expected=expected,
                      brief=brief, note=note, source=source)


def build_cases() -> list[Case]:
    ext_ok = {"forbid_risks": ["not_watertight"]}
    return [
        _src("bell_nozzle", DL + "A_bell_nozzle.stl", "internal_cfd",
             {"regions": 1, "watertight": False, "openings": 2, "port_candidates": 2,
              "ports": [port((0, 0, 0), "inlet", BELL_INLET_D, kind="rim", needs_model=True),
                        port((0, 0, BELL_LEN), "outlet", BELL_EXIT_D, kind="rim", needs_model=True)],
              "rotational_symmetry_order": AXISYM, "symmetry_planes_min": 2,
              "expect_risks": ["not_watertight", "symmetry_opportunity"], "measure_seconds_max": 60},
             "Bell nozzle inner contour exported as a bare surface: chamber gas enters the small end and leaves at "
             "the bell; internal CFD of the expansion.",
             "open shell with two rims, converging from the inlet rim at once so both stubs are short"),
        _src("swept_fin", DL + "B_swept_fin.stl", "external_cfd",
             {"regions": 1, "watertight": True, "openings": 0, "symmetry_planes_min": 1,
              "expect_risks": ["external_domain", "symmetry_opportunity"],
              "forbid_risks": ["not_watertight", "region_purpose_mismatch"], "measure_seconds_max": 30},
             "Swept trapezoidal rocket fin, transonic external flow for normal force and hinge moment.",
             "one closed plate 22 mm thick with tapered edges; mirror plane is the fin mid-plane"),
        _src("grid_fin", DL + "C_grid_fin.stl", "external_cfd",
             {"regions": GRID_PLATES, "watertight": True, "port_candidates": 0, "symmetry_planes_min": 1,
              "expect_risks": ["external_domain", "multi_body_external"], **ext_ok, "measure_seconds_max": 30},
             "Grid fin built from 36 separate lattice plates that were never unioned; external subsonic flow for "
             "drag and control force.",
             "432 triangles = 36 closed boxes; every flat face is a plate side, none is a port"),
        _src("bulkhead", DL + "Bulkhead.stl", "structural",
             {"regions": 1, "watertight": True, "rotational_symmetry_order": BULKHEAD_ARMS, "port_candidates": 0,
              "planar_faces_min": BULKHEAD_ARMS, "forbid_risks": ["not_watertight", "region_purpose_mismatch"],
              "measure_seconds_max": 30},
             "Six-arm machined bulkhead plate, 150 mm across and 6 mm thick, with a central bore and bolt bosses; "
             "static load at the arm tips.",
             "six arms at 60 degrees; the flat outer faces of the arm heads are plate sides"),
        _src("lv3_engine", DL + "LV3_Engine.stl", "internal_cfd",
             {"regions": 1, "watertight": True, "openings": 1, "port_candidates": 0,
              "ports": [port(LV3_EXIT, "any", kind="ring", classification="ring")],
              "rotational_symmetry_order": AXISYM, "symmetry_planes_min": 2,
              "expect_risks": ["ring_faces_present", "symmetry_opportunity"], **ext_ok, "measure_seconds_max": 30},
             "LV3 liquid engine chamber and nozzle as a 2 mm wall solid with the injector end closed; the user "
             "wants the hot-gas flow from injector to exit, which this file does not contain.",
             "thickness min/p05/median 1.98/2.00/2.03 mm: the file is the metal; one annular end at x=0"),
        _src("gmsh_t13", GMSH + "t13_data.stl", "structural",
             {"regions": 1, "watertight": True, "openings_min": 4, "port_candidates": 0, "symmetry_planes_min": 1,
              "forbid_risks": ["not_watertight", "region_purpose_mismatch"], "measure_seconds_max": 30},
             "gmsh tutorial 13 bracket: a hollow block with a bore through two walls; static structural after "
             "surface remeshing.",
             "four annular faces where the bore crosses the two walls; mirror plane x=0"),
        _src("gmsh_t20", GMSH + "t20_data.step", "structural",
             {"bodies": 1, "regions": 1, "watertight": True, "unit_declared": "mm",
              "rotational_symmetry_order": NUT_FLATS, "port_candidates": 0,
              "forbid_risks": ["not_watertight", "region_purpose_mismatch"], "measure_seconds_max": 30},
             "gmsh tutorial 20 hex nut from STEP, chamfered both ends; bolt-preload structural case in mm.",
             "both annular end faces meet 45 degree chamfers, so no opening is expected from the tubularity rule"),
        _src("tvc_inner", DL + "TVC Inner Gimbal.stl", "structural",
             {"regions": 1, "watertight": True, "forbid_risks": ["not_watertight", "region_purpose_mismatch"],
              "measure_seconds_max": 30},
             "TVC inner gimbal ring with actuator bracket and trunnion pins, mm; thrust load through the pins.",
             "the 1.75 mm trunnion pin reads as a port candidate: a solid rod and a fluid tube look the same"),
        _src("tvc_outer", DL + "TVC Outer Gimbal.stl", "structural",
             {"regions": 1, "watertight": True, "forbid_risks": ["not_watertight", "region_purpose_mismatch"],
              "measure_seconds_max": 30},
             "TVC outer gimbal frame, mm; structural load from the inner gimbal trunnions.",
             "one machined part; the file also carries an 8-triangle sliver of 2.6e-10 mm3 and a 2-triangle "
             "zero-area fragment, which are export debris, not bodies"),
        _src("isomodule", DL + "isomodule_flat_6p0_ID_recessed (urethane molding).stl", "structural",
             {"regions": 2, "watertight": True, **ext_ok, "measure_seconds_max": 60},
             "Flat isogrid urethane-molding module made of two closed halves that touch on the plane y=0.2496; "
             "stiffness check under a distributed load.",
             "edge histogram {2: 90442, 4: 67}, zero single-face edges; pairing the four faces of each shared edge "
             "by winding and coplanarity gives exactly two closed bodies (31010 faces 4.88e-4 m3, 29374 faces "
             "4.65e-4 m3)"),
        _src("nose_cone", DL + "Nose Cone Module Assembly (1).stl", "external_cfd",
             {"regions_min": 3, "watertight": True, "port_candidates": 0, "symmetry_planes_min": 1,
              "interfaces_min": 1, "expect_risks": ["external_domain", "multi_body_external", "symmetry_opportunity"],
              **ext_ok, "measure_seconds_max": 60},
             "Nose cone module assembly (cone shell, tip, coupler ring, internal bulkhead and brackets) as separate "
             "bodies; transonic external flow over the cone.",
             "the cone itself is a body of revolution; six 2-fold brackets sit at 60 degrees inside it"),
        _src("engine", DL + "ENGINE.stl", "internal_cfd",
             {"bodies": 2, "regions": 2, "watertight": True, "port_candidates": 0,
              "rotational_symmetry_order": ENGINE_FITTINGS, "symmetry_planes_min": 1,
              "ports": [port(ENGINE_EXIT, "any", kind="ring", classification="ring")],
              "expect_risks": ["ring_faces_present", "region_purpose_mismatch"], **ext_ok, "measure_seconds_max": 60},
             "Liquid rocket engine as two solids, a 3 mm chamber-and-nozzle wall and an injector head with three "
             "inlet fittings at 120 degrees; the user wants the gas flow from injector to nozzle exit.",
             "the nozzle exit at z=0 is a planar annulus of 130 triangles (r 51.5 to 55.8 mm) whose outer edge "
             "meets a 23 degree cone; thickness min/p05 2.97/3.01 mm says the file is metal"),
        _src("reentry_vehicle", DL + "R03_reentry_vehicle.stl", "external_cfd",
             {"regions": REENTRY_BODIES, "watertight": True, "port_candidates": 0, "planar_faces_min": 1,
              "symmetry_planes_min": 1,
              "expect_risks": ["external_domain", "multi_body_external", "symmetry_opportunity"], **ext_ok,
              "measure_seconds_max": 60},
             "Winged reentry vehicle: body, two wings, vertical tail, ventral fin and two strakes as separate bodies; "
             "hypersonic external flow for aerodynamic loads.",
             "mirror plane x=0 only (two wings, one tail); the flat 180 mm nose face is a wall, not a port"),
        _src("rocket_cfd", DL + "Rocket_modelled _for_CFD.stl", "external_cfd",
             {"regions_min": 5, "watertight": True, "symmetry_planes_min": 1,
              "rotational_symmetry_order": ROCKET_FINS, "port_candidates": 0,
              "expect_risks": ["external_domain", "multi_body_external"], **ext_ok, "measure_seconds_max": 60},
             "Three-fin sounding rocket modelled for CFD: airframe tube, nose cone, three fins at 120 degrees and "
             "six booster tubes as separate bodies; subsonic external flow for drag and stability.",
             "fin plates at -90, 30 and 150 degrees (bbox y -0.235..0.119): 3-fold about z, one mirror plane x=0; "
             "an external body has no fluid port"),
        _src("hybrid_engine", DL + "HYBRID_ENGINE.stl", "internal_cfd",
             {"regions_min": 10, "watertight": True, "expect_risks": ["ring_faces_present"], **ext_ok,
              "measure_seconds_max": 60},
             "Hybrid rocket motor assembly (chamber wall, injector head, bolts, fittings) as dozens of touching "
             "solids; the user wants the chamber-to-nozzle gas flow.",
             "edge histogram {2: 491328, 4: 765}, zero single-face edges; pairing the four faces of each shared edge "
             "by winding gives closed bodies (chamber 23224 faces, 3.90e-4 m3, the same chamber ENGINE.stl reads as "
             "watertight)"),
        _src("rdo2015", DL + "RDO2015_3802.stp", "structural",
             {"bodies": RDO_SOLIDS + 1, "unit_declared": "mm", "watertight": False,
              "expect_risks": ["not_watertight"], "measure_seconds_max": 150},
             "Creo vehicle-structure assembly RDO2015: 401 solids (frame members, brackets, fasteners) plus a few "
             "free sheet surfaces; static structural in mm.",
             "OCP: 401 solids, 178 faces owned by no solid (the one extra body the loader makes of them); the header "
             "declares SI_UNIT(.MILLI.,.METRE.) at byte 37.4M"),
    ]


def case_names() -> list[str]:
    return [c.name for c in build_cases()]


def main(out: Path | None = None) -> Path:
    out = out or Path("eval/corpus_complex") / FAMILY
    out.mkdir(parents=True, exist_ok=True)
    for c in build_cases():
        c.write(out)
        print(c.name, "->", c.source)
    return out


if __name__ == "__main__":
    main()
