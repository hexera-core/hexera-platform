"""Machinery: complex internal-flow fluid volumes built from sweeps, revolves and booleans.

Every case is a function of a few dimensions and the expected answer is computed from the same numbers: where
each port is, its hydraulic diameter, how many diameters of constant section lie behind it (the stub), which
flat faces are chamber walls rather than ports, where a ring (a face with a hole through it) sits, and which
catalog risks the construction implies (short_stub when a port's straight run is under 5 D, velocity_spread when
port bores differ by more than 2x, ring_faces_present when a ring exists).

Cases:
  pump_volute                spiral casing swept with a growing circle 360 degrees around an impeller disc, an
                             axial inlet eye on top, a tangential discharge nozzle off the tongue; 6 D stubs
  pump_volute_short_nozzle   same volute with a 2 D discharge nozzle: short_stub
  globe_valve                two coaxial 6 D ports, S-shaped path through a seat wall with a central orifice;
                             the chamber's flat walls are planar faces, the four wall faces with a branch root
                             or the orifice through them are rings
  globe_valve_wide_seat      same valve with a wider seat chamber: the two chamber walls facing the seat have
                             0.7 D of box behind them and are still walls
  exhaust_manifold_4to1      four equal 3 D runners, each with a 90 degree bend, merging into one collector
                             with a 6 D outlet and a blanked end: short_stub on the runners
  exhaust_manifold_4to1_long same with 6 D runners: no short stub anywhere
  serpentine_cold_plate_6u   one channel with six U-turns between two vertical 6 D ports
  cyclone_separator          tangential inlet, cylinder on cone, vortex finder tube nested through the roof
                             (roof ring plus interior ring at the finder's lip), overflow and underflow ports
  wye_60_unequal             60 degree wye: a 60 mm trunk and through leg, a 25 mm side leg with a 3 D run
"""
from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import trimesh
from trimesh.transformations import rotation_matrix

from geometry_agent.corpus import GENTLE_STUB_TOL, Case, _case, _cyl, _union, port, revolve_closed, sweep_circle

FAMILY = "machinery"
OUT_DIR = Path("eval/corpus_complex") / FAMILY
SECTIONS = 48


# ---- helpers ---------------------------------------------------------------------------------------------------

def _unit(v) -> np.ndarray:
    v = np.asarray(v, dtype=float)
    return v / np.linalg.norm(v)


def tube_var(path: np.ndarray, radii: np.ndarray, sections: int = SECTIONS) -> trimesh.Trimesh:
    """Closed tube of varying radius along a planar (z = 0) path. Rings are perpendicular to the local tangent
    (average of the two adjacent segments at interior stations); both ends are closed with flat caps."""
    path = np.asarray(path, dtype=float)
    radii = np.asarray(radii, dtype=float)
    n = len(path)
    tangents = np.zeros_like(path)
    tangents[0] = _unit(path[1] - path[0])
    tangents[-1] = _unit(path[-1] - path[-2])
    for i in range(1, n - 1):
        tangents[i] = _unit(_unit(path[i] - path[i - 1]) + _unit(path[i + 1] - path[i]))
    up = np.array([0.0, 0.0, 1.0])
    ang = np.linspace(0, 2 * np.pi, sections, endpoint=False)
    rings = []
    for c, t, r in zip(path, tangents, radii):
        side = _unit(np.cross(t, up))
        rings.append(c + r * (np.outer(np.cos(ang), side) + np.outer(np.sin(ang), up)))
    verts = [np.vstack(rings)]
    faces = []
    for k in range(n - 1):
        a, b = k * sections, (k + 1) * sections
        for i in range(sections):
            j = (i + 1) % sections
            faces.append([a + i, b + i, b + j])
            faces.append([a + i, b + j, a + j])
    c0 = n * sections
    c1 = c0 + 1
    verts.append(np.array([path[0], path[-1]]))
    last = (n - 1) * sections
    for i in range(sections):
        j = (i + 1) % sections
        faces.append([c0, j, i])
        faces.append([c1, last + i, last + j])
    m = trimesh.Trimesh(np.vstack(verts), np.asarray(faces), process=True)
    m.merge_vertices()
    trimesh.repair.fix_normals(m)
    return m


def _sphere(radius: float, center) -> trimesh.Trimesh:
    s = trimesh.creation.icosphere(subdivisions=3, radius=radius)
    s.apply_translation(center)
    return s


# ---- pump volute -----------------------------------------------------------------------------------------------

def pump_volute(d_eye: float = 0.08, d_noz: float = 0.06, eye_over_d: float = 6.0, noz_over_d: float = 6.0,
                alpha_deg: float = 25.0):
    """Spiral casing: a circle growing from 0.35 to 1.0 nozzle radii swept 375 degrees around a base circle, its
    inner edge on the base circle, overlapping an impeller disc; an axial eye on the disc top; a straight
    discharge nozzle leaving the spiral end tangentially, rotated alpha outward so it clears the tongue."""
    r_end = d_noz / 2
    r0 = 0.35 * r_end
    R_b = 4.0 * r_end
    delta0 = 0.5 * r0
    two_pi = 2 * np.pi
    beta = np.radians(15.0)

    def r_of(th):
        return r0 + (r_end - r0) * min(th, two_pi) / two_pi

    def R_of(th):
        return R_b + r_of(th) + delta0 * max(0.0, 1 - th / two_pi)

    def pt(th):
        R = R_of(th)
        return np.array([R * np.cos(th), R * np.sin(th), 0.0])

    split = np.radians(270.0)
    th_a = np.linspace(0.0, split, 136)
    th_b = np.linspace(split, two_pi + beta, 54)
    end = pt(two_pi + beta)
    tangent = _unit(end - pt(two_pi + beta - 0.005))
    outward = _unit([end[0], end[1], 0.0])
    a = np.radians(alpha_deg)
    direction = _unit(np.cos(a) * tangent + np.sin(a) * outward)
    R_disc = R_b + r0
    h = 3.0 * r_end

    # clear length of the nozzle: the first distance along its axis past which its section no longer meets the
    # spiral's first half turn or the impeller disc (the tongue intrusion), computed from the same parameters
    th_s = np.linspace(0.0, np.pi, 400)
    spiral_pts = np.array([pt(t) for t in th_s])
    spiral_r = np.array([r_of(t) for t in th_s])
    s_clear = 0.0
    for s in np.linspace(0.0, 8 * d_noz, 800):
        c = end + s * direction
        hits_spiral = bool(np.any(np.linalg.norm(spiral_pts - c, axis=1) < spiral_r + r_end))
        hits_disc = float(np.hypot(c[0], c[1])) < R_disc + r_end
        if hits_spiral or hits_disc:
            s_clear = s
    L_noz = noz_over_d * d_noz + s_clear
    noz_end = end + L_noz * direction

    path_a = np.array([pt(t) for t in th_a])
    rad_a = np.array([r_of(t) for t in th_a])
    path_b = np.vstack([[pt(t) for t in th_b], [end + 0.5 * L_noz * direction], [noz_end]])
    rad_b = np.array([r_of(t) for t in th_b] + [r_end, r_end])
    part_a = tube_var(path_a, rad_a)
    part_b = tube_var(path_b, rad_b)
    joint = _sphere(1.05 * r_of(split), pt(split))
    disc = trimesh.creation.cylinder(radius=R_disc, height=h, sections=SECTIONS)
    L_eye = eye_over_d * d_eye
    eye = _cyl(d_eye / 2, L_eye + 0.2 * r_end, "z", (0.0, 0.0, h / 2 - 0.2 * r_end))
    mesh = _union([disc, part_a, joint, part_b, eye])

    ports = [port((0.0, 0.0, h / 2 + L_eye), "inlet", d_eye, eye_over_d, needs_model=True),
             port(noz_end, "outlet", d_noz, noz_over_d, needs_model=True, stub_tol=GENTLE_STUB_TOL),
             port((0.0, 0.0, -h / 2), "wall", None, None, kind="cap", classification="planar_face"),
             port((0.0, 0.0, h / 2), "wall", None, None, kind="ring", classification="ring")]
    expect = ["ring_faces_present"]
    forbid = ["velocity_spread", "region_purpose_mismatch"] if d_eye / d_noz <= 2 else ["region_purpose_mismatch"]
    if noz_over_d < 5:
        expect.append("short_stub")
    else:
        forbid.append("short_stub")
    exp = {"openings": 4, "regions": 1, "watertight": True, "ports": ports, "port_candidates": 2,
           "expect_risks": expect, "forbid_risks": forbid}
    return mesh, exp


# ---- globe valve -----------------------------------------------------------------------------------------------

def globe_valve(d_p: float = 0.05, run_over_d: float = 6.0, W: float = 0.20, Dc: float = 0.12, Hc: float = 0.14,
                t: float = 0.008, w_s: float = 0.03, h_s: float = 0.035, d_o: float = 0.02, eps: float = 0.003):
    """Fluid of a globe valve: inlet pipe -> lower inlet chamber A -> under the seat U -> orifice O through the
    seat -> above the seat V -> upper outlet chamber B -> outlet pipe. The S-wall is implicit in the gaps of
    thickness t between the boxes. Both ports are on the x axis."""
    L_p = run_over_d * d_p
    xa1 = -w_s / 2 - t              # inlet chamber's inner wall
    xb0 = w_s / 2 + t               # outlet chamber's inner wall
    A = trimesh.creation.box(extents=(xa1 + W / 2, Dc, h_s + Hc / 2))
    A.apply_translation([(-W / 2 + xa1) / 2, 0, (-Hc / 2 + h_s) / 2])
    U = trimesh.creation.box(extents=(w_s / 2 - (xa1 - eps), Dc, Hc / 2 - t / 2))
    U.apply_translation([(xa1 - eps + w_s / 2) / 2, 0, (-Hc / 2 - t / 2) / 2])
    O = _cyl(d_o / 2, t + 2 * eps, "z", (0, 0, -t / 2 - eps))
    V = trimesh.creation.box(extents=(xb0 + eps + w_s / 2, Dc, Hc / 2 - t / 2))
    V.apply_translation([(-w_s / 2 + xb0 + eps) / 2, 0, (t / 2 + Hc / 2) / 2])
    B = trimesh.creation.box(extents=(W / 2 - xb0, Dc, Hc / 2 + h_s))
    B.apply_translation([(xb0 + W / 2) / 2, 0, (-h_s + Hc / 2) / 2])
    pin = _cyl(d_p / 2, L_p + eps, "x", (-W / 2 - L_p, 0, 0))
    pout = _cyl(d_p / 2, L_p + eps, "x", (W / 2 - eps, 0, 0))
    mesh = _union([A, U, O, V, B, pin, pout])

    ports = [port((-W / 2 - L_p, 0, 0), "inlet", d_p, run_over_d, needs_model=True),
             port((W / 2 + L_p, 0, 0), "outlet", d_p, run_over_d, needs_model=True),
             # walls with something through them: the pipe roots and the two faces of the seat
             port((-W / 2, 0, (h_s - Hc / 2) / 2), "wall", None, None, kind="ring", classification="ring"),
             port((W / 2, 0, (Hc / 2 - h_s) / 2), "wall", None, None, kind="ring", classification="ring"),
             port((-t / 2, 0, -t / 2), "wall", None, None, kind="ring", classification="ring"),
             port((t / 2, 0, t / 2), "wall", None, None, kind="ring", classification="ring"),
             # flat chamber walls
             port(((-W / 2 + xa1) / 2, 0, h_s), "wall", None, None, kind="cap", classification="planar_face"),
             port(((xb0 + W / 2) / 2, 0, -h_s), "wall", None, None, kind="cap", classification="planar_face"),
             port(((-W / 2 + w_s / 2) / 2, 0, -Hc / 2), "wall", None, None, kind="cap", classification="planar_face"),
             port(((-w_s / 2 + W / 2) / 2, 0, Hc / 2), "wall", None, None, kind="cap", classification="planar_face"),
             port((-w_s / 2, 0, (t / 2 + Hc / 2) / 2), "wall", None, None, kind="cap", classification="planar_face"),
             port((w_s / 2, 0, (-Hc / 2 - t / 2) / 2), "wall", None, None, kind="cap", classification="planar_face"),
             port((xa1, 0, (h_s - t / 2) / 2), "wall", None, None, kind="cap", classification="planar_face"),
             port((xb0, 0, (-h_s + t / 2) / 2), "wall", None, None, kind="cap", classification="planar_face")]
    exp = {"openings": 18, "regions": 1, "watertight": True, "ports": ports, "port_candidates": 2,
           "planar_faces_min": 12, "expect_risks": ["ring_faces_present"],
           "forbid_risks": ["short_stub", "velocity_spread", "region_purpose_mismatch", "solid_wall_representation"],
           # the orifice is the narrowest passage; the body is mirror-symmetric in y and maps onto itself under a
           # half turn about the y axis (inlet chamber <-> outlet chamber, under-seat <-> above-seat)
           "thickness_min_between": [0.96 * d_o, 1.03 * d_o], "symmetry_planes_min": 1, "rotational_symmetry_order": 2}
    return mesh, exp


# ---- exhaust manifold ------------------------------------------------------------------------------------------

def exhaust_manifold(n: int = 4, d: float = 0.04, d_c: float = 0.064, runner_over_d: float = 3.0, r_over_d: float = 1.5,
                     out_over_d: float = 6.0, blank_over_d: float = 5.5):
    """n equal runners come down from a flange plane, bend 90 degrees and merge along the collector axis.
    The collector is blanked at x = 0 and open at the far end. Marching from the blank end, the section is
    constant up to the first runner's near generator (x_first - r); marching from the outlet, up to where the
    last runner's bend first rises above the collector surface (x_last + intrude)."""
    r = d / 2
    R = r_over_d * d
    L1 = runner_over_d * d
    H = R + L1
    L2 = 0.5 * R
    pitch = R + 1.5 * d
    x_first = blank_over_d * d_c + r
    xs = [x_first + i * pitch for i in range(n)]
    # the runner's tube first rises above the collector surface where the bend's path is R_c - r above the axis
    phi = math.asin(max(-1.0, min(1.0, 1 - (d_c / 2 - r) / R)))
    intrude = R * (1 - math.cos(phi))
    L_c = xs[-1] + intrude + out_over_d * d_c
    parts = [_cyl(d_c / 2, L_c, "x", (0, 0, 0))]
    for x in xs:
        pts = [np.array([x, 0.0, H]), np.array([x, 0.0, R])]
        center = np.array([x + R, 0.0, R])
        for tt in np.linspace(0, np.pi / 2, 25)[1:]:
            pts.append(center + R * np.array([-np.cos(tt), 0.0, -np.sin(tt)]))
        pts.append(np.array([x + R + L2, 0.0, 0.0]))
        parts.append(sweep_circle(np.array(pts), r))
    mesh = _union(parts)
    ports = [port((x, 0, H), "inlet", d, runner_over_d, needs_model=True, stub_tol=GENTLE_STUB_TOL) for x in xs]
    ports.append(port((L_c, 0, 0), "outlet", d_c, out_over_d, needs_model=True, stub_tol=GENTLE_STUB_TOL))
    ports.append(port((0, 0, 0), "any", d_c, blank_over_d, needs_model=True, stub_tol=GENTLE_STUB_TOL))
    expect, forbid = [], ["region_purpose_mismatch", "ring_faces_present"]
    if d_c / d > 2:
        expect.append("velocity_spread")
    else:
        forbid.append("velocity_spread")
    if min(runner_over_d, blank_over_d, out_over_d) < 5:
        expect.append("short_stub")
    else:
        forbid.append("short_stub")
    exp = {"openings": n + 2, "regions": 1, "watertight": True, "ports": ports, "port_candidates": n + 2,
           "expect_risks": expect, "forbid_risks": forbid, "symmetry_planes_min": 1,
           "thickness_min_between": [0.96 * d, 1.03 * d],
           "model_roles_any_of_by_position": [[[0, 0, 0], "closed_end"], [[L_c, 0, 0], "outlet"]]}
    return mesh, exp


# ---- serpentine cold plate -------------------------------------------------------------------------------------

def serpentine(d: float = 0.01, passes: int = 7, L: float = 0.15, pitch: float = 0.03, port_over_d: float = 6.0):
    """One channel: `passes` straight runs along x joined by semicircular U-turns (passes - 1 of them), a vertical
    port rising from each end through a spherical corner."""
    r = d / 2
    pts = [np.array([0.0, 0.0, 0.0])]
    for k in range(passes):
        y = k * pitch
        x_end = L if k % 2 == 0 else 0.0
        pts.append(np.array([x_end, y, 0.0]))
        if k < passes - 1:
            cx, cy = x_end, y + pitch / 2
            sgn = 1.0 if k % 2 == 0 else -1.0
            for tt in np.linspace(-np.pi / 2, np.pi / 2, 17)[1:]:
                pts.append(np.array([cx + sgn * (pitch / 2) * np.cos(tt), cy + (pitch / 2) * np.sin(tt), 0.0]))
    path = np.array(pts)
    start, end = path[0], path[-1]
    L_port = port_over_d * d
    channel = sweep_circle(path, r)
    parts = [channel, _sphere(1.15 * r, start), _sphere(1.15 * r, end),
             _cyl(r, L_port, "z", tuple(start)), _cyl(r, L_port, "z", tuple(end))]
    mesh = _union(parts)
    # the port's section is constant down to the top of the channel tube, r below the corner centre
    stub = (L_port - r) / d
    ports = [port(start + [0, 0, L_port], "inlet", d, stub, needs_model=True, stub_tol=GENTLE_STUB_TOL),
             port(end + [0, 0, L_port], "outlet", d, stub, needs_model=True, stub_tol=GENTLE_STUB_TOL)]
    exp = {"openings": 2, "regions": 1, "watertight": True, "ports": ports, "port_candidates": 2,
           "thickness_min_between": [0.96 * d, 1.03 * d],
           "forbid_risks": ["short_stub", "velocity_spread", "ring_faces_present", "region_purpose_mismatch"]}
    if passes % 2 == 1:
        exp["rotational_symmetry_order"] = 2   # odd pass count: the channel and both ports map onto themselves under a half turn about the vertical axis through the plate centre
    if stub < 5:
        exp["expect_risks"] = ["short_stub"]
        exp["forbid_risks"].remove("short_stub")
    return mesh, exp


# ---- cyclone separator -----------------------------------------------------------------------------------------

def cyclone(R_b: float = 0.08, H_c: float = 0.16, H_cone: float = 0.24, d_u: float = 0.02, under_over_d: float = 6.0,
            d_vf: float = 0.05, t_vf: float = 0.005, vf_over_d: float = 2.0, over_over_d: float = 3.0,
            d_in: float = 0.03, in_over_d: float = 6.0, delta: float = 0.004):
    """Cylinder on cone with an underflow pipe (one revolve), a tangential circular inlet near the roof, and a
    vortex finder: the overflow bore runs from above the roof down vf_over_d bores into the body, and its wall
    (an annulus of thickness t_vf) is cut out of the fluid, leaving a ring on the roof and a ring at its lip."""
    R_u = d_u / 2
    L_u = under_over_d * d_u
    r_vf = d_vf / 2
    h_vf = vf_over_d * d_vf
    L_o = over_over_d * d_vf
    r_in = d_in / 2
    body = revolve_closed([(-H_cone - L_u, R_u), (-H_cone, R_u), (0.0, R_b), (H_c, R_b)], axis="z")
    bore = _cyl(r_vf, h_vf + L_o, "z", (0, 0, H_c - h_vf))
    wall = trimesh.creation.annulus(r_min=r_vf, r_max=r_vf + t_vf, height=h_vf + L_o + 0.05, sections=SECTIONS)
    wall.apply_translation([0, 0, H_c - h_vf + (h_vf + L_o + 0.05) / 2])
    x_a = R_b - r_in - delta
    z_a = H_c - r_in - 0.01
    y_e = 0.5 * math.sqrt(max(R_b**2 - (x_a + r_in) ** 2, 0.0))
    y_touch = math.sqrt(R_b**2 - (x_a - r_in) ** 2)
    L_in = y_touch + in_over_d * d_in
    inlet = _cyl(r_in, L_in + y_e, "y", (x_a, -y_e, z_a))
    fluid = _union([body, bore, inlet])
    mesh = trimesh.boolean.difference([fluid, wall], engine="manifold")
    mesh.merge_vertices()
    ports = [port((0, 0, H_c + L_o), "outlet", d_vf, (L_o + h_vf) / d_vf, needs_model=True, stub_tol=GENTLE_STUB_TOL),
             port((0, 0, -H_cone - L_u), "outlet", d_u, under_over_d, needs_model=True, stub_tol=GENTLE_STUB_TOL),
             port((x_a, L_in, z_a), "inlet", d_in, in_over_d, needs_model=True, stub_tol=GENTLE_STUB_TOL),
             port((0, 0, H_c), "wall", None, None, kind="ring", classification="ring"),
             port((0, 0, H_c - h_vf), "wall", None, None, kind="ring", classification="ring")]
    ds = sorted([d_vf, d_u, d_in])
    expect = ["ring_faces_present"] + (["velocity_spread"] if ds[-1] / ds[0] > 2 else [])
    forbid = ["region_purpose_mismatch", "solid_wall_representation", "nested_bodies"]
    if min(over_over_d + vf_over_d, under_over_d, in_over_d) >= 5:
        forbid.append("short_stub")
    exp = {"openings": 5, "regions": 1, "watertight": True, "ports": ports, "port_candidates": 3,
           "expect_risks": expect, "forbid_risks": forbid,
           "thickness_min_between": [0.96 * min(d_u, d_in, d_vf), 1.03 * min(d_u, d_in, d_vf)]}
    return mesh, exp


# ---- unequal wye -----------------------------------------------------------------------------------------------

def wye_unequal(d_t: float = 0.06, d_b: float = 0.025, angle_deg: float = 60.0, leg_over_d: float = 6.0,
                branch_over_d: float = 3.0, trunk_over_d: float = 6.0):
    """A straight main tube (through leg plus trunk, one cylinder) and a smaller side leg whose axis meets the
    main axis at the origin at angle_deg. Stubs are counted to where the side leg's far generator meets the
    main tube's surface (the start of the junction)."""
    r_t, r_b = d_t / 2, d_b / 2
    a = math.radians(angle_deg)
    s_far = (r_t + r_b) / math.sin(a)          # along the side leg from the origin to the far-side surface line
    x_far = -s_far * math.cos(a)               # along the main axis
    L_a = leg_over_d * d_t - x_far             # through-leg cap to origin
    L_t = trunk_over_d * d_t
    L_b = branch_over_d * d_b + s_far          # side-leg cap to origin
    main = _cyl(r_t, L_a + L_t, "x", (-L_a, 0, 0))
    leg_b = _cyl(r_b, L_b, "x", (-L_b, 0, 0))
    leg_b.apply_transform(rotation_matrix(a, [0, 0, 1]))
    mesh = _union([main, leg_b])
    end_b = (-L_b * math.cos(a), -L_b * math.sin(a), 0.0)
    ports = [port((-L_a, 0, 0), "inlet", d_t, leg_over_d, needs_model=True, stub_tol=GENTLE_STUB_TOL),
             port(end_b, "inlet", d_b, branch_over_d, needs_model=True, stub_tol=GENTLE_STUB_TOL),
             port((L_t, 0, 0), "outlet", d_t, trunk_over_d, needs_model=True, stub_tol=GENTLE_STUB_TOL)]
    expect, forbid = [], ["ring_faces_present", "region_purpose_mismatch"]
    if d_t / d_b > 2:
        expect.append("velocity_spread")
    else:
        forbid.append("velocity_spread")
    if min(leg_over_d, branch_over_d, trunk_over_d) < 5:
        expect.append("short_stub")
    else:
        forbid.append("short_stub")
    exp = {"openings": 3, "regions": 1, "watertight": True, "ports": ports, "port_candidates": 3,
           "expect_risks": expect, "forbid_risks": forbid, "symmetry_planes_min": 1,
           "thickness_min_between": [0.96 * min(d_t, d_b), 1.03 * min(d_t, d_b)]}
    return mesh, exp


# ---- the family ------------------------------------------------------------------------------------------------

def build_cases() -> list[Case]:
    cases: list[Case] = []
    add = cases.append
    ic = "internal_cfd"
    add(_case("pump_volute", FAMILY, ic, lambda: pump_volute(),
              brief="Centrifugal pump volute: water enters the axial eye on top and leaves through the tangential discharge nozzle.",
              note="spiral swept with a growing circle; the impeller disc's flat bottom is a wall, its top is a ring around the eye"))
    add(_case("pump_volute_short_nozzle", FAMILY, ic, lambda: pump_volute(noz_over_d=2.0),
              brief="Pump volute with the discharge flange right at the casing.",
              note="discharge nozzle 2 D long: short_stub"))
    add(_case("globe_valve", FAMILY, ic, lambda: globe_valve(),
              brief="Globe valve fluid volume, DN50, flow from -x to +x through the seat orifice.",
              note="18 planar facets: 2 ports, 4 rings (pipe roots, both seat faces), 12 chamber walls"))
    add(_case("globe_valve_wide_seat", FAMILY, ic, lambda: globe_valve(w_s=0.05, d_o=0.03),
              brief="Globe valve fluid volume, DN50, wider seat chamber.",
              note="the two chamber walls facing the seat have 0.7 D of box behind them: still walls, not ports"))
    add(_case("exhaust_manifold_4to1", FAMILY, ic, lambda: exhaust_manifold(),
              brief="4-into-1 exhaust header: four runner flanges on top are inlets, the collector end is the outlet, the other collector end is blanked.",
              note="runners 3 D then a 90 degree bend: short_stub on all four"))
    add(_case("exhaust_manifold_4to1_long", FAMILY, ic, lambda: exhaust_manifold(runner_over_d=6.0),
              brief="4-into-1 exhaust header with long runners.",
              note="every straight run is at least 5 D"))
    add(_case("serpentine_cold_plate_6u", FAMILY, ic, lambda: serpentine(),
              brief="Serpentine cooling channel, 10 mm bore, six U-turns, vertical inlet and outlet fittings.",
              note="two ports only; the U-turns are 1.5 D radius"))
    add(_case("cyclone_separator", FAMILY, ic, lambda: cyclone(),
              brief="Gas cyclone: tangential inlet, overflow through the vortex finder on top, underflow at the cone apex.",
              note="the vortex finder's wall is cut out of the fluid: a ring on the roof and an interior ring at its lip; the overflow bore is constant for 5 D"))
    add(_case("wye_60_unequal", FAMILY, ic, lambda: wye_unequal(),
              brief="60 degree wye: 60 mm through leg and trunk, 25 mm side leg merging in.",
              note="side leg 3 D straight and 2.4x smaller: short_stub and velocity_spread"))
    return cases


def write_family(out: Path = OUT_DIR) -> list[Path]:
    out.mkdir(parents=True, exist_ok=True)
    return [c.write(out) for c in build_cases()]


def main() -> None:
    for p in write_family():
        print(p)


if __name__ == "__main__":
    main()
