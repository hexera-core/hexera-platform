import os as _os

# One BLAS thread per process, set before numpy is imported by anything below: several measurement children with
# default OpenBLAS threading exhaust memory and die with "Memory allocation failed" or an access violation. A value
# already in the environment wins.
for _var in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
    _os.environ.setdefault(_var, "1")
del _os, _var

__all__ = ["analyze", "measure", "AnalysisResult", "GeometryPlan", "GeometryFacts"]


def __getattr__(name):
    if name in ("analyze", "AnalysisResult", "GeometryPlan"):
        from geometry_agent.agent import run, schema
        return {"analyze": run.analyze, "AnalysisResult": schema.AnalysisResult, "GeometryPlan": schema.GeometryPlan}[name]
    if name == "measure":
        from geometry_agent.facts.measure import measure
        return measure
    if name == "GeometryFacts":
        from geometry_agent.facts.schema import GeometryFacts
        return GeometryFacts
    raise AttributeError(name)
