"""HANDOFF 2: intake to the geometry agent.

Intake asks the Surveyor's questions and carries back what the person said. That is the whole of its job on
this boundary, and the contract is written so it cannot do more.

WHAT IT MUST CARRY:

  survey_source_sha256, survey_facts_sha256   the exact part these answers are about. An answer that cannot be
                                              bound to a part is worse than no answer: it is an answer about
                                              some other file.
  answers                                     one per question answered, with WHO answered and WHEN.
  asked                                       every question id put to the person, answered or not.
  unanswered                                  the ones they did not settle, named. A question that was asked
                                              and skipped is a different thing from one that was never asked,
                                              and a consumer must be able to tell them apart.

WHAT IT MAY CARRY: a free-text note per answer, kept for a person to read.

WHAT IS FORBIDDEN, each refused at construction:

  * an answer to a question that was not asked. There is no such thing: the question list is the uncertainty
    list, so an answer with no question is an answer to something nobody was unsure about.
  * an answer that sets a field a person does not own. `OWNERS` says which fields admit a `confirmed` claim,
    and a bore is not one of them. A customer cannot overrule a measurement of the geometry by typing, and the
    refusal here is what makes that structural rather than polite.
  * a geometry claim of its own. Intake measures nothing and sees nothing. Every mark it emits is `confirmed`.

THE FREE GROUND TRUTH. Every answer is a labelled example on a real part at zero annotation cost, from a
question we were asking anyway. `label_from` turns one into a row that says what was asked, what the look had
guessed, what the measurement had, and what the person said. That row needs no answer key and no corpus, so it
is the half of the learning loop that works on a stranger's file.
"""
from __future__ import annotations

import re
from datetime import UTC, datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from geometry_agent.contract import marks as mk
from geometry_agent.contract.asking import Question
from geometry_agent.contract.marks import CONFIRMED, ContractError, Mark
from geometry_agent.contract.survey import SurveyHandoff

INTAKE_SCHEMA = "geometry_agent.contract.intake.v1"

#: What a person is allowed to settle, which is every field whose row admits a `confirmed` claim. Computed from
#: the ownership table rather than listed again, so the two can never drift.
ANSWERABLE: frozenset[str] = frozenset(f for f, row in mk.OWNERS.items() if CONFIRMED in row)


class Answer(BaseModel):
    """One thing a person settled."""

    model_config = ConfigDict(extra="forbid")

    question_id: str
    about: str
    subject: str = ""
    value: Any
    #: Who settled it. `default_taken` is a real answer and says so: nobody typed it, the default stood. That
    #: distinction is the difference between a confirmation and an assumption, and it must survive the handoff.
    answered_by: str
    at: str = Field(default_factory=lambda: datetime.now(UTC).isoformat(timespec="seconds"))
    note: str = ""

    def model_post_init(self, _ctx: Any) -> None:
        if not self.question_id or not self.about:
            raise ContractError("intake.answer", "an answer needs the question it answers and the field it "
                                                 "settles")
        if not self.answered_by:
            raise ContractError("intake.answer", "an answer needs to say who settled it: a person, or "
                                                 "`default_taken` when the default stood and nobody typed")
        if self.about not in ANSWERABLE:
            raise ContractError("intake.answer",
                                f"{self.about!r} is not a field a person owns; it is owned by "
                                f"{mk.OWNERS.get(self.about, ('nobody',))}. A customer does not overrule a "
                                f"measurement of the geometry by typing", field=self.about)

    def as_mark(self) -> Mark:
        """The answer as a claim, which is the only form the geometry agent ever sees it in."""
        kind = CONFIRMED if self.answered_by != "default_taken" else mk.ASSUMED
        if kind == mk.ASSUMED and mk.ASSUMED not in mk.OWNERS.get(self.about, ()):
            # a default on a field that admits no assumption is not an answer; it is the question still open
            raise ContractError("intake.answer", f"the default stood on {self.about!r}, which admits no "
                                                 f"assumed claim: this question is still open", field=self.about)
        return Mark(kind=kind, field=self.about, value=self.value,
                    source=f"question {self.question_id} answered by {self.answered_by} at {self.at}",
                    why=self.note)


class IntakeHandoff(BaseModel):
    """What intake carries from the person to the geometry agent."""

    model_config = ConfigDict(extra="forbid")

    schema_name: str = INTAKE_SCHEMA
    survey_source_sha256: str
    survey_facts_sha256: str
    asked: list[str]
    answers: list[Answer]
    unanswered: list[str] = Field(default_factory=list)

    def model_post_init(self, _ctx: Any) -> None:
        if not self.survey_source_sha256 or not self.survey_facts_sha256:
            raise ContractError("intake", "an intake handoff must name the survey it answers: an answer that "
                                          "cannot be bound to a part is an answer about some other file")
        asked = set(self.asked)
        stray = sorted({a.question_id for a in self.answers} - asked)
        if stray:
            raise ContractError("intake", f"answers to questions that were not asked: {stray}. The question "
                                          f"list is the uncertainty list, so there is nothing else to answer")
        answered = {a.question_id for a in self.answers}
        missing = sorted(asked - answered - set(self.unanswered))
        if missing:
            raise ContractError("intake", f"asked but neither answered nor listed unanswered: {missing}. A "
                                          f"question that was skipped is not the same as one never asked")

    def marks(self) -> list[Mark]:
        return [a.as_mark() for a in self.answers]

    def answer_for(self, about: str, subject: str = "") -> Answer | None:
        for a in self.answers:
            if a.about == about and a.subject == subject:
                return a
        return None


def binds_to(intake: IntakeHandoff, survey: SurveyHandoff) -> None:
    """Refuse a pair that is not about the same part, and refuse an answer to a question the survey never had.

    This is the join, and it is checked rather than assumed. Two sessions on two files with the same question
    ids is exactly the failure that would be invisible at every other layer.
    """
    if intake.survey_source_sha256 != survey.source_sha256:
        raise ContractError("intake", f"answers are about {intake.survey_source_sha256[:12]} and this survey "
                                      f"is {survey.source_sha256[:12]}")
    if intake.survey_facts_sha256 != survey.facts_sha256:
        raise ContractError("intake", "the answers were given against a different measurement of this file")
    known = {u.id for u in survey.uncertainties}
    stray = sorted(set(intake.asked) - known)
    if stray:
        raise ContractError("intake", f"asked {stray}, which the survey never raised; the question list and "
                                      f"the uncertainty list are the same object")


# ---------------------------------------------------------------------------------------------------------
# the third intake: only a question that did not exist at the second
# ---------------------------------------------------------------------------------------------------------

LATE_INTAKE_SCHEMA = "geometry_agent.contract.late_intake.v1"


def topic_of_field(about: str) -> str:
    """The kind a field's question belongs to, in the ledger's nine-kind vocabulary. Two questions with the same
    topic are the same decision, so the third intake cannot ask one the second already had."""
    from geometry_agent.chain.schema import canonical_kind
    try:
        return canonical_kind(about)
    except ValueError:
        return about


class LateIntakeHandoff(BaseModel):
    """The third intake: a question that could not be asked before the plan existed, and what came back.

    REHAAN'S RULE, and this handoff is where it is enforced rather than remembered: intake fires a third time
    ONLY for a question that did not exist at the second. The canonical case is the budget trade: the envelope a
    PLAN costs is not known until the plan exists, so a customer cannot be asked to trade their budget against it
    at the second intake. Anything the second intake raised, asked or not, is refused here by topic, because a
    question asked twice is how a customer stops answering and a question held back at the second is still the
    same decision.

    It carries the questions it raised (`raised`) because none of them is in the survey, which is the point, so
    the answers have nothing else to be checked against.
    """

    model_config = ConfigDict(extra="forbid")

    schema_name: str = LATE_INTAKE_SCHEMA
    survey_source_sha256: str
    survey_facts_sha256: str
    #: What the question depends on that did not exist at the second intake: the plan it was costed against.
    depends_on: str
    raised: list[Any]
    asked: list[str]
    answers: list[Answer]
    unanswered: list[str] = Field(default_factory=list)

    def model_post_init(self, _ctx: Any) -> None:
        from geometry_agent.contract.survey import Uncertainty
        if not self.survey_source_sha256 or not self.survey_facts_sha256:
            raise ContractError("late_intake", "a late intake must name the survey it belongs to")
        if not self.depends_on:
            raise ContractError("late_intake", "a late question must name what it depends on that did not exist at "
                                               "the second intake; with nothing, it could have been asked then")
        for u in self.raised:
            if not isinstance(u, Uncertainty):
                raise ContractError("late_intake", "a raised question is a survey.Uncertainty")
        raised_ids = {u.id for u in self.raised}
        stray = sorted(set(self.asked) - raised_ids)
        if stray:
            raise ContractError("late_intake", f"asked {stray}, which this intake did not raise")
        bad = sorted({a.question_id for a in self.answers} - set(self.asked))
        if bad:
            raise ContractError("late_intake", f"answers to questions that were not asked: {bad}")
        missing = sorted(set(self.asked) - {a.question_id for a in self.answers} - set(self.unanswered))
        if missing:
            raise ContractError("late_intake", f"asked but neither answered nor listed unanswered: {missing}")
        topics = [topic_of_field(u.about) for u in self.raised if u.id in set(self.asked)]
        if len(topics) != len(set(topics)):
            raise ContractError("late_intake", "one topic asked twice in one late intake: the trade is asked ONCE")

    def marks(self) -> list[Mark]:
        return [a.as_mark() for a in self.answers]

    def answer_for(self, about: str, subject: str = "") -> Answer | None:
        for a in self.answers:
            if a.about == about and a.subject == subject:
                return a
        return None


def binds_late(late: LateIntakeHandoff, survey: SurveyHandoff) -> None:
    """Refuse a late intake about another part, and refuse any question the second intake already had.

    By id AND by topic. Same id is the same question; same topic is the same decision asked again with a new
    number on it, which is exactly what "asked ONCE" forbids. The survey's uncertainties are every question the
    second intake had, asked or held, so a budget question held below the cap at the second cannot reappear here.
    """
    if late.survey_source_sha256 != survey.source_sha256 or late.survey_facts_sha256 != survey.facts_sha256:
        raise ContractError("late_intake", "the late answers are about a different measurement of this file")
    earlier_ids = {u.id for u in survey.uncertainties}
    earlier_topics = {topic_of_field(u.about) for u in survey.uncertainties}
    for u in late.raised:
        if u.id in earlier_ids:
            raise ContractError("late_intake", f"{u.id!r} existed at the second intake; the third intake is only "
                                               f"for a question that did not", field=u.id)
        topic = topic_of_field(u.about)
        if topic in earlier_topics:
            raise ContractError("late_intake", f"the second intake already had a {topic!r} question; asking the "
                                               f"same decision again with a new number is asking it twice",
                                field=u.id)


#: A role question asks "which of these mouths is the inlet": its id names the role and its options are mouths.
_ROLE_QUESTION = re.compile(r"^role_(inlet|outlet)$")


def _answer_of(q: Question, value: Any, by: str) -> Answer:
    """One answer, stored the way `Given.role_of` reads it (the platform's NEEDS 5). A role question's answer is a
    MOUTH (the option chosen) and its role is in the question (`role_inlet`), so it is stored as subject = the
    mouth, value = the role. Stored as subject "" and value = the mouth, `role_of(mouth)` never found it and every
    role a customer confirmed on the platform read as unsettled downstream."""
    hit = _ROLE_QUESTION.match(str(q.id))
    if q.about == "opening.role" and not q.subject and hit and isinstance(value, str) and value:
        return Answer(question_id=q.id, about=q.about, subject=value, value=hit.group(1), answered_by=by)
    return Answer(question_id=q.id, about=q.about, subject=q.subject, value=value, answered_by=by)


def answered(questions: list[Question], values: dict[str, Any], *, by: str,
             survey: SurveyHandoff | None = None) -> IntakeHandoff:
    """A handoff from a dict of answers, for a caller that has already put the questions to a person.

    `survey` is the handoff the questions came from, which binds the answers to the part. Without it this could
    never return: a handoff with no survey sha is refused at construction, so every call raised."""
    survey_ids = [q.id for q in questions]
    answers = [_answer_of(q, values[q.id], by) for q in questions if q.id in values]
    return IntakeHandoff(survey_source_sha256=survey.source_sha256 if survey is not None else "",
                         survey_facts_sha256=survey.facts_sha256 if survey is not None else "",
                         asked=survey_ids, answers=answers,
                         unanswered=[q.id for q in questions if q.id not in values])


# ---------------------------------------------------------------------------------------------------------
# free ground truth
# ---------------------------------------------------------------------------------------------------------

def label_from(answer: Answer, survey: SurveyHandoff, question: Question | None = None) -> dict[str, Any]:
    """One labelled example on a real part, at zero annotation cost.

    The customer was going to be asked anyway. Their answer is the label. What makes the row worth keeping is
    the three columns beside it: what the look had said, whether it had abstained, and what the measurement had
    to offer. That is a score for the look on a customer's part with no ground truth anywhere in sight, which is
    the metric this project otherwise only has because it generated the corpus.

    Nothing here is model training. The row is a record, and what reads it is `ratchet.py`.
    """
    seen_mark = None
    if answer.subject:
        op = survey.opening(answer.subject)
        if op is not None:
            seen_mark = op.mark("opening.mouth_standoff")
    else:
        seen_mark = survey.mark(answer.about)
    return {
        "schema": "geometry_agent.contract.label.v1",
        "source_sha256": survey.source_sha256,
        "facts_sha256": survey.facts_sha256,
        "about": answer.about,
        "subject": answer.subject,
        "asked": question.text if question is not None else "",
        "why_asked": question.of.why if question is not None else "",
        "confirmed": answer.value,
        "answered_by": answer.answered_by,
        "at": answer.at,
        #: What the look had said about this field, or None where it abstained. An abstention is a row too: it
        #: is the look being right to say nothing, and it is the reason the question existed.
        "look_said": None if seen_mark is None or seen_mark.kind != mk.SEEN else seen_mark.value,
        "look_abstained": seen_mark is None or seen_mark.kind != mk.SEEN,
        "look_tier": None if seen_mark is None else seen_mark.tier,
        "measurement_had": None,
        "no_answer_key_needed": True,
    }


__all__ = ["ANSWERABLE", "INTAKE_SCHEMA", "LATE_INTAKE_SCHEMA", "Answer", "IntakeHandoff", "LateIntakeHandoff", "answered",
           "binds_late", "binds_to", "label_from", "topic_of_field"]
