"""THE FOUR STAGES AND THE THREE HANDOFFS BETWEEN THEM.

    SURVEYOR ---(1 survey)---> INTAKE ---(2 answers)---> GEOMETRY AGENT ---(3 the pair)---> BUILDER
                                                              ^                                ^
                                          the survey's facts are authoritative here             |
                                                    and the survey's information rides with the write-up

Today there is one document and every consumer reaches into it and takes what it likes. That is why the look
reached the builder with nothing for five rounds and nobody noticed: there was no boundary the absence could
fail at. Each module here is one boundary, with its own types and its own validator.

  `marks`    a claim that carries its own kind, and the table saying who may make it
  `survey`   handoff 1, the Surveyor to intake
  `asking`   the uncertainty list and the question list, which are the same object
  `build`    handoff 1 from a `hexera.report_measured` document
  `intake`   handoff 2, intake to the geometry agent, and the free ground truth an answer is
  `given`    what the agent may read and what it may not re-decide
  `deliver`  handoff 3, and the contract the look's block has to satisfy to ride in it
  `ratchet`  how it gets better as more real CAD runs through it

Nothing here is on by default. No module in this package is imported by the shipped path; a caller opts in.

ONE OF THREE `Uncertainty` TYPES IN THIS TREE (`contract/survey.py`, `ask/schema.py`, `chain/schema.py`), and they
were left separate on purpose when work/complete was integrated: none is on the shipped path, and merging them
means choosing the question budget and when a monitor alert becomes a question, which are defaults. The merged
record is `docs/synthesis.md` appendix B; `docs/integration.md` section 3 says what must survive building it.
"""
from __future__ import annotations

from geometry_agent.contract.marks import ContractError

__all__ = ["ContractError"]
