"""HANDOFF 1: the Surveyor to intake.

WHAT THE SURVEYOR IS. The measurement is the instrument and the look is the eyes. Together they describe the
geometry: they name PLACES and MEASUREMENTS. They never predict how the mesh will turn out and they never name
a builder setting, because the builder owns its own controls.

WHAT THIS HANDOFF MUST CARRY, and a missing one stops the run here:

  schema, source_sha256, facts_sha256   which file, which measurement. Without them nothing downstream can bind
                                        an answer to the part it was answered about.
  representation                        measured. carve, fluid_domain, external or annular_fluid. Where the
                                        geometry reads the same with the flow on either side of the surface
                                        (`catalog.side_reading`, with GEOMETRY_AGENT_FLUID_SIDE on) it is the
                                        brief's words (stated), a person's answer (confirmed), or today's
                                        reading standing as a default (assumed) beside the question.
  unit                                  a mark, with its kind: the file declared it, the brief stated it, or it
                                        is a guess. A guessed unit that reads as a measured one is the 1,000x
                                        error this package exists to avoid.
  openings                              every measured mouth, with its geometry. Roles are ABSENT, not empty.
  forecast_cells                        the envelope from `tools.estimate_builder_cells`, never the refinement
                                        ball.
  uncertainties                         THE PRODUCT. See `asking.py`. A survey with no uncertainty list has not
                                        finished; a survey that found none says so with an empty list and a
                                        reason.

WHAT IT MAY CARRY: the look's relied-on findings (attachments, the set of mouths it saw, an empty inside), its
candidates marked as candidates, the customer's stated budget, and the identity the look proposes under its cap.

WHAT IS FORBIDDEN, and the validator refuses the handoff rather than dropping the field:

  * any look field the trust ledger tiers `recorded`: defects, notes, orientation-from-the-picture,
    symmetry-from-the-picture, an opening's class or role as the look guessed it. Read from `vision.trust`.
  * any number the look produced. Every digit is scrubbed before the model sees a picture and a count is a
    digit, so a `seen` mark carrying one means the scrub failed.
  * any builder setting: `cells_across_diameter`, `surface_level`, `n_layers` and the rest. The Surveyor names
    places and measurements; the builder owns its controls.
  * any claim about how the mesh will turn out. This is a description of a part, not a prediction.

THE LAST OF THOSE IS PAID FOR AT THE COMPOSER AND NOT HERE, on the one block this package composes itself. A
builder control or a recorded field in a handoff is a wiring fault and refusing the handoff is the right price.
A prediction is a vision model's choice of words inside free text, and refusing the handoff for one phrase cost
the builder every structured finding that was not what tripped the rule. So `drop_outcome_claims` takes the words
out in `vision.trust.for_model`, which is the one definition of what the look may say to a MODEL and what every
rendering of the look is built from, and `refuse_outcome_claims` still refuses a block built anywhere else.

The Surveyor does not assign roles and does not choose. It says what it measured, what it saw, and what it
could not tell. The last of those is what intake asks about.
"""
from __future__ import annotations

import re
from typing import Any, ClassVar

from pydantic import BaseModel, ConfigDict, Field

from geometry_agent.contract import marks as mk
from geometry_agent.contract.marks import ContractError, Mark

SURVEY_SCHEMA = "geometry_agent.contract.survey.v1"

#: Builder controls. None of them may appear anywhere in this handoff, at any depth. The Surveyor names places
#: and measurements and the builder owns its own settings; a survey that ships a key is the two arguing.
BUILDER_KEYS: frozenset[str] = frozenset({
    "cells_across_diameter", "surface_level", "feature_level", "n_layers", "first_layer_rel",
    "first_layer_thickness", "wall_cell", "max_cells", "base_size", "refinement_regions", "level_delta",
    "expansion_ratio", "quality", "gmsh_size_value", "element_order", "locationInMesh", "seed_point",
})

#: Words that would make this a prediction rather than a description. The Surveyor never says how the mesh
#: turns out.
OUTCOME_WORDS: tuple[str, ...] = ("will mesh", "will fail", "should mesh", "the mesh will", "cells will",
                                  "layers will collapse", "is likely to fail", "expect the mesh")

#: WHAT HAPPENED TO THE LOOK, AND THERE ARE THREE ANSWERS. A look that FAILED, a look nobody has taken and a
#: look that came back and found a clear passage are three different things, and a reader that cannot tell the
#: first two apart reads silence as "I looked and there is nothing there", which is the failure that puts a bad
#: mesh on a real job. `agent.hexera.look_block` writes one of these and nothing else, and the survey block the
#: builder reads carries it under `look_state` beside `looked`.
#:
#: `pending` IS NOT ONE OF THEM, and that is deliberate. A look in flight is a state of a QUEUE, not of a look:
#: the stored document carries no look yet and cannot tell a look queued a second ago from one never queued.
#: The platform keeps that on its own row (`application/geometry_survey.look_state`, `look_queued`) because it is
#: the only side that knows it. A fourth value here would be this package claiming to know something it cannot
#: read.
LOOK_OK = "ok"
LOOK_FAILED = "failed"
LOOK_NOT_ATTEMPTED = "not_attempted"
LOOK_STATES: tuple[str, ...] = (LOOK_OK, LOOK_FAILED, LOOK_NOT_ATTEMPTED)


class SurveyedOpening(BaseModel):
    """One measured mouth. Note what is NOT here: a role.

    A role has no mark on this handoff because no source on this handoff owns one. The measurement has no role
    and the look abstains on six of every seven mouths. `role_is_unknown` is True on every row the Surveyor
    hands over, and it is a field rather than an omission so a reader cannot mistake silence for `wall`.
    """

    model_config = ConfigDict(extra="forbid")

    id: str
    marks: list[Mark]
    role_is_unknown: bool = True
    #: The look's own words about this mouth, when they are not recorded-tier: whether it stands proud, sits
    #: flush or sits in a pocket, which no measurement reports. Never a class and never a role.
    seen: list[Mark] = Field(default_factory=list)

    def mark(self, field: str) -> Mark | None:
        return mk.resolve(list(self.marks) + list(self.seen), field)


class Uncertainty(BaseModel):
    """One thing the Surveyor could not settle, with everything intake needs to ask about it.

    This is not a diagnostic. It is the question, already formed. `asking.py` renders it into words and the two
    lists are the same object by construction.
    """

    model_config = ConfigDict(extra="forbid")

    id: str
    #: The `OWNERS` field this would settle. An uncertainty that settles nothing is not worth a customer's time.
    about: str
    #: Which opening, region or `""` for the whole part. A question about a SET of mouths carries them in
    #: `subjects` and leaves this empty: four unassigned mouths are one question naming the four, not four
    #: questions, which is the rule `schema.UserQuestion.also_settles` already states for the plan's own list.
    subject: str = ""
    subjects: list[str] = Field(default_factory=list)
    #: Why nobody can settle it here, in the Surveyor's own terms: who abstained, or who disagreed with whom.
    why: str
    #: What a person may answer. Every option comes from the MEASUREMENT or from the customer's own vocabulary,
    #: never from the look's guess, because the look's guess on a role is a coin flip.
    options: list[str]
    options_from: str
    #: The value each option SETS, in the options' order, where that is not the option's own words: the budget
    #: trade's options are sentences and each sets a number. None everywhere else.
    option_values: list[Any] | None = None
    default: str | None = None
    #: `changes_mesh`, `changes_bc` or `advisory`. An advisory uncertainty is not asked; it is reported.
    effect: str = "advisory"
    #: The measured evidence a person needs in order to answer, as marks. This is what makes the question
    #: answerable: "o3 is a 12 mm circular mouth on the far end, 40 degrees off the grid" rather than "o3?".
    evidence: list[Mark] = Field(default_factory=list)


class SurveyHandoff(BaseModel):
    """The Surveyor's whole output, validated at the boundary."""

    model_config = ConfigDict(extra="forbid")

    schema_name: str = SURVEY_SCHEMA
    source_sha256: str
    facts_sha256: str
    agent_git_sha: str = ""
    #: The whole-part marks: representation, unit, scale, bbox, forecast, identity proposal, attachments.
    marks: list[Mark]
    openings: list[SurveyedOpening]
    uncertainties: list[Uncertainty]
    #: Empty is a real answer and needs a reason, so an empty list cannot pass for "we did not look".
    no_uncertainty_because: str = ""
    #: Absent when nothing looked. True and empty are different states and both are honest; what is not honest
    #: is a missing key that reads as either.
    looked: bool = False
    #: The brief this survey was measured against (`contract.brief.BriefHandoff.sha256`). Empty on a survey built
    #: the old way, measured at upload before intake; `bound_to_brief` refuses that survey on the chain path,
    #: because the brief changes the representation and a survey measured without it can be the wrong one.
    brief_sha256: str = ""

    #: MUST carry. A missing one raises at construction. `unit` is NOT here and that is the point: a file
    #: nobody has stated a unit for is the common case (an STL carries none), and the honest handoff has no
    #: unit mark and an uncertainty about the unit instead. `_unit_is_owned_or_asked` enforces exactly that, so
    #: the handoff can be silent about a unit only while it is asking about one.
    REQUIRED: ClassVar[tuple[str, ...]] = ("representation", "forecast.cells_high")

    def model_post_init(self, _ctx: Any) -> None:
        if not self.source_sha256 or not self.facts_sha256:
            raise ContractError("survey", "source_sha256 and facts_sha256 are required: without them no answer "
                                          "downstream can be bound to the part it was answered about")
        mk.require(list(self.marks), self.REQUIRED, "survey")
        if not any(m.field == "unit" for m in self.marks)                 and not any(u.about == "unit" for u in self.uncertainties):
            raise ContractError("survey", "no unit mark and no unit question: a length with no unit is the "
                                          "1,000x error, so this handoff either names the unit or asks",
                                field="unit")
        if not self.uncertainties and not self.no_uncertainty_because:
            raise ContractError("survey", "an empty uncertainty list is a claim and needs its reason: say why "
                                          "nothing was left unsettled rather than handing over silence")
        payload = self.model_dump(mode="json")
        mk.check_no_forbidden(payload, "survey")
        refuse_builder_keys(payload, "survey")
        refuse_outcome_claims(payload, "survey")
        for op in self.openings:
            for m in list(op.marks) + list(op.seen):
                if m.field == "opening.role":
                    raise ContractError("survey", "the Surveyor does not assign roles; a role is confirmed by a "
                                                  "person or it is unknown", field=f"openings[{op.id}]")

    def mark(self, field: str) -> Mark | None:
        return mk.resolve(list(self.marks), field)

    def value(self, field: str, default: Any = None) -> Any:
        m = self.mark(field)
        return default if m is None else m.value

    def opening(self, oid: str) -> SurveyedOpening | None:
        for op in self.openings:
            if op.id == oid:
                return op
        return None


def bound_to_brief(survey: SurveyHandoff, brief_sha256: str) -> None:
    """Refuse a survey that was not measured against THIS brief.

    INTAKE BEFORE MEASURE, as a check rather than a habit. The representation is the catalog's reading of the
    openings WITH the brief and the customer's port rows, so a survey measured before intake (the upload hook's
    order) or against an earlier draft of the brief can carry the wrong representation, and every downstream
    stage keys off it. An empty sha is the upload-hook survey; a different sha is a stale one. Both are refused
    by name, and `chain.job.survey_for` is how a stored measurement is re-surveyed against the brief without
    measuring the file again.
    """
    if not brief_sha256:
        raise ContractError("survey", "no brief to bind to: the chain states the brief first", field="brief_sha256")
    if not survey.brief_sha256:
        raise ContractError("survey", "this survey was measured before intake stated the brief. The brief changes "
                                      "the representation decision, so it must be re-surveyed against the brief "
                                      "before anything downstream reads it", field="brief_sha256")
    if survey.brief_sha256 != brief_sha256:
        raise ContractError("survey", f"this survey was measured against brief {survey.brief_sha256[:12]} and the "
                                      f"job's brief is {brief_sha256[:12]}: re-survey against the current brief",
                            field="brief_sha256")


def refuse_builder_keys(payload: Any, where: str) -> None:
    """Raise when anything at any depth is named after a builder control.

    PUBLIC BECAUSE A SECOND BOUNDARY READS IT. This was private and called from one place, this handoff's own
    constructor, so the rule held at handoff 1 and nothing checked it again on the block that actually reaches
    the builder. `contract.deliver.check_survey_block` calls it now; the survey block is composed in
    `agent/hexera.py` from the document rather than from this handoff, so its keys had never been past this.
    """
    def walk(node: Any, path: str) -> None:
        if isinstance(node, dict):
            for k, v in node.items():
                if str(k) in BUILDER_KEYS:
                    raise ContractError(where, f"carries the builder control {k!r}; the Surveyor names places "
                                               f"and measurements and the builder owns its own settings",
                                        field=f"{path}.{k}".lstrip("."))
                walk(v, f"{path}.{k}".lstrip("."))
        elif isinstance(node, (list, tuple)):
            for i, v in enumerate(node):
                walk(v, f"{path}[{i}]")

    walk(payload, "")


def predicts_outcome(text: Any) -> str:
    """The first `OUTCOME_WORDS` phrase in `text`, or `""`.

    ONE DEFINITION OF THE RULE, because there are now two things to do about a prediction and they must agree
    about what one is. `refuse_outcome_claims` raises at a boundary; `drop_outcome_claims` takes the offending
    words out where the look is composed for a model, where one phrase can be paid for with that phrase instead
    of with the handoff.
    A second spelling of "does this predict" is how a composer comes to drop a sentence the boundary would have
    passed, or pass one it would have refused.
    """
    low = str(text).lower() if isinstance(text, str) else ""
    return next((word for word in OUTCOME_WORDS if word in low), "")


def refuse_outcome_claims(payload: Any, where: str) -> None:
    """Raise when any string anywhere predicts how the finished mesh turns out.

    PUBLIC FOR THE SAME REASON as `refuse_builder_keys`: the survey block the builder is handed carries the
    look's own words, and the look's words never passed through this handoff, so until
    `contract.deliver.check_survey_block` called it there was no boundary between a model's prediction and the
    builder. Measured before wiring: 0 of 570,308 stored look phrases across 25,365 looks carry one of these
    words, so the check costs the corpus nothing and closes the door anyway.

    THIS IS THE BOUNDARY AND NOT THE COMPOSER. Raising here refuses a whole handoff for one phrase, which is
    right for a block built somewhere this package cannot reach and wrong for the one it composes itself:
    `vision.trust.for_model` drops the phrase and names the finding (`drop_outcome_claims`) as it composes the
    look, before any rendering of it is built, so what arrives here has already been made to satisfy the rule at
    the granularity the rule is about. What is left for this to catch is a block composed elsewhere.
    """
    def walk(node: Any, path: str) -> None:
        if isinstance(node, str):
            word = predicts_outcome(node)
            if word:
                raise ContractError(where, f"says {word!r}: this handoff describes a part and never "
                                           f"predicts how the mesh turns out", field=path)
        elif isinstance(node, dict):
            for k, v in node.items():
                walk(v, f"{path}.{k}".lstrip("."))
        elif isinstance(node, (list, tuple)):
            for i, v in enumerate(node):
                walk(v, f"{path}[{i}]")

    walk(payload, "")


def drop_outcome_claims(payload: Any) -> tuple[Any, list[str]]:
    """`payload` with every predicting string taken out, and the paths of what went.

    WHY A DROP AND NOT A REFUSAL, measured rather than argued. The look's free text and the look's findings are
    two different things: the findings are structured (a placed row is a phrase with a coordinate the RENDERER
    issued, a `seen` mark is a word with the measurement's own opening ids beside it) and none of them is what
    a prediction is. Refusing the whole survey for one phrase cost the builder every placed finding, every
    measured mark and every confirmed role, and it did not even keep the phrase from the builder: the same
    words ride in the sibling `planner_block["look"]`, which is on the platform's allowlist and which no
    boundary walks. Maximum price, no protection. So the phrase is paid for with the phrase, in both
    renderings, and the finding it was attached to is NAMED rather than silently shortened.

    A string that predicts becomes nothing: an element leaves its list, a key leaves its dict, and a string
    handed in on its own comes back `""`. Everything else is returned unchanged, so a caller can tell whether
    anything moved by reading the second half rather than by comparing.

    A CONTAINER THIS EMPTIES GOES WITH ITS LAST ELEMENT, and that is not tidiness. `attachments: []` under a
    `seen` mark reads as "the look looked and there are no attachments", which is the reading this whole item is
    about: `vision.trust.for_model` keeps a field only when its value is not `None`, `""` or `[]`, and uses the
    empty list deliberately in one place (`inside_is_plain`) to MEAN that the look found none. So a list emptied
    here would arrive at a builder as a finding the look never made. A container that was already empty when it
    came in is left alone, because nothing about it moved.

    NOT A SCRUB OF THE STORED RECORD. What the look actually said stays in the document for a person; this is
    what may be put in front of a MODEL. `vision.prompt` scrubs digits before the model is shown a picture and
    this takes words out after it has answered, and neither edits the stored look.
    """
    def walk(node: Any, path: str) -> tuple[Any, bool]:
        if isinstance(node, str):
            if predicts_outcome(node):
                dropped.append(path or ".")
                return None, False
            return node, True
        if isinstance(node, dict):
            out: dict[Any, Any] = {}
            for k, v in node.items():
                kept, keep = walk(v, f"{path}.{k}".lstrip("."))
                if keep:
                    out[k] = kept
            return out, not (node and not out)
        if isinstance(node, (list, tuple)):
            rows = []
            for i, v in enumerate(node):
                kept, keep = walk(v, f"{path}[{i}]")
                if keep:
                    rows.append(kept)
            return rows, not (node and not rows)
        return node, True

    dropped: list[str] = []
    cleaned, keep = walk(payload, "")
    # the root is the caller's own subject, so an emptied container comes back empty and the caller decides what
    # an empty one means there; only a predicting string handed in bare has nothing left to return
    return (cleaned if keep or cleaned is not None else ""), dropped


# ---------------------------------------------------------------------------------------------------------
# the customer's own budget, which nothing reads today
# ---------------------------------------------------------------------------------------------------------
#
# Every one of the 322 corpus briefs states a cell budget and no code path reads it: `cell_cap` reaches the
# agent as a CLI argument, and in the eval harness it comes out of `expected.json`, which is the answer key. On
# a stranger's file with no key, the number the customer already wrote is thrown away and the forecast is
# compared against nothing. This reads it.

_SCALE = {"k": 1_000, "thousand": 1_000, "m": 1_000_000, "mm": 1_000_000, "million": 1_000_000,
          "mil": 1_000_000, "b": 1_000_000_000, "billion": 1_000_000_000}

#: A number with an optional magnitude word, inside a sentence that is about a cell count and about a limit.
_NUM = r"(\d[\d,\.]*)\s*(k|m|mm|b|thousand|million|mil|billion)?"
_BUDGET_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(r"(?:cell\s*(?:count|budget)|mesh\s*budget|budget)[^.\n]{0,60}?"
               r"(?:under|below|less\s+than|at\s+most|no\s+more\s+than|max(?:imum)?(?:\s+of)?|up\s+to|of|:)\s*"
               + _NUM, re.I),
    re.compile(r"(?:under|below|less\s+than|at\s+most|no\s+more\s+than|max(?:imum)?(?:\s+of)?|up\s+to)\s*"
               + _NUM + r"\s*cells", re.I),
    re.compile(_NUM + r"\s*cell\s*(?:budget|cap|limit)", re.I),
)


def budget_from_brief(brief: str | None) -> tuple[int | None, str]:
    """The cell budget the customer stated, and the sentence it came from.

    Returns `(None, "")` when the brief states none, which is an honest answer and a question rather than a
    default. Nothing here needs an answer key: it reads the customer's own words, so it runs on a stranger's
    file exactly as it runs on the corpus.
    """
    text = str(brief or "")
    if not text.strip():
        return None, ""
    for pattern in _BUDGET_PATTERNS:
        for match in pattern.finditer(text):
            raw, scale = match.group(1), (match.group(2) or "").lower()
            try:
                number = float(raw.replace(",", ""))
            except ValueError:
                continue
            value = number * _SCALE.get(scale, 1.0)
            # a bare "2" cells is not a budget, and neither is a y+ target that happened to sit near the word
            if value < 1000:
                continue
            line = _sentence_around(text, match.start())
            return int(round(value)), line
    return None, ""


def _sentence_around(text: str, index: int) -> str:
    start = max(text.rfind(".", 0, index), text.rfind("\n", 0, index)) + 1
    end = min([i for i in (text.find(".", index), text.find("\n", index)) if i != -1] or [len(text)])
    return text[start:end].strip()


__all__ = ["BUILDER_KEYS", "LOOK_FAILED", "LOOK_NOT_ATTEMPTED", "LOOK_OK", "LOOK_STATES", "OUTCOME_WORDS",
           "SURVEY_SCHEMA", "SurveyHandoff", "SurveyedOpening", "Uncertainty",
           "bound_to_brief",
           "budget_from_brief", "drop_outcome_claims", "predicts_outcome", "refuse_builder_keys",
           "refuse_outcome_claims"]
