"""Build the Surveyor's handoff from a stored measurement document.

`hexera.report_measured` is the document. This turns it into the typed handoff of `survey.py`, which means
deciding, field by field, which kind of claim each value is. Nothing new is computed here: every number comes
out of the document and every word out of the look, and the only thing this file adds is the mark that says
which of the two a value was.

WHAT IT REFUSES TO CARRY ACROSS. The document holds the whole look, including the fields the trust ledger
tiers `recorded`. This takes the relied-on fields, marks the candidates as candidates, and leaves the recorded
ones where they are. `survey.SurveyHandoff` then refuses the handoff if one got through, so the rule is
enforced twice and the second time it is a failure rather than a habit.
"""
from __future__ import annotations

from typing import Any

from geometry_agent.contract import marks as mk
from geometry_agent.contract.asking import uncertainties_from
from geometry_agent.contract.survey import SurveyedOpening, SurveyHandoff, budget_from_brief

#: The look fields this carries, and why each one earned it, from `vision.trust`.
CARRIED_LOOK_FIELDS: dict[str, str] = {
    "attachments": "25 of 25 recall at 93 to 100 percent precision, and no measurement here reports one",
    "inside_is_plain": "0 false obstructions on 103 plain-passage cases: the empty list is the finding",
    "identity.name": "a name to confirm with the customer, capped at 0.6 and never stated",
    "opening.mouth_standoff": "no measurement reports whether a mouth stands proud, sits flush or sits in a "
                              "pocket",
}


#: Who settled which side of the surface is the fluid, as the kind of claim the representation then is.
SIDE_KIND: dict[str, str] = {"purpose": mk.MEASURED, "geometry": mk.MEASURED, "brief": mk.STATED,
                             "answer": mk.CONFIRMED}


def _representation_mark(document: dict[str, Any], rep: str) -> mk.Mark:
    """The representation, marked by who settled it. With no `fluid_side` in the document (the switch off) it is
    `measured`, as it always was. With one, it is measured only where the geometry or the purpose settled it: the
    brief's words are `stated`, a person's answer `confirmed`, and an open side is today's reading standing as a
    default, `assumed`, beside the question that asks it."""
    side = document.get("fluid_side")
    if not isinstance(side, dict):
        return mk.measured("representation", rep, "catalog.representation over the measured openings")
    if side.get("open"):
        return mk.assumed("representation", rep, "catalog.side_reading: which side of the surface is the fluid is "
                                                  "open, and this is today's reading standing as the default",
                          why=str(side.get("why") or ""))
    by = str(side.get("settled_by") or "")
    kind = SIDE_KIND.get(by, mk.MEASURED)
    source = {"purpose": "catalog.side_reading: the purpose", "geometry": "catalog.side_reading over the measured "
              "openings", "brief": "catalog.side_reading: the brief's own words", "answer": "catalog.side_reading: "
              "a person's answer to which side is the fluid"}.get(by, "catalog.representation over the measured openings")
    return mk.Mark(kind=kind, field="representation", value=rep, source=source, why=str(side.get("why") or ""))


def _part_marks(document: dict[str, Any], budget: int | None, budget_line: str,
                impression: dict[str, Any] | None) -> list[mk.Mark]:
    out: list[mk.Mark] = []
    rep = document.get("representation")
    if rep:
        out.append(_representation_mark(document, str(rep)))
    coords = document.get("coordinates") or {}
    unit_block = document.get("unit") or {}
    basis = str(unit_block.get("basis") or "")
    unit_value = unit_block.get("assumed") or unit_block.get("declared")
    if unit_value:
        # THE BASIS IS THE KIND, and this is the one place the two vocabularies meet. The words are
        # `hexera.coordinates_block`'s own: `occ_transfer` is the CAD kernel reading the unit out of the file,
        # which is a measurement of the file; `user_confirmed` is a person; `source_file` is the case where no
        # scale is known at all, and a unit with no scale behind it is a guess however confident it sounds.
        kind = {"occ_transfer": mk.MEASURED, "file": mk.MEASURED, "brief": mk.STATED,
                "user": mk.CONFIRMED, "user_confirmed": mk.CONFIRMED}.get(basis, mk.ASSUMED)
        out.append(mk.Mark(kind=kind, field="unit", value=unit_value,
                           source=f"coordinates.basis={basis or 'guess'}",
                           why="a guessed unit that reads as a measured one is the 1,000x error"))
    scale = coords.get("scale_to_metres")
    if scale:
        out.append(mk.measured("scale_to_metres", scale, "coordinates.scale_to_metres"))
    bbox = document.get("bbox") or {}
    if bbox.get("extent_m"):
        out.append(mk.measured("bbox_extent_m", bbox["extent_m"], "facts.bbox.extent", unit="m"))
    if bbox.get("diagonal_m"):
        out.append(mk.measured("bbox_diagonal_m", bbox["diagonal_m"], "facts.bbox.diagonal", unit="m"))
    bodies = document.get("bodies") or {}
    if bodies.get("count") is not None:
        out.append(mk.measured("bodies.count", bodies["count"], "facts.bodies"))
    if bodies.get("watertight") is not None:
        out.append(mk.measured("watertight", bodies["watertight"], "facts.watertight"))
    thickness = document.get("thickness") or {}
    if thickness.get("min_m") is not None:
        out.append(mk.measured("thickness.min_m", thickness["min_m"], "facts.features.thickness_min", unit="m"))
    clusters = thickness.get("thin_clusters") or []
    if clusters:
        out.append(mk.measured("thickness.thin_clusters",
                               [{"id": c.get("id"), "thickness_min_m": c.get("thickness_min_m"),
                                 "centroid_m": c.get("centroid_m")} for c in clusters if isinstance(c, dict)],
                               "facts.features.thin_clusters", unit="m"))
    forecast = document.get("forecast") or {}
    for field, key in (("forecast.cells_high", "cells_high"), ("forecast.cells_low", "cells_low")):
        value = forecast.get(key)
        if isinstance(value, (int, float)):
            out.append(mk.measured(field, int(value), f"forecast.{key} (tools.estimate_builder_cells)",
                                   why="the builder emulator's envelope, never the refinement ball"))
    builder = forecast.get("builder") or {}
    bore = builder.get("bore")
    if isinstance(bore, (int, float)) and scale:
        # WHICH MOUTH THIS BORE IS, read off the forecast rather than asserted. `hexera.report_measured`
        # sizes from the largest mouth a PERSON called the inlet when they named one and from the widest
        # planar mouth when nobody has, and records which in `builder.inlet_id`. This line said "the widest
        # planar mouth" either way, so on every part where the two differ it named the wrong rule for a
        # number in front of the builder: on the corpus cyclone the bore is the customer's 90.2 mm inlet
        # while the widest mouth is 286.6 mm. A provenance line that lies is worse than none.
        # AND WHO CHOSE IT. `inlet_id` is filled either way: given no binding `tools.builder_inlet` falls back
        # to the widest planar mouth and reports its id, so the id alone says nothing about who picked it. Read
        # as proof of a person, it put "the largest mouth the customer called the inlet" in front of the builder
        # on a block with no declared ports and both role questions skipped. `inlet_from_person` is the
        # distinction, recorded where it is known (`hexera.forecast`); absent on a document written before it
        # existed, and then the id alone is not enough and the honest line is the one that claims nobody.
        named = str(builder.get("inlet_id") or "")
        by_person = bool(builder.get("inlet_from_person")) and bool(named)
        out.append(mk.measured("inlet_bore_m", float(bore) * float(scale),
                               f"forecast.builder.bore (opening {named}, the largest mouth the customer "
                               "called the inlet)" if by_person else
                               (f"forecast.builder.bore (opening {named}, the widest planar mouth, the "
                                "builder's own choice while nobody has named an inlet)" if named else
                                "forecast.builder.bore (the widest planar mouth, the builder's own choice "
                                "while nobody has named an inlet)"),
                               unit="m"))
    out.append(mk.measured("opening_ids",
                           [str(r.get("id")) for r in (document.get("openings") or []) if isinstance(r, dict)],
                           "facts.openings"))
    if budget is not None:
        out.append(mk.stated("cell_budget", int(budget), f"brief: {budget_line}",
                             why="the customer's own words; nobody has been asked to confirm it"))
    if document.get("purpose"):
        # STATED ONLY WHEN SOMEBODY STATED IT (the platform's NEEDS 7). A purpose the caller filled in because
        # nobody said one is the platform's default, and marking it `stated` told every reader the customer did
        if document.get("purpose_source") == "assumed":
            out.append(mk.assumed("purpose", document["purpose"], "the platform's default; nobody stated a purpose"))
        else:
            out.append(mk.stated("purpose", document["purpose"], "the job's declared purpose"))
    if document.get("engine"):
        kind = mk.STATED if document.get("engine_source") == "declared" else mk.ASSUMED
        out.append(mk.Mark(kind=kind, field="engine", value=document["engine"],
                           source=f"engine_source={document.get('engine_source')}"))
    out.extend(_look_marks(impression))
    return out


def _look_marks(impression: dict[str, Any] | None) -> list[mk.Mark]:
    """The relied-on and candidate look fields, and not one recorded one."""
    if not impression:
        return []
    out: list[mk.Mark] = []
    attachments = impression.get("attachments") or []
    if attachments:
        out.append(mk.seen("attachments", list(attachments), "look.attachments", impression=impression))
    if not (impression.get("internal_features") or []):
        out.append(mk.seen("inside_is_plain", True, "look.internal_features (empty)", impression=impression))
    else:
        out.append(mk.seen("internal_features", list(impression["internal_features"]),
                           "look.internal_features", impression=impression))
    name = str(impression.get("looks_like") or "").strip()
    if name:
        out.append(mk.seen("identity.name", name, "look.looks_like", impression=impression))
    return out


def _openings(document: dict[str, Any], impression: dict[str, Any] | None) -> list[SurveyedOpening]:
    standoff: dict[str, str] = {}
    for row in ((impression or {}).get("openings_seen") or []):
        if isinstance(row, dict):
            word = str(row.get("mouth") or "unsure")
            if word != "unsure":
                standoff[str(row.get("id") or "unlabelled")] = word
    out: list[SurveyedOpening] = []
    for row in (document.get("openings") or []):
        if not isinstance(row, dict):
            continue
        oid = str(row.get("id") or "")
        marks: list[mk.Mark] = []
        for field, key, unit in (("opening.shape", "shape", None), ("opening.kind", "kind", None),
                                 ("opening.bore_m", "bore_diameter_m", "m"),
                                 ("opening.min_dimension_m", "min_dimension_m", "m"),
                                 ("opening.tilt_deg", "tilt_deg", "deg"),
                                 ("opening.centroid_m", "centroid_m", "m"),
                                 ("opening.normal", "normal", None)):
            value = row.get(key)
            if value is not None:
                marks.append(mk.measured(field, value, f"facts.openings[{oid}].{key}", unit=unit))
        seen_marks: list[mk.Mark] = []
        if oid in standoff:
            seen_marks.append(mk.seen("opening.mouth_standoff", standoff[oid],
                                      f"look.openings_seen[{oid}].mouth", impression=impression))
        out.append(SurveyedOpening(id=oid, marks=marks, role_is_unknown=True, seen=seen_marks))
    return out


def survey_from(document: dict[str, Any], *, brief: str | None = None, agent_git_sha: str = "",
                budget: int | None = None, declared: list[dict[str, Any]] | None = None,
                alerts: Any = None, uncertainties: list[Any] | None = None,
                brief_sha256: str = "") -> SurveyHandoff:
    """The typed handoff from a `report_measured` document.

    `budget` overrides the one read from the brief, for a caller that already has the customer's cap. When
    neither exists the budget is absent, which is honest and becomes a question rather than a default.

    `uncertainties` is the live chain's list (`chain/job.py`, from `ask.intake.ask_intake`, the finder with the
    settle cuts and the consequence ranking). When it is given it is the ONE source: `uncertainties_from` below
    is not also run, so the question list and the survey's uncertainty list cannot come from two finders. Without
    it this module's own finder runs, as it always did. `brief_sha256` binds the survey to the brief it was
    measured against; it defaults to the one the document was stamped with.
    """
    look = document.get("look") or {}
    impression = look.get("impression") if isinstance(look, dict) else None
    from_brief, budget_line = budget_from_brief(brief)
    cap = budget if budget is not None else from_brief
    line = budget_line if budget is None else "supplied by the caller"
    if uncertainties is None:
        uncertainties = uncertainties_from(document, budget=cap, budget_line=line, declared=declared,
                                           alerts=alerts)
    stamp_sha = str((document.get("stamp") or {}).get("brief_sha256") or "")
    stamp = document.get("stamp") or {}
    facts = document.get("facts") or {}
    return SurveyHandoff(
        source_sha256=str(document.get("source_sha256") or ""),
        facts_sha256=str(facts.get("sha256") or document.get("source_sha256") or ""),
        agent_git_sha=str(agent_git_sha or stamp.get("agent_git_sha") or ""),
        marks=_part_marks(document, cap, line, impression),
        openings=_openings(document, impression),
        uncertainties=uncertainties,
        no_uncertainty_because=("" if uncertainties else
                                "every field this handoff carries has an owner that spoke: the unit is "
                                "confirmed, no mouth needs a role for this purpose, and the forecast fits the "
                                "stated budget"),
        looked=bool(impression),
        brief_sha256=brief_sha256 or stamp_sha,
    )


__all__ = ["CARRIED_LOOK_FIELDS", "survey_from"]
