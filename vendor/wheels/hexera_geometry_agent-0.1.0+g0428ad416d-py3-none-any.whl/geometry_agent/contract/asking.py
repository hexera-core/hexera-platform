"""THE UNCERTAINTY LIST AND THE QUESTION LIST ARE THE SAME OBJECT.

This is the connection nobody had acted on. The look already refuses to guess a port role on most declared
mouths (docs/vision.md scores it at six of every seven; counted over four full-corpus arms in
`eval/contract/measure_contract.py` it is 69 to 79 percent, because those arms run different prompts), and
where it does guess docs/vision.md scores it at about a coin flip. Five rounds read that as a weakness to fix.
It is not. It is the input to intake:

    "I can see four openings. Two run straight through. o3 I cannot tell."

IS the question

    "Which of these is the inlet?"

They are one object, and this module is the proof: `questions_from(survey)` is a rendering of
`survey.uncertainties`, one to one, with no filtering and no second source. A question that is not an
uncertainty cannot exist, because there is nowhere to write one; an uncertainty that is never asked shows up in
the count, because the two lists are the same length by construction and a test says so.

WHERE UNCERTAINTIES COME FROM. Six places, and every one of them is a source declining to speak or two sources
disagreeing, rather than a detector firing:

  1. a role nobody owns, which is ONE question per role the purpose needs and never one per mouth. Four
     unassigned mouths are the question "which of these four is the inlet", naming the four. Where the look
     guessed, the guess is named in the reason and is not on the options list.
  2. a role the brief declares for a different number of ports than there are measured mouths. That
     disagreement is the question; where the counts match, nothing is asked at all, because the platform's own
     binder does the matching and re-asking is what the corpus intake did 163 times.
  3. a unit nobody confirmed. An STL declares none, and a length with an unconfirmed unit is the 1,000x error.
  4. a contradiction `reconcile/monitor.py` flagged. The look and the measurement disagree and neither can
     adjudicate the other, so a person does.
  5. an `unlabelled` mouth, and an identity from the picture alone, which is capped at 0.6.
  6. the budget trade. Measured cost against the budget the customer already stated, asked ONCE and only when
     the two genuinely do not fit.

WHAT MAKES A QUESTION ANSWERABLE. Every option comes from the measurement or from the customer's own
vocabulary. None comes from the look. A question is put with the measured evidence beside it, so a person is
answering "o3, the 12 mm circular mouth on the far end, 40 degrees off the grid" and not "o3".

WHAT IS NOT ASKED. An uncertainty whose effect is `advisory` is reported and never put to a person: nobody is
shown a question whose answer changes nothing.
"""
from __future__ import annotations

import re
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from geometry_agent.contract import marks as mk
from geometry_agent.contract.survey import SurveyHandoff, Uncertainty

ASKING_SCHEMA = "geometry_agent.contract.questions.v1"

#: The roles a person may pick from. The measurement's own vocabulary, not the look's: the look offers
#: inlet / outlet / not a port / unsure and its guess is a coin flip, so its words are not on the menu.
ROLE_OPTIONS: tuple[str, ...] = ("inlet", "outlet", "closed_end", "wall", "interface", "symmetry")


class Question(BaseModel):
    """One uncertainty, in words a person can answer. Nothing here is decided; it is the same object rendered."""

    model_config = ConfigDict(extra="forbid")

    id: str
    text: str
    options: list[str]
    about: str
    subject: str = ""
    default: str | None = None
    effect: str = "changes_mesh"
    #: What a person is shown alongside the question so the answer is worth having.
    evidence: list[str] = Field(default_factory=list)
    #: The uncertainty this renders, kept whole. A consumer that wants the machine form reads this.
    of: Uncertainty


def _evidence_words(u: Uncertainty) -> list[str]:
    out: list[str] = []
    for m in u.evidence:
        value = m.value
        if isinstance(value, float):
            text = f"{value:.4g}"
        elif isinstance(value, (list, tuple)):
            text = ", ".join(f"{v:.4g}" if isinstance(v, float) else str(v) for v in value)
        else:
            text = str(value)
        unit = f" {m.unit}" if m.unit else ""
        # WHICH MOUTH (the platform's NEEDS 6): an opening's evidence is sourced `facts.openings[o3].…`, and a
        # line with the id dropped cannot be attributed to a mouth by anyone reading the question
        hit = _OPENING_OF.search(str(m.source or ""))
        where = f"{hit.group(1)} " if hit else ""
        out.append(f"{where}{m.field.split('.')[-1]} {text}{unit} ({m.kind})")
    return out


_OPENING_OF = re.compile(r"openings\[([^\]]+)\]")


def _text_for(u: Uncertainty) -> str:
    """The question, in the Surveyor's own voice: what it saw, then what it could not tell."""
    subject = u.subject or (", ".join(u.subjects) if u.subjects else "this part")
    if u.about == "opening.role":
        return f"{u.why} The mouths I measure are {subject}."
    if u.about == "unit":
        return "Nothing in this file states its unit, so every size I have is a ratio. What unit is it in?"
    if u.about == "contradiction_resolution":
        return u.why + ". Which is it?"
    if u.about == "unlabelled_mouth":
        return ("I can see an opening in the pictures that the measurement did not find. Is there a mouth "
                "there?")
    if u.about == "identity.name":
        return f"From the pictures this looks like {u.default or 'something I cannot name'}. Is that right?"
    if u.about == "cell_budget":
        return u.why
    return f"I could not settle {u.about} on {subject}. {u.why}"


def questions_from(survey: SurveyHandoff, *, include_advisory: bool = False) -> list[Question]:
    """The survey's uncertainties as questions, one for one.

    There is no second source and no filtering except `effect`: an advisory uncertainty is reported rather than
    asked, because nobody is shown a question whose answer changes nothing. With `include_advisory` the mapping
    is the identity, and `test_contract_asking.py` asserts the lengths match.
    """
    out: list[Question] = []
    for u in survey.uncertainties:
        if u.effect == "advisory" and not include_advisory:
            continue
        out.append(Question(id=u.id, text=_text_for(u), options=list(u.options), about=u.about,
                            subject=u.subject, default=u.default, effect=u.effect,
                            evidence=_evidence_words(u), of=u))
    return out


# ---------------------------------------------------------------------------------------------------------
# finding the uncertainties in a measurement document
# ---------------------------------------------------------------------------------------------------------

def _opening_evidence(row: dict[str, Any]) -> list[mk.Mark]:
    oid = str(row.get("id") or "")
    out = [mk.measured("opening.shape", row.get("shape"), f"facts.openings[{oid}].shape")]
    for field, key, unit in (("opening.bore_m", "bore_diameter_m", "m"),
                             ("opening.min_dimension_m", "min_dimension_m", "m"),
                             ("opening.tilt_deg", "tilt_deg", "deg"),
                             ("opening.centroid_m", "centroid_m", "m")):
        value = row.get(key)
        if value is not None:
            out.append(mk.measured(field, value, f"facts.openings[{oid}].{key}", unit=unit))
    return out


#: The roles a purpose needs somebody to name before the run means anything. External flow needs none: the body
#: is the body and the far field is the far field, and the corpus declares no ports on any of its 61.
ROLES_NEEDED: dict[str, tuple[str, ...]] = {
    "internal_cfd": ("inlet", "outlet"),
    "conjugate_heat_transfer": ("inlet", "outlet"),
    "external_cfd": (),
    "external_aero": (),
}


def _port_opening_ids(document: dict[str, Any], declared: list[dict[str, Any]] | None) -> set[str] | None:
    """The ids of `catalog.port_openings` under the document's own representation, or None when the document
    carries no facts to read them from."""
    raw = document.get("facts")
    rep = document.get("representation")
    if not isinstance(raw, dict) or not raw.get("openings") or not rep:
        return None
    try:
        from geometry_agent.agent import catalog
        from geometry_agent.facts.schema import GeometryFacts
        facts = GeometryFacts.model_validate(raw)
        return {o.id for o in catalog.port_openings(facts, rep, declared=declared)}
    except Exception:  # noqa: BLE001 - a document this cannot read keeps the plain count
        return None


def _role_uncertainties(document: dict[str, Any], impression: dict[str, Any] | None,
                        declared: list[dict[str, Any]] | None = None) -> list[Uncertainty]:
    """The role questions, and there are at most as many as the purpose needs somebody to name.

    ONE QUESTION PER ROLE, NOT ONE PER MOUTH. Four unassigned mouths are the question "which of these four is
    the inlet", naming the four, and the plan schema already says so for its own list
    (`schema.UserQuestion.also_settles`: "four unassigned legs, five short stubs, a set of seams are one
    question naming the openings, not one question each"). One per mouth put six questions on a part where the
    corpus scores `max_questions 3`, which is the sort of thing that survives when nobody counts.

    AND NOTHING IS ASKED WHERE THE CUSTOMER ALREADY SAID. The corpus intake transcripts asked about the ports
    163 times and almost every one re-asked what the spec had already stated. Where the brief declares as many
    roled ports as there are measured mouths, the roles are the customer's `stated` claim and the platform's own
    binder matches them to mouths; this asks nothing. Where the counts DISAGREE, that disagreement is the
    question, which is the bar `docs/corpus_export.md` sets: a question is worth asking when the file and the
    brief disagree.

    The look's word is used ONLY to say which way it abstained, and never as an option.
    """
    purpose = str(document.get("purpose") or "internal_cfd")
    # A PURPOSE THIS TABLE DOES NOT NAME NEEDS NO ROLE (the platform's NEEDS 3). A structural job has no inlet,
    # and defaulting it to the flow purposes' two questions asked a customer where the flow enters a bracket
    needed = ROLES_NEEDED.get(purpose, ())
    if not needed:
        return []
    rows = [r for r in (document.get("openings") or []) if isinstance(r, dict)]
    ports = [r for r in rows if r.get("kind") in ("cap", "ring") or r.get("classification") == "planar_face"]
    # THE MOUTHS THE BUILDER CAN CUT A PORT AT, not every cap and ring (the platform fixer's NEEDS 2): a flange's
    # shoulder ring, a plate pierced by a boss and an inner body's end cap are walls the catalog already excludes
    # (`catalog.port_openings`), and counting them put a "your brief names 2 ports and I measure 6" question on
    # 151 corpus parts. Read from the facts the document carries; a document without them keeps the old count
    port_ids = _port_opening_ids(document, declared)
    if port_ids is not None:
        ports = [r for r in ports if str(r.get("id") or "") in port_ids]
    if not ports:
        return []
    ids = [str(r.get("id") or "") for r in ports]
    evidence = [m for r in ports for m in _opening_evidence(r)]

    roled = [d for d in (declared or []) if isinstance(d, dict)
             and str(d.get("role") or d.get("type") or "") in ("inlet", "outlet")]
    if roled and len(roled) == len(ports):
        return []
    if roled:
        # the name where a row has one, the role otherwise: `expected.json.ports` carries a role and no name,
        # and a question that says "your brief names 2 ports (?, ?)" is a question nobody can answer
        names = ", ".join(str(d.get("name") or d.get("role") or "a port") for d in roled)
        return [Uncertainty(
            id="role_count", about="opening.role", subjects=ids, effect="changes_bc",
            why=(f"your brief names {len(roled)} ports ({names}) and I measure {len(ports)} mouths on this "
                 f"file. One of us is counting something the other is not, and that is worth one question "
                 f"before a boundary condition lands on the wrong face."),
            options=list(ids), options_from="the measured mouths", evidence=evidence)]

    # THE SAME SENTENCE WHATEVER THE LOOK GUESSED (work/z-deliver NEEDS 4). It used to say "the look offered a
    # role on some of them", which is read off `likely_role`, a field `vision/trust.py` tiers `recorded`: this
    # text reaches the platform's intake model, and a recorded field reaches no model, not even as a count
    why_tail = (" The measurement has no role for a mouth, and a role from the look is never offered: its guesses "
                "score about a coin flip (docs/vision.md), so the choice below is yours.")
    return [Uncertainty(
        id=f"role_{role}", about="opening.role", subjects=ids, effect="changes_bc",
        why=(f"I can see {len(ids)} mouths on this file and I cannot tell which is the {role}." + why_tail),
        options=list(ids), options_from="the measured mouths", evidence=evidence)
        for role in needed]


def _unit_uncertainty(document: dict[str, Any]) -> Uncertainty | None:
    coords = document.get("coordinates") or {}
    unit = document.get("unit") or {}
    # A scale that is known is a unit that is known: `occ_transfer` means the CAD kernel read it out of the
    # file, and asking a person to confirm what the kernel transferred is the sort of question the corpus
    # intake conversations asked 299 times and should not have.
    if coords.get("scale_to_metres"):
        return None
    # `facts.units.candidates` are `[unit, score]` pairs. An option list of stringified tuples is not a
    # question a person can answer, which is exactly the kind of thing that survives when nobody renders it.
    candidates = []
    for c in (unit.get("candidates") or []):
        name = str(c[0]) if isinstance(c, (list, tuple)) and c else str(c)
        if name and name not in candidates:
            candidates.append(name)
    candidates = candidates or ["mm", "cm", "m", "in"]
    bbox = document.get("bbox") or {}
    extent = bbox.get("extent_file")
    ev = [mk.measured("bbox_extent_m", extent, "facts.bbox.extent", unit="file units")] if extent else []
    return Uncertainty(
        id="unit", about="unit", subject="", effect="changes_mesh",
        why=("this file declares no unit, so every length I have is a ratio; a guessed unit that reads as a "
             "measured one is a 1,000x error"),
        options=candidates, options_from="the measurement's plausible-unit candidates",
        default=str(unit.get("assumed") or "") or None, evidence=ev)


def _fluid_side_uncertainty(document: dict[str, Any]) -> Uncertainty | None:
    """Which side of the surface is the fluid, when the document says the geometry could not settle it.

    Every document carries `fluid_side` now, and one written before the side was hardwired on does not, so this
    finder is silent. The options are the two readings and the default is today's (the file as the fluid), which
    is what the builder does when nobody answers; it is a default, never a confirmation."""
    side = document.get("fluid_side")
    if not isinstance(side, dict) or not side.get("open"):
        return None
    readings = side.get("readings") or {}
    words = {"through": "the fluid runs through the bores; the part is the solid around it",
             "is_fluid": "the part is the fluid itself, the volume the flow fills"}
    keys = [k for k in ("through", "is_fluid") if readings.get(k)]
    return Uncertainty(
        id="fluid_side", about="representation", subject="", effect="changes_mesh",
        why=f"{side.get('why') or 'the geometry does not say which side is the fluid'}; nothing on the flow path is "
            "placed until a person says which it is",
        options=[words[k] for k in keys], option_values=[str(readings[k]) for k in keys],
        options_from="the two readings of the same surface", default=words["is_fluid"] if "is_fluid" in keys else None)


def _unlabelled_uncertainties(impression: dict[str, Any] | None) -> list[Uncertainty]:
    rows = [r for r in ((impression or {}).get("openings_seen") or []) if isinstance(r, dict)]
    n = sum(1 for r in rows if str(r.get("id") or "unlabelled") == "unlabelled")
    if not n:
        return []
    return [Uncertainty(
        id="unlabelled_mouth", about="unlabelled_mouth", subject="", effect="changes_mesh",
        why=("the look reports a mouth the measurement did not find, which is the one thing here no "
             "measurement can supply"),
        options=["yes, there is an opening there", "no, the measurement is right"],
        options_from="a yes or no on the look's own report",
        evidence=[mk.seen("unlabelled_mouth", "a mouth with no label", "look.openings_seen",
                          impression=impression)])]


#: Alert kinds a customer can settle. `health` is about the READER (an empty reply, a digit that survived the
#: scrub) and is an operator's problem, not a question anybody should be asked; `instability` is a repeat call
#: disagreeing with itself, which a person cannot adjudicate either.
ASKABLE_ALERT_KINDS: tuple[str, ...] = ("contradiction", "impossibility", "omission", "self_contradiction")


def contradiction_uncertainties(alerts: Any) -> list[Uncertainty]:
    """The monitor's contradictions, as questions a person can settle.

    The second source of free ground truth. `reconcile/monitor.py` already finds where the look and the
    measurement disagree; where a human resolves one, that resolution is a labelled example on a real part at
    no annotation cost, exactly like an answered abstention.

    Duck typed over anything with the monitor's `Alert` fields, so this package does not import `reconcile` and
    a caller can pass dicts. Alerts of kind `health` are skipped: an empty reply or a digit that survived the
    scrub is an operator's problem and not a question to put to a customer.
    """
    def field_of(alert: Any, key: str) -> str:
        value = alert.get(key, "") if isinstance(alert, dict) else getattr(alert, key, "")
        return str(value or "")

    out: list[Uncertainty] = []
    for i, a in enumerate(alerts or []):
        kind = field_of(a, "kind")
        if kind not in ASKABLE_ALERT_KINDS:
            continue
        says, measured = field_of(a, "says"), field_of(a, "measured")
        if not says or not measured:
            continue
        subject = field_of(a, "subject")
        signal = field_of(a, "signal") or f"alert_{i}"
        where = f" at {subject}" if subject else ""
        out.append(Uncertainty(
            id=f"contradiction_{signal}{'_' + subject if subject else ''}",
            about="contradiction_resolution", subject=subject, effect="changes_mesh",
            why=(f"the two sources disagree{where}. The look says {says!r} and the measurement says "
                 f"{measured!r}. Neither can settle the other, so this needs a person"),
            options=[f"the look is right: {says}"[:120], f"the measurement is right: {measured}"[:120],
                     "neither"],
            options_from="both sides of the disagreement, in the words each side used"))
    return out


def _identity_uncertainty(impression: dict[str, Any] | None) -> Uncertainty | None:
    name = str((impression or {}).get("looks_like") or "").strip()
    if not name:
        return None
    return Uncertainty(
        id="identity", about="identity.name", subject="", effect="advisory", default=name,
        why=("the name from the picture is right on 215 of 322 at best and changes on 9 to 11 of 40 identical "
             "repeat calls, so it is a name to confirm and never a name to state"),
        options=["yes", "no, it is something else"], options_from="a yes or no on the look's proposal",
        evidence=[mk.seen("identity.name", name, "look.looks_like", impression=impression)])


def _budget_uncertainty(document: dict[str, Any], budget: int | None, budget_line: str) -> Uncertainty | None:
    """THE CELL FORECAST IS AN ENVELOPE, NOT A PREDICTION.

    Measure the part, work out what resolving it properly costs, compare with the budget the customer already
    stated. If it fits, ask nothing. If it genuinely does not fit, ask ONCE, as a real trade. The number comes
    from `tools.estimate_builder_cells` by way of `forecast()["cells_high"]`, never from the refinement ball.
    """
    forecast = document.get("forecast") or {}
    high = forecast.get("cells_high")
    if not isinstance(high, (int, float)) or budget is None:
        return None
    if int(high) <= int(budget):
        return None
    return Uncertainty(
        id="budget_trade", about="cell_budget", subject="", effect="changes_mesh",
        why=(f"resolving this part properly costs about {int(high):,} cells by the builder's own sizing, and "
             f"your brief asks for {int(budget):,}. Raising the budget resolves it as measured; holding it "
             f"means a coarser wall. Which?"),
        options=[f"hold {int(budget):,}", f"raise to about {int(high):,}"],
        #: the budget each option sets, in the options' order (the platform's NEEDS 4): `Given.budget` reads an
        #: int, and a caller that had to parse "hold 2,000,000" back into one was parsing our own sentence
        option_values=[int(budget), int(high)],
        options_from="the stated budget and the builder emulator's envelope",
        default=f"hold {int(budget):,}",
        evidence=[mk.measured("forecast.cells_high", int(high), "forecast.cells_high (estimate_builder_cells)"),
                  mk.stated("cell_budget", int(budget), f"brief: {budget_line}")])


def uncertainties_from(document: dict[str, Any], *, budget: int | None = None, budget_line: str = "",
                       declared: list[dict[str, Any]] | None = None,
                       alerts: Any = None) -> list[Uncertainty]:
    """Every uncertainty in one measurement document, in the order a person should be asked.

    THIS IS THE FALLBACK FINDER AND NOT THE PRODUCT'S. `ask.intake.ask_intake` is the finder the customer is
    asked by: it applies the four cuts, ranks what is left by consequence, puts at most `ask.intake.MAX_ASKED`
    and has a finder for `dispatch_refusal` and `flow_direction`, which this one does not. Both the chain
    (`chain.job.survey`) and the platform (`application/geometry_survey.composition`) pass its list in as
    `uncertainties=`, so nothing in the shipping path reaches this function through `contract.build.survey_from`
    any more.

    IT IS STILL REACHED, in one place that matters: `hexera.planner_survey` calls `survey_from` with no
    `uncertainties=`, so the `unsettled` list inside a freshly composed `planner_block` is THIS function's. That
    list is replaced by the real one when the answers arrive (`hexera.survey_with_answers`), because a block
    built before any finder ran cannot say what the customer was asked. Leaving two finders in the tree with no
    note is how the product ended up on the wrong one, so: this is the fallback, that is the finder.

    Nothing here needs an answer key or a brief-derived ground truth: it reads a measurement and a look and
    finds the places neither of them owns. It runs on a stranger's file exactly as it runs on the corpus.
    """
    look = document.get("look") or {}
    impression = look.get("impression") if isinstance(look, dict) else None
    out: list[Uncertainty] = []
    unit = _unit_uncertainty(document)
    if unit is not None:
        out.append(unit)
    side = _fluid_side_uncertainty(document)
    if side is not None:
        out.append(side)
    budget_u = _budget_uncertainty(document, budget, budget_line)
    if budget_u is not None:
        out.append(budget_u)
    out.extend(_role_uncertainties(document, impression, declared))
    out.extend(contradiction_uncertainties(alerts))
    out.extend(_unlabelled_uncertainties(impression))
    identity = _identity_uncertainty(impression)
    if identity is not None:
        out.append(identity)
    # ONE QUESTION PER ID. Six finders write into this list and two of them can reach the same place: a
    # `phantom_mouth` alert and an `unlabelled` mouth are different findings today, but a customer asked the
    # same thing twice stops answering, and the cost of insuring against that here is four lines.
    seen_ids: set[str] = set()
    unique: list[Uncertainty] = []
    for u in out:
        if u.id in seen_ids:
            continue
        seen_ids.add(u.id)
        unique.append(u)
    return unique


__all__ = ["ASKABLE_ALERT_KINDS", "ASKING_SCHEMA", "ROLES_NEEDED", "ROLE_OPTIONS", "Question",
           "contradiction_uncertainties", "questions_from", "uncertainties_from"]
