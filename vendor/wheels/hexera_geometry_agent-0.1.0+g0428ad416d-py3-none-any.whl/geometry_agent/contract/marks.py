"""A claim that knows what kind of thing it is, and a table saying who is allowed to make it.

THE PROBLEM THIS SOLVES. Today one document leaves the agent and every consumer reaches into it and takes what
it likes. A bore in metres, a word the model wrote about a picture, and a sentence the customer typed sit in the
same dict as bare values, and by the time any of them reaches the builder nothing about the value says which it
was. That is how the look reached the builder with nothing for five rounds and nobody noticed: there was no
place the absence could show up as a failure.

A `Mark` is a value that carries its own provenance. A consumer holding one can tell, from the value alone and
with no schema to hand, whether a claim was computed, seen or confirmed by a person.

THE FIVE KINDS, and the difference between them is WHO IS ENTITLED TO BE WRONG about the field.

  measured   an instrument computed it from the geometry. Reproducible, and the only kind that carries a digit
             the agent may act on.
  seen       the look said it from rendered pictures. Every digit was scrubbed before the model saw them, so a
             `seen` mark carries a word or a set of ids and never a number. It also carries a trust tier from
             `vision.trust`, which is the measured record of what the look is worth field by field.
  confirmed  a person answered a question. The highest authority on anything no instrument can compute: a role,
             an intent, a budget.
  stated     the customer wrote it in a brief and nobody has checked it. It is not a confirmation: nobody was
             asked, so nobody can be said to have agreed.
  assumed    a default. It is the weakest kind and it exists so that a default can never be mistaken for a
             measurement, which is the failure `unit` has had twice.

THE OWNERSHIP TABLE is the second half and the more important one. Rehaan's rule is that the geometry agent
decides what to DO and never re-decides what the geometry IS, and a rule like that survives only if it is a
table a validator reads. `OWNERS` names, for every field that crosses a stage boundary, which kinds may set it,
highest authority first. A mark whose kind is not in its field's row is a loud failure, not a warning:

  * a bore, a tilt, a thickness, a cell forecast is `measured` and nothing else. No model, no customer and no
    picture may supply one, so the geometry agent cannot re-derive what the survey measured even by accident.
  * an opening's ROLE is `confirmed` and nothing else. The measurement has no role, and the look abstains on
    six of every seven mouths and is right 48 percent of the time where it guesses. A role comes from the
    customer or from nowhere.
  * an attachment or a flange is `seen` first, because 25 of 25 recall and no measurement in this pipeline
    reports one at all.

WHAT IS FORBIDDEN EVERYWHERE is not written here. It is READ from `vision.trust.FIELDS`: every look field whose
tier is `recorded` may not cross any boundary, because that is what the recorded tier already means. This module
imports that decision rather than restating it, so a demotion in `trust.py` closes a door here on the next
import and there is exactly one place the tiers live.
"""
from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, field_validator

from geometry_agent.vision import trust

MARK_SCHEMA = "geometry_agent.contract.mark.v1"

MEASURED = "measured"
SEEN = "seen"
CONFIRMED = "confirmed"
STATED = "stated"
ASSUMED = "assumed"
KINDS: tuple[str, ...] = (MEASURED, SEEN, CONFIRMED, STATED, ASSUMED)

#: The legend as it rides in a prompt: one short phrase each, because the block is size-capped and a legend
#: that costs a fifth of the ceiling is a legend that pushes a finding out. The long form is `KIND_MEANING`.
KIND_SHORT: dict[str, str] = {
    MEASURED: "an instrument computed it",
    SEEN: "a model said it from pictures, no numbers, with a trust tier",
    CONFIRMED: "a person said it",
    STATED: "the customer wrote it and nobody checked",
    ASSUMED: "a default nobody stated",
}

KIND_MEANING: dict[str, str] = {
    MEASURED: "an instrument computed it from the geometry; reproducible, and the only kind that may carry a "
              "digit the agent acts on",
    SEEN: "the look said it from rendered pictures with every digit scrubbed; carries a word, never a number, "
          "and always a trust tier",
    CONFIRMED: "a person answered a question about this part; the highest authority on anything no instrument "
               "can compute",
    STATED: "the customer wrote it in a brief and nobody has checked it; not the same as confirmed, because "
            "nobody was asked",
    ASSUMED: "a default nobody stated; the weakest kind, and it exists so a default cannot be read as a "
             "measurement",
}

#: Highest authority first. Reading down a row is the order a consumer resolves a field in.
OWNERS: dict[str, tuple[str, ...]] = {
    # --- what the part IS. measured, and only measured, but for the one row below. ----------------------------
    #: The exception, and it is not an exception about the part: WHICH SIDE OF THE SURFACE IS THE FLUID is
    #: not in the geometry on a thick ring, a block pierced by several bores or a part with no mouth
    #: (`catalog.side_reading`). There the representation is the brief's words (`stated`), a person's answer
    #: (`confirmed`), or today's reading standing as a default (`assumed`). Measured still outranks all three,
    #: and on every part where the geometry settles it the mark is `measured` and nothing else is ever asked.
    "representation": (MEASURED, CONFIRMED, STATED, ASSUMED),
    "scale_to_metres": (MEASURED,),
    "bbox_extent_m": (MEASURED,),
    "bbox_diagonal_m": (MEASURED,),
    "opening_ids": (MEASURED,),
    "opening.centroid_m": (MEASURED,),
    "opening.normal": (MEASURED,),
    "opening.bore_m": (MEASURED,),
    "opening.min_dimension_m": (MEASURED,),
    "opening.tilt_deg": (MEASURED,),
    "opening.shape": (MEASURED,),
    "opening.kind": (MEASURED,),
    "thickness.min_m": (MEASURED,),
    "thickness.thin_clusters": (MEASURED,),
    "symmetry": (MEASURED,),
    "axes.principal": (MEASURED,),
    "bodies.count": (MEASURED,),
    "watertight": (MEASURED,),
    "stub.length_over_diameter": (MEASURED,),
    #: The envelope, and it comes from `tools.estimate_builder_cells` alone. `tools.refined_cell_estimate` has a
    #: median of 1.86x the delivered cells and a max of 576x and is not admissible here at any kind.
    "forecast.cells_high": (MEASURED,),
    "forecast.cells_low": (MEASURED,),
    "inlet_bore_m": (MEASURED,),

    # --- what only a person knows. -------------------------------------------------------------------------
    #: The measurement has no role and the look abstains on six of every seven mouths; where it does guess it is
    #: right 48 percent of the time, which is a coin flip. So: the customer, or nobody.
    "opening.role": (CONFIRMED,),
    "flow_direction": (CONFIRMED, STATED),
    #: `assumed` is on this row for the platform's upload, which measures before anybody states a purpose and
    #: fills one in; the survey marks it `assumed` (`build._part_marks`) rather than claiming the customer said it.
    "purpose": (CONFIRMED, STATED, ASSUMED),
    #: `assumed` is on this row because the engine has a default nobody states (snappy), and `build.py` has
    #: always written it as one. Without the kind on the row every brief that names no engine refused its own
    #: survey; the corpus never showed it because all 322 corpus briefs name snappyHexMesh, and the first
    #: stranger's file through the wired chain did (work/z-chain).
    "engine": (CONFIRMED, STATED, ASSUMED),
    #: A budget is never assumed. When the customer has not stated one the honest value is absent, and an absent
    #: budget is a question rather than a number invented to fill the field.
    "cell_budget": (CONFIRMED, STATED),
    #: A person settling a disagreement the monitor flagged between the look and the measurement. The two
    #: sources contradict each other and neither can adjudicate itself, so the only source that can is a
    #: person, and their answer is the second kind of free ground truth (`ratchet.py`).
    "contradiction_resolution": (CONFIRMED,),
    #: Whether to send a file back or try it anyway, when `hexera.triage` predicts a named platform raise. The
    #: prediction is a measurement of the file against the platform's rules; the decision is the customer's.
    "dispatch": (CONFIRMED,),

    # --- contested between sources, and the row IS the tie-break. ------------------------------------------
    #: An STL carries no unit, so `measured` here means the file declared one. A person outranks the file and
    #: the file outranks a guess; `assumed` is last and is why a guessed unit can never read as a fact.
    "unit": (CONFIRMED, STATED, MEASURED, ASSUMED),
    #: `looks_like` is right on 215 of 322 at best and changes on 9 to 11 of 40 identical repeats, so the look
    #: may PROPOSE a name and never state one, and its confidence is capped (see `IDENTITY_CONFIDENCE_MAX`).
    "identity.name": (CONFIRMED, STATED, SEEN),

    # --- what only the look has. ---------------------------------------------------------------------------
    #: 25 of 25 recall at 93 to 100 percent precision, and no measurement in this pipeline reports one at all.
    "attachments": (SEEN, CONFIRMED),
    #: No measurement reports whether a mouth stands proud, sits flush or sits in a pocket.
    "opening.mouth_standoff": (SEEN, CONFIRMED),
    #: An id of `unlabelled` is the look reporting a mouth the measurement did not find, which is the one thing
    #: here no measurement can supply.
    "unlabelled_mouth": (SEEN, CONFIRMED),
    #: The empty list is the finding: 0 false obstructions on 103 plain-passage cases.
    "inside_is_plain": (SEEN,),
    "internal_features": (SEEN, CONFIRMED),
}

#: A field the look is only ever a candidate on: a consumer may measure at the place it names and may never act
#: on the word itself. Derived from the tiers rather than listed twice.
CANDIDATE_ONLY: frozenset[str] = frozenset({"identity.name", "opening.mouth_standoff", "internal_features"})


def recorded_look_fields() -> frozenset[str]:
    """The look fields the trust ledger tiers `recorded`, read from `vision.trust` and never copied.

    A recorded field is kept so a person can read what the model said and for nothing else. It drives no
    decision and it reaches no model, so it may not cross a stage boundary in any handoff. Deriving the set
    here means a demotion in `trust.py` closes a door in the contract on the next import.
    """
    return frozenset(name for name, entry in trust.FIELDS.items() if entry.get("tier") == trust.RECORDED)


#: The same set spelled the way the contract names fields, so a validator can match on either. `openings_seen[]`
#: entries are tiered field by field in `trust.FIELDS`, and the two that are recorded are the class and the role.
FORBIDDEN_ALIASES: dict[str, str] = {
    "openings_seen[].looks_like": "opening.class_seen",
    "openings_seen[].likely_role": "opening.role_seen",
    "orientation": "orientation_seen",
    "symmetry": "symmetry_seen",
    "defects": "defects",
    "notes": "notes",
}


def forbidden_fields() -> frozenset[str]:
    """Every name a recorded look field goes by, in one set, for a validator that walks a payload's keys."""
    recorded = recorded_look_fields()
    out = set(recorded)
    for name, alias in FORBIDDEN_ALIASES.items():
        if name in recorded:
            out.add(alias)
    return frozenset(out)


#: R38, read from the ledger rather than written again: an identity whose only named support is the picture may
#: not carry more confidence than this.
IDENTITY_CONFIDENCE_MAX = trust.IDENTITY_CONFIDENCE_MAX


class ContractError(Exception):
    """A handoff that does not satisfy its contract. Raised, never logged and swallowed.

    The whole point of the three handoffs is that a missing required field stops the run at the boundary it went
    missing at, rather than arriving downstream as an empty string that reads like a real answer.

    It is NOT a `ValueError`, and that is deliberate rather than an oversight. Pydantic converts a `ValueError`
    raised inside validation into a `ValidationError`, which would bury the contract's own sentence inside a
    wrapper and force every caller to unwrap it to find out which rule was broken. Anything that is not a
    `ValueError` propagates out of validation unchanged, so the exception a caller catches is the exception this
    package raised, with the field and the rule on it.
    """

    def __init__(self, where: str, problem: str, *, field: str = "") -> None:
        self.where, self.problem, self.field = where, problem, field
        super().__init__(f"{where}: {problem}" + (f" [{field}]" if field else ""))


class Mark(BaseModel):
    """One claim, with the kind of thing it is attached to it.

    `field` is a key of `OWNERS`; `kind` must be one of the kinds that field's row admits. `tier` is required on
    a `seen` mark and is the word `vision.trust` gives that look field, so a consumer never has to remember
    which look fields earned their place.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    kind: str
    field: str
    value: Any
    #: Where it came from in words a reader can follow back: `facts.openings[o3].tilt_deg`, `question q2`,
    #: `brief line 7`. Required, because a claim whose source cannot be named is not a claim.
    source: str
    #: The trust tier, on a `seen` mark. Absent on every other kind.
    tier: str | None = None
    unit: str | None = None
    #: A `seen` identity carries its cap with it, so a downstream reader cannot act on it as if it were certain.
    confidence_max: float | None = None
    why: str = ""

    @field_validator("kind")
    @classmethod
    def _kind_known(cls, v: str) -> str:
        if v not in KINDS:
            raise ValueError(f"kind {v!r} is not one of {KINDS}")
        return v

    def model_post_init(self, _ctx: Any) -> None:
        row = OWNERS.get(self.field)
        if row is None:
            raise ContractError("mark", f"no field {self.field!r} in the ownership table", field=self.field)
        if self.field in forbidden_fields():
            raise ContractError("mark", "the trust ledger tiers this field `recorded`: it is kept for a person "
                                        "to read and may not cross a stage boundary", field=self.field)
        if self.kind not in row:
            raise ContractError(
                "mark", f"a {self.kind!r} claim may not set this field; it is owned by {row} in that order",
                field=self.field)
        if self.kind == SEEN and not self.tier:
            raise ContractError("mark", "a seen claim must carry its trust tier from vision.trust",
                                field=self.field)
        if self.kind == SEEN and _has_digit(self.value):
            raise ContractError("mark", "the look never produces a number: every digit is scrubbed before the "
                                        "model sees a picture, and a count is a digit", field=self.field)
        if self.field == "identity.name" and self.kind == SEEN:
            cap = self.confidence_max
            if cap is None or float(cap) > IDENTITY_CONFIDENCE_MAX:
                raise ContractError("mark", f"a name from the picture alone is capped at "
                                            f"{IDENTITY_CONFIDENCE_MAX}: {trust.IDENTITY_CONFIDENCE_MAX_WHY}",
                                    field=self.field)

    @property
    def authority(self) -> int:
        """Lower is higher authority. A consumer resolving two marks on one field keeps the smaller."""
        return OWNERS[self.field].index(self.kind)

    def is_fact(self) -> bool:
        """True when this value may be acted on as it stands: measured, or confirmed by a person."""
        return self.kind in (MEASURED, CONFIRMED)


def carries_number(text: str) -> bool:
    """Whether a string carries a NUMBER in the sense the look's scrub removes one.

    THE VALIDATOR READS THE SAME PATTERN AS THE SCRUB IT VALIDATES. `vision.prompt._NUMBER` is what replaces every
    numeric token in a reply with `[n]`, and it deliberately leaves an identifier alone: `o2` is the label the
    renderer drew from the MEASUREMENT, not a number the model produced. This check used to count any digit, so
    "flange at the o2 end" failed a survey the scrub had passed, and on the export corpus that refused the survey
    on 11 of 322 parts (`eval/chain/run_chain.py`, first pass). Two instruments reading two definitions of a
    number is the blind-spot pattern this project keeps finding; now there is one definition.
    """
    from geometry_agent.vision.prompt import _NUMBER
    return bool(_NUMBER.search(str(text)))


def _has_digit(value: Any) -> bool:
    """Whether a value a `seen` mark would carry contains a number anywhere inside it."""
    if isinstance(value, bool):
        return False
    if isinstance(value, (int, float)):
        return True
    if isinstance(value, str):
        return carries_number(value)
    if isinstance(value, dict):
        return any(_has_digit(k) or _has_digit(v) for k, v in value.items())
    if isinstance(value, (list, tuple, set)):
        return any(_has_digit(v) for v in value)
    return False


def measured(field: str, value: Any, source: str, *, unit: str | None = None, why: str = "") -> Mark:
    return Mark(kind=MEASURED, field=field, value=value, source=source, unit=unit, why=why)


def seen(field: str, value: Any, source: str, *, impression: dict | None = None, why: str = "") -> Mark:
    """A look claim, with its tier read out of `vision.trust` for the field it is on."""
    tier_field = _TIER_FIELD.get(field, field)
    tier = trust.tier_of(tier_field, impression or {})
    cap = IDENTITY_CONFIDENCE_MAX if field == "identity.name" else None
    return Mark(kind=SEEN, field=field, value=value, source=source, tier=tier, confidence_max=cap,
                why=why or str(trust.FIELDS.get(tier_field, {}).get("why") or ""))


def confirmed(field: str, value: Any, source: str, *, why: str = "") -> Mark:
    return Mark(kind=CONFIRMED, field=field, value=value, source=source, why=why)


def stated(field: str, value: Any, source: str, *, why: str = "") -> Mark:
    return Mark(kind=STATED, field=field, value=value, source=source, why=why)


def assumed(field: str, value: Any, source: str, *, why: str = "") -> Mark:
    return Mark(kind=ASSUMED, field=field, value=value, source=source, why=why)


#: Which `vision.trust` field a contract field's tier is read from, where the two are spelled differently.
_TIER_FIELD: dict[str, str] = {
    "identity.name": "looks_like",
    "attachments": "attachments",
    "opening.mouth_standoff": "openings_seen[].mouth",
    "unlabelled_mouth": "openings_seen[].id",
    "inside_is_plain": "internal_features",
    "internal_features": "internal_features",
}


def resolve(marks: list[Mark], field: str) -> Mark | None:
    """The winning mark on one field: highest authority, and on a tie the first one given.

    This is the whole tie-break, and it is one function so there is never a second answer to one question. A
    confirmed unit beats a brief, a brief beats the file's own declaration, and every one of them beats a guess,
    because that is the order `OWNERS['unit']` is written in.
    """
    on_field = [m for m in marks if m.field == field]
    if not on_field:
        return None
    return min(on_field, key=lambda m: m.authority)


def require(marks: list[Mark], fields: tuple[str, ...], where: str) -> None:
    """Every field in `fields` has a mark, or the handoff fails here and loudly."""
    have = {m.field for m in marks}
    missing = [f for f in fields if f not in have]
    if missing:
        raise ContractError(where, f"required fields have no mark: {missing}. A required field that is absent "
                                   f"stops the handoff here rather than arriving downstream as an empty string")


def check_no_forbidden(payload: Any, where: str) -> None:
    """Walk a payload and refuse any key the trust ledger tiers `recorded`."""
    bad = forbidden_fields()

    def walk(node: Any, path: str) -> None:
        if isinstance(node, dict):
            for k, v in node.items():
                if str(k) in bad:
                    raise ContractError(where, f"carries {k!r}, which the trust ledger tiers `recorded`: "
                                               f"{trust.WITHHELD_FROM_MODELS.get(str(k), 'it drives no decision')}",
                                        field=f"{path}.{k}".lstrip("."))
                walk(v, f"{path}.{k}".lstrip("."))
        elif isinstance(node, (list, tuple)):
            for i, v in enumerate(node):
                walk(v, f"{path}[{i}]")

    walk(payload, "")


def as_json(mark: Mark, *, compact: bool = False) -> dict[str, Any]:
    """The self-describing form: `kind` first, so a reader that prints two lines of it already knows what it
    is holding.

    `compact` drops `why`, which is the ledger sentence behind a claim. It belongs where a person reads it: the
    survey handoff, the session report, a log. It does not belong in a size-capped block riding in a prompt,
    where one 200-character sentence repeated over four mouths is a finding pushed out by the cap. The KIND and
    the SOURCE stay in both forms, because those are what a consumer branches on.
    """
    out: dict[str, Any] = {"kind": mark.kind, "value": mark.value, "field": mark.field, "source": mark.source}
    for key in ("tier", "unit", "confidence_max"):
        v = getattr(mark, key)
        if v is not None:
            out[key] = v
    if mark.why and not compact:
        out["why"] = mark.why
    return out


__all__ = ["ASSUMED", "CANDIDATE_ONLY", "KIND_SHORT", "CONFIRMED", "FORBIDDEN_ALIASES", "IDENTITY_CONFIDENCE_MAX",
           "KINDS", "KIND_MEANING", "MARK_SCHEMA", "MEASURED", "Mark", "ContractError", "OWNERS", "SEEN",
           "STATED", "as_json", "assumed", "carries_number", "check_no_forbidden", "confirmed", "forbidden_fields",
           "measured",
           "recorded_look_fields", "require", "resolve", "seen", "stated"]
