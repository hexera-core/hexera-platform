"""HOW IT GETS BETTER AS MORE REAL CAD RUNS THROUGH IT, and it is not model training.

A RATCHET. A trust tier that gets demoted stays demoted. A computation that gets added stays added. Neither
regresses. That is the whole mechanism, and the reason it is worth having is that every other way this project
has tried to improve has been reversible by the next round's arithmetic.

WHAT FEEDS IT, and this is the part that costs nothing:

  1. THE CUSTOMER'S ANSWER. The survey says "o3, role unsure". Intake asks because that abstention IS the
     question. The customer says "that is a drain". We now have a labelled example on a real part, from a
     question we were asking anyway, with no annotator and no answer key. `intake.label_from` builds the row.
  2. A CONTRADICTION A HUMAN RESOLVED. `reconcile/` already flags where the look and the measurement disagree.
     Where a person settles one, the same row exists with the same zero cost.

WHAT IT DOES WITH THEM. Nothing automatic and nothing statistical. It counts, and when a field's record over
real parts crosses a stated floor it writes a DEMOTION, which is a permanent entry: this look field may no
longer decide anything. A promotion needs a superseding ledger entry naming a measurement that earned it, and
`apply` refuses one that does not. The asymmetry is deliberate: it is cheap to lose trust and expensive to gain
it, which is the opposite of how a metric that optimises itself behaves.

WHY IT IS NOT A CALIBRATION TABLE. A table gets recomputed and a recomputation can go either way. This is
append-only, and `state()` is a fold over the entries in order. An entry cannot be removed, so a demotion
cannot be lost by a later run choosing different arithmetic.

WHAT THIS CANNOT DO, said plainly because eight times here a measuring tool has had the blind spot of the thing
it measured. It only ever learns about a field a customer was asked about. A field nobody is asked about is
invisible to it, however wrong it is, and the answer to that is to ask, not to infer. It also cannot tell a
customer who is wrong from a look that is wrong: a confirmation is authoritative by contract, so a customer who
mislabels a port demotes a look field that was right. The ledger records who answered so that a person can go
back and see, and nothing here tries to second-guess it.

OFF BY DEFAULT. Nothing writes to a ledger unless a caller passes a path.

WHERE THE ROWS COME FROM, and until 2026-09-23 the answer was nowhere. `intake.label_from` had no caller
anywhere in the tree and this module was imported by its own test and nothing else, so the mechanism described
above had no input at all while `docs/contract.md` said it was what reads the rows. `chain/job.labels_from`
builds them now, off the second and third intakes, and drops any answer whose `answered_by` is `default_taken`,
because a ledger of this pipeline's own guesses fed back would demote a look field for disagreeing with us.

IT IS NOT THE LIVE RECALIBRATION and the two must not be confused. `chain/recalibrate.py` is what the CLI runs:
it reads whole job records rather than label rows, tests its counts against a measured null (0.07, the rate at
which this pipeline contradicts itself on a role with nothing changed) rather than the flat floor below, and it
is the only one with a state file. This module is the per-field score of the LOOK against a customer, which that
one does not compute. Neither changes anything by itself.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from geometry_agent.contract.marks import ContractError
from geometry_agent.vision import trust

RATCHET_SCHEMA = "geometry_agent.contract.ratchet.v1"

DEMOTE = "demote"
ADD_COMPUTATION = "add_computation"
PROMOTE = "promote"
OBSERVE = "observe"
ACTIONS: tuple[str, ...] = (OBSERVE, DEMOTE, ADD_COMPUTATION, PROMOTE)

#: The tiers, lowest trust last. A demotion moves down this list and never up.
TIER_ORDER: tuple[str, ...] = (trust.RELIED_ON, trust.CANDIDATE, trust.RECORDED)

#: How many real answers a field needs before its record may move a tier. Below this the count is kept and
#: nothing is decided: a field seen three times is an anecdote.
MIN_OBSERVATIONS = 20

#: The share of confirmations that must disagree with a relied-on field before it is demoted. Set at a third
#: rather than at a half deliberately: a field that is wrong one time in three is not one a consumer may act on
#: without asking, which is exactly what the candidate tier means.
DEMOTE_AT_DISAGREEMENT = 1 / 3


@dataclass(frozen=True)
class Entry:
    """One append-only fact about the pipeline's own record. Never edited, never removed."""

    action: str
    field: str
    why: str
    at: str
    #: The evidence: how many real parts, how many agreed, and which shas, so a person can go and look.
    n: int = 0
    disagreed: int = 0
    parts: tuple[str, ...] = ()
    to_tier: str = ""
    #: A promotion is only admissible with a measurement that earned it, named here.
    earned_by: str = ""

    def as_json(self) -> dict[str, Any]:
        return {"schema": RATCHET_SCHEMA, "action": self.action, "field": self.field, "why": self.why,
                "at": self.at, "n": self.n, "disagreed": self.disagreed, "parts": list(self.parts),
                "to_tier": self.to_tier, "earned_by": self.earned_by}


def entry(action: str, field: str, why: str, **kw: Any) -> Entry:
    if action not in ACTIONS:
        raise ContractError("ratchet", f"action {action!r} is not one of {ACTIONS}")
    return Entry(action=action, field=field, why=why,
                 at=datetime.now(UTC).isoformat(timespec="seconds"), **kw)


def observations(labels: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    """Fold labelled rows into a per-field record. Deterministic, and it needs no answer key.

    `agreed` is a row where the look said something and the customer confirmed it. `disagreed` is a row where
    the look said something and the customer said otherwise. An ABSTENTION is neither: it is counted on its own
    line, because the whole design turns on an abstention being the right answer rather than a miss.
    """
    out: dict[str, dict[str, Any]] = {}
    for row in labels:
        field = str(row.get("about") or "")
        if not field:
            continue
        rec = out.setdefault(field, {"n": 0, "agreed": 0, "disagreed": 0, "abstained": 0, "parts": []})
        rec["n"] += 1
        sha = str(row.get("source_sha256") or "")
        if sha and sha not in rec["parts"]:
            rec["parts"].append(sha)
        if row.get("look_abstained"):
            rec["abstained"] += 1
        elif str(row.get("look_said")) == str(row.get("confirmed")):
            rec["agreed"] += 1
        else:
            rec["disagreed"] += 1
    return out


def proposed(labels: list[dict[str, Any]], *, current: dict[str, str] | None = None) -> list[Entry]:
    """The entries this evidence justifies. Demotions only; a promotion is never proposed by arithmetic.

    `current` is the tier each field sits at now, defaulting to what `vision.trust` says today.
    """
    tiers = dict(current or {})
    out: list[Entry] = []
    for field, rec in sorted(observations(labels).items()):
        decided = rec["agreed"] + rec["disagreed"]
        if decided < MIN_OBSERVATIONS:
            out.append(entry(OBSERVE, field, f"{decided} decided answers, under the floor of "
                                             f"{MIN_OBSERVATIONS}: counted, nothing decided",
                             n=rec["n"], disagreed=rec["disagreed"], parts=tuple(rec["parts"][:20])))
            continue
        share = rec["disagreed"] / decided
        now = tiers.get(field) or _tier_now(field)
        if share >= DEMOTE_AT_DISAGREEMENT and now != trust.RECORDED:
            nxt = TIER_ORDER[min(TIER_ORDER.index(now) + 1, len(TIER_ORDER) - 1)]
            out.append(entry(DEMOTE, field,
                             f"{rec['disagreed']} of {decided} confirmations disagreed with it on real parts, "
                             f"which is {share:.0%}, at or over the {DEMOTE_AT_DISAGREEMENT:.0%} floor",
                             n=rec["n"], disagreed=rec["disagreed"], parts=tuple(rec["parts"][:20]),
                             to_tier=nxt))
        else:
            out.append(entry(OBSERVE, field,
                             f"{rec['disagreed']} of {decided} disagreed, {share:.0%}, under the floor",
                             n=rec["n"], disagreed=rec["disagreed"], parts=tuple(rec["parts"][:20])))
    return out


def _tier_now(field: str) -> str:
    alias = {"opening.role": "openings_seen[].likely_role", "identity.name": "looks_like",
             "opening.mouth_standoff": "openings_seen[].mouth", "attachments": "attachments"}
    return trust.tier_of(alias.get(field, field), {})


def apply(entries: list[Entry], *, start: dict[str, str] | None = None) -> dict[str, Any]:
    """Fold the ledger into a state. Monotone: a tier only ever moves down the list.

    A `promote` with no `earned_by` is REFUSED, not ignored. The refusal is the ratchet: it is the one place
    where the code says out loud that gaining trust costs more than losing it.
    """
    tiers = dict(start or {})
    computations: list[str] = []
    refused: list[str] = []
    for e in entries:
        if e.action == DEMOTE:
            now = tiers.get(e.field) or _tier_now(e.field)
            target = e.to_tier or TIER_ORDER[min(TIER_ORDER.index(now) + 1, len(TIER_ORDER) - 1)]
            if TIER_ORDER.index(target) < TIER_ORDER.index(now):
                refused.append(f"{e.field}: a demotion that moves the tier UP is not a demotion")
                continue
            tiers[e.field] = target
        elif e.action == PROMOTE:
            if not e.earned_by:
                refused.append(f"{e.field}: a promotion needs a measurement that earned it; "
                               f"{e.why!r} is not one")
                continue
            now = tiers.get(e.field) or _tier_now(e.field)
            target = e.to_tier or now
            if TIER_ORDER.index(target) > TIER_ORDER.index(now):
                refused.append(f"{e.field}: a promotion that moves the tier DOWN is not a promotion")
                continue
            tiers[e.field] = target
        elif e.action == ADD_COMPUTATION:
            if e.field not in computations:
                computations.append(e.field)
    return {"schema": RATCHET_SCHEMA, "tiers": tiers, "computations": computations, "refused": refused,
            "entries": len(entries)}


def append(path: str | Path, entries: list[Entry]) -> int:
    """Write entries to an append-only JSONL ledger. Returns how many were written."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("a", encoding="utf-8") as fh:
        for e in entries:
            fh.write(json.dumps(e.as_json(), sort_keys=True) + "\n")
    return len(entries)


def read(path: str | Path) -> list[Entry]:
    p = Path(path)
    if not p.exists():
        return []
    out: list[Entry] = []
    for line in p.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        row = json.loads(line)
        out.append(Entry(action=row["action"], field=row["field"], why=row["why"], at=row["at"],
                         n=int(row.get("n") or 0), disagreed=int(row.get("disagreed") or 0),
                         parts=tuple(row.get("parts") or ()), to_tier=str(row.get("to_tier") or ""),
                         earned_by=str(row.get("earned_by") or "")))
    return out


__all__ = ["ACTIONS", "ADD_COMPUTATION", "DEMOTE", "DEMOTE_AT_DISAGREEMENT", "Entry", "MIN_OBSERVATIONS",
           "OBSERVE", "PROMOTE", "RATCHET_SCHEMA", "TIER_ORDER", "append", "apply", "entry", "observations",
           "proposed", "read"]
