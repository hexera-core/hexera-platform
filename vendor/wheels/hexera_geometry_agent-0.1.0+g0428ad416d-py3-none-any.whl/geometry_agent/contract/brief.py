"""HANDOFF 0: the customer's brief, which comes FIRST.

REHAAN'S ORDER, and it is not up for debate: intake states the brief before anything is measured, because the
brief genuinely changes the representation decision. `catalog.representation` reads the brief ("carve the fluid
cavity INSIDE it") and the customer's port rows (a declared port brings back a ring the ring rules took out),
so the same file is a wall shell under one brief and a fluid domain under none. Today the upload hook measures
BEFORE intake and the order the two happen in is an accident. This handoff makes it a dependency: the survey
carries the sha of the brief it was measured against (`survey.SurveyHandoff.brief_sha256`), and
`survey.bound_to_brief` refuses a survey measured against no brief or against a different one.

WHAT IT MUST CARRY:

  purpose       what the job is for. Internal flow, external flow, conjugate heat transfer or structural.
  text          the customer's own words. May be empty, which is a stranger's file, and that is honest.
  sha256        a pure function of everything below, so two stages can check they are about the same brief.

WHAT IT MAY CARRY: the engine the customer named, the fidelity, the port rows intake parsed out of the brief
(the customer's boundary conditions), and the cell budget, read out of the brief's own words.

WHAT IS FORBIDDEN:

  * a measurement. Intake measures nothing and sees nothing. A port row may say where the customer says a port
    is and how big they say it is; those are the customer's statements (`stated`) and every one of them is
    checked against the measurement later, never taken as one.
  * a budget that is `assumed`. An absent budget is a question, not a number invented to fill the field.
  * a role outside the purpose's own vocabulary (`hexera.PURPOSE_ROLES` plus `opening_unknown`/`closed_end`).
"""
from __future__ import annotations

import hashlib
import json
from typing import Any, get_args

from pydantic import BaseModel, ConfigDict, Field

from geometry_agent.contract import marks as mk
from geometry_agent.contract.marks import ContractError, Mark
from geometry_agent.contract.survey import budget_from_brief
from geometry_agent.facts.schema import Fidelity, Purpose

BRIEF_SCHEMA = "geometry_agent.contract.brief.v1"

PURPOSES: tuple[str, ...] = tuple(get_args(Purpose))
FIDELITIES: tuple[str, ...] = tuple(get_args(Fidelity))

#: The roles a customer's port row may carry. The closed list the handover speaks, plus the two the plan schema
#: uses for a mouth that is known to be no port.
DECLARED_ROLES: frozenset[str] = frozenset({"inlet", "outlet", "wall", "symmetry", "farfield", "closed_end",
                                            "interface", "opening_unknown"})

#: A port row is the customer's statement about a place. These are the keys it may carry and nothing else: a
#: row with a `bore_diameter_m` on it would be intake reporting a measurement, which intake never makes.
DECLARED_KEYS: frozenset[str] = frozenset({"name", "role", "type", "near", "near_mm", "area", "bore_diameter",
                                           "normal", "shape"})


class BriefHandoff(BaseModel):
    """What the customer stated before anything was measured."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    schema_name: str = BRIEF_SCHEMA
    purpose: str
    text: str = ""
    engine: str | None = None
    fidelity: str = "standard"
    declared: list[dict[str, Any]] = Field(default_factory=list)
    #: `stated` when read out of the brief or handed over by intake, `confirmed` when a person answered. Never
    #: `assumed`: `OWNERS['cell_budget']` admits no assumption, and this handoff is where that bites first.
    cell_cap: Mark | None = None
    sha256: str = ""

    def model_post_init(self, _ctx: Any) -> None:
        if self.purpose not in PURPOSES:
            raise ContractError("brief", f"purpose {self.purpose!r} is not one of {PURPOSES}", field="purpose")
        if self.fidelity not in FIDELITIES:
            raise ContractError("brief", f"fidelity {self.fidelity!r} is not one of {FIDELITIES}",
                                field="fidelity")
        for i, row in enumerate(self.declared):
            if not isinstance(row, dict):
                raise ContractError("brief", f"port row {i} is not a row", field=f"declared[{i}]")
            extra = sorted(set(row) - DECLARED_KEYS)
            if extra:
                raise ContractError("brief", f"port row {i} carries {extra}: a port row is the customer's "
                                             f"statement about a place, and intake measures nothing",
                                    field=f"declared[{i}]")
            role = str(row.get("role") or row.get("type") or "")
            if role and role not in DECLARED_ROLES:
                raise ContractError("brief", f"port row {i} has role {role!r}, outside {sorted(DECLARED_ROLES)}",
                                    field=f"declared[{i}].role")
        if self.cell_cap is not None and self.cell_cap.field != "cell_budget":
            raise ContractError("brief", "the budget mark must be on field `cell_budget`", field="cell_cap")
        expected = brief_sha(self.purpose, self.text, self.engine, self.fidelity, self.declared,
                             None if self.cell_cap is None else self.cell_cap.value)
        if self.sha256 and self.sha256 != expected:
            raise ContractError("brief", "sha256 does not match the brief it is attached to: a brief edited "
                                         "after it was hashed is a different brief", field="sha256")
        if not self.sha256:
            object.__setattr__(self, "sha256", expected)

    @property
    def budget(self) -> int | None:
        return None if self.cell_cap is None else int(self.cell_cap.value)

    @property
    def engine_source(self) -> str:
        return "declared" if self.engine else "assumed"


def brief_sha(purpose: str, text: str, engine: str | None, fidelity: str, declared: list[dict[str, Any]],
              cell_cap: Any) -> str:
    """A pure function of what the customer stated. No time, no session, no model, so the same brief re-hashes
    to the same value and a survey can be checked against it months later."""
    payload = json.dumps({"purpose": purpose, "text": text or "", "engine": engine or "", "fidelity": fidelity,
                          "declared": declared or [], "cell_cap": cell_cap}, sort_keys=True, default=str)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def brief_from(purpose: str, text: str = "", *, declared: list[dict[str, Any]] | None = None,
               engine: str | None = None, fidelity: str = "standard", cell_cap: int | None = None,
               cell_cap_by: str = "") -> BriefHandoff:
    """The first intake's output.

    `cell_cap` is a budget intake already holds; `cell_cap_by` names who gave it (a person answering makes it
    `confirmed`, anything else `stated`). With no `cell_cap` the budget is read out of the brief's own words by
    `survey.budget_from_brief`, which needs no answer key, and a brief that states none has no budget at all.
    """
    if cell_cap is not None:
        kind = mk.CONFIRMED if cell_cap_by in ("customer", "operator") else mk.STATED
        mark = Mark(kind=kind, field="cell_budget", value=int(cell_cap),
                    source=f"intake: {cell_cap_by or 'handed over with the brief'}")
    else:
        value, line = budget_from_brief(text)
        mark = None if value is None else mk.stated("cell_budget", int(value), f"brief: {line}",
                                                    why="the customer's own words; nobody has been asked to "
                                                        "confirm it")
    return BriefHandoff(purpose=purpose, text=text or "", engine=engine or None, fidelity=fidelity,
                        declared=[dict(r) for r in (declared or [])], cell_cap=mark)


__all__ = ["BRIEF_SCHEMA", "DECLARED_KEYS", "DECLARED_ROLES", "FIDELITIES", "PURPOSES", "BriefHandoff",
           "brief_from", "brief_sha"]
