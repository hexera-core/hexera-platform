"""Reconciling the measurement with the look: what each one can and cannot say about the other's claims.

STEP 4 IS WIRED. `chain/job.run_job` calls `chain/job.reconcile`, which calls `reconcile.joint.for_job`, between
the look and the second intake. Before that it was eight files and 257 KB with no importer anywhere under `src/`:
`ask/uncertainty.dispute_uncertainty` was built to read a `Reconciliation`, sat behind
`if reconciliation is None: return []`, and nothing ever built one. `tests/test_reconcile_wiring.py` reads this
paragraph against an import scan of the tree, and `tests/test_chain_reconcile.py` follows the call, because a
function that exists is not a function that runs. WIRED INTO `run_job`, which is the whole of the claim: the
platform does not call `run_job`, so a customer job driven through it still does not reach step 4. That is
"AND `run_job` IS THE ONLY CALLER" below, and it is the one thing left before this layer earns its description.

WHAT IT IS WORTH, measured over 322 corpus parts and four cached draws with no answer key used to produce any of
it: 247, 243, 246 and 255 contradictions, on 159, 153, 156 and 160 parts, raising a customer question on 72, 72,
70 and 73. Parts with no contradiction run 8.3 per cent false statements and parts with three run 25.7. It is the
only quality signal in this product that works on a customer file nobody has ever seen, because a disagreement
between two sources needs no answer key to notice.

AND EVERY ONE OF THOSE COUNTS WAS MEASURED UNDER A PROMPT THAT IS NOT THE ONE WE SHIP. The cached replies were
taken under variant `panels_stops`, which asked `orientation` and `symmetry`. The shipped prompt is `swept_two`
and asks neither, so `run_claims` makes no claim about either: a field the prompt never asked has no answer, and
reading its empty value as the look's answer would be reading silence as a finding. Re-scored with today's
`vision.prompt.not_asked(SYSTEM)`, on the same replies and the same four draws, the same pipeline finds 132, 130,
130 and 142 contradictions on 112, 109, 108 and 111 parts. 46 per cent of every published contradiction in this
layer came from two fields a live job cannot produce. The QUESTION count is untouched (72, 72, 70 and 73), because
no question was ever about either field, and so are the suppressions. What needs re-measuring on today's prompt
is the banding above, which is the number that would go in front of an operator.

WHAT THE SHIPPING PATH GETS TODAY, on the same corpus, the same four draws and today's prompt: 114, 115, 117 and
127 contradictions, on 98, 96, 96 and 98 parts of 322, raising a customer question on 58, 58, 57 and 59. Every
finding is one the full pipeline also makes, with the same count, and nothing is invented. The gap is one missing
reader, `eval/vision/stance.py`, which `src/` cannot import; `joint.Joint.readers` carries its absence into the
block so no count is read as agreement about the inside.

WHAT IT COSTS: 0.088 s a job median with the triangles in hand, 0.21 s median when it loads them itself, over 12
real corpus parts at four repeats each. One helical mixer takes 17.9 s and 17.6 s of that is `load_mesh`.

RE-MEASURED INDEPENDENTLY, on parts anyone can regenerate rather than on a list nobody can, because a number in a
docstring with no way back to it is not evidence. `corpus_complex.machinery.pump_volute`, `globe_valve`,
`exhaust_manifold`, `serpentine`, `cyclone` and `wye_unequal`, exported to STL, measured, then `chain/job.reconcile`
timed four times each with the path passed so it loads its own triangles: 0.013, 0.013, 0.013, 0.028, 0.045 and
0.053 s median, 466 to 14,970 triangles, median of medians 0.021 s. The eight synthetic fixtures come in at 0.001 to
0.064 s, median 0.006 s, on the same four repeats, and the four that short circuit on representation sit at 0.001 s.
Slower than that means a bigger mesh and it is `load_mesh`, not this layer. Against a job that pays for a vision
call this is free, and that is the point of quoting it: the cost is never the reason not to run step 4.

TWO FAILURE MODES THIS LAYER HAS, both of them the measurement's and neither of them the look's, and both now
pinned rather than described. A missing record of what the renderer labelled read as "nothing was labelled" and
turned 247, 243, 246 and 255 contradictions into 1,799, 1,798, 1,800 and 1,808, with 317 of 322 parts flagged on
every draw (`inventory.Measured.labelled`). A missing
negation splitter read a denial as an assertion and invented 9, 5, 5 and 9 WITHHOLD-tier firings a draw
(`reconcile.phrasing`).

AND A THIRD, WHICH IS THE `not_asked` RULE APPLIED ON ONE READER AND NOT ITS TWIN. `inventory.run_claims` skips a
claim whose field the prompt never asked. `monitor.run_signals` reads the same `Look`, which has carried
`not_asked` all along, and did not gate on it, so the two could disagree about whether `orientation` exists at all:
on the cached corpus, taken under a variant that DID ask it, `long_axis_named_wrong` fires at WITHHOLD, which
suppresses the look, while the contradiction count has stopped counting the field. `run_signals` now gates, one
signal of 24 reads such a field, and the set is DERIVED from each signal's source rather than listed, so a new one
fails a test until it declares `reads=`.

WHERE THAT LEAVES EACH CALLER, because the gate can only act on a `Look` that was given a `not_asked` to act on.
`joint.run` builds its `Look` with `not_asked_of(look_block)`, so the live path and everything through
`joint.for_job` is gated. `eval/vision/inventory.py:202` passes `not_asked=not_asked_of(rec)`, and that is the
script the re-scored contradiction counts above came from, which is why those numbers already exclude the field.
`eval/vision/monitor.py:107` and `eval/vision/reconcile.py:78` build a `Look` with no `not_asked` at all, so those
two benches stay ungated and their firing counts still include the field the contradiction counts exclude. Adding
it is one keyword argument in each, and both are NEEDS FROM OTHERS: `eval/` is not this branch's to edit.

THE LIVE PATH NEVER SHOWED THIS, and that is measured rather than assumed: a reply to the shipped prompt carries no
orientation, and with the field empty the signal returns nothing even with the gate taken out. So this one cost the
bench numbers their consistency with each other and cost a customer nothing, which is the opposite way round from
the first two.

WHAT REACHES THE BUILDER, and all of it as a fact about the JOB rather than a claim about the part.
`joint.record_block` at its default (`counts`) carries the numbers, the question, the confirmed fields, the tiers
and the firings as signal IDS, and quotes no suppressed sentence. `joint.planner_block` then puts
`contradictions` and the firings INSIDE `look`, because the platform's `GEOMETRY_AGENT_BLOCK_KEYS` is an allowlist
and a new top-level key is dropped in silence. The MEASURED half goes to the same place by a different route:
`joint.into_document` writes `measured_places` and `hexera._planner_places` ranks the rows, which is +77 places
over 322 parts and the only throat and section-change places there are.

AND `run_job` IS THE ONLY CALLER, which is the honest limit of the sentence at the top. The platform composes its
own document and never calls `run_job`: `meshpipeline/application/geometry_survey.compose` builds it out of
`hexera.report_measured` and takes exactly one name from this package's chain module
(`chain.job.contract_uncertainties`), and a grep for `reconcile`, `joint`, `into_document` or `alerts` over
`geometry_survey.py`, `geometry_step.py` and `geometry_vision.py` returns nothing at all. So step 4 runs for this
package's own whole-chain entry, for its tests and for the eval, and a customer job driven through the platform
still does not reach it. The seam is one call wide and it is `geometry_vision.py`, at `attach_look(document, look)`:
that is the one moment the platform holds the measurement, the look AND the local bytes together, and the bytes are
inside a `TemporaryDirectory` that is discarded on the next line, so the call has to go in that block or pay a
second fetch. Wiring it is a NEEDS FROM OTHERS, because `src/meshpipeline/` is not this branch's to edit.

THE THREE KEYS ARE NOT WRITTEN ONTO THE STEP-3 DOCUMENT, and that is deliberate. `into_document` is called on the
step-7 document (`chain/job.deliver_to_builder`, on `final`) because `hexera._planner_places` reads `measured_places`
off the document the planner block is built from, and that is that one. Writing the same three keys onto
`run.document` as well looks like symmetry and is measurably nothing: over a whole job on three fixtures, with the
three keys present and with them absent, every question, every uncertainty, the whole builder handoff and every note
came back byte identical, and an instrumented `run.document` recorded no read of any of the three by any consumer,
on `__getitem__`, `get`, `__contains__`, `keys`, `items`, `values`, iteration or `copy`. `run.document` never leaves
`run_job`. A key that is written is not a key that is read, and adding one here would be this project's signature
failure wearing this layer's clothes.

WHAT IS STILL NOT REACHED, of the eight. `entry.mouth_runs` (the per-mouth march, and with it the `at_each_mouth`
half of `say.block`) is not called: it cuts a plane per station per region, its own docstring puts that at seconds
to minutes on a large part, and nobody has measured it on four draws. `joint.Joint.readers` carries `mouth_march`
so the document says the channel did not run rather than implying it found nothing. `walk.py` grades the `walk`
field, and `vision.prompt.not_asked(SYSTEM)` names `walk`: the shipped prompt never asks for one, so that whole
channel is dead by construction and its fate belongs with the prompt rather than here.
"""
