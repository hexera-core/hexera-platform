"""The inventory the reconciler is built on: for every field the look produces, what the measurement can say.

ONE FUNCTION PER CHECKABLE CLAIM. Each takes the measurement and one look and returns findings, each of which
is CONFIRM, CONTRADICT or SILENT. SILENT is a first-class answer and is the commonest one: a field the
measurement cannot reach is a fact about the pair, not a gap in this file, and it is reported rather than
omitted. A claim that can only ever confirm is worth nothing to a reconciler, so every claim below is written
so that both verdicts are reachable, and the ones where they are not say so in `CANNOT`.

WHAT A CONTRADICTION MEANS, and this is the sentence the reconciler has to be built around. It means ONE OF
THESE TWO IS WRONG. It does not mean the look is wrong. What is known about the measurement's own error, per
claim, is `verdict.STANDING`: a licence, the measured cost of holding it, and an `untested` flag where the
corpus could not exercise it. `eval/vision/inventory.py` measures it against the corpus answer key and prints
the cases where the measurement is the one at fault.

THIS PARAGRAPH USED TO NAME A TABLE CALLED `RELIABILITY`, IN THIS FILE, AND THERE HAS NEVER BEEN ONE. The table
is `verdict.STANDING` and always was. A docstring naming a structure that does not exist is the same defect as a
key that is written and never read, on the one paragraph a reader of this package reads first.

AND THE `untested` FLAG IS NOT DECORATION, which one near-miss in this round proved. `opening_id_exists` holds
`OVERRULES`, the licence that suppresses the look outright, with `"untested": True` and "0 contradictions on all
four draws" beside it. Wired with no record of what the renderer labelled, that claim went from never firing to
1,552, 1,555, 1,554 and 1,553 suppressions a draw. An OVERRULES licence the corpus has never exercised is a
loaded gun, and what
made it safe was `Measured.labelled` being able to say "nobody recorded this" rather than "nothing was drawn".

WHY THE LOOK-SIDE READING IS INJECTED RATHER THAN WRITTEN HERE. The project has been burned seven times by a
measuring tool that shared a blind spot with the thing it measured. The question "does this reply assert the
passage is plain" already has a format-neutral, hand-checked answer in `eval/vision/stance.py`, scored against
151 replies read by hand. Writing a second one here would be a new blind spot with no hand check behind it, so
`Look.stance` is passed in and this file never re-decides it. What this file does read for itself is narrow,
per-field vocabulary (an axis name, a mouth word, a shape word) where no detector existed.

Nothing here reads a brief, a family, a file name or an answer key.
"""
from __future__ import annotations

import re
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from typing import Any

import numpy as np

from geometry_agent.reconcile import phrasing
from geometry_agent.reconcile.profile import (
    FlowProfile,
    mark_is_solid,
    obstruction_marks,
    restriction_verdict,
)

CONFIRM = "confirm"
CONTRADICT = "contradict"
SILENT = "silent"


@dataclass
class Finding:
    """One verdict about one claim, about one sub-item of one field."""
    claim: str
    look_field: str
    verdict: str
    subject: str = ""
    said: str = ""
    measured: str = ""
    note: str = ""


@dataclass
class Measured:
    """Everything the measurement holds about one part, in the form the claims read it.

    `facts` is the `GeometryFacts` the pipeline already produces. `profile` is the 41-station cross-section
    `render.choose_stations` computes and discards, recovered by `reconcile.profile`. `mark_places` and
    `stopped` are the renderer's own records of where it put the letters and which faces the stops detector
    called stops, taken from the bench record rather than recomputed so a claim cannot drift from the picture
    the model was actually shown."""
    case: str
    representation: str
    facts: Any
    profile: FlowProfile
    #: [{"id": "A", "cut": 3, "kind": "void"|"body"|"cut"}], or None when nobody recorded it. Three-state for
    #: the reason `labelled` is: see below, and `knows_marks`.
    mark_places: list[dict] | None = None
    #: opening ids the stops detector called stops, in the order the panels are captioned, or None when nobody
    #: recorded it. Three-state for the reason `labelled` is: see below, and `knows_stops`.
    stopped: list[str] | None = None
    #: THREE STATES AND NOT TWO, and the difference is about 1,550 false suppressions a draw.
    #:
    #: `["o1", "o2"]`   the renderer drew a label for o1 and o2 and this is its own record of it
    #: `[]`             the renderer drew no labels, and says so
    #: `None`           NOBODY RECORDED WHAT WAS LABELLED. The measurement does not know.
    #:
    #: The third state is what the shipping path has, because `hexera.look_block`'s `drawn` table carries
    #: `marks` and `stops` and not `labelled` (a NEEDS FROM OTHERS on `vision/look.py`). Before this field
    #: could say so, the empty list served for both, and an absent record read as "the renderer drew nothing":
    #: `opening_id_exists` then contradicted every mouth the look correctly answered and `monitor.phantom_mouth`
    #: raised a WITHHOLD on each one. Measured over the 322-part corpus and four cached draws, that is 1,552,
    #: 1,555, 1,554 and 1,553 false suppressions and the same count of false alerts, on 317 of 322 parts on every
    #: draw, against 159, 153, 156 and 160 with the record present. A signal that fires on 98 per cent of files is
    #: not a signal. With the absence recorded as absence, all three counts are byte for byte the record-present
    #: ones on all four draws.
    #:
    #: Every reader of these three fields must ask the matching `knows_` first. `None` is not "none drawn".
    #: All three are the RENDERER's record of what it put on the paper, they arrive together in the look
    #: block's `drawn` table, and they go missing together: a stored look taken before that table existed, or
    #: a manifest that could not be read, leaves all three unknown at once.
    labelled: list[str] | None = None

    @property
    def knows_labels(self) -> bool:
        """Whether anyone recorded which openings the renderer drew a label for."""
        return self.labelled is not None

    @property
    def knows_marks(self) -> bool:
        """Whether anyone recorded which letters the renderer drew, and where."""
        return self.mark_places is not None

    @property
    def knows_stops(self) -> bool:
        """Whether anyone recorded which openings the stops detector drew a panel for."""
        return self.stopped is not None

    def opening(self, oid: str):
        return next((o for o in self.facts.openings if o.id == oid), None)

    def stub(self, oid: str):
        return next((s for s in self.facts.stubs if s.opening_id == oid), None)

    @property
    def has_passage(self) -> bool:
        return self.representation in ("fluid_domain", "annular_fluid", "wall_shell")


@dataclass
class Look:
    """One reply, plus the verdicts an existing detector already decided about it."""
    case: str
    impression: dict
    #: `stance.stance()`'s dict: verdict in names / denies / declines / silent, with its evidence.
    stance: dict = field(default_factory=lambda: {"verdict": "silent", "named": [], "denied": []})
    #: `stance.says_it_is_solid()`: has this reply said in its own words that the part has no interior. Read
    #: by `reconcile.monitor` and injected here for the same reason `stance` is: it is hand-checked against
    #: 151 replies read by eye and a second copy of it would be a second blind spot.
    says_solid: bool = False
    #: A clause cut into pieces, each marked negated or contrastive. A mark answer's meaning turns on a
    #: negation ("not fluid", "excluded from the fluid volume"), and the project has one hand-built splitter
    #: for that: it lived in `eval/vision/meaning.py`, which `src/` cannot import, so on the shipping path this
    #: was None and every reader fell back to the whole string. `reconcile.phrasing` is that splitter under
    #: `src/`, pinned equal to the eval copy over all 1,288 cached replies, and it is the DEFAULT here so the
    #: injection cannot be forgotten again. Passing None explicitly still selects the negation-blind fallback,
    #: which is what the tests that measure the fallback's cost do.
    segments: Any = phrasing.segments
    #: The record fields the prompt this reply answered NEVER ASKED (`vision.prompt.not_asked`). Each is in the
    #: record at its empty value, and reading that value as the look's answer is reading silence as a finding:
    #: under `swept_two` an unasked `symmetry` reads "unsure", and under `swept` an unasked `sharp_edges` with a
    #: measured knife edge would be a false CONTRADICT. `run_claims` makes no claim about any of them.
    not_asked: tuple[str, ...] = ()

    def get(self, key: str, default=None):
        return (self.impression or {}).get(key, default)

    def list_of(self, key: str) -> list[str]:
        v = self.get(key)
        if isinstance(v, str):
            return [v] if v.strip() else []
        return [str(x) for x in v if str(x).strip()] if isinstance(v, list) else []

    def text_of(self, key: str) -> str:
        return " ".join(self.list_of(key)) if isinstance(self.get(key), list) else str(self.get(key) or "")


# ---------------------------------------------------------------------------------------------------------------
# the narrow, per-field vocabulary this file reads for itself
# ---------------------------------------------------------------------------------------------------------------

#: An axis named in words. `orientation` is prose, and the question asked of it is only ever which axis is the
#: long one, because that is the only thing the measurement holds exactly (`bbox.longest_axis`).
_LONG_AXIS = re.compile(r"long(?:est)?\s+axis[^.;]{0,40}?([+-]?\s*[XYZ])\b", re.I)
_AXIS_FALLBACK = re.compile(r"\b(?:runs|lies|extends|oriented|aligned)\s+(?:along|with|parallel to)\s+"
                            r"(?:the\s+)?([+-]?\s*[XYZ])\b", re.I)
_UNSURE = re.compile(r"\bunsure\b|\bcannot tell\b|\bcan'?t tell\b|\bunclear\b|\bnot (?:sure|clear)\b", re.I)

#: The look's own words for material and for space, read at a lettered place. Deliberately short: a letter
#: answer is a few words, and the two classes are the only thing this claim asks about.
_SAYS_MATERIAL = re.compile(r"\bsolid\b|\bmaterial\b|\bwall\b|\bmetal\b|\bbody\b|\bplug\b|\bcore\b|\bweb\b"
                            r"|\brib\b|\bvane\b|\bbaffle\b|\bblade\b|\bstrut\b|\bboss\b|\bcentre[- ]?body\b"
                            r"|\bcenter[- ]?body\b|\bfilled\b|\bblocked\b|\bobstruct", re.I)
_SAYS_SPACE = re.compile(r"\bopen\b|\bbore\b|\bvoid\b|\bempty\b|\bcavit|\bpassage\b|\bchannel\b|\bgap\b"
                         r"|\bhole\b|\bhollow\b|\bspace\b|\bclear\b|\bduct\b|\bannul", re.I)

#: A stop panel answered. The prompt asks whether the passage ends at a wall or carries on.
_SAYS_STOPS = re.compile(r"\bruns into\b|\bgoes no further\b|\bdead[- ]?ends?\b|\bblind\b|\bclosed\b|\bcapped\b"
                         r"|\bblocked\b|\bstops?\b|\bterminat|\bends? (?:at|in|against)\b|\bsealed\b", re.I)
_SAYS_CONTINUES = re.compile(r"\bcontinues\b|\bcarries on\b|\bgoes (?:on|through)\b|\bpasses through\b"
                             r"|\bopens? (?:out|into|through)\b|\bnot (?:closed|blocked|capped)\b"
                             r"|\bthrough[- ]?(?:flow|passage)\b", re.I)

#: A taper named in words: the diffuser cone row, which the measurement has in the profile and the look does
#: not have in its answers.
_SAYS_TAPER = re.compile(r"\btapers?\b|\btapering\b|\bcones?\b|\bconical\b|\bdiffuser\b|\bexpans|\bwidens?\b"
                         r"|\bwidening\b|\bnarrows?\b|\bnarrowing\b|\bcontract|\bventuri\b|\bthroat\b"
                         r"|\bnozzle\b|\breduc|\bflares?\b|\bflaring\b|\bbell[- ]?mouth\b"
                         r"|\bchange (?:of|in) (?:section|area|diameter)\b|cross[- ]?section(?:al)? (?:change|area)", re.I)

#: The look's word for a knife edge, which is the one edge class the measurement counts separately.
_SAYS_KNIFE = re.compile(r"\bknife\b|\btrailing edge\b|\brazor\b|\bfeather(?:ed)? edge\b|\bwedge\b", re.I)

_SAYS_MIRROR = re.compile(r"\bmirror\b|\bbilateral\b|\bsymmetric(?:al)? about\b|\bplane of symmetry\b"
                          r"|\bsymmetry plane\b", re.I)
_SAYS_ROTATIONAL = re.compile(r"\brotational(?:ly)?\b|\baxisymmetric\b|\bsurface of revolution\b|\bn-fold\b"
                              r"|\b\d+-fold\b|\brevolved?\b", re.I)
_SAYS_NO_SYMMETRY = re.compile(r"\bnone apparent\b|\bno (?:apparent |obvious )?symmetry\b|\bnot symmetric"
                               r"|\basymmetric", re.I)

#: The look's names for a part with an internal passage and for a part that is a body in a stream. Used for
#: the one `looks_like` claim the measurement can decide: which of the two kinds of file this is.
_NAME_INTERNAL = re.compile(r"\bduct\b|\bpipe\b|\bmanifold\b|\bplenum\b|\bhousing\b|\belbow\b|\bnozzle\b"
                            r"|\bvolute\b|\bscroll\b|\bheader\b|\bchamber\b|\bventuri\b|\bdiffuser\b"
                            r"|\bmixer\b|\bcyclone\b|\bseparator\b|\bexchanger\b|\bcasing\b|\bmanifold\b"
                            r"|\bpassage\b|\bflow (?:domain|volume|path)\b|\bchannel\b|\breducer\b|\btee\b"
                            r"|\bwye\b|\bfitting\b|\bbend\b", re.I)
_NAME_EXTERNAL = re.compile(r"\bwing\b|\baerofoil\b|\bairfoil\b|\bcar\b|\bvehicle\b|\bbody\b|\bbluff\b"
                            r"|\bahmed\b|\bfuselage\b|\bnacelle\b|\brotor\b|\bimpeller\b|\bpropeller\b"
                            r"|\bbracket\b|\bhull\b|\bblade\b", re.I)


def _axis_said(text: str) -> int | None:
    """0, 1, 2 for X, Y, Z when the prose names a long axis, else None. The sign is discarded: an axis is an
    axis and `bbox.longest_axis` has no sign to compare against."""
    for pat in (_LONG_AXIS, _AXIS_FALLBACK):
        m = pat.search(text or "")
        if m:
            return "xyz".index(m.group(1).strip().lstrip("+-").lower())
    return None


def _letter_of(answer: str) -> str:
    m = re.match(r"^\s*\(?([A-Za-z])\)?\s*[:.)\-]\s+", answer or "")
    return m.group(1).upper() if m else ""


# ---------------------------------------------------------------------------------------------------------------
# the claims
#
# Signature: fn(Measured, Look) -> list[Finding]. Registered by the decorator with the look field it is about
# and a one-line statement of what it cannot do, which is printed in the inventory table.
# ---------------------------------------------------------------------------------------------------------------

CLAIMS: list[dict[str, Any]] = []


def claim(look_field: str, what: str, cannot: str, how: str):
    def wrap(fn: Callable[[Measured, Look], list[Finding]]):
        CLAIMS.append({"id": fn.__name__, "field": look_field, "what": what,
                       "cannot": cannot, "how": how, "fn": fn})
        return fn
    return wrap


# --- looks_like ---------------------------------------------------------------------------------------------

@claim("looks_like",
       what="whether the name is of a part with a passage through it or of a body in a stream",
       cannot="the part's actual name. The measurement holds no vocabulary of parts and never will.",
       how="the measured representation (fluid_domain / annular_fluid / wall_shell against external)")
def looks_like_kind_of_file(m: Measured, look: Look) -> list[Finding]:
    name = str(look.get("looks_like") or "")
    if not name.strip():
        return [Finding("looks_like_kind_of_file", "looks_like", SILENT, note="no name given")]
    internal, external = bool(_NAME_INTERNAL.search(name)), bool(_NAME_EXTERNAL.search(name))
    if internal == external:
        return [Finding("looks_like_kind_of_file", "looks_like", SILENT, said=name,
                        note="the name says neither or both")]
    if m.representation == "unknown":
        return [Finding("looks_like_kind_of_file", "looks_like", SILENT, said=name,
                        note="representation unknown")]
    wants_passage = internal
    has_passage = m.has_passage
    verdict = CONFIRM if wants_passage == has_passage else CONTRADICT
    return [Finding("looks_like_kind_of_file", "looks_like", verdict, said=name,
                    measured=m.representation,
                    note="a housing named on an external body, or a wing named on a fluid domain")]


@claim("looks_like",
       what="nothing else. This claim exists to put the size of that silence in the table.",
       cannot="everything: the noun, the family, the duty, the industry.",
       how="not computable from geometry")
def looks_like_the_name_itself(m: Measured, look: Look) -> list[Finding]:
    name = str(look.get("looks_like") or "")
    return [Finding("looks_like_the_name_itself", "looks_like", SILENT, said=name,
                    note="the measurement holds no part name and cannot confirm or contradict one")]


# --- confidence ---------------------------------------------------------------------------------------------

@claim("confidence",
       what="nothing. It is a statement about the model, not about the geometry.",
       cannot="be confirmed or contradicted by any measurement. It is usable as a TRIGGER and not as a claim.",
       how="not computable from geometry")
def confidence_is_about_the_model(m: Measured, look: Look) -> list[Finding]:
    return [Finding("confidence_is_about_the_model", "confidence", SILENT,
                    said=str(look.get("confidence") or ""),
                    note="a confidence is not a claim about the part")]


# --- orientation --------------------------------------------------------------------------------------------

@claim("orientation",
       what="which bounding-box axis is the longest",
       cannot="which end is the nose, which face is the base, or which way the flow goes. The measurement has "
              "`axes.blunt_end_sign` but it is a guess with its own confidence and is not used here.",
       how="facts.bbox.longest_axis against the axis named in the prose")
def orientation_long_axis(m: Measured, look: Look) -> list[Finding]:
    text = look.text_of("orientation")
    if not text.strip():
        return [Finding("orientation_long_axis", "orientation", SILENT, note="no orientation given")]
    if _UNSURE.search(text) and _axis_said(text) is None:
        return [Finding("orientation_long_axis", "orientation", SILENT, said=text[:80],
                        note="the look declined to name an axis")]
    said = _axis_said(text)
    if said is None:
        return [Finding("orientation_long_axis", "orientation", SILENT, said=text[:80],
                        note="no long axis named in the prose")]
    got = int(m.facts.bbox.longest_axis)
    extent = list(m.facts.bbox.extent)
    order = sorted(extent, reverse=True)
    if len(order) > 1 and order[1] > 0 and order[0] / order[1] < 1.05:
        return [Finding("orientation_long_axis", "orientation", SILENT, said="xyz"[said], measured="xyz"[got],
                        note="the two longest extents are within 5 per cent: there is no longest axis")]
    return [Finding("orientation_long_axis", "orientation", CONFIRM if said == got else CONTRADICT,
                    said="xyz"[said], measured="xyz"[got])]


# --- openings_seen ------------------------------------------------------------------------------------------

def _openings_seen(look: Look) -> list[dict]:
    v = look.get("openings_seen")
    return [o for o in v if isinstance(o, dict)] if isinstance(v, list) else []


@claim("openings_seen[].id",
       what="whether the id exists and whether a label for it was actually drawn",
       cannot="whether a drawn label was VISIBLE in the views. An id the look never mentions is silent here, "
              "because occlusion is real and the measurement cannot see the picture.",
       how="facts.openings ids and the renderer's own `labelled` list")
def opening_id_exists(m: Measured, look: Look) -> list[Finding]:
    out: list[Finding] = []
    ids = {o.id for o in m.facts.openings}
    # THE MEASUREMENT'S OWN FAILURE MODE, AND IT IS NOT THE LOOK'S FAULT. This claim rests entirely on the
    # renderer's record of which openings it labelled. With no record there is no claim: an id the look named
    # is then neither confirmed nor contradicted, because the only thing that could contradict it is missing.
    # Reading the absent record as "nothing was labelled" contradicted 1,552, 1,555, 1,554 and 1,553 correctly
    # answered mouths over the four cached draws. See `Measured.labelled`.
    if not m.knows_labels:
        return [Finding("opening_id_exists", "openings_seen[].id", SILENT, subject=str(s.get("id") or ""),
                        note="nobody recorded which openings the renderer labelled, so this claim has no "
                             "measurement to make one")
                for s in _openings_seen(look)]
    drawn = set(m.labelled or ())
    for seen in _openings_seen(look):
        oid = str(seen.get("id") or "").strip()
        if not oid or oid.lower() in ("unlabelled", "unlabeled", "none", "unsure"):
            out.append(Finding("opening_id_exists", "openings_seen[].id", SILENT, subject=oid,
                               note="an unlabelled opening: the measurement cannot match it to an id"))
            continue
        if oid in drawn:
            out.append(Finding("opening_id_exists", "openings_seen[].id", CONFIRM, subject=oid,
                               measured="a label for this id was drawn"))
        elif oid in ids:
            out.append(Finding("opening_id_exists", "openings_seen[].id", CONTRADICT, subject=oid,
                               measured="this opening was measured but no label for it was drawn"))
        else:
            out.append(Finding("opening_id_exists", "openings_seen[].id", CONTRADICT, subject=oid,
                               measured=f"no such opening; the measurement found {len(ids)}"))
    return out


@claim("openings_seen[].looks_like",
       what="hole, cap and open end against the measured classification; flange face not at all",
       cannot="a FLANGE. No measurement in this pipeline reports one, and the look is 25 of 25 on them. Every "
              "`flange face` answer is silent here and that silence is the point.",
       how="facts.openings[].classification, .kind, .bore_diameter and the stub behind the face")
def opening_looks_like_vs_class(m: Measured, look: Look) -> list[Finding]:
    out: list[Finding] = []
    if not m.has_passage:
        # On an external body the measured opening classes are about the domain box and the body's own flat
        # faces, not about ports into a passage, and `port_candidate` fires on both. Contradicting the look's
        # "not a port" on a wing's face was 49 of this claim's 50 contradictions and the look was right every
        # time. The measurement has no standing here and says so.
        return [Finding("opening_looks_like_vs_class", "openings_seen[].looks_like", SILENT, subject=str(s.get("id") or ""),
                        note=f"{m.representation}: no internal passage for a port to serve")
                for s in _openings_seen(look)]
    for seen in _openings_seen(look):
        oid = str(seen.get("id") or "").strip()
        said = str(seen.get("looks_like") or "").strip().lower()
        o = m.opening(oid)
        if o is None or not said or said == "unsure":
            out.append(Finding("opening_looks_like_vs_class", "openings_seen[].looks_like", SILENT,
                               subject=oid, said=said,
                               note="unsure, or no measured opening of that id"))
            continue
        if said in ("flange face", "flange", "lip"):
            out.append(Finding("opening_looks_like_vs_class", "openings_seen[].looks_like", SILENT,
                               subject=oid, said=said, measured=o.classification,
                               note="the measurement has no flange and no lip concept"))
            continue
        stub = m.stub(oid)
        bore = bool(o.bore_diameter) or bool(stub and stub.length_over_diameter >= 0.5)
        if said == "hole":
            ok = o.classification == "hole"
            bad = o.classification in ("port_candidate", "ring") and bore
        elif said == "cap":
            ok = o.kind == "cap" and not bore
            bad = bore
        elif said == "open end":
            ok = bore or o.classification in ("port_candidate", "ring")
            # only a face that is a large flat SIDE of the body contradicts "open end". A planar_face with a
            # small area fraction is often a fluid domain's own port that the stub march did not resolve, and
            # contradicting the look there was 27 of this claim's 56 contradictions.
            bad = o.classification == "planar_face" and not bore and o.area_fraction_of_region >= 0.05
        else:
            out.append(Finding("opening_looks_like_vs_class", "openings_seen[].looks_like", SILENT,
                               subject=oid, said=said, note="no measured counterpart for this word"))
            continue
        verdict = CONFIRM if ok else (CONTRADICT if bad else SILENT)
        out.append(Finding("opening_looks_like_vs_class", "openings_seen[].looks_like", verdict, subject=oid,
                           said=said, measured=f"{o.kind}/{o.classification}, bore={bore}"))
    return out


@claim("openings_seen[].mouth",
       what="very little, and less than the first version of this claim believed. A flat side of a block "
            "cannot be protruding, and a face with a long tube of its own behind it is not flush with a wall.",
       cannot="RECESSED, at all: no pocket depth is measured anywhere in the facts. And it cannot use "
              "`on_bbox_face` the way the first version did. A protruding stub's mouth is the extreme point "
              "of the part, so it lies ON the bounding box: reading that as flush contradicted `protruding` "
              "on 86 faces, most of them nozzle stubs that do protrude. `on_bbox_face` says where a face is, "
              "never whether it stands proud, and this claim is mostly silent because of it.",
       how="facts.openings[].classification with the stub length over the opening's own diameter")
def opening_mouth_vs_bbox(m: Measured, look: Look) -> list[Finding]:
    out: list[Finding] = []
    for seen in _openings_seen(look):
        oid = str(seen.get("id") or "").strip()
        said = str(seen.get("mouth") or "").strip().lower()
        o = m.opening(oid)
        if o is None or said in ("", "unsure"):
            out.append(Finding("opening_mouth_vs_bbox", "openings_seen[].mouth", SILENT, subject=oid,
                               said=said, note="unsure, or no measured opening of that id"))
            continue
        if said == "recessed":
            out.append(Finding("opening_mouth_vs_bbox", "openings_seen[].mouth", SILENT, subject=oid,
                               said=said, note="no pocket depth is measured anywhere in the facts"))
            continue
        stub = m.stub(oid)
        lod = float(stub.length_over_diameter) if stub else 0.0
        # a tube of its own, twice as long as it is wide, behind the face
        tube = o.classification == "port_candidate" and lod >= 2.0
        # a flat side of a body: it is the surface, so nothing can stand proud of it
        side = o.classification == "planar_face" and o.area_fraction_of_region >= 0.05
        # A tube behind the face does NOT contradict `flush`. A plain pipe end has the whole pipe behind it
        # and is neither proud of anything nor sunk into anything: there is no surrounding wall to be flush
        # with. Reading a long stub as "therefore protruding" contradicted `flush` on 101 faces, most of them
        # ordinary pipe ends. Only one direction of this claim survives.
        if said == "flush":
            verdict = CONFIRM if side else SILENT
        elif said == "protruding":
            verdict = CONFIRM if tube else (CONTRADICT if side else SILENT)
        else:
            verdict = SILENT
        out.append(Finding("opening_mouth_vs_bbox", "openings_seen[].mouth", verdict, subject=oid, said=said,
                           measured=f"{o.classification}, stub L/D={lod:.1f}, "
                                    f"area_fraction={o.area_fraction_of_region:.2f}",
                           note="" if verdict != SILENT
                                else "neither a flat side of a body nor a face with a tube behind it"))
    return out


@claim("openings_seen[].likely_role",
       what="`not a port`, against a face the measurement classified as a plain side of a body",
       cannot="INLET against OUTLET. Nothing in a static geometry says which way the flow goes. Every inlet "
              "and every outlet answer is silent here, which is 100 per cent of the role answers that are not "
              "`not a port` or `unsure`.",
       how="facts.openings[].classification and the stub behind the face")
def opening_role_not_a_port(m: Measured, look: Look) -> list[Finding]:
    out: list[Finding] = []
    if not m.has_passage:
        # On an external body the measured opening classes are about the domain box and the body's own flat
        # faces, not about ports into a passage, and `port_candidate` fires on both. Contradicting the look's
        # "not a port" on a wing's face was 49 of this claim's 50 contradictions and the look was right every
        # time. The measurement has no standing here and says so.
        return [Finding("opening_role_not_a_port", "openings_seen[].likely_role", SILENT, subject=str(s.get("id") or ""),
                        note=f"{m.representation}: no internal passage for a port to serve")
                for s in _openings_seen(look)]
    for seen in _openings_seen(look):
        oid = str(seen.get("id") or "").strip()
        said = str(seen.get("likely_role") or "").strip().lower()
        o = m.opening(oid)
        if o is None or said in ("", "unsure"):
            out.append(Finding("opening_role_not_a_port", "openings_seen[].likely_role", SILENT, subject=oid,
                               said=said, note="unsure, or no measured opening of that id"))
            continue
        if said in ("inlet", "outlet"):
            out.append(Finding("opening_role_not_a_port", "openings_seen[].likely_role", SILENT, subject=oid,
                               said=said, measured=o.classification,
                               note="no measurement distinguishes an inlet from an outlet"))
            continue
        if said in ("not a port", "not a port ", "none"):
            stub = m.stub(oid)
            tube = o.classification == "port_candidate" and bool(stub and stub.length_over_diameter >= 1.0)
            verdict = CONTRADICT if tube else (CONFIRM if o.classification == "planar_face" else SILENT)
            out.append(Finding("opening_role_not_a_port", "openings_seen[].likely_role", verdict, subject=oid,
                               said=said, measured=f"{o.classification}, tube_behind={tube}"))
            continue
        out.append(Finding("opening_role_not_a_port", "openings_seen[].likely_role", SILENT, subject=oid,
                           said=said, note="no measured counterpart for this word"))
    return out


@claim("openings_seen[].why",
       what="nothing. It is free prose about the model's reasoning.",
       cannot="be checked at all.",
       how="not computable from geometry")
def opening_why_is_prose(m: Measured, look: Look) -> list[Finding]:
    return [Finding("opening_why_is_prose", "openings_seen[].why", SILENT,
                    subject=str(s.get("id") or ""), said=str(s.get("why") or "")[:60],
                    note="free prose") for s in _openings_seen(look)]


# --- internal_features: the headline --------------------------------------------------------------------

@claim("internal_features",
       what="THE HEADLINE. Whether the look's assertion that the passage is plain survives the cross-section "
            "profile that `choose_stations` computes and discards.",
       cannot="speak at all on an external body, and cannot read a passage whose bore leaves the cut plane "
              "(an s-duct, a tee branch). Those are SILENT and they are a third of the corpus.",
       how="reconcile.profile.restriction_verdict over the 41-station flow-area profile, against "
           "stance.stance()'s format-neutral verdict")
def passage_plain_vs_profile(m: Measured, look: Look) -> list[Finding]:
    verdict, detail = restriction_verdict(m.profile)
    said = look.stance.get("verdict", "silent")
    where = f"{verdict}" + (f" at t={detail['at']:.2f}, {detail['open_fraction']:.0%} open"
                            if detail and "open_fraction" in detail else "")
    if verdict == "unreadable":
        return [Finding("passage_plain_vs_profile", "internal_features", SILENT, said=said,
                        measured=where, note=(detail or {}).get("why", ""))]
    if said == "denies":
        out = CONTRADICT if verdict == "restricted" else CONFIRM
        return [Finding("passage_plain_vs_profile", "internal_features", out, said="the passage is plain",
                        measured=where)]
    if said == "names":
        out = CONFIRM if verdict == "restricted" else CONTRADICT
        return [Finding("passage_plain_vs_profile", "internal_features", out,
                        said="names " + ", ".join(k for k, _ in look.stance.get("named", [])[:3]),
                        measured=where)]
    return [Finding("passage_plain_vs_profile", "internal_features", SILENT, said=said, measured=where,
                    note="the look neither named nor denied")]


@claim("internal_features",
       what="the same question on the independent channel: a solid thing standing inside the passage, found "
            "on the cut image the model was shown and never told to it",
       cannot="see anything that touches the wall. A mixer element welded to the bore wall is not enclosed in "
              "that plane and nominates nothing, so this channel is blind to it. It is also blind wherever "
              "the representation is neither a wall shell nor a fluid domain.",
       how="reconcile.profile.obstruction_marks over the renderer's own `mark_places`: the `body` kind on a "
           "wall shell and the `void` kind on a fluid domain, which are not the same kind")
def passage_plain_vs_body_marks(m: Measured, look: Look) -> list[Finding]:
    if not m.mark_places:
        return [Finding("passage_plain_vs_body_marks", "internal_features", SILENT,
                        note="no lettered marks were drawn on this part")]
    bodies = obstruction_marks(m.mark_places, m.representation)
    if not m.has_passage:
        return [Finding("passage_plain_vs_body_marks", "internal_features", SILENT,
                        note=f"{m.representation}: no passage for a thing to stand in")]
    said = look.stance.get("verdict", "silent")
    measured = (f"{len(bodies)} of {len(m.mark_places)} marks stand on a solid thing in the passage"
                if bodies else "no mark stands on a solid thing in the passage")
    if said == "denies":
        return [Finding("passage_plain_vs_body_marks", "internal_features",
                        CONTRADICT if bodies else CONFIRM, said="the passage is plain", measured=measured)]
    if said == "names":
        return [Finding("passage_plain_vs_body_marks", "internal_features",
                        CONFIRM if bodies else SILENT, said="names something inside", measured=measured,
                        note="" if bodies else "a thing that touches the wall nominates no body mark")]
    return [Finding("passage_plain_vs_body_marks", "internal_features", SILENT, said=said, measured=measured)]


@claim("internal_features",
       what="a change of section: the diffuser cone row, which the measurement has to three decimals",
       cannot="tell a cone from a step from a sudden widening. It reads the two ends, so a passage that "
              "narrows and widens back to the same size reads as no taper at all.",
       how="reconcile.profile.FlowProfile.taper over the recovered 41-station profile")
def taper_named_vs_profile(m: Measured, look: Look) -> list[Finding]:
    if not m.profile.usable:
        return [Finding("taper_named_vs_profile", "internal_features", SILENT,
                        note=m.profile.why_not or "no readable profile")]
    tp = m.profile.taper()
    text = " ".join(look.list_of("internal_features") + look.list_of("notes")
                    + [str(look.get("looks_like") or "")] + look.list_of("marks_seen"))
    said = bool(_SAYS_TAPER.search(text))
    measured = f"ratio {tp['ratio']:.2f}" if tp else "ends within the taper ratio"
    if tp and said:
        return [Finding("taper_named_vs_profile", "internal_features", CONFIRM, said="names a change of section",
                        measured=measured)]
    if tp and not said:
        return [Finding("taper_named_vs_profile", "internal_features", CONTRADICT,
                        said="no change of section named", measured=measured)]
    if not tp and said:
        return [Finding("taper_named_vs_profile", "internal_features", CONTRADICT,
                        said="names a change of section", measured=measured)]
    return [Finding("taper_named_vs_profile", "internal_features", CONFIRM, said="no change of section named",
                    measured=measured)]


@claim("internal_features",
       what="a separate body sitting inside the file: an insert, a core, a fixture",
       cannot="see a feature modelled as part of the same body, which is how the corpus builds almost all of "
              "them. It fires on 10 of 316 parts.",
       how="facts.bodies and facts.regions[].contains")
def insert_named_vs_bodies(m: Measured, look: Look) -> list[Finding]:
    nested = [r for r in m.facts.regions if getattr(r, "contains", None)]
    many = int(getattr(m.facts, "bodies", 1) or 1) > 1
    if not many and not nested:
        return [Finding("insert_named_vs_bodies", "internal_features", SILENT,
                        measured="one body, nothing nested",
                        note="a one-body file cannot contradict or confirm a named insert")]
    said = look.stance.get("verdict", "silent")
    measured = f"bodies={getattr(m.facts, 'bodies', 1)}, nested={len(nested)}"
    if said == "denies":
        return [Finding("insert_named_vs_bodies", "internal_features", CONTRADICT,
                        said="the passage is plain", measured=measured)]
    if said == "names":
        return [Finding("insert_named_vs_bodies", "internal_features", CONFIRM, said="names something inside",
                        measured=measured)]
    return [Finding("insert_named_vs_bodies", "internal_features", SILENT, said=said, measured=measured)]


# --- sharp_edges --------------------------------------------------------------------------------------------

@claim("sharp_edges",
       what="whether there is any sharp edge at all, and whether there is a knife edge",
       cannot="WHERE. `sharp_edge_count` is one number for the whole part, so `a sharp mouth rim` and `a sharp "
              "trailing edge` are the same evidence to the measurement. It can only contradict the extremes.",
       how="facts.features.sharp_edge_count and .knife_edge_count")
def sharp_edges_vs_counts(m: Measured, look: Look) -> list[Finding]:
    said = look.list_of("sharp_edges")
    f = m.facts.features
    out: list[Finding] = []
    if said and f.sharp_edge_count == 0:
        out.append(Finding("sharp_edges_vs_counts", "sharp_edges", CONTRADICT, said=f"{len(said)} named",
                           measured="sharp_edge_count = 0"))
    elif not said and f.sharp_edge_count > 0:
        out.append(Finding("sharp_edges_vs_counts", "sharp_edges", SILENT, said="none named",
                           measured=f"sharp_edge_count = {f.sharp_edge_count}",
                           note="a part with sharp edges may still have none worth naming: not a contradiction"))
    else:
        out.append(Finding("sharp_edges_vs_counts", "sharp_edges", CONFIRM, said=f"{len(said)} named",
                           measured=f"sharp_edge_count = {f.sharp_edge_count}"))
    knife_said = any(_SAYS_KNIFE.search(s) for s in said)
    if knife_said or f.knife_edge_count > 0:
        ok = knife_said == (f.knife_edge_count > 0)
        # which way round it went, because the two are not the same claim: naming a knife edge the measurement
        # cannot find is an assertion, and not naming one is only a denial by way of the prompt's "empty when
        # none". A reconciler should weigh them differently and cannot if they arrive in one number.
        subject = "knife" if ok else ("knife:look_named_none_measured" if knife_said
                                      else "knife:look_silent_measured")
        out.append(Finding("sharp_edges_vs_counts", "sharp_edges", CONFIRM if ok else CONTRADICT,
                           subject=subject, said="knife edge named" if knife_said else "no knife edge named",
                           measured=f"knife_edge_count = {f.knife_edge_count}"))
    return out


# --- attachments --------------------------------------------------------------------------------------------

@claim("attachments",
       what="almost nothing, and that is the finding. A flange is a collar around a mouth and the pipeline "
            "measures no such thing. The one reachable signal is a ring face concentric with a port.",
       cannot="a boss, a bracket, a lug, a stem or a mounting pad. None of them is measured. The look is 25 of "
              "25 on this field and the measurement cannot check a single one of those 25.",
       how="facts.openings of classification `ring` whose centroid sits within one hydraulic diameter of a "
           "port_candidate face")
def attachment_flange_vs_ring(m: Measured, look: Look) -> list[Finding]:
    said = look.list_of("attachments")
    flange = [s for s in said if re.search(r"\bflange\b|\bcollar\b", s, re.I)]
    rings = [o for o in m.facts.openings if o.classification == "ring"]
    ports = [o for o in m.facts.openings if o.classification == "port_candidate"]
    concentric = 0
    for r in rings:
        for p in ports:
            d = float(np.linalg.norm(np.asarray(r.centroid) - np.asarray(p.centroid)))
            if p.hydraulic_diameter and d <= p.hydraulic_diameter:
                concentric += 1
                break
    measured = f"{len(rings)} ring faces, {concentric} concentric with a port"
    out: list[Finding] = []
    if flange:
        out.append(Finding("attachment_flange_vs_ring", "attachments",
                           CONFIRM if concentric else (CONTRADICT if not rings else SILENT),
                           said=flange[0][:60], measured=measured,
                           note="" if rings else "the part has no ring face anywhere"))
    else:
        out.append(Finding("attachment_flange_vs_ring", "attachments", SILENT,
                           said=f"{len(said)} attachments named, none a flange", measured=measured,
                           note="no measurement of a boss, bracket, lug, stem or pad exists"))
    return out


# --- thin_parts ---------------------------------------------------------------------------------------------

@claim("thin_parts",
       what="whether the part has a thin region at all, in both directions",
       cannot="WHICH part is thin. `thin_clusters` carries a centroid, but the look says `a thin vane` and not "
              "a coordinate, so the two cannot be matched item by item. The two directions are NOT equally "
              "strong and `subject` names which one fired: the look naming a thin part the measurement cannot "
              "find is the look asserting something, and the look naming none while a cluster exists rests "
              "only on the prompt's `empty when none`.",
       how="facts.features.thin_clusters. `thickness_p05` over `thickness_median` was tried as a second "
           "signal and dropped: it fired on 20 parts with no cluster at all, most of them fluid domains where "
           "the thickness field is the passage width and a low ratio means the passage varies.")
def thin_parts_vs_clusters(m: Measured, look: Look) -> list[Finding]:
    said = look.list_of("thin_parts")
    f = m.facts.features
    clusters = len(f.thin_clusters)
    if f.thickness_median is None:
        return [Finding("thin_parts_vs_clusters", "thin_parts", SILENT, said=f"{len(said)} named",
                        measured="no thickness field measured on this part")]
    thin = clusters > 0
    direction = "" if bool(said) == thin else ("look_named_none_measured" if said else "look_silent_measured")
    return [Finding("thin_parts_vs_clusters", "thin_parts", CONFIRM if bool(said) == thin else CONTRADICT,
                    subject=direction, said=f"{len(said)} named", measured=f"{clusters} thin clusters")]


# --- defects ------------------------------------------------------------------------------------------------

@claim("defects",
       what="every defect class the look is asked for, because the loader already checks all of them",
       cannot="a defect the loader silently repaired before measuring. `drop_debris` removes stray components "
              "and reports the count, so that one is visible; a duplicate face merged by `clean_surface` is "
              "not. On this corpus the measurement says 316 of 316 files are clean, so every non-empty "
              "`defects` list is a contradiction here and the field is known to be wrong 3 to 5 times a pass.",
       how="facts.watertight, .features.non_manifold_edge_count, .winding_consistent, .debris_components, "
           ".bodies, .interfaces")
def defects_vs_file_health(m: Measured, look: Look) -> list[Finding]:
    said = look.list_of("defects")
    f, facts = m.facts.features, m.facts
    problems = []
    if not facts.watertight:
        problems.append("not watertight")
    if getattr(f, "non_manifold_edge_count", 0):
        problems.append(f"{f.non_manifold_edge_count} non-manifold edges")
    if not getattr(f, "winding_consistent", True):
        problems.append("inconsistent winding")
    if getattr(facts, "debris_components", 0):
        problems.append(f"{facts.debris_components} debris components")
    if any(getattr(i, "kind", "shared") == "coincident" for i in getattr(facts, "interfaces", [])):
        problems.append("coincident, unglued bodies")
    measured = ", ".join(problems) if problems else "watertight, manifold, consistent, no debris"
    verdict = CONFIRM if bool(said) == bool(problems) else CONTRADICT
    return [Finding("defects_vs_file_health", "defects", verdict, said=f"{len(said)} named: " + "; ".join(said)[:80],
                    measured=measured)]


# --- symmetry -----------------------------------------------------------------------------------------------

@claim("symmetry",
       what="mirror planes and rotational order, both of which the measurement computes",
       cannot="check WHICH plane when the look names one loosely, and cannot check `nearly symmetric except "
              "for X`. `symmetry_scores` is a score and not a yes, so a part just under the threshold is a "
              "contradiction here that is really a disagreement about where the line is.",
       how="facts.axes.symmetry_planes and .rotational_order")
def symmetry_vs_axes(m: Measured, look: Look) -> list[Finding]:
    text = look.text_of("symmetry")
    a = m.facts.axes
    if a.symmetry_planes is None or not getattr(a, "symmetry_measured", True):
        # the symmetry stage did not run (the time budget skipped it): nothing was measured to hold the look
        # against, and reading it as zero planes would contradict a look that says "mirror symmetric"
        return [Finding("symmetry_vs_axes", "symmetry", SILENT, said=text[:60], measured="not measured",
                        note="the symmetry stage did not run")]
    planes, order = len(a.symmetry_planes), a.rotational_order
    measured = f"{planes} mirror planes, rotational order {order}"
    if not text.strip() or (_UNSURE.search(text) and not _SAYS_MIRROR.search(text)):
        return [Finding("symmetry_vs_axes", "symmetry", SILENT, said=text[:60], measured=measured,
                        note="the look declined")]
    out: list[Finding] = []
    if _SAYS_NO_SYMMETRY.search(text) and not _SAYS_MIRROR.search(text) and not _SAYS_ROTATIONAL.search(text):
        out.append(Finding("symmetry_vs_axes", "symmetry", CONTRADICT if (planes or order) else CONFIRM,
                           subject="none", said="none apparent", measured=measured))
        return out
    if _SAYS_MIRROR.search(text):
        out.append(Finding("symmetry_vs_axes", "symmetry", CONFIRM if planes else CONTRADICT,
                           subject="mirror", said="mirror symmetric", measured=measured))
    if _SAYS_ROTATIONAL.search(text):
        out.append(Finding("symmetry_vs_axes", "symmetry", CONFIRM if order else CONTRADICT,
                           subject="rotational", said="rotationally symmetric", measured=measured))
    if not out:
        out.append(Finding("symmetry_vs_axes", "symmetry", SILENT, said=text[:60], measured=measured,
                           note="the prose names neither a mirror nor a rotation"))
    return out


# --- notes --------------------------------------------------------------------------------------------------

@claim("notes",
       what="nothing. It is free prose and carries no claim in a fixed form.",
       cannot="be checked. Its content is read by `stance` and scored under internal_features when it carries "
              "a claim about the passage; as a field it is silent.",
       how="not computable from geometry")
def notes_is_prose(m: Measured, look: Look) -> list[Finding]:
    return [Finding("notes_is_prose", "notes", SILENT, said=look.text_of("notes")[:60], note="free prose")]


# --- marks_seen ---------------------------------------------------------------------------------------------

@claim("marks_seen[]",
       what="whether the letter is standing on material or in empty space. The strongest checkable claim in "
            "the whole inventory: the renderer knows exactly what it drew the letter on top of.",
       cannot="say what the solid IS. The measurement has no word for whether it is a vane, a plug or a "
              "core, and it cannot speak at all where the representation is neither a wall shell nor a fluid "
              "domain, which is 63 of the 322 parts.",
       how="reconcile.profile.mark_is_solid over the mark kind from render.enclosed_regions, recorded per "
           "letter in `mark_places`. The kind means the OPPOSITE thing on a fluid domain and on a wall "
           "shell, and reading it without that table is worth 444 false contradictions on one draw.")
def mark_material_vs_kind(m: Measured, look: Look) -> list[Finding]:
    if not m.knows_marks:
        # THE SAME ABSENCE AS `opening_id_exists`'s, one record along. With no record of what the renderer drew,
        # `kinds` is empty and every lettered answer falls through to "no such letter was drawn", which reads a
        # missing measurement as an invented letter. Nothing here can be asked without the table.
        return [Finding("mark_material_vs_kind", "marks_seen[]", SILENT, subject=_letter_of(a) or "?",
                        said=re.sub(r"^\s*\(?[A-Za-z]\)?\s*[:.)\-]\s+", "", a)[:60],
                        note="nobody recorded which letters the renderer drew, so no letter can be checked "
                             "against the picture")
                for a in look.list_of("marks_seen")]
    kinds = {str(p.get("id")): str(p.get("kind")) for p in m.mark_places or ()}
    out: list[Finding] = []
    for answer in look.list_of("marks_seen"):
        letter = _letter_of(answer)
        kind = kinds.get(letter)
        body = re.sub(r"^\s*\(?[A-Za-z]\)?\s*[:.)\-]\s+", "", answer)
        if kind is None:
            out.append(Finding("mark_material_vs_kind", "marks_seen[]", CONTRADICT, subject=letter or "?",
                               said=body[:60], measured="no such letter was drawn"))
            continue
        if _UNSURE.search(body):
            out.append(Finding("mark_material_vs_kind", "marks_seen[]", SILENT, subject=letter, said=body[:60],
                               measured=kind, note="the look declined at this letter"))
            continue
        says_material = bool(_SAYS_MATERIAL.search(body))
        says_space = bool(_SAYS_SPACE.search(body))
        if says_material == says_space:
            out.append(Finding("mark_material_vs_kind", "marks_seen[]", SILENT, subject=letter, said=body[:60],
                               measured=kind, note="the answer names neither material nor space, or both"))
            continue
        is_material = mark_is_solid(kind, m.representation)
        if is_material is None:
            out.append(Finding("mark_material_vs_kind", "marks_seen[]", SILENT, subject=letter, said=body[:60],
                               measured=kind,
                               note=f"{m.representation}: the mark kind says nothing about solid or space"))
            continue
        verdict = CONFIRM if says_material == is_material else CONTRADICT
        out.append(Finding("mark_material_vs_kind", "marks_seen[]", verdict, subject=letter, said=body[:60],
                           measured=f"{kind} on a {m.representation}: "
                                    f"{'solid' if is_material else 'open space'}"))
    return out


# --- stops_seen ---------------------------------------------------------------------------------------------

@claim("stops_seen[]",
       what="whether the passage in the panel ends at a wall. Every panel drawn IS a stop by construction: the "
            "detector drew it because it found one.",
       cannot="be trusted where the detector is wrong. It is gated off fluid domains entirely, because there a "
              "closed end and a port face are the same geometry, so a contradiction here on a wall shell is "
              "the look's and a MISSING panel on a fluid domain is the measurement's.",
       how="vision.terminus.find_stops, recorded per part in `stopped`")
def stop_panel_vs_detector(m: Measured, look: Look) -> list[Finding]:
    answers = look.list_of("stops_seen")
    if not m.knows_stops:
        # "no stops view was drawn" is a MEASUREMENT, and with no record of what was drawn this claim does not
        # have it. Saying it anyway suppresses every stops answer on a part whose look block carries no `drawn`
        # table, which is every stored look taken before that table existed. This claim holds OVERRULES.
        return [Finding("stop_panel_vs_detector", "stops_seen[]", SILENT,
                        note="nobody recorded whether a stops view was drawn for this part")]
    if not m.stopped:
        if answers:
            return [Finding("stop_panel_vs_detector", "stops_seen[]", CONTRADICT,
                            said=f"{len(answers)} panels answered", measured="no stops view was drawn")]
        return [Finding("stop_panel_vs_detector", "stops_seen[]", SILENT,
                        note="no stops view was drawn for this part")]
    out: list[Finding] = []
    for i, oid in enumerate(m.stopped):
        if i >= len(answers):
            out.append(Finding("stop_panel_vs_detector", "stops_seen[]", SILENT, subject=oid,
                               measured="a stop", note="the look answered fewer panels than were drawn"))
            continue
        body = answers[i]
        if _UNSURE.search(body):
            out.append(Finding("stop_panel_vs_detector", "stops_seen[]", SILENT, subject=oid, said=body[:60],
                               measured="a stop", note="the look declined at this panel"))
            continue
        stops, goes = bool(_SAYS_STOPS.search(body)), bool(_SAYS_CONTINUES.search(body))
        if stops == goes:
            out.append(Finding("stop_panel_vs_detector", "stops_seen[]", SILENT, subject=oid, said=body[:60],
                               measured="a stop", note="the answer says neither"))
            continue
        out.append(Finding("stop_panel_vs_detector", "stops_seen[]", CONFIRM if stops else CONTRADICT,
                           subject=oid, said=body[:60], measured="a stop"))
    return out


# --- the abstention fields ------------------------------------------------------------------------------------

@claim("could_not_check / cannot_tell",
       what="nothing, by construction. An abstention makes no claim about the part.",
       cannot="be confirmed or contradicted. It is a routing signal for the reconciler and not a claim.",
       how="not computable from geometry")
def abstention_makes_no_claim(m: Measured, look: Look) -> list[Finding]:
    n = len(look.list_of("could_not_check")) + len(look.list_of("cannot_tell"))
    return [Finding("abstention_makes_no_claim", "could_not_check / cannot_tell", SILENT,
                    said=f"{n} abstentions", note="an abstention is not a claim")]


# ---------------------------------------------------------------------------------------------------------------
# running the table
# ---------------------------------------------------------------------------------------------------------------

#: WHAT EACH PROMPT ON RECORD DID NOT ASK FOR. A TABLE OF FACTS ABOUT PASSES ALREADY TAKEN, not a registry.
#:
#: `vision/prompt.py` held thirty-two named prompts until 2026-09-23 and this function rebuilt whichever one a
#: stored record named, to know which of its claims may be scored. Thirty-one of them are deleted and the text
#: cannot be rebuilt, but the records are still on disk and still name them, and the question they are asked is
#: about the pass rather than about the tree: WHAT DID THE PROMPT THAT PRODUCED THIS REPLY NOT ASK FOR.
#:
#: Returning nothing for a name this tree cannot build would be the wrong answer and not a missing one. Nothing
#: means "every field was asked", so `run_claims` would score a claim against a field the prompt never put, and
#: a field nobody asked about comes back empty, which reads as the look having searched and found nothing. That
#: is the failure this whole channel exists to stop.
#:
#: Computed from the registry at `27617667`, the last commit that had it, by
#: `not_asked(system_for(name))` for every name in `VARIANTS`. It is frozen: a pass taken under one of these
#: prompts will not change what that prompt asked.
HISTORIC_NOT_ASKED: dict[str, tuple[str, ...]] = {
    "calibrated": ("could_not_check", "cannot_tell", "marks_seen", "stops_seen", "walk"),
    "cannot_tell": ("could_not_check", "marks_seen", "stops_seen", "walk"),
    "capped": ("could_not_check", "cannot_tell", "marks_seen", "stops_seen", "walk"),
    "close": ("could_not_check", "cannot_tell", "stops_seen", "walk"),
    "count_openings": ("could_not_check", "cannot_tell", "marks_seen", "stops_seen", "walk"),
    "door_marks": ("cannot_tell", "stops_seen", "walk"),
    "door_plain": ("cannot_tell", "stops_seen", "walk"),
    "door_view": ("cannot_tell", "stops_seen", "walk"),
    "door_why": ("cannot_tell", "stops_seen", "walk"),
    "internals": ("could_not_check", "cannot_tell", "marks_seen", "stops_seen", "walk"),
    "lean": ("confidence", "orientation", "could_not_check", "defects", "cannot_tell", "marks_seen",
             "stops_seen", "walk"),
    "marks": ("could_not_check", "cannot_tell", "stops_seen", "walk"),
    "marks_quiet": ("could_not_check", "cannot_tell", "marks_seen", "stops_seen", "walk"),
    "marks_stops": ("could_not_check", "cannot_tell", "walk"),
    "no_orientation": ("orientation", "could_not_check", "cannot_tell", "marks_seen", "stops_seen", "walk"),
    "no_orientation_no_defects": ("orientation", "could_not_check", "defects", "cannot_tell", "marks_seen",
                                  "stops_seen", "walk"),
    "outside_in": ("could_not_check", "cannot_tell", "marks_seen", "stops_seen", "walk"),
    "panels": ("could_not_check", "cannot_tell", "stops_seen", "walk"),
    "panels_door": ("cannot_tell", "stops_seen", "walk"),
    "panels_stops": ("could_not_check", "cannot_tell", "walk"),
    "panels_swept": ("orientation", "could_not_check", "sharp_edges", "cannot_tell", "stops_seen", "walk",
                     "symmetry"),
    "panels_swept_two": ("orientation", "could_not_check", "cannot_tell", "stops_seen", "walk", "symmetry"),
    "placard": ("could_not_check", "cannot_tell", "walk"),
    "placard_key": ("could_not_check", "cannot_tell", "walk"),
    "roles_off": ("could_not_check", "cannot_tell", "marks_seen", "stops_seen", "walk"),
    "shortlist": ("could_not_check", "cannot_tell", "marks_seen", "stops_seen", "walk"),
    "stops": ("could_not_check", "cannot_tell", "marks_seen", "walk"),
    "swept": ("orientation", "could_not_check", "sharp_edges", "cannot_tell", "walk", "symmetry"),
    "swept_two": ("orientation", "could_not_check", "cannot_tell", "walk", "symmetry"),
    "v1": ("could_not_check", "cannot_tell", "marks_seen", "stops_seen", "walk"),
    "walk": ("could_not_check", "cannot_tell"),
    "walk_alone": ("could_not_check", "cannot_tell", "marks_seen"),
}


def not_asked_of(record: Any) -> tuple[str, ...]:
    """The fields the prompt behind a stored look never asked, from whatever the record carries: the look block's
    own `prompt.not_asked` (`vision.look`), else the bench record's `prompt_variant`. Empty when neither says, which
    is every record taken before the prompt could leave a field out, when every prompt asked every field.

    A `prompt_variant` is answered from the prompt in the tree when it is the one in the tree, and from
    `HISTORIC_NOT_ASKED` otherwise, for the reason that table writes out at length."""
    if not isinstance(record, dict):
        return ()
    prompt = record.get("prompt")
    if isinstance(prompt, dict) and isinstance(prompt.get("not_asked"), (list, tuple)):
        return tuple(str(f) for f in prompt["not_asked"])
    variant = record.get("prompt_variant")
    if isinstance(variant, str) and variant:
        from geometry_agent.vision import prompt as vp
        if variant == vp.VARIANT:
            return tuple(vp.not_asked(vp.SYSTEM))
        if variant == vp.WITHHELD_VARIANT:
            return tuple(vp.not_asked(vp._no_stops(vp.SYSTEM)))
        return HISTORIC_NOT_ASKED.get(variant, ())
    return ()


def _field_root(field_name: str) -> str:
    return field_name.split("[", 1)[0].split(" ", 1)[0].strip()


def run_claims(m: Measured, look: Look, only: Sequence[str] | None = None) -> list[Finding]:
    out: list[Finding] = []
    unasked = set(look.not_asked or ())
    for c in CLAIMS:
        if only and c["id"] not in only:
            continue
        if unasked and _field_root(c["field"]) in unasked:
            # never asked, so nothing was said: no finding at all, not SILENT with a reason the look did not give
            continue
        try:
            out += c["fn"](m, look)
        except Exception as exc:  # a claim that throws is a silent claim, and it says so rather than vanishing
            out.append(Finding(c["id"], c["field"], SILENT, note=f"claim raised {type(exc).__name__}: {exc}"))
    return out


def claim_table() -> list[dict[str, str]]:
    """The inventory itself: every claim, the field it is about, how it is computed and what it cannot do."""
    return [{"claim": c["id"], "field": c["field"], "what": c["what"], "how": c["how"], "cannot": c["cannot"]}
            for c in CLAIMS]
