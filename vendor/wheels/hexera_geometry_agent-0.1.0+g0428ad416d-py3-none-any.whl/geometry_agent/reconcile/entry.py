"""The cross-section curve read inward from EACH MOUTH along that mouth's own normal.

WHY THIS EXISTS AND WHY IT IS NOT THE GLOBAL PROFILE. `profile.flow_profile` cuts 41 stations across ONE fitted
axis, `render.flow_axis`, which is the principal direction of the labelled mouths. That axis is the flow path
only on a part whose mouths lie on a line. The headline case of this round is a diffuser-fed plenum, which has
one inlet stub and one or two outlet stubs at varied angles, so its three mouths do not lie on a line, the
fitted axis is a chord through them, and the cut plane leaves the bore in the middle: measured on
`diffuser_plenum_001` the global flow profile reads 0.00 at five interior stations on a part with nothing in
it at all. `profile.axis_trust` already refuses that part, correctly and unhelpfully.

A MOUTH NORMAL IS A MEASURED FACT AND IT IS LOCAL. It needs no fit, it is right on a tee and on a manifold as
much as on a straight pipe, and it points down the passage that mouth opens into for as far as that passage
runs straight. So the question this file asks is not "what shape is the part" but "what does the passage do as
you go in at this mouth", once per mouth, and a branched part gets one answer per branch instead of one
meaningless answer for the whole.

WHAT THE NUMBER IS, said precisely because it is NOT the flow area. At each station the plane cuts the surface
and `stubs._section` sums the areas of the closed loops whose centroids lie within 1.5 diameters of the march
point. On a fluid domain that is the passage's own cross-section. On a wall shell it is the outer loop plus
the inner loop of the wall, which is about twice the bore and not the bore. Either way it is MONOTONE in the
size of the passage: a bore that halves halves both loops. This file only ever reads the curve's SHAPE, never
its level, so a constant factor between a shell and a fluid domain cancels and there is no representation
table here to get the sign of. That is deliberate: the representation sign error cost `profile.py` a rewrite
and 444 false contradictions, and a shape reading that does not need the sign cannot make it.

WHAT IT REFUSES. `run_at` returns a run with `kind="unreadable"` and a reason rather than a shape whenever the
march cannot follow one passage: no section at the mouth, fewer than `MIN_STATIONS` stations before the
passage stops being itself, or a mouth whose inward direction cannot be found. A measured fact that lies is
worse than a missing one, so every one of those is a refusal and never a "straight".

WHY THIS IS NOT `facts.stubs`. `stubs.measure_stub` marches the same way and stops at the FIRST station whose
area differs from the entry by more than `AREA_TOL`, recording `terminated_by="area_change"`. On a conical
stub that is the second station, so the stub's length is 0.33 diameters and the cone it is a cone OF lies
entirely outside what the stub measured. The stub answers "how long is the straight run"; this answers "and
then what", and the direction of that change is the whole of the diffuser row.

WHERE THIS STOPS AND `facts/centreline.py` TAKES OVER. This march goes straight down the mouth's normal, which is
right for a stub and leaves the bore at the first bend. The builder-facing reading of the same question is the
centreline march in `facts/coverage.py`: it follows the passage through a bend at the plane of least section
area, and its taper places carry the included angle, so the diffuser reaches the typed block with a number the
builder can use. This file stays what the reconciler reads the look against, and it is unchanged, so the
diffuser row it scored (14 of 14) is the same row.

Nothing here reads a brief, a family, a file name, a declared role or an answer key.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np

#: How far apart the stations are, in mouth diameters, and how far in the march may go. The step is the one
#: `stubs.STEP_OVER_D` uses so a station here and a station there are the same place; the reach is shorter
#: than `stubs.MAX_MARCH_OVER_D` because a feature at the mouth is what this file is for and a passage that
#: has run eight diameters without changing is a straight pipe whatever it does later.
STEP_OVER_D = 0.25
MAX_OVER_D = 8.0
#: The loops whose centroid counts, in mouth diameters. `stubs.NEAR_RADIUS_OVER_D`, unchanged.
NEAR_RADIUS_OVER_D = 1.5
#: One step of this factor or more is a DISCONTINUITY, not a taper: the plane has met something that is not
#: the passage it was following (a chamber wall, a branch, the far side of a plenum). The march stops there
#: and the curve before it is what gets read. 1.6 in area is 1.26 in diameter, which is larger than any one
#: step of a cone that takes four steps to double.
JUMP = 1.6
#: A step that changes the section by less than this is FLAT. Tessellation and the plane landing on a B-rep
#: face move the loop sum by a few parts in a thousand on a truly cylindrical stub.
FLAT_STEP = 1.02
#: How much the section has to change across the whole run before the run is a taper rather than a straight
#: pipe with a blend at the end of it. In area: 1.30 is 1.14 in diameter.
TAPER_RATIO = 1.30
#: What fraction of the run's steps have to move the same way for the change to be a TAPER and not a blend.
#: THE NUMBER THIS RULE EXISTS FOR, and it is the whole difference between the inlet and the outlets of a
#: diffuser-fed plenum. On `diffuser_plenum_001` the three stubs read, inward from the mouth:
#:   o1  1.66 1.66 1.66 2.09 |  one step of four moves          -> straight, and the brief calls it cylindrical
#:   o2  1.84 2.09 2.35 2.62 2.91 3.23 |  five of five move     -> widens,   and the brief calls it the cone
#:   o3  1.51 1.52 1.52 1.52 2.01 |  one step of four moves     -> straight, and the brief calls it cylindrical
#: Without this rule o3's single 1.33 step at the fillet where the stub meets the chamber reads as a taper and
#: every outlet in the family becomes a diffuser. The total ratio alone cannot tell a cone from a fillet; how
#: many stations the change is spread over can.
#:
#: MOVED FROM 0.6 TO 0.8 BY THE INTEGRATOR, on three numbers and with the one that could not decide it named.
#: 0.6 was committed at `ff128753`, before any scorer existed (`1a7094a2`), so it had never been chosen against
#: a number at all; the author of the sweep measured 0.8 and left the move, because both of the columns they
#: had are the diffuser row's own.
#:   `eval/vision/results/form/sensitivity.md`  the row is 14 of 14 at both, the mouth named is the declared
#:                                             inlet on 13 at both, wrong place 0 at both, and EXTRA mouths
#:                                             called cones on those same 14 parts goes 1 to 0
#:   the corpus-wide control, which is the held-out column: the pattern fires on 53 of the 308 parts whose
#:                                             brief names no diffuser at 0.6 and on 24 at 0.8. Those 308 are
#:                                             out of sample for a threshold chosen on the 14
#:   `eval/vision/results/joint/sweep.md`      the DOCUMENT is identical on all four draws, 5961 5985 6022
#:                                             5971 either way. It could not decide this and does not pretend
#:                                             to: 40 parts lose a shape line at 0.8 and not one statement
#:                                             changes, because those lines say what the document already says
#: So: nothing measured gets worse, one measured column gets better, and the corpus-wide firings halve. The
#: reason that last one matters is the sweep author's own hand check of 20 of the 110 statements the judge
#: cannot settle: 12 true, 3 wrong, 5 unsettleable. About one in seven of that tail is wrong and no table sees
#: it, so halving the tail is the strongest thing either number says.
SUSTAINED = 0.8
#: Below this many stations there is no curve to read a shape off and the answer is a refusal.
MIN_STATIONS = 4
#: How far behind a degenerate station is retried, as a fraction of the step. `stubs.STATION_NUDGE`.
STATION_NUDGE = 0.01
#: How much of the run's own largest section a valley has to stand clear of before it is a THROAT, and a peak
#: before it is a bulge. Taken from `profile.DIP_FRACTION`, which is where this project argued the level, so
#: the two channels call the same narrowing a restriction or do not.
DIP = 0.20


@dataclass
class MouthRun:
    """What the passage does as you go in at one mouth.

    `kind` is one of `widens`, `narrows`, `straight`, `unreadable`. `ratio` is the section at the last station
    the march kept over the section at the first, so it is above one when the passage opens out. `stations` is
    how many were kept and `stopped_by` says what ended the march, which is as much of the finding as the
    shape is: a stub that stops on a JUMP has run into something, and a stub that stops at `max_reach` has
    not."""
    opening_id: str
    kind: str
    ratio: float = 1.0
    stations: int = 0
    length_over_d: float = 0.0
    stopped_by: str = ""
    why_not: str = ""
    #: The section at each kept station, in units of the mouth's own area. Kept so a reader can argue with the
    #: shape rather than take it.
    curve: list[float] = field(default_factory=list)
    #: The fraction of steps that moved the same way as the whole run. Below `SUSTAINED` the change is a blend
    #: at one station and not a taper.
    sustained: float = 0.0
    #: How many loops the plane cut at the first kept station. More than one on a fluid domain means the mouth
    #: opens onto more than one passage, which is a mouth this file cannot speak for.
    entry_loops: int = 0
    #: The typical section of each stretch the march crossed, in order, one number per stretch between two
    #: discontinuities. THE SECOND HALF OF THE READING, and without it a plate is invisible: an orifice run is
    #: constant for thirteen stations, drops in one step, is constant again and comes back, so the first
    #: stretch alone says `straight` and is right about the stretch and wrong about the part. `notch` and
    #: `step` are read off this list and not off `curve`.
    levels: list[float] = field(default_factory=list)
    #: `notch`, `step_down`, `step_up` or "": what the sequence of levels does beyond the first stretch.
    beyond: str = ""
    #: Whether the march ever crossed a plane where the number of section loops changed, which is a plane that
    #: met a second passage. `beyond` is forced empty when it did.
    crossed_a_branch: bool = False

    @property
    def readable(self) -> bool:
        return self.kind != "unreadable"

    def as_dict(self) -> dict[str, Any]:
        return {"opening_id": self.opening_id, "kind": self.kind, "ratio": round(self.ratio, 4),
                "stations": self.stations, "length_over_d": round(self.length_over_d, 3),
                "stopped_by": self.stopped_by, "why_not": self.why_not, "sustained": round(self.sustained, 3),
                "entry_loops": self.entry_loops, "beyond": self.beyond,
                "crossed_a_branch": self.crossed_a_branch,
                "levels": [round(x, 4) for x in self.levels], "curve": [round(x, 4) for x in self.curve]}


def _prominence(curve: np.ndarray) -> tuple[float, int, float, int]:
    """`(valley depth, valley index, peak height, peak index)`, each as a fraction of the curve's own largest.

    Prominence and not depth, for the reason `profile.FlowProfile.dip` writes out at length: the narrowest
    station of a reducer is its small end, and reading depth calls every reducer a throat. A valley's
    prominence is the smaller of the highest value before it and the highest after it, less its own, so a
    passage that narrows and never recovers has a prominence of zero and a passage that narrows and opens out
    again does not."""
    peak = float(curve.max()) or 1.0
    before = np.maximum.accumulate(curve)
    after = np.maximum.accumulate(curve[::-1])[::-1]
    valley = (np.minimum(before, after) - curve) / peak
    # the same reading for a PEAK: a station stands clear of the higher of the two floors either side of it,
    # so a run that only grows has a ridge of zero and a bulge does not
    ridge = (curve - np.maximum(np.minimum.accumulate(curve), np.minimum.accumulate(curve[::-1])[::-1])) / peak
    inner = np.zeros(len(curve), dtype=bool)
    inner[1:-1] = True
    if not inner.any():
        return 0.0, 0, 0.0, 0
    vi = int(np.argmax(np.where(inner, valley, -np.inf)))
    pi = int(np.argmax(np.where(inner, ridge, -np.inf)))

    return float(valley[vi]), vi, float(ridge[pi]), pi


def _beyond(levels: list[float]) -> str:
    """What the sequence of stretch levels does past the first one: `notch`, `step_down`, `step_up` or "".

    A NOTCH is a level that stands below both a level before it and a level after it by `DIP` of the largest.
    That is an orifice plate, a short throat with square shoulders, a segmental baffle: the passage shuts down
    to a fraction of itself and opens out again. A STEP is a single discontinuity that never comes back, which
    is a pipe meeting a larger pipe or a stub meeting a chamber, and it is a different finding.

    Read on the LEVELS and not on the stations, so a plate one station thick and a plate four stations thick
    are one notch and not one notch and four steps."""
    if len(levels) < 2:
        return ""
    arr = np.asarray(levels, dtype=np.float64)
    top = float(arr.max()) or 1.0
    for i in range(1, len(arr) - 1):
        if (min(float(arr[:i].max()), float(arr[i + 1:].max())) - float(arr[i])) / top >= DIP:
            return "notch"
    first, last = float(arr[0]), float(arr[-1])
    if first <= 0:
        return ""
    if last / first >= 1.0 + DIP:
        return "step_up"
    if last / first <= 1.0 - DIP:
        return "step_down"
    return ""


def _classify(curve: list[float]) -> tuple[str, float, float]:
    """`(kind, ratio, sustained)` for a kept run. Shape only; the level is never read.

    FIVE SHAPES AND THE ORDER MATTERS. A valley beats a ramp beats flat, because a venturi read off its two
    ends alone comes back `straight`: its run starts and finishes at the full bore and the whole part is in
    the middle. That is the same mistake as reading a diffuser off a single endpoint ratio and it is caught
    here rather than in the reconciler."""
    if len(curve) < MIN_STATIONS:
        return "unreadable", 1.0, 0.0
    arr = np.asarray(curve, dtype=np.float64)
    first, last = float(arr[0]), float(arr[-1])
    if first <= 0 or not np.isfinite(arr).all():
        return "unreadable", 1.0, 0.0
    ratio = last / first
    steps = [b / a for a, b in zip(curve, curve[1:]) if a > 0]
    if not steps:
        return "unreadable", 1.0, 0.0
    want_up = ratio > 1.0
    moved = sum(1 for s in steps if (s > FLAT_STEP if want_up else s < 1.0 / FLAT_STEP))
    sustained = moved / len(steps)
    valley, _vi, ridge, _pi = _prominence(arr)
    if valley >= DIP:
        return "waist", ratio, sustained
    if ridge >= DIP:
        return "bulge", ratio, sustained
    if ratio >= TAPER_RATIO and sustained >= SUSTAINED:
        return "widens", ratio, sustained
    if ratio <= 1.0 / TAPER_RATIO and sustained >= SUSTAINED:
        return "narrows", ratio, sustained
    return "straight", ratio, sustained


def run_at(mesh, opening, corridor=None, step: float = STEP_OVER_D) -> MouthRun:
    """The inward curve at one mouth, and what shape it is.

    `mesh` is the region mesh the opening belongs to, as `stubs.measure_stubs` picks it. Every geometric
    choice is `stubs`': the same inward test, the same near radius, the same plane cut, so a station here and
    a station in the stub march are the same plane through the same surface.
    """
    from geometry_agent.facts.stubs import _chain_tol, _inward, _march_corridor, _section

    oid = str(opening.id)
    area0 = float(opening.area or 0.0)
    if area0 <= 0:
        return MouthRun(oid, "unreadable", why_not="the mouth has no area")
    local = _march_corridor(mesh, opening, corridor)
    d = max(float(opening.hydraulic_diameter), 1e-9)
    direction = _inward(local, opening)
    c0 = np.asarray(opening.centroid, dtype=float)
    radius = NEAR_RADIUS_OVER_D * d
    span = float(step)
    _chain_tol(local)  # warms trimesh's extent cache once rather than once a station
    curve: list[float] = []
    loops_first = 0
    stopped = "max_reach"
    k = span

    def probe(at: float) -> tuple[int, float]:
        """One station, retried a hair behind if the plane landed flat on a face.

        `stubs.STATION_NUDGE` exists for the same reason and this is the same rule: a plane that falls exactly
        on a B-rep wall cuts open chains instead of a loop, and reading that as the end of the passage ends a
        march in the middle of a straight pipe. Measured: without the retry the march on
        `diffuser_plenum_001` stopped after two stations at a step of 0.125 diameters and after six at 0.25,
        so the shape it read was a property of where the stations happened to land."""
        loops, area, _cen, _total = _section(local, c0 + at * d * direction, direction, radius)
        if loops == 0 or area <= 0:
            loops, area, _cen, _total = _section(local, c0 + (at - STATION_NUDGE * span) * d * direction,
                                                 direction, radius)
        return int(loops), float(area)

    # The march does not stop at a discontinuity, it RECORDS one and carries on. Every stretch between two
    # discontinuities is a place where the section is one thing; `curve` is the first of them, which is the
    # passage the mouth actually opens into, and `stretches` is all of them, which is what the passage does
    # further in. Stopping at the first jump was the earlier rule and it made an orifice plate unreadable:
    # the plate IS the jump, so the march ended in front of it every time and reported a plain pipe.
    stretches: list[list[float]] = [[]]
    crossed_a_branch = False
    prev = 0.0
    prev_loops = 0
    while k <= MAX_OVER_D + 1e-9:
        loops, area = probe(k)
        if loops == 0 or area <= 0:
            # `stopped_by` says what ended the FIRST stretch, which is the passage the mouth opens into. A
            # march that reached the end of the body while still in that stretch ended there, and reporting
            # `max_reach` for it was a wrong recorded fact even though nothing read it.
            stopped = "end_of_body" if len(stretches) == 1 else stopped
            break
        value = area / area0
        by_area = bool(stretches[-1]) and (value / prev >= JUMP or value / prev <= 1.0 / JUMP)
        by_loops = bool(stretches[-1]) and loops != prev_loops
        if by_area or by_loops:
            crossed_a_branch = crossed_a_branch or by_loops
            stretches.append([])
            if len(stretches) == 2:
                stopped = "jump" if by_area else "loop_count_changed"
        if not stretches[-1] and len(stretches) == 1:
            loops_first = loops
        stretches[-1].append(value)
        prev, prev_loops = value, loops
        k += span
    curve = stretches[0]
    levels = [float(np.median(s)) for s in stretches if s]
    # THE BRANCH REFUSAL, and it is the per-mouth twin of the axis gate. A stretch boundary where the number
    # of loops changed is a plane that has met a SECOND passage: a header's branch stub, a tee's leg, the
    # far wall of a chamber. The section either side of that boundary is the section of two different things,
    # so the drop between them is not a restriction and the rise is not a step. Measured on the corpus before
    # this gate existed: `manifold` reported 46 notches and `tee_wye` 7, every one of them a branch opening
    # being read as a plate in the run. `beyond` says nothing once a branch has been crossed.
    beyond = "" if crossed_a_branch else _beyond(levels)
    if len(curve) < MIN_STATIONS:
        return MouthRun(oid, "unreadable", stations=len(curve), stopped_by=stopped, curve=curve,
                        entry_loops=loops_first, levels=levels, beyond=beyond,
                        crossed_a_branch=crossed_a_branch,
                        why_not=f"only {len(curve)} stations before the march stopped ({stopped})")
    kind, ratio, sustained = _classify(curve)
    return MouthRun(oid, kind, ratio=ratio, stations=len(curve),
                    length_over_d=span * len(curve), stopped_by=stopped, curve=curve,
                    sustained=sustained, entry_loops=loops_first, levels=levels, beyond=beyond,
                    crossed_a_branch=crossed_a_branch)


def mouth_runs(mesh, facts, max_openings: int = 12, step: float = STEP_OVER_D) -> list[MouthRun]:
    """One run per opening, in the order the measurement lists them.

    The corridor is precomputed per region exactly as `stubs.measure_stubs` does it, because cutting a plane
    through a whole body once a station is the difference between seconds and minutes on a large part.
    """
    from geometry_agent.facts.regions import region_meshes
    from geometry_agent.facts.stubs import _corridor_faces

    parts = region_meshes(mesh)
    todo = list(facts.openings)[:max_openings]
    by_region: dict[int, list] = {}
    for o in todo:
        idx = int(str(o.region_id)[1:]) - 1
        by_region.setdefault(idx if 0 <= idx < len(parts) else -1, []).append(o)
    out: dict[str, MouthRun] = {}
    for idx, group in by_region.items():
        part = parts[idx] if idx >= 0 else mesh
        try:
            corridors = _corridor_faces(np.asarray(part.triangles_center), group)
        except (ValueError, AttributeError, MemoryError):
            corridors = [None] * len(group)
        for o, corridor in zip(group, corridors):
            try:
                out[str(o.id)] = run_at(part, o, corridor, step)
            except Exception as exc:  # a march that raises is a refusal, never a shape
                out[str(o.id)] = MouthRun(str(o.id), "unreadable", why_not=f"{type(exc).__name__}: {exc}"[:120])
    return [out[str(o.id)] for o in todo if str(o.id) in out]
