"""CUTTING A REPLY INTO THE PIECES A NEGATION CAN REACH ACROSS, on the shipping path.

WHY THIS FILE EXISTS, and it is not a tidy-up. `reconcile.inventory.Look.segments` and every monitor signal
that reads a lettered answer take the segmenter as an INJECTED function, for the reason those files give: the
project has one hand-built splitter for negation and a second copy of it would be a second blind spot. The
splitter was `eval/vision/meaning.segments`, and `eval/` is not importable from `src/`. So on the shipping path
the injection was never made, and `read_mark_answer` fell back to reading the whole string, which is
negation-blind.

WHAT THAT FALLBACK COSTS, measured on the committed corpus rather than argued. 322 parts, four cached draws, no
model call: with the hand-built splitter injected, `inside_a_body_with_no_interior` fires on 0 parts on every draw
and `mark_read_against_the_picture` on 0. With the fallback they fire on 3 and 6, 1 and 4, 2 and 3, and 2 and 7,
so 9, 5, 5 and 9 firings a draw that the splitter's owner measured at zero. Both signals are WITHHOLD tier, so
every one of those is a finding taken OUT of the document because a negation was read as an assertion, and
`inside_a_body_with_no_interior`'s own docstring pins its zero as the finding. A reader that breaks the property
its owner measured is not a degraded reader, it is a wrong one.

SO THIS FILE IS THE SPLITTER, UNDER `src/`, AND IT IS THE SAME SPLITTER. `clauses` and `segments` are
`eval/vision/meaning.py`'s, brought over whole: the same regexes, the same carry rules, the same output dicts.
It is not a rewrite and it is not a simplification, because the value of this reader is entirely in which
phrasings its patterns were built from, and none of that was written here.

THE DUPLICATE IS CLOSED BY A MEASUREMENT AND NOT BY A PROMISE. `tests/test_reconcile_phrasing.py` runs this
module and `eval/vision/meaning.py` over every clause of all 1,288 cached replies and asserts the outputs are
equal, key for key. If either side drifts, that test fails on the corpus rather than in production. Making
`eval/vision/meaning.py` import from here, so there is one copy and not two agreeing copies, is a change to a
file this branch does not own and is listed as a NEEDS FROM OTHERS.

NOTHING HERE READS A BRIEF, A FAMILY, A CASE ROW OR ANY OTHER ANSWER KEY. It takes a string and returns its
pieces. That is the whole interface, and `test_reconcile_phrasing.py` pins that this module imports nothing
but `re`.
"""

from __future__ import annotations

import re
from typing import Any

# ---------------------------------------------------------------------------------------------------------------
# the patterns, from eval/vision/meaning.py, with the comments that say what each one was written for
# ---------------------------------------------------------------------------------------------------------------

#: A sentence break. `internal_features` entries are usually one clause each; `notes` is where the sentences are.
_SENTENCE = re.compile(r"(?<=[.;])\s+")
#: Inside a clause, the places a new assertion can start. The connector is kept, because it is the connector
#: that says whether the next piece continues the one before it: a comma continues a list ("no baffles, vanes,
#: plugs"), and "with" or "around" starts something new ("no baffles are visible around the central core").
_SEGMENT = re.compile(r"\s*(,|;|\band\b|\bor\b|\bbut\b|\bwith\b|\baround\b|\bsurrounding\b|\bcontaining\b"
                      r"|\bexcept\b|\bapart from\b|\baside from\b|\bother than\b|\bbeyond\b|\bwhile\b"
                      r"|\brather than\b|\binstead of\b|\bas opposed to\b|\bnot just\b)\s*")
#: A connector that starts a new assertion: what follows does not inherit the negation before it.
_BREAKS_SCOPE = re.compile(r"^(?:with|around|surrounding|containing|but|except|apart from|aside from|"
                           r"other than|beyond|while)$")
#: A connector introducing what the part is NOT. "the flow path is annular rather than a plain bore" names the
#: annulus; read without this its tail would be a claim that the bore is plain.
_CONTRAST_CONNECTOR = re.compile(r"^(?:rather than|instead of|as opposed to|not just)$")
#: The same idea inside one segment, where there is no connector to read it off.
_CONTRAST = re.compile(r"\bnot (?:a |an |the )?plain\b|\bnot only\b|\brather than\b|\binstead of\b")
#: The words that put a segment in the negative.
NEGATION = re.compile(r"\bno\b|\bnot\b|\bnone\b|\bnothing\b|\bnor\b|\bneither\b|\bwithout\b|\bfree of\b"
                      r"|\babsence of\b|\bdevoid of\b|\blacks?\b|\blacking\b|\bunobstructed\b|\buninterrupted\b"
                      r"|\bfeatureless\b|\bclear of\b|\bempty of\b|\bnever\b")
#: The half of those that take the thing away, as opposed to the adjectives that describe it. "no baffle" leaves
#: no baffle behind; "an unobstructed flow path" leaves a flow path.
VERBAL_NEGATION = re.compile(r"\bno\b|\bnot\b|\bnone\b|\bnothing\b|\bnor\b|\bneither\b|\bwithout\b|\blacks?\b"
                             r"|\blacking\b|\bdevoid of\b|\babsence of\b|\bfree of\b|\bempty of\b|\bnever\b")


def clauses(text: str) -> list[str]:
    """One clause per sentence of a field entry, lower cased."""
    return [c.strip() for c in _SENTENCE.split(str(text or "").lower()) if c.strip()]


def segments(clause: str) -> list[dict[str, Any]]:
    """A clause cut into segments, each marked negated or not and each marked contrastive or not.

    The negation carries forward across a segment boundary that is only a list comma, which is what makes
    "no baffles, vanes, plugs, or internal obstructions are visible" one negated statement and not one negated
    segment followed by three assertions that a vane, a plug and an obstruction are there.
    """
    parts = _SEGMENT.split(clause)
    out: list[dict[str, Any]] = []
    carried_negation = carried_contrast = carried_verbal = False
    for i in range(0, len(parts), 2):
        piece = parts[i].strip()
        connector = parts[i - 1].strip() if i else ""
        if not piece:
            continue
        own_negation = bool(NEGATION.search(piece))
        own_contrast = bool(_CONTRAST.search(piece)) or bool(_CONTRAST_CONNECTOR.match(connector))
        if own_contrast:
            carried_negation, carried_contrast, carried_verbal = False, True, False
        elif own_negation:
            carried_negation, carried_contrast = True, False
            carried_verbal = bool(VERBAL_NEGATION.search(piece))
        elif _BREAKS_SCOPE.match(connector):
            carried_negation = carried_contrast = carried_verbal = False
        negated = own_negation or carried_negation
        out.append({"text": piece, "negated": negated, "contrast": own_contrast or carried_contrast,
                    "verbal": negated and carried_verbal})
    return out


__all__ = ["NEGATION", "VERBAL_NEGATION", "clauses", "segments"]
