"""What survives step 4, in the shape step 5 already reads.

`verdict.py` decides. This file does the surgery and assembles the block: the impression with the suppressed
claims taken out, the disagreements written down, the one question, and the places the measurement had all
along.

THE UNIT OF SUPPRESSION IS THE CLAIM, NOT THE FIELD, and that is the difference between a reconciler and a
censor. A reply that says "the bore runs straight through with nothing in it, and the wall is thin at the far
shoulder" carries one claim the measurement contradicts and one it does not. Removing `notes` removes both.
`DROPS` below says, per claim, exactly what comes out: a value, one item of a list, one key of one opening's
record, or one sentence of a string. A sentence removed leaves the rest of the string intact.

WHY THE SENTENCE AND NOT THE FIELD, measured rather than assumed. The look overflows `impression_line`'s 300
character cap on 322 of 322 parts, so what reaches a reader is the head of a line; the denial that causes the
harm is one clause of it and the true statements around it are the rest. `eval/vision/reconcile.py` prints the
true-statement and false-statement columns separately for exactly this reason, because a suppression that took
the field would look identical on a count of contradictions and be much worse on the document.

THE BLOCK IS ADDITIVE TO THE SCHEMA AND DESTRUCTIVE TO NOTHING. `reconciled()` returns a NEW impression; the
reply as it arrived is untouched and is what `disagreements` quotes, so the record of what the model said
survives its own suppression. `vision.trust`'s three tiers still decide what a consumer may do, with one
change this module is entitled to make: a candidate the measurement confirmed is relied on, because that is
what the tier is defined as waiting for.
"""
from __future__ import annotations

import re
from typing import Any

from geometry_agent.reconcile.verdict import (
    CONFIRMED,
    DISPUTED,
    RECONCILE_SCHEMA,
    SUPPRESSED,
    Reconciliation,
    question,
)
from geometry_agent.vision import trust

#: Sentence boundary. Deliberately dull: a full stop, a semicolon or a newline, and never a decimal point,
#: because every digit was scrubbed before the reply was stored and a lone full stop between two letters is a
#: sentence end here. Pinned by `test_taking_nothing_out_returns_the_same_words`.
_SENTENCE = re.compile(r"(?<=[.;])\s+|\n+")

#: WHAT COMES OUT WHEN A CLAIM IS SUPPRESSED.
#:
#:   value     the field's own value goes, and the field is left empty
#:   item      the one list item the finding is about goes, the rest of the list stays
#:   opening   one KEY of one opening's record goes, named by `key`; the opening entry stays
#:   entry     the whole opening entry goes, because the opening itself is not there
#:   denial    every sentence the injected denial detector flagged goes, wherever in the reply it is written
#:
#: `denial` is the only one that crosses fields, and it has to: `stance.units` reads every string at any depth
#: under any key, so the sentence asserting the passage is empty can be in `internal_features`, in `notes`, in
#: a mark answer or in a field invented tomorrow. Removing it from `internal_features` alone would leave the
#: same assertion in the document under another label, which is the format-dependence this project has already
#: had to fix twice.
DROPS: dict[str, dict[str, str]] = {
    "looks_like_kind_of_file": {"how": "value", "field": "looks_like"},
    "orientation_long_axis": {"how": "value", "field": "orientation"},
    "opening_id_exists": {"how": "entry"},
    "opening_looks_like_vs_class": {"how": "opening", "key": "looks_like"},
    "opening_role_not_a_port": {"how": "opening", "key": "likely_role"},
    "passage_plain_vs_profile": {"how": "denial"},
    "passage_plain_vs_body_marks": {"how": "denial"},
    "insert_named_vs_bodies": {"how": "denial"},
    #: `word` is `value` narrowed to the items that carry the word the disagreement is about. The claim
    #: returns TWO findings and they are not the same claim: one is "you named sharp edges and this mesh has
    #: none", which takes the field, and one is "you named a KNIFE edge and the knife count is zero", which
    #: takes only the items that say knife. Taking the field for the second would destroy every true sharp-edge
    #: statement on the part to remove one word.
    "sharp_edges_vs_counts": {"how": "value", "field": "sharp_edges",
                              "when_subject": "knife:look_named_none_measured",
                              "then": "word", "word": "knife"},
    "defects_vs_file_health": {"how": "value", "field": "defects"},
    "stop_panel_vs_detector": {"how": "item", "field": "stops_seen"},
}


def _sentences(text: str) -> list[str]:
    return [s for s in (p.strip() for p in _SENTENCE.split(text)) if s]


def _norm(text: str) -> str:
    return re.sub(r"[^a-z0-9 ]+", " ", str(text).lower()).strip()


def _without(text: str, clauses: list[str]) -> str:
    """One string with the flagged sentences taken out and the rest left exactly as written."""
    keep = [s for s in _sentences(text) if not any(c and c in _norm(s) for c in clauses)]
    return " ".join(keep)


#: An opening id, recognised by its own shape. Used to spot a record that describes a MOUTH.
_OPENING_ID = re.compile(r"o\d{1,3}")


def _is_a_mouth_record(node: dict) -> bool:
    """Whether this dict is one opening's record, decided from its VALUES and never from its keys.

    WHY THIS EXISTS, and it is a bug I shipped and measured rather than one I reasoned my way out of. The
    injected denial detector reads every string at any depth, so `likely_role: "not a port"` becomes a clause
    and `asserts_empty` flags it. On one part that cost five TRUE `not_a_port` statements: the surgery removed
    a role the look was right about, because a detector built to answer "does this reply say the passage is
    empty" was being asked "is this sentence a denial", which is not the same question and is not what its
    hand check covers.

    A CLAIM ABOUT A MOUTH IS NOT A CLAIM ABOUT WHAT IS IN THE PASSAGE. A mark letter is a place inside the
    passage and its answers stay strippable; an opening is the way in and out, and "not a port" said about one
    is about that mouth. The test is on content, matching `document.walk_strings`'s own place-record rule,
    which the metric agent reached separately for the same reason.
    """
    return any(isinstance(v, str) and _OPENING_ID.fullmatch(v.strip()) for v in node.values())


def _strip_denials(node: Any, clauses: list[str]) -> Any:
    """Every string anywhere in the reply, with the flagged sentences removed. Keys are never consulted."""
    if isinstance(node, str):
        return _without(node, clauses)
    if isinstance(node, dict):
        if _is_a_mouth_record(node):
            return node
        return {k: _strip_denials(v, clauses) for k, v in node.items()}
    if isinstance(node, (list, tuple)):
        out = [_strip_denials(v, clauses) for v in node]
        return [v for v in out if not (isinstance(v, str) and not v.strip())]
    return node


def reconciled(impression: dict[str, Any], r: Reconciliation) -> dict[str, Any]:
    """The impression with every suppressed claim removed and nothing else changed."""
    out: dict[str, Any] = {k: (list(v) if isinstance(v, list) else v) for k, v in (impression or {}).items()}
    suppressed = r.of(SUPPRESSED)
    if not suppressed:
        return out
    denial_clauses = [_norm(c) for _k, c in r.denied] if any(
        DROPS.get(v.claim, {}).get("how") == "denial" for v in suppressed) else []

    for v in suppressed:
        plan = DROPS.get(v.claim)
        if plan is None:
            # a claim with a licence to overrule and no surgery defined removes nothing and says so in the
            # record. Silently doing nothing is how a reconciler comes to report suppressions it never made.
            continue
        how = plan["how"]
        if plan.get("when_subject") and v.subject == plan["when_subject"]:
            how = plan["then"]
        if how == "word":
            field = plan["field"]
            items = out.get(field)
            if isinstance(items, list):
                out[field] = [x for x in items if plan["word"] not in _norm(x)]
        elif how == "value":
            field = plan["field"]
            out[field] = [] if isinstance(out.get(field), list) else ""
        elif how == "item":
            field = plan["field"]
            items = out.get(field)
            if isinstance(items, list) and v.subject:
                out[field] = [x for x in items if _norm(v.subject) not in _norm(x)]
        elif how in ("opening", "entry"):
            seen = [o for o in (out.get("openings_seen") or []) if isinstance(o, dict)]
            if how == "entry":
                out["openings_seen"] = [o for o in seen if str(o.get("id") or "") != v.subject]
            else:
                out["openings_seen"] = [{**o, plan["key"]: "unsure"}
                                        if str(o.get("id") or "") == v.subject else o for o in seen]
    if denial_clauses:
        out = _strip_denials(out, denial_clauses)
    return out


def disagreements(r: Reconciliation, *, rationale: bool = True) -> list[dict[str, Any]]:
    """Every contradiction, suppressed or disputed, with both sides kept.

    A SUPPRESSED claim is quoted here in full. That is the point: the model's words survive their own removal
    from the builder's copy, so a person reading the record can see what was taken out and why, and a later
    round can ask whether the suppression was right without re-running anything.

    `rationale=False` LEAVES OUT `why`, and the reason is a fault this found in its own output rather than a
    preference. `why` is `STANDING[claim]["why"]`, which is the engineering argument for the licence: a
    paragraph of corpus statistics written for whoever next changes the table. Two of the seventeen name a
    corpus family in it, and on `venturi_orifice_001` the sentence "`dip` fires on 20 of 20 venturi and orifice
    runs and 0 of 25 straight reducers" travelled into the delivered document, where `document.walk_strings`
    read it as prose about the part and `truth.judge` scored it FALSE as an identity claim: the document told a
    reader a venturi was a straight reducer. The argument for a licence is a fact about this repository and not
    about the customer's file. `claim` is in the row either way, and `rationale_for` resolves it, so nothing is
    lost: it is moved to a reader that wants it.
    """
    rows = []
    for v in r.of(SUPPRESSED) + r.of(DISPUTED):
        row = {"action": v.action, "about": v.look_field, "claim": v.claim,
               "subject": v.subject, "the_look_said": v.said, "the_measurement_said": v.measured,
               "licence": v.licence}
        row["why"] = v.why if rationale else f"the standing of `{v.claim}`: reconcile.block.rationale_for"
        rows.append(row)
    return rows


def rationale_for(claim: str) -> str:
    """The engineering argument behind one claim's licence, for a reader that wants it out of band."""
    from geometry_agent.reconcile.verdict import STANDING
    return str((STANDING.get(claim) or {}).get("why") or "")


def tiers(impression: dict[str, Any], r: Reconciliation) -> dict[str, str]:
    """The tier every field ends at, which is what a consumer branches on.

    Base tiers are `vision.trust`'s, unchanged. The only movement is a candidate the measurement confirmed
    becoming relied on, and a suppressed field dropping out of the table entirely because it is no longer in
    the block to have a tier.
    """
    out = {name: trust.tier_of(name, impression) for name in trust.IMPRESSION_FIELDS}
    contested = _contested(r)
    for v in r.verdicts:
        base = out.get(v.look_field)
        if base is None or v.look_field in contested:
            continue
        if v.action == CONFIRMED and v.tier == trust.RELIED_ON and base == trust.CANDIDATE:
            out[v.look_field] = trust.RELIED_ON
    for v in r.of(SUPPRESSED):
        out.pop(v.look_field, None)
    return out


def _contested(r: Reconciliation) -> set[str]:
    """Fields with an open disagreement on this part.

    A FIELD CANNOT BE BOTH CONFIRMED AND DISPUTED, and before this existed it could be: two claims read the
    same field from two channels, one agreed and one did not, and the block promoted the field to relied_on
    while carrying a live dispute about it a few lines below. `internal_features` is read by three claims, so
    it is where this happened. One channel agreeing does not settle a question another channel is still
    arguing about.
    """
    return {v.look_field for v in r.of(DISPUTED)} | {v.look_field for v in r.of(SUPPRESSED)}


def confirmed_fields(r: Reconciliation) -> list[str]:
    """The fields a consumer may now act on that it could not before: candidates the measurement confirmed.

    A field with an open dispute on this part is not in the list however many claims confirmed it.
    """
    contested = _contested(r)
    return sorted({v.look_field for v in r.of(CONFIRMED)
                   if v.tier == trust.RELIED_ON and v.look_field not in contested})


def block(impression: dict[str, Any], r: Reconciliation, *, rationale: bool = True) -> dict[str, Any]:
    """THE TYPED BLOCK step 5 carries. Everything about the pair, in one place, with nothing lost.

    `impression` is the reply as it arrived and is never modified. `reconciled` is what reaches the builder.
    `contradictions` is the count that needs no answer key, and it is at the top level because it is the only
    quality signal in this pipeline that survives a file nobody has seen.
    """
    counts = r.counts
    return {
        "schema": RECONCILE_SCHEMA,
        "is_measurement": False,
        "read_as": "the look and the measurement, reconciled. A confirmed claim was checked against the "
                   "measurement and agreed with it. A suppressed claim was contradicted by a measurement "
                   "entitled to contradict it and is quoted under disagreements rather than carried. A "
                   "disputed claim is on the record from both sides and is what the question asks about.",
        "case": r.case,
        "counts": counts,
        "contradictions": r.contradictions,
        "reconciled": reconciled(impression, r),
        "confirmed": confirmed_fields(r),
        "disagreements": disagreements(r, rationale=rationale),
        "question": question(r),
        "measured_and_never_said": r.supplied,
        "tiers": tiers(impression, r),
        "readable": r.readable,
    }


def supplied_lines(r: Reconciliation) -> list[str]:
    """The recovered measurements as plain sentences, for a consumer that reads prose and not a dict.

    Each one names a PLACE and what the measurement found there. None of them is a builder setting, none of
    them predicts anything about the mesh, and none of them contains a digit: the magnitudes stay typed under
    `measured_and_never_said[].sizes`.
    """
    return [str(s["said"]) for s in r.supplied]


__all__ = ["DROPS", "block", "confirmed_fields", "disagreements", "rationale_for", "reconciled",
           "supplied_lines", "tiers"]
