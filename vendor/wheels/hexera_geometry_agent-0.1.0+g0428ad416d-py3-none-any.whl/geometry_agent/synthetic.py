"""Synthetic geometries with known ground truth. Used by tests, the eval corpus, and CLI smoke."""
from __future__ import annotations

from pathlib import Path

import numpy as np
import trimesh
from trimesh.transformations import rotation_matrix

SECTIONS = 48


def _cyl(radius: float, length: float, axis: str, start: tuple[float, float, float]) -> trimesh.Trimesh:
    c = trimesh.creation.cylinder(radius=radius, height=length, sections=SECTIONS)
    if axis == "x":
        c.apply_transform(rotation_matrix(np.pi / 2, [0, 1, 0]))
    elif axis == "y":
        c.apply_transform(rotation_matrix(-np.pi / 2, [1, 0, 0]))
    offset = np.array(start, dtype=float)
    offset[{"x": 0, "y": 1, "z": 2}[axis]] += length / 2
    c.apply_translation(offset)
    return c


def _union(parts: list[trimesh.Trimesh]) -> trimesh.Trimesh:
    m = trimesh.boolean.union(parts, engine="manifold")
    m.merge_vertices()
    return m


def manifold(stub_over_d: float, d_main: float = 0.10, d_branch: float = 0.04, main_len: float = 0.60) -> trimesh.Trimesh:
    """Distributor: one large inlet at -X, closed at +X, two small branches along +Y. Fluid volume solid."""
    main = _cyl(d_main / 2, main_len, "x", (0, 0, 0))
    stub = stub_over_d * d_branch
    b1 = _cyl(d_branch / 2, d_main / 2 + stub, "y", (main_len / 3, 0, 0))
    b2 = _cyl(d_branch / 2, d_main / 2 + stub, "y", (2 * main_len / 3, 0, 0))
    return _union([main, b1, b2])


def pipe(d: float = 0.05, length: float = 0.5) -> trimesh.Trimesh:
    return _cyl(d / 2, length, "x", (0, 0, 0))


def open_pipe_shell(d: float = 0.05, length: float = 0.5) -> trimesh.Trimesh:
    """A pipe wall only: caps removed, so both ends are open rims and the mesh is not watertight."""
    m = pipe(d, length)
    keep = np.abs(m.face_normals[:, 0]) < 0.5
    m.update_faces(keep)
    m.remove_unreferenced_vertices()
    return m


def two_regions(gap: float = 0.05) -> trimesh.Trimesh:
    a = trimesh.creation.box(extents=(0.2, 0.1, 0.1))
    b = trimesh.creation.box(extents=(0.2, 0.1, 0.1))
    b.apply_translation([0, 0.1 + gap, 0])
    return trimesh.util.concatenate([a, b])


def thin_fin(body: float = 0.2, fin_t: float = 0.002, fin_h: float = 0.08) -> trimesh.Trimesh:
    base = trimesh.creation.box(extents=(body, body, 0.05))
    fin = trimesh.creation.box(extents=(body * 0.8, fin_t, fin_h))
    fin.apply_translation([0, 0, 0.025 + fin_h / 2 - 0.002])
    return _union([base, fin])


def naca0012(chord: float = 0.3, span: float = 0.1, n: int = 80) -> trimesh.Trimesh:
    """Symmetric airfoil extruded along Z. Blunt leading edge at -X, sharp trailing edge at +X."""
    from shapely.geometry import Polygon

    beta = np.linspace(0, np.pi, n)
    x = 0.5 * (1 - np.cos(beta))
    t = 0.12
    yt = 5 * t * (0.2969 * np.sqrt(x) - 0.1260 * x - 0.3516 * x**2 + 0.2843 * x**3 - 0.1036 * x**4)
    upper = np.column_stack([x, yt])
    lower = np.column_stack([x[::-1], -yt[::-1]])
    pts = np.vstack([upper, lower[1:-1]]) * chord
    poly = Polygon(pts)
    m = trimesh.creation.extrude_polygon(poly, height=span)
    m.apply_translation([0, 0, -span / 2])
    return m


def rotor_in_box(blades: int = 4) -> trimesh.Trimesh:
    """Open rotor: hub plus radial blades, no rotating zone. Purpose external_cfd would want one."""
    hub = trimesh.creation.cylinder(radius=0.03, height=0.04, sections=SECTIONS)
    parts = [hub]
    for i in range(blades):
        blade = trimesh.creation.box(extents=(0.12, 0.01, 0.03))
        blade.apply_translation([0.02 + 0.06, 0, 0])
        blade.apply_transform(rotation_matrix(2 * np.pi * i / blades, [0, 0, 1]))
        parts.append(blade)
    return _union(parts)


CASES: dict[str, tuple] = {
    "manifold_short": (lambda: manifold(1.5), "internal_cfd"),
    "manifold_long": (lambda: manifold(6.0), "internal_cfd"),
    "pipe": (pipe, "internal_cfd"),
    "open_pipe_shell": (open_pipe_shell, "internal_cfd"),
    "two_regions": (two_regions, "internal_cfd"),
    "thin_fin": (thin_fin, "external_cfd"),
    "naca0012": (naca0012, "external_cfd"),
    "rotor_in_box": (rotor_in_box, "external_cfd"),
}


def write_all(out_dir: Path) -> dict[str, Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    paths = {}
    for name, (builder, _purpose) in CASES.items():
        p = out_dir / f"{name}.stl"
        if not p.exists():
            builder().export(p)
        paths[name] = p
    return paths


# ---- devious cases -------------------------------------------------------------------------

def _rotate_offaxis(m: trimesh.Trimesh) -> trimesh.Trimesh:
    m = m.copy()
    m.apply_transform(rotation_matrix(np.radians(37), [0, 0, 1]))
    m.apply_transform(rotation_matrix(np.radians(20), [1, 0, 0]))
    m.apply_translation([0.31, -0.12, 0.07])
    return m


def manifold_offaxis() -> trimesh.Trimesh:
    """Same short-stub manifold, rotated and translated so nothing is axis-aligned."""
    return _rotate_offaxis(manifold(1.5))


def collector() -> trimesh.Trimesh:
    """Three small inlets feeding one large outlet: the largest port is NOT the inlet."""
    main = _cyl(0.05, 0.6, "x", (0, 0, 0))
    parts = [main]
    for x in (0.1, 0.3, 0.5):
        parts.append(_cyl(0.015, 0.05 + 6 * 0.03, "y", (x, 0, 0)))
    return _union(parts)


def pipe_wall_solid(d_in: float = 0.05, wall: float = 0.004, length: float = 0.5) -> trimesh.Trimesh:
    """The pipe's metal, not its bore. Internal CFD needs the fluid volume, which this is not."""
    outer = _cyl(d_in / 2 + wall, length, "x", (0, 0, 0))
    inner = _cyl(d_in / 2, length + 0.02, "x", (-0.01, 0, 0))
    m = trimesh.boolean.difference([outer, inner], engine="manifold")
    m.merge_vertices()
    return m


def elbow(d: float = 0.05, leg: float = 0.3) -> trimesh.Trimesh:
    """Two legs joined by a sphere at the corner: a 90 degree bend."""
    a = _cyl(d / 2, leg, "x", (0, 0, 0))
    b = _cyl(d / 2, leg, "y", (leg, 0, 0))
    corner = trimesh.creation.icosphere(subdivisions=3, radius=d / 2)
    corner.apply_translation([leg, 0, 0])
    return _union([a, b, corner])


def pipe_with_drain(d: float = 0.05, length: float = 0.5) -> trimesh.Trimesh:
    """Straight pipe with a D/10 drain hole on the underside."""
    main = _cyl(d / 2, length, "x", (0, 0, 0))
    drain = _cyl(d / 20, d / 2 + 0.03, "y", (length * 0.7, -(d / 2 + 0.03), 0))
    return _union([main, drain])


def tee_unequal(d: float = 0.05) -> trimesh.Trimesh:
    """T-junction: one branch 6D, the other 1.5D."""
    main = _cyl(d / 2, 0.5, "x", (0, 0, 0))
    long_ = _cyl(d / 2, d / 2 + 6 * d, "y", (0.25, 0, 0))
    short = _cyl(d / 2, d / 2 + 1.5 * d, "z", (0.25, 0, 0))
    return _union([main, long_, short])


def internal_void() -> trimesh.Trimesh:
    """A block with a sealed cavity inside it. Two regions, one enclosing the other."""
    block = trimesh.creation.box(extents=(0.3, 0.2, 0.2))
    cavity = trimesh.creation.box(extents=(0.1, 0.08, 0.08))
    hollow = trimesh.boolean.difference([block, cavity], engine="manifold")
    hollow.merge_vertices()
    return hollow


def seam_split(d: float = 0.05, length: float = 0.5) -> trimesh.Trimesh:
    """One wall strip deleted end to end: an unstitched seam, the way a bad CAD export looks."""
    m = pipe(d, length)
    wall = np.where(np.abs(m.face_normals[:, 0]) < 0.5)[0]
    cx = m.triangles_center[wall]
    pick = wall[np.argsort(np.abs(cx[:, 0] - length * 0.4) + np.abs(cx[:, 2] - d / 2))[:2]]
    keep = np.ones(len(m.faces), dtype=bool)
    keep[pick] = False
    m.update_faces(keep)
    m.remove_unreferenced_vertices()
    return m


def hairline_gap(d: float = 0.05, length: float = 0.5) -> trimesh.Trimesh:
    """Finely tessellated pipe with two small wall triangles deleted: a pinhole, not a port."""
    m = pipe(d, length)
    for _ in range(3):
        m = m.subdivide()
    wall = np.where(np.abs(m.face_normals[:, 0]) < 0.5)[0]
    cx = m.triangles_center[wall]
    pick = wall[np.argsort(np.abs(cx[:, 0] - length * 0.4) + np.abs(cx[:, 2] - d / 2) + np.abs(cx[:, 1]))[:2]]
    keep = np.ones(len(m.faces), dtype=bool)
    keep[pick] = False
    m.update_faces(keep)
    m.remove_unreferenced_vertices()
    return m


def sudden_expansion(d: float = 0.04) -> trimesh.Trimesh:
    """Pipe steps from D to 2D at mid-length."""
    small = _cyl(d / 2, 0.3, "x", (0, 0, 0))
    big = _cyl(d, 0.3, "x", (0.3, 0, 0))
    return _union([small, big])


def nested_cht() -> trimesh.Trimesh:
    """A solid block and a separate fluid channel body running through it: two bodies, one inside the other's box."""
    block = trimesh.creation.box(extents=(0.3, 0.15, 0.15))
    channel = _cyl(0.02, 0.32, "x", (-0.16, 0, 0))
    solid = trimesh.boolean.difference([block, channel], engine="manifold")
    fluid = _cyl(0.0198, 0.3, "x", (-0.15, 0, 0))
    return trimesh.util.concatenate([solid, fluid])


def glued_cht_pipe(r_in: float = 0.025, wall: float = 0.004, length: float = 0.5, sections: int = 64
                   ) -> trimesh.Trimesh:
    """A pipe wall and the fluid inside it, meeting on one surface: the shape a conjugate run is about.

    Built from two primitives on the same section count so the bore is one surface carried twice, which is what
    a compound export of a solid and its fluid looks like. It exists because the 322-part corpus has ONE
    interface in it and nothing to check a per-interface thickness against. Here both answers are known in
    closed form: the wall is `wall` and the passage is `2 * r_in`, each measured from a facet centroid and so
    each shorter by `cos(pi / sections)`, which is 0.12 per cent at 64 sections."""
    solid = trimesh.creation.annulus(r_min=r_in, r_max=r_in + wall, height=length, sections=sections)
    fluid = trimesh.creation.cylinder(radius=r_in, height=length, sections=sections)
    m = trimesh.util.concatenate([solid, fluid])
    m.merge_vertices()
    return m


def mm_manifold() -> trimesh.Trimesh:
    """The short manifold exported in millimetres: 600 units long. No unit in the file."""
    m = manifold(1.5)
    m.apply_scale(1000.0)
    return m


def flapped_airfoil(gap: float = 0.004) -> trimesh.Trimesh:
    """Main element plus a flap with a small slot gap: near-touching surfaces."""
    main = naca0012(chord=0.25, span=0.1)
    flap = naca0012(chord=0.08, span=0.1)
    flap.apply_transform(rotation_matrix(np.radians(-20), [0, 0, 1]))
    flap.apply_translation([0.25 + gap, -0.001, 0])
    return trimesh.util.concatenate([main, flap])


HARD_CASES: dict[str, tuple] = {
    "manifold_offaxis": (manifold_offaxis, "internal_cfd"),
    "collector": (collector, "internal_cfd"),
    "pipe_wall_solid": (pipe_wall_solid, "internal_cfd"),
    "elbow": (elbow, "internal_cfd"),
    "pipe_with_drain": (pipe_with_drain, "internal_cfd"),
    "tee_unequal": (tee_unequal, "internal_cfd"),
    "internal_void": (internal_void, "structural"),
    "hairline_gap": (hairline_gap, "internal_cfd"),
    "seam_split": (seam_split, "internal_cfd"),
    "sudden_expansion": (sudden_expansion, "internal_cfd"),
    "nested_cht": (nested_cht, "conjugate_heat_transfer"),
    "mm_manifold": (mm_manifold, "internal_cfd"),
    "flapped_airfoil": (flapped_airfoil, "external_cfd"),
    "brief_conflict": (lambda: manifold(6.0), "internal_cfd"),
}


def write_hard(out_dir: Path) -> dict[str, Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    paths = {}
    for name, (builder, _purpose) in HARD_CASES.items():
        p = out_dir / f"{name}.stl"
        if not p.exists():
            builder().export(p)
        paths[name] = p
    return paths
