"""analyze(): measure, then reason. The one entry point intake will call.

What bounds a call (docs/eval_protocol.md section 9). The measurement used to run in this process with nothing
in front of it: a 40.02 MiB STEP of 402 bodies loads to 26,579,682 triangles and peaks at 14.68 GiB of working
set before a single fact is computed, which is the whole machine, and a customer file can be worse. So a file
over `max_file_bytes` is refused without being opened, the measurement itself runs in a child process that is
killed at `measure_timeout_s`, and either refusal comes back as `exit="refused"`, which is neither a model
failure nor a measurement that tried and broke. `GEOMETRY_AGENT_DISABLED` refuses every call, read fresh each
time so it stops the next case of a run already in flight.
"""
from __future__ import annotations

import tempfile
import time
from pathlib import Path

from geometry_agent import observe
from geometry_agent.agent.client import ModelClient, client_from_env
from geometry_agent.agent.loop import ChainGiven, LoopConfig, run_loop
from geometry_agent.agent.schema import AnalysisResult
from geometry_agent.agent.tools import ToolContext
from geometry_agent.facts.load import UnsupportedGeometry
from geometry_agent.facts.measure import measure, measure_isolated
from geometry_agent.facts.schema import FACTS_SCHEMA_VERSION, Fidelity, GeometryFacts, Purpose
from geometry_agent.vision.client import VisionClient

#: The file-size ceiling, in mebibytes, and the variable that moves it (`off` removes it). The largest file
#: either corpus measures is 16.43 MiB and the one that exhausts this machine is 40.02 MiB; 32 sits between
#: them. Bytes are the only cost known before the file is opened: this one expands 665-fold from bytes to
#: triangles, and nothing cheaper than opening it can say that in advance.
MAX_FILE_MB_ENV = "GEOMETRY_AGENT_MAX_FILE_MB"
DEFAULT_MAX_FILE_MB = 32.0
#: How long a measurement may run before the child carrying it is killed (`off` measures in this process with
#: no deadline). 900 s is `measure_isolated`'s own default; the slowest real part on this machine measures in
#: about 650 s.
MEASURE_TIMEOUT_ENV = "GEOMETRY_AGENT_MEASURE_TIMEOUT_S"
DEFAULT_MEASURE_TIMEOUT_S = 900.0

REFUSED_DISABLED = ("the geometry agent is switched off on this machine ({var}=1); no file was opened and no "
                    "model was called. Unset it to run.")
REFUSED_TOO_LARGE = ("the file is {mb:.1f} MiB, over the {cap:.0f} MiB ceiling this agent measures within "
                     "({var} moves it). It was not opened: a file this size can cost tens of gigabytes to "
                     "tessellate, so the refusal is the agent's, not the model's.")
REFUSED_SLOW = ("the measurement did not finish within {sec:.0f}s and was stopped ({var} moves the deadline). "
                "The file was reached and read; nothing about it is known, and no model was called.")
#: What the child's failure says when it never started: the interpreter or the package was not reachable from it.
#: Then the deadline cannot be kept, and keeping it would mean refusing every file, so the measurement runs here.
NO_CHILD = ("No module named", "can't open file", "cannot open file")
#: What `facts.measure.measure_isolated` says when it killed the child at the deadline, and nothing else says.
#: The deadline is read off the message rather than off the clock because `measure_isolated` retries a native
#: fault twice: a file that breaks the measurement three times can spend more wall seconds than the deadline and
#: would otherwise be called a refusal, and a refusal is retried by `--skip-done` while a failure is not.
#: tests/test_unattended.py pins this string to the one that module raises.
DEADLINE_SAID = "measurement exceeded"


def file_ceiling_bytes(env: dict | None = None) -> int:
    """The size ceiling in force, in bytes; 0 when there is none."""
    return int(observe.setting(MAX_FILE_MB_ENV, DEFAULT_MAX_FILE_MB, env) * 1024 * 1024)


def measure_timeout_s(env: dict | None = None) -> float:
    """The measurement deadline in force, in seconds; 0 for none, which measures in this process."""
    return observe.setting(MEASURE_TIMEOUT_ENV, DEFAULT_MEASURE_TIMEOUT_S, env)


def cache_entry(path: Path, purpose: Purpose, cache_dir: str | Path) -> Path:
    """Where `facts.measure` keeps this file's facts. The format is measure()'s, repeated here only so a run can
    say whether it paid for a measurement; tests/test_unattended.py pins the two together."""
    from geometry_agent.facts import load
    return Path(cache_dir) / f"{load.sha256_of(path)}.{purpose}.v{FACTS_SCHEMA_VERSION}.json"


def _refused(reason: str) -> AnalysisResult:
    return AnalysisResult(ok=False, exit="refused", plan=None, reason=reason, rounds=0, tool_calls=0,
                          grounding_rejections=0)


def measured_facts(path: Path, purpose: Purpose, cache_dir: str | Path | None,
                   timeout_s: float) -> tuple[GeometryFacts | None, AnalysisResult | None]:
    """The facts for a file, or the refusal that stands in their place.

    With a deadline the measurement is a child process, because a native tessellation cannot be interrupted from
    inside this one; `measure_isolated` needs somewhere to hand the facts back, so a caller with no cache of its
    own gets a temporary directory that is thrown away afterwards."""
    if timeout_s <= 0:
        return measure(path, purpose=purpose, cache_dir=cache_dir), None
    t0 = time.perf_counter()
    scratch = tempfile.TemporaryDirectory(prefix="geometry-agent-facts-") if cache_dir is None else None
    try:
        return measure_isolated(path, purpose=purpose, cache_dir=cache_dir or scratch.name, timeout_s=timeout_s), None
    except UnsupportedGeometry as exc:
        spent = time.perf_counter() - t0
        if DEADLINE_SAID in str(exc):
            observe.warning("measure.refused", why="deadline", seconds=spent, deadline=timeout_s,
                            **observe.file_id(path))
            return None, _refused(REFUSED_SLOW.format(sec=timeout_s, var=MEASURE_TIMEOUT_ENV))
        if any(s in str(exc) for s in NO_CHILD):
            # the child could not start at all (no interpreter, the package not importable from it). That is a
            # deployment fault, not a fault of the file: measure here instead, and say so, rather than refusing
            # every part this process is asked about.
            observe.warning("measure.unisolated", why="the measurement child could not start", deadline=timeout_s)
            return measure(path, purpose=purpose, cache_dir=cache_dir), None
        raise  # the child ran and failed on the file itself: a measurement failure, not a refusal
    finally:
        if scratch is not None:
            scratch.cleanup()


def analyze(
    path: str | Path,
    purpose: Purpose,
    brief: str = "",
    fidelity: Fidelity = "standard",
    cell_cap: int | None = None,
    declared: list[dict] | None = None,
    client: ModelClient | None = None,
    cache_dir: str | Path | None = None,
    render_dir: str | Path | None = None,
    config: LoopConfig | None = None,
    facts: GeometryFacts | None = None,
    vision: VisionClient | None = None,
    memory: object | None = None,
    max_file_bytes: int | None = None,
    measure_timeout: float | None = None,
    given: ChainGiven | None = None,
) -> AnalysisResult:
    """Measure `path`, then run the model loop. `vision` (a VisionClient, see
    geometry_agent.vision.client.vision_client_from_env) adds the look_at_views tool to the run; None, the
    default, keeps the run purely measured and the tool out of the model's list.

    `memory` (a geometry_agent.learn.memory.CaseMemory, dev plan P7) offers the opening message a block about
    parts that measured like this one; None, the default, keeps memory off and the message is byte for byte what
    it was without it.

    `max_file_bytes` and `measure_timeout` bound the measurement; None takes each from the environment (see the
    module docstring) and 0 removes it. Both refuse with `exit="refused"`, which is the agent declining, not a
    model failure (`model_error`) and not a measurement that ran and broke (`measurement_failed`)."""
    if observe.disabled():
        observe.warning("run.refused", why="switch", var=observe.DISABLE_ENV)
        return _refused(REFUSED_DISABLED.format(var=observe.DISABLE_ENV))
    path = Path(path)
    if facts is None:
        ceiling = file_ceiling_bytes() if max_file_bytes is None else int(max_file_bytes)
        timeout = measure_timeout_s() if measure_timeout is None else float(measure_timeout)
        try:
            size = path.stat().st_size
        except OSError as exc:
            return AnalysisResult(ok=False, exit="measurement_failed", plan=None, reason=str(exc),
                                  rounds=0, tool_calls=0, grounding_rejections=0)
        if ceiling > 0 and size > ceiling:
            observe.warning("run.refused", why="size", bytes=size, ceiling=ceiling, suffix=path.suffix.lower())
            return _refused(REFUSED_TOO_LARGE.format(mb=size / 1024 / 1024, cap=ceiling / 1024 / 1024,
                                                     var=MAX_FILE_MB_ENV))
        if cache_dir is None:
            observe.info("measure.miss", purpose=purpose, cache="none", deadline=timeout,
                         **observe.file_id(path, size))
        elif not cache_entry(path, purpose, cache_dir).exists():
            observe.info("measure.miss", purpose=purpose, deadline=timeout, **observe.file_id(path, size))
        try:
            facts, refusal = measured_facts(path, purpose, cache_dir, timeout)
            if refusal is not None:
                return refusal
        except (UnsupportedGeometry, OSError, ValueError) as exc:
            observe.warning("measure.failed", error=type(exc).__name__, **observe.file_id(path, size))
            return AnalysisResult(ok=False, exit="measurement_failed", plan=None, reason=str(exc),
                                  rounds=0, tool_calls=0, grounding_rejections=0)
    ctx = ToolContext(facts=facts, purpose=purpose, fidelity=fidelity, cell_cap=cell_cap, declared=declared,
                      brief=brief, render_dir=str(render_dir) if render_dir else None, vision=vision, memory=memory)
    client = client or client_from_env()
    # `given` is step 5 of the wired chain (`chain.job.plan` builds it from the survey and the customer's answers):
    # the loop then refuses a context that reads the part differently and sends back a plan that contradicts the
    # survey or a confirmation. The whole chain, brief to builder, is `chain.job.run_job` (work/z-chain NEEDS 7)
    return run_loop(client, ctx, config, given=given)
