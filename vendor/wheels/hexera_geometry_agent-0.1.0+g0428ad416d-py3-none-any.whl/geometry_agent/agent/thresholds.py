"""Threshold governance (dev plan P2, principle 6): every numeric rule parameter of the catalog as data.

The dataclass carries the defaults, which are the hand-written constants in catalog.py. The JSON beside this
file carries the values in force plus, per key, its unit or frame, rule class, audience, stratum, status,
provenance, minimum support and history. The catalog reads `current()`; the prompt's rule sentences are
generated from the same object; `geometry-agent thresholds ship` is the only path that changes a value.
"""
from __future__ import annotations

import hashlib
import json
import os
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import asdict, dataclass, fields
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

ENV_FILE = "GEOMETRY_AGENT_THRESHOLDS_FILE"
DEFAULT_FILE = Path(__file__).with_name("thresholds.json")
RULE_CLASSES = ("physics_rule", "calibrated")
AUDIENCES = ("user", "builder", "info")
STATUSES = ("proposed", "signed", "shipped", "retired")
#: What a sweep must state for a calibrated key to be proposed (docs/thresholds.md, section 3).
PROVENANCE_KEYS = ("source", "corpus_version", "sweep_file", "n", "fires", "lift", "mcc_cv", "band", "fitted_at")
ENTRY_KEYS = ("value", "default", "unit_or_frame", "rule_class", "audience", "stratum", "status", "provenance",
              "min_support", "history", "reference")
#: A calibrated key is refitted only from at least this many new learning rows in its stratum (dev plan P2).
DEFAULT_MIN_SUPPORT = 20


class ThresholdsError(ValueError):
    """The thresholds file disagrees with the dataclass, or a governance rule refuses the request."""


@dataclass(frozen=True)
class Thresholds:
    """Every numeric rule parameter catalog.py reads, at today's value. The field order is the catalog's."""
    #: An outlet run at or above this many diameters is long enough for a pressure outlet.
    STUB_OK_OVER_D: float = 5.0
    #: Under this many diameters a short outlet stub is high severity (the user must decide).
    STUB_BLOCKING_OVER_D: float = 2.0
    PORT_TUBULARITY: float = 0.85
    #: Port bores differing by more than this factor need per-bore refinement, not one first cell.
    VELOCITY_RATIO_MAX: float = 2.0
    #: A thin cluster under this many surface cells across degenerates.
    THIN_CELLS_MIN: float = 3.0
    #: A gap under this many surface cells across collapses.
    GAP_CELLS_MIN: float = 3.0
    SIZE_BAND: float = 0.25
    #: Declared port area over measured area must lie within this band to match.
    AREA_MATCH_BAND: float = 0.25
    #: A declared `near` point must lie within this many diameters of the candidate's centroid.
    NEAR_MATCH_OVER_D: float = 1.5
    #: More port candidates than this without roles is ambiguous.
    MANY_CANDIDATES: int = 6
    #: A port under this fraction of the largest port's diameter is a drain, vent or tap.
    TINY_PORT_FRACTION: float = 0.15
    HOLE_TUBULARITY_MAX: float = 0.3
    #: Rotational order from which a thin-featured body reads as bladed.
    ROTOR_MIN_BLADES: int = 3
    #: An inlet run at or above STUB_OK_OVER_D but under this is still developing (info only).
    INLET_DEVELOPED_OVER_D: float = 10.0
    #: A port whose bore holds fewer surface cells than this is under-resolved at the tier.
    PORT_CELLS_MIN: float = 8.0
    #: A conical diffuser steeper than this half angle separates.
    DIFFUSER_ANGLE_MAX_DEG: float = 7.0
    #: Two bores within this relative band are interchangeable.
    SAME_BORE_BAND: float = 0.02
    #: Non-manifold edges are a decision from this count upward.
    NON_MANIFOLD_EDGES_MIN: int = 12
    #: Or from this fraction of the faces upward.
    NON_MANIFOLD_EDGE_FRACTION: float = 1e-4
    #: The highest rotational order tested; a body that passes it is axisymmetric, not bladed.
    AXISYMMETRIC_ORDER: int = 12
    #: A minimum thickness under this fraction of the diagonal is blade-like.
    BLADE_THICKNESS_OF_DIAG: float = 0.05
    #: A ring whose annulus is thinner than this fraction of its bore is the end of a wall.
    WALL_SHELL_ANNULUS_FRACTION: float = 0.15
    #: An inner body's end cap sits in a ring's plane within this fraction of the bore along the normal.
    INNER_CAP_PLANE_TOL: float = 0.05
    #: The carve seed point sits this many bores inside the inlet ring.
    SEED_INSET_OVER_BORE: float = 0.4
    #: A body whose volume over area is under this fraction of its ring's bore is a skin around a cavity.
    SHELL_VOLUME_OVER_AREA_OF_BORE: float = 0.1
    #: A boss's end face sits within this many of its own diameters of the plate it pierces.
    PIERCE_REACH_OVER_CAP_D: float = 3.0
    #: A cap or a ring is coaxial with a ring when its lateral offset is under this fraction of the bore.
    COAXIAL_OVER_BORE: float = 0.1
    #: A ring whose outer boundary equals another ring's bore within this band sits inside that bore (a step).
    INNER_STEP_BORE_BAND: float = 0.05
    #: A brief dimension settles the unit when it matches a measured length within this band.
    UNIT_MATCH_BAND: float = 0.06
    #: A thin cluster under this many surface cells across is high severity.
    THIN_CELLS_HIGH: float = 1.0
    #: The refinement target across a near-touching gap is the gap over this.
    GAP_TARGET_DIVISOR: float = 4.0
    #: The far-field box an external case needs, in body lengths.
    EXTERNAL_UPSTREAM_OVER_L: float = 5.0
    EXTERNAL_DOWNSTREAM_OVER_L: float = 15.0
    EXTERNAL_LATERAL_OVER_L: float = 5.0
    #: A circular mouth whose normal sits this many degrees or more off the nearest coordinate axis is tilted
    #: for snappy's axis-aligned grid (the port cap is cut stair-stepped, one level coarser than the wall).
    #: Calibrated on the learning half (eval/calib/sweeps/port_tilt_2026-09-09.json), status proposed.
    TILTED_MOUTH_DEG: float = 0.5


KEYS: tuple[str, ...] = tuple(f.name for f in fields(Thresholds))
_TYPES: dict[str, type] = {f.name: f.type if isinstance(f.type, type) else (int if f.type == "int" else float) for f in fields(Thresholds)}
DEFAULTS = Thresholds()


def thresholds_path(path: str | Path | None = None) -> Path:
    """The file in force: the argument, else $GEOMETRY_AGENT_THRESHOLDS_FILE, else the package's own JSON."""
    if path:
        return Path(path)
    override = os.environ.get(ENV_FILE)
    return Path(override) if override else DEFAULT_FILE


def _cast(key: str, value: Any) -> int | float:
    t = _TYPES.get(key, float)
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ThresholdsError(f"{key}: value {value!r} is not a number")
    if t is int:
        if float(value) != int(value):
            raise ThresholdsError(f"{key}: value {value!r} must be an integer")
        return int(value)
    return float(value)


def read_table(path: str | Path | None = None) -> dict[str, dict[str, Any]]:
    """The JSON table, key -> entry, checked against the dataclass: every key present, no key unknown."""
    p = thresholds_path(path)
    try:
        table = json.loads(p.read_text(encoding="utf-8"))
    except OSError as exc:
        raise ThresholdsError(f"cannot read thresholds file {p}: {exc}") from exc
    except ValueError as exc:
        raise ThresholdsError(f"thresholds file {p} is not valid JSON: {exc}") from exc
    problems = validate_table(table)
    if problems:
        raise ThresholdsError(f"thresholds file {p}: " + "; ".join(problems[:8]))
    return table


def validate_table(table: Any) -> list[str]:
    """Every problem that would make the table unsafe to load, so the file and the dataclass never drift silently."""
    if not isinstance(table, dict):
        return ["the table must be a JSON object keyed by threshold name"]
    problems = []
    missing = [k for k in KEYS if k not in table]
    unknown = [k for k in table if k not in KEYS]
    if missing:
        problems.append(f"missing keys {missing}")
    if unknown:
        problems.append(f"unknown keys {unknown} (not fields of Thresholds)")
    for key in KEYS:
        entry = table.get(key)
        if entry is None:
            continue
        if not isinstance(entry, dict):
            problems.append(f"{key}: entry must be an object")
            continue
        for field_name in ENTRY_KEYS:
            if field_name not in entry:
                problems.append(f"{key}: missing {field_name}")
        try:
            _cast(key, entry.get("value"))
        except ThresholdsError as exc:
            problems.append(str(exc))
        if entry.get("rule_class") not in RULE_CLASSES:
            problems.append(f"{key}: rule_class must be one of {RULE_CLASSES}")
        if entry.get("audience") not in AUDIENCES:
            problems.append(f"{key}: audience must be one of {AUDIENCES}")
        if entry.get("status") not in STATUSES:
            problems.append(f"{key}: status must be one of {STATUSES}")
        if entry.get("provenance") is not None and not isinstance(entry.get("provenance"), dict):
            problems.append(f"{key}: provenance must be an object or null")
        if not isinstance(entry.get("history"), list):
            problems.append(f"{key}: history must be a list")
    return problems


def from_table(table: dict[str, dict[str, Any]]) -> Thresholds:
    return Thresholds(**{k: _cast(k, table[k]["value"]) for k in KEYS})


def load(path: str | Path | None = None) -> Thresholds:
    """The thresholds in force, read fresh from the file (see thresholds_path)."""
    return from_table(read_table(path))


_CACHE: dict[str, Any] = {}
_OVERRIDE: list[Thresholds] = []


@contextmanager
def override(thresholds: Thresholds) -> Iterator[Thresholds]:
    """Make `current()` return `thresholds` inside the block: how the ship command replays every transcript
    under a proposed value without writing the file, and how a test tries a value in the whole agent."""
    _OVERRIDE.append(thresholds)
    try:
        yield thresholds
    finally:
        _OVERRIDE.pop()


def current() -> Thresholds:
    """The thresholds in force: an active override, else the file, cached per file version (path, mtime, size)
    so the catalog can call it on every detect_risks without rereading and a shipped change or an env override
    is still seen at once."""
    if _OVERRIDE:
        return _OVERRIDE[-1]
    p = thresholds_path()
    try:
        st = p.stat()
        key: tuple = (str(p.resolve()), st.st_mtime_ns, st.st_size)
    except OSError:
        key = (str(p), None, None)
    if _CACHE.get("key") != key:
        _CACHE["value"] = load(p)
        _CACHE["key"] = key
    return _CACHE["value"]


def invalidate() -> None:
    _CACHE.clear()


def values(thresholds: Thresholds | None = None) -> dict[str, int | float]:
    return dict(asdict(thresholds if thresholds is not None else current()))


def thresholds_sha256(thresholds: Thresholds | None = None) -> str:
    """sha256 of the values in force (canonical JSON, sorted keys). Provenance, status and history edits do not
    change it; only a value does, which is what a result stamp needs to tell one behaviour from another."""
    canon = json.dumps(values(thresholds), sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canon.encode("utf-8")).hexdigest()


def write_table(table: dict[str, dict[str, Any]], path: str | Path | None = None) -> Path:
    problems = validate_table(table)
    if problems:
        raise ThresholdsError("refusing to write an invalid table: " + "; ".join(problems[:8]))
    p = thresholds_path(path)
    p.write_text(json.dumps(table, indent=1) + "\n", encoding="utf-8")
    invalidate()
    return p


def _today() -> str:
    return datetime.now(UTC).date().isoformat()


def propose(table: dict[str, dict[str, Any]], key: str, value: float, sweep: dict[str, Any],
            sweep_file: str | None = None, date: str | None = None) -> dict[str, Any]:
    """Record a proposal on `key`: status proposed, provenance from the sweep, the value unchanged. The
    proposed value lives in provenance.proposed_value until ship moves it into value."""
    if key not in table:
        raise ThresholdsError(f"unknown threshold {key!r}; known: {list(KEYS)}")
    entry = table[key]
    if entry.get("status") == "retired":
        raise ThresholdsError(f"{key} is retired; a retired key is not proposed")
    proposed = _cast(key, value)
    prov = {k: sweep.get(k) for k in PROVENANCE_KEYS}
    prov["sweep_file"] = str(sweep_file or sweep.get("sweep_file") or "")
    prov["fitted_at"] = sweep.get("fitted_at") or date or _today()
    prov["proposed_value"] = proposed
    prov["baselines"] = sweep.get("baselines")
    prov["noise_floor_mcc"] = sweep.get("noise_floor_mcc")
    prov["mcc_cv_previous"] = sweep.get("mcc_cv_previous")
    prov["proposed_on"] = date or _today()
    entry["status"] = "proposed"
    entry["provenance"] = prov
    return entry


def ship_refusals(table: dict[str, dict[str, Any]], key: str, override_physics: bool = False) -> list[str]:
    """Every governance rule that refuses shipping `key` now, in words. Empty means ship may proceed (the
    replay regression is the caller's last gate)."""
    if key not in table:
        return [f"unknown threshold {key!r}; known: {list(KEYS)}"]
    entry = table[key]
    out: list[str] = []
    status = entry.get("status")
    if status not in ("proposed", "signed"):
        out.append(f"{key} has status {status!r}; only a proposed (or signed) key ships: run `thresholds propose` first")
        return out
    prov = entry.get("provenance") or {}
    if "proposed_value" not in prov:
        out.append(f"{key}: the proposal carries no proposed_value")
        return out
    if prov["proposed_value"] == entry.get("value"):
        out.append(f"{key}: the proposed value {prov['proposed_value']!r} equals the value in force; nothing to ship")
    if entry.get("rule_class") == "physics_rule" and not override_physics:
        out.append(f"{key} is a physics rule: it never moves automatically. A contradicting sweep is a note to Rehaan "
                   f"with the reference. Reference: {entry.get('reference') or 'none recorded'}. "
                   "Rerun with --override-physics --signed-by <name> once he has signed it.")
    if entry.get("rule_class") == "calibrated":
        n = prov.get("n")
        support = entry.get("min_support") if entry.get("min_support") is not None else DEFAULT_MIN_SUPPORT
        if not isinstance(n, (int, float)) or n < support:
            out.append(f"{key}: the sweep's n is {n!r}, under the minimum support {support}")
        mcc = prov.get("mcc_cv")
        baselines = prov.get("baselines") or {}
        fam = baselines.get("family_only_mcc") if isinstance(baselines, dict) else None
        flag = baselines.get("flag_everything_mcc") if isinstance(baselines, dict) else None
        if not all(isinstance(x, (int, float)) for x in (mcc, fam, flag)):
            out.append(f"{key}: the sweep must report mcc_cv and both baselines (family_only_mcc, flag_everything_mcc); "
                       f"got mcc_cv={mcc!r}, baselines={baselines!r}")
        else:
            if mcc <= fam:
                out.append(f"{key}: cross-validated MCC {mcc} does not beat the family-only baseline {fam}")
            if mcc <= flag:
                out.append(f"{key}: cross-validated MCC {mcc} does not beat the flag-everything baseline {flag}")
        band = prov.get("band")
        if isinstance(band, (list, tuple)) and len(band) == 2 and all(isinstance(b, (int, float)) for b in band):
            lo, hi = sorted(band)
            if lo <= entry.get("value") <= hi:
                out.append(f"{key}: the value in force {entry.get('value')} sits inside the sweep's band [{lo}, {hi}]; "
                           "the fitted value has not left the band, so no move is warranted")
        prev, noise = prov.get("mcc_cv_previous"), prov.get("noise_floor_mcc")
        if isinstance(prev, (int, float)) and isinstance(noise, (int, float)) and isinstance(mcc, (int, float)) \
                and mcc - prev <= noise:
            out.append(f"{key}: cross-validated MCC improves by {mcc - prev:.4f} over the last fit, not more than the "
                       f"noise floor's equivalent {noise}")
    return out


def ship(table: dict[str, dict[str, Any]], key: str, signed_by: str | None = None, date: str | None = None,
         override_physics: bool = False) -> dict[str, Any]:
    """Move the proposed value into force: the history entry (from, to, date, who signed, both hashes before and
    after, the provenance), status shipped. Raises ThresholdsError on any refusal; run the replay regression
    before calling this (the CLI does)."""
    refusals = ship_refusals(table, key, override_physics=override_physics)
    if refusals:
        raise ThresholdsError("; ".join(refusals))
    from geometry_agent.agent import prompt

    entry = table[key]
    prov = dict(entry.get("provenance") or {})
    before = from_table(table)
    old, new = entry["value"], _cast(key, prov["proposed_value"])
    entry["value"] = new
    after = from_table(table)
    record = {
        "from": old, "to": new, "date": date or _today(), "signed_by": signed_by,
        "thresholds_sha256_before": thresholds_sha256(before), "thresholds_sha256_after": thresholds_sha256(after),
        "prompt_sha256_before": prompt.prompt_sha256(before), "prompt_sha256_after": prompt.prompt_sha256(after),
        "override_physics": bool(override_physics and entry.get("rule_class") == "physics_rule"),
        "provenance": prov,
    }
    entry.setdefault("history", []).append(record)
    entry["status"] = "shipped"
    return record


def rows(table: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    """One flat row per key for `thresholds show` and the docs table."""
    out = []
    for key in KEYS:
        e = table[key]
        prov = e.get("provenance") or {}
        out.append({"key": key, "value": e["value"], "default": e["default"], "unit_or_frame": e["unit_or_frame"],
                    "rule_class": e["rule_class"], "audience": e["audience"], "stratum": e["stratum"],
                    "status": e["status"], "n": prov.get("n"), "fitted_at": prov.get("fitted_at"),
                    "proposed_value": prov.get("proposed_value") if e["status"] in ("proposed", "signed") else None,
                    "history": len(e.get("history") or [])})
    return out
