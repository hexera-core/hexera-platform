"""Apply the user's answers to a plan, and keep every override as a labelled example.

Each question the agent asked has options. The answer settles a role (which opening is the inlet), a decision
on a risk (extend the stub, accept it, abort), the unit, or the purpose. Applying answers produces the confirmed
plan intake carries forward, and a `Correction` for every place the user disagreed with what the agent proposed.
Those pairs (proposed, confirmed) are the training signal for the next round of the agent's own judgment, so
they are written out, one JSON line each, with the facts digest they belong to."""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from geometry_agent.agent.schema import Decision, GeometryPlan, Role, UserQuestion

ROLE_WORDS: dict[str, Role] = {
    "inlet": "inlet", "outlet": "outlet", "closed end": "closed_end", "closed_end": "closed_end", "wall": "wall",
    "closed": "closed_end", "blanked": "closed_end", "capped": "closed_end", "symmetry": "symmetry", "farfield": "farfield",
}
DECISION_WORDS: dict[str, Decision] = {
    "accept": "continue", "accept as is": "continue", "continue": "continue", "use half model": "continue",
    "flow is symmetric, use half model": "continue", "mesh the full body": "fix", "use recommended box": "continue",
    "fix": "fix", "extend": "fix", "extend to 5d": "fix", "send to repair": "fix", "repair": "fix", "defeature it": "fix",
    "declare as inlet": "fix", "drop fidelity": "fix", "raise cap": "fix", "add rotating zone": "fix",
    "run stationary": "continue", "abort": "abort", "change purpose": "change_purpose", "change purpose to cht": "change_purpose",
    "intentional (cht)": "change_purpose", "confirm declared unit": "continue", "override unit": "fix",
    "keep the assigned direction": "continue", "keep": "continue", "reverse it": "fix", "reverse": "fix",
    "glue the bodies in cad": "fix", "glue": "fix", "close the gap in cad": "fix", "upload the fluid body": "fix",
    # `no_shared_interface`'s own default, and the one option in DEFAULT_OPTIONS none of the three routes
    # reached: its three siblings ("send to repair", "glue the bodies in cad", "close the gap in cad") were
    # all here, so answering that question with the answer it recommends left the decision pending
    "fix in cad": "fix",
    "extract the bore in cad": "fix", "rims are ports, cap them": "fix", "one of these is a port": "fix",
    "open port": "continue", "closed for this run": "fix", "inner body is the fluid": "continue",
    "outer body is the fluid": "fix", "remove the cavity": "fix", "pick from measured list": "fix",
    "correct declaration": "fix", "name the ports now": "fix",
}


def _role_in(text: str) -> Role | None:
    """The role an option or free answer names, longest word first so 'closed end' wins over 'closed'."""
    t = _norm(text)
    for key in sorted(ROLE_WORDS, key=len, reverse=True):
        if key == t or f" {key} " in f" {t} ":
            return ROLE_WORDS[key]
    return None


@dataclass
class Correction:
    facts_sha256: str
    question_id: str
    relates_to: str
    field: str
    proposed: Any
    confirmed: Any
    answer: str
    at: str = field(default_factory=lambda: datetime.now(UTC).isoformat(timespec="seconds"))


@dataclass
class Confirmation:
    plan: GeometryPlan
    corrections: list[Correction]
    unanswered: list[str]
    unit: str | None = None
    purpose_change: str | None = None


def _norm(s: str) -> str:
    return " ".join(str(s).strip().lower().replace("_", " ").split())


def _pick(answer: str, options: list[str]) -> str:
    a = _norm(answer)
    for o in options:
        if _norm(o) == a:
            return o
    for o in options:
        if a and (a in _norm(o) or _norm(o) in a):
            return o
    return answer


def overrulable(plan: GeometryPlan) -> list[UserQuestion]:
    """The questions the brief answered, rebuilt from the simulation warnings that carry them (P4.4, checker R27):
    `provenance.asked` is False, `settled_by` names the brief phrase, and the question, its options and its
    default are still there. They are not asked, but an answer to one overrules what the brief decided, which is
    the whole point of never deleting a question: the user can still say otherwise."""
    out = []
    for w in plan.simulation_warnings or []:
        rid = w.provenance.get("risk_id")
        if w.question and w.provenance.get("asked") is False and isinstance(rid, str):
            out.append(UserQuestion(id=str(w.provenance.get("question_id") or w.id), text=w.question, options=list(w.options),
                                    relates_to=rid, default=w.default, also_settles=list(w.also_settles), effect=w.effect))
    return out


def apply_answers(plan: GeometryPlan, answers: dict[str, str]) -> Confirmation:
    """`answers` maps question id to the chosen option text (or free text). Unknown ids are ignored; unanswered
    questions are reported. Roles, risk decisions, unit and purpose are applied; the plan's flow lists follow.

    A question the brief answered (`overrulable`) is applied only when an answer names it, and never counts as
    unanswered: the plan already took the brief's reading, and an answer here is the user overruling it."""
    p = plan.model_copy(deep=True)
    corrections: list[Correction] = []
    unanswered = []
    unit = None
    purpose_change = None
    risks = {r.id: r for r in p.risks}
    patches = {x.id: x for x in p.patches}
    answers = dict(answers)
    # an answer keyed by a simulation warning's id (sw1) is the answer to that warning's question
    for w in p.simulation_warnings or []:
        qid = w.provenance.get("question_id")
        if w.id in answers and qid and qid not in answers:
            answers[qid] = answers[w.id]
    settled_risks: dict[str, tuple[str, str]] = {}

    def note(q, field_name, proposed, confirmed, answer, target=None):
        if proposed != confirmed:
            corrections.append(Correction(p.facts_sha256, q.id, target or q.relates_to, field_name, proposed, confirmed, answer))

    asked = list(p.questions)
    for q in [*asked, *(x for x in overrulable(p) if x.id in answers)]:
        if q.id not in answers:
            unanswered.append(q.id)
            continue
        raw = answers[q.id]
        choice = _pick(raw, q.options)
        key = _norm(choice)
        settled = False
        for rid in [q.relates_to, *q.also_settles]:
            settled_risks.setdefault(rid, (q.id, choice))
        for target in [q.relates_to, *q.also_settles]:
            if target == "unit":
                unit = choice.strip()
                settled = True
                continue
            if target == "purpose":
                purpose_change = choice.strip()
                settled = True
                continue
            if target in patches:
                role = _role_in(choice)
                if role is not None:
                    note(q, "role", patches[target].role, role, raw, target)
                    patches[target].role = role
                    patches[target].confirmed_by_user = True
                    settled = True
                continue
            if target in risks:
                r = risks[target]
                role = _role_in(choice)
                oid = r.measurement.get("opening_id")
                if role is not None and oid in patches:
                    note(q, "role", patches[oid].role, role, raw, target)
                    patches[oid].role = role
                    patches[oid].confirmed_by_user = True
                    r.user_decision = "fix" if role in ("inlet", "outlet") and r.kind == "undeclared_opening" else "continue"
                    settled = True
                    continue
                if r.kind == "role_assumed" and "reverse" in key:
                    for pid in r.measurement.get("inlet_ids", []) + r.measurement.get("outlet_ids", []):
                        if pid in patches and patches[pid].role in ("inlet", "outlet"):
                            new = "outlet" if patches[pid].role == "inlet" else "inlet"
                            note(q, "role", patches[pid].role, new, raw, target)
                            patches[pid].role = new
                            patches[pid].confirmed_by_user = True
                    note(q, "user_decision", r.user_decision, "fix", raw, target)
                    r.user_decision = "fix"
                    settled = True
                    continue
                decision = DECISION_WORDS.get(key)
                if decision is None and any(w in key.split() for w in ("yes", "ok", "accept", "keep", "fine")):
                    decision = "continue"
                if decision is None:
                    # free text nobody could map: leave the decision pending and say so, never guess "fix"
                    continue
                note(q, "user_decision", r.user_decision, decision, raw, target)
                r.user_decision = decision
                settled = True
        if not settled:
            unanswered.append(q.id)
    p.flow.inlet_ids = [x.id for x in p.patches if x.role == "inlet"]
    p.flow.outlet_ids = [x.id for x in p.patches if x.role == "outlet"]
    # schema 3: the answer to a question settles the simulation warning that carries it and every warning whose
    # risk the question also settles (also_settles); the warning records the answer and the question id
    for w in p.simulation_warnings or []:
        qid = w.provenance.get("question_id")
        hit = None
        if qid and qid in answers:
            hit = (qid, _pick(answers[qid], w.options or []))
        else:
            for rid in [w.provenance.get("risk_id"), *w.also_settles]:
                if rid in settled_risks:
                    hit = settled_risks[rid]
                    break
        if hit is not None:
            w.answer, w.settled_by = hit[1], hit[0]
    return Confirmation(plan=p, corrections=corrections, unanswered=unanswered, unit=unit, purpose_change=purpose_change)


def log_corrections(corrections: list[Correction], path: str | Path) -> int:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        for c in corrections:
            f.write(json.dumps(asdict(c), default=str) + "\n")
    return len(corrections)
