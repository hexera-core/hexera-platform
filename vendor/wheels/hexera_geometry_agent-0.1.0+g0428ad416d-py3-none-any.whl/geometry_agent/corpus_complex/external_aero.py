"""External aerodynamics: the everyday bodies a CFD service meets, built parametrically so every expectation is
derived from the dimensions that built the mesh.

What the construction fixes and the expectation asserts: how many bodies the file holds (regions, and with them
multi_body_external or its absence), that every body is closed, the clearance between the closest pair of bodies
(gap_between_regions, and gap_resolution / near_touching when that clearance is under three surface cells at
standard fidelity: base cell = diagonal / 80, surface cell = base / 4), the thinnest wall (thickness_min, and
thin_feature when it is under three surface cells), which mirror planes and which rotational order the geometry
has, whether the section near one end is the larger (blunt_end_sign, and from it the flow sign the brief fixes),
knife edges (a dihedral turn over 150 degrees: the trailing edge of a NACA section, never a box or a disc), and
for the simplest bodies the planar faces the opening finder must list.

Cases:
  car_box_arches_wheels        box body on axle-height underside, cabin flush at the rear, four arches cut in, four
                               separate wheels 12 mm inside their arches, on the ground z = 0
  cyclist_blunt_body_two_wheels  torso capsule and head on a beam frame, two 15 mm thin wheels 8 mm under the frame
  building_block_on_ground_plate  low-rise block with a lower annex on a 200 mm ground slab, one body, one mirror plane
  quadcopter_frame_four_rotors  square hub, four arms, four 2 mm rotor discs 4 mm above the arm tips: 4-fold
  ship_hull_below_waterline    lofted hull: elliptical entrance, parallel middle body, parabolic run to a transom
  heat_sink_fins_crossflow     base plate with 24 fins of 0.8 mm: thin_feature, thickness_min is the fin
  sphere_validation            icosphere: no openings, no risk but the domain, three planes, axisymmetric
  circular_cylinder_crossflow  L/D 10 cylinder: two end caps are the only planar faces, order 12 about its axis
  wind_turbine_rotor_3blade    hub plus three NACA0012 blades, one body: rotor_topology from 3-fold symmetry
  wind_turbine_rotor_named     the same rotor as an ASCII STL whose solid name says rotor: rotor_topology from the name
  bridge_deck_section          extruded box girder with two parapets: four planar faces, two mirror planes, order 2
  wing_with_flap_gap           NACA0012 wing and a deflected flap with an exactly known slot gap
  streamlined_fairing_blunt_base  round nose, cylinder, boat-tail to a flat base: the nose is the blunt end
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import trimesh
from trimesh.transformations import rotation_matrix

from geometry_agent.corpus import SECTIONS, Case, _box, _case, port
from geometry_agent.synthetic import _cyl, _union, naca0012

FAMILY = "external_aero"
OUT_DIR = Path("eval/corpus_complex") / FAMILY
EC = "external_cfd"

#: facts/estimate.py at standard fidelity: base cell = diagonal / 80, surface cell = base / 2**2
CELLS_ACROSS_DIAG = 80
SURFACE_LEVELS = 2
#: agent/catalog.py: thin_feature and gap_resolution / near_touching fire under this many surface cells
CELLS_MIN = 3.0
#: facts/features.py: a wall under this fraction of the diagonal is a thin cluster; a gap under this is near
THIN_OF_DIAG = 0.015
NEAR_OF_DIAG = 0.02
#: facts/axes.py: a blunt end needs the two end sections to differ by more than this fraction of the larger
BLUNT_CONF_MIN = 0.25
#: margin over every threshold: the expectation is only asserted when the construction clears it by this factor
MARGIN = 1.25


def _surface_cell(extent) -> float:
    return float(np.linalg.norm(extent)) / CELLS_ACROSS_DIAG / 2**SURFACE_LEVELS


def _diag(extent) -> float:
    return float(np.linalg.norm(extent))


def _band(v: float, rel: float = 0.05) -> list[float]:
    return [v * (1 - rel), v * (1 + rel)]


def _wall(near, d: float | None = None, stub: float | None = None, classification: str = "planar_face", stub_tol=None) -> dict:
    """An external body's flat face: whatever the finder calls it, its role is wall."""
    return port(near, "wall", d, stub, kind="cap", classification=classification, needs_model=False, stub_tol=stub_tol)


def _base_expect(regions: int, extent, extra_expect=(), extra_forbid=()) -> dict:
    """What every closed external body implies: the far-field domain, one body or several, never the internal
    risks, never a hole."""
    expect = ["external_domain"] + list(extra_expect)
    forbid = ["not_watertight", "surface_holes", "region_purpose_mismatch", "solid_wall_representation",
              "short_stub", "velocity_spread", "nested_bodies"] + list(extra_forbid)
    if regions > 1:
        expect.append("multi_body_external")
    else:
        forbid += ["multi_body_external", "gap_resolution"]
    return {"regions": regions, "watertight": True, "expect_risks": expect, "forbid_risks": forbid}


def _thin_terms(t_min: float, extent) -> tuple[list[str], list[str]]:
    """(expect, forbid) for thin_feature given the thinnest wall in the file and the bounding extent."""
    hs = _surface_cell(extent)
    diag = _diag(extent)
    if t_min < THIN_OF_DIAG * diag / MARGIN and t_min / hs < CELLS_MIN / MARGIN:
        return ["thin_feature"], []
    if t_min > THIN_OF_DIAG * diag * MARGIN or t_min / hs > CELLS_MIN * MARGIN:
        return [], ["thin_feature"]
    return [], []


def _gap_terms(gap: float, extent) -> tuple[list[str], list[str]]:
    """(expect, forbid) for gap_resolution and near_touching given the smallest clearance between two facing
    surfaces (of different bodies) and the bounding extent. near_touching needs the gap both under NEAR_OF_DIAG
    of the diagonal (so the ray pass counts it) and under CELLS_MIN surface cells; gap_resolution only the latter."""
    hs = _surface_cell(extent)
    diag = _diag(extent)
    expect, forbid = [], []
    if gap / hs < CELLS_MIN / MARGIN:
        expect.append("gap_resolution")
        if gap < NEAR_OF_DIAG * diag / MARGIN:
            expect.append("near_touching")
    elif gap / hs > CELLS_MIN * MARGIN:
        forbid += ["gap_resolution", "near_touching"]
    if gap > NEAR_OF_DIAG * diag * MARGIN and "near_touching" not in forbid:
        forbid.append("near_touching")
    return expect, forbid


def _clean(mesh: trimesh.Trimesh) -> trimesh.Trimesh:
    """Strip what a boolean leaves behind that is not surface: zero-area triangles (the manifold engine writes a
    folded pair where a blade root meets a hub) and the vertices they alone referenced."""
    mesh = mesh.copy()
    mesh.update_faces(mesh.nondegenerate_faces(height=1e-12))
    mesh.remove_unreferenced_vertices()
    mesh.merge_vertices()
    return mesh


def _extent(mesh: trimesh.Trimesh) -> tuple[float, float, float]:
    lo, hi = mesh.bounds
    return tuple(float(v) for v in hi - lo)


def _ngon_dh(r: float, n: int = SECTIONS) -> float:
    """Hydraulic diameter of the regular n-gon a tessellated circle of radius r really is: 2 r cos(pi/n)."""
    return 2 * r * math.cos(math.pi / n)


def _blunt_sign(a_lo: float, a_hi: float) -> int:
    """facts/axes.py _blunt_end: +1 when the section near the high end of the principal axis is the larger, -1
    when the low end is, 0 when they are within BLUNT_CONF_MIN of each other. The construction must clear the
    threshold by MARGIN or the sign is not asserted."""
    top = max(a_lo, a_hi)
    conf = abs(a_hi - a_lo) / top
    if conf < BLUNT_CONF_MIN * MARGIN:
        return 0
    return 1 if a_hi > a_lo else -1


# ---- lofts -------------------------------------------------------------------------------------------------------

def loft_half_sections(stations: np.ndarray, half_breadth: np.ndarray, draft: np.ndarray, n: int = 25) -> trimesh.Trimesh:
    """A hull below its waterline: at each station x a half-ellipse (y = b cos t, z = -d sin t, t in [0, pi]) hangs
    under the flat waterline plane z = 0. The first station is a point (the stem); the last is closed with a flat
    transom. Built face by face so it is closed and consistently oriented."""
    t = np.linspace(0.0, np.pi, n)
    rings = []
    for x, b, d in zip(stations[1:], half_breadth[1:], draft[1:]):
        rings.append(np.column_stack([np.full(n, x), b * np.cos(t), -d * np.sin(t)]))
    verts = [np.array([[stations[0], 0.0, 0.0]]), np.vstack(rings)]
    faces = []
    tip = 0
    r = lambda k, j: 1 + k * n + j  # noqa: E731
    for j in range(n - 1):
        faces.append([tip, r(0, j + 1), r(0, j)])
    faces.append([tip, r(0, 0), r(0, n - 1)])
    m = len(rings)
    for k in range(m - 1):
        for j in range(n - 1):
            faces.append([r(k, j), r(k, j + 1), r(k + 1, j + 1)])
            faces.append([r(k, j), r(k + 1, j + 1), r(k + 1, j)])
        faces.append([r(k, n - 1), r(k, 0), r(k + 1, 0)])
        faces.append([r(k, n - 1), r(k + 1, 0), r(k + 1, n - 1)])
    last = rings[-1]
    c = len(verts[0]) + len(verts[1])
    verts.append(last.mean(axis=0, keepdims=True))
    for j in range(n - 1):
        faces.append([c, r(m - 1, j), r(m - 1, j + 1)])
    faces.append([c, r(m - 1, n - 1), r(m - 1, 0)])
    mesh = trimesh.Trimesh(np.vstack(verts), np.asarray(faces), process=True)
    mesh.merge_vertices()
    trimesh.repair.fix_normals(mesh)
    return mesh


def revolve_pole(profile: list[tuple[float, float]], sections: int = SECTIONS) -> trimesh.Trimesh:
    """Solid of revolution about x whose first station is a point on the axis (a round nose) and whose last is
    closed with a flat cap."""
    stations = np.asarray([p[0] for p in profile], dtype=float)
    radii = np.asarray([p[1] for p in profile], dtype=float)
    ang = np.linspace(0, 2 * np.pi, sections, endpoint=False)
    rings = [np.column_stack([np.full(sections, s), r * np.cos(ang), r * np.sin(ang)]) for s, r in zip(stations[1:], radii[1:])]
    verts = [np.array([[stations[0], 0.0, 0.0]]), np.vstack(rings)]
    faces = []
    n = sections
    r = lambda k, j: 1 + k * n + j  # noqa: E731
    for i in range(n):
        j = (i + 1) % n
        faces.append([0, r(0, i), r(0, j)])
    for k in range(len(rings) - 1):
        for i in range(n):
            j = (i + 1) % n
            faces.append([r(k, i), r(k + 1, i), r(k + 1, j)])
            faces.append([r(k, i), r(k + 1, j), r(k, j)])
    c = 1 + len(rings) * n
    verts.append(np.array([[stations[-1], 0.0, 0.0]]))
    last = len(rings) - 1
    for i in range(n):
        j = (i + 1) % n
        faces.append([c, r(last, j), r(last, i)])
    mesh = trimesh.Trimesh(np.vstack(verts), np.asarray(faces), process=True)
    mesh.merge_vertices()
    trimesh.repair.fix_normals(mesh)
    return mesh


def _wheel(r: float, w: float, center) -> trimesh.Trimesh:
    """A wheel with its axle along y. trimesh's cylinder puts a vertex at local +x and one every 360/SECTIONS
    degrees, so after the quarter turn about x there is a vertex straight up and one straight down: the tread's
    top and bottom are vertices, and a clearance measured from them is exact."""
    m = trimesh.creation.cylinder(radius=r, height=w, sections=SECTIONS)
    m.apply_transform(rotation_matrix(np.pi / 2, [1, 0, 0]))
    m.apply_translation(center)
    return m


def _prism_from_polygon(pts_yz: list[tuple[float, float]], x0: float, x1: float) -> trimesh.Trimesh:
    """A polygon in the y-z plane extruded from x0 to x1 (its area must be positive with the points in
    counter-clockwise order in y, z)."""
    from shapely.geometry import Polygon
    m = trimesh.creation.extrude_polygon(Polygon(pts_yz), height=x1 - x0)
    # extrude_polygon builds in x-y extruded along z: map (u, v, w) -> (x = w + x0, y = u, z = v)
    T = np.array([[0.0, 0.0, 1.0, x0], [1.0, 0.0, 0.0, 0.0], [0.0, 1.0, 0.0, 0.0], [0.0, 0.0, 0.0, 1.0]])
    m.apply_transform(T)
    trimesh.repair.fix_normals(m)
    return m


# ---- passenger car -----------------------------------------------------------------------------------------------

def car_box_arches_wheels(L: float = 4.2, W: float = 1.8, H1: float = 0.55, cabin_L: float = 2.4, cabin_W: float = 1.6,
                          cabin_H: float = 0.55, wheel_r: float = 0.32, wheel_w: float = 0.22,
                          gap: float = 0.012, x_front_axle: float = 0.8, x_rear_axle: float = 3.4):
    """Lower box whose underside is at axle height (z = wheel_r), a cabin box flush with the rear end on top, four
    arches (half-cylinders of radius wheel_r + gap along y, wheel_w + gap deep from each side) cut out, and four
    wheels touching the ground at z = 0 sitting inside them. Everything is derived: the clearance between wheel
    and arch is `gap` at every angle (the wheel and the arch cut share SECTIONS and phase); the arch meets the
    underside at a right angle (its axis lies in that plane), so no wedge thins out there and the roof over a
    front arch is the thinnest wall of the body; the rear section carries the cabin and the front does not."""
    clearance = wheel_r
    lower = _box((L, W, H1), (L / 2, 0, clearance + H1 / 2))
    cabin = _box((cabin_L, cabin_W, cabin_H), (L - cabin_L / 2, 0, clearance + H1 + cabin_H / 2))
    body = _union([lower, cabin])
    cuts, wheels = [], []
    depth = wheel_w + gap
    for x in (x_front_axle, x_rear_axle):
        for sgn in (-1, 1):
            cut = _wheel(wheel_r + gap, depth + 0.05, (x, sgn * (W / 2 - depth / 2 + 0.025), wheel_r))
            cuts.append(cut)
            wheels.append(_wheel(wheel_r, wheel_w, (x, sgn * (W / 2 - wheel_w / 2), wheel_r)))
    body = _clean(trimesh.boolean.difference([body] + cuts, engine="manifold"))
    mesh = trimesh.util.concatenate([body] + wheels)
    extent = _extent(mesh)
    t_roof = (clearance + H1) - (2 * wheel_r + gap)     # lower box top minus the top of a front arch
    t_min = min(wheel_w, t_roof, W - 2 * depth)
    thin_e, thin_f = _thin_terms(t_min, extent)
    gap_e, gap_f = _gap_terms(gap, extent)
    exp = _base_expect(5, extent, thin_e + gap_e, thin_f + gap_f + ["knife_edge", "rotor_topology"])
    exp.update({"gap_between_regions_between": [0.97 * gap, 1.03 * gap], "thickness_min_between": _band(t_min),
                "symmetry_planes_min": 1, "ground_plane_z": 0.0})
    # sections 6% in from each end along x: the front is the lower box alone, the rear carries the cabin too
    a_front = W * H1
    a_rear = W * H1 + cabin_W * cabin_H
    blunt = _blunt_sign(a_front, a_rear)
    if blunt:
        # the brief puts the nose at -x; air moves +x over the car. The measured blunt end is the rear (+x), so a
        # policy that reads the blunt end as the leading edge gets this backwards: the brief decides.
        exp["flow_direction_sign"] = 1
        exp["blunt_end_sign_measured"] = blunt
    return mesh, exp


# ---- cyclist -----------------------------------------------------------------------------------------------------

def cyclist_two_wheels(wheel_r: float = 0.35, wheel_w: float = 0.015, wheelbase: float = 1.05, gap: float = 0.008,
                       beam: float = 0.05, torso_r: float = 0.16, torso_h: float = 0.5, lean_deg: float = 40.0,
                       head_r: float = 0.12):
    """Two thin wheels on the ground at z = 0, a beam frame `gap` above their tops joined to a seat post, a
    torso capsule leaning forward and a head sphere: three bodies. The wheels are the thinnest walls, and the
    clearance between a wheel's top vertex and the beam's underside is the closest approach of two bodies."""
    wheels = [_wheel(wheel_r, wheel_w, (0.0, 0.0, wheel_r)), _wheel(wheel_r, wheel_w, (wheelbase, 0.0, wheel_r))]
    z_beam = 2 * wheel_r + gap
    frame = _box((wheelbase + 2 * wheel_r * 0.2, beam, beam), (wheelbase / 2, 0, z_beam + beam / 2))
    x_post = wheelbase * 0.55
    z_seat = z_beam + beam + 0.25
    post = _box((beam, beam, z_seat - z_beam - beam + 0.02), (x_post, 0, (z_beam + beam + z_seat + 0.02) / 2 - 0.01))
    a = np.radians(lean_deg)
    axis = np.array([np.sin(a), 0.0, np.cos(a)])
    base = np.array([x_post, 0.0, z_seat + torso_r * 0.6])      # lower end of the capsule's cylinder
    torso = trimesh.creation.capsule(height=torso_h, radius=torso_r, count=[24, 24])
    torso.apply_transform(rotation_matrix(a, [0, 1, 0]))
    torso.apply_translation(base + axis * torso_h / 2)
    head = trimesh.creation.icosphere(subdivisions=3, radius=head_r)
    head.apply_translation(base + axis * (torso_h + torso_r + head_r * 0.6))
    rider = _clean(_union([frame, post, torso, head]))
    mesh = trimesh.util.concatenate([rider] + wheels)
    extent = _extent(mesh)
    thin_e, thin_f = _thin_terms(wheel_w, extent)
    gap_e, gap_f = _gap_terms(gap, extent)
    exp = _base_expect(3, extent, thin_e + gap_e, thin_f + gap_f + ["knife_edge", "rotor_topology"])
    exp.update({"gap_between_regions_between": [0.97 * gap, 1.03 * gap], "thickness_min_between": _band(wheel_w),
                "symmetry_planes_min": 1, "ground_plane_z": 0.0})
    return mesh, exp


# ---- building on a ground plate ----------------------------------------------------------------------------------

def building_on_plate(plate=(40.0, 30.0, 0.2), main=(10.0, 8.0, 12.0), annex=(6.0, 6.0, 5.0), x_main: float = -4.0):
    """A ground slab with a main block and a lower annex against its +x side, all one body, centred in y only."""
    px, py, pz = plate
    mx, my, mz = main
    ax, ay, az = annex
    slab = _box(plate, (0, 0, -pz / 2))
    block = _box(main, (x_main, 0, mz / 2))
    wing = _box(annex, (x_main + mx / 2 + ax / 2, 0, az / 2))
    mesh = _clean(_union([slab, block, wing]))
    extent = _extent(mesh)
    thin_e, thin_f = _thin_terms(pz, extent)
    exp = _base_expect(1, extent, thin_e, thin_f + ["knife_edge", "rotor_topology", "near_touching"])
    exp.update({"thickness_min_between": _band(pz), "symmetry_planes_min": 1, "ground_plane_z": 0.0})
    return mesh, exp


# ---- quadcopter --------------------------------------------------------------------------------------------------

def quadcopter(hub: float = 0.10, hub_h: float = 0.03, arm_len: float = 0.16, arm_w: float = 0.015, arm_t: float = 0.008,
               disc_r: float = 0.06, disc_t: float = 0.002, gap: float = 0.004):
    """Square hub, four arms along +-x and +-y, and above each arm tip a thin rotor disc floating `gap` above the
    arm's top face: five bodies with 4-fold symmetry about z and mirror planes x = 0, y = 0 and both diagonals."""
    parts = [_box((hub, hub, hub_h))]
    for k in range(4):
        arm = _box((arm_len + hub / 2, arm_w, arm_t), (hub / 4 + arm_len / 2, 0, 0))
        arm.apply_transform(rotation_matrix(k * np.pi / 2, [0, 0, 1]))
        parts.append(arm)
    frame = _clean(_union(parts))
    discs = []
    for k in range(4):
        d = trimesh.creation.cylinder(radius=disc_r, height=disc_t, sections=SECTIONS)
        d.apply_translation([hub / 2 + arm_len - disc_r * 0.6, 0, arm_t / 2 + gap + disc_t / 2])
        d.apply_transform(rotation_matrix(k * np.pi / 2, [0, 0, 1]))
        discs.append(d)
    mesh = trimesh.util.concatenate([frame] + discs)
    extent = _extent(mesh)
    thin_e, thin_f = _thin_terms(disc_t, extent)
    gap_e, gap_f = _gap_terms(gap, extent)
    exp = _base_expect(5, extent, thin_e + gap_e, thin_f + gap_f + ["knife_edge"])
    exp.update({"gap_between_regions_between": [0.97 * gap, 1.03 * gap], "thickness_min_between": _band(disc_t),
                "symmetry_planes_min": 2, "rotational_symmetry_order": 4})
    return mesh, exp


# ---- ship hull ---------------------------------------------------------------------------------------------------

def ship_hull(L: float = 7.0, B: float = 1.0, T: float = 0.4, entrance: float = 0.3, run_start: float = 0.6,
              transom_s: float = 0.9, n_stations: int = 121):
    """Half-breadth b(x): elliptical entrance to 0.3 L, full beam to 0.6 L, parabolic run b = B/2 (1 - s^2) with
    s = (x - 0.6 L) / (0.4 L), cut by a transom at s = transom_s. Draft d = T sqrt(2 b / B). The stem is a point.
    The section near the bow (6% of the length in) is far larger than the section near the transom, so the bow is
    the blunt end by area and the flow the brief fixes (bow at -x) runs +x."""
    x_end = L * (run_start + transom_s * (1 - run_start))
    xs = np.concatenate([np.linspace(0.0, entrance * L, 61)[:-1], np.linspace(entrance * L, run_start * L, 11)[:-1],
                         np.linspace(run_start * L, x_end, 49)])

    def half_breadth(x):
        x = np.asarray(x, dtype=float)
        b = np.full_like(x, B / 2)
        e = x < entrance * L
        b[e] = B / 2 * np.sqrt(np.clip(1 - ((entrance * L - x[e]) / (entrance * L)) ** 2, 0, 1))
        r = x > run_start * L
        b[r] = B / 2 * (1 - ((x[r] - run_start * L) / ((1 - run_start) * L)) ** 2)
        return b

    def draft(x):
        return T * np.sqrt(np.clip(half_breadth(x) / (B / 2), 0, 1))

    bs, ds = half_breadth(xs), draft(xs)
    mesh = loft_half_sections(xs, bs, ds)
    extent = _extent(mesh)
    a_lo = math.pi / 2 * float(half_breadth(0.06 * x_end)) * float(draft(0.06 * x_end))
    a_hi = math.pi / 2 * float(half_breadth(0.94 * x_end)) * float(draft(0.94 * x_end))
    blunt = _blunt_sign(a_lo, a_hi)
    thin_e, thin_f = _thin_terms(2 * float(half_breadth(0.5 * x_end)), extent)   # the hull is a solid: nothing thin
    exp = _base_expect(1, extent, thin_e, thin_f + ["knife_edge", "rotor_topology", "near_touching"])
    exp.update({"symmetry_planes_min": 1})
    if blunt == -1:
        exp["flow_direction_sign"] = 1
        exp["blunt_end_sign_measured"] = blunt
    return mesh, exp


# ---- finned heat sink --------------------------------------------------------------------------------------------

def heat_sink(base=(0.10, 0.06, 0.008), n_fins: int = 24, fin_t: float = 0.0008, fin_h: float = 0.03):
    """A base plate with n_fins fins along x, evenly spaced across y from edge to edge; the fins set the thinnest
    wall and the fin spacing is wide enough not to be a near-touching gap. One body, mirror planes x and y, a
    half turn about z."""
    bx, by, bz = base
    parts = [_box(base, (0, 0, bz / 2))]
    pitch = (by - fin_t) / (n_fins - 1)
    for k in range(n_fins):
        y = -by / 2 + fin_t / 2 + k * pitch
        parts.append(_box((bx, fin_t, fin_h + 0.001), (0, y, bz + fin_h / 2 - 0.0005)))
    mesh = _clean(_union(parts))
    extent = _extent(mesh)
    thin_e, thin_f = _thin_terms(fin_t, extent)
    spacing = pitch - fin_t
    gap_e, gap_f = _gap_terms(spacing, extent)
    # a single body: gap_resolution never applies, near_touching only if the fin spacing is near
    exp = _base_expect(1, extent, thin_e + [k for k in gap_e if k == "near_touching"],
                       thin_f + ["knife_edge", "rotor_topology"] + [k for k in gap_f if k == "near_touching"])
    exp.update({"thickness_min_between": _band(fin_t), "symmetry_planes_min": 2, "rotational_symmetry_order": 2,
                "fin_count": n_fins, "fin_spacing": spacing})
    return mesh, exp


# ---- validation bodies -------------------------------------------------------------------------------------------

def sphere(R: float = 0.5):
    mesh = trimesh.creation.icosphere(subdivisions=4, radius=R)
    extent = _extent(mesh)
    exp = _base_expect(1, extent, [], ["thin_feature", "knife_edge", "rotor_topology", "near_touching"])
    exp.update({"openings": 0, "symmetry_planes_min": 3, "rotational_symmetry_order": 12,
                "thickness_min_between": [1.9 * R, 2.0 * R * 1.001]})
    return mesh, exp


def cylinder_crossflow(D: float = 0.10, L_over_D: float = 10.0):
    L = L_over_D * D
    mesh = _cyl(D / 2, L, "z", (0, 0, -L / 2))
    extent = _extent(mesh)
    exp = _base_expect(1, extent, [], ["thin_feature", "knife_edge", "rotor_topology", "near_touching"])
    dh = _ngon_dh(D / 2)
    ports = [_wall((0, 0, -L / 2), dh, L / dh, classification="port_candidate", stub_tol=max(0.3, 0.12 * L / dh)),
             _wall((0, 0, L / 2), dh, L / dh, classification="port_candidate", stub_tol=max(0.3, 0.12 * L / dh))]
    exp.update({"openings": 2, "port_candidates": 2, "ports": ports, "symmetry_planes_min": 3, "rotational_symmetry_order": 12,
                "thickness_min_between": [0.95 * D, 1.01 * D]})
    return mesh, exp


# ---- wind turbine rotor ------------------------------------------------------------------------------------------

def turbine_rotor(R: float = 1.0, r_hub: float = 0.12, hub_len: float = 0.25, chord: float = 0.10, blades: int = 3):
    """Hub (a cylinder about x, the rotor axis) plus `blades` untwisted NACA0012 blades whose span runs radially,
    chord along x, one body. Each blade's chord plane is a mirror plane, so there are `blades` mirror planes
    through the axis and none normal to it (blunt leading edge, sharp trailing edge)."""
    hub = _cyl(r_hub, hub_len, "x", (-hub_len / 2, 0, 0))
    parts = [hub]
    span = R - r_hub + 0.03
    for k in range(blades):
        b = naca0012(chord=chord, span=span, n=80)
        b.apply_translation([-chord * 0.35, 0, span / 2 + r_hub - 0.03])
        b.apply_transform(rotation_matrix(2 * np.pi * k / blades, [1, 0, 0]))
        parts.append(b)
    mesh = _clean(_union(parts))
    extent = _extent(mesh)
    t_blade = 0.12 * chord
    thin_e, thin_f = _thin_terms(t_blade, extent)
    exp = _base_expect(1, extent, thin_e + ["knife_edge", "rotor_topology"], thin_f + ["near_touching"])
    exp.update({"rotational_symmetry_order": blades, "symmetry_planes_min": blades})
    return mesh, exp


# ---- bridge deck -------------------------------------------------------------------------------------------------

def bridge_deck(span: float = 60.0, top_w: float = 12.0, bot_w: float = 10.0, depth: float = 2.5,
                parapet_w: float = 0.3, parapet_h: float = 1.2):
    """A trapezoidal box girder extruded along x with a parapet along each deck edge. The two end faces are the
    only faces with a long constant section behind them; the deck top and the soffit are planar faces of the body
    (the girder section changes within a fraction of their hydraulic diameter); the webs and the parapet faces
    are strips over 10:1 and are not listed. The webs lean 22 degrees off vertical, so their normals are 68
    degrees off the soffit's (past facts/openings.py WALL_COS = 0.45, 63 degrees): the soffit's rim is wall."""
    from shapely.geometry import Polygon
    profile = [(-top_w / 2, 0.0), (-bot_w / 2, -depth), (bot_w / 2, -depth), (top_w / 2, 0.0)]
    girder = _prism_from_polygon(profile, 0.0, span)
    parapets = [_box((span, parapet_w, parapet_h + 0.01), (span / 2, sgn * (top_w - parapet_w) / 2, parapet_h / 2 - 0.005)) for sgn in (-1, 1)]
    mesh = _clean(_union([girder] + parapets))
    extent = _extent(mesh)
    end = Polygon(profile).union(Polygon([(-top_w / 2, 0), (-top_w / 2, parapet_h), (-top_w / 2 + parapet_w, parapet_h), (-top_w / 2 + parapet_w, 0)])) \
        .union(Polygon([(top_w / 2 - parapet_w, 0), (top_w / 2 - parapet_w, parapet_h), (top_w / 2, parapet_h), (top_w / 2, 0)]))
    dh_end = 4 * end.area / end.length
    stub = span / dh_end
    thin_e, thin_f = _thin_terms(parapet_w, extent)
    exp = _base_expect(1, extent, thin_e, thin_f + ["knife_edge", "rotor_topology", "near_touching"])
    # the finder places a face at the mean of its outline's vertices, not at the area centroid
    outline = np.asarray(end.exterior.coords)[:-1]
    zc = float(outline[:, 1].mean())
    inner = top_w - 2 * parapet_w
    ports = [_wall((0.0, 0.0, zc), dh_end, stub, classification="port_candidate", stub_tol=max(0.3, 0.12 * stub)),
             _wall((span, 0.0, zc), dh_end, stub, classification="port_candidate", stub_tol=max(0.3, 0.12 * stub)),
             _wall((span / 2, 0.0, 0.0), 2 * span * inner / (span + inner)),
             _wall((span / 2, 0.0, -depth), 2 * span * bot_w / (span + bot_w))]
    exp.update({"openings": 4, "port_candidates": 2, "planar_faces_min": 2, "ports": ports,
                "thickness_min_between": _band(parapet_w), "symmetry_planes_min": 2, "rotational_symmetry_order": 2})
    return mesh, exp


# ---- wing with flap ----------------------------------------------------------------------------------------------

def wing_with_flap(chord: float = 0.5, span: float = 3.0, flap_chord: float = 0.15, deflection_deg: float = 20.0,
                   overlap: float = 0.03, drop: float = 0.015):
    """NACA0012 main element and a NACA0012 flap deflected nose-down about its own leading edge, which sits
    `overlap` ahead of the main trailing edge and `drop` below the chord line. Both are extrusions along y over
    the same span, so the closest approach of the two bodies is the 2D distance between the two section polygons,
    computed exactly here. Two bodies, one mirror plane (mid-span), knife edges at both trailing edges."""
    from shapely.geometry import Polygon

    def section(c: float):
        beta = np.linspace(0, np.pi, 80)
        x = 0.5 * (1 - np.cos(beta))
        yt = 5 * 0.12 * (0.2969 * np.sqrt(x) - 0.1260 * x - 0.3516 * x**2 + 0.2843 * x**3 - 0.1036 * x**4)
        pts = np.vstack([np.column_stack([x, yt]), np.column_stack([x[::-1], -yt[::-1]])[1:-1]]) * c
        return pts

    main_pts = section(chord)
    a = np.radians(-deflection_deg)
    Rm = np.array([[np.cos(a), -np.sin(a)], [np.sin(a), np.cos(a)]])
    flap_pts = section(flap_chord) @ Rm.T + np.array([chord - overlap, -drop])
    gap = float(Polygon(main_pts).distance(Polygon(flap_pts)))
    assert gap > 0, "flap intersects the main element"

    def extrude(pts):
        m = trimesh.creation.extrude_polygon(Polygon(pts), height=span)
        m.apply_translation([0, 0, -span / 2])
        m.apply_transform(rotation_matrix(-np.pi / 2, [1, 0, 0]))   # z (span) -> y, thickness -> z
        trimesh.repair.fix_normals(m)
        return m

    main, flap = extrude(main_pts), extrude(flap_pts)
    mesh = trimesh.util.concatenate([main, flap])
    extent = _extent(mesh)
    gap_e, gap_f = _gap_terms(gap, extent)
    # the trailing-edge wedge is thinner than any cell at any tier: thin_feature is certain
    exp = _base_expect(2, extent, ["thin_feature", "knife_edge"] + gap_e, gap_f + ["rotor_topology"])
    exp.update({"gap_between_regions_between": [0.97 * gap, 1.03 * gap], "symmetry_planes_min": 1, "slot_gap": gap})
    return mesh, exp


# ---- streamlined fairing -----------------------------------------------------------------------------------------

def fairing(R: float = 0.15, L: float = 1.2, x_cyl_end: float = 0.6, r_base: float = 0.06):
    """Hemispherical nose from x = 0, cylinder to x_cyl_end, straight boat-tail to a flat base of radius r_base at
    x = L. By section area the nose is the blunt end (6% in from the nose the sphere is already wide; 6% in from
    the base the tail is narrow), so a flow read from the blunt end runs +x, which is also what the brief says.
    The base is a flat face with a widening cone behind it: a planar face, not a port."""
    nose = [(x, math.sqrt(max(R * R - (R - x) ** 2, 0.0))) for x in np.linspace(0, R, 13)[1:]]
    profile = [(0.0, 0.0)] + nose + [(x_cyl_end, R), (L, r_base)]
    mesh = revolve_pole(profile)
    extent = _extent(mesh)

    def radius_at(x):
        if x <= R:
            return math.sqrt(max(R * R - (R - x) ** 2, 0.0))
        if x <= x_cyl_end:
            return R
        return R + (r_base - R) * (x - x_cyl_end) / (L - x_cyl_end)

    a_lo, a_hi = (math.pi * radius_at(f * L) ** 2 for f in (0.06, 0.94))
    blunt = _blunt_sign(a_lo, a_hi)
    exp = _base_expect(1, extent, [], ["thin_feature", "knife_edge", "rotor_topology", "near_touching"])
    exp.update({"openings": 1, "port_candidates": 0, "planar_faces_min": 1,
                "ports": [_wall((L, 0, 0), _ngon_dh(r_base))], "symmetry_planes_min": 2, "rotational_symmetry_order": 12})
    if blunt == -1:
        exp["flow_direction_sign"] = 1
        exp["blunt_end_sign_measured"] = blunt
    return mesh, exp


# ---- the family --------------------------------------------------------------------------------------------------

@dataclass
class AsciiCase(Case):
    """A case written as an ASCII STL carrying a solid name, so the names layer has something to read."""
    solid_name: str = ""

    def write(self, out: Path) -> Path:
        d = out / self.name
        d.mkdir(parents=True, exist_ok=True)
        geo = d / "geometry.stl"
        if not geo.exists():
            m = self.build()
            m.metadata["name"] = self.solid_name
            geo.write_text(trimesh.exchange.stl.export_stl_ascii(m), encoding="ascii")
        return super().write(out)


def build_cases() -> list[Case]:
    cases: list[Case] = []
    add = cases.append
    add(_case("car_box_arches_wheels", FAMILY, EC, lambda: car_box_arches_wheels(),
              brief="Passenger car, simplified: 4.2 m box body with a cabin at the back, four wheels in their arches, standing on the ground plane z = 0. The nose is at -x; we want drag at 30 m/s.",
              note="five bodies; wheel-to-arch clearance 12 mm is under one surface cell; the roof over the front arch is the thinnest wall; the big end by section is the rear, the brief says the nose is at -x"))
    add(_case("cyclist_blunt_body_two_wheels", FAMILY, EC, lambda: cyclist_two_wheels(),
              brief="Rider on a bicycle, simplified to a torso and head over a beam frame with two wheels on the ground. Head wind, drag and the wake behind the rider.",
              note="three bodies; 15 mm wheels are the thin feature; 8 mm between wheel top and frame is the closest approach"))
    add(_case("building_block_on_ground_plate", FAMILY, EC, lambda: building_on_plate(),
              brief="Low-rise building with a lower annex on a flat ground slab; pedestrian-level wind around it.",
              note="one body; the 200 mm slab is thin at this scale; one mirror plane (y) because the annex sits on one side"))
    add(_case("quadcopter_frame_four_rotors", FAMILY, EC, lambda: quadcopter(),
              brief="Quadcopter frame with four rotor discs above the arm tips; hover in still air.",
              note="five bodies; 2 mm discs 4 mm above the arms; 4-fold about z, four mirror planes"))
    add(_case("ship_hull_below_waterline", FAMILY, EC, lambda: ship_hull(),
              brief="Ship hull below the waterline, bow at -x, 7 m long; resistance at 4 m/s in calm water.",
              note="one lofted body, waterline plane is flat; the elliptical entrance makes the bow the blunt end by section, which agrees with the brief"))
    add(_case("heat_sink_fins_crossflow", FAMILY, EC, lambda: heat_sink(),
              brief="Finned heat sink, 24 fins of 0.8 mm on a 100 by 60 base, air blowing along the fins at 3 m/s.",
              note="one body; the fins are the thin feature and set thickness_min; fin spacing 1.8 mm is wider than a near-touching gap"))
    add(_case("sphere_validation", FAMILY, EC, lambda: sphere(),
              brief="Sphere, 1 m diameter, drag validation against the standard curve.",
              note="no planar face at all: zero openings; three mirror planes and axisymmetric about any axis"))
    add(_case("circular_cylinder_crossflow", FAMILY, EC, lambda: cylinder_crossflow(),
              brief="Circular cylinder, 100 mm diameter and 1 m long, in cross-flow: vortex shedding.",
              note="the two end caps are planar faces with a 10 D constant section behind them; order 12 about the axis, three mirror planes"))
    add(_case("wind_turbine_rotor_3blade", FAMILY, EC, lambda: turbine_rotor(),
              brief="Three-blade wind turbine rotor, 2 m diameter, 300 rpm about x; torque at 10 m/s wind.",
              note="one body, no rotating zone: rotor_topology from 3-fold symmetry plus thin blades; three mirror planes through the axis"))
    cases.append(AsciiCase(name="wind_turbine_rotor_named", family=FAMILY, purpose=EC, build=lambda: turbine_rotor()[0],
                           expected={**turbine_rotor()[1], "names_min": 1}, solid_name="rotor_3blade_hub",
                           brief="Wind turbine rotor, 2 m diameter, exported from CAD with the solid named.",
                           note="same rotor as an ASCII STL whose solid line names it rotor: rotor_topology from the name"))
    add(_case("bridge_deck_section", FAMILY, EC, lambda: bridge_deck(),
              brief="Bridge deck: 60 m of box girder with a parapet along each edge, wind across the deck at 25 m/s.",
              note="four planar faces: two ends with 15 D behind them, the deck top and the soffit; the 300 mm parapets are thin; two mirror planes, a half turn about z"))
    add(_case("wing_with_flap_gap", FAMILY, EC, lambda: wing_with_flap(),
              brief="Wing with a single slotted flap deflected 20 degrees, 3 m span, 0.5 m chord; lift and drag at 50 m/s.",
              note="two bodies; the slot gap is the exact 2D distance between the two section polygons; trailing edges are knife edges"))
    add(_case("streamlined_fairing_blunt_base", FAMILY, EC, lambda: fairing(),
              brief="Streamlined fairing, round nose at -x, boat-tail to a flat base at +x, 1.2 m long; base drag at 40 m/s.",
              note="one body of revolution; the flat base is a planar face with a widening cone behind it, not a port; the round nose is the blunt end by section"))
    return cases


def write_family(out: Path = OUT_DIR) -> list[Path]:
    out.mkdir(parents=True, exist_ok=True)
    return [c.write(out) for c in build_cases()]


def main() -> None:
    for p in write_family():
        print(p)


if __name__ == "__main__":
    main()
