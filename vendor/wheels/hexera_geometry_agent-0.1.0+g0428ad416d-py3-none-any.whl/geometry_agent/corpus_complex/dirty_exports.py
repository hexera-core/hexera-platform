"""dirty_exports: the ways real CAD exports are broken, applied to otherwise clean parts.

Every case starts from a part whose facts are known from construction (the straight pipe and the short-stub
manifold of synthetic.py) and applies one export defect: duplicated faces, a flipped patch, needle triangles,
an internal baffle sharing an edge with the wall, floating debris, a mixed-unit assembly, jittered vertex
copies, degenerate triangles, an inside-out shell, the whole body exported twice, and an ASCII STL whose
'solid' header names the part. The expectations describe the part, not the defect: a closed pipe with two
ports stays a closed pipe with two ports whatever the exporter did to its triangles, so a check that fails
here is a place where the measurement layer reports the defect instead of the part (or crashes on it).
Where the defect really changes the answer (a non-manifold baffle, a second body in another unit) the
expectation says so and the note says why.

Run:  python -m geometry_agent.corpus_complex.dirty_exports
      python eval/run_eval.py eval/corpus_complex/dirty_exports --workers 3 -v --isolated --results-dir eval/results/dirty_exports
"""
from __future__ import annotations

import json
import math
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import trimesh

from geometry_agent.corpus import Case, _box, port, revolve_closed
from geometry_agent.synthetic import _union, manifold, pipe

FAMILY = "dirty_exports"
OUT_DIR = Path("eval/corpus_complex") / FAMILY

PIPE_D = 0.05
PIPE_L = 0.5
PIPE_STUB_OVER_D = PIPE_L / PIPE_D  # 10: a straight pipe's stub runs the whole length

# synthetic.manifold(1.5): main D 0.10 along x, 0.60 long; two D 0.04 branches at x = 0.2, 0.4 along +y,
# each 1.5 branch diameters above the main bore (tip at y = 0.05 + 0.06 = 0.11).
MAN_D_MAIN, MAN_D_BRANCH, MAN_LEN, MAN_STUB = 0.10, 0.04, 0.60, 1.5
MAN_TIP_Y = MAN_D_MAIN / 2 + MAN_STUB * MAN_D_BRANCH
MAN_BRANCH_X = (MAN_LEN / 3, 2 * MAN_LEN / 3)


# ---- writing -------------------------------------------------------------------------------------------------

def _write_ascii_stl(triangles: np.ndarray, path: Path, name: str) -> None:
    """ASCII STL at full double precision (binary STL is float32, which would round a 1e-9 jitter away)."""
    tri = np.asarray(triangles, dtype=float)
    n = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
    n = n / np.maximum(np.linalg.norm(n, axis=1), 1e-300)[:, None]
    lines = [f"solid {name}"]
    for (a, b, c), nn in zip(tri, n):
        lines.append(f"  facet normal {nn[0]:.9g} {nn[1]:.9g} {nn[2]:.9g}")
        lines.append("    outer loop")
        for v in (a, b, c):
            lines.append(f"      vertex {v[0]:.17g} {v[1]:.17g} {v[2]:.17g}")
        lines.append("    endloop")
        lines.append("  endfacet")
    lines.append(f"endsolid {name}")
    path.write_text("\n".join(lines) + "\n", encoding="ascii")


@dataclass
class DirtyCase(Case):
    """A Case that can be written as ASCII STL with a named solid; otherwise identical to corpus.Case."""
    ascii_name: str | None = None

    def write(self, out: Path) -> Path:
        d = out / self.name
        d.mkdir(parents=True, exist_ok=True)
        geo = d / "geometry.stl"
        if not geo.exists():
            m = self.build()
            if self.ascii_name is not None:
                _write_ascii_stl(np.asarray(m.triangles), geo, self.ascii_name)
            else:
                m.export(geo)
        exp = {"purpose": self.purpose, "family": self.family, **self.expected}
        if self.brief:
            exp["brief"] = self.brief
        if self.note:
            exp["note"] = self.note
        (d / "expected.json").write_text(json.dumps(exp, indent=1, default=float))
        return d


# ---- helpers -------------------------------------------------------------------------------------------------

def _raw(vertices, faces) -> trimesh.Trimesh:
    """A mesh exactly as given: no vertex merge, no face cleanup. The defect must survive to the file."""
    return trimesh.Trimesh(np.asarray(vertices, dtype=float), np.asarray(faces, dtype=np.int64), process=False)


def _fine_pipe(levels: int = 2) -> trimesh.Trimesh:
    """The straight pipe with its wall split along the length, so a patch of wall triangles can be picked."""
    m = pipe(PIPE_D, PIPE_L)
    for _ in range(levels):
        m = m.subdivide()
    m.merge_vertices()
    return m


def _wall_faces(m: trimesh.Trimesh) -> np.ndarray:
    return np.where(np.abs(m.face_normals[:, 0]) < 0.5)[0]


def _pipe_ports(stub: float | None = PIPE_STUB_OVER_D, stub_tol: float | None = None) -> list[dict]:
    return [port((0, 0, 0), "any", PIPE_D, stub, needs_model=True, stub_tol=stub_tol),
            port((PIPE_L, 0, 0), "any", PIPE_D, stub, needs_model=True, stub_tol=stub_tol)]


def _manifold_ports() -> list[dict]:
    ports = [port((0, 0, 0), "any", MAN_D_MAIN, None, needs_model=True),
             port((MAN_LEN, 0, 0), "any", MAN_D_MAIN, None, needs_model=True)]
    ports += [port((x, MAN_TIP_Y, 0), "outlet", MAN_D_BRANCH, MAN_STUB, needs_model=True) for x in MAN_BRANCH_X]
    return ports


CLEAN_PIPE_FORBID = ["not_watertight", "surface_holes", "region_purpose_mismatch", "nested_bodies"]


def _clean_pipe_expect(**extra) -> dict:
    exp = {"openings": 2, "regions": 1, "watertight": True, "port_candidates": 2, "ports": _pipe_ports(),
           "forbid_risks": list(CLEAN_PIPE_FORBID), "expect_risks": []}
    exp.update(extra)
    return exp


# ---- constructions -------------------------------------------------------------------------------------------

def dup_faces_wall_patch():
    """A patch of wall triangles copied in place (same vertices, same winding): what an exporter does when a
    face is listed in two shells. The surface still encloses the pipe's volume; no edge is open."""
    m = _fine_pipe(2)
    c = m.triangles_center
    wall = _wall_faces(m)
    patch = wall[(c[wall, 0] > 0.15) & (c[wall, 0] < 0.30) & (c[wall, 2] > 0.7 * PIPE_D / 2)]
    faces = np.vstack([m.faces, m.faces[patch]])
    out = _raw(m.vertices, faces)
    exp = _clean_pipe_expect()
    exp["construction"] = f"straight pipe D {PIPE_D} L {PIPE_L}; {len(patch)} wall triangles duplicated in place (edges of the patch carry 3 or 4 faces)"
    exp["should"] = ("closed volume with two D 0.05 ports and 10 D stubs; the duplicates are removable (exact copies) and are not holes, "
                     "not extra bodies and not openings")
    return out, exp


def flipped_normals_patch():
    """The wall between x = 0.1 and 0.35 wound the other way. Every edge still has exactly two faces."""
    m = _fine_pipe(2)
    c = m.triangles_center
    wall = _wall_faces(m)
    flip = wall[(c[wall, 0] > 0.10) & (c[wall, 0] < 0.35)]
    faces = m.faces.copy()
    faces[flip] = faces[flip][:, ::-1]
    out = _raw(m.vertices, faces)
    exp = _clean_pipe_expect(forbid_risks=CLEAN_PIPE_FORBID + ["thin_feature"])
    exp["true_volume"] = math.pi * (PIPE_D / 2) ** 2 * PIPE_L
    exp["construction"] = f"straight pipe; {len(flip)} of {len(wall)} wall triangles ({len(flip) / len(wall):.0%}) with reversed winding"
    exp["should"] = f"closed pipe, two ports, 10 D stubs, volume pi r^2 L = {exp['true_volume']:.4g}; inconsistent winding is a repair item, not a hole"
    return out, exp


def sliver_cap(aspect: float = 1000.0):
    """The x = 0 cap re-triangulated with a needle next to every fan triangle: a vertex inserted on each rim
    edge r/aspect from its start. The wall triangle on that rim edge is split too, so the mesh stays closed."""
    m = pipe(PIPE_D, PIPE_L)
    r = PIPE_D / 2
    V = m.vertices.copy()
    F = m.faces.copy()
    cap = np.where(m.face_normals[:, 0] < -0.5)[0]
    centre = [int(v) for v in np.unique(F[cap]) if abs(V[v, 0]) < 1e-9 and np.hypot(V[v, 1], V[v, 2]) < 1e-9]
    assert len(centre) == 1, centre
    centre = centre[0]
    new_v = list(V)
    split: dict[tuple[int, int], int] = {}
    for f in cap:
        a, b, c = F[f]
        rim = [v for v in (a, b, c) if v != centre]
        key = (min(rim), max(rim))
        if key in split:
            continue
        p0, p1 = V[rim[0]], V[rim[1]]
        edge = float(np.linalg.norm(p1 - p0))
        t = (r / aspect) / edge
        new_v.append(p0 + t * (p1 - p0))
        split[(rim[0], rim[1])] = len(new_v) - 1
        split[(rim[1], rim[0])] = len(new_v) - 1
    faces = []
    for a, b, c in F:
        tri = (int(a), int(b), int(c))
        done = False
        for i in range(3):
            u, w = tri[i], tri[(i + 1) % 3]
            if (u, w) in split:
                p = split[(u, w)]
                o = tri[(i + 2) % 3]
                faces.append([u, p, o])
                faces.append([p, w, o])
                done = True
                break
        if not done:
            faces.append(list(tri))
    out = _raw(np.asarray(new_v), faces)
    exp = _clean_pipe_expect()
    exp["construction"] = (f"straight pipe; the x=0 cap has {len(split) // 2} needle triangles of base r/{aspect:.0f} = {r / aspect:.2e} and height r "
                           f"(aspect ~{aspect:.0f}); the adjoining wall triangles are split on the same vertices")
    exp["should"] = "closed pipe, two circular D 0.05 ports, 10 D stubs; slivers change nothing the flow sees"
    return out, exp


def baffle_tjunction():
    """A zero-thickness half-disc baffle inside the pipe at mid-length, glued to the wall: its arc edges are the
    wall's own ring edges (three faces per edge) and its chord is a free edge in the fluid. Real baffles are
    exported exactly like this."""
    L, r = PIPE_L, PIPE_D / 2
    m = revolve_closed([(0.0, r), (L / 2, r), (L, r)], "x")
    V = m.vertices
    ring = np.where(np.abs(V[:, 0] - L / 2) < 1e-9)[0]
    ang = np.arctan2(V[ring, 2], V[ring, 1])
    order = ring[np.argsort(ang)]
    lower = [int(v) for v in order if V[v, 2] <= 1e-12]   # the half of the ring at or below z = 0
    faces = list(m.faces)
    for k in range(1, len(lower) - 1):
        faces.append([lower[0], lower[k], lower[k + 1]])
    out = _raw(V, faces)
    exp = {"openings": 2, "regions": 1, "watertight": False, "port_candidates": 2,
           "ports": _pipe_ports(stub=None),
           "expect_risks": ["not_watertight"],
           "forbid_risks": ["surface_holes", "region_purpose_mismatch", "nested_bodies"]}
    exp["construction"] = (f"straight pipe D {PIPE_D} L {L} with a ring of vertices at x = L/2; a half-disc baffle (z <= 0) at x = L/2 fanned "
                           f"from the ring's own vertices: {len(lower) - 1} arc edges shared with the wall (3 faces each), one free chord edge")
    exp["should"] = ("one body, two D 0.05 ports, no holes; the surface is not 2-manifold (a T-junction edge and a free chord) so it is not "
                     "watertight in the mesher's sense and must be flagged; the baffle sits 5 D from either port, so a march that sees "
                     "obstructions would stop at 5 D, one that only tracks the closed section runs 10 D: neither stub value is asserted")
    exp["baffle_over_d_from_each_port"] = (L / 2) / PIPE_D
    return out, exp


def debris_near_manifold(n: int = 20, size: float = 1e-4, seed: int = 3):
    """The short-stub manifold plus 20 floating triangles of 0.1 mm just above the main pipe: tessellation crumbs."""
    m = manifold(MAN_STUB)
    rng = np.random.default_rng(seed)
    verts, faces = [m.vertices], [m.faces]
    off = len(m.vertices)
    for k in range(n):
        centre = np.array([0.05 + 0.5 * k / (n - 1), rng.uniform(-0.02, 0.02), MAN_D_MAIN / 2 + 0.002 + rng.uniform(0, 0.003)])
        tri = centre + size * rng.normal(size=(3, 3))
        verts.append(tri)
        faces.append(np.array([[off, off + 1, off + 2]]))
        off += 3
    out = _raw(np.vstack(verts), np.vstack(faces))
    exp = {"openings": 4, "regions": 1, "watertight": True, "port_candidates": 4, "ports": _manifold_ports(),
           "expect_risks": ["short_stub", "velocity_spread"],
           "forbid_risks": ["region_purpose_mismatch", "nested_bodies", "surface_holes", "not_watertight"]}
    exp["construction"] = (f"synthetic.manifold(1.5) (D 0.10 main, 0.60 long, two D 0.04 branches with 1.5 D stubs) plus {n} disconnected "
                           f"triangles of ~{size:.0e} above the main pipe, outside its bounding box, total area ~{n * size * size:.0e}")
    exp["should"] = ("the manifold: one watertight fluid body, four ports (two D 0.10 ends, two D 0.04 branch tips with 1.5 D stubs), short_stub and "
                     "velocity_spread. The crumbs are debris to delete (area 1e-7 of the part): not regions that need a purpose decision, not "
                     "holes, not openings. If the measurement reports them as regions or rims the agent must call them debris, not bodies")
    return out, exp


def mixed_scale_assembly():
    """The manifold in metres concatenated with an L-bracket modelled in millimetres (40 x 30 x 25 units), the way a
    mixed-unit assembly export looks: the bracket sits at x = 650 where 0.65 m would be."""
    m = manifold(MAN_STUB)
    flange = _box((0.04, 0.03, 0.005), (0.02, 0, 0.0025))
    web = _box((0.005, 0.03, 0.025), (0.0025, 0, 0.0125))
    bracket = _union([flange, web])
    bracket.apply_scale(1000.0)
    bracket.apply_translation([650.0, 0.0, 0.0])
    out = trimesh.util.concatenate([m, bracket])
    exp = {"regions": 2, "watertight": True, "ports": _manifold_ports(),
           "expect_risks": ["region_purpose_mismatch", "short_stub", "velocity_spread"],
           "forbid_risks": ["nested_bodies", "surface_holes", "not_watertight"],
           "unit_best_guess": "m"}
    exp["construction"] = ("synthetic.manifold(1.5) in metres (0.60 long, D 0.10) plus an L-bracket 40 x 30 x 25 in millimetre units at x = 650; "
                           "bounding diagonal ~690 file units")
    exp["should"] = ("two bodies: the manifold's ports and stubs measured as before; region_purpose_mismatch is right (a second body in an internal "
                     "case). The fluid body is 0.6 units long with a 0.1 bore: metres. A unit guess from the whole bounding box says mm, which "
                     "makes the manifold a 0.6 mm part; the honest reading is a mixed-scale file, with the fluid body plausible only in m")
    return out, exp


def jittered_vertices(eps: float = 1e-9, seed: int = 1):
    """Every vertex copy in the triangle soup moved independently by up to 1e-9 (2e-9 of the part), then written at
    full precision: the way a kernel with a loose tolerance leaves an STL. All copies of a vertex should still merge."""
    m = pipe(PIPE_D, PIPE_L)
    rng = np.random.default_rng(seed)
    soup = np.asarray(m.triangles, dtype=float).copy()
    soup += rng.uniform(-eps, eps, size=soup.shape)
    n = len(soup)
    out = _raw(soup.reshape(-1, 3), np.arange(3 * n).reshape(-1, 3))
    exp = _clean_pipe_expect()
    exp["construction"] = f"straight pipe D {PIPE_D} L {PIPE_L} as a triangle soup; each of the {3 * n} vertex copies jittered by U(-{eps:.0e}, {eps:.0e}) per axis; ASCII STL at 17 digits"
    exp["should"] = "closed pipe, two ports, 10 D stubs: a 1e-9 discrepancy on a 0.5 part is far below any tolerance and must merge"
    return out, exp


def degenerate_triangles(n: int = 12, seed: int = 2):
    """Twelve zero-area triangles (v, v, w) on wall edges: collapsed slivers, which float32 rounding produces from
    real ones. They add nothing to the surface and no edge is left open."""
    m = _fine_pipe(1)
    rng = np.random.default_rng(seed)
    wall = _wall_faces(m)
    pick = rng.choice(wall, size=n, replace=False)
    extra = []
    for f in pick:
        a, b, _ = m.faces[f]
        extra.append([int(a), int(a), int(b)])
    out = _raw(m.vertices, np.vstack([m.faces, np.asarray(extra)]))
    exp = _clean_pipe_expect()
    exp["construction"] = f"straight pipe; {n} zero-area triangles of the form (v, v, w) added on wall edges"
    exp["should"] = "closed pipe, two ports, 10 D stubs; degenerate triangles are dropped, not reported as an open surface"
    return out, exp


def inside_out():
    """The whole shell wound inwards: every normal points into the fluid. A common export sign error."""
    m = pipe(PIPE_D, PIPE_L)
    out = _raw(m.vertices, m.faces[:, ::-1])
    exp = _clean_pipe_expect(forbid_risks=CLEAN_PIPE_FORBID + ["thin_feature", "near_touching"])
    exp["true_thickness_min_between"] = [0.9 * PIPE_D, 1.1 * PIPE_D]
    exp["construction"] = "straight pipe with every face reversed"
    exp["should"] = ("closed pipe, two ports, 10 D stubs; the bore (0.05) is the wall-to-wall distance whichever way the normals point, so no "
                     "thin feature and no near-touching surfaces")
    return out, exp


def duplicate_body():
    """The pipe exported twice in place: two identical closed shells on the same vertices. Every face is doubled."""
    m = pipe(PIPE_D, PIPE_L)
    out = trimesh.util.concatenate([m, m.copy()])
    exp = _clean_pipe_expect(measure_seconds_max=60.0)
    exp["construction"] = "straight pipe concatenated with an exact copy of itself (every triangle appears twice on the same vertices)"
    exp["should"] = "one closed pipe, two ports, 10 D stubs; the second copy is an exact duplicate to drop, not hundreds of bodies"
    return out, exp


def ascii_named_inlet_manifold():
    """The clean short-stub manifold, ASCII STL whose header reads 'solid INLET_MANIFOLD'. Names are read from STEP
    only today; the case records whether the STL name reaches the facts."""
    m = manifold(MAN_STUB)
    exp = {"openings": 4, "regions": 1, "watertight": True, "port_candidates": 4, "ports": _manifold_ports(),
           "expect_risks": ["short_stub", "velocity_spread"],
           "forbid_risks": ["region_purpose_mismatch", "nested_bodies", "surface_holes", "not_watertight"]}
    exp["construction"] = "synthetic.manifold(1.5) as ASCII STL with 'solid INLET_MANIFOLD' / 'endsolid INLET_MANIFOLD'"
    exp["should"] = ("the manifold's facts unchanged; the solid name is free evidence ('inlet' + 'manifold') that a STEP file would surface "
                     "through facts.names; whether an STL name is read is recorded, not asserted")
    return m, exp


# ---- the family ----------------------------------------------------------------------------------------------

def _case(name: str, builder, note: str = "", ascii_name: str | None = None, brief: str = "") -> DirtyCase:
    def build():
        return builder()[0]
    _, exp = builder()
    return DirtyCase(name=name, family=FAMILY, purpose="internal_cfd", build=build, expected=exp, note=note,
                     brief=brief, ascii_name=ascii_name)


def build_cases() -> list[Case]:
    pipe_brief = "Straight pipe, flow from -x to +x."
    man_brief = "Supply manifold: the large end is the inlet, the two short branches are outlets, the far end is capped."
    return [
        _case("dup_faces_wall_patch", dup_faces_wall_patch, brief=pipe_brief,
              note="duplicate faces: a closed volume the mesher will reject for non-manifold edges; the fix is to drop the copies"),
        _case("flipped_normals_patch", flipped_normals_patch, brief=pipe_brief,
              note="half the wall wound backwards; the signed volume is wrong unless the winding is repaired"),
        _case("sliver_cap", sliver_cap, brief=pipe_brief, note="aspect-1000 needles on one cap"),
        _case("baffle_tjunction", baffle_tjunction, brief=pipe_brief + " There is a half-height baffle at mid-length.",
              note="non-manifold: an internal baffle shares its arc edges with the wall"),
        _case("debris_near_manifold", debris_near_manifold, brief=man_brief,
              note="20 floating 0.1 mm triangles above the main pipe: debris, not bodies"),
        _case("mixed_scale_assembly", mixed_scale_assembly, brief=man_brief + " A mounting bracket is included.",
              note="manifold in metres, bracket in millimetres, one file"),
        _case("jittered_vertices", jittered_vertices, brief=pipe_brief, ascii_name="pipe",
              note="vertex copies differ by up to 2e-9; an absolute merge tolerance may fail to stitch them"),
        _case("degenerate_triangles", degenerate_triangles, brief=pipe_brief, note="zero-area (v, v, w) triangles on the wall"),
        _case("inside_out", inside_out, brief=pipe_brief, note="every normal points into the fluid"),
        _case("duplicate_body", duplicate_body, brief=pipe_brief, note="the whole shell twice on the same vertices"),
        _case("ascii_named_inlet_manifold", ascii_named_inlet_manifold, brief=man_brief, ascii_name="INLET_MANIFOLD",
              note="clean geometry; only the STL header carries a name"),
    ]


def main(out: Path = OUT_DIR) -> list[Path]:
    out.mkdir(parents=True, exist_ok=True)
    written = []
    for c in build_cases():
        d = c.write(out)
        m = trimesh.load(d / "geometry.stl", force="mesh", process=False)
        written.append(d)
        print(f"{c.name:32s} {len(m.faces):7d} faces  {d / 'geometry.stl'}")
    return written


if __name__ == "__main__":
    main()
