"""Real B-rep STEP parts built with OCP, the kind of file a customer uploads. Everything is in millimetres and the
STEP header says so (OCCT's default), so the declared unit is part of the truth.

Cases: a flanged pipe tee (wall solid: every end is an annular ring, the outer junction is filleted), the same
tee with its fluid as a second solid sharing the bore, a tee fluid volume with a filleted junction, a duct whose
inlet is a curved B-spline surface (deep and shallow sag), CHT blocks with a straight round channel and with a
serpentine channel (block minus channel plus the channel itself, sharing faces exactly), a 7-tube shell-and-tube
exchanger (15 solids, 14 interface pairs), a manifold whose branch tips carry a 45 degree chamfer, and a bracket
with four bolts sitting in clearance holes. Every expectation is derived from the dimensions that built the shape.

Run: .venv/Scripts/python -m geometry_agent.corpus_complex.step_brep  -> eval/corpus_complex/step_brep/<case>/"""
from __future__ import annotations

import json
import math
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from geometry_agent.corpus import GENTLE_STUB_TOL, Case, port

FAMILY = "step_brep"
OUT_DIR = Path("eval/corpus_complex") / FAMILY


# ---- OCP helpers ----------------------------------------------------------------------------------------------

def _static(owner, name: str):
    fn = getattr(owner, name + "_s", None) or getattr(owner, name, None)
    if fn is None:
        raise AttributeError(f"{owner!r} has neither {name}_s nor {name}")
    return fn


def _pnt(x, y, z):
    from OCP.gp import gp_Pnt
    return gp_Pnt(float(x), float(y), float(z))


def _dir(x, y, z):
    from OCP.gp import gp_Dir
    return gp_Dir(float(x), float(y), float(z))


def _cyl(origin, axis, r: float, h: float):
    from OCP.BRepPrimAPI import BRepPrimAPI_MakeCylinder
    from OCP.gp import gp_Ax2
    return BRepPrimAPI_MakeCylinder(gp_Ax2(_pnt(*origin), _dir(*axis)), float(r), float(h)).Shape()


def _box(lo, hi):
    from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
    return BRepPrimAPI_MakeBox(_pnt(*lo), float(hi[0] - lo[0]), float(hi[1] - lo[1]), float(hi[2] - lo[2])).Shape()


def _fuse(shapes: list):
    from OCP.BRepAlgoAPI import BRepAlgoAPI_Fuse
    out = shapes[0]
    for s in shapes[1:]:
        out = BRepAlgoAPI_Fuse(out, s).Shape()
    return out


def _cut(a, b):
    from OCP.BRepAlgoAPI import BRepAlgoAPI_Cut
    return BRepAlgoAPI_Cut(a, b).Shape()


def _common(a, b):
    from OCP.BRepAlgoAPI import BRepAlgoAPI_Common
    return BRepAlgoAPI_Common(a, b).Shape()


def _unify(shape):
    from OCP.ShapeUpgrade import ShapeUpgrade_UnifySameDomain
    u = ShapeUpgrade_UnifySameDomain(shape, True, True, False)
    u.Build()
    return u.Shape()


def _general_fuse(shapes: list):
    """Glue solids that touch along faces so the result's solids share those faces exactly (one TopoDS face in
    both solids): the block minus the channel and the channel itself, the shell fluid and the tube walls, and so
    on. The arguments must not overlap in volume (pre-cut them): with overlapping arguments OCCT's general fuse
    returned the common part twice."""
    from OCP.BOPAlgo import BOPAlgo_GlueEnum
    from OCP.BRepAlgoAPI import BRepAlgoAPI_BuilderAlgo
    from OCP.collections import List_TopoDS_Shape
    gf = BRepAlgoAPI_BuilderAlgo()
    args = List_TopoDS_Shape()
    for s in shapes:
        args.Append(s)
    gf.SetArguments(args)
    gf.SetGlue(BOPAlgo_GlueEnum.BOPAlgo_GlueShift)
    gf.SetRunParallel(False)
    gf.Build()
    if not gf.IsDone():
        raise RuntimeError("general fuse failed")
    return gf.Shape()


def _explore(shape, kind) -> list:
    from OCP.TopExp import TopExp_Explorer
    out = []
    exp = TopExp_Explorer(shape, kind)
    while exp.More():
        out.append(exp.Current())
        exp.Next()
    return out


def _solids(shape) -> list:
    from OCP.TopAbs import TopAbs_SOLID
    return _explore(shape, TopAbs_SOLID)


def _edge_midpoint(edge) -> np.ndarray:
    from OCP.BRepAdaptor import BRepAdaptor_Curve
    from OCP.TopoDS import TopoDS
    c = BRepAdaptor_Curve(_static(TopoDS, "Edge")(edge))
    t = 0.5 * (c.FirstParameter() + c.LastParameter())
    p = c.Value(t)
    return np.array([p.X(), p.Y(), p.Z()])


def _edges_where(shape, pred) -> list:
    from OCP.TopAbs import TopAbs_EDGE
    from OCP.TopoDS import TopoDS
    as_edge = _static(TopoDS, "Edge")
    return [as_edge(e) for e in _explore(shape, TopAbs_EDGE) if pred(_edge_midpoint(e))]


def _fillet(shape, radius: float, edges: list):
    from OCP.BRepFilletAPI import BRepFilletAPI_MakeFillet
    if not edges:
        raise RuntimeError("fillet: no edges selected")
    f = BRepFilletAPI_MakeFillet(shape)
    for e in edges:
        f.Add(float(radius), e)
    f.Build()
    if not f.IsDone():
        raise RuntimeError("fillet failed")
    return f.Shape()


def _chamfer(shape, dist: float, edges: list):
    from OCP.BRepFilletAPI import BRepFilletAPI_MakeChamfer
    if not edges:
        raise RuntimeError("chamfer: no edges selected")
    c = BRepFilletAPI_MakeChamfer(shape)
    for e in edges:
        c.Add(float(dist), e)
    c.Build()
    if not c.IsDone():
        raise RuntimeError("chamfer failed")
    return c.Shape()


def _compound(shapes: list):
    from OCP.BRep import BRep_Builder
    from OCP.TopoDS import TopoDS_Compound
    comp = TopoDS_Compound()
    b = BRep_Builder()
    b.MakeCompound(comp)
    for s in shapes:
        b.Add(comp, s)
    return comp


def _surface_area(shape) -> float:
    from OCP.BRepGProp import BRepGProp
    from OCP.GProp import GProp_GProps
    props = GProp_GProps()
    _static(BRepGProp, "SurfaceProperties")(shape, props)
    return float(props.Mass())


def write_step(shape, path: Path) -> Path:
    from OCP.STEPControl import STEPControl_AsIs, STEPControl_Writer
    w = STEPControl_Writer()
    w.Transfer(shape, STEPControl_AsIs)
    w.Write(str(path))
    return path


@dataclass
class StepCase(Case):
    """A Case whose build() returns a TopoDS_Shape and whose geometry file is a STEP."""

    def write(self, out: Path) -> Path:
        d = out / self.name
        d.mkdir(parents=True, exist_ok=True)
        geo = d / "geometry.step"
        if not geo.exists():
            write_step(self.build(), geo)
        exp = {"purpose": self.purpose, "family": self.family, **self.expected}
        if self.brief:
            exp["brief"] = self.brief
        if self.note:
            exp["note"] = self.note
        (d / "expected.json").write_text(json.dumps(exp, indent=1, default=float))
        return d


MM = {"unit_declared": "mm", "unit_best_guess": "mm"}


# ---- 1. flanged pipe tee, wall solid, filleted outer junction -------------------------------------------------

def tee_wall_geometry(ro=30.0, rob=27.0, ri=22.0, L=400.0, Lb=200.0, rf=50.0, tf=12.0, fillet=8.0):
    """Wall of a tee fitting: main run along x from 0 to L (outer radius ro), branch along +y from the axis to Lb
    (outer radius rob: equal-radius cylinder junctions cannot be filleted in OCCT), one bore ri, a flange of radius
    rf and thickness tf at each of the three ends, the outer run/branch junction filleted. Every end face is an
    annulus (ri..rf); every flange has an inner shoulder annulus (ro or rob..rf) facing back along the pipe."""
    outer = _fuse([_cyl((0, 0, 0), (1, 0, 0), ro, L), _cyl((L / 2, 0, 0), (0, 1, 0), rob, Lb)])
    tol = 1e-3

    def on_junction(p):
        return (abs(math.hypot(p[1], p[2]) - ro) < tol and abs(math.hypot(p[0] - L / 2, p[2]) - rob) < tol and p[1] > 0)

    outer = _fillet(outer, fillet, _edges_where(outer, on_junction))
    flanges = [_cyl((0, 0, 0), (1, 0, 0), rf, tf), _cyl((L - tf, 0, 0), (1, 0, 0), rf, tf),
               _cyl((L / 2, Lb - tf, 0), (0, 1, 0), rf, tf)]
    body = _fuse([outer] + flanges)
    bore = _fuse([_cyl((-1, 0, 0), (1, 0, 0), ri, L + 2), _cyl((L / 2, 0, 0), (0, 1, 0), ri, Lb + 1)])
    wall = _unify(_cut(body, bore))
    assert len(_solids(wall)) == 1
    return wall


def tee_wall_flanged():
    ro, rob, ri, L, Lb, rf, tf = 30.0, 27.0, 22.0, 400.0, 200.0, 50.0, 12.0
    ends = [(0, 0, 0), (L, 0, 0), (L / 2, Lb, 0)]
    ports = [port(e, "wall", None, None, kind="ring", classification="ring") for e in ends]
    exp = {"bodies": 1, "regions": 1, "watertight": True, "openings": 6, "port_candidates": 0, "ports": ports,
           "expect_risks_any": ["wall_shell_to_carve", "solid_wall_representation"], "forbid_risks": ["short_stub", "not_watertight"], **MM,
           "note": "wall solid of a flanged tee: 3 end annuli (ri 22..rf 50) plus 3 flange shoulder annuli (ro 30 or 27..rf 50); "
                   "no fluid body, no port candidate; outer junction filleted r8"}
    return lambda: tee_wall_geometry(ro, rob, ri, L, Lb, rf, tf), exp


# ---- 2. the same tee wall with its fluid as a second solid, fluid extended past the flanges ---------------------

def tee_wall_with_fluid():
    ro, rob, ri, L, Lb, rf, tf, ext = 30.0, 27.0, 22.0, 400.0, 200.0, 50.0, 12.0, 100.0

    def build():
        wall = tee_wall_geometry(ro, rob, ri, L, Lb, rf, tf)
        fluid = _fuse([_cyl((-ext, 0, 0), (1, 0, 0), ri, L + 2 * ext), _cyl((L / 2, 0, 0), (0, 1, 0), ri, Lb + ext)])
        shape = _general_fuse([wall, fluid])
        assert len(_solids(shape)) == 2, len(_solids(shape))
        return shape

    d = 2 * ri
    # fluid stubs: -x end runs ext + L/2 - ri to the branch junction; branch runs ext + Lb - ri to the run bore
    run_stub = (ext + L / 2 - ri) / d
    br_stub = (ext + Lb - ri) / d
    ports = [port((-ext, 0, 0), "any", d, run_stub, needs_model=True, stub_tol=GENTLE_STUB_TOL),
             port((L + ext, 0, 0), "any", d, run_stub, needs_model=True, stub_tol=GENTLE_STUB_TOL),
             port((L / 2, Lb + ext, 0), "any", d, br_stub, needs_model=True, stub_tol=GENTLE_STUB_TOL)]
    ports += [port(e, "wall", None, None, kind="ring", classification="ring") for e in [(0, 0, 0), (L, 0, 0), (L / 2, Lb, 0)]]
    exp = {"bodies": 2, "regions": 2, "watertight": True, "interfaces_min": 1, "port_candidates": 3, "openings": 9,
           "ports": ports, "nested": [], "forbid_risks": ["no_shared_interface", "not_watertight", "solid_wall_representation"], **MM,
           "note": "wall solid plus the bore fluid extended 100 past each flange; the bore surface is one shared face set; "
                   "fluid bbox exceeds the wall so nothing is nested"}
    return build, exp


# ---- 3. tee fluid volume with a filleted junction ---------------------------------------------------------------

def tee_fluid_filleted(d=50.0, d_branch=40.0, run_over_d=6.0, branch_over_d=6.0, fillet=8.0):
    """Reducing tee fluid volume (a filleted equal-tee junction is not buildable in OCCT)."""
    r, rb = d / 2, d_branch / 2
    L = 2 * run_over_d * d
    Lb = r + branch_over_d * d_branch

    def build():
        fluid = _fuse([_cyl((0, 0, 0), (1, 0, 0), r, L), _cyl((L / 2, 0, 0), (0, 1, 0), rb, Lb)])
        tol = 1e-3

        def on_junction(p):
            return abs(math.hypot(p[1], p[2]) - r) < tol and abs(math.hypot(p[0] - L / 2, p[2]) - rb) < tol and p[1] > 0

        out = _fillet(fluid, fillet, _edges_where(fluid, on_junction))
        assert len(_solids(out)) == 1
        return out

    ports = [port((0, 0, 0), "inlet", d, run_over_d, needs_model=True, stub_tol=GENTLE_STUB_TOL),
             port((L, 0, 0), "outlet", d, run_over_d, needs_model=True, stub_tol=GENTLE_STUB_TOL),
             port((L / 2, Lb, 0), "outlet", d_branch, branch_over_d, needs_model=True, stub_tol=GENTLE_STUB_TOL)]
    exp = {"bodies": 1, "regions": 1, "watertight": True, "openings": 3, "port_candidates": 3, "ports": ports,
           "forbid_risks": ["short_stub", "ring_faces_present", "solid_wall_representation"], **MM}
    return build, exp


# ---- 4. duct whose inlet is a curved B-spline surface ------------------------------------------------------------

def _bspline_inlet_face(w: float, h: float, sag: float, n: int = 15):
    """x = -sag * (1 - (2y/w)^2): a parabolic-cylinder inlet, planar top and bottom walls, curved only across y."""
    from OCP.Approx import Approx_ParametrizationType
    from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeFace
    from OCP.collections import Array2_gp_Pnt
    from OCP.GeomAPI import GeomAPI_PointsToBSplineSurface
    m = 4
    pts = Array2_gp_Pnt(1, n, 1, m)
    for i in range(n):
        y = -w / 2 + w * i / (n - 1)
        x = -sag * (1 - (2 * y / w) ** 2)
        for j in range(m):
            z = -h / 2 + h * j / (m - 1)
            pts.SetValue(i + 1, j + 1, _pnt(x, y, z))
    surf = GeomAPI_PointsToBSplineSurface(pts, Approx_ParametrizationType.Approx_ChordLength, 3, 8).Surface()
    return BRepBuilderAPI_MakeFace(surf, 1e-6).Face()


def duct_bspline_inlet(w=200.0, h=100.0, L=900.0, sag=30.0):
    """L/h stays under the 10:1 aspect cap so the four duct walls are counted as planar-face openings, as the
    block sides are in the CHT cases; the total is then 4 walls + planar outlet + curved inlet."""
    def build():
        from OCP.BRepPrimAPI import BRepPrimAPI_MakePrism
        from OCP.gp import gp_Vec
        face = _bspline_inlet_face(w, h, sag)
        prism = BRepPrimAPI_MakePrism(face, gp_Vec(L + sag + 10.0, 0, 0)).Shape()
        duct = _common(prism, _box((-sag - 10.0, -w, -h), (L, w, h)))
        sol = _solids(duct)
        assert len(sol) == 1, len(sol)
        return sol[0]

    dh = 4 * w * h / (2 * (w + h))
    # area centroid of the curved inlet face x = f(y): weighted by arc length
    y = np.linspace(-w / 2, w / 2, 2001)
    f = -sag * (1 - (2 * y / w) ** 2)
    ds = np.sqrt(1 + np.gradient(f, y) ** 2)
    xc = float(np.trapezoid(f * ds, y) / np.trapezoid(ds, y)) if hasattr(np, "trapezoid") else float(np.trapz(f * ds, y) / np.trapz(ds, y))
    stub = L / dh
    ports = [port((L, 0, 0), "outlet", dh, stub, needs_model=True, stub_tol=GENTLE_STUB_TOL),
             port((xc, 0, 0), "inlet", dh, stub, needs_model=True, stub_tol=GENTLE_STUB_TOL)]
    exp = {"bodies": 1, "regions": 1, "watertight": True, "openings": 6, "port_candidates": 2, "planar_faces_min": 4, "ports": ports,
           "forbid_risks": ["short_stub", "not_watertight"], **MM,
           "note": f"rectangular duct {w:g}x{h:g}, {L:g} long; the inlet is a B-spline surface bulging {sag:g} mm out of plane "
                   f"(radius of curvature ~{(w * w / 4 + sag * sag) / (2 * sag):.0f} mm); the outlet is planar"}
    return build, exp


# ---- 5/6. CHT blocks: block minus channel plus the channel, sharing faces -----------------------------------------

def cht_block_round_channel(bx=300.0, by=100.0, bz=50.0, d=20.0, yc=20.0):
    """The channel runs off-centre (y = yc) so the fluid's end caps do not share a centroid with the block's end
    rings (the evaluator matches ports by nearest centroid)."""
    def build():
        block = _box((0, -by / 2, -bz / 2), (bx, by / 2, bz / 2))
        ch = _cyl((0, yc, 0), (1, 0, 0), d / 2, bx)
        shape = _general_fuse([_cut(block, ch), ch])
        assert len(_solids(shape)) == 2
        return shape

    stub = bx / d
    ports = [port((0, yc, 0), "inlet", d, stub, needs_model=True), port((bx, yc, 0), "outlet", d, stub, needs_model=True)]
    exp = {"bodies": 2, "regions": 2, "watertight": True, "interfaces_min": 1, "port_candidates": 2, "planar_faces_min": 4,
           "openings": 8, "ports": ports, "nested": [["r2", "r1"]],
           "expect_risks": ["solid_fluid_pair"], "forbid_risks": ["no_shared_interface", "region_purpose_mismatch", "nested_bodies"], **MM,
           "note": f"interface area = channel lateral area {math.pi * d * bx:.0f} mm^2; block end faces are rings, its 4 sides planar faces"}
    return build, exp


def cht_block_serpentine(bx=300.0, by=200.0, bz=50.0, s=20.0, y_pitch=60.0, inset=50.0):
    """Three passes along x at y = -pitch, 0, +pitch joined by two cross-connectors; square section s; inlet on the
    x=0 face at y=-pitch, outlet on the x=bx face at y=+pitch. The channel leaves the block only at those two faces."""
    z0, z1 = bz / 2 - s / 2, bz / 2 + s / 2
    hs = s / 2
    y1, y2, y3 = -y_pitch, 0.0, y_pitch
    turn = bx - inset

    def build():
        block = _box((0, -by / 2, 0), (bx, by / 2, bz))
        boxes = [
            _box((0, y1 - hs, z0), (turn, y1 + hs, z1)),               # pass 1
            _box((turn - s, y1 - hs, z0), (turn, y2 + hs, z1)),        # connector 1
            _box((inset, y2 - hs, z0), (turn, y2 + hs, z1)),           # pass 2
            _box((inset, y2 - hs, z0), (inset + s, y3 + hs, z1)),      # connector 2
            _box((inset, y3 - hs, z0), (bx, y3 + hs, z1)),             # pass 3
        ]
        channel = _unify(_fuse(boxes))
        assert len(_solids(channel)) == 1
        shape = _general_fuse([_cut(block, channel), channel])
        assert len(_solids(shape)) == 2, len(_solids(shape))
        return shape

    dh = s
    stub_in = (turn - s) / dh          # pass 1 is straight until connector 1 begins
    stub_out = (bx - inset - s) / dh   # pass 3 is straight back to connector 2
    ports = [port((0, y1, bz / 2), "inlet", dh, stub_in, needs_model=True),
             port((bx, y3, bz / 2), "outlet", dh, stub_out, needs_model=True)]
    exp = {"bodies": 2, "regions": 2, "watertight": True, "interfaces_min": 1, "port_candidates": 2, "planar_faces_min": 4,
           "ports": ports, "nested": [["r2", "r1"]],
           "expect_risks": ["solid_fluid_pair"], "forbid_risks": ["no_shared_interface", "region_purpose_mismatch", "nested_bodies"], **MM,
           "note": "serpentine square channel 20x20 through a 300x200x50 block; the channel's internal faces are all interfaces"}
    return build, exp


# ---- 7. shell-and-tube exchanger: shell fluid, 7 tube walls, 7 tube fluids ----------------------------------------

def shell_and_tube(rs=100.0, L=600.0, pitch=50.0, ro=12.0, ri=9.0, wall_ext=20.0, fluid_ext=40.0, dn=50.0, Ln=100.0,
                   shared: bool = True):
    """15 solids. shared=True glues them so every solid/fluid boundary is one shared face set; shared=False writes
    the same 15 solids as a plain compound, each with its own copy of the coincident surfaces (how a CAD assembly
    export usually arrives: zero gap, no shared topology)."""
    centres = [(0.0, 0.0)] + [(pitch * math.cos(math.radians(60 * k)), pitch * math.sin(math.radians(60 * k))) for k in range(6)]
    xn = [L / 6, 5 * L / 6]

    def build():
        shell = _fuse([_cyl((0, 0, 0), (1, 0, 0), rs, L)] + [_cyl((x, 0, 0), (0, 0, 1), dn / 2, rs + Ln) for x in xn])
        walls = [_cyl((-wall_ext, y, z), (1, 0, 0), ro, L + 2 * wall_ext) for y, z in centres]
        fluids = [_cyl((-fluid_ext, y, z), (1, 0, 0), ri, L + 2 * fluid_ext) for y, z in centres]
        parts = [_cut(shell, _fuse(walls))] + [_cut(w, f) for w, f in zip(walls, fluids)] + fluids
        shape = _general_fuse(parts) if shared else _compound(parts)
        n = len(_solids(shape))
        assert n == 15, n
        return shape

    di = 2 * ri
    tube_stub = min((L + 2 * fluid_ext) / di, 25.0)   # the march stops at 25 diameters
    noz_stub = (Ln + rs - math.sqrt(rs**2 - (dn / 2) ** 2)) / dn
    ports = [port((x, 0, rs + Ln), "any", dn, noz_stub, needs_model=True, stub_tol=GENTLE_STUB_TOL) for x in xn]
    for y, z in centres:
        ports.append(port((-fluid_ext, y, z), "any", di, tube_stub, needs_model=True))
        ports.append(port((L + fluid_ext, y, z), "any", di, tube_stub, needs_model=True))
    # the tube fluids protrude past their walls and the walls past the shell, so no body's bbox sits inside another's
    exp = {"bodies": 15, "regions": 15, "watertight": True, "interfaces_min": 14, "nested": [], "port_candidates": 16,
           "openings": 32, "ports": ports,
           "forbid_risks": ["no_shared_interface", "not_watertight", "region_purpose_mismatch"], **MM,
           "note": "shell fluid with two radial nozzles and 7 tube holes, 7 tube walls (od 24, id 18) protruding 20 past the shell, "
                   "7 tube fluids protruding 40; interface pairs: shell-wall x7 and wall-fluid x7; rings: 2 shell ends + 14 wall ends"
                   + ("" if shared else "; the 15 solids are a plain compound: coincident surfaces, no shared topology, zero gap")}
    return build, exp


# ---- 8. manifold with 45 degree chamfered branch tips -------------------------------------------------------------

def manifold_chamfered(n=3, d_main=100.0, d_branch=40.0, end_over_d=6.0, pitch_over_d=2.0, branch_over_d=6.0, chamfer_over_d=0.1):
    end = end_over_d * d_main
    pitch = pitch_over_d * d_main
    L = 2 * end + (n - 1) * pitch
    xs = [end + k * pitch for k in range(n)]
    rb = d_branch / 2
    tip = d_main / 2 + branch_over_d * d_branch
    c = chamfer_over_d * d_branch

    def build():
        fluid = _fuse([_cyl((0, 0, 0), (1, 0, 0), d_main / 2, L)] + [_cyl((x, 0, 0), (0, 1, 0), rb, tip) for x in xs])
        tol = 1e-3

        def tip_circle(p):
            return abs(p[1] - tip) < tol and any(abs(math.hypot(p[0] - x, p[2]) - rb) < tol for x in xs)

        out = _chamfer(fluid, c, _edges_where(fluid, tip_circle))
        assert len(_solids(out)) == 1
        return out

    d_face = d_branch - 2 * c
    ports = [port((0, 0, 0), "any", d_main, end_over_d, needs_model=True), port((L, 0, 0), "any", d_main, end_over_d, needs_model=True)]
    ports += [port((x, tip, 0), "outlet", d_face, (tip - d_main / 2) / d_face, needs_model=True, stub_tol=GENTLE_STUB_TOL) for x in xs]
    exp = {"bodies": 1, "regions": 1, "watertight": True, "openings": n + 2, "port_candidates": n + 2, "ports": ports,
           "expect_risks": ["velocity_spread"], "forbid_risks": ["short_stub", "not_watertight", "solid_wall_representation"], **MM,
           "note": f"fluid volume; each branch tip edge carries a 45 degree chamfer of {c:g} mm, so the flat tip face is "
                   f"{d_face:g} across and its rim meets a cone at 45 degrees; the tube behind is {d_branch:g} across"}
    return build, exp


# ---- 9. bracket with four bolts in clearance holes ----------------------------------------------------------------

def bracket_bolts(px=200.0, py=100.0, pz=20.0, hole_d=10.0, bolt_d=9.0, head_d=16.0, head_h=6.0, below=15.0, clearance=0.5):
    holes = [(30.0, -30.0), (30.0, 30.0), (px - 30.0, -30.0), (px - 30.0, 30.0)]

    def build():
        plate = _box((0, -py / 2, 0), (px, py / 2, pz))
        plate = _cut(plate, _fuse([_cyl((x, y, -1), (0, 0, 1), hole_d / 2, pz + 2) for x, y in holes]))
        bolts = []
        for x, y in holes:
            shank = _cyl((x, y, -below), (0, 0, 1), bolt_d / 2, below + pz + clearance)
            head = _cyl((x, y, pz + clearance), (0, 0, 1), head_d / 2, head_h)
            bolts.append(_unify(_fuse([shank, head])))
        shape = _compound([plate] + bolts)
        assert len(_solids(shape)) == 5
        return shape

    g = (hole_d - bolt_d) / 2   # radial clearance, equal to the axial head clearance
    assert abs(g - clearance) < 1e-9
    shank_len = below + pz + clearance
    ports = [port((x, y, -below), "any", bolt_d, shank_len / bolt_d, needs_model=True) for x, y in holes]
    exp = {"bodies": 5, "regions": 5, "watertight": True, "nested": [], "gap_between_regions_between": [0.5 * g, 3.0 * g],
           "port_candidates": 4, "planar_faces_min": 8, "ports": ports, "expect_risks": ["region_purpose_mismatch"],
           "forbid_risks": ["not_watertight", "internal_void"], **MM,
           "note": "plate with 4 through holes d10, 4 bolts d9 with d16 heads floating 0.5 above the plate: radial and axial "
                   "clearance both 0.5; bolts protrude below the plate so no body is nested"}
    return build, exp


# ---- the family --------------------------------------------------------------------------------------------------

def _case(name: str, purpose: str, builder, brief: str = "") -> StepCase:
    build, exp = builder()
    exp = dict(exp)
    note = exp.pop("note", "")
    return StepCase(name=name, family=FAMILY, purpose=purpose, build=build, expected=exp, brief=brief, note=note)


def build_cases() -> list[Case]:
    ic, cht, st = "internal_cfd", "conjugate_heat_transfer", "structural"
    return [
        _case("tee_wall_flanged_filleted", ic, tee_wall_flanged,
              brief="Flanged tee fitting, DN50, flow enters the run and leaves through the run and the branch."),
        _case("tee_wall_flanged_with_fluid", cht, tee_wall_with_fluid,
              brief="Flanged tee fitting with its bore fluid; conjugate heat transfer between the water and the steel."),
        _case("tee_fluid_filleted", ic, tee_fluid_filleted,
              brief="Fluid volume of an equal tee with a filleted junction; flow enters at -x."),
        _case("duct_bspline_inlet_deep", ic, lambda: duct_bspline_inlet(sag=30.0),
              brief="Rectangular duct 200x100; the inlet is the curved cut where it meets a drum, the outlet is the flat end."),
        _case("duct_bspline_inlet_shallow", ic, lambda: duct_bspline_inlet(sag=3.0),
              brief="Rectangular duct 200x100 with a slightly curved inlet face and a flat outlet."),
        _case("cht_block_round_channel", cht, cht_block_round_channel,
              brief="Cold plate: aluminium block with one straight 20 mm round channel; water in at x=0, out at x=300."),
        _case("cht_block_serpentine", cht, cht_block_serpentine,
              brief="Cold plate: block with a three-pass serpentine 20x20 channel; inlet on the x=0 face, outlet on the x=300 face."),
        _case("shell_and_tube_7", cht, shell_and_tube,
              brief="Shell-and-tube exchanger: shell fluid with two radial nozzles, seven tubes with their walls and tube-side fluid."),
        _case("shell_and_tube_7_unshared", cht, lambda: shell_and_tube(shared=False),
              brief="Shell-and-tube exchanger exported as an assembly: shell fluid, seven tube walls, seven tube fluids."),
        _case("manifold_chamfered_ports", ic, manifold_chamfered,
              brief="Distribution manifold: large run, three branch outlets on top with chamfered tips; supplied from one run end."),
        _case("bracket_bolts_clearance", st, bracket_bolts,
              brief="Bracket plate bolted with four M9 bolts in 10 mm clearance holes; static load case."),
    ]


def main(argv: list[str] | None = None) -> int:
    import sys
    only = set(argv or sys.argv[1:])
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    for c in build_cases():
        if only and c.name not in only:
            continue
        d = c.write(OUT_DIR)
        print(f"{c.name}: {d / 'geometry.step'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
