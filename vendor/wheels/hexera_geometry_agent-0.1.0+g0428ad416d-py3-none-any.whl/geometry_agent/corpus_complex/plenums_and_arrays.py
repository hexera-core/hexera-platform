"""Plenums and arrays: box-like fluid volumes whose flat sides are walls, and repeated identical openings.

Every case is built from a few dimensions and the expected answer is computed from the same numbers: which
flat faces carry a tube behind them (port candidates), which are sides of a slab or a box (planar faces), which
are walls with a branch root in them (rings), how long each stub is, and how many identical openings a plate
carries. Classification expectations follow the documented rules in facts/openings.py: a face with under half a
diameter of tube behind it is flush with whatever it sits in (planar_face); a face whose march ends within three
diameters at a twin face looking back is one side of a slab; a facet with a second boundary loop is a ring.

Cases:
  plenum_box_nozzles_2d      box plenum, one inlet nozzle on top, three outlet nozzles below, stubs 2D
  plenum_box_flush_large     same box, ports cut flush (open rims, no stub); holes large enough that the faces
                             that carry them fall below the tubularity threshold and vanish from the list
  plenum_box_flush_small     same, smaller flush holes: the faces stay (as rings) and the file is a fluid box
                             with two end rings and no port candidate, which must not read as a pipe wall
  plenum_box_nozzles_0p3d    same box, nozzle stubs 0.3D: under the flush threshold, so planar_face
  plenum_box_stub_ladder     four outlet nozzles with stubs 0.25, 0.75, 1.6, 4.1 D: the flush threshold
  showerhead_61_hex          disc plenum, inlet on top, 61 identical 2D nozzles in a hex pattern below
  header_12_alternating      header pipe, 12 identical 6D branch outlets alternating up and down
  cube_duct_full_faces       cube fluid box: inlet and outlet are whole opposite faces; geometry says planar
  duct_segment_5p4d          square duct 5.4D long: end faces are port candidates, sides are planar
  duct_slab_2p1d             square duct 2.1D long: end faces face a twin within 3D, so all six are planar
  microchannel_200_plenums   200 channels of 0.5 mm between two plenums with one port each
"""
from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import trimesh

from geometry_agent.corpus import Case, _box, _case, port
from geometry_agent.synthetic import _cyl, _union

FAMILY = "plenums_and_arrays"
OUT_DIR = Path("eval/corpus_complex") / FAMILY

#: facts/openings.py thresholds the expectations are derived from
FLUSH_STUB_OVER_D = 0.5
SLAB_STUB_OVER_D = 3.0
MIN_TUBULARITY = 0.85
STUB_STEP = 1 / 6


def _rect_dh(a: float, b: float) -> float:
    return 2 * a * b / (a + b)


def _ring(near) -> dict:
    return port(near, "any", kind="ring", classification="ring")


def _planar(near, d: float | None = None, role: str = "any", needs_model: bool = False, stub=None, stub_tol=None) -> dict:
    return port(near, role, d, stub, kind="cap", classification="planar_face", needs_model=needs_model, stub_tol=stub_tol)


def _nozzle_class(stub_over_d: float) -> str:
    """What the documented flush rule says about a nozzle of this length on a box: under half a diameter of tube
    behind the face, the face is flush with the wall it sits in."""
    return "planar_face" if stub_over_d < FLUSH_STUB_OVER_D else "port_candidate"


# ---- box plenum --------------------------------------------------------------------------------------------------

BOX = (0.3, 0.2, 0.1)
D_IN, X_IN = 0.06, 0.05
D_OUT, XS_OUT = 0.025, (-0.10, -0.02, 0.06)


def _box_side_ports(L) -> list[dict]:
    Lx, Ly, Lz = L
    return [_planar((Lx / 2, 0, 0), _rect_dh(Ly, Lz)), _planar((-Lx / 2, 0, 0), _rect_dh(Ly, Lz)),
            _planar((0, Ly / 2, 0), _rect_dh(Lx, Lz)), _planar((0, -Ly / 2, 0), _rect_dh(Lx, Lz))]


def _plenum_mesh(L, d_in, x_in, stub_in, d_out, xs_out, stubs_out) -> tuple[trimesh.Trimesh, tuple, list[tuple]]:
    Lx, Ly, Lz = L
    parts = [_box(L)]
    tip_in = (x_in, 0.0, Lz / 2 + stub_in * d_in)
    parts.append(_cyl(d_in / 2, Lz / 2 + stub_in * d_in, "z", (x_in, 0, 0)))
    tips_out = []
    for x, s in zip(xs_out, stubs_out):
        h = Lz / 2 + s * d_out
        parts.append(_cyl(d_out / 2, h, "z", (x, 0, -h)))
        tips_out.append((x, 0.0, -h))
    return _union(parts), tip_in, tips_out


def plenum_box_nozzles(stub_in: float = 2.0, stubs_out=(2.0, 2.0, 2.0), L=BOX, d_in=D_IN, x_in=X_IN, d_out=D_OUT, xs_out=XS_OUT):
    """Rectangular plenum, one inlet nozzle on top, outlet nozzles on the bottom. The four sides are planar faces;
    the top and bottom carry nozzle roots, so their facets have inner loops and are rings."""
    Lx, Ly, Lz = L
    mesh, tip_in, tips_out = _plenum_mesh(L, d_in, x_in, stub_in, d_out, xs_out, stubs_out)
    ports = [port(tip_in, "inlet", d_in, stub_in, classification=_nozzle_class(stub_in), needs_model=True)]
    ports += [port(t, "outlet", d_out, s, classification=_nozzle_class(s), needs_model=True) for t, s in zip(tips_out, stubs_out)]
    ports += _box_side_ports(L) + [_ring((0, 0, Lz / 2)), _ring((0, 0, -Lz / 2))]
    stubs = [stub_in, *stubs_out]
    n_pc = sum(1 for s in stubs if _nozzle_class(s) == "port_candidate")
    exp = {"openings": 1 + len(xs_out) + 4 + 2, "regions": 1, "watertight": True, "ports": ports,
           "port_candidates": n_pc, "planar_faces_min": 4 + (1 + len(xs_out) - n_pc),
           "forbid_risks": ["not_watertight", "surface_holes", "solid_wall_representation", "region_purpose_mismatch"],
           "expect_risks": ["ring_faces_present"]}
    if n_pc >= 2:
        if d_in / d_out > 2:
            exp["expect_risks"].append("velocity_spread")
        if any(_nozzle_class(s) == "port_candidate" and s < 5 for s in stubs_out):
            exp["expect_risks"].append("short_stub")
    return mesh, exp


def plenum_box_flush(d_in: float, d_out: float, L=BOX, x_in=X_IN, xs_out=XS_OUT):
    """The same plenum with the ports cut flush: the nozzle faces are deleted, leaving open rims in the box faces.
    What the facts layer can see follows from its own rules: each rim lies flat in a wall (tubularity 0, so
    'hole'); a box face with holes keeps its facet only if the open hole edges are under 15% of its boundary
    (MIN_TUBULARITY), and then it is a ring. The file is a fluid volume with flush ports either way."""
    Lx, Ly, Lz = L
    mesh, _, _ = _plenum_mesh(L, d_in, x_in, 1.0, d_out, xs_out, [1.0] * len(xs_out))
    keep = np.abs(mesh.triangles_center[:, 2]) <= Lz / 2 + 1e-9
    mesh = mesh.copy()
    mesh.update_faces(keep)
    mesh.remove_unreferenced_vertices()
    rims = [port((x_in, 0, Lz / 2), "any", d_in, kind="rim", classification="hole")]
    rims += [port((x, 0, -Lz / 2), "any", d_out, kind="rim", classification="hole") for x in xs_out]
    outer = 2 * (Lx + Ly)
    top_tub = outer / (outer + math.pi * d_in)
    bot_tub = outer / (outer + len(xs_out) * math.pi * d_out)
    # a box face carrying flush holes stays listed as a ring whatever the holes' share of its boundary: the open
    # hole edges are counted apart from the wall boundary, so the face's tubularity is judged on the outer rim
    rings = [_ring((0, 0, Lz / 2)), _ring((0, 0, -Lz / 2))]
    ports = rims + _box_side_ports(L) + rings
    exp = {"openings": len(ports), "regions": 1, "watertight": False, "ports": ports,
           "port_candidates": 0, "planar_faces_min": 4, "holes_min": len(rims),
           "expect_risks": ["not_watertight", "surface_holes"],
           # the file is a fluid box with flush ports, not the metal of a pipe
           "forbid_risks": ["solid_wall_representation", "region_purpose_mismatch"],
           "flush_face_tubularity": {"top": round(top_tub, 3), "bottom": round(bot_tub, 3)}}
    return mesh, exp


# ---- shower head ---------------------------------------------------------------------------------------------------

def hex_points(rings: int, pitch: float) -> list[tuple[float, float]]:
    pts = []
    for i in range(-rings, rings + 1):
        for j in range(-rings, rings + 1):
            if max(abs(i), abs(j), abs(i + j)) <= rings:
                pts.append((pitch * (i + j / 2), pitch * j * math.sqrt(3) / 2))
    return pts


def showerhead(n_rings: int = 4, d: float = 0.004, pitch_over_d: float = 3.0, stub: float = 2.0,
               R: float = 0.06, t: float = 0.012, d_in: float = 0.02, stub_in: float = 2.0):
    """Disc plenum with one inlet nozzle on top and a hex pattern of identical outlet nozzles below.
    Nozzle pitch is 3D so no neighbour falls inside a march's 1.5D entry radius or 2D corridor."""
    pts = hex_points(n_rings, pitch_over_d * d)
    disc = trimesh.creation.cylinder(radius=R, height=t, sections=96)
    parts = [disc, _cyl(d_in / 2, t / 2 + stub_in * d_in, "z", (0, 0, 0))]
    tip = t / 2 + stub * d
    for x, y in pts:
        parts.append(_cyl(d / 2, tip, "z", (x, y, -tip)))
    mesh = _union(parts)
    ports = [port((0, 0, t / 2 + stub_in * d_in), "inlet", d_in, stub_in, needs_model=True)]
    ports += [port((x, y, -tip), "outlet", d, stub, needs_model=True) for x, y in pts]
    ports += [_ring((0, 0, t / 2)), _ring((0, 0, -t / 2))]
    exp = {"openings": len(pts) + 1 + 2, "port_candidates": len(pts) + 1, "regions": 1, "watertight": True, "ports": ports,
           "nozzle_count": len(pts), "rotational_symmetry_order": 6,
           "expect_risks": ["short_stub", "velocity_spread", "ring_faces_present"],
           "forbid_risks": ["rotor_topology", "not_watertight", "surface_holes", "region_purpose_mismatch"],
           "measure_seconds_max": 60}
    return mesh, exp


# ---- alternating header ------------------------------------------------------------------------------------------

def header_alternating(n: int = 12, d_main: float = 0.10, d_branch: float = 0.03, stub: float = 6.0,
                       end_over_d: float = 6.0, pitch_over_d: float = 1.5):
    """Header along x with n identical branch outlets alternating +y and -y. Symmetric about z=0 and under a
    half turn about the z axis through its centre (branch k maps onto branch n-1-k on the other side)."""
    end, pitch = end_over_d * d_main, pitch_over_d * d_main
    main_len = 2 * end + (n - 1) * pitch
    xs = [end + k * pitch for k in range(n)]
    tip = d_main / 2 + stub * d_branch
    parts = [_cyl(d_main / 2, main_len, "x", (0, 0, 0))]
    tips = []
    for k, x in enumerate(xs):
        if k % 2 == 0:
            parts.append(_cyl(d_branch / 2, tip, "y", (x, 0, 0)))
            tips.append((x, tip, 0.0))
        else:
            parts.append(_cyl(d_branch / 2, tip, "y", (x, -tip, 0)))
            tips.append((x, -tip, 0.0))
    mesh = _union(parts)
    ports = [port((0, 0, 0), "any", d_main, end_over_d, needs_model=True), port((main_len, 0, 0), "any", d_main, end_over_d, needs_model=True)]
    ports += [port(tp, "outlet", d_branch, stub, needs_model=True) for tp in tips]
    exp = {"openings": n + 2, "port_candidates": n + 2, "regions": 1, "watertight": True, "ports": ports,
           "symmetry_planes_min": 1, "rotational_symmetry_order": 2,
           "expect_risks": ["velocity_spread"] if d_main / d_branch > 2 else [],
           "forbid_risks": ["short_stub", "not_watertight", "ring_faces_present", "rotor_topology"],
           "model_roles_any_of_by_position": [[[0, 0, 0], "inlet"], [[main_len, 0, 0], "inlet"]]}
    return mesh, exp


# ---- box ducts -----------------------------------------------------------------------------------------------------

def box_duct(length_over_d: float, a: float = 0.1):
    """A square duct of side a and length length_over_d * a along x, as a fluid box. The end faces have the
    full section behind them; whether that reads as a tube or as one side of a slab follows the slab rule
    (a twin face within SLAB_STUB_OVER_D). The four long sides are always planar faces."""
    Lx = length_over_d * a
    mesh = _box((Lx, a, a), (Lx / 2, 0, 0))
    steps = math.floor(length_over_d / STUB_STEP - 1e-9)
    measured = steps * STUB_STEP           # the march is quantised to sixths of a diameter and stops inside the body
    end_class = "planar_face" if measured < SLAB_STUB_OVER_D else "port_candidate"
    tol = max(0.3, length_over_d - measured + 0.05)
    ports = [port((0, 0, 0), "inlet", a, length_over_d, classification=end_class, needs_model=True, stub_tol=tol),
             port((Lx, 0, 0), "outlet", a, length_over_d, classification=end_class, needs_model=True, stub_tol=tol)]
    ports += [_planar((Lx / 2, a / 2, 0), _rect_dh(Lx, a) if Lx / a <= 10 else None), _planar((Lx / 2, -a / 2, 0), _rect_dh(Lx, a) if Lx / a <= 10 else None),
              _planar((Lx / 2, 0, a / 2), _rect_dh(Lx, a) if Lx / a <= 10 else None), _planar((Lx / 2, 0, -a / 2), _rect_dh(Lx, a) if Lx / a <= 10 else None)]
    n_pc = 2 if end_class == "port_candidate" else 0
    exp = {"openings": 6, "regions": 1, "watertight": True, "ports": ports, "port_candidates": n_pc, "planar_faces_min": 6 - n_pc,
           "forbid_risks": ["ring_faces_present", "not_watertight", "surface_holes", "region_purpose_mismatch"]}
    if n_pc == 2 and measured >= 5:
        exp["forbid_risks"].append("short_stub")
    elif n_pc == 2:
        exp["expect_risks"] = ["short_stub"]
    exp["symmetry_planes_min"] = 3   # a box is mirror-symmetric about all three of its mid-planes
    return mesh, exp


# ---- microchannel plate ---------------------------------------------------------------------------------------------

def microchannel_plate(nx: int = 20, ny: int = 10, d: float = 0.0005, pitch: float = 0.001, length: float = 0.03,
                       depth: float = 0.004, pd: float = 0.004, port_stub: float = 6.0):
    """nx*ny channels of diameter d between two rectangular plenums, each with one round port nozzle. One fluid
    body: two port candidates, the plenums' eight narrow sides are planar faces, the four plenum faces that carry
    channel roots or the port root are rings. The channel bore sets the minimum wall-to-wall thickness."""
    # trimesh cannot make a watertight cylinder 0.25 mm in radius in metres (its vertex merge collapses it), so the
    # plate is built a thousand times larger and scaled back: the file is in metres like the rest of the corpus.
    S = 1000.0
    tubes = [_cyl(S * d / 2, S * (length + depth), "x", (-S * depth / 2, S * (i - (nx - 1) / 2) * pitch, S * (j - (ny - 1) / 2) * pitch))
             for i in range(nx) for j in range(ny)]
    wy, wz = nx * pitch + d, ny * pitch + d
    pin = _box((S * depth, S * wy, S * wz), (-S * depth / 2, 0, 0))
    pout = _box((S * depth, S * wy, S * wz), (S * (length + depth / 2), 0, 0))
    port_in = _cyl(S * pd / 2, S * port_stub * pd, "x", (-S * (depth + port_stub * pd), 0, 0))
    port_out = _cyl(S * pd / 2, S * port_stub * pd, "x", (S * (length + depth), 0, 0))
    mesh = _union([pin, pout, port_in, port_out] + tubes)
    mesh.apply_scale(1.0 / S)
    x_in, x_out = -depth - port_stub * pd, length + depth + port_stub * pd
    ports = [port((x_in, 0, 0), "inlet", pd, port_stub, needs_model=True), port((x_out, 0, 0), "outlet", pd, port_stub, needs_model=True)]
    for xc in (-depth / 2, length + depth / 2):
        ports += [_planar((xc, wy / 2, 0), _rect_dh(depth, wz)), _planar((xc, -wy / 2, 0), _rect_dh(depth, wz)),
                  _planar((xc, 0, wz / 2), _rect_dh(depth, wy)), _planar((xc, 0, -wz / 2), _rect_dh(depth, wy))]
    ports += [_ring((-depth, 0, 0)), _ring((0, 0, 0)), _ring((length, 0, 0)), _ring((length + depth, 0, 0))]
    exp = {"openings": len(ports), "port_candidates": 2, "planar_faces_min": 8, "regions": 1, "watertight": True, "ports": ports,
           "channel_count": nx * ny, "thickness_min_between": [0.9 * d, 1.12 * d], "symmetry_planes_min": 2,
           "forbid_risks": ["region_purpose_mismatch", "not_watertight", "surface_holes", "short_stub"],
           "expect_risks": ["ring_faces_present"], "measure_seconds_max": 60}
    return mesh, exp


# ---- the family -------------------------------------------------------------------------------------------------------

def build_cases() -> list[Case]:
    ic = "internal_cfd"
    cases: list[Case] = []
    add = cases.append
    add(_case("plenum_box_nozzles_2d", FAMILY, ic, lambda: plenum_box_nozzles(2.0, (2.0, 2.0, 2.0)),
              brief="Rectangular plenum box, 300 by 200 by 100. One 60 mm inlet nozzle on top, three 25 mm outlet nozzles underneath, all nozzles two diameters long.",
              note="four nozzle caps are the port candidates; the box's four sides are planar faces; the top and bottom faces carry nozzle roots so their facets are rings"))
    add(_case("plenum_box_flush_large", FAMILY, ic, lambda: plenum_box_flush(D_IN, D_OUT),
              brief="Rectangular plenum, 60 mm inlet in the top face, three 25 mm outlets in the bottom face, ports cut flush with no stubs.",
              note="flush ports are open rims lying flat in the wall: holes by the rules; the top and bottom faces carry the holes and stay listed as rings (their open hole edges are not counted against their tubularity)"))
    add(_case("plenum_box_flush_small", FAMILY, ic, lambda: plenum_box_flush(0.03, 0.012),
              brief="Rectangular plenum, 30 mm inlet in the top face, three 12 mm outlets in the bottom face, ports cut flush with no stubs.",
              note="smaller flush holes: the top and bottom faces survive as rings on the bounding box; two end rings and no port candidate must not be read as a pipe wall (the body is a fluid box)"))
    add(_case("plenum_box_nozzles_0p3d", FAMILY, ic, lambda: plenum_box_nozzles(0.3, (0.3, 0.3, 0.3)),
              brief="Rectangular plenum with one inlet boss on top and three outlet bosses below, each boss 0.3 diameters tall.",
              note="under FLUSH_STUB_OVER_D the nozzle faces are flush with the wall: planar_face, roles from the brief only"))
    add(_case("plenum_box_stub_ladder", FAMILY, ic, lambda: plenum_box_nozzles(3.0, (0.25, 0.75, 1.6, 4.1), xs_out=(-0.11, -0.04, 0.03, 0.10)),
              brief="Plenum with one inlet nozzle on top and four outlet nozzles of different lengths below.",
              note="stubs 0.25, 0.75, 1.6, 4.1 D: the first is flush (planar_face), the rest are port candidates with short stubs"))
    add(_case("showerhead_61_hex", FAMILY, ic, lambda: showerhead(),
              brief="Shower head: a 120 mm disc plenum fed by a 20 mm inlet on top, 61 outlet nozzles of 4 mm in a hexagonal pattern on the face.",
              note="61 identical outlets must read as one group; the pattern has 6-fold symmetry about the disc axis; the nozzle bores are thin but this is not a rotor"))
    add(_case("header_12_alternating", FAMILY, ic, lambda: header_alternating(),
              brief="Distribution header with twelve identical 30 mm branch outlets alternating up and down along a 100 mm run; fed from one end, blanked at the other.",
              note="12 identical branches in two facing groups; mirror plane z=0; half-turn symmetry about z through the centre"))
    add(_case("cube_duct_full_faces", FAMILY, ic, lambda: box_duct(1.0),
              brief="Cube-shaped duct segment 100 mm on a side: flow enters through the whole -x face and leaves through the whole +x face; the other four faces are walls.",
              note="all six faces are planar by geometry (one diameter of body behind each, a twin face looking back); only the brief makes two of them ports"))
    add(_case("duct_segment_5p4d", FAMILY, ic, lambda: box_duct(5.4),
              brief="Square duct segment 100 by 100, 540 long; flow along it.",
              note="5.4 D of constant section behind each end face: port candidates; the sides are planar faces"))
    add(_case("duct_slab_2p1d", FAMILY, ic, lambda: box_duct(2.1),
              brief="Short square duct segment 100 by 100, 210 long; flow along it.",
              note="the march from each end reaches the far face within 3 D: a slab, so every face is planar and the brief decides"))
    add(_case("microchannel_200_plenums", FAMILY, ic, lambda: microchannel_plate(),
              brief="Microchannel cold plate: 200 channels of 0.5 mm diameter, 30 mm long, between an inlet plenum and an outlet plenum with one 4 mm port each.",
              note="scale: 0.5 mm channels in a 70 mm part; two port candidates, eight planar plenum sides, four rings; thickness_min is the channel bore"))
    return cases


def write_family(out: Path = OUT_DIR) -> list[Path]:
    out.mkdir(parents=True, exist_ok=True)
    return [c.write(out) for c in build_cases()]


def main() -> None:
    for p in write_family():
        print(p)


if __name__ == "__main__":
    main()
