"""An OpenAI-compatible /chat/completions server backed by any ModelClient. Proves the wire path without a key."""
from __future__ import annotations

import json
import threading
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from geometry_agent.agent.client import ModelClient, ModelError, ModelResponse, ToolCall


def _to_openai(resp: ModelResponse, model: str) -> dict:
    msg: dict = {"role": "assistant", "content": resp.content or None}
    if resp.tool_calls:
        msg["tool_calls"] = [{"id": tc.id, "type": "function",
                              "function": {"name": tc.name, "arguments": json.dumps(tc.arguments)}}
                             for tc in resp.tool_calls]
    return {"id": "chatcmpl-fake", "object": "chat.completion", "model": model,
            "choices": [{"index": 0, "message": msg, "finish_reason": "tool_calls" if resp.tool_calls else "stop"}],
            "usage": {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}}


def _from_openai(messages: list[dict]) -> list[dict]:
    return messages


@dataclass
class FakeProvider:
    policy_factory: type | None = None
    require_key: str | None = None
    fail_every: int = 0
    _server: ThreadingHTTPServer | None = None
    _thread: threading.Thread | None = None
    calls: int = 0

    def __post_init__(self):
        self._policies: dict[str, ModelClient] = {}

    @property
    def base_url(self) -> str:
        assert self._server is not None
        return f"http://127.0.0.1:{self._server.server_address[1]}/v1"

    def start(self) -> FakeProvider:
        provider = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *a):  # noqa: D401
                pass

            def do_GET(self):
                if self.path.endswith("/models"):
                    self._json(200, {"data": [{"id": "fake"}]})
                else:
                    self._json(404, {"error": "not found"})

            def do_POST(self):
                if not self.path.endswith("/chat/completions"):
                    return self._json(404, {"error": "not found"})
                if provider.require_key and self.headers.get("authorization") != f"Bearer {provider.require_key}":
                    return self._json(401, {"error": {"message": "invalid api key"}})
                body = json.loads(self.rfile.read(int(self.headers.get("content-length", 0)) or 0) or b"{}")
                provider.calls += 1
                if provider.fail_every and provider.calls % provider.fail_every == 0:
                    return self._json(500, {"error": {"message": "synthetic failure"}})
                key = str(id(threading.current_thread())) if False else "session"
                policy = provider._policies.get(key)
                if policy is None:
                    from geometry_agent.agent.reference import ReferencePolicy
                    policy = (provider.policy_factory or ReferencePolicy)()
                    provider._policies[key] = policy
                messages = _from_openai(body.get("messages", []))
                try:
                    resp = policy.complete(messages, body.get("tools", []))
                except ModelError as exc:
                    return self._json(500, {"error": {"message": str(exc)}})
                self._json(200, _to_openai(resp, body.get("model", "fake")))

            def _json(self, code: int, obj: dict):
                data = json.dumps(obj).encode()
                self.send_response(code)
                self.send_header("content-type", "application/json")
                self.send_header("content-length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

        self._server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)
        self._thread.start()
        return self

    def reset(self):
        self._policies.clear()
        self.calls = 0

    def stop(self):
        if self._server:
            self._server.shutdown()
            self._server.server_close()

    def __enter__(self):
        return self.start()

    def __exit__(self, *exc):
        self.stop()


__all__ = ["FakeProvider", "ToolCall"]
