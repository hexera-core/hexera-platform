"""March inward from each opening and measure how far the cross-section stays constant: the stub length.

The march tracks one section loop from station to station: the loop that continues the previous one (closest
centroid, area within AREA_TOL). Other closed loops on the same plane are read by where they sit: a loop that
ENCLOSES the tracked one is a surrounding passage (a vortex finder inside a cyclone, a dip tube, the inner pipe
of a tube-in-tube exchanger, a nozzle inside a plenum) and does not end the stub; a loop INSIDE the tracked
one is an island (a rod, an inner wall) whose area leaves the section; only a disjoint loop of comparable area
is a junction. Section centroids are polygon area centroids (shoelace in the section plane), not vertex means:
a B-rep wall tessellated into two long triangles gives a square loop 8 vertices whose mean slides along the
diagonals as the plane sweeps, which read as 30 mm of drift on a dead-straight 20 mm channel.

Constants (why these values):
  STEP_OVER_D 1/6         one station every sixth of a diameter: the quantum every stub length is reported in.
  AREA_TOL 0.20           a section within 20% of the entry area is "the same tube" (a taper past that is a change).
  DRIFT_OVER_D 0.30       the tracked centroid may wander 0.3 D laterally before the tube is called bent.
  JUNCTION_AREA_MIN 0.25  a disjoint loop beside the tracked one ends the stub only when it holds at least a
                          quarter of the tracked section: a passage of comparable size opening alongside. A
                          D/10 drain seen end-on (1% of the area) or a bolt hole does not end a stub.
  STATION_NUDGE 0.01      a station whose plane lies exactly on a wall (a B-rep face at a round number of
                          diameters, as the connector of a serpentine at 11.5 D) cuts nothing but open
                          chains; it is retried a hundredth of a step behind, where the tube still is.
  MOUTH_AREA_BAND (.5, 2) the mouth of a port is not always the tube: a 45 degree chamfer of 0.1 D on a
                          branch tip puts the entry probe in a cone and the bore behind at 1.56x the tip's
                          area; a B-spline inlet bulging 30 mm out of a 200x100 duct gives the probe three
                          quarters of the duct. When the first station disagrees with the probe by more than
                          AREA_TOL but within this band, and the second station agrees with the first, the
                          reference section is the settled one and the march goes on; the entry ratio
                          reported is whichever of the probe and the settled section lies nearer the face's
                          area. Outside the band (a box behind a flush hole is 20x) the face ends at once,
                          as before.
"""
from __future__ import annotations

import math
from typing import NamedTuple

import numpy as np
import trimesh

from geometry_agent.facts.schema import Opening, Stub

STEP_OVER_D = 1 / 6
MAX_MARCH_OVER_D = 25.0
AREA_TOL = 0.20
DRIFT_OVER_D = 0.30
NEARLY_CLOSED_FRACTION = 0.08
JUNCTION_AREA_MIN = 0.25
MOUTH_AREA_BAND = (0.5, 2.0)
#: Section loops whose centroid sits further than this from the march axis are not the tube being marched.
NEAR_RADIUS_OVER_D = 1.5


def _chain_segments(segs: np.ndarray, tol: float) -> list[np.ndarray]:
    """Chain (n,2,3) segments into loops by endpoint proximity. Returns only closed loops.

    The walk is the one this function has always done (vertices in order of first appearance, each walk leaving
    along the first neighbour listed, a chain that does not close walked back from its start and kept when its
    ends nearly meet), with the bookkeeping in arrays and plain lists instead of a dict built segment by segment
    and a numpy row per segment: a 4.36M-face part cuts 8,000 segments a station and this was 10 of its 29
    seconds of stub marching. `_chain_segments_reference` is the old form, kept for the test that pins the two
    to the same output."""
    if len(segs) == 0:
        return []
    segs = np.asarray(segs)
    pts = segs.reshape(-1, 3)
    key = np.round(pts / tol).astype(np.int64)
    _, first_at, inv = np.unique(key, axis=0, return_index=True, return_inverse=True)
    inv = inv.reshape(-1)
    canon = pts[first_at]
    pair = inv.reshape(-1, 2)
    keep = pair[:, 0] != pair[:, 1]
    ends = pair[keep].reshape(-1)
    if len(ends) == 0:
        return []
    others = pair[keep][:, ::-1].reshape(-1)
    order = np.argsort(ends, kind="stable")
    ends_sorted, nbrs = ends[order], others[order]
    n_ids = int(inv.max()) + 1
    starts = np.searchsorted(ends_sorted, np.arange(n_ids), side="left").tolist()
    stops = np.searchsorted(ends_sorted, np.arange(n_ids), side="right").tolist()
    nb = nbrs.tolist()
    _, first_seen = np.unique(ends, return_index=True)
    vertex_order = np.unique(ends)[np.argsort(first_seen, kind="stable")].tolist()
    seen = bytearray(n_ids)
    loops = []

    def walk(start: int, first: int) -> tuple[list[int], bool]:
        chain, prev, cur = [start], start, first
        while not seen[cur] and cur != start:
            seen[cur] = 1
            chain.append(cur)
            nxt = None
            for k in range(starts[cur], stops[cur]):
                if nb[k] != prev:
                    nxt = nb[k]
                    break
            if nxt is None:
                return chain, False
            prev, cur = cur, nxt
        return chain, cur == start

    for start in vertex_order:
        if seen[start] or starts[start] == stops[start]:
            continue
        seen[start] = 1
        head = nb[starts[start]]
        fwd, closed = walk(start, head)
        if closed:
            loop = fwd
        else:
            back: list[int] = []
            other = next((nb[k] for k in range(starts[start], stops[start]) if nb[k] != head), None)
            if other is not None:
                back, _ = walk(start, other)
            loop = list(reversed(back[1:])) + fwd
        if len(loop) < 3:
            continue
        pts_loop = canon[np.asarray(loop, dtype=np.int64)]
        if not closed:
            gap = float(np.linalg.norm(pts_loop[0] - pts_loop[-1]))
            length = float(np.sum(np.linalg.norm(np.diff(pts_loop, axis=0), axis=1)))
            closed = length > 0 and gap < NEARLY_CLOSED_FRACTION * length
        if closed:
            loops.append(pts_loop)
    return loops


def _chain_segments_reference(segs: np.ndarray, tol: float) -> list[np.ndarray]:
    """The walk as it was written first, one dict entry per segment: the reference `_chain_segments` is pinned to."""
    if len(segs) == 0:
        return []
    pts = segs.reshape(-1, 3)
    key = np.round(pts / tol).astype(np.int64)
    _, inv = np.unique(key, axis=0, return_inverse=True)
    inv = inv.reshape(-1, 2)
    adj: dict[int, list[int]] = {}
    for a, b in inv:
        if a == b:
            continue
        adj.setdefault(int(a), []).append(int(b))
        adj.setdefault(int(b), []).append(int(a))
    canon: dict[int, np.ndarray] = {}
    for (a, b), (pa, pb) in zip(inv, segs):
        canon.setdefault(int(a), pa)
        canon.setdefault(int(b), pb)
    seen: set[int] = set()
    loops = []

    def walk(start: int, first: int) -> tuple[list[int], bool]:
        chain, prev, cur = [start], start, first
        while cur not in seen and cur != start:
            seen.add(cur)
            chain.append(cur)
            nxt = [v for v in adj[cur] if v != prev]
            if not nxt:
                return chain, False
            prev, cur = cur, nxt[0]
        return chain, cur == start

    for start in adj:
        if start in seen or not adj[start]:
            continue
        seen.add(start)
        fwd, closed = walk(start, adj[start][0])
        if closed:
            loop = fwd
        else:
            back: list[int] = []
            others = [v for v in adj[start] if v != adj[start][0]]
            if others:
                back, _ = walk(start, others[0])
            loop = list(reversed(back[1:])) + fwd
        if len(loop) < 3:
            continue
        pts_loop = np.array([canon[v] for v in loop])
        if not closed:
            gap = float(np.linalg.norm(pts_loop[0] - pts_loop[-1]))
            length = float(np.sum(np.linalg.norm(np.diff(pts_loop, axis=0), axis=1)))
            closed = length > 0 and gap < NEARLY_CLOSED_FRACTION * length
        if closed:
            loops.append(pts_loop)
    return loops


def _loop_area_normal(pts: np.ndarray) -> float:
    pts = np.asarray(pts, dtype=float)
    n = np.cross(pts, np.roll(pts, -1, axis=0)).sum(axis=0)
    return float(np.linalg.norm(n) / 2)


def _loop_centroid(pts: np.ndarray) -> np.ndarray:
    """Area centroid of a closed planar polygon (fan of signed triangles from the vertex mean). Falls back to
    the vertex mean for a degenerate loop."""
    pts = np.asarray(pts, dtype=float)
    ref = pts.mean(axis=0)
    a = pts - ref
    b = np.roll(pts, -1, axis=0) - ref
    cross = np.cross(a, b)
    n = cross.sum(axis=0)
    nn = float(np.linalg.norm(n))
    if nn <= 0:
        return ref
    signed = cross @ (n / nn)
    total = float(signed.sum())
    if abs(total) <= 1e-12 * max(1.0, float(np.abs(signed).sum())):
        return ref
    tri_c = ref + (a + b) / 3.0
    return (tri_c * signed[:, None]).sum(axis=0) / total


class _Loop(NamedTuple):
    area: float
    centroid: np.ndarray
    pts: np.ndarray


def _plane_basis(normal: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    n = np.asarray(normal, dtype=float)
    n = n / max(float(np.linalg.norm(n)), 1e-12)
    helper = np.array([1.0, 0.0, 0.0]) if abs(n[0]) < 0.9 else np.array([0.0, 1.0, 0.0])
    u = np.cross(n, helper)
    u /= max(float(np.linalg.norm(u)), 1e-12)
    v = np.cross(n, u)
    return u, v


def _encloses(loop: _Loop, point: np.ndarray, u: np.ndarray, v: np.ndarray) -> bool:
    """Even-odd point-in-polygon of `point` against the loop, both projected onto the section plane basis."""
    rel = loop.pts - point
    x, y = rel @ u, rel @ v
    x2, y2 = np.roll(x, -1), np.roll(y, -1)
    crossing = (y > 0) != (y2 > 0)
    if not crossing.any():
        return False
    dy = y2 - y
    with np.errstate(divide="ignore", invalid="ignore"):
        xi = x + (-y) * (x2 - x) / dy
    hits = crossing & np.isfinite(xi) & (xi > 0)
    return bool(hits.sum() % 2 == 1)


def _chain_tol(mesh: trimesh.Trimesh) -> float:
    """Endpoint-merging tolerance for chaining section segments; read once per march, because every access to
    `mesh.extents` re-validates trimesh's cache with a hash of the vertex array."""
    return 1e-6 * float(np.linalg.norm(mesh.extents)) + 1e-12


#: A march over a corridor of more faces than this cuts each station through only the faces that straddle it
#: (`_Slicer`); below it the whole corridor is cut, which is cheaper than sorting it.
SLICER_MIN_FACES = 50_000


class _Slicer:
    """The faces a plane square to one direction can cut, found by where each face spans along that direction.

    Every station of a march is a plane square to the same direction, and `mesh_plane` otherwise takes the dot
    product of every vertex and classifies every face at every station: on a 4.36M-face part whose corridor was
    the whole part that was 28 of 41 seconds of stub marching. Here the per-vertex dot is taken once, the faces
    are sorted by the lowest dot of their vertices, and a station passes `mesh_plane` only the faces whose span
    along the direction reaches it, in their original order, so the segments come back in the order the full
    cut returns them."""

    def __init__(self, mesh: trimesh.Trimesh, direction: np.ndarray):
        self.direction = np.asarray(direction, dtype=float)
        vertices = np.asarray(mesh.vertices, dtype=float)
        self.vdot = vertices @ self.direction
        fd = self.vdot[np.asarray(mesh.faces)]
        self.lo, self.hi = fd.min(axis=1), fd.max(axis=1)
        self.order = np.argsort(self.lo, kind="stable")
        self.lo_sorted = self.lo[self.order]
        # a vertex within tol.merge of the plane is ON it for mesh_plane; the margin keeps every such face and
        # absorbs the rounding between v.n - o.n and (v - o).n
        self.margin = 4.0 * trimesh.tol.merge + 1e-12 * float(np.abs(self.vdot).max(initial=0.0))

    def cut(self, mesh: trimesh.Trimesh, origin: np.ndarray):
        s = float(np.asarray(origin, dtype=float) @ self.direction)
        k = int(np.searchsorted(self.lo_sorted, s + self.margin, side="right"))
        faces = self.order[:k]
        faces = np.sort(faces[self.hi[faces] >= s - self.margin])
        if len(faces) == 0:
            return None
        return trimesh.intersections.mesh_plane(mesh, plane_normal=self.direction, plane_origin=origin,
                                                local_faces=faces, cached_dots=self.vdot - s)


def _section_loops(mesh: trimesh.Trimesh, origin: np.ndarray, normal: np.ndarray, tol: float | None = None,
                   slicer: _Slicer | None = None) -> tuple[list[_Loop], bool]:
    """Every closed loop where the plane cuts the surface, plus whether the plane met surface that closed no
    loop at all (the corridor slice truncates long features into open chains): either way there is geometry
    there, so a march that finds no tube has reached a junction, not the end of the body."""
    if slicer is not None and np.array_equal(np.asarray(normal, dtype=float), slicer.direction):
        segs = slicer.cut(mesh, origin)
    else:
        segs = trimesh.intersections.mesh_plane(mesh, plane_normal=normal, plane_origin=origin)
    if segs is None or len(segs) == 0:
        return [], False
    if tol is None:
        tol = _chain_tol(mesh)
    loops = []
    for lp in _chain_segments(np.asarray(segs), tol):
        a = _loop_area_normal(lp)
        if a > 0:
            loops.append(_Loop(a, _loop_centroid(lp), lp))
    return loops, True


def _near_loops(loops: list[_Loop], origin: np.ndarray, radius: float) -> list[_Loop]:
    return [lp for lp in loops if float(np.linalg.norm(lp.centroid - origin)) <= radius]


def _section(mesh: trimesh.Trimesh, origin: np.ndarray, normal: np.ndarray, radius: float) -> tuple[int, float, np.ndarray | None, int]:
    """Closed section loops within `radius` of `origin`: count, area, area-weighted centroid, plus how much else
    the plane met (closed loops elsewhere on the plane, or 1 when it cut only open chains). The probe tools use
    this shape; the march itself works on the loops."""
    loops, met = _section_loops(mesh, origin, normal)
    if not loops:
        return 0, 0.0, None, (1 if met else 0)
    near = _near_loops(loops, origin, radius)
    if not near:
        return 0, 0.0, None, len(loops)
    area = float(sum(lp.area for lp in near))
    centroid = sum(lp.area * lp.centroid for lp in near) / area
    return len(near), area, centroid, len(loops)


def _inward(mesh: trimesh.Trimesh, opening: Opening) -> np.ndarray:
    n = np.asarray(opening.normal, dtype=float)
    c = np.asarray(opening.centroid, dtype=float)
    d = opening.hydraulic_diameter
    probe = 0.15 * d
    for sign in (-1.0, 1.0):
        loops, area, _, _ = _section(mesh, c + sign * probe * n, n, NEAR_RADIUS_OVER_D * d)
        if loops > 0 and area > 0:
            return sign * n
    return -n


MARCH_CORRIDOR_OVER_D = 2.0


#: Openings whose corridors are projected together in one matrix product against a body's face centres, and
#: the most that product may weigh: a 1.3M-face body times 64 openings is 634 MiB of float64 in one piece,
#: which is what killed a 402-body STEP measured beside another job; 32 MiB keeps a batch of six there and
#: the full 64 on anything under 65k faces.
CORRIDOR_BATCH = 64
CORRIDOR_BATCH_BYTES = 32 * 1024 * 1024


def _corridor_faces(centers: np.ndarray, openings: list[Opening]) -> list[np.ndarray | None]:
    """Face indices of each opening's march corridor: faces within MAX_MARCH_OVER_D diameters along the
    opening normal in either direction and MARCH_CORRIDOR_OVER_D diameters to the side. The band along the
    normal is one chunked matrix product for all openings of a body, and the lateral distance is taken on
    each band only: a thousand ports on a 273k-face rocket tube cost a second, not a pass over every face
    per port. None means the whole body (the corridor would keep everything, or too little to cut)."""
    out: list[np.ndarray | None] = [None] * len(openings)
    if len(centers) < 3 or not openings:
        return out
    batch = int(max(1, min(CORRIDOR_BATCH, CORRIDOR_BATCH_BYTES // (8 * len(centers)))))
    for start in range(0, len(openings), batch):
        chunk = openings[start:start + batch]
        normals = np.array([o.normal for o in chunk], dtype=float)
        along_all = centers @ normals.T
        for j, o in enumerate(chunk):
            d = max(o.hydraulic_diameter, 1e-9)
            c = np.asarray(o.centroid, dtype=float)
            n = normals[j]
            along = along_all[:, j] - float(c @ n)
            band = np.where(np.abs(along) <= (MAX_MARCH_OVER_D + 1.0) * d)[0]
            if len(band) < 3:
                continue
            rel = centers[band] - c
            lateral = np.linalg.norm(rel - along[band][:, None] * n, axis=1)
            keep = band[lateral <= MARCH_CORRIDOR_OVER_D * d]
            if 3 <= len(keep) < len(centers):
                out[start + j] = keep
    return out


def _march_corridor(mesh: trimesh.Trimesh, opening: Opening, faces: np.ndarray | None = None) -> trimesh.Trimesh:
    """The part of the surface the march can meet (see _corridor_faces). Every plane cut then runs on that
    slice instead of the whole 2M-face part; the section it sees is the same, because a section loop that
    counts sits within 1.5 diameters of the axis. `faces` is the precomputed corridor; without it the
    corridor is computed for this one opening."""
    if faces is None:
        faces = _corridor_faces(np.asarray(mesh.triangles_center), [opening])[0]
    if faces is None:
        return mesh
    return mesh.submesh([faces], append=True)


#: When the plane at a station falls exactly on a wall of the part (a B-rep face at a round number of
#: diameters), the cut degenerates into open chains; the station is retried this fraction of a step behind.
STATION_NUDGE = 0.01


def _lateral(vec: np.ndarray, direction: np.ndarray) -> float:
    return float(np.linalg.norm(vec - np.dot(vec, direction) * direction))


def _continuation(near: list[_Loop], prev_centroid: np.ndarray, prev_area: float, direction: np.ndarray, d: float) -> _Loop:
    """The loop that continues the tracked one: closest laterally among those of about the previous area;
    failing that the closest of the right area at any offset (drift will end the march); failing that the
    closest loop of any area (the area check will end it)."""
    by_offset = sorted(near, key=lambda lp: _lateral(lp.centroid - prev_centroid, direction))
    same_area = [lp for lp in by_offset if prev_area > 0 and abs(lp.area / prev_area - 1.0) <= AREA_TOL]
    close = [lp for lp in same_area if _lateral(lp.centroid - prev_centroid, direction) <= DRIFT_OVER_D * d]
    if close:
        return close[0]
    if same_area:
        return same_area[0]
    return by_offset[0]


def _sort_loops(near: list[_Loop], tracked: _Loop, direction: np.ndarray) -> tuple[list[_Loop], list[_Loop], list[_Loop]]:
    """(enclosing, islands, disjoint) among the other near loops, relative to the tracked loop."""
    u, v = _plane_basis(direction)
    enclosing, islands, disjoint = [], [], []
    for lp in near:
        if lp is tracked:
            continue
        if _encloses(lp, tracked.centroid, u, v):
            enclosing.append(lp)
        elif _encloses(tracked, lp.centroid, u, v):
            islands.append(lp)
        else:
            disjoint.append(lp)
    return enclosing, islands, disjoint


def measure_stub(mesh: trimesh.Trimesh, opening: Opening, corridor: np.ndarray | None = None) -> Stub:
    d = max(opening.hydraulic_diameter, 1e-9)
    mesh = _march_corridor(mesh, opening, corridor)
    direction = _inward(mesh, opening)
    c0 = np.asarray(opening.centroid, dtype=float)
    step = STEP_OVER_D * d
    max_steps = int(MAX_MARCH_OVER_D / STEP_OVER_D)
    radius = NEAR_RADIUS_OVER_D * d
    tol = _chain_tol(mesh)
    slicer = _Slicer(mesh, direction) if len(mesh.faces) > SLICER_MIN_FACES else None

    loops, _met = _section_loops(mesh, c0 + 0.05 * d * direction, direction, tol, slicer)
    near0 = _near_loops(loops, c0 + 0.05 * d * direction, radius)
    if not near0:
        return Stub(opening_id=opening.id, length=0.0, length_over_diameter=0.0, terminated_by="end_of_body", stations=0,
                    inward_direction=tuple(float(v) for v in direction), entry_loops=0,
                    entry_area_ratio=(0.0 if opening.area > 0 else None))
    tracked = _continuation(near0, c0, opening.area, direction, d)
    enclosing0, islands0, disjoint0 = _sort_loops(near0, tracked, direction)
    area0 = tracked.area - sum(lp.area for lp in islands0)
    loops0 = 1 + len(islands0) + len(disjoint0)
    entry_ratio = (area0 / opening.area) if opening.area > 0 else None
    if area0 <= 0:
        return Stub(opening_id=opening.id, length=0.0, length_over_diameter=0.0, terminated_by="end_of_body", stations=0,
                    inward_direction=tuple(float(v) for v in direction), entry_loops=int(loops0), entry_area_ratio=entry_ratio)
    cen0 = tracked.centroid
    prev_centroid, prev_area = cen0, tracked.area
    length = 0.0
    reason = "max_march"
    mouth: tuple[float, np.ndarray] | None = None  # (area, centroid) of station 1 when the probe sat in a mouth
    k = 1
    while k <= max_steps:
        origin = c0 + k * step * direction
        loops, met = _section_loops(mesh, origin, direction, tol, slicer)
        near = _near_loops(loops, origin, radius)
        if not near and met:
            nudged = origin - STATION_NUDGE * step * direction
            loops, met = _section_loops(mesh, nudged, direction, tol, slicer)
            near = _near_loops(loops, nudged, radius)
        if not near and loops:
            # the tube has run into a passage so wide its centroid is off the axis: still the section it flows into
            u, v = _plane_basis(direction)
            near = [lp for lp in loops if _encloses(lp, prev_centroid, u, v)]
        if not near:
            reason = "junction" if (loops or met) else "end_of_body"
            break
        pick = _continuation(near, prev_centroid, prev_area, direction, d)
        _enclosing, islands, disjoint = _sort_loops(near, pick, direction)
        if any(lp.area >= JUNCTION_AREA_MIN * pick.area for lp in disjoint):
            reason = "junction"
            break
        area = pick.area - sum(lp.area for lp in islands)
        if area <= 0:
            reason = "area_change"
            break
        if mouth is not None:
            # station 1 disagreed with the probe: it was the tube only if station 2 agrees with it
            if abs(area / mouth[0] - 1.0) > AREA_TOL:
                reason = "area_change"
                break
            area0, cen0 = mouth[0], mouth[1]
            if opening.area > 0:
                settled = area0 / opening.area
                entry_ratio = settled if abs(settled - 1.0) < abs((entry_ratio or 0.0) - 1.0) else entry_ratio
            mouth = None
        elif abs(area / area0 - 1.0) > AREA_TOL:
            ratio = area / area0
            if k == 1 and MOUTH_AREA_BAND[0] <= ratio <= MOUTH_AREA_BAND[1]:
                mouth = (area, pick.centroid)
            else:
                reason = "area_change"
                break
        if _lateral(pick.centroid - cen0, direction) > DRIFT_OVER_D * d:
            reason = "drift"
            break
        prev_centroid, prev_area = pick.centroid, pick.area
        if mouth is None:
            length = k * step
        k += 1
    end = c0 + length * direction
    return Stub(
        opening_id=opening.id, length=float(length), length_over_diameter=float(length / d),
        terminated_by=reason, stations=k,
        end_point=tuple(float(v) for v in end), inward_direction=tuple(float(v) for v in direction),
        entry_loops=int(loops0), entry_area_ratio=entry_ratio,
    )


def measure_stubs(mesh: trimesh.Trimesh, openings: list[Opening], max_openings: int = 12,
                  keep_going=None) -> list[Stub]:
    """Stubs for the first `max_openings` openings. `keep_going(k)` may stop the loop early (a time budget);
    the stubs already measured are returned."""
    from geometry_agent.facts.regions import region_meshes
    parts = region_meshes(mesh)
    todo = openings[:max_openings]

    def part_of(o: Opening) -> tuple[int, trimesh.Trimesh]:
        idx = int(o.region_id[1:]) - 1
        return (idx, parts[idx]) if 0 <= idx < len(parts) else (-1, mesh)

    by_part: dict[int, list[int]] = {}
    for k, o in enumerate(todo):
        if o.kind != "ring":
            by_part.setdefault(part_of(o)[0], []).append(k)
    corridor: dict[int, np.ndarray | None] = {}
    for idx, ks in by_part.items():
        body = parts[idx] if idx >= 0 else mesh
        for k, faces in zip(ks, _corridor_faces(np.asarray(body.triangles_center), [todo[k] for k in ks])):
            corridor[k] = faces

    out = []
    for k, o in enumerate(todo):
        if keep_going is not None and not keep_going(k):
            break
        if o.kind == "ring":
            out.append(measure_ring_stub(part_of(o)[1], o))
            continue
        out.append(measure_stub(part_of(o)[1], o, corridor.get(k)))
    return out


#: A ring whose annulus is narrower than this fraction of its bore is the open end of a wall shell: its stub is
#: the bore (the cavity the mesher carves). A wider ring is an annular passage around a hub: its stub is the
#: annulus. The catalog draws the wall-shell line at the same fraction.
RING_BORE_TRACK_FRACTION = 0.15


def measure_ring_stub(mesh: trimesh.Trimesh, ring: Opening) -> Stub:
    """A ring's stub is tracked like a cap's, on the section the flow actually uses: the bore loop of a thin ring
    (the section inside a pipe wall has two loops, the outer skin and the bore; the continuation picks the loop
    of the bore's area and the outer loop encloses it), or the annulus of a thick ring (outer loop minus the hub
    island). Lengths are over the tracked diameter."""
    bore = ring.bore_diameter or 0.0
    if bore <= 0 or ring.hydraulic_diameter <= 0:
        return Stub(opening_id=ring.id, length=0.0, length_over_diameter=0.0, terminated_by="end_of_body", stations=0)
    annulus = (ring.hydraulic_diameter - bore) / 2.0
    if annulus < RING_BORE_TRACK_FRACTION * bore:
        probe = ring.model_copy(update={"kind": "cap", "hydraulic_diameter": bore, "area": math.pi / 4.0 * bore * bore})
    else:
        probe = ring.model_copy(update={"kind": "cap"})
    stub = measure_stub(mesh, probe, None)
    return stub.model_copy(update={"opening_id": ring.id})
