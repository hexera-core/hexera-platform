"""Load a geometry file into a single trimesh.Trimesh. STL/OBJ/PLY natively; STEP via optional OCP.

A STEP file can hold several solids. Each becomes a body: its faces are tessellated and vertex-merged on their
own, so two solids that share an interface keep separate copies of the shared faces and each body stays a closed
shell. The body index rides on `mesh.face_attributes["body"]`; regions are read from it when present.

A surface file gets the cleanup an exporter owes it before anything is measured: vertex copies within a radius
scaled to the part are one vertex, degenerate and exactly duplicated triangles are dropped, and stray crumbs
(components too small to be a body) are removed and counted in `mesh.metadata["debris_components"]`. The edge
table and the face connectivity built from it are computed once per mesh object and cached on it
(`edge_table`, `face_components`), so no later stage rebuilds a 3F x 2 edge array of its own."""
from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import trimesh

MESH_SUFFIXES = {".stl", ".obj", ".ply", ".off", ".glb", ".gltf"}
STEP_SUFFIXES = {".step", ".stp"}
IGES_SUFFIXES = {".iges", ".igs"}
BODY_ATTR = "body"
DEBRIS_META = "debris_components"

#: Vertex copies closer than this fraction of the bounding diagonal are one vertex. A kernel with a loose tolerance
#: writes each triangle's corners independently and leaves them apart by about 1e-9 of the part; the smallest real
#: feature on the same part is never within 1e-7 of its size (a 0.5 mm feature on a 700 mm assembly is 7e-4).
MERGE_TOL_OF_DIAG = 1e-7
#: A connected component with fewer faces than a tetrahedron cannot enclose anything: a stray triangle, a doubled
#: triangle, a folded pair.
DEBRIS_MIN_FACES = 4
#: An open component under this fraction of the total area is export debris (a crumb, a torn sliver), not a shell
#: with a hole in it: the 20 stray 0.1 mm triangles on a 0.6 m manifold total 1e-7 of its area.
DEBRIS_AREA_FRACTION = 1e-6
#: A closed component under DEBRIS_AREA_FRACTION whose bounding diagonal is under this many median edge lengths of
#: the whole mesh is a folded sliver, not a body: no mesher resolves a body smaller than one triangle of the part.
#: A real small bolt on an assembly spans many of the assembly's edges.
DEBRIS_CLOSED_DIAG_OVER_EDGE = 1.0
#: Faces meeting at an edge with three or more faces are paired by the wedge rule below; past this many such edges
#: the remaining ones are joined as one sheet, so a badly torn 7M-face export stays bounded.
NONMANIFOLD_PAIR_LIMIT = 200_000
#: Two faces at the same edge whose in-plane directions differ by less than this angle are copies of one surface
#: (the two bodies' shared joint faces, opposite normals); a body has no zero-angle wedge, so they never pair.
COINCIDENT_ANGLE_RAD = 1e-6


class UnsupportedGeometry(Exception):
    pass


def sha256_of(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def load_mesh(path: Path, angular_deflection: float = 0.2, linear_deflection: float | None = None) -> trimesh.Trimesh:
    suffix = path.suffix.lower()
    if suffix in MESH_SUFFIXES:
        mesh = _as_single(trimesh.load(path, force="mesh", process=False))
    elif suffix in STEP_SUFFIXES or suffix in IGES_SUFFIXES:
        mesh = _load_step(path, angular_deflection, linear_deflection)
    else:
        raise UnsupportedGeometry(f"{path.name}: unsupported format {suffix!r}; supported: {sorted(MESH_SUFFIXES | STEP_SUFFIXES | IGES_SUFFIXES)}")
    return drop_debris(mesh)


def body_of_face(mesh: trimesh.Trimesh) -> np.ndarray | None:
    """Per-face body index when the loader knew the bodies (STEP solids); None for a plain surface file."""
    body = mesh.face_attributes.get(BODY_ATTR)
    if body is None or len(body) != len(mesh.faces):
        return None
    return np.asarray(body, dtype=int)


def _as_single(obj) -> trimesh.Trimesh:
    if isinstance(obj, trimesh.Scene):
        geoms = [g for g in obj.dump() if isinstance(g, trimesh.Trimesh)]
        if not geoms:
            raise UnsupportedGeometry("scene contains no triangle geometry")
        obj = trimesh.util.concatenate(geoms)
    if not isinstance(obj, trimesh.Trimesh) or len(obj.faces) == 0:
        raise UnsupportedGeometry("file contains no triangles")
    return clean_surface(obj)


# ---- cleanup -------------------------------------------------------------------------------------------------

def clean_surface(mesh: trimesh.Trimesh) -> trimesh.Trimesh:
    """Vertex copies merged within MERGE_TOL_OF_DIAG of the diagonal, degenerate faces (a repeated vertex) and
    exact duplicate faces (same vertices, same winding) dropped. A face and its reversed copy are kept: that is
    how two touching bodies each carry the joint surface, which `interfaces` reads."""
    merge_close_vertices(mesh)
    faces = np.asarray(mesh.faces)
    degenerate = (faces[:, 0] == faces[:, 1]) | (faces[:, 1] == faces[:, 2]) | (faces[:, 2] == faces[:, 0])
    if degenerate.any():
        mesh.update_faces(~degenerate)
        faces = np.asarray(mesh.faces)
    if len(faces):
        dup = _duplicate_face_mask(faces)
        if dup.any():
            mesh.update_faces(~dup)
    mesh.remove_unreferenced_vertices()
    if len(mesh.faces) == 0:
        raise UnsupportedGeometry("file contains no non-degenerate triangles")
    return mesh


def _duplicate_face_mask(faces: np.ndarray) -> np.ndarray:
    """True for every face after the first that lists the same three vertices in the same cyclic order."""
    faces = np.asarray(faces, dtype=np.int64)
    k = np.argmin(faces, axis=1)
    rows = np.arange(len(faces))
    rolled = np.stack([faces[rows, (k + i) % 3] for i in range(3)], axis=1)
    first, _ = _row_groups(rolled)
    mask = np.ones(len(faces), dtype=bool)
    mask[first] = False
    return mask


def _row_groups(rows: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """(first index of each distinct row, the group of every row), groups numbered in sorted-row order.

    A stable sort on the columns, so the first row of each run is the earliest occurrence: the same first
    indices `np.unique(rows, axis=0, return_index=True)` gives, in a fraction of the time on millions of rows
    (it sorts a byte view of each row as one opaque value)."""
    n = len(rows)
    if n == 0:
        return np.zeros(0, dtype=np.int64), np.zeros(0, dtype=np.int64)
    order = np.lexsort(rows.T[::-1])
    srt = rows[order]
    new = np.empty(n, dtype=bool)
    new[0] = True
    new[1:] = np.any(srt[1:] != srt[:-1], axis=1)
    group_sorted = np.cumsum(new) - 1
    group = np.empty(n, dtype=np.int64)
    group[order] = group_sorted
    return order[new], group


def _merge_exact(mesh: trimesh.Trimesh) -> None:
    """trimesh's `merge_vertices`, the same result to the last index, with its grouping done by a column sort.

    trimesh rounds each vertex to `tol.merge` digits and groups the rounded rows through `np.unique` on a byte
    view of the row, which on the 13M unmerged vertices of a 4.36M-face STL was 15 of the load's 37 seconds.
    Here the rows are grouped by a stable sort on their three integer columns, and the groups are numbered in
    order of first occurrence as trimesh numbers them, so `mask` and `inverse` are identical and the mesh that
    comes out is the one trimesh would have made. A mesh carrying vertex normals or UV texture, which trimesh
    also groups on, is handed to trimesh."""
    if len(mesh.vertices) == 0:
        return
    visual = getattr(mesh, "visual", None)
    textured = visual is not None and visual.defined and visual.kind == "texture"
    normals = mesh._cache["vertex_normals"]
    if textured or np.shape(normals) == mesh.vertices.shape:
        mesh.merge_vertices()
        return
    digits = trimesh.util.decimal_to_digits(trimesh.tol.merge)
    referenced = np.zeros(len(mesh.vertices), dtype=bool)
    referenced[np.asarray(mesh.faces)] = True
    stacked = (np.asarray(mesh.vertices) * (10 ** digits)).round().astype(np.int64)[referenced]
    first, group = _row_groups(stacked)
    by_first = np.argsort(first, kind="stable")
    rank = np.empty(len(first), dtype=np.int64)
    rank[by_first] = np.arange(len(first))
    inverse = np.zeros(len(mesh.vertices), dtype=np.int64)
    inverse[referenced] = rank[group]
    mesh.update_vertices(mask=np.nonzero(referenced)[0][first[by_first]], inverse=inverse)


def merge_close_vertices(mesh: trimesh.Trimesh, tol: float | None = None) -> None:
    """Merge every pair of vertices within `tol` (default MERGE_TOL_OF_DIAG x the bounding diagonal): an exact merge
    first, then a radius search over what is left, so copies that straddle a rounding boundary still meet. A pure
    hash merge (trimesh's, at 1e-8 absolute) leaves copies 2e-9 apart unmerged whenever they round apart."""
    from scipy.spatial import cKDTree

    if len(mesh.vertices) == 0:
        return
    _merge_exact(mesh)
    if tol is None:
        tol = MERGE_TOL_OF_DIAG * float(np.linalg.norm(mesh.extents))
    if tol <= 0:
        return
    verts = np.asarray(mesh.vertices)
    pairs = cKDTree(verts).query_pairs(r=tol, output_type="ndarray")
    if len(pairs) == 0:
        return
    parent = np.arange(len(verts))

    def find(i: int) -> int:
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    for a, b in pairs:
        ra, rb = find(int(a)), find(int(b))
        if ra != rb:
            parent[max(ra, rb)] = min(ra, rb)
    touched = np.unique(pairs.reshape(-1))
    roots = np.arange(len(verts))
    for i in touched:
        roots[i] = find(int(i))
    mesh.faces = roots[np.asarray(mesh.faces)]
    mesh.remove_unreferenced_vertices()


# ---- edge table and connectivity -----------------------------------------------------------------------------

_EDGE_ATTR = "_geometry_agent_load_edge_table"
_COMP_ATTR = "_geometry_agent_load_face_components"


@dataclass
class EdgeTable:
    """Every distinct edge of the mesh once. `edges[e]` is (lo, hi) vertex ids; `counts[e]` how many faces use it;
    the faces at edge e are `face_ids[face_ptr[e]:face_ptr[e + 1]]`, and `face_dir` (parallel to face_ids) is +1
    when that face traverses the edge lo -> hi, -1 when hi -> lo. `face_edge[f, k]` is the edge id of face f's
    k-th edge (its vertices k and k+1 mod 3)."""
    edges: np.ndarray
    counts: np.ndarray
    face_ptr: np.ndarray
    face_ids: np.ndarray
    face_dir: np.ndarray
    face_edge: np.ndarray

    @property
    def boundary(self) -> np.ndarray:
        """Edges with a single face: the open rims."""
        return self.edges[self.counts == 1]

    @property
    def non_manifold(self) -> np.ndarray:
        """Edges with three or more faces."""
        return self.edges[self.counts >= 3]

    def faces_at(self, edge_id: int) -> np.ndarray:
        return self.face_ids[self.face_ptr[edge_id]:self.face_ptr[edge_id + 1]]


def edge_table(mesh: trimesh.Trimesh) -> EdgeTable:
    """The edge table of `mesh`, built once per mesh object and cached on it (like regions.region_meshes). Edges
    are keyed as one int64 per edge and sorted once: a fifth of the memory of a row-wise unique over a 3F x 2
    int64 array, which is what pushed a 7.7M-edge assembly into MemoryError."""
    cached = getattr(mesh, _EDGE_ATTR, None)
    if cached is not None and cached[0] == len(mesh.faces):
        return cached[1]
    faces = np.asarray(mesh.faces, dtype=np.int64)
    nv = int(len(mesh.vertices))
    a = faces.reshape(-1)
    b = faces[:, [1, 2, 0]].reshape(-1)
    lo = np.minimum(a, b)
    hi = np.maximum(a, b)
    direction = np.where(a == lo, 1, -1).astype(np.int8)
    key = lo * nv + hi
    del a, b, hi
    order = np.argsort(key, kind="stable")
    sorted_key = key[order]
    starts = np.concatenate([[True], sorted_key[1:] != sorted_key[:-1]]) if len(sorted_key) else np.zeros(0, dtype=bool)
    first = np.nonzero(starts)[0]
    counts = np.diff(np.append(first, len(sorted_key))).astype(np.int32)
    lo_sorted = (sorted_key // nv)[first] if nv else np.zeros(0, dtype=np.int64)
    hi_sorted = (sorted_key % nv)[first] if nv else np.zeros(0, dtype=np.int64)
    edges = np.stack([lo_sorted, hi_sorted], axis=1).astype(np.int32)
    del lo, sorted_key
    edge_id = (np.cumsum(starts) - 1).astype(np.int32)
    face_edge = np.empty(len(key), dtype=np.int32)
    face_edge[order] = edge_id
    del key, edge_id, starts
    face_ptr = np.concatenate([[0], np.cumsum(counts)]).astype(np.int64)
    face_ids = (order // 3).astype(np.int32)
    face_dir = direction[order]
    del order, direction
    table = EdgeTable(edges=edges, counts=counts, face_ptr=face_ptr, face_ids=face_ids, face_dir=face_dir,
                      face_edge=face_edge.reshape(-1, 3))
    try:
        setattr(mesh, _EDGE_ATTR, (len(mesh.faces), table))
    except AttributeError:
        pass
    return table


def face_components(mesh: trimesh.Trimesh) -> np.ndarray:
    """Connected-component label per face, from the edge table, cached on the mesh. Faces sharing a two-face edge
    are one component. At an edge with three or more faces the faces are paired by the wedge rule: a closed body
    traverses an edge once each way, and the face that continues a given face's winding is the nearest one going
    around the edge into that face's material side. Where the faces at an edge cannot be paired (an odd count,
    unbalanced windings, an inconsistent matching) the edge joins them all, so a baffle fanned from the wall's
    own ring stays one sheet with the pipe, while two closed bodies that touch on a shared surface each stay
    closed instead of losing their joint faces (which trimesh's face_adjacency, two-face edges only, does)."""
    cached = getattr(mesh, _COMP_ATTR, None)
    if cached is not None and cached[0] == len(mesh.faces):
        return cached[1]
    from scipy.sparse import coo_matrix
    from scipy.sparse.csgraph import connected_components

    n = len(mesh.faces)
    t = edge_table(mesh)
    links = [_two_face_links(t)]
    multi = np.nonzero(t.counts >= 3)[0]
    if len(multi):
        links.append(_pair_non_manifold(mesh, t, multi))
    src = np.concatenate([lk[:, 0] for lk in links])
    dst = np.concatenate([lk[:, 1] for lk in links])
    graph = coo_matrix((np.ones(len(src), dtype=np.int8), (src, dst)), shape=(n, n))
    _, labels = connected_components(graph, directed=False)
    labels = labels.astype(np.int64)
    try:
        setattr(mesh, _COMP_ATTR, (n, labels))
    except AttributeError:
        pass
    return labels


def _two_face_links(t: EdgeTable) -> np.ndarray:
    two = np.nonzero(t.counts == 2)[0]
    if len(two) == 0:
        return np.zeros((0, 2), dtype=np.int64)
    p = t.face_ptr[two]
    return np.stack([t.face_ids[p], t.face_ids[p + 1]], axis=1).astype(np.int64)


def _pair_non_manifold(mesh: trimesh.Trimesh, t: EdgeTable, edge_ids: np.ndarray) -> np.ndarray:
    verts = np.asarray(mesh.vertices, dtype=float)
    faces = np.asarray(mesh.faces)
    out: list[np.ndarray] = []
    for n_done, e in enumerate(edge_ids):
        fids = t.face_ids[t.face_ptr[e]:t.face_ptr[e + 1]]
        dirs = t.face_dir[t.face_ptr[e]:t.face_ptr[e + 1]]
        pairs = None
        if n_done < NONMANIFOLD_PAIR_LIMIT and len(fids) % 2 == 0 and int(dirs.sum()) == 0:
            pairs = _wedge_pairs(verts, faces, t.edges[e], fids, dirs)
        if pairs is None:
            base = np.full(len(fids) - 1, fids[0], dtype=np.int64)
            out.append(np.stack([base, fids[1:].astype(np.int64)], axis=1))
        else:
            out.append(pairs)
    return np.vstack(out) if out else np.zeros((0, 2), dtype=np.int64)


def _wedge_pairs(verts: np.ndarray, faces: np.ndarray, edge: np.ndarray, fids: np.ndarray, dirs: np.ndarray) -> np.ndarray | None:
    """Pair the faces at one edge so each pair is two faces of one closed body. With outward normals, a face that
    traverses the edge lo -> hi has its material on the clockwise side (about the lo -> hi axis) and one that
    traverses hi -> lo on the counter-clockwise side; each face's partner is the nearest opposite-direction face
    in that rotational direction, skipping a coincident copy of itself. None when the matching is not mutual."""
    a, b = verts[edge[0]], verts[edge[1]]
    axis = b - a
    norm = float(np.linalg.norm(axis))
    if norm <= 0:
        return None
    axis = axis / norm
    tri = faces[fids]
    is_a = tri == edge[0]
    is_b = tri == edge[1]
    other = ~(is_a | is_b)
    if not (other.sum(axis=1) == 1).all():
        return None
    third = tri[other]
    tvec = verts[third] - a
    tvec = tvec - np.outer(tvec @ axis, axis)
    lengths = np.linalg.norm(tvec, axis=1)
    if (lengths <= 0).any():
        return None
    tvec = tvec / lengths[:, None]
    u = tvec[0]
    v = np.cross(axis, u)
    theta = np.arctan2(tvec @ v, tvec @ u)
    n = len(fids)
    partner = np.full(n, -1, dtype=np.int64)
    two_pi = 2 * np.pi
    for i in range(n):
        best, best_delta = -1, None
        for j in range(n):
            if j == i or dirs[j] == dirs[i]:
                continue
            delta = (theta[i] - theta[j]) % two_pi if dirs[i] > 0 else (theta[j] - theta[i]) % two_pi
            if delta < COINCIDENT_ANGLE_RAD or delta > two_pi - COINCIDENT_ANGLE_RAD:
                continue
            if best_delta is None or delta < best_delta:
                best, best_delta = j, delta
        if best < 0:
            return None
        partner[i] = best
    if not all(partner[partner[i]] == i for i in range(n)):
        return None
    pairs = np.array([(int(fids[i]), int(fids[partner[i]])) for i in range(n) if i < partner[i]], dtype=np.int64)
    return pairs.reshape(-1, 2)


def drop_debris(mesh: trimesh.Trimesh) -> trimesh.Trimesh:
    """Remove the components that are export debris (see DEBRIS_*) and record how many in
    mesh.metadata[DEBRIS_META]. Body attributes follow the surviving faces."""
    labels = face_components(mesh)
    n_comp = int(labels.max()) + 1 if len(labels) else 0
    mesh.metadata.setdefault(DEBRIS_META, 0)
    if n_comp <= 1:
        return mesh
    areas = np.asarray(mesh.area_faces, dtype=float)
    total = float(areas.sum())
    comp_faces = np.bincount(labels, minlength=n_comp)
    comp_area = np.bincount(labels, weights=areas, minlength=n_comp)
    small = np.nonzero((comp_faces < DEBRIS_MIN_FACES) | (comp_area < DEBRIS_AREA_FRACTION * total))[0]
    if len(small) == 0:
        return mesh
    t = edge_table(mesh)
    verts = np.asarray(mesh.vertices)
    faces = np.asarray(mesh.faces)
    median_edge = float(np.median(np.linalg.norm(verts[t.edges[:, 0]] - verts[t.edges[:, 1]], axis=1)))
    drop = np.zeros(len(faces), dtype=bool)
    dropped = 0
    for c in small:
        members = np.nonzero(labels == c)[0]
        if comp_faces[c] >= DEBRIS_MIN_FACES and _component_closed(t, members):
            pts = verts[np.unique(faces[members])]
            if float(np.linalg.norm(pts.max(axis=0) - pts.min(axis=0))) >= DEBRIS_CLOSED_DIAG_OVER_EDGE * median_edge:
                continue
        drop[members] = True
        dropped += 1
    if dropped == 0:
        return mesh
    if drop.all():
        raise UnsupportedGeometry("file contains only debris (no component large enough to be a body)")
    mesh.update_faces(~drop)
    mesh.remove_unreferenced_vertices()
    mesh.metadata[DEBRIS_META] = int(mesh.metadata.get(DEBRIS_META, 0)) + dropped
    if BODY_ATTR in mesh.face_attributes:
        _, body = np.unique(np.asarray(mesh.face_attributes[BODY_ATTR]), return_inverse=True)
        mesh.face_attributes[BODY_ATTR] = body.reshape(-1).astype(int)
        mesh.metadata["bodies"] = int(body.max()) + 1 if len(body) else 0
    return mesh


def _component_closed(t: EdgeTable, members: np.ndarray) -> bool:
    """Every edge of the component is used by exactly two of its faces."""
    _, counts = np.unique(t.face_edge[members].reshape(-1), return_counts=True)
    return bool((counts == 2).all())


def _static(owner, name: str):
    """OCP 7 exposes OCCT statics with an `_s` suffix (TopoDS.Face_s); OCP 8 drops it for some. Accept both."""
    fn = getattr(owner, name + "_s", None) or getattr(owner, name, None)
    if fn is None:
        raise AttributeError(f"{owner!r} has neither {name}_s nor {name}")
    return fn


def _explore(shape, kind) -> list:
    from OCP.TopExp import TopExp_Explorer
    out = []
    exp = TopExp_Explorer(shape, kind)
    while exp.More():
        out.append(exp.Current())
        exp.Next()
    return out


def _load_step(path: Path, angular_deflection: float, linear_deflection: float | None) -> trimesh.Trimesh:
    try:
        from OCP.BRep import BRep_Tool
        from OCP.BRepMesh import BRepMesh_IncrementalMesh
        from OCP.IFSelect import IFSelect_RetDone
        from OCP.STEPControl import STEPControl_Reader
        from OCP.TopAbs import TopAbs_FACE, TopAbs_Orientation, TopAbs_SOLID
        from OCP.TopExp import TopExp
        from OCP.TopLoc import TopLoc_Location
        from OCP.TopoDS import TopoDS
    except ImportError as exc:
        raise UnsupportedGeometry(
            f"{path.name}: STEP needs the optional 'step' extra (pip install 'hexera-geometry-agent[step]'), "
            f"or pre-tessellate to STL ({exc})"
        ) from exc

    if path.suffix.lower() in IGES_SUFFIXES:
        from OCP.IGESControl import IGESControl_Reader
        reader = IGESControl_Reader()
        if reader.ReadFile(str(path)) != IFSelect_RetDone:
            raise UnsupportedGeometry(f"{path.name}: IGES reader refused the file")
        reader.TransferRoots()
    else:
        reader = STEPControl_Reader()
        if reader.ReadFile(str(path)) != IFSelect_RetDone:
            raise UnsupportedGeometry(f"{path.name}: STEP reader refused the file")
        reader.TransferRoots()
    shape = reader.OneShape()
    bbox_diag = _occ_diag(shape)
    lin = linear_deflection if linear_deflection is not None else max(bbox_diag * 1e-3, 1e-6)
    BRepMesh_IncrementalMesh(shape, lin, False, angular_deflection, True)

    as_face = _static(TopoDS, "Face")
    triangulation = _static(BRep_Tool, "Triangulation")

    def tessellate_fast(faces) -> trimesh.Trimesh | None:
        """OCCT writes the group's existing triangulation as a binary STL and trimesh reads it back, all in C.
        Pulling nodes one by one through the binding costs minutes on a million-face assembly."""
        import os
        import tempfile

        try:
            from OCP.BRep import BRep_Builder
            from OCP.StlAPI import StlAPI_Writer
            from OCP.TopoDS import TopoDS_Compound
        except ImportError:
            return None
        comp = TopoDS_Compound()
        builder = BRep_Builder()
        builder.MakeCompound(comp)
        for raw in faces:
            builder.Add(comp, raw)
        writer = StlAPI_Writer()
        writer.ASCIIMode = False
        fd, tmp = tempfile.mkstemp(suffix=".stl")
        os.close(fd)
        try:
            if not writer.Write(comp, tmp):
                return None
            if os.path.getsize(tmp) < 84 + 50:
                return None
            m = trimesh.load(tmp, force="mesh", process=False)
        finally:
            try:
                os.remove(tmp)
            except OSError:
                pass
        if not isinstance(m, trimesh.Trimesh) or len(m.faces) == 0:
            return None
        m.merge_vertices()
        m.update_faces(m.nondegenerate_faces())
        m.remove_unreferenced_vertices()
        return m if len(m.faces) else None

    def tessellate(faces) -> trimesh.Trimesh | None:
        fast = tessellate_fast(faces)
        if fast is not None:
            return fast
        return tessellate_python(faces)

    def tessellate_python(faces) -> trimesh.Trimesh | None:
        verts: list[np.ndarray] = []
        tris: list[np.ndarray] = []
        offset = 0
        for raw in faces:
            face = as_face(raw)
            loc = TopLoc_Location()
            tri = triangulation(face, loc)
            if tri is None:
                continue
            trsf = loc.Transformation()
            n = tri.NbNodes()
            pts = np.array([[*tri.Node(i + 1).Transformed(trsf).Coord()] for i in range(n)], dtype=float)
            idx = np.array([[*tri.Triangle(i + 1).Get()] for i in range(tri.NbTriangles())], dtype=int) - 1
            if face.Orientation() == TopAbs_Orientation.TopAbs_REVERSED:
                idx = idx[:, ::-1]
            verts.append(pts)
            tris.append(idx + offset)
            offset += n
        if not tris:
            return None
        m = trimesh.Trimesh(np.vstack(verts), np.vstack(tris), process=False)
        m.merge_vertices()
        m.update_faces(m.nondegenerate_faces())
        m.remove_unreferenced_vertices()
        return m if len(m.faces) else None

    solids = _explore(shape, TopAbs_SOLID)
    groups: list[list] = [_explore(solid, TopAbs_FACE) for solid in solids]
    if groups:
        free = _free_faces(shape, groups, TopAbs_FACE, TopExp)
        if free:
            groups.append(free)
    else:
        groups = [_explore(shape, TopAbs_FACE)]

    bodies = [m for m in (tessellate(g) for g in groups) if m is not None]
    # OCCT tessellates each B-rep face on its own; at a coarse deflection two neighbouring faces of a twisted or
    # helical surface can disagree along their shared edge and the closed solid comes out with a seam of open
    # edges. When a solid that OCCT holds as closed comes out open, the whole shape is re-meshed finer (so faces
    # shared between solids stay identically triangulated) and read again, up to TESSELLATION_RETRIES times.
    ang, lin_now = angular_deflection, lin
    for _attempt in range(TESSELLATION_RETRIES):
        open_solids = [k for k, m in enumerate(bodies) if k < len(solids) and not m.is_watertight]
        if not open_solids or linear_deflection is not None:
            break
        ang, lin_now = ang / 2.0, lin_now / 2.0
        BRepMesh_IncrementalMesh(shape, lin_now, False, ang, True)
        finer = [m for m in (tessellate(g) for g in groups) if m is not None]
        if len(finer) != len(bodies):
            break
        bodies = finer
    if not bodies:
        raise UnsupportedGeometry(f"{path.name}: STEP tessellation produced no triangles")
    for k, m in enumerate(bodies):
        m.face_attributes[BODY_ATTR] = np.full(len(m.faces), k, dtype=int)
    mesh = bodies[0] if len(bodies) == 1 else trimesh.util.concatenate(bodies)
    if len(mesh.face_attributes.get(BODY_ATTR, [])) != len(mesh.faces):
        mesh.face_attributes[BODY_ATTR] = np.concatenate([np.full(len(m.faces), k, dtype=int) for k, m in enumerate(bodies)])
    mesh.metadata["bodies"] = len(bodies)
    return mesh


PAIRWISE_FACE_LIMIT = 2000
#: How many times a STEP whose closed solids tessellate open is re-meshed at half the deflection (0.2 -> 0.1 -> 0.05
#: radians). The helical static mixers in the pipeline corpus close at 0.1; clean parts never pay for it.
TESSELLATION_RETRIES = 2


def _free_faces(shape, solid_face_groups: list[list], TopAbs_FACE, TopExp) -> list:
    """Faces that belong to no solid (sheets, open shells) in a file that also has solids. Identity is the
    underlying TShape, which the binding hashes consistently (OCP 7 and 8), so this is one set lookup per face.
    A pairwise IsSame scan is kept only for small files where the binding cannot hash; on a 24k-face assembly
    that scan took two minutes."""
    all_faces = _explore(shape, TopAbs_FACE)
    n_in_solids = sum(len(g) for g in solid_face_groups)
    if len(all_faces) <= n_in_solids:
        return []
    try:
        owned = {hash(f.TShape()) for g in solid_face_groups for f in g}
        return [f for f in all_faces if hash(f.TShape()) not in owned]
    except TypeError:
        pass
    if len(all_faces) > PAIRWISE_FACE_LIMIT:
        return []
    owned_list = [f for g in solid_face_groups for f in g]
    return [f for f in all_faces if not any(f.IsSame(o) for o in owned_list)]


def _occ_diag(shape) -> float:
    from OCP.Bnd import Bnd_Box
    from OCP.BRepBndLib import BRepBndLib

    box = Bnd_Box()
    _static(BRepBndLib, "Add")(shape, box)
    lo, hi = box.CornerMin(), box.CornerMax()
    return float(np.linalg.norm([hi.X() - lo.X(), hi.Y() - lo.Y(), hi.Z() - lo.Z()]))
