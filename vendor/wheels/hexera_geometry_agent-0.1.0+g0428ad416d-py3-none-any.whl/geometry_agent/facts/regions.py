"""Connected components of the surface, what each encloses, and which sit inside which."""
from __future__ import annotations

import numpy as np
import trimesh

from geometry_agent.facts import load
from geometry_agent.facts.openings import _region_of_faces
from geometry_agent.facts.schema import Region

_CACHE_ATTR = "_geometry_agent_region_meshes"

#: A candidate is tested for enclosure at its centroid plus this many face centres drawn by area, so the verdict
#: does not hang on one point that happens to sit in a container's end plane or through-hole.
NEST_SAMPLE_POINTS = 5
#: Rays are cast from each sample point along the six axes and the eight cube diagonals. A point inside a
#: container's outer envelope sees the container in every direction except along a through-channel it may sit in
#: (two of the fourteen); a point beside a body inside its bounding box sees it in about half.
ENCLOSURE_DIRECTIONS = np.array(
    [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1],
     [1, 1, 1], [1, 1, -1], [1, -1, 1], [1, -1, -1], [-1, 1, 1], [-1, 1, -1], [-1, -1, 1], [-1, -1, -1]], dtype=float)
ENCLOSURE_DIRECTIONS /= np.linalg.norm(ENCLOSURE_DIRECTIONS, axis=1)[:, None]
#: A sample point counts as enclosed when at least this fraction of its rays hit the container: 12 of 14 for a
#: point in a straight through-channel, about 7 of 14 for a point beside an L-shaped body.
ENCLOSED_RAY_FRACTION = 0.8
#: Bounding-box containment tolerance, as a fraction of the container's diagonal (bodies that fill a cavity share
#: its extent exactly; a float32 STL rounds by 1e-7).
BBOX_TOL_OF_DIAG = 1e-6
#: Ray origins start this fraction of the container's diagonal along the ray, so a point lying exactly on the
#: container's surface (a body filling a cavity shares its wall) does not count its own wall as the hit.
RAY_OFFSET_OF_DIAG = 1e-6


def region_meshes(mesh: trimesh.Trimesh) -> list[trimesh.Trimesh]:
    """One sub-mesh per region, built once per mesh object and kept on it: openings, stubs, gaps and symmetry
    all need them, and on a 402-body assembly rebuilding them per caller cost minutes."""
    cached = getattr(mesh, _CACHE_ATTR, None)
    if cached is not None and cached[0] == len(mesh.faces):
        return cached[1]
    region_of = _region_of_faces(mesh)
    n = int(region_of.max()) + 1 if len(region_of) else 0
    parts = [mesh] if n <= 1 else [mesh.submesh([np.where(region_of == k)[0]], append=True) for k in range(n)]
    try:
        setattr(mesh, _CACHE_ATTR, (len(mesh.faces), parts))
    except AttributeError:
        pass
    return parts


def _sample_points(part: trimesh.Trimesh, n: int, seed: int = 0) -> np.ndarray:
    """The part's area-weighted centroid plus `n` face centres drawn by area with a fixed seed: the same points
    every run, spread over the surface rather than clustered where the exporter listed the first faces."""
    centres = np.asarray(part.triangles_center)
    areas = np.asarray(part.area_faces, dtype=float)
    total = float(areas.sum())
    centroid = (areas[:, None] * centres).sum(axis=0) / total if total > 0 else centres.mean(axis=0)
    if len(centres) <= n:
        return np.vstack([centroid[None, :], centres])
    rng = np.random.default_rng(seed)
    idx = rng.choice(len(centres), size=n, replace=False, p=areas / total) if total > 0 else np.arange(n)
    return np.vstack([centroid[None, :], centres[np.sort(idx)]])


def _encloses(container: trimesh.Trimesh, points: np.ndarray) -> bool:
    """True when most of `points` see `container` in at least ENCLOSED_RAY_FRACTION of ENCLOSURE_DIRECTIONS: a
    handful of explicit rays per point against the container's own triangles, nothing bulk."""
    if len(points) == 0:
        return False
    diag = float(np.linalg.norm(container.extents))
    dirs = np.tile(ENCLOSURE_DIRECTIONS, (len(points), 1))
    origins = np.repeat(points, len(ENCLOSURE_DIRECTIONS), axis=0) + dirs * (RAY_OFFSET_OF_DIAG * diag)
    hit = np.asarray(container.ray.intersects_any(origins, dirs), dtype=bool).reshape(len(points), -1)
    enclosed = hit.mean(axis=1) >= ENCLOSED_RAY_FRACTION
    return bool(enclosed.sum() * 2 > len(points))


def _watertight(part: trimesh.Trimesh) -> bool:
    """Every edge used by exactly two faces: trimesh's `is_watertight`, read off the loader's edge table (the
    whole mesh's is already built and cached; trimesh would group all 3F edges again, 6.5 s on 4.36M faces)."""
    if len(part.faces) == 0:
        return False
    return bool(np.all(load.edge_table(part).counts == 2))


def _volume(part: trimesh.Trimesh) -> float:
    """Signed volume by the divergence theorem, sum of v0 . (v1 x v2) / 6: the volume trimesh's mass properties
    return, without the centre of mass and inertia it computes alongside (5.3 s on 4.36M faces)."""
    tri = np.asarray(part.triangles, dtype=float)
    if len(tri) == 0:
        return 0.0
    return float(np.einsum("ij,ij->i", tri[:, 0], np.cross(tri[:, 1], tri[:, 2])).sum() / 6.0)


def detect_regions(mesh: trimesh.Trimesh) -> list[Region]:
    """Regions plus their nesting. `a.nested_in = b` only when b is watertight, a's bounding box lies inside b's,
    and sample points of a see b all around them (a ray test against b's triangles); of several such containers
    the innermost (smallest bounding box) is named, and `b.contains` lists the inverse. A group of free sheet
    faces spanning an assembly's box is therefore never a container, and a body beside another inside its box is
    not nested in it."""
    parts = region_meshes(mesh)
    out = []
    for k, p in enumerate(parts, start=1):
        wt = _watertight(p)
        lo, hi = p.bounds
        out.append(Region(
            id=f"r{k}", faces=int(len(p.faces)), watertight=wt,
            volume=float(abs(_volume(p))) if wt else None,
            bbox_extent=tuple(float(v) for v in p.extents),
            bbox_min=tuple(float(v) for v in lo), bbox_max=tuple(float(v) for v in hi),
            surface_area=float(p.area),
        ))
    if len(out) < 2:
        return out
    lo = np.array([r.bbox_min for r in out], dtype=float)
    hi = np.array([r.bbox_max for r in out], dtype=float)
    volume = np.prod(hi - lo, axis=1)
    tol = BBOX_TOL_OF_DIAG * np.linalg.norm(hi - lo, axis=1)
    closed = np.array([r.watertight for r in out], dtype=bool)
    for i, a in enumerate(out):
        inside = (lo <= lo[i] + tol[:, None]).all(axis=1) & (hi >= hi[i] - tol[:, None]).all(axis=1)
        candidates = np.nonzero(closed & inside & (volume > volume[i]))[0]
        candidates = candidates[candidates != i]
        if len(candidates) == 0:
            continue
        points = _sample_points(parts[i], NEST_SAMPLE_POINTS)
        for j in sorted(candidates.tolist(), key=lambda j: (volume[j], j)):
            if _encloses(parts[j], points):
                a.nested_in = out[j].id
                out[j].contains.append(a.id)
                break
    return out
