"""Three facts about the surface the mesher is actually handed, rather than about the part it stands for.

The rest of `facts` measures the PART: where its mouths are, how long its stubs run, how thin its walls get.
This module measures the TESSELLATION: how the triangles are arranged, how far they sit from the shape they
approximate, and how thick the solid is at each place two bodies meet. Those three decide whether a mesher
finishes, and none of them is answered by an edge length or a global minimum.

EVERY ONE OF THEM REFUSES RATHER THAN GUESSES, and each refusal says which of two different things it is:

  `computable = False` with a reason   the input cannot carry the answer (an STL has no surface behind its
                                       triangles), so no measurement here or anywhere could produce one
  a `reason` on a row with no numbers  the input could carry it and this part does not (an inward ray that
                                       never meets a second surface has no thickness to report)

A fact that lies is worse than a missing one, because the builder has no way to tell them apart.
"""
from __future__ import annotations

import numpy as np
import trimesh

from geometry_agent.facts import load
from geometry_agent.facts.schema import (
    ChordDeviation,
    EdgeAngleBin,
    FeatureEdgeSpectrum,
    InterfaceThickness,
)

# ---------------------------------------------------------------------------------------------------------------
# H. the feature-edge spectrum
# ---------------------------------------------------------------------------------------------------------------
#: The included-angle buckets, in degrees, from a fold back on itself to flat. The top of the range is split
#: finely on purpose: that is where a tessellated curve puts its edges, and the difference between forty edges
#: and forty thousand lives inside the last five degrees.
SPECTRUM_EDGES: tuple[float, ...] = (0.0, 30.0, 60.0, 90.0, 120.0, 150.0, 165.0, 175.0, 178.0, 179.0, 179.9, 180.0)
#: The angles the cumulative column is reported at. They are read as a question ("what would an extractor set
#: here return"), never as an answer: this module names no setting.
SPECTRUM_THRESHOLDS: tuple[float, ...] = (20.0, 30.0, 45.0, 60.0, 90.0, 120.0, 150.0, 165.0, 175.0)
#: Where a threshold can plausibly sit, for the empty-band search. Below this an extractor takes almost nothing
#: and above it almost everything, so an empty band outside the window is not information.
BAND_WINDOW = (20.0, 175.0)


def feature_edge_spectrum(mesh: trimesh.Trimesh) -> FeatureEdgeSpectrum:
    """The distribution of included angle over the manifold edges, with the three populations it cannot bin.

    THE INCLUDED ANGLE, AND WHY IT IS NOT THE NORMAL ANGLE. trimesh gives the angle between adjacent face
    NORMALS: 0 on a flat surface, rising as the surface bends. A feature-edge extractor is given the angle
    between the FACES: 180 on a flat surface, 90 at a square corner. They are complements, and reporting one
    while the builder reads the other inverts the whole curve. It is UNSIGNED, as an extractor's is: a
    re-entrant square corner is 270 through the material and reads 90 here, the same as a convex one.

    AN EDGE WHOSE TWO FACES ARE WOUND AGAINST EACH OTHER HAS NO ANGLE THIS CAN REPORT, and it is counted apart
    rather than binned. One of the two normals points the wrong way, so the normal angle is the complement of
    the real one: a flat stretch of surface reads as a fold back on itself. Which face is the reversed one is
    not in the file. Found by the verifier: 1 per cent of a corpus elbow's triangles reversed, as a careless
    STL export does, put 186 edges and 3,363 of length at or below 30 degrees on a part that has none."""
    table = load.edge_table(mesh)
    open_edges = int(np.count_nonzero(table.counts == 1))
    non_manifold = int(np.count_nonzero(table.counts >= 3))

    normal_angles = np.degrees(np.asarray(mesh.face_adjacency_angles, dtype=float))
    pairs = np.asarray(mesh.face_adjacency_edges)
    if len(normal_angles) == 0:
        return FeatureEdgeSpectrum(manifold_edges=0, open_edges=open_edges, non_manifold_edges=non_manifold,
                                   bins=[], cumulative=[], widest_empty_band=None)
    against = _wound_against(np.asarray(mesh.faces), np.asarray(mesh.face_adjacency), pairs)
    manifold = int(len(normal_angles))
    normal_angles, pairs = normal_angles[~against], pairs[~against]
    lengths = np.linalg.norm(mesh.vertices[pairs[:, 0]] - mesh.vertices[pairs[:, 1]], axis=1)
    included = np.clip(180.0 - normal_angles, 0.0, 180.0)

    bins: list[EdgeAngleBin] = []
    for lo, hi in zip(SPECTRUM_EDGES[:-1], SPECTRUM_EDGES[1:]):
        # half open below, closed at the very top so a perfectly flat edge at exactly 180 is counted once
        sel = (included >= lo) & (included < hi) if hi < 180.0 else (included >= lo) & (included <= hi)
        bins.append(EdgeAngleBin(included_lo=lo, included_hi=hi, edges=int(sel.sum()),
                                 length=float(lengths[sel].sum())))

    cumulative = []
    for t in SPECTRUM_THRESHOLDS:
        sel = included <= t
        cumulative.append((float(t), int(sel.sum()), float(lengths[sel].sum())))

    return FeatureEdgeSpectrum(
        manifold_edges=manifold, open_edges=open_edges, non_manifold_edges=non_manifold,
        inconsistent_edges=int(against.sum()),
        bins=bins, cumulative=cumulative, widest_empty_band=_widest_empty_band(included),
    )


def _wound_against(faces: np.ndarray, adjacency: np.ndarray, shared: np.ndarray) -> np.ndarray:
    """Per adjacent face pair, whether the two faces traverse their shared edge the SAME way round.

    Consistently wound neighbours walk a shared edge in opposite directions, one u to v and the other v to u.
    Walking it the same way means one of the two is reversed, and then the angle between their normals is the
    complement of the angle between the faces."""
    if len(adjacency) == 0:
        return np.zeros(0, dtype=bool)
    u, v = shared[:, 0][:, None], shared[:, 1][:, None]

    def forward(which: np.ndarray) -> np.ndarray:
        rows = faces[which]
        return np.any((rows == u) & (np.roll(rows, -1, axis=1) == v), axis=1)

    return forward(adjacency[:, 0]) == forward(adjacency[:, 1])


def _widest_empty_band(included: np.ndarray) -> tuple[float, float] | None:
    """The widest run of included angle inside BAND_WINDOW carrying no edge at all.

    Read as: anywhere in this band, the answer is the same set of edges. A wide band says the choice of
    threshold does not matter on this surface; a band of nothing says every degree changes the answer. It is
    computed on the sorted angles, so it is exact and costs one sort."""
    lo, hi = BAND_WINDOW
    inside = np.sort(included[(included >= lo) & (included <= hi)])
    if len(inside) == 0:
        return (float(lo), float(hi))
    edges = np.concatenate(([lo], inside, [hi]))
    gaps = np.diff(edges)
    k = int(np.argmax(gaps))
    if gaps[k] <= 0.0:
        return None
    return (float(edges[k]), float(edges[k + 1]))


# ---------------------------------------------------------------------------------------------------------------
# I. chord deviation against the true surface
# ---------------------------------------------------------------------------------------------------------------
#: Formats whose triangles are the whole of the file. There is no surface behind them to measure against, and
#: there is no way to invent one: three points on a circle and three points on a hexagon are the same three
#: points. Anything not in here and not in `load.STEP_SUFFIXES | load.IGES_SUFFIXES` is refused by name too.
TESSELLATED_ONLY = load.MESH_SUFFIXES
#: Chords evaluated per part, about. A part of a million triangles has one and a half million of them, so
#: every face is thinned by ONE stride worked out from the part's whole triangle count BEFORE any surface is
#: evaluated. It used to be applied afterwards, to a list every chord of the part had already been evaluated
#: for, which bounded the size of the answer and not the time it took: the cost it was said to cap was
#: uncapped, and the only thing between a large assembly and the whole measurement budget was the load-time
#: price in `measure`. The stride touches 14 of the 322 corpus parts (blade rows and wings), which now read
#: 22,142 to 39,769 chords where the thinning afterwards gave 40,000.
MAX_CHORDS = 40_000
#: Fractions along each chord at which the distance to the surface is taken. Three interior points, so the
#: deviation is a lower bound on the chord's farthest departure and never above it.
CHORD_SAMPLES = (0.25, 0.5, 0.75)
#: A chord shorter than this fraction of the part's own coordinate scale is a node repeated at a pole or a seam
#: and has no direction. It is dropped, because a ratio taken over it is arithmetic and not geometry.
DEGENERATE_CHORD = 1e-9


def chord_deviation(path, mesh: trimesh.Trimesh | None = None) -> ChordDeviation:
    """How far this tessellation sits from the surface it approximates, or why that cannot be asked.

    THE REFUSAL IS THE PRODUCT ON HALF THE INPUTS. An STL is a wall of triangles: the radius that produced them
    is not in the file and cannot be recovered from them, so a mesher handed one is meshing the hexagon whether
    it knows it or not. Saying so is information; guessing a curvature from the triangles and calling it a
    deviation would be a number that lies."""
    from pathlib import Path

    path = Path(path)
    suffix = path.suffix.lower()
    if suffix in TESSELLATED_ONLY:
        return ChordDeviation(
            computable=False, surface_available=False,
            reason=(f"a {suffix.lstrip('.')} file carries triangles and nothing else. The surface they stand "
                    f"for is not in it, so how far they sit from it cannot be measured from this input by any "
                    f"means. What the mesher will see IS these triangles."))
    if suffix not in (load.STEP_SUFFIXES | load.IGES_SUFFIXES):
        return ChordDeviation(computable=False, surface_available=False,
                              reason=f"no reader here knows what surface a {suffix.lstrip('.')} file describes")
    try:
        return _chord_from_brep(path)
    except _NoSurface as exc:
        return ChordDeviation(computable=False, surface_available=False, reason=str(exc))


class _NoSurface(RuntimeError):
    pass


def _chord_from_brep(path) -> ChordDeviation:
    """The sag of every triangle edge, measured against the face's own surface at the chord's own parameters.

    HOW IT IS MEASURED, EXACTLY. Every triangulation OCCT builds keeps the (u, v) of each node on its face. For
    a triangle edge the chord is the straight segment between two node points; the surface point at the mean of
    their parameters is where the surface sits over the middle of that chord, and the distance between the two
    is the sag. On a circular arc that midpoint is where the sag is greatest, which is the case this fact
    exists for. On a surface whose parameterisation is far from uniform it is a sample of the sag and not its
    maximum, and this is the one place the number is a lower bound rather than an answer.

    WHAT IT IS A PROPERTY OF. The CAD surface AND the deflection this measurement asked for. A different
    deflection is a different set of triangles and a different sag, so both requested values travel with the
    numbers and neither is a property of the file alone."""
    try:
        from OCP.BRep import BRep_Tool
        from OCP.BRepMesh import BRepMesh_IncrementalMesh
        from OCP.IFSelect import IFSelect_RetDone
        from OCP.TopAbs import TopAbs_FACE
        from OCP.TopLoc import TopLoc_Location
        from OCP.TopoDS import TopoDS
    except ImportError as exc:
        raise _NoSurface(f"the file carries a surface and this checkout cannot read it: OCP is missing ({exc})") from exc

    if path.suffix.lower() in load.IGES_SUFFIXES:
        from OCP.IGESControl import IGESControl_Reader
        reader = IGESControl_Reader()
    else:
        from OCP.STEPControl import STEPControl_Reader
        reader = STEPControl_Reader()
    if reader.ReadFile(str(path)) != IFSelect_RetDone:
        raise _NoSurface("the reader refused this file, so its surface could not be opened")
    reader.TransferRoots()
    shape = reader.OneShape()

    diag = load._occ_diag(shape)
    linear = max(diag * 1e-3, 1e-6)
    angular = 0.2
    BRepMesh_IncrementalMesh(shape, linear, False, angular, True)

    as_face = load._static(TopoDS, "Face")
    triangulation = load._static(BRep_Tool, "Triangulation")
    surface_of = load._static(BRep_Tool, "Surface")

    sags: list[np.ndarray] = []
    chords: list[np.ndarray] = []
    faces_with_surface = 0
    unprojected = 0
    usable = []
    for raw in load._explore(shape, TopAbs_FACE):
        face = as_face(raw)
        loc = TopLoc_Location()
        tri = triangulation(face, loc)
        if tri is None:
            continue
        surf = surface_of(face, TopLoc_Location())
        if surf is None or not _has_uv(tri):
            continue
        usable.append((tri, surf, loc))
    # one stride for the whole part, from its triangle count: an interior edge is shared by two triangles, so
    # a face of n triangles has about 1.5 n chords
    expected = 1.5 * sum(int(tri.NbTriangles()) for tri, _s, _l in usable)
    stride = max(1, int(np.ceil(expected / MAX_CHORDS)))
    for tri, surf, loc in usable:
        faces_with_surface += 1
        got = _face_sag(tri, surf, loc, stride)
        if got is None:
            continue
        sag, chord, lost = got
        unprojected += lost
        sags.append(sag)
        chords.append(chord)

    if not sags:
        raise _NoSurface("the file's faces carry no parameterised triangulation, so no chord has a surface "
                         "point to be measured against")
    if not sum(len(s) for s in sags):
        raise _NoSurface(f"no chord of the {faces_with_surface} faces with a surface could be projected onto it, "
                         f"so there is no distance to report")
    sag = np.concatenate(sags)
    chord = np.concatenate(chords)
    if len(sag) > MAX_CHORDS:
        take = np.linspace(0, len(sag) - 1, MAX_CHORDS).astype(int)
        sag, chord = sag[take], chord[take]
    ratio = sag / chord
    return ChordDeviation(
        computable=True, surface_available=True,
        reason="",
        requested_linear=float(linear), requested_angular_deg=float(np.degrees(angular)),
        sag_max=float(sag.max()), sag_p95=float(np.percentile(sag, 95)), sag_median=float(np.median(sag)),
        sag_over_chord_max=float(ratio.max()),
        chords_sampled=int(len(sag)), faces_with_surface=faces_with_surface,
        chords_over_requested=int(np.count_nonzero(sag > linear)),
        chords_unprojected=int(unprojected),
    )


def _has_uv(tri) -> bool:
    try:
        return bool(tri.HasUVNodes())
    except AttributeError:
        return False


def _face_sag(tri, surf, loc, stride: int = 1) -> tuple[np.ndarray, np.ndarray, int] | None:
    """(deviation, chord length, chords dropped) for the triangle edges of one face.

    THE DEVIATION IS HOW FAR THE CHORD SITS FROM THE SURFACE, measured from three points ON the chord to the
    nearest point of the face's surface. That is the quantity a mesher means by chordal deviation, and it is
    what the deflection a tessellator is given bounds. Two earlier rules measured something else: the first
    from the chord's midpoint to the surface point at the mean parameter (the parameterisation's slide along
    the chord counted as sag, 14.9 on a tessellation built to 0.69), the second from that surface point to the
    segment (its slide ACROSS the chord still counted, see below).

    IT IS A LOWER BOUND ON THE CHORD'S FARTHEST DEPARTURE, SAID PLAINLY. Three points are sampled along each
    chord, so a surface whose farthest departure sits between them is under-reported, and the nearest point is
    sought on the untrimmed surface, which can only be nearer than the face. A chord none of whose points could
    be projected is dropped and counted, never reported."""
    n = int(tri.NbNodes())
    if n < 3:
        return None
    transform = loc.Transformation()
    pts = np.empty((n, 3), dtype=float)
    uv = np.empty((n, 2), dtype=float)
    for i in range(1, n + 1):
        p = tri.Node(i).Transformed(transform)
        pts[i - 1] = (p.X(), p.Y(), p.Z())
        q = tri.UVNode(i)
        uv[i - 1] = (q.X(), q.Y())
    m = int(tri.NbTriangles())
    if m < 1:
        return None
    idx = np.empty((m, 3), dtype=int)
    for k in range(1, m + 1):
        a, b, c = tri.Triangle(k).Get()
        idx[k - 1] = (a - 1, b - 1, c - 1)
    ends = np.unique(np.sort(np.concatenate([idx[:, [0, 1]], idx[:, [1, 2]], idx[:, [2, 0]]]), axis=1), axis=0)
    p0, p1 = pts[ends[:, 0]], pts[ends[:, 1]]
    chord = np.linalg.norm(p1 - p0, axis=1)
    #: A chord this short is a node repeated at a pole or a seam, not an edge. Dividing by it manufactures a
    #: ratio of 1e286, which the first run of this measurement duly printed.
    alive = chord > DEGENERATE_CHORD * max(float(np.abs(pts).max()), 1.0)
    if stride > 1:
        alive[np.arange(len(alive)) % stride != 0] = False
    if not alive.any():
        return None
    ends, p0, p1, chord = ends[alive], p0[alive], p1[alive], chord[alive]
    uv0, uv1 = uv[ends[:, 0]].copy(), uv[ends[:, 1]].copy()
    #: THE POLE, WHICH IS WHERE A PARAMETER STOPS MEANING ANYTHING. At the top of a sphere every longitude is
    #: the same point, so the node there carries whichever u the tessellator happened to write. Interpolating
    #: between that u and the other end's walks around the pole instead of along the chord, and on
    #: `mini_housing_013` that is 11.0 of deviation on a 20.7 chord, sixteen times the deflection the
    #: tessellation was built to. The test is the surface's own derivative: where it vanishes along a parameter,
    #: that parameter does not move the point, so the other end's value is the only meaningful one.
    dead_u, dead_v = _degenerate_parameters(surf, uv)
    for axis, dead in ((0, dead_u), (1, dead_v)):
        a_dead, b_dead = dead[ends[:, 0]], dead[ends[:, 1]]
        uv0[a_dead & ~b_dead, axis] = uv1[a_dead & ~b_dead, axis]
        uv1[b_dead & ~a_dead, axis] = uv0[b_dead & ~a_dead, axis]
    #: THE SEAM, AND IT IS EXACT RATHER THAN A HEURISTIC. On a periodic surface the two ends of a chord can sit
    #: either side of the seam, one at u just above 0 and one at u just below the period. Interpolating between
    #: them the long way round walks the whole surface: on the two spherical faces of `mini_housing_013` that
    #: reported 11.2 of deviation against a tessellation built to 0.69, which no correct triangulation can do.
    #: The period is asked of the surface itself, so the short way round is a fact and not a guess.
    step = uv1 - uv0
    for axis, name in ((0, "U"), (1, "V")):
        period = _period(surf, name)
        if period:
            wrapped = np.abs(step[:, axis]) > 0.5 * period
            step[wrapped, axis] -= np.sign(step[wrapped, axis]) * period

    #: THE DISTANCE IS FROM A POINT ON THE CHORD TO THE SURFACE, and the interpolated parameter only says where
    #: to start looking. The previous rule measured from the surface point at the interpolated parameter to the
    #: segment, and that point is not over the chord wherever the parameterisation is not uniform ACROSS it: on
    #: a latitude of a sphere it is on the small circle, which bulges more than the great circle the chord
    #: actually cuts, and on a spline it can sit off to the side. The verifier projected the same chords onto
    #: their own surfaces and the old rule came out larger by more than a tenth of the deflection on 2,488 of
    #: 6,165 sphere chords of `mini_housing_013` and 1,209 of 3,433 spline chords of `volute_scroll_006`, and
    #: smaller on none: 172 chords over the deflection where the surface has 109, and 0.63 of sag on a spline
    #: chord that departs from its surface by 0.013. The rule it replaced claimed it could not over-report.
    inverse = transform.Inverted()
    locate = _Locator(surf)
    best = np.zeros(len(ends), dtype=float)
    lost = np.zeros(len(ends), dtype=bool)
    for s in CHORD_SAMPLES:
        at = uv0 + s * step
        q = p0 + s * (p1 - p0)
        for i in range(len(ends)):
            d = locate.distance(q[i], at[i], inverse)
            if d is None:
                lost[i] = True
            elif d > best[i]:
                best[i] = d
    keep = ~lost
    return best[keep], chord[keep], int(lost.sum())


class _Locator:
    """The distance from a point to a face's own surface: the nearest surface point FOUND, never a guess.

    Every candidate is the distance to a real point of the surface, so the answer is never below the true
    distance, and the smallest candidate is kept. The candidates are the starting point itself (the surface
    at the interpolated parameter), a local search from it, and a global projection when the local search
    did not beat the start. The start is kept as a candidate on purpose, and both searches are checked
    against it, because both were caught returning a far point: the local search walked to the far side of
    a sphere on six chords of `mini_housing_013` (330 for a chord of 20), and on the spline lofts of the
    `transition` family both it and OCCT's global projection returned 17.9 for a chord point 0.14 from its
    starting point, which a brute-force search over the face's own parameter box put within 0.3. Taking the
    smallest candidate, the transition family reads what the brute force reads. A point with no candidate at
    all (the surface would not evaluate at the start and neither search returned) is dropped and counted."""

    def __init__(self, surf):
        from OCP.Extrema import Extrema_GenLocateExtPS
        from OCP.GeomAdaptor import GeomAdaptor_Surface

        self.surf = surf
        self.adaptor = GeomAdaptor_Surface(surf)
        self.local = Extrema_GenLocateExtPS(self.adaptor, 1e-9, 1e-9)

    def distance(self, point, uv, inverse) -> float | None:
        from OCP.GeomAPI import GeomAPI_ProjectPointOnSurf
        from OCP.gp import gp_Pnt

        p = gp_Pnt(float(point[0]), float(point[1]), float(point[2])).Transformed(inverse)
        u, v = float(uv[0]), float(uv[1])
        try:
            best = p.Distance(self.surf.Value(u, v))
        except Exception:  # noqa: BLE001 - OCCT raises by surface class; a point with no start is projected globally
            best = float("inf")
        settled = False
        try:
            self.local.Perform(p, u, v)
            if self.local.IsDone():
                found = float(np.sqrt(self.local.SquareDistance()))
                # no farther than the start (within rounding) means it found the foot or the start already was
                settled = found <= best * (1.0 + 1e-9) + 1e-12
                best = min(best, found)
        except Exception:  # noqa: BLE001, S110 - a failed local search falls through to the global projection
            pass
        if not settled:
            # the local search failed or went farther than where it started: ask globally, keep the nearer
            try:
                proj = GeomAPI_ProjectPointOnSurf(p, self.surf)
                if proj.NbPoints() > 0:
                    best = min(best, float(proj.LowerDistance()))
            except Exception:  # noqa: BLE001, S110 - a point OCCT cannot project keeps the candidates it has
                pass
        return best if np.isfinite(best) else None


#: A parameter direction is dead at a node when the surface barely moves along it: this fraction of the largest
#: movement anywhere on the face. A pole is exactly zero and float arithmetic puts it near it.
DEGENERATE_DERIVATIVE = 1e-6


def _degenerate_parameters(surf, uv: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Per node, whether u and whether v is a direction the surface does not move along there."""
    from OCP.gp import gp_Pnt, gp_Vec

    n = len(uv)
    # NaN and not zero for a node that will not differentiate: the comparison below is False for NaN, which
    # leaves it not degenerate as the comment on the except says. Zero read as degenerate, the opposite.
    du = np.full(n, np.nan, dtype=float)
    dv = np.full(n, np.nan, dtype=float)
    point, d1u, d1v = gp_Pnt(), gp_Vec(), gp_Vec()
    for i, (u, v) in enumerate(uv):
        try:
            surf.D1(float(u), float(v), point, d1u, d1v)
        except Exception:  # noqa: BLE001, S112 - a surface that will not differentiate here is left not degenerate
            continue  # noqa: S112
        du[i], dv[i] = d1u.Magnitude(), d1v.Magnitude()
    top_u = float(np.nanmax(du)) if np.isfinite(du).any() else 0.0
    top_v = float(np.nanmax(dv)) if np.isfinite(dv).any() else 0.0
    with np.errstate(invalid="ignore"):
        return (du < DEGENERATE_DERIVATIVE * max(top_u, 1e-300),
                dv < DEGENERATE_DERIVATIVE * max(top_v, 1e-300))


def _period(surf, axis: str) -> float:
    """The surface's period along one parameter, or 0 when it has none.

    OCCT raises rather than returning on a surface that is not periodic in that direction, and which exception
    it raises depends on the concrete surface class, so the ask is guarded rather than predicted. A period of 0
    means the seam correction below does nothing, which is the right answer for a plane or a spline patch."""
    try:
        if not bool(getattr(surf, f"Is{axis}Periodic")()):
            return 0.0
        return float(getattr(surf, f"{axis}Period")())
    except Exception:  # noqa: BLE001 - OCCT's exception type varies by surface class
        return 0.0


def _point_to_segment(q: np.ndarray, a: np.ndarray, b: np.ndarray) -> np.ndarray:
    ab = b - a
    denom = np.einsum("ij,ij->i", ab, ab)
    t = np.where(denom > 0, np.einsum("ij,ij->i", q - a, ab) / np.maximum(denom, 1e-300), 0.0)
    foot = a + np.clip(t, 0.0, 1.0)[:, None] * ab
    return np.linalg.norm(q - foot, axis=1)


# ---------------------------------------------------------------------------------------------------------------
# J. wall thickness at each interface
# ---------------------------------------------------------------------------------------------------------------
#: A side whose faces return a finite thickness on fewer than this share of them is refused whole. A median over
#: the third of a wall that happened to close is a number about the third, not about the wall, and the builder
#: cannot see which it got.
MIN_HIT_FRACTION = 0.5
#: Faces sampled per side. An interface of ten thousand triangles does not need all of them for a median, and
#: this many keeps the ray cast well under a second.
MAX_INTERFACE_FACES = 2000


def interface_thickness(mesh: trimesh.Trimesh, region_of: np.ndarray, interfaces_found,
                        interface_mask: np.ndarray | None = None, seed: int = 0) -> list[InterfaceThickness]:
    """How thick each body is at each interface, from that interface's own faces inward.

    ONE ROW PER SIDE, WHICH IS THE POINT. `thickness_min`, `p05` and `median` are taken over the whole part. A
    conjugate run does not size from the whole part: it puts cells through the solid BETWEEN two interfaces, and
    a part with a thick flange and a thin liner has a different answer at each of them. Both sides of each
    interface are reported because which one is the solid is the customer's word, not the geometry's.

    WHY IT REFUSES WHEN A REGION HAS MORE THAN ONE INTERFACE. `detect_interfaces` returns one mask over all
    interface faces and no label saying which interface a face belongs to. With one interface on a region that
    is not ambiguous. With two, a face of that region could belong to either, and a thickness measured from the
    wrong face is a number about somewhere else. There is no way to tell them apart from what the detector
    returns, so the row says so and carries no numbers.

    WHAT THIS CANNOT SEE, and it is a real limit rather than a caveat. The ray leaves each face along its inward
    normal and reports the first surface it meets, which is the thickness ALONG THE NORMAL and not the shortest
    distance across. On a cylinder wall the two are equal; on a fillet the normal distance is the larger. Where
    the ray meets nothing the face contributes nothing, and where too few contribute the row is refused rather
    than reported thin."""
    from geometry_agent.facts.features import _ray_distances

    rows: list[InterfaceThickness] = []
    if not interfaces_found:
        return rows
    if interface_mask is None:
        return [InterfaceThickness(
            region_a=i.region_a, region_b=i.region_b, through_region=side,
            reason="the interface faces were not handed to this measurement, so it has nothing to cast from")
            for i in interfaces_found for side in (i.region_a, i.region_b)]

    touches = _interfaces_per_region(interfaces_found)
    rng = np.random.default_rng(seed)
    for iface in interfaces_found:
        for side, other in ((iface.region_a, iface.region_b), (iface.region_b, iface.region_a)):
            rows.append(_one_side(mesh, region_of, interface_mask, iface, side, other, touches, rng,
                                  _ray_distances))
    return rows


def _interfaces_per_region(interfaces_found) -> dict[str, int]:
    counts: dict[str, int] = {}
    for i in interfaces_found:
        for r in (i.region_a, i.region_b):
            counts[r] = counts.get(r, 0) + 1
    return counts


def _one_side(mesh, region_of, mask, iface, side, other, touches, rng, ray_distances) -> InterfaceThickness:
    row = InterfaceThickness(region_a=iface.region_a, region_b=iface.region_b, through_region=side)
    if touches.get(side, 0) > 1:
        row.reason = (f"{side} meets {touches[side]} interfaces and the detector returns one mask over all of "
                      f"them, so which of its faces belong to this one cannot be told apart here")
        return row
    index = _region_index(side)
    if index is None:
        row.reason = f"this interface names a region, {side}, that this measurement cannot locate"
        return row
    own = region_of == index
    faces = np.flatnonzero(mask & own)
    if len(faces) == 0:
        row.reason = f"no face of {side} is in the interface mask"
        return row
    n_total = int(len(faces))
    if n_total > MAX_INTERFACE_FACES:
        faces = np.sort(rng.choice(faces, MAX_INTERFACE_FACES, replace=False))
    # ONLY A FACE THIS BODY CAN LEAVE THROUGH COUNTS AS THE FAR SIDE: its own, or an interface face, which lies
    # on some body's boundary where two meet. A ray inside a closed body can reach nothing else first. Without
    # this a wall thinner than the cast can resolve (hits closer than 2e-3 of the diagonal are discarded as
    # grazes) let the ray out and the row reported the distance to whatever stood beyond: the verifier's 0.2
    # plate glued to a fluid block, with a lid 20 above it, read 20.0 through the plate. Interface faces have
    # to be allowed as well as its own because the ray cast reports ONE of two coincident triangles, and at a
    # glued pipe's far bore it reports the wall's and not the fluid's
    d = ray_distances(mesh, faces, inward=True, allowed=own | np.asarray(mask, dtype=bool))
    finite = d[np.isfinite(d) & (d > 0)]
    row.faces_in_interface = n_total
    row.faces_measured = int(len(finite))
    if len(finite) < MIN_HIT_FRACTION * len(faces):
        floor = 2e-3 * float(np.linalg.norm(mesh.extents))
        row.reason = (f"only {len(finite)} of {len(faces)} rays into {side} met {side}'s own far side, so there is "
                      f"no thickness here to report: the body is open, the interface faces do not look into it, "
                      f"or it is thinner than this cast resolves ({floor:.3g} in the file's units)")
        return row
    row.thickness_min = float(finite.min())
    row.thickness_p05 = float(np.percentile(finite, 5))
    row.thickness_median = float(np.median(finite))
    return row


def _region_index(region_id: str) -> int | None:
    try:
        return int(str(region_id).lstrip("r")) - 1
    except ValueError:
        return None
