"""THE COVERAGE FACTS: what neither the measurement nor the look supplied, measured where a method on a
tessellation supports it and refused, with the reason written down, where none does.

`docs/joint_research.md`'s gap list, item by item, and what this module does about each one it owns:

| gap | what the builder could not be told | here |
|---|---|---|
| 5 | whether the flow turns and how hard | `centreline.march_all`: a path per mouth by plane sections, bends with R/D, refused when the turn is not one circular arc in one plane or the march lost the passage |
| 7 | a point provably OUTSIDE the domain, for the leak check | `outside_point`: past the bounding box, with the proof; refused on an external flow, where outside the part is the fluid |
| 6 | a named partition of the wall | `partition.partition`: crease patches at the spectrum's own empty band, each a plane, cylinder, cone, sphere or free-form surface |
| 8 | where a flow feature will sit | `flow_places`: steps, tapers with their angle, throats, plates standing in the passage, a chamber the passage opens into, a flat end of an external body. PLACES, never an outcome |
| 2 | local feature size from a medial axis | REFUSED: `LOCAL_FEATURE_SIZE_REFUSAL` says why |
| 4 | curvature | per-vertex REFUSED (`VERTEX_CURVATURE_REFUSAL`); a radius fitted over a whole patch, with its residual, is in the partition |

THE SCOPE RULE, enforced by tests. A place says where and what is measured there. It never says what the flow
will do (no separation, recirculation, wake, jet), never predicts the mesh, and never names a builder setting.
The `what` sentence carries no digit: the numbers are in `measurement`, typed, so a reader never parses prose
for a number and a number is never softened into prose.

DIRECTION. The geometry does not know which way the flow goes (gap 12). A step is an expansion one way and a
contraction the other, so a step is named by which side is larger, not by what the flow does across it. A flat
end of an external body is a base only once the customer's stated flow direction is given (`flow_direction`);
without it, it is a flat end and that is all it is called.

Everything here is in the file's own units, like the rest of `facts`. `planner_places` converts to metres once,
for the typed block, and nowhere else.
"""
from __future__ import annotations

import time
from typing import Any, Literal

import numpy as np
from pydantic import BaseModel, Field

from geometry_agent.facts.centreline import Centreline, march_all
from geometry_agent.facts.partition import WallPartition, partition

Vec3 = tuple[float, float, float]
COVERAGE_VERSION = "geometry_agent.coverage.v1"


# ---------------------------------------------------------------------------------------------------------------
# THE TWO REFUSALS
# ---------------------------------------------------------------------------------------------------------------

class Refusal(BaseModel):
    """A fact this module could compute a number for and will not, because the number would lie."""
    status: Literal["refused"] = "refused"
    why: str
    evidence: list[str] = Field(default_factory=list)


LOCAL_FEATURE_SIZE_REFUSAL = Refusal(
    why=("A local feature size from the medial axis is not given. The medial axis of a triangulated surface is "
         "not the medial axis of the solid it stands for at any tessellation density: every convex edge adds a "
         "spurious branch, and the filters that prune them have no setting that is right across parts. A size "
         "read off it would be a property of the tessellator, reported as a property of the part."),
    evidence=[
        "docs/research_computational_geometry.md 1.2: continuity of the medial axis needs C2 closeness "
        "(Chazal and Soufflet via Attali et al.), which no tessellation has",
        "docs/research_computational_geometry.md 3.1 and 3.2, MEASURED on this corpus: an unfiltered "
        "shrinking-ball medial size read 0.00005 where the smallest passage is 0.0399 (800x too small), and no "
        "separation angle was right on more than 3 of 6 parts",
        "docs/synthesis.md 2.1: do not emit a single filtered medial minimum",
        "what IS given instead: the passage's own section, area and hydraulic diameter, at every station of "
        "every centreline (`centrelines[].stations`), which is a plane section and converges",
    ])

VERTEX_CURVATURE_REFUSAL = Refusal(
    why=("A per-vertex curvature is not given. Discrete mean curvature provably does not converge on a "
         "tessellated cylinder: with every vertex exactly on the surface it oscillates between about -3 and 0 "
         "as the mesh refines, from the valence pattern alone, and a CAD export's long thin facets are the "
         "condition under which the cheap operators fail worst."),
    evidence=[
        "docs/research_computational_geometry.md 4.1: Wardetzky, the 4-8 cylinder counterexample",
        "docs/research_computational_geometry.md 4.2: Gatzke and Grimm, sensitivity to tangential vertex motion",
        "what IS given instead: a radius fitted over each whole crease patch that is a cylinder or a sphere, "
        "with its residual, and refused when the residual is large (`partition.patches[].radius`), and the "
        "bend radius of each centreline turn (`centrelines[].bends[].radius`)",
    ])


# ---------------------------------------------------------------------------------------------------------------
# THE POINT OUTSIDE
# ---------------------------------------------------------------------------------------------------------------
#: How far past the bounding box the points are, as a fraction of its diagonal. The loader's tessellation can
#: sit inside the true surface by its chord sag, at most R (1 - cos 0.1) for the 0.2 radian angular deflection
#: `load.load_mesh` asks for, which is under 0.0025 of the diagonal for any radius the part can have. 0.05 is
#: twenty times that, and small enough that a background box a few per cent larger than the part holds it.
OUTSIDE_MARGIN = 0.05
#: Representations whose flow is inside the part's surfaces, so a point outside every surface is outside the
#: flow domain.
FLOW_INSIDE = ("fluid_domain", "wall_shell", "annular_fluid")


class OutsideCandidate(BaseModel):
    side: Literal["x_min", "x_max", "y_min", "y_max", "z_min", "z_max"]
    point: Vec3


class OutsidePoint(BaseModel):
    """Points provably outside the flow domain, one past each face of the bounding box, so the builder can take
    whichever its own background box holds. `status` is `refused` when the representation puts the flow
    outside the part (an external body) or does not say where the flow is."""
    status: Literal["measured", "refused"]
    why: str = ""
    points: list[OutsideCandidate] = Field(default_factory=list)
    margin: float | None = None
    proof: str = ""


def outside_point(bbox_min, bbox_max, representation: str | None, sag: float | None = None) -> OutsidePoint:
    """Points outside every closed surface of the part, and why they are.

    THE PROOF, which is the whole value. Every point of every surface of the part lies inside its axis-aligned
    bounding box, so a point outside the box is outside every closed surface. When the flow is inside the part
    (a fluid domain, a wall shell to carve, an annulus) that point is outside the flow domain, and a mesh that
    reaches it has leaked. The margin covers the gap between the triangles and the true surface.

    REFUSED when that last step fails: on an external body the space outside the part IS the flow, and on an
    unsettled representation nobody has said which side is the flow."""
    rep = representation or "unknown"
    if rep not in FLOW_INSIDE:
        why = ("the flow is outside the part, so a point outside its surfaces is in the flow domain, not outside it"
               if rep == "external" else
               f"the representation is {rep!r}: which side of the surface is the flow is not settled")
        return OutsidePoint(status="refused", why=why)
    lo = np.asarray(bbox_min, dtype=np.float64)
    hi = np.asarray(bbox_max, dtype=np.float64)
    if lo.shape != (3,) or hi.shape != (3,) or not (np.isfinite(lo).all() and np.isfinite(hi).all()):
        return OutsidePoint(status="refused", why="the bounding box is not finite")
    diag = float(np.linalg.norm(hi - lo))
    if diag <= 0:
        return OutsidePoint(status="refused", why="the part has no extent")
    margin = OUTSIDE_MARGIN * diag
    if sag is not None and np.isfinite(sag) and sag >= 0.5 * margin:
        return OutsidePoint(status="refused",
                            why=(f"the measured chord sag ({sag:.4g}) is at least half the margin ({margin:.4g}): "
                                 "the true surface may reach past the box by more than the proof allows"))
    centre = 0.5 * (lo + hi)
    names = (("x_min", "x_max"), ("y_min", "y_max"), ("z_min", "z_max"))
    pts: list[OutsideCandidate] = []
    for axis in range(3):
        for sign, name in ((-1.0, names[axis][0]), (1.0, names[axis][1])):
            p = centre.copy()
            p[axis] = (lo[axis] - margin) if sign < 0 else (hi[axis] + margin)
            pts.append(OutsideCandidate(side=name, point=(float(p[0]), float(p[1]), float(p[2]))))
    return OutsidePoint(
        status="measured", points=pts, margin=margin,
        proof=("each point is past one face of the part's axis-aligned bounding box by the margin, so it is outside "
               "every closed surface of the part; the flow here is inside the part's surfaces, so the point is "
               "outside the flow domain. The margin is twenty times the largest chord sag the loader's "
               "tessellation allows"))


# ---------------------------------------------------------------------------------------------------------------
# THE PLACES
# ---------------------------------------------------------------------------------------------------------------
#: A change of section between two neighbouring stations of this ratio or more is a STEP. `entry.JUMP`'s number,
#: for the same reason: a cone that doubles its area takes several stations, a step takes one.
STEP_RATIO = 1.6
#: A gradual change of section is a TAPER when its hydraulic diameter changes by at least this per unit length
#: (2 tan 1 degree: an included angle of 2 degrees) over at least `TAPER_MIN_STATIONS` stations, and the area
#: changes by at least `TAPER_MIN_AREA_CHANGE` across it.
TAPER_SLOPE = 0.035
TAPER_MIN_STATIONS = 3
TAPER_MIN_AREA_CHANGE = 0.10
#: A taper's angle is stated only when its equivalent diameter is a straight line against length (a cone) to
#: within this fraction of the mean diameter, and its sections are round (4 pi A / P^2 above `ROUND`).
CONE_RESIDUAL = 0.01
ROUND = 0.97
#: A smooth narrowing is a THROAT when the passage narrows AND recovers by this fraction of the larger side:
#: the prominence of the valley, `profile.DIP_FRACTION`'s number.
THROAT_DIP = 0.20
#: Two places of one kind nearer than this many passage diameters are one place, found from two mouths.
SAME_PLACE_OVER_D = 0.75
#: An external body's flat end: a plane patch facing along the principal axis to within this angle, at the
#: body's extreme along it, covering at least this fraction of the body's box section across the axis.
FLAT_END_DEG = 10.0
FLAT_END_FRACTION = 0.2
#: When the flow direction is given, a flat end facing downstream to within this cosine is the base.
BASE_COS = 0.7

PlaceKind = Literal["bend", "throat", "section_change", "junction", "obstruction", "path_lost", "flat_end",
                    "blunt_base"]
#: The order places are listed in: the flow path first, then what stands in it, then an external body's ends.
#: The builder spends a cell budget in list order, and the typed block used to list eight wall-side places
#: before the throat of a venturi.
KIND_ORDER: dict[str, int] = {"throat": 0, "obstruction": 1, "section_change": 2, "bend": 3, "junction": 4,
                              "path_lost": 5, "blunt_base": 6, "flat_end": 7}


class FlowPlace(BaseModel):
    """A place along the flow path, or on an external body, where the geometry does something a mesher has a
    decision to make at. `what` names it in words with no digit; `measurement` carries the numbers."""
    id: str = ""
    kind: PlaceKind
    what: str
    where: Vec3
    opening_id: str | None = None
    measurement: dict[str, Any] = Field(default_factory=dict)
    source: str
    #: passage diameter there, for merging places found from two mouths and for scaling to cells
    scale: float = 0.0


def _v(p) -> Vec3:
    return (float(p[0]), float(p[1]), float(p[2]))


def _line_places(line: Centreline) -> list[FlowPlace]:
    out: list[FlowPlace] = []
    if line.status != "measured" or not line.stations:
        return out
    oid = line.opening_id
    st = line.stations
    pts = np.array([x.point for x in st], dtype=np.float64)
    area = np.array([x.area for x in st], dtype=np.float64)
    dh = np.array([x.hydraulic_diameter for x in st], dtype=np.float64)
    s = np.array([x.s for x in st], dtype=np.float64)
    src = f"centreline from {oid}"
    # bends
    for b in line.bends:
        if b.status == "measured":
            out.append(FlowPlace(
                kind="bend", opening_id=oid, source=src, scale=b.diameter or dh.mean(),
                what="the flow path turns here; the place is the inside of the turn",
                where=b.inner_point or b.mid_point,
                measurement={"turn_deg": round(b.turn_deg, 2), "radius": b.radius, "radius_from": b.radius_from,
                             "r_over_d": b.r_over_d,
                             "diameter": b.diameter, "width_in_plane": b.width_in_plane,
                             "r_over_width": b.r_over_width, "inner_radius": b.inner_radius,
                             "centreline_point": b.mid_point}))
        elif b.refused_by not in ("junction", "truncated"):
            # a junction is not a turn, and a turn the march stopped inside is at the place the stop already
            # names (the chamber, the junction, the place the march was lost): a second place there would be
            # the centroid sliding into the space it met, called a turn
            out.append(FlowPlace(
                kind="bend", opening_id=oid, source=src, scale=float(dh.mean()),
                what="the flow path turns here; its radius is not stated because the turn could not be fitted",
                where=b.mid_point,
                measurement={"turn_deg": round(b.turn_deg, 2), "radius": None, "radius_refused": b.refused_by,
                             "why": b.why}))
    # steps between neighbouring stations. Not within a diameter of a chamber the march stopped at: those are
    # the chamber's own mouth, already named as the passage opening into it
    stop_at = (np.asarray(line.stop_point, dtype=np.float64)
               if line.stopped_by == "opens_into_chamber" and line.stop_point is not None else None)
    for k in range(len(st) - 1):
        if area[k] <= 0:
            continue
        if stop_at is not None and np.linalg.norm(0.5 * (pts[k] + pts[k + 1]) - stop_at) < dh[k] + dh[k + 1]:
            continue
        r = area[k + 1] / area[k]
        if r >= STEP_RATIO or r <= 1.0 / STEP_RATIO:
            out.append(FlowPlace(
                kind="section_change", opening_id=oid, source=src, scale=float(min(dh[k], dh[k + 1])),
                what="the passage section changes abruptly here",
                where=_v(0.5 * (pts[k] + pts[k + 1])),
                measurement={"change": "step", "area_ratio": round(max(r, 1.0 / r), 4),
                             "larger_side": "away_from_mouth" if r > 1 else "towards_mouth",
                             "diameter_small": float(min(dh[k], dh[k + 1])),
                             "diameter_large": float(max(dh[k], dh[k + 1]))}))
    # gradual tapers, within the stretches between steps
    out += _tapers(line, pts, area, dh, s, src)
    # a smooth throat: narrows and recovers
    out += _throats(line, pts, area, dh, s, src)
    # surface standing in the passage between two stations
    for i in line.intrusions:
        # WHETHER THE PASSAGE COMES BACK decides what stands in it. Surface in the passage that the flow passes
        # and that the passage recovers from is a plate, a baffle, a rod. Surface after which the section does not
        # come back, and splits into more than one loop or covers the middle, is the crotch where the passage
        # divides: on the corpus every one of the 16 of those first named obstructions was a wye's divider or a
        # manifold's header wall, and the attention truth calls none of them an obstruction
        if i.recovers and i.open_area <= 0:
            kind, what = "obstruction", "surface covers the middle of the passage here and the passage comes back"
        elif i.recovers and i.open_fraction <= 1.0 - THROAT_DIP:
            kind, what = "throat", "a plate or a lip stands across the passage here and the passage opens out again"
        elif i.recovers and i.islands:
            kind, what = "obstruction", "something stands free inside the passage here"
        elif i.islands or i.open_area <= 0:
            kind, what = "junction", "the passage divides here"
        elif i.open_fraction <= 1.0 - THROAT_DIP:
            kind, what = "section_change", "surface stands inside the passage here and it does not open out again"
        else:
            continue
        out.append(FlowPlace(kind=kind, opening_id=oid, source=src, where=i.point, what=what,
                             scale=float(dh[min(range(len(s)), key=lambda j: abs(s[j] - i.s))]),
                             measurement={"open_fraction": round(i.open_fraction, 4), "open_area": i.open_area,
                                          "islands": i.islands, "recovers": i.recovers}))
    # how the march ended, when that is itself a place
    if line.stopped_by == "opens_into_chamber" and line.stop_point is not None:
        out.append(FlowPlace(kind="section_change", opening_id=oid, source=src, where=line.stop_point,
                             scale=float(dh[-1]), what="the passage opens into a larger chamber here",
                             measurement={"change": "opens_into_chamber",
                                          "area_ratio": round(line.stop_area_ratio or 0.0, 3),
                                          "diameter_small": float(dh[-1])}))
    elif line.stopped_by == "sidestep" and line.stop_point is not None:
        out.append(FlowPlace(kind="junction", opening_id=oid, source=src, where=line.stop_point,
                             scale=float(dh[-1]),
                             what="a second passage opens off this one here, to one side",
                             measurement={"area_ratio": round(line.stop_area_ratio or 0.0, 3),
                                          "diameter": float(dh[-1])}))
    elif line.stopped_by == "turned_back" and line.stop_point is not None:
        out.append(FlowPlace(kind="path_lost", opening_id=oid, source=src, where=line.stop_point,
                             scale=float(dh[-1]),
                             what="the measurement could not follow the passage past here",
                             measurement={"marched_length": line.length, "diameter": float(dh[-1])}))
    return out


def _tapers(line: Centreline, pts, area, dh, s, src) -> list[FlowPlace]:
    out: list[FlowPlace] = []
    n = len(area)
    if n < TAPER_MIN_STATIONS + 1:
        return out
    de = np.sqrt(4.0 * area / np.pi)
    ratio = area[1:] / np.where(area[:-1] > 0, area[:-1], 1.0)
    is_step = (ratio >= STEP_RATIO) | (ratio <= 1.0 / STEP_RATIO)
    ds = np.diff(s)
    slope = np.where(ds > 0, np.diff(de) / np.where(ds > 0, ds, 1.0), 0.0)
    sign = np.where(slope >= TAPER_SLOPE, 1, np.where(slope <= -TAPER_SLOPE, -1, 0))
    sign[is_step] = 0
    k = 0
    while k < len(sign):
        if sign[k] == 0:
            k += 1
            continue
        j = k
        while j + 1 < len(sign) and sign[j + 1] == sign[k]:
            j += 1
        a, b = k, j + 1                    # stations a .. b
        # a round passage that flares into a chamber or a fillet at one end is a cone and then something else:
        # the non-round stations are taken off the ends before the cone is read, so a stub whose cone runs into a
        # filleted box reports the cone's area ratio (2.7 on `diffuser_plenum_004`) and not the fillet's (5.3)
        rnd = 4.0 * np.pi * area / np.where(dh > 0, (4.0 * area / np.where(dh > 0, dh, 1.0)) ** 2, 1.0)
        ra, rb = a, b
        while rb - ra >= TAPER_MIN_STATIONS and rnd[rb] < ROUND:
            rb -= 1
        while rb - ra >= TAPER_MIN_STATIONS and rnd[ra] < ROUND:
            ra += 1
        if rb - ra >= TAPER_MIN_STATIONS and float(rnd[ra:rb + 1].min()) >= ROUND:
            a, b = ra, rb
        if b - a >= TAPER_MIN_STATIONS and area[a] > 0 and abs(area[b] / area[a] - 1.0) >= TAPER_MIN_AREA_CHANGE:
            idx = np.arange(a, b + 1)
            fit, fit_idx = _line_fit_trimmed(s, de, idx)
            resid = (float(np.sqrt(np.mean((np.polyval(fit, s[fit_idx]) - de[fit_idx]) ** 2)))
                     / float(de[fit_idx].mean()))
            roundness = float(rnd[idx].min())
            cone = resid <= CONE_RESIDUAL and roundness >= ROUND
            mid = idx[len(idx) // 2]
            meas: dict[str, Any] = {"change": "taper", "area_ratio": round(float(area[b] / area[a]), 4),
                                    "larger_side": "away_from_mouth" if area[b] > area[a] else "towards_mouth",
                                    "length": float(s[b] - s[a]), "start": _v(pts[a]), "end": _v(pts[b]),
                                    "diameter_small": float(min(dh[a], dh[b])),
                                    "diameter_large": float(max(dh[a], dh[b]))}
            if cone:
                meas["included_angle_deg"] = round(float(np.degrees(2.0 * np.arctan(abs(fit[0]) / 2.0))), 3)
            else:
                meas["included_angle_deg"] = None
                meas["angle_refused"] = ("the section is not round along the taper" if roundness < ROUND else
                                         "the diameter does not change linearly with length: not a cone")
            out.append(FlowPlace(kind="section_change", opening_id=line.opening_id, source=src, where=_v(pts[mid]),
                                 scale=float(dh[idx].min()),
                                 what="the passage section changes gradually along this stretch",
                                 measurement=meas))
        k = j + 1
    return out


def _line_fit_trimmed(s: np.ndarray, de: np.ndarray, idx: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """A straight line through diameter against length, with the end stations taken back off where they are the
    cylinder either side of a cone. A station straddles the junction whenever the cone does not start on one,
    and on 16 of 25 corpus reducers that one station put the whole taper off a line and refused its angle. Only
    ends are dropped, never below `TAPER_MIN_STATIONS`, so a bell stays a bell."""
    idx = np.asarray(idx)
    fit = np.polyfit(s[idx], de[idx], 1)
    while len(idx) > TAPER_MIN_STATIONS + 1:
        res = np.abs(np.polyval(fit, s[idx]) - de[idx])
        med = float(np.median(res))
        worst_end = max(res[0], res[-1])
        if worst_end <= 3.0 * med or worst_end <= 1e-4 * float(de[idx].mean()):
            break
        idx = idx[1:] if res[0] >= res[-1] else idx[:-1]
        fit = np.polyfit(s[idx], de[idx], 1)
    return fit, idx


def _throats(line: Centreline, pts, area, dh, s, src) -> list[FlowPlace]:
    n = len(area)
    if n < 5:
        return []
    before = np.maximum.accumulate(area)
    after = np.maximum.accumulate(area[::-1])[::-1]
    floor = np.minimum(before, after)
    prom = (floor - area) / np.where(floor > 0, floor, 1.0)
    inner = np.zeros(n, dtype=bool)
    inner[2:n - 2] = True
    if not inner.any():
        return []
    i = int(np.argmax(np.where(inner, prom, -np.inf)))
    if prom[i] < THROAT_DIP:
        return []
    return [FlowPlace(kind="throat", opening_id=line.opening_id, source=src, where=_v(pts[i]), scale=float(dh[i]),
                      what="the passage narrows to its smallest section here and opens out again on both sides",
                      measurement={"open_fraction": round(float(area[i] / floor[i]), 4),
                                   "diameter": float(dh[i]), "area": float(area[i])})]


def _flat_ends(part: WallPartition, facts, flow_direction) -> list[FlowPlace]:
    if part.status != "measured" or facts is None:
        return []
    ax = np.asarray(facts.axes.principal[0], dtype=np.float64)
    ax = ax / (np.linalg.norm(ax) or 1.0)
    across = [np.asarray(facts.axes.principal[1], dtype=np.float64), np.asarray(facts.axes.principal[2])]
    corners = np.array([[x, y, z] for x in (facts.bbox.min[0], facts.bbox.max[0])
                        for y in (facts.bbox.min[1], facts.bbox.max[1])
                        for z in (facts.bbox.min[2], facts.bbox.max[2])], dtype=np.float64)
    along = corners @ ax
    lo, hi = float(along.min()), float(along.max())
    extent = hi - lo
    if extent <= 0:
        return []
    box_section = float(np.ptp(corners @ across[0]) * np.ptp(corners @ across[1])) or 1.0
    flow = None
    if flow_direction is not None:
        f = np.asarray(flow_direction, dtype=np.float64)
        flow = f / (np.linalg.norm(f) or 1.0)
    out = []
    for p in part.patches:
        if p.surface != "plane" or p.axis is None:
            continue
        n = np.asarray(p.axis, dtype=np.float64)
        cos = float(n @ ax)
        if abs(cos) < np.cos(np.radians(FLAT_END_DEG)):
            continue
        at = float(np.asarray(p.centroid) @ ax)
        end = "high" if cos > 0 else "low"
        if (end == "high" and hi - at > 0.02 * extent) or (end == "low" and at - lo > 0.02 * extent):
            continue
        fraction = p.area / box_section
        if fraction < FLAT_END_FRACTION:
            continue
        kind = "flat_end"
        what = "the body ends in a flat face here, across its long axis"
        if flow is not None:
            # the patch normal points out of the body; a face whose outward normal points downstream is the base
            outward = n if float((np.asarray(p.centroid) - corners.mean(axis=0)) @ n) >= 0 else -n
            if float(outward @ flow) >= BASE_COS:
                kind, what = "blunt_base", "the body ends in a flat face here, facing downstream"
        out.append(FlowPlace(kind=kind, source=f"partition patch {p.id}", where=p.centroid,
                             scale=float(np.sqrt(p.area)), what=what,
                             measurement={"patch": p.id, "area": p.area, "fraction_of_box_section": round(fraction, 4),
                                          "faces_along_axis": end}))
    return out


def _dedupe(places: list[FlowPlace]) -> list[FlowPlace]:
    out: list[FlowPlace] = []
    for p in places:
        here = np.asarray(p.where)
        same = [q for q in out if q.kind == p.kind and np.linalg.norm(np.asarray(q.where) - here)
                < SAME_PLACE_OVER_D * max(p.scale, q.scale, 1e-12)]
        if not same:
            out.append(p)
    return out


def _rank_key(p: FlowPlace) -> tuple:
    m = p.measurement
    if p.kind == "bend":
        within = m.get("r_over_d") if m.get("r_over_d") is not None else 1e9
    elif p.kind == "throat":
        within = m.get("open_fraction", 1.0)
    elif p.kind == "section_change":
        within = -float(m.get("area_ratio") or 1.0)
    else:
        within = 0.0
    return (KIND_ORDER.get(p.kind, 99), within)


def flow_places(lines: list[Centreline], part: WallPartition | None = None, facts=None,
                flow_direction=None, representation: str | None = None) -> list[FlowPlace]:
    """Every place, deduplicated across mouths, in list order: flow path first, tightest first within a kind."""
    places: list[FlowPlace] = []
    for line in lines:
        places += _line_places(line)
    has_mouths = any(ln.status == "measured" for ln in lines)
    external = representation == "external" or (representation in (None, "unknown") and not has_mouths)
    if external and part is not None:
        places += _flat_ends(part, facts, flow_direction)
    places = _dedupe(places)
    places.sort(key=_rank_key)
    for k, p in enumerate(places):
        p.id = f"f{k + 1}"
    return places


# ---------------------------------------------------------------------------------------------------------------
# THE WHOLE RECORD
# ---------------------------------------------------------------------------------------------------------------

class Coverage(BaseModel):
    """The coverage facts for one part. `outside` is None when no representation was given: the point is proved
    against which side is the flow, and the measurement alone does not know that."""
    version: str = COVERAGE_VERSION
    centrelines: list[Centreline] = Field(default_factory=list)
    skipped_mouths: list[str] = Field(default_factory=list)
    places: list[FlowPlace] = Field(default_factory=list)
    partition: WallPartition
    outside: OutsidePoint | None = None
    local_feature_size: Refusal = LOCAL_FEATURE_SIZE_REFUSAL
    vertex_curvature: Refusal = VERTEX_CURVATURE_REFUSAL
    timings: dict[str, float] = Field(default_factory=dict)
    warnings: list[str] = Field(default_factory=list)


class _NoPassage(Exception):
    """Raised inside `measure_coverage` when the representation has no passage to march."""


#: The share of the budget the marches may spend before the rest of the mouths are listed as skipped.
MARCH_BUDGET_FRACTION = 0.7


def measure_coverage(mesh, facts, representation: str | None = None, flow_direction=None,
                     time_budget_s: float = 30.0) -> Coverage:
    """Every coverage fact for one part, inside one time budget. Nothing here raises: a stage that fails is a
    refusal with its reason, and a stage the budget skipped says so."""
    t0 = time.perf_counter()
    timings: dict[str, float] = {}
    warnings: list[str] = []

    def left() -> float:
        return time_budget_s - (time.perf_counter() - t0)

    try:
        t = time.perf_counter()
        if representation == "external":
            # the flow is around the part: no passage runs in from a face of it, and a "centreline" marched in
            # from a flat face of a car body would be a path through the solid
            raise _NoPassage
        marches = march_all(mesh, facts, keep_going=lambda: left() > (1.0 - MARCH_BUDGET_FRACTION) * time_budget_s,
                            deadline=t0 + MARCH_BUDGET_FRACTION * time_budget_s)
        timings["centrelines"] = round(time.perf_counter() - t, 3)
        lines, skipped = marches.lines, marches.skipped
        cut = [ln.opening_id for ln in lines if ln.stopped_by == "budget"]
        if cut:
            warnings.append(f"centrelines cut short by the time budget for {len(cut)} mouths: {', '.join(cut[:8])}")
        if skipped:
            warnings.append(f"centrelines not marched for {len(skipped)} mouths: {', '.join(skipped[:8])}")
    except _NoPassage:
        lines, skipped = [], []
    except Exception as exc:  # noqa: BLE001 - a coverage stage is never worth the measurement
        lines, skipped = [], []
        warnings.append(f"centrelines not measured: {type(exc).__name__}: {str(exc)[:160]}")
    try:
        t = time.perf_counter()
        part = (partition(mesh, facts, getattr(facts, "feature_edges", None)) if left() > 0 else
                WallPartition(status="refused", why="the coverage time budget was spent before the partition"))
        timings["partition"] = round(time.perf_counter() - t, 3)
    except Exception as exc:  # noqa: BLE001
        part = WallPartition(status="refused", why=f"{type(exc).__name__}: {str(exc)[:160]}")
    places = flow_places(lines, part, facts, flow_direction, representation)
    outside = None
    if representation is not None:
        sag = getattr(getattr(facts, "chord", None), "sag_max", None)
        outside = outside_point(facts.bbox.min, facts.bbox.max, representation, sag)
    timings["total"] = round(time.perf_counter() - t0, 3)
    return Coverage(centrelines=lines, skipped_mouths=skipped, places=places, partition=part, outside=outside,
                    timings=timings, warnings=warnings)


# ---------------------------------------------------------------------------------------------------------------
# THE TYPED BLOCK'S ROWS, in metres
# ---------------------------------------------------------------------------------------------------------------
#: Measurement keys that are lengths in the file's units, converted to metres for the typed block.
LENGTH_KEYS = ("radius", "diameter", "width_in_plane", "inner_radius", "diameter_small", "diameter_large",
               "length", "marched_length")
AREA_KEYS = ("open_area", "area")
POINT_KEYS = ("centreline_point", "start", "end")


def planner_places(cov: Coverage, scale_to_metres: float | None) -> list[dict[str, Any]]:
    """The places as rows for `planner_block["places"]`: `id`, `kind`, `what`, `where_m`, `measurement`,
    `from`. Every length is metres, converted here once; with no confirmed scale every length is None and
    `where_missing` says why, never a number in a field labelled metres."""
    s = float(scale_to_metres) if scale_to_metres else None
    rows = []
    for p in cov.places:
        meas: dict[str, Any] = {}
        for k, v in p.measurement.items():
            if k in LENGTH_KEYS:
                meas[f"{k}_m"] = (float(v) * s) if (v is not None and s is not None) else None
            elif k in AREA_KEYS:
                meas[f"{k}_m2"] = (float(v) * s * s) if (v is not None and s is not None) else None
            elif k in POINT_KEYS:
                meas[f"{k}_m"] = [float(c) * s for c in v] if (v is not None and s is not None) else None
            else:
                meas[k] = v
        row = {"id": p.id, "kind": p.kind, "what": p.what,
               "where_m": [float(c) * s for c in p.where] if s is not None else None,
               "measurement": meas, "from": f"coverage: {p.source}"}
        if p.opening_id:
            row["opening_id"] = p.opening_id
        if s is None:
            row["where_missing"] = "unit_not_confirmed"
        rows.append(row)
    return rows


def planner_outside(cov: Coverage, scale_to_metres: float | None) -> dict[str, Any] | None:
    """The leak-check points for the typed block, in metres, or the refusal. None when no representation was
    given, so the key is absent rather than a refusal the measurement did not make."""
    o = cov.outside
    if o is None:
        return None
    if o.status != "measured":
        return {"status": "refused", "why": o.why}
    s = float(scale_to_metres) if scale_to_metres else None
    if s is None:
        return {"status": "refused", "why": "the unit of this file has not been confirmed"}
    return {"status": "measured", "points_m": [{"side": c.side, "point": [x * s for x in c.point]} for c in o.points],
            "margin_m": o.margin * s if o.margin is not None else None, "proof": o.proof}


#: How many wall regions the typed block lists, largest first. The rest are counted.
WALL_ROWS = 12


def planner_wall(cov: Coverage, scale_to_metres: float | None) -> dict[str, Any]:
    """The named wall regions for the typed block, in metres: each patch's id, surface, share of the wall, fitted
    radius, box, and the openings it borders, so the builder can address a region by name. Or the refusal."""
    part = cov.partition
    if part.status != "measured":
        return {"status": "refused", "why": part.why}
    s = float(scale_to_metres) if scale_to_metres else None

    def m(v):
        return None if (v is None or s is None) else float(v) * s

    rows = []
    for p in part.patches[:WALL_ROWS]:
        row = {"id": p.id, "surface": p.surface, "area_fraction": round(p.area_fraction, 4),
               "radius_m": m(p.radius), "half_angle_deg": p.half_angle_deg,
               "centroid_m": [c * s for c in p.centroid] if s is not None else None,
               "box_min_m": [c * s for c in p.bbox_min] if s is not None else None,
               "box_max_m": [c * s for c in p.bbox_max] if s is not None else None,
               "borders": list(p.borders), "neighbours": list(p.neighbours)}
        if p.opening_id:
            row["is_opening"] = p.opening_id
        if p.why_no_radius and p.surface in ("cylinder", "cone", "freeform"):
            row["why_no_radius"] = p.why_no_radius
        rows.append(row)
    out = {"status": "measured", "creases_at_included_deg": part.crease_included_deg,
           "regions_total": part.patches_total, "regions": rows,
           "listed_area_fraction": round(part.area_listed_fraction, 4)}
    if s is None:
        out["where_missing"] = "unit_not_confirmed"
    return out


def planner_coverage(cov: Coverage, scale_to_metres: float | None) -> dict[str, Any]:
    """Everything this module hands the builder's typed block, in one dict: the places, the leak-check points,
    the named wall regions, and the two refusals by name, so a reader learns they were decided and not forgotten."""
    out: dict[str, Any] = {"version": cov.version,
                           "places": planner_places(cov, scale_to_metres),
                           "wall": planner_wall(cov, scale_to_metres),
                           "refused": {"local_feature_size": cov.local_feature_size.why,
                                       "vertex_curvature": cov.vertex_curvature.why}}
    outside = planner_outside(cov, scale_to_metres)
    if outside is not None:
        out["outside"] = outside
    return out
