"""Local scales the mesher must resolve (edge lengths, sharp edges, wall thickness, gaps between surfaces) and
the surface defects it trips on (non-manifold edges, inconsistent winding, sliver triangles).

Thickness and gaps are chords that have to prove what they crossed; `chords.py` has the three tests and why the
old one-ray reading put the bore in `min_gap` and half a pipe's length in `thickness_median`. Sharp and knife
edges are counted as feature LINES and slivers as a fraction, because the per-triangle counts they replaced
grew with the triangle count on an unchanged shape.

Distances from points to a surface are exact here: the query goes to the triangles themselves, found through
centroid k-d trees bucketed by triangle size (`_TriangleDistance`), never to a point cloud standing in for the
surface. trimesh's ProximityQuery gathers every candidate triangle per query point and allocated gigabytes on
a 600k-face assembly; it is not used anywhere."""
from __future__ import annotations

import numpy as np
import trimesh
from scipy.spatial import cKDTree

from geometry_agent.facts import chords, load
from geometry_agent.facts.schema import ChordCoverage, Features, GapCluster, ThinCluster

#: Dihedral angle above which an edge is sharp (the mesher must keep it) and above which it is a knife edge.
SHARP_DEG = 60.0
KNIFE_DEG = 150.0
#: A chord under this fraction of the diagonal is a thin place (inward) or a near-touching gap (outward). The
#: thin clusters and the gap clusters are the accepted chords below it, grouped by where they are.
THIN_FRACTION_OF_DIAG = 0.015
GAP_FRACTION_OF_DIAG = 0.02
#: Connected components with fewer faces than this are export crumbs (a stray triangle, a folded sliver): a
#: closed body needs four faces at least. Rays neither start from them nor stop on them, so debris a loader
#: left behind cannot pollute thickness_min or min_gap.
MIN_COMPONENT_FACES = 4
#: A triangle is a sliver when its longest edge exceeds this many times its height (2 * area / longest edge).
#: A needle and a long strip are the same shape, so this is a pure shape count: trimesh's 48-section pipes are
#: strips of aspect 150 and stay under it; the needles of a bad export (dirty_exports/sliver_cap, r/1000 wide)
#: start at 1000. OCCT's default deflection tessellates a 600 mm tube into strips of aspect 600 to 3000, and
#: those are counted too: the count says how many such triangles the surface carries, not that they are wrong.
SLIVER_ASPECT = 300.0
#: Query points per region for the region gap: its vertices and face centres thinned to this many, plus as many
#: uniform surface samples so the middle of a large triangle is represented too.
GAP_QUERY_POINTS = 4000
#: Regions compared for the gap, largest surface first, so an assembly of hundreds of parts still finishes.
MAX_GAP_REGIONS = 24
#: Region pairs refined from the point-to-point bound to the exact point-to-triangle distance, closest pairs
#: first; a pair whose bounding boxes are farther apart than the best gap so far is skipped, and the search
#: stops once the gap is zero.
GAP_REFINE_PAIRS = 48
#: A gap below this fraction of the diagonal is zero: the bodies touch (tessellation round-off is 1e-9 or less).
GAP_ZERO_OF_DIAG = 1e-9
#: Nearest centroids fetched per size bucket in an exact distance query. The triangle nearest a point has its
#: centroid within (distance + bucket radius), and among same-sized triangles it is one of the closest
#: centroids; eight covers a vertex fan of ordinary valence.
TRIANGLE_KNN = 8
#: Lattice cloud that stands in for a region's surface in the cheap first filter of an exact query: points every
#: h along each triangle's rows and edges, so no surface point is farther than h from the cloud and
#: "cloud distance <= bound + h" rejects nothing that is truly within bound. h is this fraction of the
#: diagonal, coarsened per region (by LATTICE_COARSEN a step) until the rows and edge points the region's
#: triangles longer than h would add stay under LATTICE_MAX_POINTS; the vertices are always in. The count is
#: predicted from the triangles' lengths and heights, not from area / h**2, because every triangle longer than
#: h costs a few points whatever its area: on a 1.3M-face frame member that estimate was off fifteenfold and
#: the cloud reached 4.7M points.
LATTICE_H_OF_DIAG = 2e-3
LATTICE_MAX_POINTS = 300_000
LATTICE_COARSEN = 1.5

_TRI_DIST_ATTR = "_geometry_agent_triangle_distance"


class _TriangleDistance:
    """Exact distance from points to a set of triangles. Triangles are bucketed by circumradius in powers of
    two, each bucket a k-d tree over its centroids. A triangle within `bound` of a point has its centroid within
    bound + the bucket's radius, so each bucket is asked for its TRIANGLE_KNN nearest centroids inside that
    radius and only those candidates get the exact point-to-triangle test. Memory is linear in the number of
    candidates, never in points x triangles."""

    def __init__(self, triangles: np.ndarray, normals: np.ndarray | None = None, face_ids: np.ndarray | None = None,
                 vertices: np.ndarray | None = None, vertex_owner: np.ndarray | None = None):
        self.triangles = np.asarray(triangles, dtype=float)
        self.normals = None if normals is None else np.asarray(normals, dtype=float)
        self.face_ids = np.arange(len(self.triangles)) if face_ids is None else np.asarray(face_ids)
        self.vertices = vertices
        self.vertex_owner = vertex_owner
        if self.normals is None:
            cross = np.cross(self.triangles[:, 1] - self.triangles[:, 0], self.triangles[:, 2] - self.triangles[:, 0])
            self.normals = cross / np.maximum(np.linalg.norm(cross, axis=1), 1e-300)[:, None]
        centers = self.triangles.mean(axis=1)
        self.centers = centers
        tri = self.triangles
        self.longest = np.max(np.stack([np.linalg.norm(tri[:, 1] - tri[:, 0], axis=1), np.linalg.norm(tri[:, 2] - tri[:, 1], axis=1),
                                        np.linalg.norm(tri[:, 0] - tri[:, 2], axis=1)], axis=1), axis=1)
        self.height = np.linalg.norm(np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0]), axis=1) / np.maximum(self.longest, 1e-300)
        radius = np.linalg.norm(self.triangles - centers[:, None, :], axis=2).max(axis=1)
        positive = radius[radius > 0]
        r0 = float(positive.min()) if len(positive) else 1.0
        level = np.floor(np.log2(np.maximum(radius, r0) / r0)).astype(int)
        self.buckets: list[tuple[cKDTree, np.ndarray, float, np.ndarray, np.ndarray]] = []
        for lv in np.unique(level):
            idx = np.where(level == lv)[0]
            pts = self.triangles[idx].reshape(-1, 3)
            self.buckets.append((cKDTree(centers[idx]), idx, float(radius[idx].max()), pts.min(axis=0), pts.max(axis=0)))

    def spacing(self, h: float) -> float:
        """h coarsened by LATTICE_COARSEN steps until the points the lattice adds beyond the vertices (rows of
        L / 2h + 2 points per row and ceil(height / h) rows, plus two edges of L / h + 2 points, per triangle
        longer than h) fit LATTICE_MAX_POINTS."""
        while True:
            big = self.longest > h
            if not big.any():
                return h
            L = self.longest[big]
            rows = np.ceil(self.height[big] / h)
            added = float((rows * (L / (2.0 * h) + 2.0) + 2.0 * (L / h + 2.0)).sum())
            if added <= LATTICE_MAX_POINTS:
                return h
            h *= LATTICE_COARSEN

    def lattice(self, h: float) -> tuple[cKDTree, float]:
        """The lattice cloud at spacing h (built once) and its cover radius: every point of the surface lies
        within that radius of some cloud point. The vertices alone cover a triangle whose longest edge is under
        h; only larger triangles get lattice rows."""
        if getattr(self, "_lattice", None) is None:
            tri = self.triangles
            verts, owner = self.vertices, self.vertex_owner
            if verts is None or owner is None:
                verts, first = np.unique(tri.reshape(-1, 3), axis=0, return_index=True)
                owner = first // 3
            big = np.nonzero(self.longest > h)[0]
            rows, row_owner = _lattice_points(tri[big], h)
            self._lattice = (cKDTree(np.vstack([verts, rows])), h)
            self._lattice_owner = np.concatenate([np.asarray(owner, dtype=int), big[row_owner]])
        return self._lattice

    def distance_to(self, pts: np.ndarray, tri: np.ndarray) -> np.ndarray:
        """Exact distance from each point to the given local triangle (one per point)."""
        pts = np.asarray(pts, dtype=float).reshape(-1, 3)
        if len(pts) == 0:
            return np.zeros(0)
        return np.linalg.norm(trimesh.triangles.closest_point(self.triangles[tri], pts) - pts, axis=1)

    def query(self, pts: np.ndarray, bound: float = np.inf, lattice_h: float | None = None,
              threshold_only: bool = False) -> tuple[np.ndarray, np.ndarray]:
        """(distance, local triangle index) per point; inf and -1 where no triangle lies within `bound`. With
        `lattice_h` and a finite bound the points are first sifted through the lattice cloud, which is exact
        and far cheaper than the per-bucket search when most points are nowhere near the surface. With
        `threshold_only` a point within `bound` of the triangle owning its nearest lattice point is settled
        there (the answer is then a triangle within bound, not necessarily the nearest), which is all the
        coincidence test needs and spares the bucket search for nearly every point that truly touches."""
        pts = np.asarray(pts, dtype=float).reshape(-1, 3)
        best = np.full(len(pts), np.inf)
        best_idx = np.full(len(pts), -1)
        if len(pts) == 0:
            return best, best_idx
        if lattice_h is not None and np.isfinite(bound):
            tree, cover = self.lattice(lattice_h)
            d, j = tree.query(pts, k=1, distance_upper_bound=bound + cover)
            keep = np.nonzero(np.isfinite(d))[0]
            if threshold_only and len(keep):
                guess = self._lattice_owner[j[keep]]
                dg = self.distance_to(pts[keep], guess)
                settled = dg <= bound
                best[keep[settled]] = dg[settled]
                best_idx[keep[settled]] = guess[settled]
                keep = keep[~settled]
            if len(keep) < len(pts):
                if len(keep):
                    best[keep], best_idx[keep] = self.query(pts[keep], bound)
                return best, best_idx
        p_lo, p_hi = pts.min(axis=0), pts.max(axis=0)
        for tree, idx, r_max, b_lo, b_hi in self.buckets:
            if np.isfinite(bound) and (np.any(p_lo > b_hi + bound) or np.any(p_hi < b_lo - bound)):
                continue
            k = min(TRIANGLE_KNN, len(idx))
            d, j = tree.query(pts, k=k, distance_upper_bound=bound + r_max)
            d = np.asarray(d).reshape(len(pts), -1)
            j = np.asarray(j).reshape(len(pts), -1)
            pi, ki = np.nonzero(np.isfinite(d))
            if len(pi) == 0:
                continue
            tri = idx[j[pi, ki]]
            if np.isfinite(bound):
                # the distance to a triangle's plane bounds the distance to the triangle from below: candidates
                # whose plane is already farther than `bound` need no exact test
                plane = np.abs(np.einsum("ij,ij->i", pts[pi] - self.centers[tri], self.normals[tri]))
                near = plane <= bound
                pi, tri = pi[near], tri[near]
                if len(pi) == 0:
                    continue
            closest = trimesh.triangles.closest_point(self.triangles[tri], pts[pi])
            dd = np.linalg.norm(closest - pts[pi], axis=1)
            order = np.lexsort((dd, pi))
            pi, dd, tri = pi[order], dd[order], tri[order]
            first = np.ones(len(pi), dtype=bool)
            first[1:] = pi[1:] != pi[:-1]
            p, dmin, tmin = pi[first], dd[first], tri[first]
            better = dmin < best[p]
            best[p[better]] = dmin[better]
            best_idx[p[better]] = tmin[better]
        return best, best_idx


def _lattice_points(tri: np.ndarray, h: float) -> tuple[np.ndarray, np.ndarray]:
    """Points at most h apart on every triangle: along rows parallel to its longest edge and along its edges.
    A point of the triangle is within h/2 of a row (or of an edge, when its foot on the row falls outside the
    triangle) and within h/2 of a point along it, so the cloud covers the surface within h / sqrt(2). Row
    counts follow the height and edge counts the length, so a long thin strip costs its length over h, not its
    length squared."""
    tri = np.asarray(tri, dtype=float)
    if len(tri) == 0:
        return np.zeros((0, 3)), np.zeros(0, dtype=int)
    e = np.stack([np.linalg.norm(tri[:, 1] - tri[:, 0], axis=1), np.linalg.norm(tri[:, 2] - tri[:, 1], axis=1),
                  np.linalg.norm(tri[:, 0] - tri[:, 2], axis=1)], axis=1)
    k = np.argmax(e, axis=1)
    rows_idx = np.arange(len(tri))
    A = tri[rows_idx, k]
    B = tri[rows_idx, (k + 1) % 3]
    C = tri[rows_idx, (k + 2) % 3]
    L = e[rows_idx, k]
    area = 0.5 * np.linalg.norm(np.cross(B - A, C - A), axis=1)
    height = 2.0 * area / np.maximum(L, 1e-300)
    mv = np.maximum(1, np.ceil(height / h)).astype(int)
    # rows j = 0..mv-1 at v = j / mv (the row at v = 1 is the vertex C, covered by the edge points)
    row_tri = np.repeat(rows_idx, mv)
    row_j = np.arange(len(row_tri)) - np.repeat(np.cumsum(mv) - mv, mv)
    v = row_j / mv[row_tri]
    a = A[row_tri] + v[:, None] * (C[row_tri] - A[row_tri])
    b = B[row_tri] + v[:, None] * (C[row_tri] - B[row_tri])
    n_pts = np.maximum(2, np.ceil(L[row_tri] * (1.0 - v) / h).astype(int) + 1)
    pt_row = np.repeat(np.arange(len(row_tri)), n_pts)
    i = np.arange(len(pt_row)) - np.repeat(np.cumsum(n_pts) - n_pts, n_pts)
    t = i / (n_pts[pt_row] - 1)
    rows = a[pt_row] + t[:, None] * (b[pt_row] - a[pt_row])
    owners = [row_tri[pt_row]]
    edges = []
    for P, Q in ((A, C), (B, C)):
        n_e = np.maximum(2, np.ceil(np.linalg.norm(Q - P, axis=1) / h).astype(int) + 1)
        pe = np.repeat(rows_idx, n_e)
        ie = np.arange(len(pe)) - np.repeat(np.cumsum(n_e) - n_e, n_e)
        te = ie / (n_e[pe] - 1)
        edges.append(P[pe] + te[:, None] * (Q[pe] - P[pe]))
        owners.append(pe)
    return np.vstack([rows, *edges]), np.concatenate(owners)


def lattice_spacing(mesh: trimesh.Trimesh, region: int, region_of: np.ndarray) -> float:
    """Lattice spacing for one region: LATTICE_H_OF_DIAG of the diagonal, coarsened so the region's cloud stays
    under LATTICE_MAX_POINTS beyond its vertices."""
    diag = float(np.linalg.norm(mesh.extents))
    return triangle_distance_of(mesh, region, region_of).spacing(LATTICE_H_OF_DIAG * diag)


def triangle_distance_of(mesh: trimesh.Trimesh, region: int, region_of: np.ndarray) -> _TriangleDistance:
    """The exact distance query for one region's surface, built once per (mesh, region) and kept on the mesh:
    interfaces and the region gap both ask for it."""
    cache = getattr(mesh, _TRI_DIST_ATTR, None)
    if cache is None or cache[0] != len(mesh.faces):
        cache = (len(mesh.faces), {})
        try:
            setattr(mesh, _TRI_DIST_ATTR, cache)
        except AttributeError:
            pass
    store = cache[1]
    if region not in store:
        faces = np.where(region_of == region)[0]
        vid, first = np.unique(np.asarray(mesh.faces)[faces].reshape(-1), return_index=True)
        store[region] = _TriangleDistance(mesh.triangles[faces], mesh.face_normals[faces], faces,
                                          np.asarray(mesh.vertices)[vid], first // 3)
    return store[region]


def _component_face_counts(mesh: trimesh.Trimesh) -> np.ndarray:
    """Per face, the number of faces in its connected component, from the loader's component labels (the same
    rule that drops debris, so a crumb the loader kept for any reason is still recognised here)."""
    if len(mesh.faces) == 0:
        return np.zeros(0, dtype=int)
    labels = load.face_components(mesh)
    return np.bincount(labels)[labels]


def _ray_distances(mesh: trimesh.Trimesh, faces: np.ndarray, inward: bool, allowed: np.ndarray | None = None) -> np.ndarray:
    """Distance from each face along its normal (inward: the wall thickness behind it; outward: the gap to the
    next surface). A hit does not count when it is the face itself or a neighbour in the same plane (travel
    under 2 eps: the origin is lifted eps off the face and any facet coplanar with it is grazed, not crossed),
    or when it lands on debris (`allowed` False)."""
    origins = mesh.triangles_center[faces]
    normals = mesh.face_normals[faces] * (-1.0 if inward else 1.0)
    eps = 1e-3 * float(np.linalg.norm(mesh.extents))
    origins = origins + normals * eps
    out = np.full(len(faces), np.inf)
    if len(faces) == 0:
        return out
    locs, ray_idx, tri_idx = mesh.ray.intersects_location(origins, normals, multiple_hits=True)
    if len(ray_idx):
        d = np.linalg.norm(locs - origins[ray_idx], axis=1) + eps
        own = faces[ray_idx]
        valid = (tri_idx != own) & (d > 2 * eps)
        if allowed is not None:
            valid &= allowed[tri_idx]
        np.minimum.at(out, ray_idx[valid], d[valid])
    return out


def _winding_consistent(table) -> bool:
    """Every edge used by exactly two faces is traversed once each way (trimesh's is_winding_consistent, read
    off the loader's edge table instead of regrouping 3F edges)."""
    two = np.nonzero(table.counts == 2)[0]
    if len(two) == 0:
        return True
    first = table.face_ptr[two]
    return bool(np.all(table.face_dir[first].astype(int) + table.face_dir[first + 1].astype(int) == 0))


def _sliver_faces(mesh: trimesh.Trimesh) -> int:
    """Triangles whose longest edge is over SLIVER_ASPECT times their height. A zero-area triangle is the limit
    of a sliver and counts."""
    tri = np.asarray(mesh.triangles)
    if len(tri) == 0:
        return 0
    longest = np.max(np.stack([np.linalg.norm(tri[:, 1] - tri[:, 0], axis=1), np.linalg.norm(tri[:, 2] - tri[:, 1], axis=1),
                               np.linalg.norm(tri[:, 0] - tri[:, 2], axis=1)], axis=1), axis=1)
    height = 2.0 * np.asarray(mesh.area_faces) / np.maximum(longest, 1e-300)
    return int(np.count_nonzero((height * SLIVER_ASPECT < longest) & (longest > 0)))


def _coverage(res: chords.Result) -> ChordCoverage:
    return ChordCoverage(faces_total=res.faces_total, faces_cast=res.faces_cast, every_face_tested=res.every_face,
                         minimum_exhaustive=res.exhaustive, rejected_fraction=round(res.rejected_fraction, 6),
                         passage_fraction=round(res.passage_fraction, 6), oblique_fraction=round(res.oblique_fraction, 6))


def _thin_clusters(mesh: trimesh.Trimesh, res: chords.Result, below: float, region_of: np.ndarray) -> list[ThinCluster]:
    return [ThinCluster(id=f"t{k}", faces=c["faces"], thickness_min=c["min"], thickness_median=c["median"],
                        centroid=c["centroid"], area=c["area"], extent=c["extent"])
            for k, c in enumerate(chords.clusters(mesh, res, below, region_of), start=1)]


def _gap_clusters(mesh: trimesh.Trimesh, res: chords.Result, below: float, region_of: np.ndarray) -> list[GapCluster]:
    return [GapCluster(id=f"g{k}", faces=c["faces"], gap_min=c["min"], gap_median=c["median"], gap_max=c["max"],
                       centroid=c["centroid"], extent=c["extent"], area=c["area"], regions=c["regions"])
            for k, c in enumerate(chords.clusters(mesh, res, below, region_of), start=1)]


def _gap_points(part: trimesh.Trimesh, seed: int) -> np.ndarray:
    """Query points on one region: vertices and face centres thinned to GAP_QUERY_POINTS, plus the same number
    of seeded area-uniform surface samples."""
    pts = np.vstack([part.vertices, part.triangles_center])
    if len(pts) > GAP_QUERY_POINTS:
        pts = pts[:: len(pts) // GAP_QUERY_POINTS + 1]
    samples, _ = trimesh.sample.sample_surface(part, GAP_QUERY_POINTS, seed=seed)
    return np.vstack([pts, samples])


def _bbox_distance(a: np.ndarray, b: np.ndarray) -> float:
    sep = np.maximum(0.0, np.maximum(b[0] - a[1], a[0] - b[1]))
    return float(np.linalg.norm(sep))


def _region_gap(mesh: trimesh.Trimesh, seed: int = 0) -> tuple[float | None, tuple[str, str] | None]:
    """Smallest distance between the surfaces of two regions. A point-to-point pass over each region's query
    points bounds it from above for every pair; the closest pairs are then refined with the exact point-to-
    triangle distance, so two bodies whose tessellations differ but whose surfaces touch report zero, and a
    0.5 mm clearance reports 0.5 rather than the spacing of the nearest sampled points. Regions are compared
    largest first and capped, so an assembly of hundreds of parts still finishes."""
    from geometry_agent.facts.openings import _region_of_faces
    from geometry_agent.facts.regions import region_meshes
    parts = region_meshes(mesh)
    if len(parts) < 2:
        return None, None
    order = sorted(range(len(parts)), key=lambda k: -float(parts[k].area))[:MAX_GAP_REGIONS]
    pts = {i: _gap_points(parts[i], seed) for i in order}
    trees = {i: cKDTree(pts[i]) for i in order}
    pairs = []
    for a_pos, i in enumerate(order):
        for j in order[a_pos + 1:]:
            d = min(float(trees[i].query(pts[j])[0].min()), float(trees[j].query(pts[i])[0].min()))
            pairs.append((d, i, j))
    pairs.sort()
    best, (bi, bj) = pairs[0][0], pairs[0][1:]
    zero = GAP_ZERO_OF_DIAG * float(np.linalg.norm(mesh.extents))
    region_of = None
    for _, i, j in pairs[:GAP_REFINE_PAIRS]:
        if best <= zero:
            break
        if _bbox_distance(parts[i].bounds, parts[j].bounds) >= best:
            continue
        if region_of is None:
            region_of = _region_of_faces(mesh)
        for surface, query in ((i, j), (j, i)):
            d, _ = triangle_distance_of(mesh, surface, region_of).query(pts[query], bound=best,
                                                                        lattice_h=lattice_spacing(mesh, surface, region_of))
            m = float(d.min())
            if m < best:
                best, (bi, bj) = m, (min(i, j), max(i, j))
    if best <= zero:
        best = 0.0
    return best, (f"r{bi + 1}", f"r{bj + 1}")


def detect_features(mesh: trimesh.Trimesh, seed: int = 0, region_gap: bool = True,
                    ray_cap: int = chords.RAY_FACE_CAP, dist_cap: int = chords.DISTRIBUTION_FACES) -> Features:
    """Every number here is deterministic: no face sample is drawn (`seed` reaches only the region gap's query
    points, which are fixed by it). `ray_cap` and `dist_cap` bound the chord casting on a giant file, and when
    either binds, `thickness_coverage` and `gap_coverage` say so."""
    from geometry_agent.facts.openings import _region_of_faces
    diag = float(np.linalg.norm(mesh.extents))
    table = load.edge_table(mesh)
    # the distinct edges from the loader's table, already built: trimesh's edges_unique groups all 3F edges
    # again for the same set (1.3 s on 1M faces)
    ev = np.asarray(table.edges)
    el = np.linalg.norm(np.asarray(mesh.vertices)[ev[:, 0]] - np.asarray(mesh.vertices)[ev[:, 1]], axis=1)
    angles = np.degrees(mesh.face_adjacency_angles)
    pairs = np.asarray(mesh.face_adjacency_edges)
    verts = np.asarray(mesh.vertices)
    edge_len = np.linalg.norm(verts[pairs[:, 0]] - verts[pairs[:, 1]], axis=1) if len(pairs) else np.zeros(0)
    sharp = angles > SHARP_DEG
    knife = angles > KNIFE_DEG

    solid = _component_face_counts(mesh) >= MIN_COMPONENT_FACES
    if not solid.any():
        solid = np.ones(len(mesh.faces), dtype=bool)
    pool = np.flatnonzero(solid)
    region_of = _region_of_faces(mesh)
    wall = chords.measure_side(mesh, pool, inward=True, allowed=solid, ray_cap=ray_cap, dist_cap=dist_cap)
    gap = chords.measure_side(mesh, pool, inward=False, allowed=solid, ray_cap=ray_cap, dist_cap=dist_cap)
    have_t = len(wall.values) > 0
    gap_clusters = _gap_clusters(mesh, gap, GAP_FRACTION_OF_DIAG * diag, region_of)
    gap_between, closest = _region_gap(mesh, seed) if region_gap else (None, None)
    n_faces = len(mesh.faces)
    slivers = _sliver_faces(mesh)

    return Features(
        edge_length_min=float(el.min()) if len(el) else 0.0,
        edge_length_median=float(np.median(el)) if len(el) else 0.0,
        sharp_edge_count=chords.feature_lines(verts, pairs[sharp]),
        sharp_edge_length=float(edge_len[sharp].sum()),
        knife_edge_count=chords.feature_lines(verts, pairs[knife]),
        knife_edge_length=float(edge_len[knife].sum()),
        thickness_min=wall.minimum,
        thickness_p05=chords.weighted_percentile(wall.values, wall.weights, 5.0) if have_t else None,
        thickness_median=chords.weighted_percentile(wall.values, wall.weights, 50.0) if have_t else None,
        thin_clusters=_thin_clusters(mesh, wall, THIN_FRACTION_OF_DIAG * diag, region_of),
        near_touching_pairs=len(gap_clusters),
        min_gap=gap.minimum,
        min_gap_between_regions=gap_between, closest_regions=closest,
        non_manifold_edge_count=int(np.count_nonzero(table.counts >= 3)),
        winding_consistent=_winding_consistent(table),
        sliver_faces=slivers,
        sliver_fraction=float(slivers / n_faces) if n_faces else 0.0,
        gap_clusters=gap_clusters,
        thickness_coverage=_coverage(wall),
        gap_coverage=_coverage(gap),
    )
