"""The centreline of a passage, marched in from each mouth, and the bends on it with their radius.

WHY THIS EXISTS. A 90 degree elbow at R/D 1 and one at R/D 5 were indistinguishable in the facts record
(`docs/joint_research.md`, gap 5), and they are different meshing problems. The area profile cannot help: it is
cut across ONE fitted axis and refuses every elbow (`reconcile/profile.trust`). The per-mouth march
(`reconcile/entry.py`) cannot either: it goes straight along the mouth normal and leaves the bore at the bend.

WHAT THE LITERATURE SAYS, and why this is not that. The standard centreline is VMTK's: the minimal path in the
reciprocal-radius metric over the Voronoi diagram, which carries the maximal inscribed sphere at every point.
`docs/research_computational_geometry.md` sections 1.2 and 8 say not to build it here: the medial axis of a
triangulation is not the medial axis of the solid at any density, and a shrinking-ball prototype on this corpus
was 800 times too small. So this file never touches the medial axis. It uses PLANE SECTIONS, which do converge:
a tessellation within a Hausdorff distance e of the true surface cuts a plane in a polygon within about e of the
true section, except where the plane is nearly tangent to the surface, and a plane across a passage is the
opposite of tangent. The centroid of the section is then the centreline point, exactly, for any passage whose
section is symmetric about the path (a circular or rectangular pipe, straight or bent), and within the section's
own asymmetry otherwise.

THE MARCH. From the mouth, step `STEP_OVER_D` section diameters along the current tangent, find the plane
through that point that cuts the passage in the least area (`_across`: that plane is across the passage on a
cylinder, a cone and a torus alike), take the innermost closed loop enclosing the point (the passage), and move
to its centroid. The plane's normal is the tangent for the next step. The step halves where the path turns more
than `MAX_TURN_PER_STEP_DEG` in one step, down to `MIN_STEP_OVER_D`.

THE BEND, off the marched points, CHECKED AGAINST THE WALL. Where the tangent turns, a circle is fitted in 3D
(plane by SVD, then an algebraic fit refined by Gauss-Newton) to the points of that turn. The turn is refused
when it holds fewer than `MIN_BEND_STATIONS` stations, when its section jumps (a junction, not a bend), when its
points are not on one circle or not in one plane, or when the march stopped inside it. Then the radius is read a
second way, off the wall's own vertices, which lie on the true surface where the facets do not
(`_wall_radius`): the inner and outer walls across the turn fitted as circles. The radius is stated ONLY when
those two walls are concentric arcs, and it is then theirs; everywhere else it is refused, because a centroid
circle with nothing independent to check it can be confidently wrong (30 per cent on a coarse corpus elbow).
Validated against the corpus generator's own radius on the 36 elbows and 13 S-ducts in `eval/coverage/bends.py`.

WHAT IT NEVER SAYS. It never names a flow direction, a separation, a recirculation or a mesh setting. It says
where the path turns, how tight the turn is against the passage it turns, and where the inside of the turn is.
Nothing here reads a brief, a family, a file name or an answer key.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Literal

import numpy as np
from pydantic import BaseModel, Field

Vec3 = tuple[float, float, float]

#: Step between stations, in section diameters (the hydraulic diameter of the last section). Small enough that
#: a bend of R/D 1 carries seven stations over 90 degrees, large enough that a 60 D passage is 300 cuts.
STEP_OVER_D = 0.2
#: How far the march may go, in the mouth's own diameters, and in stations. A passage that has run this far is
#: a long pipe whatever it does next, and the cost of a part is bounded by the second number.
MAX_OVER_D = 80.0
MAX_STATIONS = 400
#: Where the first station is, in mouth diameters inside the mouth plane. On the plane itself the cut meets
#: the mouth's own face edge-on.
FIRST_OVER_D = 0.1
#: The first section has to be this close to the mouth's own passage area, or the mouth's centre is not inside
#: its own passage (an annulus, whose centre is in the hub, or a mouth whose face is not across its passage).
#: `stubs.MOUTH_AREA_BAND`'s numbers, for the same reason.
ENTRY_AREA_BAND = (0.5, 2.0)
#: A section larger than this multiple of the largest section already seen is a chamber or a header the
#: passage opens into. The centreline stops there: inside a chamber the section centroid is not a path.
CHAMBER_RATIO = 2.5
#: ...and wider than this many of the last section's diameters in BOTH directions across the plane. A cut through
#: a turn tighter than the march can follow is large in one direction only.
CHAMBER_MINOR = 1.3
#: The window a chamber's growth is measured over, in passage diameters: `CHAMBER_RATIO` times the area half a
#: diameter back. A 40 degree cone grows 1.85 times in area over half a diameter; the fillet into a housing
#: grows 4 to 6 times.
CHAMBER_WINDOW_OVER_D = 0.5
CHAMBER_ASPECT = 2.5
#: A section that moves sideways by more than this fraction of the previous diameter in one step has met a
#: second passage (a tee's branch, a header): the centroid of the merged section is between two passages.
SIDESTEP_OVER_D = 0.25
#: A step whose chord turns by more than this is taken again at half the length, down to `MIN_STEP_OVER_D`: the
#: plane of a long step across a tight bend cuts the bore obliquely and its centroid leaves the path. At R/D
#: 0.75 and a fixed step of 0.2 D the march read the radius 10 per cent low and left the bore halfway round.
MAX_TURN_PER_STEP_DEG = 8.0
MIN_STEP_OVER_D = 0.1
#: Stops that end a march inside the passage rather than at a mouth. A turn reaching one of them is cut short.
TRUNCATING_STOPS = ("turned_back", "sidestep", "opens_into_chamber", "budget")
#: The tilt the least-area search tries either way about each axis across the current normal (`_across`).
TILT_RAD = 0.08
#: One step turning the tangent by more than this is not a bend, it is the march losing the passage.
MAX_STEP_TURN_DEG = 45.0
#: Faces considered for a cut: those whose bounding box meets a ball of this many section diameters around
#: the predicted point. A cut that finds no passage inside it is retried against the whole body once, so a
#: chamber larger than the ball is still seen as a chamber and not as the end of the passage.
REACH_OVER_D = 2.0

#: A surface vertex between two stations is IN the passage when it lies inside the earlier station's section by
#: more than this fraction of the local diameter. Below it are the bore's own facets, which sit on the section
#: boundary to within the chord sag and, in a bend, the sagitta of one step (0.005 D at R/D 1).
INTRUDE_OVER_D = 0.05
#: The section after an intrusion is back to the passage when it is within this fraction of the one before.
RECOVER = 0.2
#: How far either side of an intrusion's axial position the open area is cut, in local diameters: a plane on
#: the plate's own face cuts it edge-on.
INTRUSION_NUDGE = 0.004

#: THE BEND TESTS. A station is IN A TURN when its tangent turns faster than `MIN_CURVATURE_D` (curvature times
#: the local diameter, i.e. D over R): 0.05 is a radius of 20 diameters. Below it the path is straight within
#: the resolution of the march. Set on the STRAIGHT families alone (reducers, venturis, transitions), whose
#: largest reading is printed by `eval/coverage/bends.py`, never on the elbows it is validated on.
MIN_CURVATURE_D = 0.05
#: Two bursts of turning the same way this close together, in passage diameters of arc length, are one turn.
RUN_JOIN_OVER_D = 1.0
#: A turn of less than this in total is not reported as a bend.
MIN_TURN_DEG = 10.0
#: The fewest marched points a circle may be fitted to. Three define a circle and prove nothing.
MIN_BEND_STATIONS = 4
#: Refusals: RMS distance of the turn's points from the fitted circle, and from its plane, over the radius.
MAX_ARC_RESIDUAL = 0.03
MAX_PLANE_RESIDUAL = 0.03
#: A turn is refused when the section changes size by more than this between two neighbouring stations inside
#: it. A bend keeps its section, or changes it a few per cent a station in a reducing elbow; a path that crosses
#: a tee's junction or a manifold's header gains the branch's area in one step. Measured on the synthetic
#: manifold before this rule: a path from the inlet into a branch read a "bend" of R/D 0.29 at the junction.
BEND_AREA_STEP = 0.10
#: THE WALL CROSS-CHECK (`_wall_radius`): the turn is cut into this many angular slices, the end `WALL_SPAN_TRIM`
#: of it at each side is left out (where the turn meets its legs), at least `WALL_MIN_BINS` slices must hold a
#: wall vertex on each side, and the two walls must be concentric circles to `WALL_CONCENTRIC` of the width,
#: each through its points to `WALL_FIT` of its radius.
WALL_BINS = 8
WALL_SPAN_TRIM = 0.1
WALL_MIN_BINS = 3
WALL_CONCENTRIC = 0.02
WALL_FIT = 0.005
#: An end point of a turn further off the fitted circle than this fraction of the radius is a leg point, and it is
#: taken off before the radius is read (`_trimmed_fit`).
END_TRIM = 0.001


class Station(BaseModel):
    """One marched section. `area` and `hydraulic_diameter` are the passage's own, islands taken out."""
    s: float
    point: Vec3
    area: float
    hydraulic_diameter: float


class Bend(BaseModel):
    """One turn of the path. `status` is `measured` or `refused`, and a refused bend carries no radius.

    `radius` is the centreline's, `diameter` the passage's hydraulic diameter in the turn, `r_over_d` their
    ratio. `width_in_plane` is the passage's extent along the radius of the turn, which is the dimension a
    rectangular elbow turns across, and `inner_radius` is the radius of the inside of the turn: `radius -
    width_in_plane / 2`, and zero or less is a sharp inside corner."""
    status: Literal["measured", "refused"]
    why: str = ""
    turn_deg: float
    stations: int
    s_start: float
    s_end: float
    mid_point: Vec3
    radius: float | None = None
    diameter: float | None = None
    r_over_d: float | None = None
    width_in_plane: float | None = None
    r_over_width: float | None = None
    inner_radius: float | None = None
    inner_point: Vec3 | None = None
    centre: Vec3 | None = None
    plane_normal: Vec3 | None = None
    arc_residual: float | None = None
    plane_residual: float | None = None
    #: The radius read off the WALL's own vertices, which lie on the true surface: the mean of circles fitted to
    #: the innermost and outermost wall points across the turn. The cross-check `radius` must agree with.
    wall_radius: float | None = None
    #: The radius the section centroids fitted, kept beside the one stated.
    centroid_radius: float | None = None
    #: Where `radius` came from: `wall`, the inner and outer walls fitted as concentric arcs through surface
    #: vertices, which is the only source a radius is stated from.
    radius_from: str = ""
    #: Why the radius was refused, as a code: `too_few_stations`, `junction` (not a bend at all: the path crossed
    #: a junction), `no_fit`, `not_planar`, `not_circular`, `no_wall_points`, `wall_disagrees`, `truncated`.
    refused_by: str = ""


class Intrusion(BaseModel):
    """Surface standing inside the passage BETWEEN two marched stations: a plate, a baffle, a rod, the face of an
    inward step. Found by the vertices and not by the stations, because an orifice plate three hundredths of a
    diameter thick falls between two stations a fifth of a diameter apart and no station cut ever sees it.

    `open_area` is the passage in the plane through the intrusion, `open_fraction` that over the section before
    it, `islands` the loops standing free inside the passage in that plane (a rod, a strut, a tube), and
    `recovers` whether the station after it is back within `RECOVER` of the one before. `open_area` is zero
    when the plane through the intrusion encloses no passage at the centreline point: something covers the
    middle of the passage there."""
    s: float
    point: Vec3
    open_area: float
    open_fraction: float
    islands: int = 0
    recovers: bool


class Centreline(BaseModel):
    """The path marched in from one mouth, the bends on it, and what ended it.

    `status` is `refused` when no path could be followed at all, with `why`. `stopped_by` is one of
    `left_the_passage` (the cut found no passage enclosing the point: a mouth, a closed end, or a wall),
    `opens_into_chamber`, `sidestep` (a second passage merged into the section), `turned_back`, `max_reach`,
    `budget` (the coverage time budget ran out mid-passage; nothing past it is claimed).
    `reached_opening` is the mouth the march came out at, when it stopped within a diameter of one.
    `straight` is True only when the whole marched length turned by less than `MIN_TURN_DEG`: it is a
    measured absence of a bend over `length`, never a claim about the passage beyond it."""
    opening_id: str
    status: Literal["measured", "refused"]
    why: str = ""
    stopped_by: str = ""
    reached_opening: str | None = None
    length: float = 0.0
    mouth_diameter: float = 0.0
    turn_deg: float = 0.0
    straight: bool | None = None
    bends: list[Bend] = Field(default_factory=list)
    stations: list[Station] = Field(default_factory=list)
    #: At a stop that met something (a chamber, a second passage), the section just past it over the one before.
    stop_area_ratio: float | None = None
    stop_point: Vec3 | None = None
    intrusions: list[Intrusion] = Field(default_factory=list)


# ---------------------------------------------------------------------------------------------------------------
# one cut
# ---------------------------------------------------------------------------------------------------------------

@dataclass
class _Body:
    """One region's triangles, with per-face bounding boxes so a cut only reads the faces near it."""
    v: np.ndarray
    f: np.ndarray
    lo: np.ndarray
    hi: np.ndarray
    tol: float

    @classmethod
    def of(cls, mesh) -> _Body:
        v = np.asarray(mesh.vertices, dtype=np.float64)
        f = np.asarray(mesh.faces, dtype=np.int64)
        tri = v[f]
        ext = float(np.linalg.norm(v.max(axis=0) - v.min(axis=0))) if len(v) else 1.0
        return cls(v=v, f=f, lo=tri.min(axis=1), hi=tri.max(axis=1), tol=1e-6 * ext + 1e-12)


@dataclass
class _Section:
    area: float
    centroid: np.ndarray
    perimeter: float
    #: the passage's outer boundary as a soup of segments, (m, 2, 3): what `_intrusions` and `_width_along` read
    segs: np.ndarray
    loops: int = 1


def _slice(body: _Body, origin: np.ndarray, normal: np.ndarray,
           reach: float | None) -> np.ndarray:
    """Where the plane crosses the triangles near `origin`: segments `(m, 2, 3)`, each ORIENTED so the material
    is on its left seen from +normal (direction `normal x face normal`).

    `render.plane_segments`' rule for a triangle the plane crosses, with each segment turned the way its face
    points, because that orientation is what lets a loop's area and centroid be summed straight off the
    segments (Green's theorem) without chaining them into an ordered polygon first. Chaining was two thirds of
    the march's time."""
    n = np.asarray(normal, dtype=np.float64)
    n = n / (np.linalg.norm(n) or 1.0)
    if reach is None:
        f = body.f
    else:
        f = body.f[np.all((body.lo <= origin + reach) & (body.hi >= origin - reach), axis=1)]
    if not len(f):
        return np.zeros((0, 2, 3))
    tri_v = body.v[f]
    sd = (tri_v - origin) @ n
    scale = float(np.max(np.abs(sd))) or 1.0
    sd = np.where(np.abs(sd) < 1e-12 * scale, 1e-12 * scale, sd)
    pos = sd > 0
    k = pos.sum(axis=1)
    hit = np.flatnonzero((k == 1) | (k == 2))
    if not len(hit):
        return np.zeros((0, 2, 3))
    tv, ts, tp = tri_v[hit], sd[hit], pos[hit]
    rows = np.arange(len(hit))
    odd = np.where(tp.sum(axis=1) >= 2, np.argmin(tp, axis=1), np.argmax(tp, axis=1))
    v0, s0 = tv[rows, odd], ts[rows, odd]
    ends = []
    for step in (1, 2):
        kk = (odd + step) % 3
        v1, s1 = tv[rows, kk], ts[rows, kk]
        ends.append(v0 + (v1 - v0) * (s0 / (s0 - s1))[:, None])
    segs = np.stack(ends, axis=1)
    fn = np.cross(tv[:, 1] - tv[:, 0], tv[:, 2] - tv[:, 0])
    want = np.cross(n, fn)
    flip = np.einsum("ij,ij->i", segs[:, 1] - segs[:, 0], want) < 0
    segs[flip] = segs[flip][:, ::-1]
    return segs


@dataclass
class _Loops:
    """The closed loops of one cut, summed straight off oriented segments."""
    area: np.ndarray        # |signed area| per loop, 0 for an open chain
    centroid: np.ndarray    # (k, 3)
    perimeter: np.ndarray
    encloses: np.ndarray    # whether the loop encloses the cut's origin
    seg_loop: np.ndarray    # loop index per kept segment (-1: an open chain)
    segs: np.ndarray


def _loops(body: _Body, origin: np.ndarray, normal: np.ndarray, reach: float | None) -> _Loops | None:
    """Every closed loop of one cut. A loop is closed when each of its points has exactly one segment in and
    one out; a corridor-truncated chain, or a face wound against its neighbours, fails that and is not a loop."""
    from scipy.sparse import coo_matrix
    from scipy.sparse.csgraph import connected_components

    from geometry_agent.facts.stubs import _plane_basis
    segs = _slice(body, origin, normal, reach)
    if not len(segs):
        return None
    key = np.round(segs.reshape(-1, 3) / body.tol).astype(np.int64)
    _, inv = np.unique(key, axis=0, return_inverse=True)
    ids = inv.reshape(-1, 2)
    keep = ids[:, 0] != ids[:, 1]
    segs, ids = segs[keep], ids[keep]
    if not len(segs):
        return None
    nid = int(ids.max()) + 1
    g = coo_matrix((np.ones(len(ids)), (ids[:, 0], ids[:, 1])), shape=(nid, nid))
    ncomp, lab = connected_components(g, directed=False)
    comp = lab[ids[:, 0]]
    outd = np.bincount(ids[:, 0], minlength=nid)
    ind = np.bincount(ids[:, 1], minlength=nid)
    bad = np.bincount(lab[(outd != 1) | (ind != 1)], minlength=ncomp) > 0
    u, w = _plane_basis(normal)
    rel0, rel1 = segs[:, 0] - origin, segs[:, 1] - origin
    x0, y0, x1, y1 = rel0 @ u, rel0 @ w, rel1 @ u, rel1 @ w
    cross = x0 * y1 - x1 * y0
    area = 0.5 * np.bincount(comp, weights=cross, minlength=ncomp)
    cx = np.bincount(comp, weights=(x0 + x1) * cross, minlength=ncomp)
    cy = np.bincount(comp, weights=(y0 + y1) * cross, minlength=ncomp)
    length = np.bincount(comp, weights=np.hypot(x1 - x0, y1 - y0), minlength=ncomp)
    crosses = (y0 > 0) != (y1 > 0)
    with np.errstate(divide="ignore", invalid="ignore"):
        xi = x0 + (0.0 - y0) * (x1 - x0) / (y1 - y0)
    hits = np.bincount(comp, weights=(crosses & (xi > 0)).astype(float), minlength=ncomp)
    ok = (~bad) & (np.abs(area) > 0)
    safe = np.where(np.abs(area) > 0, area, 1.0)
    centroid = (origin + (cx / (6.0 * safe))[:, None] * u + (cy / (6.0 * safe))[:, None] * w)
    return _Loops(area=np.where(ok, np.abs(area), 0.0), centroid=centroid, perimeter=length,
                  encloses=ok & (hits % 2 == 1), seg_loop=np.where(ok[comp], comp, -1), segs=segs)


def _passage(body: _Body, origin: np.ndarray, normal: np.ndarray, reach: float | None) -> _Section | None:
    """The passage the point is in: the innermost closed loop enclosing it, less the loops inside that one
    which do not enclose it (a rod, a hub). None when no loop encloses the point."""
    from geometry_agent.facts.stubs import _plane_basis
    lp = _loops(body, origin, normal, reach)
    if lp is None or not lp.encloses.any():
        return None
    around = np.flatnonzero(lp.encloses)
    outer = int(around[np.argmin(lp.area[around])])
    outer_segs = lp.segs[lp.seg_loop == outer]
    islands: list[int] = []
    if len(lp.area) > 1:
        u, w = _plane_basis(normal)
        edges = np.stack([np.column_stack([(outer_segs[:, j] - origin) @ u, (outer_segs[:, j] - origin) @ w])
                          for j in (0, 1)], axis=1)
        for k in range(len(lp.area)):
            if k == outer or lp.encloses[k] or lp.area[k] <= 0 or lp.area[k] >= lp.area[outer]:
                continue
            c = lp.centroid[k] - origin
            if _inside_edges(edges, np.array([[float(c @ u), float(c @ w)]]), 0.0)[0]:
                islands.append(k)
    area = float(lp.area[outer] - sum(lp.area[k] for k in islands))
    if area <= 0:
        return None
    moment = lp.area[outer] * lp.centroid[outer] - sum((lp.area[k] * lp.centroid[k] for k in islands),
                                                       np.zeros(3))
    perimeter = float(lp.perimeter[outer] + sum(lp.perimeter[k] for k in islands))
    return _Section(area=area, centroid=moment / area, perimeter=perimeter, segs=outer_segs,
                    loops=1 + len(islands))


def _inside_edges(edges: np.ndarray, q: np.ndarray, margin: float) -> np.ndarray:
    """Which 2D points lie inside a closed boundary given as unordered edges `(m, 2, 2)`, by more than
    `margin` from it: parity of crossings along +x, then the distance to the nearest edge."""
    x, y = edges[:, 0, 0][None, :], edges[:, 0, 1][None, :]
    x2, y2 = edges[:, 1, 0][None, :], edges[:, 1, 1][None, :]
    px, py = q[:, 0][:, None], q[:, 1][:, None]
    crossing = (y > py) != (y2 > py)
    with np.errstate(divide="ignore", invalid="ignore"):
        xi = x + (py - y) * (x2 - x) / (y2 - y)
    inside = (np.sum(crossing & (px < xi), axis=1) % 2) == 1
    if margin <= 0 or not inside.any():
        return inside
    ex, ey = x2 - x, y2 - y
    ll = ex * ex + ey * ey
    with np.errstate(divide="ignore", invalid="ignore"):
        tt = np.clip(((px - x) * ex + (py - y) * ey) / np.where(ll > 0, ll, 1.0), 0.0, 1.0)
    dist = np.hypot(px - (x + tt * ex), py - (y + tt * ey)).min(axis=1)
    return inside & (dist > margin)


def _cut(body: _Body, origin: np.ndarray, normal: np.ndarray, d: float) -> _Section | None:
    sec = _passage(body, origin, normal, REACH_OVER_D * d)
    if sec is None:
        sec = _passage(body, origin, normal, None)
    return sec


def _across(body: _Body, point: np.ndarray, t: np.ndarray, d: float) -> tuple[_Section, np.ndarray] | None:
    """The section through `point` that is ACROSS the passage: the plane of least section area, found from `t`.

    WHY THE LEAST AREA AND NOT THE PATH'S OWN CHORDS. The first version took the tangent from the chord between
    two marched centroids and extrapolated it by half a step, which is exact on a bend and unstable on a cone:
    tilt a cut across a cone of half-angle a and its centroid slides sideways by about r tan a times the tilt,
    so the next chord tilts by that over the step, and the extrapolation doubles it. On a reducer of 28 degrees
    included angle the tilt grew 0.004, 0.007, 0.01, 0.03, 0.07 radians and the march lost the bore at the cone
    on 42 of 72 reducer marches. The least-area plane does not read the centroids at all. Through a point on a
    cylinder, a cone or a torus it is the plane across the axis (an oblique cut of a cylinder is A / cos(tilt),
    of a cone symmetric in the tilt, of a torus smallest in the plane holding the torus axis), so it is right on
    all three and nothing feeds back.

    Found by a parabola through the area at the current normal and at a tilt of `TILT_RAD` either way about two
    axes across it, taken twice at a third of the tilt the second time. A tilted cut that meets nothing or
    jumps in area (a step, a mouth) leaves that axis alone, and so does a curve that is not a minimum."""
    from geometry_agent.facts.stubs import _plane_basis
    base = _cut(body, point, t, d)
    if base is None:
        return None
    n = _unit(np.asarray(t, dtype=np.float64))
    for delta in (TILT_RAD, TILT_RAD / 3.0):
        u, w = _plane_basis(n)
        offsets = []
        for axis in (u, w):
            areas = []
            for sgn in (-1.0, 1.0):
                sec = _cut(body, point, _unit(n + sgn * delta * axis), d)
                if sec is None or abs(sec.area / base.area - 1.0) > 0.3:
                    break
                areas.append(sec.area)
            if len(areas) < 2:
                offsets.append(0.0)
                continue
            curv = areas[0] - 2.0 * base.area + areas[1]
            offsets.append(float(np.clip(delta * (areas[0] - areas[1]) / (2.0 * curv), -2 * delta, 2 * delta))
                           if curv > 0 else 0.0)
        if not any(offsets):
            break
        trial = _unit(n + offsets[0] * u + offsets[1] * w)
        sec = _cut(body, point, trial, d)
        if sec is None or abs(sec.area / base.area - 1.0) > 0.3 or sec.area > base.area * (1.0 + 1e-9):
            break
        base, n = sec, trial
        # the finer pass is only worth its four cuts where the first one actually turned the plane
        if max(abs(o) for o in offsets) < 0.25 * delta:
            break
    return base, n


def _area_back(stations: list[Station], s_now: float, window: float) -> float:
    """The passage area at the station nearest `window` behind `s_now`, or the first station's."""
    target = s_now - window
    best = stations[0]
    for st in stations:
        if st.s <= target:
            best = st
        else:
            break
    return best.area


def _wide_both_ways(sec: _Section, normal: np.ndarray, d: float) -> bool:
    """Whether a section is a chamber's: wider than `CHAMBER_MINOR` diameters along its narrow principal axis,
    and no more than `CHAMBER_ASPECT` times longer one way than the other."""
    from geometry_agent.facts.stubs import _plane_basis
    pts = sec.segs.reshape(-1, 3) - sec.centroid
    if len(pts) < 3:
        return False
    u, w = _plane_basis(normal)
    xy = np.column_stack([pts @ u, pts @ w])
    try:
        _, _, vt = np.linalg.svd(xy - xy.mean(axis=0), full_matrices=False)
    except np.linalg.LinAlgError:
        return False
    major = float(np.ptp(xy @ vt[0]))
    minor = float(np.ptp(xy @ vt[-1]))
    return minor >= CHAMBER_MINOR * d and major <= CHAMBER_ASPECT * max(minor, 1e-12)


def _unit(v: np.ndarray) -> np.ndarray:
    n = float(np.linalg.norm(v))
    return v / n if n > 0 else v


def _angle_deg(a: np.ndarray, b: np.ndarray) -> float:
    return float(np.degrees(np.arccos(np.clip(float(_unit(a) @ _unit(b)), -1.0, 1.0))))


# ---------------------------------------------------------------------------------------------------------------
# the march
# ---------------------------------------------------------------------------------------------------------------

def _mouth_diameter(opening) -> float:
    bore = getattr(opening, "bore_diameter", None)
    if getattr(opening, "kind", "") == "ring" and bore:
        return float(bore)
    return float(opening.hydraulic_diameter or 0.0)


def _mouth_area(opening) -> float:
    bore = getattr(opening, "bore_area", None)
    if getattr(opening, "kind", "") == "ring":
        if bore:
            return float(bore)
        d = _mouth_diameter(opening)
        return float(np.pi * d * d / 4.0)
    return float(opening.area or 0.0)


def march(mesh, opening, inward: np.ndarray | None = None, others: list | None = None,
          body: _Body | None = None, deadline: float | None = None) -> Centreline:
    """The centreline in from one mouth. `inward` is the mouth's measured inward direction (`Stub.
    inward_direction`); without it the stub march's own test is used. `others` are the other openings, so the
    march can say which mouth it came out at."""
    oid = str(opening.id)
    d0 = _mouth_diameter(opening)
    a0 = _mouth_area(opening)
    if d0 <= 0 or a0 <= 0:
        return Centreline(opening_id=oid, status="refused", why="the mouth has no diameter")
    body = body or _Body.of(mesh)
    if inward is None:
        from geometry_agent.facts.stubs import _inward
        inward = _inward(mesh, opening)
    t = _unit(np.asarray(inward, dtype=np.float64))
    c0 = np.asarray(opening.centroid, dtype=np.float64)
    first = _cut(body, c0 + FIRST_OVER_D * d0 * t, t, d0)
    if first is None:
        return Centreline(opening_id=oid, status="refused", mouth_diameter=d0,
                          why="no closed section encloses the mouth's centre just inside it")
    if not (ENTRY_AREA_BAND[0] <= first.area / a0 <= ENTRY_AREA_BAND[1]):
        return Centreline(opening_id=oid, status="refused", mouth_diameter=d0,
                          why=(f"the section enclosing the mouth's centre is {first.area / a0:.2f} of the mouth's "
                               "own passage area, so the centre is not inside its own passage (an annulus, or a "
                               "mouth whose face is not across the passage)"))
    p = first.centroid
    stations = [Station(s=0.0, point=_vec(p), area=first.area, hydraulic_diameter=_dh(first))]
    loops: list[np.ndarray] = [first.segs]
    tangents: list[np.ndarray] = [t]
    peak = first.area
    prev = first
    s = 0.0
    stopped = "max_reach"
    stop_ratio: float | None = None
    stop_point: np.ndarray | None = None
    h = STEP_OVER_D * _dh(first)
    while len(stations) < MAX_STATIONS and s < MAX_OVER_D * d0:
        if deadline is not None and time.perf_counter() > deadline:
            # out of time mid-passage: what was marched is kept, and a turn reaching here is cut short
            stopped = "budget"
            break
        d = max(_dh(prev), 1e-12)
        h = min(h, STEP_OVER_D * d)
        fine_enough = h <= MIN_STEP_OVER_D * d
        guess = p + h * t
        found = _across(body, guess, t, d)
        if found is None:
            if not fine_enough:
                h *= 0.5
                continue
            stopped = "left_the_passage"
            break
        sec, cut_normal = found
        chord = _unit(sec.centroid - p)
        turn = _angle_deg(cut_normal, t)
        if turn > MAX_TURN_PER_STEP_DEG and not fine_enough:
            # a turn this fast in one step: take a shorter step where the path bends
            h *= 0.5
            continue
        if float(chord @ t) <= 0 or turn > MAX_STEP_TURN_DEG:
            stopped = "turned_back"
            break
        side = float(np.linalg.norm((sec.centroid - guess) - float((sec.centroid - guess) @ t) * t))
        # THE SECTION A CHAMBER IS MEASURED AGAINST: the one half a diameter back, not the last one. A stub
        # running into a spherical housing grows 1.7, 2.3, 1.7 times a station through the fillet and never 2.5
        # in one step, so a one-step test marched on through every housing and out of the far side of it
        ref = _area_back(stations, s + float(np.linalg.norm(sec.centroid - p)), CHAMBER_WINDOW_OVER_D * d)
        chamber = sec.area > CHAMBER_RATIO * min(peak, ref)
        sidestep = side > SIDESTEP_OVER_D * d and sec.area > 1.2 * prev.area
        if (chamber or sidestep) and not fine_enough:
            # confirmed at the shortest step before it is believed: in a turn tighter than one diameter a long
            # step's plane reaches past the inside of the bend and reads a chamber that is not there
            h *= 0.5
            continue
        if chamber or sidestep:
            wide = _wide_both_ways(sec, cut_normal, d)
            if not wide:
                # half a diameter further on: a stub entering a filleted box meets the fillet first, which is
                # large one way only, and the box itself a step later
                ahead = _cut(body, sec.centroid + CHAMBER_WINDOW_OVER_D * d * t, t, d)
                if ahead is not None and ahead.area > CHAMBER_RATIO * ref and _wide_both_ways(ahead, t, d):
                    sec, wide = ahead, True
            if wide:
                # a space wide both ways across the plane: the passage has opened into a chamber, whether the
                # centroid jumped sideways doing it (a stub entering a plenum near its wall) or not
                stopped, stop_ratio, stop_point = "opens_into_chamber", sec.area / ref, sec.centroid
            elif sidestep:
                stopped, stop_ratio, stop_point = "sidestep", sec.area / prev.area, sec.centroid
            else:
                # large in one direction only: an oblique cut through a turn tighter than the march can follow,
                # a mitre, or a run crossing the passage, all of which read as a chamber by area alone
                stopped = "turned_back"
            break
        s += float(np.linalg.norm(sec.centroid - p))
        p = sec.centroid
        t = cut_normal
        stations.append(Station(s=s, point=_vec(p), area=sec.area, hydraulic_diameter=_dh(sec)))
        loops.append(sec.segs)
        tangents.append(cut_normal)
        peak = max(peak, sec.area)
        prev = sec
        h *= 1.5
    if stopped == "turned_back" and len(stations) > 2 and abs(stations[-1].area / stations[-2].area - 1.0) > 0.1:
        # the station accepted just before the march lost the passage is usually the first one off it: an
        # oblique cut, larger than its neighbour. It is not kept as a point on the path.
        stations.pop()
        loops.pop()
        tangents.pop()
        s = stations[-1].s
    if stopped == "turned_back":
        stop_point = np.asarray(stations[-1].point, dtype=np.float64)
    reached = _reached(stations[-1].point, others or [], oid, d0) if stopped == "left_the_passage" else None
    line = Centreline(opening_id=oid, status="measured", stopped_by=stopped, reached_opening=reached,
                      length=s, mouth_diameter=d0, stations=stations,
                      stop_area_ratio=stop_ratio, stop_point=_vec(stop_point) if stop_point is not None else None)
    _read_bends(line, body)
    line.intrusions = _intrusions(line, body, loops, tangents)
    return line


def _intrusions(line: Centreline, body: _Body, loops: list[np.ndarray],
                tangents: list[np.ndarray]) -> list[Intrusion]:
    """Every segment between two stations that has surface standing inside the passage, cut through and read."""
    from geometry_agent.facts.stubs import _plane_basis
    st = line.stations
    out: list[Intrusion] = []
    for k in range(len(st) - 1):
        p0, p1 = np.asarray(st[k].point), np.asarray(st[k + 1].point)
        axis = p1 - p0
        h = float(np.linalg.norm(axis))
        if h <= 0:
            continue
        t = axis / h
        d = st[k].hydraulic_diameter
        mid = 0.5 * (p0 + p1)
        reach = 0.5 * h + d
        near = np.all((body.lo <= mid + reach) & (body.hi >= mid - reach), axis=1)
        if not near.any():
            continue
        vi = np.unique(body.f[near].ravel())
        rel = body.v[vi] - p0
        tau = rel @ t / h
        keep = (tau > 0.02) & (tau < 0.98)
        if not keep.any():
            continue
        # inside BOTH stations' sections, each in its own plane. One is not enough in a bend: the outer wall
        # between two stations projects inside the earlier section by (R + r)(1 - cos(h / R)), which is 0.044 D
        # at R/D 0.75, and inside the later one by the same from the other side; a plate is inside both
        inside = np.ones(int(keep.sum()), dtype=bool)
        for j, origin in ((k, p0), (k + 1, p1)):
            u, w = _plane_basis(tangents[j])
            edges = np.stack([np.column_stack([(loops[j][:, e] - origin) @ u, (loops[j][:, e] - origin) @ w])
                              for e in (0, 1)], axis=1)
            rel_j = body.v[vi][keep] - origin
            lat = rel_j - np.outer(rel_j @ tangents[j], tangents[j])
            inside &= _inside_edges(edges, np.column_stack([lat @ u, lat @ w]), INTRUDE_OVER_D * d)
            if not inside.any():
                break
        if not inside.any():
            continue
        at = float(np.median(tau[keep][inside]))
        centre = p0 + at * h * t
        opens = [_cut(body, centre + sgn * INTRUSION_NUDGE * d * t, t, d) for sgn in (-1.0, 1.0)]
        areas = [o.area for o in opens if o is not None]
        open_area = min(areas) if len(areas) == 2 else 0.0
        islands = max((o.loops - 1 for o in opens if o is not None), default=0)
        before = st[k].area
        after = st[k + 1].area
        out.append(Intrusion(s=float(st[k].s + at * h), point=_vec(centre), open_area=float(open_area),
                             open_fraction=float(open_area / before) if before > 0 else 0.0, islands=int(islands),
                             recovers=bool(abs(after / before - 1.0) <= RECOVER) if before > 0 else False))
    return out


def _dh(sec: _Section) -> float:
    return 4.0 * sec.area / sec.perimeter if sec.perimeter > 0 else 2.0 * float(np.sqrt(sec.area / np.pi))


def _vec(p: np.ndarray | None) -> Vec3:
    return (float(p[0]), float(p[1]), float(p[2]))


def _reached(point: Vec3, others: list, oid: str, d0: float) -> str | None:
    p = np.asarray(point, dtype=np.float64)
    best, best_d = None, np.inf
    for o in others:
        if str(o.id) == oid:
            continue
        dist = float(np.linalg.norm(np.asarray(o.centroid, dtype=np.float64) - p))
        if dist < best_d:
            best, best_d = str(o.id), dist
    return best if best is not None and best_d <= max(d0, _mouth_diameter_any(others, best)) else None


def _mouth_diameter_any(others: list, oid: str | None) -> float:
    for o in others:
        if str(o.id) == oid:
            return _mouth_diameter(o)
    return 0.0


# ---------------------------------------------------------------------------------------------------------------
# the bends
# ---------------------------------------------------------------------------------------------------------------

def _tangents(pts: np.ndarray) -> np.ndarray:
    n = len(pts)
    t = np.zeros_like(pts)
    for i in range(n):
        a, b = max(i - 1, 0), min(i + 1, n - 1)
        t[i] = _unit(pts[b] - pts[a])
    return t


def fit_circle_3d(pts: np.ndarray) -> dict[str, Any] | None:
    """A circle through 3D points: plane by SVD, algebraic (Kasa) fit in it, then Gauss-Newton on the geometric
    distance. Returns centre, radius, the plane normal, and both RMS residuals over the radius."""
    pts = np.asarray(pts, dtype=np.float64)
    if len(pts) < 3:
        return None
    mean = pts.mean(axis=0)
    rel = pts - mean
    try:
        _, sv, vt = np.linalg.svd(rel, full_matrices=False)
    except np.linalg.LinAlgError:
        return None
    normal = vt[2]
    e1, e2 = vt[0], vt[1]
    x, y = rel @ e1, rel @ e2
    plane_rms = float(np.sqrt(np.mean((rel @ normal) ** 2)))
    a = np.column_stack([x, y, np.ones_like(x)])
    rhs = x * x + y * y
    try:
        sol, *_ = np.linalg.lstsq(a, rhs, rcond=None)
    except np.linalg.LinAlgError:
        return None
    cx, cy = sol[0] / 2.0, sol[1] / 2.0
    r = float(np.sqrt(max(sol[2] + cx * cx + cy * cy, 0.0)))
    if not np.isfinite(r) or r <= 0:
        return None
    for _ in range(20):
        dx, dy = x - cx, y - cy
        dist = np.sqrt(dx * dx + dy * dy)
        if np.any(dist <= 0):
            break
        res = dist - r
        jac = np.column_stack([-dx / dist, -dy / dist, -np.ones_like(dist)])
        try:
            step, *_ = np.linalg.lstsq(jac, -res, rcond=None)
        except np.linalg.LinAlgError:
            break
        cx, cy, r = cx + step[0], cy + step[1], r + step[2]
        if float(np.abs(step).max()) < 1e-12 * max(r, 1.0):
            break
    if not np.isfinite(r) or r <= 0:
        return None
    arc_rms = float(np.sqrt(np.mean((np.hypot(x - cx, y - cy) - r) ** 2)))
    centre = mean + cx * e1 + cy * e2
    return {"centre": centre, "radius": float(r), "normal": normal,
            "arc_residual": arc_rms / r, "plane_residual": plane_rms / r}


def _trimmed_fit(pts: np.ndarray, idx: list[int]) -> tuple[dict[str, Any] | None, list[int]]:
    """The circle through a turn, with the straight leg taken back off each end.

    The turn is found by where the tangent turns, and a central-difference tangent turns one station early and
    one late, so the first and last points of a turn are often on the legs. A leg point pulls the circle wide:
    on a torus of R/D 1 it read 1.088 with them and reads within a per cent without. An end point is dropped
    while it sits further off the circle than `END_TRIM` of the radius and than twice the median point, and
    never below `MIN_BEND_STATIONS`. Only ends are dropped, so a spiral or a mitre still fails the residual."""
    idx = list(idx)
    fit = fit_circle_3d(pts[idx])
    while fit is not None and len(idx) > MIN_BEND_STATIONS:
        res = np.abs(np.linalg.norm(pts[idx] - fit["centre"], axis=1) - fit["radius"]) / fit["radius"]
        first, last = float(res[0]), float(res[-1])
        worst = max(first, last)
        if worst <= END_TRIM or worst <= 2.0 * float(np.median(res)):
            break
        idx = idx[1:] if first >= last else idx[:-1]
        fit = fit_circle_3d(pts[idx])
    return fit, idx


def _read_bends(line: Centreline, body: _Body) -> None:
    """Fill `bends`, `turn_deg` and `straight` from the marched points."""
    pts = np.array([st.point for st in line.stations], dtype=np.float64)
    if len(pts) < 3:
        line.straight = None
        return
    s = np.array([st.s for st in line.stations])
    dh = np.array([st.hydraulic_diameter for st in line.stations])
    area = np.array([st.area for st in line.stations])
    tan = _tangents(pts)
    k = min(2, len(pts) - 1)
    line.turn_deg = _angle_deg(tan[:k].mean(axis=0), tan[-k:].mean(axis=0))
    n = len(pts)
    curv = np.zeros(n)
    binorm = np.zeros((n, 3))
    for i in range(1, n - 1):
        ds = s[i + 1] - s[i - 1]
        if ds <= 0:
            continue
        curv[i] = np.radians(_angle_deg(tan[i - 1], tan[i + 1])) / ds * dh[i]
        binorm[i] = _unit(np.cross(tan[i - 1], tan[i + 1]))
    bent = curv >= MIN_CURVATURE_D
    runs: list[list[int]] = []
    for i in range(n):
        if not bent[i]:
            continue
        # stations a turn joins across: a faceted turn kinks at every facet and runs straight between, so its
        # curvature comes in bursts with flat stations between them. On `bend_elbow_013` (a 119 degree turn of a
        # 53 mm flat duct) every burst turned about five degrees and the turn was never seen at all
        joins = s[i] - s[runs[-1][-1]] <= RUN_JOIN_OVER_D * dh[i] if runs else False
        if runs and (i - runs[-1][-1] <= 2 or joins) and float(binorm[i] @ binorm[runs[-1][-1]]) > 0.5:
            runs[-1].extend(range(runs[-1][-1] + 1, i + 1))
        else:
            runs.append([i])
    bends: list[Bend] = []
    chords = np.array([_unit(pts[j + 1] - pts[j]) for j in range(n - 1)])
    extreme: int | None = None
    for k, run in enumerate(runs):
        a, b = max(run[0] - 1, 0), min(run[-1] + 1, n - 1)
        # THE TURN, off the chords between stations and not off central-difference tangents. A central difference
        # at an S-duct's inflection averages the two arcs and reads short of the extreme heading, which lost two
        # to five degrees of every S-duct arc. So the turn is the largest angle any chord reaches from the chord
        # where the turn starts, searched up to the next turn when there is no straight between them, and the
        # next turn starts from the chord that reached it.
        joined_before = k > 0 and run[0] - runs[k - 1][-1] <= 4
        joined_after = k + 1 < len(runs) and runs[k + 1][0] - run[-1] <= 4
        lc = extreme if (joined_before and extreme is not None) else max(run[0] - 2, 0)
        rc = min(runs[k + 1][0], n - 2) if joined_after else min(run[-1] + 1, n - 2)
        angles = [_angle_deg(chords[lc], chords[j]) for j in range(lc, rc + 1)]
        turn = max(angles) if angles else 0.0
        extreme = lc + int(np.argmax(angles)) if angles else None
        if turn < MIN_TURN_DEG:
            continue
        idx = list(range(a, b + 1))
        mid = idx[len(idx) // 2]
        bend = Bend(status="refused", turn_deg=turn, stations=len(idx), s_start=float(s[a]), s_end=float(s[b]),
                    mid_point=_vec(pts[mid]))
        if len(idx) < MIN_BEND_STATIONS:
            bend.refused_by = "too_few_stations"
            bend.why = (f"only {len(idx)} marched stations inside the turn, fewer than {MIN_BEND_STATIONS}: a mitre "
                        "or a turn tighter than the march can follow")
            bends.append(bend)
            continue
        jumps = [abs(area[i + 1] / area[i] - 1.0) for i in idx[:-1] if area[i] > 0]
        if jumps and max(jumps) > BEND_AREA_STEP:
            bend.refused_by = "junction"
            bend.why = (f"the section changes size by {max(jumps):.0%} between two stations inside the turn: the "
                        "path is crossing a junction or a fitting there, and that is not a bend")
            bends.append(bend)
            continue
        fit, idx = _trimmed_fit(pts, idx)
        mid = idx[len(idx) // 2]
        bend.stations, bend.mid_point = len(idx), _vec(pts[mid])
        bend.s_start, bend.s_end = float(s[idx[0]]), float(s[idx[-1]])
        if fit is None:
            bend.refused_by = "no_fit"
            bend.why = "no circle could be fitted to the turn"
            bends.append(bend)
            continue
        bend.arc_residual = round(fit["arc_residual"], 5)
        bend.plane_residual = round(fit["plane_residual"], 5)
        if fit["plane_residual"] > MAX_PLANE_RESIDUAL:
            bend.refused_by = "not_planar"
            bend.why = (f"the turn is not in one plane (off it by {fit['plane_residual']:.3f} of the radius): a "
                        "twisted or spiral path has no single bend radius")
            bends.append(bend)
            continue
        if fit["arc_residual"] > MAX_ARC_RESIDUAL:
            bend.refused_by = "not_circular"
            bend.why = (f"the turn is not a circular arc (off the best circle by {fit['arc_residual']:.3f} of the "
                        "radius): a spiral, or two turns run together")
            bends.append(bend)
            continue
        r = fit["radius"]
        dmid = float(np.median(dh[idx]))
        radial = _unit(pts[mid] - fit["centre"])
        width = _width_along(body, pts[mid], tan[mid], radial, dmid)
        wall = _wall_radius(body, fit, pts[idx[0]], pts[idx[-1]], width or dmid)
        bend.centroid_radius = r
        if wall is None:
            bend.refused_by = "no_wall_points"
            bend.why = ("the wall has too few surface points inside the turn to check the radius against, so the "
                        "radius is not stated")
            bends.append(bend)
            continue
        bend.wall_radius = wall["radius"]
        if not wall["concentric"]:
            # NO INDEPENDENT CHECK EXISTS, so no radius. Where the section grows or morphs through the turn (an
            # S-duct diffusing, a reducing elbow) the walls are not concentric, and the one thing that could
            # check the centroids' circle is gone. Measured before this rule: the centroids stated 4 S-duct radii
            # at 1 to 3 per cent, and on `s_duct_010` agreed with a wall-midpoint circle at 495 against a true
            # 446. Two estimates that are both wrong can agree; only concentric walls through surface points
            # are exact, so only those are stated.
            bend.refused_by = "wall_disagrees"
            bend.why = (f"the walls are not concentric arcs through the turn (the section changes, or the "
                        f"tessellation draws the turn too coarsely), so the centroids' radius of {r:.4g} has "
                        "nothing independent to check it against and is not stated")
            bends.append(bend)
            continue
        # the two walls are concentric arcs through points ON the surface: that is the turn's radius, and it
        # holds where a coarse tessellation has pulled the centroids off it
        r, bend.radius_from = wall["radius"], "wall"
        bend.status, bend.why = "measured", ""
        bend.radius, bend.diameter = r, dmid
        bend.r_over_d = r / dmid if dmid > 0 else None
        bend.centre = _vec(fit["centre"])
        bend.plane_normal = _vec(fit["normal"])
        if width is not None:
            bend.width_in_plane = width
            bend.r_over_width = r / width if width > 0 else None
            bend.inner_radius = r - width / 2.0
            bend.inner_point = _vec(pts[mid] - radial * width / 2.0)
        bends.append(bend)
    if line.stopped_by in TRUNCATING_STOPS:
        # A TURN THE MARCH STOPPED INSIDE is not a measured turn. Measured on a torus of R/D 0.75: the march read
        # a sidestep in the middle of the bend, and the points before it fitted R/D 0.70 over 49 degrees of a
        # 90 degree turn, a confident wrong number on both. Any turn reaching the last stations of a march that
        # did not come out at a mouth is refused, radius and all; its turn angle is kept as a lower bound.
        for b in bends:
            if b.s_end >= s[max(0, n - 3)] and b.refused_by != "junction":
                b.status, b.radius, b.r_over_d, b.diameter = "refused", None, None, None
                b.width_in_plane = b.r_over_width = b.inner_radius = b.wall_radius = b.centroid_radius = None
                b.radius_from = ""
                b.inner_point = b.centre = b.plane_normal = None
                b.refused_by = "truncated"
                b.why = (f"the march stopped inside this turn ({line.stopped_by}), so the turn is only a lower "
                         "bound and its radius is not stated")
    line.bends = bends
    # `straight` is a measured absence of a turn over `length`, and a march that lost the passage has not
    # measured the passage it lost: it says nothing then, rather than straight
    line.straight = None if line.stopped_by in ("turned_back", "budget") else (not bends and line.turn_deg < MIN_TURN_DEG)


def _wall_radius(body: _Body, fit: dict[str, Any], first: np.ndarray, last: np.ndarray,
                 width: float) -> dict[str, Any] | None:
    """THE CROSS-CHECK: the turn's radius read off the wall instead of off the section centroids.

    A tessellation's VERTICES lie on the true surface. Its facets do not, and a turn drawn with three or four flat
    facets has section centroids that follow the facets: on `bend_elbow_015` (176 triangles, a 40 degree
    rectangular turn) the centroids sat on a circle to half a per cent and that circle's radius was 30 per cent
    too large. So the innermost and the outermost wall vertex in each of `WALL_BINS` slices across the turn are
    taken (the inner and outer walls of the turn, at whatever height the vertices happen to be), a circle is
    fitted to each, and their mean is the wall's radius for the centreline. `concentric` says the two circles
    share a centre to `WALL_CONCENTRIC` of the width and each passes through its points to `WALL_FIT` of its
    radius: a bend of constant section. None when fewer than `WALL_MIN_BINS` slices hold a vertex on either side:
    there is then nothing to check the radius against."""
    c = np.asarray(fit["centre"], dtype=np.float64)
    n = _unit(np.asarray(fit["normal"], dtype=np.float64))
    e1 = _unit((first - c) - float((first - c) @ n) * n)
    e2 = np.cross(n, e1)
    span = float(np.arctan2(float((last - c) @ e2), float((last - c) @ e1)))
    if abs(span) < 1e-6:
        return None
    r = float(fit["radius"])
    rel = body.v - c
    h = rel @ n
    x, y = rel @ e1, rel @ e2
    rho = np.hypot(x, y)
    ang = np.arctan2(y, x) * np.sign(span)
    lo, hi = WALL_SPAN_TRIM * abs(span), (1.0 - WALL_SPAN_TRIM) * abs(span)
    keep = (ang >= lo) & (ang <= hi) & (np.abs(h) <= width) & (np.abs(rho - r) <= width)
    if not keep.any():
        return None
    xs, ys, rs, an = x[keep], y[keep], rho[keep], ang[keep]
    edges = np.linspace(lo, hi, WALL_BINS + 1)
    which = np.clip(np.searchsorted(edges, an, side="right") - 1, 0, WALL_BINS - 1)
    inner, outer = [], []
    for b in range(WALL_BINS):
        sel = np.flatnonzero(which == b)
        if not len(sel):
            continue
        i_in = sel[np.argmin(rs[sel])]
        i_out = sel[np.argmax(rs[sel])]
        if rs[i_in] < r:
            inner.append((xs[i_in], ys[i_in]))
        if rs[i_out] > r:
            outer.append((xs[i_out], ys[i_out]))
    if len(inner) < WALL_MIN_BINS or len(outer) < WALL_MIN_BINS:
        return None
    circles = []
    for side in (inner, outer):
        arr = np.asarray(side)
        circ = _circle_2d_fit(arr[:, 0], arr[:, 1])
        if circ is None:
            return None
        circles.append(circ)
    (ci, ri, resi), (co, ro, reso) = circles
    concentric = (float(np.linalg.norm(ci - co)) <= WALL_CONCENTRIC * width
                  and resi <= WALL_FIT and reso <= WALL_FIT)
    return {"radius": 0.5 * (ri + ro), "concentric": bool(concentric)}


def _circle_2d_fit(x: np.ndarray, y: np.ndarray) -> tuple[np.ndarray, float, float] | None:
    """`(centre, radius, rms residual over radius)` of the circle through planar points, algebraic fit."""
    a = np.column_stack([x, y, np.ones_like(x)])
    try:
        sol, *_ = np.linalg.lstsq(a, x * x + y * y, rcond=None)
    except np.linalg.LinAlgError:
        return None
    cx, cy = sol[0] / 2.0, sol[1] / 2.0
    r2 = sol[2] + cx * cx + cy * cy
    if not np.isfinite(r2) or r2 <= 0:
        return None
    r = float(np.sqrt(r2))
    res = float(np.sqrt(np.mean((np.hypot(x - cx, y - cy) - r) ** 2))) / r
    return np.array([cx, cy]), r, res


def _width_along(body: _Body, point: np.ndarray, tangent: np.ndarray, radial: np.ndarray, d: float) -> float | None:
    """The passage's extent along the radius of the turn, at one station: the section loop's span on the radial
    direction. None when the section cannot be cut there."""
    sec = _cut(body, point, tangent, d)
    if sec is None:
        return None
    along = (sec.segs.reshape(-1, 3) - sec.centroid) @ _unit(radial - float(radial @ tangent) * tangent)
    return float(along.max() - along.min())


# ---------------------------------------------------------------------------------------------------------------
# every mouth
# ---------------------------------------------------------------------------------------------------------------
#: Which openings are mouths a passage runs in from. A planar face on an external body or on the flat side of a
#: rectangular duct is not one, and marching across a duct's height from its side wall is not a path.
MOUTH_CLASSES = ("port_candidate", "ring")
#: At most this many mouths are marched, largest first, and the rest are named in `skipped`.
MAX_MOUTHS = 12


@dataclass
class Marches:
    lines: list[Centreline] = field(default_factory=list)
    skipped: list[str] = field(default_factory=list)


def march_all(mesh, facts, max_mouths: int = MAX_MOUTHS, keep_going=None,
              deadline: float | None = None) -> Marches:
    """One centreline per mouth, marched on the region the mouth belongs to. `keep_going()` may stop it early
    (a time budget); the mouths not marched are listed, never silently dropped."""
    from geometry_agent.facts.regions import region_meshes
    parts = region_meshes(mesh)
    bodies: dict[int, _Body] = {}
    mouths = [o for o in facts.openings if o.classification in MOUTH_CLASSES]
    mouths.sort(key=lambda o: -_mouth_area(o))
    out = Marches()
    inward = {s.opening_id: s.inward_direction for s in getattr(facts, "stubs", []) or []}
    for k, o in enumerate(mouths):
        if k >= max_mouths or (keep_going is not None and not keep_going()):
            out.skipped.append(str(o.id))
            continue
        idx = int(str(o.region_id)[1:]) - 1 if str(o.region_id).startswith("r") else -1
        part = parts[idx] if 0 <= idx < len(parts) else mesh
        body = bodies.get(idx)
        if body is None:
            body = bodies[idx] = _Body.of(part)
        way = inward.get(str(o.id))
        try:
            out.lines.append(march(part, o, np.asarray(way, dtype=np.float64) if way else None,
                                   others=list(facts.openings), body=body, deadline=deadline))
        except Exception as exc:  # noqa: BLE001 - a march that raises is a refusal, never a path
            out.lines.append(Centreline(opening_id=str(o.id), status="refused",
                                        why=f"{type(exc).__name__}: {exc}"[:160]))
    return out
