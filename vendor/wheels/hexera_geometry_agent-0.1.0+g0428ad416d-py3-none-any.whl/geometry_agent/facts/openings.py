"""Find where fluid could enter or leave: open rims on shells, planar caps on solid fluid volumes, rings on walls.

Candidate faces are coplanar facets, or patches of faces joined across smooth edges whose normals all lie within
one narrow cone (a curved B-spline inlet tessellates into several near-coplanar facets; a cylinder, cone, fillet or
dome spans too wide a cone and is not a candidate). A candidate is an opening when most of its outer boundary meets
a wall that turns well away from its plane. Thresholds, and why each value:

  MIN_AREA_FRACTION 2e-5    floor on a candidate's area as a fraction of ITS REGION's surface, not the file's: beside
                            a millimetre bracket every port of a metre-scale fluid body fell under a file-wide floor
  MIN_TUBULARITY 0.85       at least 85% of the outer boundary must be wall; open inner loops (flush holes) are not
                            boundary at all, they make the face a ring (they used to count against it)
  WALL_COS 0.45             a neighbour is a wall when its normal is 63 degrees or more off the face normal: the
                            23 degree cone at a nozzle exit (|dot| 0.39) is wall, which the old 0.35 (70 degrees)
                            refused; a hex prism's peer flats (60 degrees, |dot| 0.5) are not, so a nut's flats
                            are not caps; a 45 degree chamfer (0.71) is a band, judged by what lies beyond it
  SMOOTH_MERGE_DEG 15       adjacent faces within this dihedral angle belong to one patch
  CAP_NORMAL_CONE_DEG 35    every normal of a merged patch must lie within this angle of the patch mean: a 30 mm sag
                            over a 200 mm inlet tilts its edge normals 31 degrees; a 45 degree chamfer cone does not fit
  CHAMFER_BAND_OVER_D 0.25  an inclined band of neighbours narrower than a quarter diameter is an edge break (chamfer
                            or fillet); the faces one ring beyond it decide whether the rim meets a wall
  BAND_BEYOND_WALL_FRACTION 0.5  those faces are wall by a majority of their area
  RING_FILL_FRACTION 0.9    faces filling under 90% of their outer loop hide a hole behind a non-manifold seam: a ring
  MAX_ASPECT 10             an outer loop over 10:1 is a strip, not a port

Classification (classify_openings) says which caps are port candidates; its thresholds sit above it. What changed
and why: a facing twin no longer needs the march to have reached the end of the body (a nozzle root or a flush
hole stops the march on a plenum side); the core-span rule only fires on a body under SLAB_STUB_OVER_D deep along
the march (a pipe end always spans its own tube: the old raw-bbox span read a header's ends as sides); the flush
test is inclusive at 0.5 D, also holds against the face's width, and measures a boss by the shoulder ring it stands
on; a cap the budget left unmarched is a planar face; the area-fraction test is against the body's core surface.
"""
from __future__ import annotations

import numpy as np
import trimesh

from geometry_agent.facts.schema import Opening

MIN_AREA_FRACTION = 2e-5
MIN_TUBULARITY = 0.85
MAX_ASPECT = 10.0
WALL_COS = 0.45
SMOOTH_MERGE_DEG = 15.0
CAP_NORMAL_CONE_DEG = 35.0
#: A smooth component whose area-weighted normal sum keeps at least this fraction of its length has a dominant
#: direction worth peeling around when the whole component fails the cone (a cylinder's normals cancel; a domed
#: end that leaked into its bore does not).
PATCH_DIRECTION_MIN = 0.3
#: Peeling keeps only the faces within this angle of the dominant direction, tighter than the cone a patch must
#: fit: the chamfer or fillet the chain leaked through starts further out (a 35 degree chamfer straddles the 35
#: degree cone), and a curved inlet whose walls meet it at right angles never leaks, so it is never peeled.
PEEL_CONE_DEG = 20.0
#: A merged patch whose normals all lie within this angle of its mean is flat for the purpose of the chamfer walk
#: (a nut's slightly domed bearing face); a peeled fillet arc spans PEEL_CONE_DEG and is not.
NEARLY_PLANAR_DEG = 10.0
CHAMFER_BAND_OVER_D = 0.25
#: What lies beyond a band must be wall by more than this fraction of its area; a majority, because a chamfer
#: tessellated in two rows shows its second row (inclined) beside the wall behind it.
BAND_BEYOND_WALL_FRACTION = 0.5
#: Neighbours within 5 degrees of the candidate's plane are pieces of the same flat surface, not a band.
COPLANAR_COS = 0.996
#: The chamfer walk steps outward at most this many face rings; the band-width bound usually stops it sooner.
MAX_BAND_RINGS = 4
#: A planar candidate whose faces fill less than this fraction of its outer loop has a hole whose rim the face
#: adjacency cannot see (a non-manifold seam where another body meets it): it is a ring, not a cap. A simply
#: connected planar facet fills its loop exactly; a curved patch fills more than its projection.
RING_FILL_FRACTION = 0.9
#: A face lies on a side of its region's bounding box when its centroid is within this fraction of the region's
#: diagonal of that side and its normal is along that axis.
BBOX_SIDE_TOL_OF_DIAG = 0.01
_EDGE_TABLE_ATTR = "_geometry_agent_openings_open_edges"
#: Where planar_caps leaves its tubularity-gate counts (schema.OpeningGate) on the mesh.
GATE_META = "opening_gate"


def _loop_geometry(pts: np.ndarray) -> dict | None:
    if len(pts) < 3:
        return None
    if np.allclose(pts[0], pts[-1]):
        pts = pts[:-1]
    if len(pts) < 3:
        return None
    n = np.cross(pts, np.roll(pts, -1, axis=0)).sum(axis=0)
    area = float(np.linalg.norm(n) / 2)
    if area <= 0:
        return None
    normal = n / np.linalg.norm(n)
    centroid = pts.mean(axis=0)
    perimeter = float(np.sum(np.linalg.norm(np.roll(pts, -1, axis=0) - pts, axis=1)))
    to2d = trimesh.geometry.plane_transform(centroid, normal)
    p2 = trimesh.transform_points(pts, to2d)[:, :2]
    try:
        _, extents = trimesh.bounds.oriented_bounds_2D(p2)
        w, h = float(max(extents)), float(min(extents))
    except Exception:
        w = h = float(np.sqrt(area))
    circularity = 4 * np.pi * area / (perimeter**2) if perimeter > 0 else 0.0
    rect_fill = area / (w * h) if w * h > 0 else 0.0
    if circularity > 0.88:
        shape = "circle"
    elif rect_fill > 0.9 and circularity < 0.85:
        shape = "rectangle"
    else:
        shape = "irregular"
    return {
        "centroid": centroid, "normal": normal, "area": area, "perimeter": perimeter,
        "width": w, "height": h, "shape": shape,
        "hydraulic_diameter": 4 * area / perimeter if perimeter > 0 else 0.0,
        "equivalent_diameter": float(np.sqrt(4 * area / np.pi)),
    }


_SIDE_NAMES = (("x_min", "x_max"), ("y_min", "y_max"), ("z_min", "z_max"))


def _bbox_side(bounds: np.ndarray, centroid: np.ndarray, normal: np.ndarray) -> str | None:
    """Which side of `bounds` (the face's own region) the face lies on: by its centroid's position, the normal's
    sign deciding only when the region is flat along that axis and both sides coincide."""
    lo, hi = np.asarray(bounds, dtype=float)
    tol = BBOX_SIDE_TOL_OF_DIAG * float(np.linalg.norm(hi - lo))
    axis = int(np.argmax(np.abs(normal)))
    if abs(abs(normal[axis]) - 1.0) > 0.05:
        return None
    d_lo, d_hi = abs(centroid[axis] - lo[axis]), abs(centroid[axis] - hi[axis])
    if min(d_lo, d_hi) >= tol:
        return None
    if abs(d_lo - d_hi) < 1e-12 * max(tol, 1e-12):
        return _SIDE_NAMES[axis][1 if normal[axis] > 0 else 0]
    return _SIDE_NAMES[axis][0 if d_lo < d_hi else 1]


def _edge_table(mesh: trimesh.Trimesh) -> tuple[np.ndarray, np.ndarray]:
    """Open (single-face) edges as sorted vertex pairs and the face that owns each, from the edge arrays trimesh
    already caches for the mesh (edges_sorted, edges_unique_inverse, edges_face). Rebuilding the 3n x 2 edge
    list here and running np.unique over its rows is what ran a 2.6M-face assembly out of memory; this allocates
    nothing of that size that features.py (edges_unique_length) does not allocate anyway. Kept on the mesh so the
    rim and cap passes share one table."""
    cached = getattr(mesh, _EDGE_TABLE_ATTR, None)
    if cached is not None and cached[0] == len(mesh.faces):
        return cached[1]
    from geometry_agent.facts import load
    shared = getattr(load, "edge_table", None)
    if shared is not None:
        # the loader's table (one int64 key per edge, cached on the mesh) is the cheapest source there is
        t = shared(mesh)
        single = np.where(np.asarray(t.counts) == 1)[0]
        table = (np.asarray(t.edges)[single].astype(np.int64), np.asarray(t.face_ids)[np.asarray(t.face_ptr)[single]].astype(np.int64))
    else:
        inverse = np.asarray(mesh.edges_unique_inverse)
        counts = np.bincount(inverse, minlength=len(mesh.edges_unique))
        single = counts[inverse] == 1
        table = (np.asarray(mesh.edges_sorted)[single].astype(np.int64), np.asarray(mesh.edges_face)[single].astype(np.int64))
    try:
        setattr(mesh, _EDGE_TABLE_ATTR, (len(mesh.faces), table))
    except AttributeError:
        pass
    return table


def _chain_loops(boundary: np.ndarray) -> list[list[int]]:
    adj: dict[int, list[int]] = {}
    for a, b in boundary:
        adj.setdefault(int(a), []).append(int(b))
        adj.setdefault(int(b), []).append(int(a))
    seen: set[int] = set()
    loops = []
    for start in adj:
        if start in seen:
            continue
        loop = [start]
        seen.add(start)
        prev, cur = None, start
        while True:
            nxt = [v for v in adj[cur] if v != prev and v not in seen]
            if not nxt:
                break
            prev, cur = cur, nxt[0]
            loop.append(cur)
            seen.add(cur)
        if len(loop) >= 3:
            loops.append(loop)
    return loops


def _region_of_faces(mesh: trimesh.Trimesh) -> np.ndarray:
    """Region index per face: the loader's bodies when it knew them (STEP solids), else the connected components
    of the surface from load.face_components (edge-table connectivity, so an edge with three or more faces is not
    a cut and a soup with no two-face edge still measures). Regions are numbered largest surface area first so
    ids are stable; the result is cached on the mesh."""
    from geometry_agent.facts.load import body_of_face, face_components
    cached = getattr(mesh, "_geometry_agent_region_of", None)
    if cached is not None and cached[0] == len(mesh.faces):
        return cached[1]
    body = body_of_face(mesh)
    labels = np.asarray(body if body is not None else face_components(mesh), dtype=np.int64).reshape(-1)
    n_faces = len(mesh.faces)
    out = np.full(n_faces, -1, dtype=np.int64)
    if n_faces:
        n_labels = int(labels.max()) + 1
        area = np.bincount(labels, weights=np.asarray(mesh.area_faces, dtype=float), minlength=n_labels)
        first_face = np.full(n_labels, n_faces, dtype=np.int64)
        np.minimum.at(first_face, labels, np.arange(n_faces))
        order = sorted(range(n_labels), key=lambda k: (-float(area[k]), int(first_face[k])))
        rank = np.empty(n_labels, dtype=np.int64)
        rank[order] = np.arange(n_labels)
        out = rank[labels]
    try:
        mesh._geometry_agent_region_of = n_faces, out
    except AttributeError:
        pass
    return out


def open_rims(mesh: trimesh.Trimesh, region_of: np.ndarray) -> list[dict]:
    """Loops of single-face edges: the open ends of shells, pinholes, seams. Mesh arrays are read once; reading
    `mesh.face_normals` per edge re-hashes the whole mesh each time (80 s on a 1.3M-face part)."""
    vertices = np.asarray(mesh.vertices)
    face_normals = np.asarray(mesh.face_normals)
    boundary, owner = _edge_table(mesh)
    if len(boundary) == 0:
        return []
    face_of_edge = {(int(a), int(b)): int(f) for (a, b), f in zip(boundary, owner)}
    out = []
    for loop in _chain_loops(boundary):
        g = _loop_geometry(vertices[loop])
        if g is None:
            continue
        perp = total = 0.0
        faces = []
        for i in range(len(loop)):
            a, b = int(loop[i]), int(loop[(i + 1) % len(loop)])
            fi = face_of_edge.get((min(a, b), max(a, b)))
            length = float(np.linalg.norm(vertices[a] - vertices[b]))
            total += length
            if fi is not None:
                faces.append(fi)
                if abs(float(np.dot(face_normals[fi], g["normal"]))) < WALL_COS:
                    perp += length
        g["tubularity"] = perp / max(total, 1e-12)
        g["kind"] = "rim"
        g["region"] = int(region_of[faces[0]]) if faces else 0
        g["loops"] = 1
        g["faces"] = np.array(sorted(set(faces)), dtype=int)
        out.append(g)
    return out


class _Boundary:
    """For one labelling of faces into candidates: the adjacency pairs that cross a candidate's boundary and the
    open edges its faces own, each sorted by candidate so a candidate's boundary is one slice."""

    def __init__(self, label_of_face: np.ndarray, n_labels: int, adjacency: np.ndarray, adj_edges: np.ndarray,
                 open_edges: np.ndarray, open_face: np.ndarray, only: np.ndarray | None = None):
        la, lb = label_of_face[adjacency[:, 0]], label_of_face[adjacency[:, 1]]
        crossing = la != lb
        if only is not None:
            crossing &= only[adjacency[:, 0]] | only[adjacency[:, 1]]
        crossing = np.where(crossing)[0]
        side_label = np.concatenate([la[crossing], lb[crossing]])
        side_other = np.concatenate([adjacency[crossing, 1], adjacency[crossing, 0]])
        side_edge = np.concatenate([adj_edges[crossing], adj_edges[crossing]])
        order = np.argsort(side_label, kind="stable")
        self.other, self.edge = side_other[order], side_edge[order]
        side_label = side_label[order]
        ids = np.arange(n_labels)
        self.starts, self.stops = np.searchsorted(side_label, ids), np.searchsorted(side_label, ids, side="right")
        open_label = label_of_face[open_face]
        oorder = np.argsort(open_label, kind="stable")
        self.open_edges, open_label = open_edges[oorder], open_label[oorder]
        self.ostarts, self.ostops = np.searchsorted(open_label, ids), np.searchsorted(open_label, ids, side="right")

    def of(self, i: int) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        return self.other[self.starts[i]:self.stops[i]], self.edge[self.starts[i]:self.stops[i]], self.open_edges[self.ostarts[i]:self.ostops[i]]


class _Neighbours:
    """Face -> adjacent faces, built once on first use (only the chamfer walk needs it). It also carries the two
    membership masks the walk reads, allocated once and left all False between walks: `np.isin` against a
    growing array of seen faces cost 13 of 41 seconds of opening detection on a 4.36M-face part."""

    def __init__(self, adjacency: np.ndarray, n_faces: int, n_facets: int = 0):
        src = np.concatenate([adjacency[:, 0], adjacency[:, 1]]).astype(np.int32)
        dst = np.concatenate([adjacency[:, 1], adjacency[:, 0]]).astype(np.int32)
        order = np.argsort(src, kind="stable")
        self.dst = dst[order]
        src = src[order]
        ids = np.arange(n_faces)
        self.starts, self.stops = np.searchsorted(src, ids), np.searchsorted(src, ids, side="right")
        self.seen = np.zeros(n_faces, dtype=bool)
        self.touched = np.zeros(max(n_facets, 1), dtype=bool)

    def of(self, faces: np.ndarray) -> np.ndarray:
        return np.concatenate([self.dst[self.starts[f]:self.stops[f]] for f in faces]) if len(faces) else np.zeros(0, dtype=np.int32)


def _smooth_patches(mesh: trimesh.Trimesh, facets, face_normals: np.ndarray, face_areas: np.ndarray,
                    adjacency: np.ndarray, face_to_facet: np.ndarray) -> tuple[list[np.ndarray], np.ndarray, np.ndarray]:
    """Connected patches of faces joined across edges under SMOOTH_MERGE_DEG whose normals all lie within
    CAP_NORMAL_CONE_DEG of the patch's area-weighted mean, and which are more than one coplanar facet. Returns the
    patches, their mean normals and each patch's smallest normal dot with its mean (1 = planar). A cylinder, cone, fillet or dome is one smooth patch too, but its normals span
    far more than the cone, so it is not a candidate; a curved inlet is.

    A smooth chain leaks: a gently domed end face runs through its edge fillet into the bore, and the whole chain
    fails the cone. So a failed component that still has a dominant direction (its area-weighted normal sum keeps
    PATCH_DIRECTION_MIN of its length; a full cylinder's cancels to nothing) is peeled once: the faces within
    PEEL_CONE_DEG of that direction are re-connected and tried again."""
    n_faces = len(face_normals)
    smooth = np.asarray(mesh.face_adjacency_angles) < np.radians(SMOOTH_MERGE_DEG)
    # nothing to merge unless a smooth edge joins two different facets or touches a face outside every facet
    fa, fb = face_to_facet[adjacency[:, 0]], face_to_facet[adjacency[:, 1]]
    joins = smooth & ((fa != fb) | (fa < 0))
    if not joins.any():
        return [], np.zeros((0, 3)), np.zeros(0)
    cos_cone = np.cos(np.radians(CAP_NORMAL_CONE_DEG))

    def grow(nodes: np.ndarray, edge_mask: np.ndarray):
        comps = trimesh.graph.connected_components(adjacency[edge_mask], nodes=nodes, min_len=2)
        comp_of = np.full(n_faces, -1)
        for k, c in enumerate(comps):
            comp_of[c] = k
        n_comps = len(comps)
        if n_comps == 0:
            return comps, comp_of, np.zeros((0, 3)), np.zeros(0), np.zeros(0, dtype=bool), np.zeros(0, dtype=bool)
        member = comp_of >= 0
        weighted = np.zeros((n_comps, 3))
        np.add.at(weighted, comp_of[member], face_normals[member] * face_areas[member, None])
        area_sum = np.bincount(comp_of[member], weights=face_areas[member], minlength=n_comps)
        norms = np.linalg.norm(weighted, axis=1)
        mean = weighted / np.maximum(norms, 1e-300)[:, None]
        dots = np.einsum("ij,ij->i", face_normals[member], mean[comp_of[member]])
        min_dot = np.full(n_comps, 1.0)
        np.minimum.at(min_dot, comp_of[member], dots)
        fits = (min_dot >= cos_cone) & (norms > 0)
        # a component that is exactly one facet brings nothing new: keep only those that join facets or lone faces
        joined = np.zeros(n_comps, dtype=bool)
        j = joins & edge_mask & (comp_of[adjacency[:, 0]] >= 0) & (comp_of[adjacency[:, 0]] == comp_of[adjacency[:, 1]])
        joined[comp_of[adjacency[j, 0]]] = True
        directional = norms >= PATCH_DIRECTION_MIN * np.maximum(area_sum, 1e-300)
        return comps, comp_of, mean, min_dot, fits & joined, (~fits) & directional

    comps, comp_of, mean, min_dot, keep, peel = grow(np.arange(n_faces), smooth)
    patches = [np.asarray(comps[k], dtype=int) for k in np.where(keep)[0]]
    normals = [mean[k] for k in np.where(keep)[0]]
    spreads = [float(min_dot[k]) for k in np.where(keep)[0]]
    if peel.any():
        member = comp_of >= 0
        within = np.zeros(n_faces, dtype=bool)
        within[member] = peel[comp_of[member]] & (np.einsum("ij,ij->i", face_normals[member], mean[comp_of[member]]) >= np.cos(np.radians(PEEL_CONE_DEG)))
        edge_mask = smooth & within[adjacency[:, 0]] & within[adjacency[:, 1]]
        if edge_mask.any():
            comps2, _, mean2, min_dot2, keep2, _ = grow(np.where(within)[0], edge_mask)
            patches += [np.asarray(comps2[k], dtype=int) for k in np.where(keep2)[0]]
            normals += [mean2[k] for k in np.where(keep2)[0]]
            spreads += [float(min_dot2[k]) for k in np.where(keep2)[0]]
    return patches, (np.asarray(normals) if normals else np.zeros((0, 3))), np.asarray(spreads)


def _band_walk(band: np.ndarray, band_area: float, band_len: float, normal: np.ndarray, limit: float, seen: np.ndarray,
               touched: np.ndarray, face_normals: np.ndarray, face_areas: np.ndarray, neighbours: _Neighbours,
               face_to_facet: np.ndarray) -> bool:
    """Step outward from one band of inclined neighbours, ring by ring through faces that keep turning away (a
    chamfer tessellated in two rows), until what lies beyond is mostly wall (True) or the band has grown wider
    than `limit`, runs out, or comes back to a coplanar surface (False). `band_area` and `band_len` describe the
    whole inclined boundary the band belongs to (area of every inclined neighbour over the inclined length), so
    the width is the band's, not one rim segment's. `seen` and `touched` are the neighbours' masks as the caller
    set them; the faces this walk adds are cleared again before it returns, so every walk starts from the same
    set."""
    added: list[np.ndarray] = []
    try:
        for _ in range(MAX_BAND_RINGS):
            if band_area / band_len > limit:
                return False
            beyond = np.unique(neighbours.of(band))
            facet = face_to_facet[beyond]
            on_touched = np.zeros(len(beyond), dtype=bool)
            has = facet >= 0
            on_touched[has] = touched[facet[has]]
            beyond = beyond[~seen[beyond] & ~on_touched]
            if len(beyond) == 0:
                return False
            dots = np.abs(face_normals[beyond] @ normal)
            wall = dots < WALL_COS
            if float(face_areas[beyond][wall].sum()) >= BAND_BEYOND_WALL_FRACTION * float(face_areas[beyond].sum()):
                return True
            if (dots >= COPLANAR_COS).any():
                return False
            band = beyond[~wall]
            band_area += float(face_areas[band].sum())
            seen[beyond] = True
            added.append(beyond)
        return False
    finally:
        for faces in added:
            seen[faces] = False


def _band_wall_length(other: np.ndarray, inclined: np.ndarray, shared_len: np.ndarray, normal: np.ndarray, area: float,
                      members: np.ndarray, face_normals: np.ndarray, face_areas: np.ndarray, neighbours: _Neighbours,
                      face_to_facet: np.ndarray) -> float:
    """Boundary length along inclined neighbours that turn out to be edge breaks in front of a wall: a narrow band
    (a chamfer or fillet under CHAMFER_BAND_OVER_D of the candidate's diameter) with wall beyond it. Each
    neighbouring surface (facet, or lone face) is walked on its own, so a hex flat's chamfered ends do not vouch
    for its two peer flats. Faces on a flat surface the candidate already borders as a wall are not beyond anything
    (a strip of a cylinder wall would otherwise borrow the cap at its own end), and a coplanar neighbour is no edge break:
    the candidate is then a fragment of a larger flat surface that the facet tolerance split, judged as a whole."""
    idx = np.where(inclined)[0]
    if len(idx) == 0:
        return 0.0
    if (np.abs(face_normals[other[idx]] @ normal) >= COPLANAR_COS).any():
        return 0.0
    limit = CHAMFER_BAND_OVER_D * float(np.sqrt(4.0 * area / np.pi))
    # flat surfaces the candidate already borders as walls are not beyond any band
    touched = np.unique(face_to_facet[other[~inclined]])
    touched = touched[touched >= 0]
    seen = np.unique(np.concatenate([members, other]))
    surface = face_to_facet[other[idx]].astype(np.int64)
    lone = surface < 0
    surface[lone] = -2 - other[idx][lone]          # every lone face is its own surface
    inclined_len = float(shared_len[idx].sum())
    inclined_area = float(face_areas[np.unique(other[idx])].sum())
    if inclined_len <= 0:
        return 0.0
    if len(neighbours.touched) <= int(face_to_facet.max(initial=-1)):
        neighbours.touched = np.zeros(int(face_to_facet.max()) + 1, dtype=bool)
    neighbours.seen[seen] = True
    neighbours.touched[touched] = True
    total = 0.0
    try:
        for key in np.unique(surface):
            sel = idx[surface == key]
            band = np.unique(other[sel])
            if _band_walk(band, inclined_area, inclined_len, normal, limit, neighbours.seen, neighbours.touched,
                          face_normals, face_areas, neighbours, face_to_facet):
                total += float(shared_len[sel].sum())
    finally:
        neighbours.seen[seen] = False
        neighbours.touched[touched] = False
    return total


def _tubularity(other, shared, open_edges, normal, area, members, vertices, face_normals, face_areas, neighbours_of, face_to_facet):
    """Fraction of the candidate's outer boundary that meets a wall, plus its boundary loops (largest first).
    Open edges on the outer loop are not wall (an unstitched cap); open edges that form inner loops are holes
    through the face and do not count either way: the face is then a ring with a hole in it."""
    dots = np.abs(face_normals[other] @ normal) if len(other) else np.zeros(0)
    shared_len = np.linalg.norm(vertices[shared[:, 0]] - vertices[shared[:, 1]], axis=1) if len(shared) else np.zeros(0)
    wall = dots < WALL_COS
    perp = float(shared_len[wall].sum())
    shared_total = float(shared_len.sum())
    if len(open_edges):
        all_boundary = np.vstack([shared, open_edges]) if len(shared) else open_edges
    else:
        all_boundary = shared
    if len(all_boundary) == 0:
        return 0.0, []
    open_outer = 0.0
    loops: list[list[int]] | None = None
    if len(open_edges):
        loops = _chain_loops(all_boundary)
        if not loops:
            return 0.0, []
        loops.sort(key=lambda lp: -_loop_area(vertices[lp]))
        outer = loops[0]
        on_outer = {(min(outer[k], outer[(k + 1) % len(outer)]), max(outer[k], outer[(k + 1) % len(outer)])) for k in range(len(outer))}
        open_len = np.linalg.norm(vertices[open_edges[:, 0]] - vertices[open_edges[:, 1]], axis=1)
        open_outer = float(sum(ln for (a, b), ln in zip(open_edges, open_len) if (int(a), int(b)) in on_outer))
    boundary_len = shared_total + open_outer
    if boundary_len <= 0:
        return 0.0, []
    if perp < MIN_TUBULARITY * boundary_len and (~wall).any() and neighbours_of is not None:
        perp += _band_wall_length(other, ~wall, shared_len, normal, area, members, face_normals, face_areas, neighbours_of(), face_to_facet)
    tubularity = perp / boundary_len
    if tubularity < MIN_TUBULARITY:
        return tubularity, []
    if loops is None:
        loops = _chain_loops(all_boundary)
        loops.sort(key=lambda lp: -_loop_area(vertices[lp]))
    return tubularity, loops


#: The largest perimeter squared over area a face can have and still be a port by MAX_ASPECT: a rectangle of
#: aspect r has 4 (r + 1)**2 / r, a circle 4 pi. Only a face this compact counts toward the gate's candidates,
#: so the strips a tessellated cylinder is made of (each a flat facet, aspect in the hundreds) do not fill the
#: count with faces that could never have been a port.
PORT_SHAPED_P2_OVER_A = 4.0 * (MAX_ASPECT + 1.0) ** 2 / MAX_ASPECT


def _port_shaped(area: float, shared: np.ndarray, open_edges: np.ndarray, vertices: np.ndarray) -> bool:
    if area <= 0:
        return False
    per = 0.0
    for e in (shared, open_edges):
        if len(e):
            per += float(np.linalg.norm(vertices[e[:, 0]] - vertices[e[:, 1]], axis=1).sum())
    return per * per / area <= PORT_SHAPED_P2_OVER_A


def planar_caps(mesh: trimesh.Trimesh, region_of: np.ndarray) -> list[dict]:
    """Face groups whose outer boundary is mostly walls: the flat (or gently curved) ends of tubes and blocks.
    Candidates are the coplanar facets and, first, the smooth patches that merge several of them; a facet
    absorbed into a patch that became an opening is not listed again.

    Everything per candidate is looked up from arrays grouped once up front. Reading `mesh.face_normals` or
    `mesh.faces` inside the loop is not free: trimesh re-hashes the whole mesh to validate its cache on every
    access, which cost 37 of 64 seconds on a 600k-face part."""
    facets = mesh.facets
    if len(facets) == 0:
        # no two faces are coplanar: nothing flat for the gate to judge, which is a measured zero
        try:
            mesh.metadata[GATE_META] = {"candidates": 0, "rejected_by_tubularity": 0, "best_rejected_tubularity": None}
        except (AttributeError, TypeError):
            pass
        return []
    facet_normals = np.asarray(mesh.facets_normal)
    facet_areas = np.asarray(mesh.facets_area)
    vertices = np.asarray(mesh.vertices)
    faces = np.asarray(mesh.faces)
    face_normals = np.asarray(mesh.face_normals)
    face_areas = np.asarray(mesh.area_faces)
    face_centres = np.asarray(mesh.triangles_center)
    adjacency = np.asarray(mesh.face_adjacency)
    adj_edges = np.asarray(mesh.face_adjacency_edges)
    open_edges_all, open_face_all = _edge_table(mesh)
    region_area = np.bincount(region_of, weights=face_areas, minlength=int(region_of.max()) + 1 if len(region_of) else 0)
    face_to_facet = np.full(len(faces), -1)
    for i, f in enumerate(facets):
        face_to_facet[f] = i

    neighbours_cache: list[_Neighbours] = []

    def neighbours_of() -> _Neighbours:
        if not neighbours_cache:
            neighbours_cache.append(_Neighbours(adjacency, len(faces), len(facets)))
        return neighbours_cache[0]

    # the tubularity gate, counted, so an empty list of openings can say which empty it is (schema.OpeningGate)
    gate = {"candidates": 0, "rejected_by_tubularity": 0, "best_rejected_tubularity": None}

    def evaluate(members: np.ndarray, normal: np.ndarray, area: float, boundary: _Boundary, i: int, planar: bool) -> dict | None:
        region = int(region_of[members[0]])
        if area < MIN_AREA_FRACTION * region_area[region]:
            return None
        other, shared, open_edges = boundary.of(i)
        # only a flat candidate gets the chamfer walk (a facet, or a patch within NEARLY_PLANAR_DEG): a curved patch
        # with inclined neighbours is a fillet continuing past where the cone cut it, not a face behind an edge break
        tubularity, loops = _tubularity(other, shared, open_edges, normal, area, members, vertices, face_normals, face_areas,
                                        neighbours_of if planar else None, face_to_facet)
        if loops:
            gate["candidates"] += 1
        elif (len(other) or len(open_edges)) and _port_shaped(area, shared, open_edges, vertices):
            gate["candidates"] += 1
            gate["rejected_by_tubularity"] += 1
            best = gate["best_rejected_tubularity"]
            gate["best_rejected_tubularity"] = float(tubularity) if best is None else max(best, float(tubularity))
        if not loops:
            return None
        g = _loop_geometry(vertices[loops[0]])
        if g is None or g["height"] <= 0 or g["width"] / g["height"] > MAX_ASPECT:
            return None
        g["normal"] = normal / np.linalg.norm(normal)
        g["tubularity"] = float(tubularity)
        g["region"] = region
        g["loops"] = len(loops)
        g["faces"] = np.asarray(members, dtype=int)
        if len(loops) >= 2:
            inner = _loop_geometry(vertices[loops[1]])
            g["kind"] = "ring"
            g["ring_area"] = float(area)
            if inner is not None:
                g["bore"] = inner
            # every hole through the face, not just the largest: a block with two bores has two
            g["bore_areas"] = [float(_loop_area(vertices[lp])) for lp in loops[1:]]
        elif area < RING_FILL_FRACTION * g["area"]:
            # the faces fill well under the outer loop: there is a hole whose rim the adjacency cannot see (an edge
            # with three or more faces, where another body meets this one). A planar face with a hole is a ring;
            # its bore is what is missing from the loop.
            g["kind"] = "ring"
            g["ring_area"] = float(area)
            missing = float(g["area"] - area)
            g["bore"] = {"area": missing, "equivalent_diameter": float(np.sqrt(4 * missing / np.pi))}
        else:
            g["kind"] = "cap"
            g["area"] = float(area)
            # the exact centroid of the face, not the mean of its rim vertices: a B-rep rim carries its vertices
            # where the walls happened to be split, which put a symmetric curved inlet 12 mm off its axis
            g["centroid"] = (face_centres[members] * face_areas[members, None]).sum(axis=0) / max(float(area), 1e-300)
            # a merged patch is curved: its true area exceeds the outer loop's planar projection
            g["hydraulic_diameter"] = 4 * area / g["perimeter"] if g["perimeter"] > 0 else 0.0
            g["equivalent_diameter"] = float(np.sqrt(4 * area / np.pi))
        return g

    out = []
    consumed = np.zeros(len(facets), dtype=bool)
    patches, patch_normals, patch_spread = _smooth_patches(mesh, facets, face_normals, face_areas, adjacency, face_to_facet)
    if patches:
        label = np.full(len(faces), -1)
        in_patch = np.zeros(len(faces), dtype=bool)
        for k, p in enumerate(patches):
            label[p] = k
            in_patch[p] = True
        boundary = _Boundary(label, len(patches), adjacency, adj_edges, open_edges_all, open_face_all, only=in_patch)
        for k, p in enumerate(patches):
            g = evaluate(p, patch_normals[k], float(face_areas[p].sum()), boundary, k,
                         planar=bool(patch_spread[k] >= np.cos(np.radians(NEARLY_PLANAR_DEG))))
            if g is not None:
                out.append(g)
                consumed[face_to_facet[p][face_to_facet[p] >= 0]] = True

    boundary = _Boundary(face_to_facet, len(facets), adjacency, adj_edges, open_edges_all, open_face_all)
    for i in range(len(facets)):
        if consumed[i]:
            continue
        g = evaluate(np.asarray(facets[i], dtype=int), facet_normals[i], float(facet_areas[i]), boundary, i, planar=True)
        if g is not None:
            out.append(g)
    try:
        mesh.metadata[GATE_META] = gate
    except (AttributeError, TypeError):
        pass
    return out


def _loop_area(pts: np.ndarray) -> float:
    pts = np.asarray(pts, dtype=float)
    n = np.cross(pts, np.roll(pts, -1, axis=0)).sum(axis=0)
    return float(np.linalg.norm(n) / 2)


def detect_openings_with_faces(mesh: trimesh.Trimesh) -> tuple[list[Opening], list[np.ndarray]]:
    """Openings plus, for each, the face indices it is made of (needed to tell interface faces from ports)."""
    from geometry_agent.facts.regions import region_meshes

    region_of = _region_of_faces(mesh)
    region_area = {int(k): float(mesh.area_faces[region_of == k].sum()) for k in np.unique(region_of)}
    region_bounds = {k: np.asarray(p.bounds, dtype=float) for k, p in enumerate(region_meshes(mesh))}
    cands = open_rims(mesh, region_of) + planar_caps(mesh, region_of)
    cands.sort(key=lambda g: (-round(g["area"], 9), tuple(np.round(g["centroid"], 6))))
    out, faces = [], []
    for k, g in enumerate(cands, start=1):
        bore = g.get("bore")
        bounds = region_bounds.get(int(g["region"]), np.asarray(mesh.bounds, dtype=float))
        side = _bbox_side(bounds, np.asarray(g["centroid"]), np.asarray(g["normal"]))
        out.append(Opening(
            id=f"o{k}", kind=g["kind"],
            centroid=tuple(float(v) for v in g["centroid"]),
            normal=tuple(float(v) for v in g["normal"]),
            area=g["area"], perimeter=g["perimeter"],
            hydraulic_diameter=g["hydraulic_diameter"], equivalent_diameter=g["equivalent_diameter"],
            width=g["width"], height=g["height"], shape=g["shape"],
            tubularity=float(g["tubularity"]),
            on_bbox_face=side is not None,
            bbox_side=side,
            region_id=f"r{g['region'] + 1}",
            bore_diameter=float(bore["equivalent_diameter"]) if bore else None,
            bore_area=float(bore["area"]) if bore else None,
            bore_count=len(g["bore_areas"]) if g.get("bore_areas") is not None else None,
            bore_areas=sorted(g["bore_areas"], reverse=True) if g.get("bore_areas") is not None else None,
            area_fraction_of_region=float(g["area"] / region_area[int(g["region"])]) if region_area.get(int(g["region"])) else 0.0,
            face_count=int(len(g["faces"])),
        ))
        faces.append(g["faces"])
    return out, faces


def detect_openings(mesh: trimesh.Trimesh) -> list[Opening]:
    return detect_openings_with_faces(mesh)[0]


PORT_ENTRY_AREA_BAND = (0.75, 1.25)
#: A flat face over this fraction of its body's core surface (the surface without the walls of the nozzles that
#: stand on it) with under a diameter of tube behind it is a side of the body. Was taken against the whole region
#: surface, where a plenum's nozzle walls pushed its 0.2 x 0.1 sides to 0.079.
PLANAR_FACE_AREA_FRACTION = 0.08
PLANAR_FACE_STUB_OVER_D = 1.0
SPANS_BODY_FRACTION = 0.8
SLAB_STUB_OVER_D = 3.0
#: A twin face must sit within half a diameter of the line the march follows inward from the face.
SLAB_TWIN_LATERAL_OVER_D = 0.5
#: Half a diameter of tube or less behind a face is no tube: the face is flush with whatever it sits in. Inclusive,
#: because the march is quantised to sixths of a diameter and a 0.5 D boss measures exactly 0.50.
#: A port cut flush into a plenum wall is geometrically a wall face with a condition on it; the brief decides.
FLUSH_STUB_OVER_D = 0.5
#: The same, against the face's width (its longer in-plane extent): a passage shorter than half the width of the
#: face it starts from is no tube either. Identical to the diameter test for a round face; for the 100 x 20 end
#: of a plate (D_h 33) with 22 mm of plate before the first bolt hole it says what the diameter test cannot.
FLUSH_STUB_OVER_WIDTH = 0.5
SLAB_AREA_BAND = 0.25
INTERFACE_AREA_FRACTION = 0.5
#: A cap with a tube behind it and under half the area of its region's largest flat face is the tip of a nozzle
#: standing on the body; its stub is the nozzle's length and its walls are not the body's surface.
PROTRUSION_AREA_FRACTION = 0.5


def _tube_behind(s) -> bool:
    lo, hi = PORT_ENTRY_AREA_BAND
    return s.entry_loops == 1 and s.entry_area_ratio is not None and lo <= s.entry_area_ratio <= hi


def _region_cores(openings: list[Opening], stub_of: dict, region_extents: dict[str, tuple[float, float, float]]
                  ) -> tuple[dict[str, tuple[float, float, float]], dict[str, float]]:
    """Per region: the bounding-box extents with the nozzles that stand on the body taken off (the longest nozzle
    on each bounding-box side sets that side, so its measured stub is what comes off), and the wall area of those
    nozzles, which the body's core surface does not include."""
    largest: dict[str, float] = {}
    for o in openings:
        if o.kind != "rim":
            largest[o.region_id] = max(largest.get(o.region_id, 0.0), o.area)
    ext = {r: list(e) for r, e in region_extents.items()}
    walls: dict[str, float] = {}
    longest: dict[tuple[str, str], float] = {}
    for o in openings:
        s = stub_of.get(o.id)
        if o.kind != "cap" or s is None or s.length <= 0 or not _tube_behind(s):
            continue
        if o.area >= PROTRUSION_AREA_FRACTION * largest.get(o.region_id, 0.0):
            continue
        walls[o.region_id] = walls.get(o.region_id, 0.0) + o.perimeter * s.length
        if o.bbox_side is not None:
            key = (o.region_id, o.bbox_side)
            longest[key] = max(longest.get(key, 0.0), s.length)
    for (r, side), length in longest.items():
        if r in ext:
            axis = "xyz".index(side[0])
            ext[r][axis] = max(ext[r][axis] - length, 0.0)
    return {r: tuple(e) for r, e in ext.items()}, walls


def _flush(o: Opening, s, rings: list[Opening]) -> bool:
    """Half a diameter or less of tube behind the face, or half the face's width or less: no tube. The length is
    the march's, or the distance to a shoulder ring the face stands on when that is shorter (see _shoulder_behind).
    `rings` are the ring openings of the face's own region."""
    length = float(s.length)
    shoulder = _shoulder_behind(o, s, rings)
    if shoulder is not None:
        length = min(length, shoulder)
    d = max(o.hydraulic_diameter, 1e-12)
    return length / d <= FLUSH_STUB_OVER_D or length <= FLUSH_STUB_OVER_WIDTH * o.width


def _slab_side(o: Opening, extents: tuple[float, float, float]) -> bool:
    """The face reaches across its body's core in both in-plane directions AND the core is under SLAB_STUB_OVER_D
    diameters deep behind it: a side of a slab (a plenum whose far side is a ring or a dome, so no twin is
    listed). The span alone says nothing: a pipe end always spans its own tube, and a header 6 D long with
    branches on it is a tube whose core the end face spans exactly."""
    n = np.asarray(o.normal, dtype=float)
    axis = int(np.argmax(np.abs(n)))
    if abs(n[axis]) < 0.9:
        return False
    depth = float(extents[axis])
    if depth >= SLAB_STUB_OVER_D * max(o.hydraulic_diameter, 1e-12):
        return False
    e = sorted(float(extents[k]) for k in range(3) if k != axis)
    return o.width >= SPANS_BODY_FRACTION * e[1] and o.height >= SPANS_BODY_FRACTION * e[0]


def _facing_twin(o: Opening, s, openings: list[Opening]) -> bool:
    """Another opening of the same body sits on the line the march follows inward, within SLAB_STUB_OVER_D along it
    and half a diameter beside it, facing back, of about the same area: the two sides of a slab (a plenum, a plate,
    a short block), not the ends of a duct. Whatever stopped the march (a nozzle root, a flush hole crossed on the
    way) does not matter: the twin is a fact about the two faces."""
    if o.area <= 0:
        return False
    d = max(o.hydraulic_diameter, 1e-12)
    inward = np.asarray(s.inward_direction, dtype=float) if s.inward_direction else -np.asarray(o.normal, dtype=float)
    c = np.asarray(o.centroid, dtype=float)
    for t in openings:
        if t is o or t.region_id != o.region_id or t.kind == "ring":
            continue
        if abs(t.area / o.area - 1.0) > SLAB_AREA_BAND:
            continue
        if np.dot(t.normal, o.normal) > -0.9:
            continue
        rel = np.asarray(t.centroid, dtype=float) - c
        along = float(rel @ inward)
        lateral = float(np.linalg.norm(rel - along * inward))
        if 0.0 < along <= SLAB_STUB_OVER_D * d and lateral <= SLAB_TWIN_LATERAL_OVER_D * d:
            return True
    return False


def _shoulder_behind(o: Opening, s, rings: list[Opening]) -> float | None:
    """Distance from a cap to the nearest ring of its body that faces the same way, sits on the march line behind
    it within SLAB_STUB_OVER_D, and whose bore is about the cap's area: the cap is the end of a boss standing on
    that shoulder, and the boss is exactly that long. The march's first section lies 0.05 D behind the face, so a
    boss shorter than that (a 4 mm plug on the end of a 160 mm tube) reads as the tube behind it instead."""
    if o.area <= 0:
        return None
    d = max(o.hydraulic_diameter, 1e-12)
    inward = np.asarray(s.inward_direction, dtype=float) if s.inward_direction else -np.asarray(o.normal, dtype=float)
    c = np.asarray(o.centroid, dtype=float)
    best = None
    for t in rings:
        if not t.bore_area or abs(t.bore_area / o.area - 1.0) > SLAB_AREA_BAND or np.dot(t.normal, o.normal) < 0.9:
            continue
        rel = np.asarray(t.centroid, dtype=float) - c
        along = float(rel @ inward)
        lateral = float(np.linalg.norm(rel - along * inward))
        if 0.0 < along <= SLAB_STUB_OVER_D * d and lateral <= SLAB_TWIN_LATERAL_OVER_D * d:
            best = along if best is None else min(best, along)
    return best


def classify_openings(openings: list[Opening], stubs: list, faces: list[np.ndarray], interface_mask: np.ndarray,
                      face_areas: np.ndarray, region_extents: dict[str, tuple[float, float, float]] | None = None) -> None:
    """Set `classification` on every opening. Geometry only; the model may still assign any role.

    A cap is a port candidate when a single closed section of about its own area lies right behind it (a tube)
    and it is not simply one flat side of a body. Three things say "side": the face is more than 8% of its
    body's core surface with under a diameter of tube behind it; a twin face of about the same area looks back
    at it from within three diameters along the march line (the two sides of a slab); or the face spans the
    body's core in both in-plane directions and that core is under three diameters deep behind it (a slab whose
    far side is a ring or a dome). The span alone never decides: a pipe end spans its own tube. Half a diameter
    or less behind a face, or half the face's width or less, is flush; a shoulder ring the face stands on
    measures that length exactly when the march's first station overshoots it. A cap whose stub the time budget
    left unmarched is a planar face: nothing showed a tube behind it. Rims are ports when their edge faces stand
    as walls to them, holes otherwise. Faces shared with another body are interfaces, whatever else they look
    like."""
    stub_of = {s.opening_id: s for s in stubs}
    region_extents = region_extents or {}
    cores, nozzle_walls = _region_cores(openings, stub_of, region_extents)
    rings_of: dict[str, list[Opening]] = {}
    for o in openings:
        if o.kind == "ring":
            rings_of.setdefault(o.region_id, []).append(o)
    for o, fids in zip(openings, faces):
        if o.kind == "ring":
            o.classification = "ring"
            continue
        if len(fids) and interface_mask[fids].any():
            shared = float(face_areas[fids][interface_mask[fids]].sum())
            if shared >= INTERFACE_AREA_FRACTION * float(face_areas[fids].sum()):
                o.classification = "interface"
                continue
        if o.kind == "rim":
            o.classification = "port_candidate" if o.tubularity >= MIN_TUBULARITY else "hole"
            continue
        s = stub_of.get(o.id)
        if s is None:
            o.classification = "planar_face"
            continue
        short = s.length_over_diameter < PLANAR_FACE_STUB_OVER_D
        ext = cores.get(o.region_id)
        region_area = o.area / o.area_fraction_of_region if o.area_fraction_of_region > 0 else 0.0
        core_area = max(region_area - nozzle_walls.get(o.region_id, 0.0), 0.0)
        core_fraction = o.area / core_area if core_area > 0 else 0.0
        if not _tube_behind(s):
            o.classification = "planar_face"
        elif _flush(o, s, rings_of.get(o.region_id, [])):
            o.classification = "planar_face"
        elif short and core_fraction > PLANAR_FACE_AREA_FRACTION:
            o.classification = "planar_face"
        elif s.length_over_diameter < SLAB_STUB_OVER_D and (_facing_twin(o, s, openings) or (ext is not None and _slab_side(o, ext))):
            o.classification = "planar_face"
        else:
            o.classification = "port_candidate"
