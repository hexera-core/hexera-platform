"""path -> GeometryFacts. Deterministic, read-only, cached by content hash.

Every stage is timed against one budget. When a giant file exhausts it, the stages that remain are the ones a
plan can do without for a first pass (more stub marches, the region gap, symmetry), and each one skipped is
named in `warnings`, so a partial answer says it is partial. The plan-critical stages (bodies, openings, the
largest stubs, thickness, estimates) always run."""
from __future__ import annotations

import json
import os
import time
from contextlib import ExitStack
from pathlib import Path

import numpy as np

from geometry_agent.facts import (
    axes,
    estimate,
    features,
    interfaces,
    load,
    names,
    openings,
    regions,
    stubs,
    tessellation,
    units,
)
from geometry_agent.facts.schema import (
    FACTS_SCHEMA_VERSION,
    MEASUREMENT_REVISION,
    Axes,
    BBox,
    GeometryFacts,
    OpeningGate,
    Purpose,
)

#: Every planar candidate is marched, largest first, while the budget allows (the corridor slice makes a march
#: cost milliseconds: 471 caps on a real rocket took 1.5 s). This ceiling only bounds a pathological export.
MAX_STUBS = 100_000
#: Wall-clock budget for one measurement. Past it, optional stages are skipped and say so.
DEFAULT_TIME_BUDGET_S = 120.0
#: Below this many openings every stub is marched whatever the clock says; they are what the plan is about.
STUBS_ALWAYS = 8
#: What the chord-deviation stage costs: a fixed part for the surface projections and a multiple of the load
#: for reading, tessellating and walking the file again. `CHORD_BASE_S + CHORD_COST_OVER_LOAD * load`.
#:
#: IT WAS 5.5 LOADS AND NOTHING ELSE, and the shape was wrong once the stage stopped evaluating every chord.
#: `tessellation.MAX_CHORDS` now thins before any surface is evaluated, so the projections are bounded whatever
#: the part, and what still grows with the part is the second read. Measured by the verifier over the 322 corpus
#: parts, uncached, one timing run with two measurements sharing the machine: the stage took at most 1.79 s,
#: 5.5 loads was exceeded on 108 parts, all loading in under 0.28 s and by at most 0.76 s, and on the 11 parts
#: loading in over 0.5 s it never took more than 2.4 loads (0.55 above 1 s). 2 s plus 2 loads covers every
#: corpus part, and the second load is a margin for the walk over the nodes on a part larger than any here,
#: which is reasoned and not measured.
CHORD_BASE_S = 2.0
CHORD_COST_OVER_LOAD = 2.0
#: Stub marching stops once this share of the budget is spent, so thickness, gaps and symmetry keep their share;
#: how many candidates were left unmarched is written to warnings so the classifier can say so.
STUB_BUDGET_FRACTION = 0.6
#: Watertight regions whose bounding diagonals differ by more than this factor are read as mixed scales (a part
#: in metres beside one in millimetres, or a stray part) and named in a warning. A 0.6 m manifold beside a 40 mm
#: bracket written in mm is 86x apart. An assembly with its fasteners can exceed this in one unit; the warning
#: names both bodies so that reading is a one-line check.
MIXED_SCALE_RATIO = 50.0
#: A child measurement that dies of memory or a native fault is retried this many times after RETRY_WAIT_S; the
#: fault comes from concurrent children competing for memory, which a short wait usually resolves.
ISOLATED_RETRIES = 2
RETRY_WAIT_S = 3.0
#: Windows exit codes for an access violation and a stack overflow in a native library.
NATIVE_FAULT_CODES = {3221225477, 3221225725, -1073741819, -1073741571}
#: One BLAS thread per child: concurrent children with default OpenBLAS threading exhaust memory and die with
#: "Memory allocation failed" or an access violation.
SINGLE_THREAD_ENV = {"OPENBLAS_NUM_THREADS": "1", "OMP_NUM_THREADS": "1", "MKL_NUM_THREADS": "1"}


class _Budget:
    def __init__(self, seconds: float):
        self.seconds = seconds
        self.t0 = time.perf_counter()
        self.skipped: list[str] = []

    def elapsed(self) -> float:
        return time.perf_counter() - self.t0

    def left(self) -> float:
        return self.seconds - self.elapsed()

    def allows(self, stage: str, expected_s: float = 0.0) -> bool:
        if self.left() - expected_s > 0:
            return True
        self.skipped.append(stage)
        return False


def _bbox(mesh) -> BBox:
    lo, hi = mesh.bounds
    ext = hi - lo
    return BBox(
        min=tuple(float(v) for v in lo), max=tuple(float(v) for v in hi), extent=tuple(float(v) for v in ext),
        diagonal=float(np.linalg.norm(ext)), longest_axis=int(np.argmax(ext)), shortest_axis=int(np.argmin(ext)),
        aspect=float(ext.max() / max(ext.min(), 1e-12)),
    )


def _axes_fallback(mesh) -> Axes:
    """The principal frame only, for when the symmetry stage did not run. Every symmetry field is None, NOT an
    empty list and not a score of zero: `[]` is a measured "no mirror plane", and writing it for a stage that
    never ran told the builder a symmetric part had no symmetry (the distributor read [2] at 17k, 272k and 1M
    faces and [] at 4.36M, the same shape). The blunt end is not measured either: sign 0 at confidence 0."""
    mean, vals, vecs = axes._principal(mesh)
    return Axes(principal=tuple(tuple(float(v) for v in vecs[:, k]) for k in range(3)), variance=tuple(float(v) for v in vals),
                slenderness=float(np.sqrt(max(vals[0], 1e-18) / max(vals[1], 1e-18))), symmetry_scores=None,
                symmetry_planes=None, symmetry_normals=None, symmetry_measured=False,
                blunt_end_sign=0, blunt_end_confidence=0.0)


#: The warning a part gets when it has flat faces and the tubularity gate turned every one of them down, so an
#: empty list of openings is not read as a part with no mouths.
GATE_WARNING = ("openings refused, not absent: this part has flat faces big enough to be a port and every one failed "
                "the tubularity gate (the best reached {best:.3f} of the {need:.2f} needed): too little of each face's "
                "edge meets a wall squarely. On a part whose outer edges are filleted the wall arrives through the "
                "fillet and the gate sees none of it; which faces are ports must come from the customer")


#: The chord casting in `features` is priced per face: every face casts two chords and the distribution faces
#: eight probes each. When the clock left for the whole rest of the measurement is under CHORD_SHORT_S, the
#: casting is cut to the short caps below and the coverage fields say so, rather than the features stage alone
#: running the measurement past its budget. Measured on the 4.36M-face distributor: full caps took 19 s of the
#: features stage, with the ray structure (9 s) built whatever the caps.
CHORD_SHORT_S = 45.0

#: The coverage stage's own ceiling, seconds: `facts.coverage.measure_coverage`'s default. Measured at a median
#: of 1.5 s and a maximum of 20 s over the 322 export parts (work/z-cover), on a loaded machine.
COVERAGE_TIME_S = 30.0
CHORD_SHORT_CAPS = (250_000, 50_000)


#: WHERE A PASSAGE STOPS WITH NO MOUTH, from the measurement (work/z-next, gap C). `vision.terminus.find_stops`
#: reads nothing but the mesh and the measured openings; only its DRAWING is the look's. Until this stage it ran
#: inside the renderer, so a closed end reached the builder only on a run that looked. Now it runs at measure
#: time, with the mesh read as the material (the reading the detector needs; where the file is the fluid it finds
#: nothing by design, and `hexera.planner_places` applies that gate by representation).
#:
#: IT WAS `GEOMETRY_AGENT_MEASURED_STOPS`, OFF BY DEFAULT, AND THE SWITCH IS DELETED. Flipped first and then
#: deleted, in that order, because deleting a switch freezes whatever it was set to. What the flip moved, measured
#: over 8 fixture parts of 4 purposes by a deep diff of `hexera.report_measured_json` key path by key path: the
#: new `passage_ends` list, its own entry in `timings`, and the clock. No other key of the measurement moved.
#: A cached or stored document measured without the stage is topped up in memory only when the openings detected
#: again on the loaded mesh sit where the document's own are, within this fraction of the bounding diagonal; any
#: further off and the ids could name different faces, so the stage is refused and says so.
PASSAGE_ENDS_MATCH_OF_DIAG = 1e-6


def measure_passage_ends(mesh, ops, op_faces) -> list:
    """`terminus.find_stops` on the measured openings and the faces each is made of, the mesh read as the material.
    The same call the renderer makes for the stops view, with the same limit on how many, so a run that looks and
    a run that does not name the same ends."""
    from geometry_agent.facts.schema import PassageEnd
    from geometry_agent.vision.terminus import find_stops, mouths_from_openings
    stops = find_stops(mesh, mouths_from_openings(ops), [np.asarray(f, dtype=np.int64) for f in op_faces], solid=True)
    return [PassageEnd(opening_id=s.opening_id, point=tuple(float(c) for c in s.point),
                       normal=tuple(float(c) for c in s.normal), depth=float(s.depth), diameter=float(s.diameter))
            for s in stops]


def add_passage_ends(facts: GeometryFacts, path: str | Path | None = None, mesh=None) -> GeometryFacts:
    """The passage ends for a document measured without them (a cache entry, a stored measurement), in memory.

    The file is loaded and its openings detected again, because `find_stops` needs the faces each opening is made
    of and `Opening` does not carry them. The detection is deterministic on the same mesh; it is checked anyway,
    opening by opening, and a disagreement refuses the stage with a warning rather than tying a stop to the wrong
    id. The document on disk is never rewritten (an entry that exists is only ever read)."""
    if facts.passage_ends is not None:
        return facts
    out = facts.model_copy(deep=True)
    try:
        m = mesh if mesh is not None else load.load_mesh(Path(path or facts.source_path))
        ops, op_faces = openings.detect_openings_with_faces(m)
        tol = PASSAGE_ENDS_MATCH_OF_DIAG * max(float(facts.bbox.diagonal), 1e-12)
        same = len(ops) == len(facts.openings) and all(
            float(np.linalg.norm(np.asarray(a.centroid) - np.asarray(b.centroid))) <= tol
            for a, b in zip(ops, facts.openings))
        if not same:
            out.warnings.append("passage_ends not measured: the openings detected again on the loaded mesh do not "
                                "sit where this document's do, so a stop could not be tied to its id")
            return out
        t = time.perf_counter()
        out.passage_ends = measure_passage_ends(m, facts.openings, op_faces)
        out.timings = {**out.timings, "passage_ends": round(time.perf_counter() - t, 3)}
    except Exception as exc:  # noqa: BLE001 - an optional fact is never worth the measurement
        out.warnings.append(f"passage_ends not measured: {type(exc).__name__}: {str(exc)[:160]}")
    return out


def _chord_caps(budget: _Budget, n_faces: int) -> tuple[int, int]:
    from geometry_agent.facts import chords
    if budget.left() >= CHORD_SHORT_S or n_faces <= CHORD_SHORT_CAPS[0]:
        return chords.RAY_FACE_CAP, chords.DISTRIBUTION_FACES
    return CHORD_SHORT_CAPS


def _gate(mesh) -> OpeningGate | None:
    raw = mesh.metadata.get(openings.GATE_META)
    if not isinstance(raw, dict):
        return None
    return OpeningGate(**raw)


def cached_is_current(facts: GeometryFacts) -> bool:
    """A cached document is served only when the measurement that wrote it is the current one."""
    return int(getattr(facts, "measurement_revision", 0) or 0) >= MEASUREMENT_REVISION


#: The environment variable every direct reader of a facts cache honours, so a run can be pointed at a cache written
#: by the current measurement instead of the main tree's, which is revision 0 until Rehaan regenerates it.
FACTS_CACHE_ENV = "GEOMETRY_AGENT_FACTS_CACHE"
_STALE_SEEN: set[str] = set()


def facts_cache_dir(default: str | Path) -> Path:
    """The facts cache a reader should open: `FACTS_CACHE_ENV` when it is set, else the reader's own default."""
    return Path(os.environ.get(FACTS_CACHE_ENV) or default)


def read_cached(path: str | Path, *, reader: str = "") -> tuple[GeometryFacts, bool]:
    """A cached document read directly, and whether the measurement that wrote it is the current one.

    FOR THE READERS THAT OPEN A CACHE FILE THEMSELVES instead of calling `measure` (work/z-facts NEEDS 13). They
    used to take any revision as current, so on the main tree's revision-0 cache they served `min_gap` as the
    bore and half a pipe's length as its wall. Each now learns which it has: an evaluation that exists to
    reproduce a committed number may keep a stale document on purpose, and says so once per process (on stderr,
    naming the reader and the revision); a reader that stands for the product measures again instead."""
    p = Path(path)
    facts = GeometryFacts.model_validate_json(p.read_text(encoding="utf-8"))
    current = cached_is_current(facts)
    if not current:
        key = f"{reader or 'a reader'}:{p.parent}"
        if key not in _STALE_SEEN:
            _STALE_SEEN.add(key)
            import sys
            print(f"[facts] {reader or 'a reader'} is reading measurement revision "
                  f"{int(getattr(facts, 'measurement_revision', 0) or 0)} from {p.parent} (current is "
                  f"{MEASUREMENT_REVISION}); set {FACTS_CACHE_ENV} to a current cache to read today's measurement",
                  file=sys.stderr)
    return facts, current


def _read_cache(cache: Path) -> GeometryFacts | None:
    if not cache.exists():
        return None
    facts = GeometryFacts.model_validate_json(cache.read_text(encoding="utf-8"))
    return facts if cached_is_current(facts) else None


#: The warning on a document measured again in memory because the cache held an older revision's.
STALE_WARNING = ("the cache held this file's facts from measurement revision {old}; they were measured again "
                 "and the cache entry was left as it was (an entry that exists is only ever read)")


def _stale_revision(cache: Path | None) -> int | None:
    """The revision of an existing cache entry that is too old to serve; None when there is no such entry."""
    if cache is None or not cache.exists():
        return None
    try:
        raw = json.loads(cache.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    rev = int(raw.get("measurement_revision", 0) or 0)
    return rev if rev < MEASUREMENT_REVISION else None


def purge_stale(cache_dir: str | Path) -> int:
    """Delete the entries in a cache the CALLER OWNS that an older measurement revision wrote, and say how many.
    `measure` never does this itself: an entry that exists is only ever read, because a cache directory may
    belong to someone else (the export cache under the main tree is read by a dozen tools and written by none)."""
    n = 0
    for f in Path(cache_dir).glob(f"*.v{FACTS_SCHEMA_VERSION}.json"):
        if _stale_revision(f) is not None:
            f.unlink(missing_ok=True)
            n += 1
    return n


def write_cache(cache: Path, text: str) -> None:
    """Write a cache entry so a reader never sees half of one.

    Four workers share a --cache-dir and, under --isolated, each measurement is its own subprocess, so two of them
    can be writing the same file while a third reads it. A plain write_text leaves a window where the JSON on disk
    is truncated. The write goes to a temp file beside the target and is then renamed, which is atomic on this
    filesystem; a loser of the race renames over the winner with identical content."""
    cache.parent.mkdir(parents=True, exist_ok=True)
    tmp = cache.with_name(f"{cache.name}.{os.getpid()}.part")
    try:
        tmp.write_text(text, encoding="utf-8")
        os.replace(tmp, cache)
    finally:
        if tmp.exists():
            tmp.unlink(missing_ok=True)


def measure(path: str | Path, purpose: Purpose = "internal_cfd", cache_dir: str | Path | None = None,
            time_budget_s: float = DEFAULT_TIME_BUDGET_S) -> GeometryFacts:
    path = Path(path)
    digest = load.sha256_of(path)
    cache = Path(cache_dir) / f"{digest}.{purpose}.v{FACTS_SCHEMA_VERSION}.json" if cache_dir else None
    if cache is not None:
        cached = _read_cache(cache)
        if cached is not None:
            # an entry written before the passage-end stage existed is topped up in memory, never rewritten. There
            # is no switch to consult any more: the stage always runs, so an entry that carries the ends is served
            # with them and one that does not has them measured on the loaded mesh (`add_passage_ends` checks the
            # openings still sit where the entry's do and refuses rather than tie a stop to the wrong id)
            return add_passage_ends(cached, path)
    # AN ENTRY THAT EXISTS IS ONLY EVER READ. A stale one is measured again in memory and left on disk: callers
    # pass cache directories they do not own and rely on a present entry being read, not written (the offline
    # harness hands the main tree's export cache to measure, and the first cut of this revision check rewrote
    # an entry there). Only a missing entry is written.
    stale = _stale_revision(cache)
    if stale is not None:
        cache = None

    budget = _Budget(time_budget_s)
    warnings: list[str] = [STALE_WARNING.format(old=stale)] if stale is not None else []
    timings: dict[str, float] = {}

    def timed(stage: str, fn):
        t = time.perf_counter()
        out = fn()
        timings[stage] = round(time.perf_counter() - t, 3)
        return out

    mesh = timed("load", lambda: load.load_mesh(path))
    # NOTHING BELOW CHANGES THE MESH, so trimesh's cache is locked for the rest of the measurement: unlocked,
    # every property read re-hashes the vertex and face arrays to check they have not moved, and on a
    # 4.36M-face part that was 14 of 175 seconds spent confirming nothing had changed.
    with ExitStack() as locks:
        locks.enter_context(mesh._cache)
        # the ray intersector keeps its own cache, verified against a hash of the mesh on every query
        locks.enter_context(mesh.ray._cache)
        return _measure_loaded(path, mesh, digest, purpose, cache, budget, warnings, timings, timed, time_budget_s, locks)


def _measure_loaded(path: Path, mesh, digest: str, purpose: Purpose, cache: Path | None, budget: _Budget,
                    warnings: list[str], timings: dict[str, float], timed, time_budget_s: float,
                    locks: ExitStack) -> GeometryFacts:
    bbox = _bbox(mesh)
    debris = int(mesh.metadata.get(load.DEBRIS_META, 0))
    if debris:
        warnings.append(f"dropped {debris} debris components: stray triangles from the export")
    region_of = timed("connectivity", lambda: openings._region_of_faces(mesh))
    regs = timed("regions", lambda: regions.detect_regions(mesh))
    for part in regions.region_meshes(mesh):
        if part is not mesh:
            locks.enter_context(part._cache)
    ifaces, iface_mask = timed("interfaces", lambda: interfaces.detect_interfaces(mesh, region_of))
    pairs_skipped = int(mesh.metadata.get(interfaces.PAIRS_SKIPPED_META, 0))
    if pairs_skipped:
        warnings.append(f"{pairs_skipped} touching region pairs beyond the {interfaces.MAX_COINCIDENT_PAIRS} pair cap "
                        f"not searched for coincident interfaces (the smallest bodies)")
    ops, op_faces = timed("openings", lambda: openings.detect_openings_with_faces(mesh))
    gate = _gate(mesh)
    if gate is not None and gate.candidates and gate.rejected_by_tubularity == gate.candidates:
        warnings.append(GATE_WARNING.format(best=gate.best_rejected_tubularity or 0.0, need=openings.MIN_TUBULARITY))

    n_stubs = min(len(ops), MAX_STUBS)
    if len(ops) > MAX_STUBS:
        warnings.append(f"{len(ops)} planar candidates found; stubs measured for the {MAX_STUBS} largest only; "
                        f"{len(ops) - MAX_STUBS} left unmarched")

    def keep_going(k: int) -> bool:
        if k < STUBS_ALWAYS or budget.elapsed() < STUB_BUDGET_FRACTION * budget.seconds:
            return True
        warnings.append(f"time budget: stubs measured for the {k} largest openings of {len(ops)}; "
                        f"{len(ops) - k} left unmarched")
        return False

    stbs = timed("stubs", lambda: stubs.measure_stubs(mesh, ops, max_openings=n_stubs, keep_going=keep_going))
    openings.classify_openings(ops, stbs, op_faces, iface_mask, mesh.area_faces, {r.id: r.bbox_extent for r in regs})
    watertight = all(r.watertight for r in regs)
    warnings.extend(_mixed_scale_warnings(regs, purpose))

    ray_cap, dist_cap = _chord_caps(budget, len(mesh.faces))
    feats = timed("features", lambda: features.detect_features(mesh, region_gap=budget.allows("region_gap"),
                                                               ray_cap=ray_cap, dist_cap=dist_cap))
    if not (feats.thickness_coverage.minimum_exhaustive and feats.gap_coverage.minimum_exhaustive):
        warnings.append(f"thickness and gap minima taken over {feats.thickness_coverage.faces_cast} of "
                        f"{feats.thickness_coverage.faces_total} faces (an even stride), so each is an upper bound; "
                        f"percentiles over {'every face' if feats.thickness_coverage.every_face_tested else 'a systematic area-proportional sample'}")
    if budget.allows("symmetry"):
        ax, per_region = timed("axes", lambda: axes.detect_axes_full(mesh))
        for r, (rot_axis, rot_order) in zip(regs, per_region):
            r.rotational_axis, r.rotational_order = rot_axis, rot_order
    else:
        ax = _axes_fallback(mesh)
    #: THREE FACTS ABOUT THE TESSELLATION, not about the part. Each is optional in the schema and `None` there
    #: means NOT MEASURED. So a stage skipped for time must leave None and a stage that ran must leave an
    #: object, even an empty one: writing an empty list on a skip would tell the builder there is nothing there.
    #:
    #: AFTER SYMMETRY, AND THE ORDER IS THE COMPOSITION RULE. The budget is one clock and `allows` only asks
    #: whether any of it is left, so a stage placed ahead of symmetry can spend the part's remaining seconds
    #: and push symmetry out, and then `axes` is `_axes_fallback`: principal axes, no planes, no rotational
    #: order. The branch that added these three put them ahead of it, so on a slow part adding them could
    #: have changed the measurement's own axis. Here they run last and can only ever skip THEMSELVES, which
    #: `tests/test_measure_budget.py` pins.
    #:
    #: The chord stage opens and tessellates a STEP or IGES a second time (the loader keeps the mesh and drops
    #: the shape) and then projects up to about 40,000 chords onto their surfaces, so it is priced at a fixed
    #: part plus a multiple of the load and not started when that would overrun. On a triangle-only file it
    #: reads nothing and refuses by name, which costs nothing and is kept.
    #:
    #: AND NONE OF THE THREE CAN TAKE THE MEASUREMENT DOWN WITH IT. They are additive facts behind a schema
    #: that reads None as not measured, and every stage before them has already produced the facts a builder
    #: sizes from. An exception inside one (an OCCT surface class that will not evaluate, a ray cast that
    #: fails) used to propagate out of `measure` and fail the whole upload; now that stage is None and a
    #: warning says why.
    def optional(stage: str, fn):
        try:
            return timed(stage, fn)
        except Exception as exc:  # noqa: BLE001 - an optional fact is never worth the measurement
            warnings.append(f"{stage} not measured: {type(exc).__name__}: {str(exc)[:160]}")
            return None

    reads_twice = path.suffix.lower() in (load.STEP_SUFFIXES | load.IGES_SUFFIXES)
    spectrum = (optional("feature_edges", lambda: tessellation.feature_edge_spectrum(mesh))
                if budget.allows("feature_edges") else None)
    chord_cost = CHORD_BASE_S + CHORD_COST_OVER_LOAD * timings.get("load", 0.0) if reads_twice else 0.0
    chord = (optional("chord", lambda: tessellation.chord_deviation(path))
             if budget.allows("chord", expected_s=chord_cost) else None)
    iface_thick = (optional("interface_thickness",
                            lambda: tessellation.interface_thickness(mesh, region_of, ifaces, iface_mask))
                   if budget.allows("interface_thickness") else None)
    for stage in budget.skipped:
        if stage != "stubs":
            warnings.append(f"time budget of {time_budget_s:.0f}s exhausted after {budget.elapsed():.0f}s: {stage} skipped")

    facts = GeometryFacts(
        source_path=str(path), source_format=path.suffix.lower().lstrip("."), sha256=digest,
        faces=int(len(mesh.faces)), vertices=int(len(mesh.vertices)),
        watertight=watertight, total_surface_area=float(mesh.area),
        total_volume=float(sum(r.volume or 0.0 for r in regs)) if watertight else None,
        bbox=bbox,
        bodies=int(mesh.metadata.get("bodies", len(regs))),
        regions=regs,
        interfaces=ifaces,
        openings=ops,
        stubs=stbs,
        features=feats,
        axes=ax,
        units=units.unit_evidence(path, bbox.diagonal, _reference_diagonal(regs, ops, bbox.diagonal)),
        names=names.extract_names(path),
        cell_estimates=estimate.estimate_cells(mesh, purpose, watertight),
        warnings=warnings,
        timings={**timings, "total": round(budget.elapsed(), 3)},
        debris_components=debris,
        feature_edges=spectrum,
        chord=chord,
        interface_thickness=iface_thick,
        opening_gate=gate,
        measurement_revision=MEASUREMENT_REVISION,
    )
    # THE COVERAGE FACTS, last, for the reason the three optional stages above run last: they can only ever skip
    # themselves. They read the facts just built (openings, stubs, the edge spectrum), so they run on the
    # document, and they are measured without a representation, which the measurement does not decide:
    # `hexera.report_measured` rebuilds the places once it is known. Their own clock is capped, because a march
    # on a part with hundreds of mouths would otherwise take whatever the measurement left over
    if budget.allows("coverage"):
        from geometry_agent.facts import coverage as coverage_mod
        cov_s = min(COVERAGE_TIME_S, max(5.0, budget.left()))
        facts.coverage = optional("coverage", lambda: coverage_mod.measure_coverage(mesh, facts, time_budget_s=cov_s))
        if facts.coverage is not None:
            facts.coverage.places = []  # rebuilt with the representation; a place list without it is a guess
            # THE CLOCK LIVES IN `facts.timings` ONLY. Nested in the coverage record it made two measurements of one
            # file differ in a field every identity reader keeps (`learn.store.facts_sha256` drops the top-level
            # timings and nothing else), so the same bytes had a new identity every run
            timings.update({f"coverage_{k}": v for k, v in facts.coverage.timings.items()})
            facts.coverage.timings = {}
    else:
        # `facts.warnings`, NOT `warnings`: the model copied the local list when it was built a few lines above, so
        # a line appended to `warnings` from here on never reaches the document. This one did not, so a coverage
        # stage the clock skipped was skipped in silence
        facts.warnings.append(f"time budget of {time_budget_s:.0f}s exhausted after {budget.elapsed():.0f}s: "
                              "coverage skipped")
    # THE PASSAGE ENDS, last and optional like the coverage: they read the openings and their faces, which every
    # stage above has finished with, and they can only ever skip themselves
    # (into `facts.warnings` itself: the model copied the local list when it was built, so a line appended to
    # `warnings` from here on never reaches the document)
    if budget.allows("passage_ends"):
        t_ends = time.perf_counter()
        try:
            facts.passage_ends = measure_passage_ends(mesh, ops, op_faces)
        except Exception as exc:  # noqa: BLE001 - an optional fact is never worth the measurement
            facts.warnings.append(f"passage_ends not measured: {type(exc).__name__}: {str(exc)[:160]}")
        timings["passage_ends"] = round(time.perf_counter() - t_ends, 3)
    else:
        facts.warnings.append(f"time budget of {time_budget_s:.0f}s exhausted after {budget.elapsed():.0f}s: "
                              "passage_ends skipped")
    facts.timings = {**timings, "total": round(budget.elapsed(), 3)}
    # THE OVERRUN IS SAID LAST, AFTER EVERY STAGE, or it is not said at all. It used to be checked before the
    # coverage and the passage ends ran and written into the local `warnings` list that the model had already
    # copied, so a measurement that overran because of either of those two overran in silence. This is the same
    # sentence, moved to where the clock has stopped, and it now names what is MISSING from the record rather than
    # only what is left in it: on the 4.36M-face distributor the mandatory stages alone take 135 s against a
    # 120 s budget, so an overrun there is a fact about the file and the honest answer is to say which parts of
    # the record the budget cost, and which stage spent the time (`timings` carries every stage's seconds).
    if budget.elapsed() > budget.seconds:
        facts.warnings.append(overrun_warning(facts, budget.elapsed(), time_budget_s))
    if cache:
        write_cache(cache, facts.model_dump_json(indent=1))
    return facts


#: The stages `measure` never skips, in the order it runs them. A budget cannot take any of these away, so when
#: they alone overrun the budget the measurement says so and keeps them: a record missing its openings is not a
#: record. `estimates` is arithmetic on what they produced and costs nothing.
MANDATORY_STAGES: tuple[str, ...] = ("load", "connectivity", "regions", "interfaces", "openings", "stubs",
                                     "features", "estimates")


def missing_from(facts: GeometryFacts) -> list[str]:
    """Which parts of the record this measurement does not have, named as the fields a reader would look for.

    `None` means NOT MEASURED everywhere in the schema, so the absent parts can be listed from the document
    itself rather than from a list somebody keeps in step with it. A reader that gets the overrun warning is
    told which fields the clock cost, not only that there was an overrun."""
    absent = []
    if facts.axes.symmetry_measured is False:
        absent.append("axes.symmetry_* (the mirror planes and the rotational order)")
    for field in ("feature_edges", "chord", "interface_thickness", "coverage", "passage_ends"):
        if getattr(facts, field, None) is None:
            absent.append(f"{field}")
    # `min_gap_between_regions` is None BOTH when the stage was skipped and when the part has one body, so this
    # one field cannot say which on its own and the skip line is what separates them
    if any("region_gap skipped" in w for w in facts.warnings):
        absent.append("features.min_gap_between_regions (the gap between the closest two bodies)")
    return absent


def overrun_warning(facts: GeometryFacts, elapsed: float, time_budget_s: float) -> str:
    """One line for a measurement that took longer than its budget: by how much, which stages spent the time, and
    what the clock cost the record."""
    spent = sorted(((s, v) for s, v in facts.timings.items() if s != "total" and not s.startswith("coverage_")),
                   key=lambda kv: -kv[1])[:3]
    worst = ", ".join(f"{s} {v:.3g}s" for s, v in spent)
    absent = missing_from(facts)
    gap = ("; the record is missing " + ", ".join(absent)) if absent else "; nothing is missing from the record"
    return (f"the measurement took {elapsed:.0f}s against a time budget of {time_budget_s:.0f}s. The stages that "
            f"always run ({', '.join(MANDATORY_STAGES)}) are never skipped, so an overrun means they alone cost "
            f"more than the budget: the longest were {worst}{gap}")


#: How close a recomputed domain volume has to sit to the one the document recorded before the arithmetic is
#: accepted as reproduced. The estimate is float arithmetic over numbers the document rounds on the way to JSON,
#: so exact equality is not available; 1e-9 relative is far tighter than the gap between the two branches, which
#: is the external box at 2000 L^3 against the body.
REPRICE_MATCH_REL = 1e-9
#: The prefix of the one warning `_mixed_scale_warnings` writes, which is the other purpose-dependent thing in
#: the measurement: the units it calls plausible come from `units.PLAUSIBLE_DIAG_M[purpose]`.
MIXED_SCALE_PREFIX = "mixed scales: "
#: The line a repriced document carries, so the numbers say which purpose they are for and a reader is never left
#: to assume. `was` is what the measurement's own arithmetic says it was priced for.
REPRICED_WARNING = ("the cell estimates and the unit plausibility here were recomputed for purpose {now}; the "
                    "measurement priced them for {was} and the survey re-measures nothing, so a job with a "
                    "different purpose would otherwise have been priced on the wrong domain")


class PurposeMismatch(RuntimeError):
    """A document cannot be priced for the purpose the job has, and a wrong price is worse than no price.

    Raised rather than answered when the recorded estimate cannot be reproduced from the document's own numbers,
    which means the document was written by arithmetic this code does not know and repricing it would be a guess.
    """


def _reprice_inputs(facts: GeometryFacts) -> tuple[np.ndarray, float, float]:
    """The extent, the area and the BODY volume the estimate was computed from, read back off the document.

    The body volume is the enclosed volume when the surface closes and half the bounding box when it does not,
    which is `estimate._body_volume`'s own rule; `total_volume` is the sum of the regions' volumes and the
    enclosed volume is the same sum of the same per-face terms, so the two agree to float association order.
    """
    ext = np.asarray(facts.bbox.extent, dtype=float)
    if facts.watertight:
        if facts.total_volume is None:
            raise PurposeMismatch("this document is watertight and carries no total_volume, so the body volume "
                                  "the estimate was computed from cannot be read back")
        body = abs(float(facts.total_volume))
    else:
        body = float(np.prod(ext)) * 0.5
    return ext, float(facts.total_surface_area), body


def measured_for(facts: GeometryFacts) -> str:
    """WHICH PURPOSE BRANCH PRICED THIS DOCUMENT, derived from the document and not recorded in it.

    `estimate.estimate_cells` branches twice on the purpose: the domain volume is the external box minus the body
    on `external_cfd` and the body itself otherwise, and the prism layers are dropped on `structural`. Both
    branches leave their mark in the numbers the document already carries, so the purpose the estimate was
    computed under is a MEASUREMENT of the document rather than a field somebody has to have written:
    `domain_volume` says which volume rule ran and `layer_cells` says whether the layers did.

    Returns "external_cfd", "structural" or "internal" (the branch `internal_cfd` and `conjugate_heat_transfer`
    share). Raises `PurposeMismatch` when `domain_volume` matches neither rule, because then the document's own
    numbers do not come from arithmetic this code can redo."""
    ext, _area, body = _reprice_inputs(facts)
    if not facts.cell_estimates:
        raise PurposeMismatch("this document carries no cell estimates, so there is nothing to price from")
    external, _ = estimate._domain_from(ext, body, "external_cfd", facts.watertight)
    internal, _ = estimate._domain_from(ext, body, "internal_cfd", facts.watertight)
    recorded = float(facts.cell_estimates[0].domain_volume)

    def same(a: float, b: float) -> bool:
        return abs(a - b) <= REPRICE_MATCH_REL * max(abs(a), abs(b), 1e-300)

    if same(recorded, external) and not same(external, internal):
        return "external_cfd"
    if same(recorded, internal):
        return "structural" if all(e.layer_cells == 0 for e in facts.cell_estimates) and facts.total_surface_area > 0             else "internal"
    raise PurposeMismatch(f"the domain volume this document records ({recorded:.6g}) is neither the body "
                          f"({internal:.6g}) nor the external box minus it ({external:.6g}), so which purpose "
                          "priced it cannot be established and repricing it would be a guess")


def _same_branch(measured: str, purpose: Purpose) -> bool:
    """Do the measurement's branch and this purpose price the same way? The two flow purposes that are not
    external share one branch, so a document measured for `internal_cfd` is already right for
    `conjugate_heat_transfer` and nothing is recomputed."""
    if purpose == "external_cfd":
        return measured == "external_cfd"
    if purpose == "structural":
        return measured == "structural"
    return measured == "internal"


def repriced_for(facts: GeometryFacts, purpose: Purpose) -> GeometryFacts:
    """This document priced for the purpose the JOB has, which is not always the one it was measured under.

    THE MEASUREMENT HAS EXACTLY TWO PURPOSE-DEPENDENT THINGS: `cell_estimates` (`estimate.estimate_cells`) and
    the mixed-scale `warnings` (the units each body is plausible in come from `units.PLAUSIBLE_DIAG_M[purpose]`).
    Everything else it measures is the part. The survey measures once, at upload, and re-measures nothing by
    design, so an external job used to be priced on internal counts: the external branch is a different domain
    and a cell four levels coarser in the far field, which is not a margin, it is a different number.

    Both are recomputed here from the numbers the document already carries, so nothing is re-read and nothing is
    re-measured, and the document says in a warning which purpose its numbers are for. A document whose recorded
    estimate cannot be reproduced raises `PurposeMismatch` instead: refusing to price is acceptable and pricing
    on the wrong domain is not."""
    was = measured_for(facts)
    if _same_branch(was, purpose):
        return facts
    ext, area, body = _reprice_inputs(facts)
    out = facts.model_copy(deep=True)
    out.cell_estimates = estimate.estimate_cells_from(ext, area, body, purpose, facts.watertight)
    out.warnings = [w for w in out.warnings if not w.startswith(MIXED_SCALE_PREFIX)]
    out.warnings.extend(_mixed_scale_warnings(facts.regions, purpose))
    out.warnings.append(REPRICED_WARNING.format(now=purpose, was=was))
    return out


#: The line a document gets when its own estimate cannot be reproduced, so nothing can say which purpose priced
#: it. It does not touch the numbers: it says they are not vouched for, which is the refusal.
UNPRICEABLE_WARNING = ("the cell estimates here could not be confirmed to be for purpose {now}: {why}. They are "
                       "left as they are and nothing may read them as this purpose's price")


def priced_for(facts: GeometryFacts, purpose: Purpose) -> GeometryFacts:
    """`repriced_for` for a caller that must not be taken down by a document it did not write.

    Same recomputation where it is exact. Where `measured_for` cannot establish which purpose priced the document
    the numbers are left untouched and a warning says they are not this purpose's price, because a caller that
    stops dead on a hand-built or foreign document is a worse answer than one that says what it does not know.
    A caller that wants the refusal itself calls `repriced_for`. Idempotent: a repriced document is already on
    this purpose's branch, so a second call changes nothing."""
    try:
        return repriced_for(facts, purpose)
    except PurposeMismatch as exc:
        out = facts.model_copy(deep=True)
        line = UNPRICEABLE_WARNING.format(now=purpose, why=str(exc))
        if line not in out.warnings:
            out.warnings.append(line)
        return out


def _reference_diagonal(regs, ops, bbox_diagonal: float) -> float:
    """The body whose size the unit question is about. When the watertight bodies span more than
    MIXED_SCALE_RATIO the whole-file diagonal is meaningless: use the body carrying the port candidates (the
    fluid), else the largest closed body."""
    closed = [(float(np.linalg.norm(r.bbox_extent)), r) for r in regs if r.watertight]
    closed = [(d, r) for d, r in closed if d > 0]
    if len(closed) < 2:
        return bbox_diagonal
    small_d = min(d for d, _ in closed)
    big_d = max(d for d, _ in closed)
    if big_d <= MIXED_SCALE_RATIO * small_d:
        return bbox_diagonal
    ports_in: dict[str, int] = {}
    for o in ops:
        if o.classification == "port_candidate":
            ports_in[o.region_id] = ports_in.get(o.region_id, 0) + 1
    if ports_in:
        best = max(ports_in, key=ports_in.get)
        for d, r in closed:
            if r.id == best:
                return d
    return big_d


def _mixed_scale_warnings(regs, purpose: Purpose) -> list[str]:
    """One warning when the watertight bodies span more than MIXED_SCALE_RATIO in bounding diagonal. The largest
    and the smallest are named with their diagonals, and the units that make each plausible for the purpose, so
    the unit question is asked about the right body."""
    closed = [(float(np.linalg.norm(r.bbox_extent)), r) for r in regs if r.watertight]
    closed = [(d, r) for d, r in closed if d > 0]
    if len(closed) < 2:
        return []
    small_d, small = min(closed, key=lambda t: t[0])
    big_d, big = max(closed, key=lambda t: t[0])
    if big_d <= MIXED_SCALE_RATIO * small_d:
        return []
    lo, hi = units.PLAUSIBLE_DIAG_M.get(purpose, units.PLAUSIBLE_DIAG_M["structural"])

    def fits(d: float) -> str:
        ok = [u for u, f in units.TO_METRES.items() if lo <= d * f <= hi]
        return "/".join(ok) if ok else "no unit"

    return [f"mixed scales: {small.id} diagonal {small_d:.3g} (plausible in {fits(small_d)}) vs {big.id} {big_d:.3g} "
            f"(plausible in {fits(big_d)}), {big_d / small_d:.0f}x apart; the file mixes units or contains a stray part"]


def facts_to_json(facts: GeometryFacts) -> str:
    return json.dumps(facts.model_dump(mode="json"), indent=1)


def measure_isolated(path: str | Path, purpose: Purpose = "internal_cfd", cache_dir: str | Path = ".facts_cache",
                     time_budget_s: float = DEFAULT_TIME_BUDGET_S, timeout_s: float = 900.0) -> GeometryFacts:
    """measure() in a child process. A native crash in OCCT or trimesh, or a runaway allocation, then kills the
    child and raises here instead of taking down a corpus run of hundreds of files. The child writes the cache
    file; the parent reads it back."""
    path = Path(path)
    cache_dir = Path(cache_dir)
    cache_dir.mkdir(parents=True, exist_ok=True)
    cache = cache_dir / f"{load.sha256_of(path)}.{purpose}.v{FACTS_SCHEMA_VERSION}.json"
    cached = _read_cache(cache)
    if cached is not None:
        return cached
    # a stale entry is not overwritten (see measure): the child writes into a directory of its own instead
    scratch = None
    stale = _stale_revision(cache)
    if stale is not None:
        import tempfile
        scratch = tempfile.TemporaryDirectory(prefix="geometry-agent-restale-")
        cache_dir = Path(scratch.name)
        cache = cache_dir / cache.name
    try:
        facts = _measure_child(path, purpose, cache_dir, cache, time_budget_s, timeout_s)
    finally:
        if scratch is not None:
            scratch.cleanup()
    if stale is not None:
        facts.warnings.append(STALE_WARNING.format(old=stale))
    return facts


def _measure_child(path: Path, purpose: Purpose, cache_dir: Path, cache: Path, time_budget_s: float,
                   timeout_s: float) -> GeometryFacts:
    import subprocess
    import sys

    cmd = [sys.executable, "-m", "geometry_agent.facts.measure", str(path), "--purpose", purpose,
           "--cache-dir", str(cache_dir), "--time-budget", str(time_budget_s)]
    env = {**os.environ, **SINGLE_THREAD_ENV}
    attempts = 0
    while True:
        attempts += 1
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout_s, env=env)  # noqa: S603 (our own interpreter, fixed argv)
        except subprocess.TimeoutExpired as exc:
            raise load.UnsupportedGeometry(f"{path.name}: measurement exceeded {timeout_s:.0f}s and was killed") from exc
        if proc.returncode == 0 and cache.exists():
            fresh = _read_cache(cache)
            if fresh is not None:
                return fresh
        text = proc.stderr or proc.stdout or ""
        tail = " | ".join(text.strip().splitlines()[-3:])[:400]
        transient = proc.returncode in NATIVE_FAULT_CODES or "MemoryError" in text or "Memory allocation failed" in text
        if transient and attempts <= ISOLATED_RETRIES:
            time.sleep(RETRY_WAIT_S)
            continue
        retried = f" after {attempts} attempts" if attempts > 1 else ""
        raise load.UnsupportedGeometry(f"{path.name}: measurement process failed{retried} (rc {proc.returncode}): {tail}")


def _main(argv: list[str] | None = None) -> int:
    import argparse
    ap = argparse.ArgumentParser(prog="python -m geometry_agent.facts.measure")
    ap.add_argument("file")
    ap.add_argument("--purpose", default="internal_cfd")
    ap.add_argument("--cache-dir", default=None)
    ap.add_argument("--time-budget", type=float, default=DEFAULT_TIME_BUDGET_S)
    ap.add_argument("--print", action="store_true")
    a = ap.parse_args(argv)
    facts = measure(a.file, purpose=a.purpose, cache_dir=a.cache_dir, time_budget_s=a.time_budget)
    if a.print or not a.cache_dir:
        print(facts_to_json(facts))
    return 0


if __name__ == "__main__":
    raise SystemExit(_main())
