"""A transparent cell-count estimate per fidelity tier, so the budget conversation happens before dispatch."""
from __future__ import annotations

import numpy as np
import trimesh

from geometry_agent.facts.schema import CellEstimate, Fidelity, Purpose

TIERS: dict[Fidelity, dict] = {
    "draft": {"cells_across_diag": 40, "surface_levels": 1, "layers": 3},
    "standard": {"cells_across_diag": 80, "surface_levels": 2, "layers": 8},
    "max": {"cells_across_diag": 160, "surface_levels": 3, "layers": 15},
}
FILL = 0.7
BAND_CELLS = 3
EXTERNAL_BOX = (20.0, 10.0, 10.0)
FARFIELD_LEVELS = 4
NEAR_BOX_OVER_L = 2.0


def _signed_volume(mesh: trimesh.Trimesh) -> float:
    """The enclosed volume, v0 . (v1 x v2) / 6 summed: what trimesh's mass properties return as volume, without
    the inertia they compute with it (5.8 s on a 4.36M-face part, for a number this one line gives)."""
    from geometry_agent.facts.regions import _volume
    return _volume(mesh)


def _body_volume(ext: np.ndarray, signed: float, watertight: bool) -> float:
    """The body's own volume, which is the one input to the estimate that is not in the bounding box or the area:
    the enclosed volume when the surface closes, half the bounding box when it does not."""
    return float(abs(signed)) if watertight else float(np.prod(np.asarray(ext, dtype=float))) * 0.5


def _domain_from(ext: np.ndarray, body: float, purpose: Purpose, watertight: bool) -> tuple[float, str]:
    """`_domain_volume` over numbers instead of over a mesh, so the same arithmetic serves a repricing."""
    ext = np.asarray(ext, dtype=float)
    if purpose == "external_cfd":
        L = float(ext.max())
        box = EXTERNAL_BOX[0] * L * EXTERNAL_BOX[1] * L * EXTERNAL_BOX[2] * L
        return max(box - body, body), (f"external box {EXTERNAL_BOX[0]}L x {EXTERNAL_BOX[1]}L x {EXTERNAL_BOX[2]}L "
                                       "around the body minus the body")
    src = "enclosed volume" if watertight else "half the bounding box (surface is not watertight)"
    return body, src


def estimate_cells(mesh: trimesh.Trimesh, purpose: Purpose, watertight: bool) -> list[CellEstimate]:
    return estimate_cells_from(np.asarray(mesh.extents, dtype=float), float(mesh.area),
                               _body_volume(mesh.extents, _signed_volume(mesh), watertight), purpose, watertight)


def estimate_cells_from(ext: np.ndarray, area: float, body: float, purpose: Purpose,
                        watertight: bool) -> list[CellEstimate]:
    """The estimate from the four numbers it needs and nothing else: the bounding extent, the surface area, the
    body's own volume and the purpose.

    SPLIT OUT SO A JOB CAN BE PRICED FOR THE PURPOSE IT HAS. The estimate is the one purpose-dependent thing in
    the measurement and the survey re-measures nothing, so an external job used to be priced on the internal
    counts (`facts.measure.repriced_for` is what repairs that, and it calls this)."""
    ext = np.asarray(ext, dtype=float)
    diag = float(np.linalg.norm(ext))
    vol, vol_src = _domain_from(ext, body, purpose, watertight)
    L = float(ext.max())
    out = []
    for tier, cfg in TIERS.items():
        h = diag / cfg["cells_across_diag"]
        hs = h / (2 ** cfg["surface_levels"])
        if purpose == "external_cfd":
            h_far = h * 2**FARFIELD_LEVELS
            near = (NEAR_BOX_OVER_L * L) ** 3
            volume_cells = int(vol / h_far**3 * FILL + near / (2 * h) ** 3 * FILL)
            vol_note = f"far field at {FARFIELD_LEVELS} levels coarser than the body cell; a {NEAR_BOX_OVER_L}L near box one level coarser"
        else:
            volume_cells = int(vol / h**3 * FILL)
            vol_note = "uniform base cell through the domain"
        surface_cells = int(area * BAND_CELLS / hs**2)
        layer_cells = int(area * cfg["layers"] / hs**2) if purpose != "structural" else 0
        out.append(CellEstimate(
            tier=tier, base_size=float(h), surface_cell=float(hs), cells=volume_cells + surface_cells + layer_cells,
            surface_cells=surface_cells, volume_cells=volume_cells, layer_cells=layer_cells,
            domain_volume=float(vol),
            assumptions=[
                f"base cell = bbox diagonal / {cfg['cells_across_diag']}",
                f"{cfg['surface_levels']} surface refinement level(s), {BAND_CELLS}-cell band",
                f"{cfg['layers']} prism layers on all surfaces" if layer_cells else "no prism layers (structural)",
                f"domain volume from {vol_src}",
                vol_note,
                f"castellation fill {FILL}",
            ],
        ))
    return out
