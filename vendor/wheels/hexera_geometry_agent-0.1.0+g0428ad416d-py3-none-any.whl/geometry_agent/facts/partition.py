"""A named partition of the wall: the surface cut into patches at its real creases, each patch said to be a
plane, a cylinder, a cone, a sphere or free-form, and a radius fitted to the ones that have one.

WHY THIS EXISTS. The mesher authors patches and sets refinement per patch region, and the facts record had one
undifferentiated wall (`docs/joint_research.md`, gap 6): openings became inlet and outlet and everything else was
"wall". A builder cannot address "the cone of the inlet stub" or "the flat end of the chamber" when the only
name on offer is the whole surface.

THE METHOD AND WHAT BACKS IT. Creases by dihedral-angle thresholding, which Cazals et al. (GRAPP 2011) measured
at AUC 99.9 on clean CAD meshes, tied with a trained SVM (`docs/research_computational_geometry.md` section 7).
The hard part is not which edges but which threshold, and the tessellation facts already answer that honestly:
the crease threshold is the middle of the widest empty band of included angle that has edges on BOTH sides of
it (`crease_band`), so every edge on one side of the line is a crease and every edge on the other is not, and
moving the line anywhere inside the band would not change the partition. The partition is REFUSED when there
is no band that wide: then every degree moves the answer, and a partition drawn at an arbitrary degree would be a
fact that lies.

THE RADIUS, and why it is fitted and never estimated per vertex. Discrete mean curvature provably does not
converge on a tessellated cylinder (Wardetzky; section 4.1): it oscillates between about -3 and 0 as the mesh
refines, on vertices exactly on the surface, purely from the valence pattern. The same document names the
defensible alternative: a cylinder or sphere fitted over a coherent patch, with its residual reported and the
radius refused when the residual is large. That is what `radius` is. Per-vertex curvature is not emitted
anywhere (`coverage.VERTEX_CURVATURE_REFUSAL`).

WHAT IT CANNOT DO. A crease-free surface is one patch however many shapes it blends: an elbow's bore, its legs
and its bend are one smooth patch, which is `freeform` with no radius. That is true and it is coarse; the bend's
own radius comes from the centreline (`facts/centreline.py`), not from here. A crease shallower than the
tessellation's own facet angle (a 7 degree cone meeting a cylinder) is below the band and is not a crease here.

Nothing here reads a brief, a family, a file name or an answer key.
"""
from __future__ import annotations

from typing import Literal

import numpy as np
from pydantic import BaseModel, Field

Vec3 = tuple[float, float, float]

#: The narrowest empty band of included angle a crease threshold may sit in. Below it the angle distribution
#: runs through the window with no gap, and where the line is drawn decides the answer.
MIN_BAND_DEG = 5.0
#: Patches are listed largest first, up to this many; the rest are counted and their area summed.
MAX_LISTED = 32
#: Patches fitted for a surface type, largest first. A blade row can carry thousands of crease patches.
MAX_FITTED = 64
#: A patch is a plane when every face normal is within this many degrees of the area-weighted mean normal.
PLANE_DEG = 1.0
#: A patch is a cylinder or a cone when the spread of its normals along the fitted axis is below this, as a
#: cosine: normals of a cylinder are all perpendicular to its axis, a cone's all at one angle to it.
AXIS_SPREAD = 0.02
#: A fitted radius is REFUSED when the RMS distance of the patch's vertices from the fitted surface exceeds
#: this fraction of the radius.
MAX_FIT_RESIDUAL = 0.01
#: A patch whose normals turn by less than this about the fitted axis cannot fix a radius: a sliver of a
#: large cylinder is indistinguishable from a plane at CAD tolerance.
MIN_ARC_DEG = 20.0
#: Fewer faces than this and a curved patch is not fitted. A plane needs no minimum: two triangles with one
#: normal are a plane.
MIN_FIT_FACES = 6


class WallPatch(BaseModel):
    """One patch of the wall, bounded by creases. `surface` is what the fit says it is, and `radius` is None
    unless the fit was good enough to state one (`fit_residual` is reported either way)."""
    id: str
    region_id: str = ""
    faces: int
    area: float
    area_fraction: float
    centroid: Vec3
    bbox_min: Vec3
    bbox_max: Vec3
    surface: Literal["plane", "cylinder", "cone", "sphere", "freeform", "unfitted"]
    #: plane normal, or cylinder and cone axis
    axis: Vec3 | None = None
    radius: float | None = None
    half_angle_deg: float | None = None
    fit_residual: float | None = None
    why_no_radius: str = ""
    #: when this patch IS a measured opening's face, that opening's id
    opening_id: str | None = None
    #: openings whose face shares a crease with this patch
    borders: list[str] = Field(default_factory=list)
    neighbours: list[str] = Field(default_factory=list)


class WallPartition(BaseModel):
    status: Literal["measured", "refused"]
    why: str = ""
    #: the included angle the creases were cut at, and the empty band it is the middle of
    crease_included_deg: float | None = None
    band: tuple[float, float] | None = None
    patches: list[WallPatch] = Field(default_factory=list)
    patches_total: int = 0
    area_listed_fraction: float = 0.0
    #: The smallest radius the fits could state, and which patch it is on. None when no patch has one.
    smallest_radius: float | None = None
    smallest_radius_patch: str | None = None


def _vec(p) -> Vec3:
    return (float(p[0]), float(p[1]), float(p[2]))


def _labels(mesh, crease_normal_deg: float) -> np.ndarray:
    """Connected components of the faces over edges that are NOT creases."""
    from scipy.sparse import coo_matrix
    from scipy.sparse.csgraph import connected_components
    n = len(mesh.faces)
    adj = np.asarray(mesh.face_adjacency)
    ang = np.degrees(np.asarray(mesh.face_adjacency_angles, dtype=float))
    keep = ang < crease_normal_deg
    a, b = adj[keep, 0], adj[keep, 1]
    g = coo_matrix((np.ones(len(a)), (a, b)), shape=(n, n))
    _, labels = connected_components(g, directed=False)
    return labels


def _circle_2d(x: np.ndarray, y: np.ndarray) -> tuple[float, float, float] | None:
    a = np.column_stack([x, y, np.ones_like(x)])
    try:
        sol, *_ = np.linalg.lstsq(a, x * x + y * y, rcond=None)
    except np.linalg.LinAlgError:
        return None
    cx, cy = sol[0] / 2.0, sol[1] / 2.0
    r2 = sol[2] + cx * cx + cy * cy
    if not np.isfinite(r2) or r2 <= 0:
        return None
    r = float(np.sqrt(r2))
    for _ in range(15):
        dx, dy = x - cx, y - cy
        dist = np.hypot(dx, dy)
        if np.any(dist <= 0):
            break
        jac = np.column_stack([-dx / dist, -dy / dist, -np.ones_like(dist)])
        try:
            step, *_ = np.linalg.lstsq(jac, -(dist - r), rcond=None)
        except np.linalg.LinAlgError:
            break
        cx, cy, r = cx + step[0], cy + step[1], r + step[2]
        if float(np.abs(step).max()) < 1e-12 * max(abs(r), 1.0):
            break
    return (float(cx), float(cy), float(r)) if np.isfinite(r) and r > 0 else None


def _coverage_deg(angles: np.ndarray) -> float:
    """How much of the circle a set of directions covers: 360 less the widest gap between neighbours."""
    a = np.sort(np.mod(angles, 2 * np.pi))
    if len(a) < 2:
        return 0.0
    gaps = np.diff(np.concatenate([a, a[:1] + 2 * np.pi]))
    return float(np.degrees(2 * np.pi - gaps.max()))


def _sphere(pts: np.ndarray) -> tuple[np.ndarray, float] | None:
    a = np.column_stack([2 * pts, np.ones(len(pts))])
    try:
        sol, *_ = np.linalg.lstsq(a, (pts * pts).sum(axis=1), rcond=None)
    except np.linalg.LinAlgError:
        return None
    c = sol[:3]
    r2 = sol[3] + float(c @ c)
    if not np.isfinite(r2) or r2 <= 0:
        return None
    return c, float(np.sqrt(r2))


def _fit(patch: WallPatch, verts: np.ndarray, normals: np.ndarray, weights: np.ndarray) -> None:
    """Say what surface one patch is and, when the fit is good enough, its radius."""
    w = weights / (weights.sum() or 1.0)
    mean_n = (normals * w[:, None]).sum(axis=0)
    ln = float(np.linalg.norm(mean_n))
    if ln > 0:
        dev = np.degrees(np.arccos(np.clip(normals @ (mean_n / ln), -1.0, 1.0)))
        if float(dev.max()) <= PLANE_DEG:
            patch.surface, patch.axis = "plane", _vec(mean_n / ln)
            return
    # the axis is the direction the normals do not vary in: zero for a cylinder, and for a cone too once the
    # normals are centred, which is why they are (uncentred, a cone wider than 35 degrees hides its axis)
    centred = normals - mean_n
    if len(normals) < MIN_FIT_FACES:
        patch.why_no_radius = f"{len(normals)} faces, too few to fit a curved surface to"
        return
    m = (centred * w[:, None]).T @ centred
    vals, vecs = np.linalg.eigh(m)
    axis = vecs[:, 0]
    along = normals @ axis
    spread = float(np.sqrt(np.sum(w * (along - float(w @ along)) ** 2)))
    if spread <= AXIS_SPREAD:
        # how far the normals turn about the axis: a sliver of a cylinder cannot fix its radius
        e1 = vecs[:, 2]
        e2 = np.cross(axis, e1)
        turn = _coverage_deg(np.arctan2(normals @ e2, normals @ e1))
        mean_along = float(w @ along)
        cone = abs(mean_along) > AXIS_SPREAD
        patch.surface = "cone" if cone else "cylinder"
        patch.axis = _vec(axis)
        if cone:
            patch.half_angle_deg = float(np.degrees(np.arcsin(min(1.0, abs(mean_along)))))
            patch.why_no_radius = "a cone has a radius at every station and no single one"
            return
        if turn < MIN_ARC_DEG:
            patch.why_no_radius = (f"the patch turns by {turn:.0f} degrees about its axis, under {MIN_ARC_DEG:.0f}: "
                                   "too little arc to fix a radius")
            return
        rel = verts - verts.mean(axis=0)
        x, y = rel @ e1, rel @ e2
        circ = _circle_2d(x, y)
        if circ is None:
            patch.why_no_radius = "no circle could be fitted across the axis"
            return
        cx, cy, r = circ
        res = float(np.sqrt(np.mean((np.hypot(x - cx, y - cy) - r) ** 2))) / r
        patch.fit_residual = round(res, 5)
        if res > MAX_FIT_RESIDUAL:
            patch.why_no_radius = f"the vertices sit {res:.3f} of the radius off the fitted cylinder"
            return
        patch.radius = r
        return
    sph = _sphere(verts)
    if sph is not None:
        c, r = sph
        res = float(np.sqrt(np.mean((np.linalg.norm(verts - c, axis=1) - r) ** 2))) / r
        if res <= MAX_FIT_RESIDUAL:
            patch.surface, patch.radius, patch.fit_residual = "sphere", r, round(res, 5)
            return
    patch.surface = "freeform"
    patch.why_no_radius = ("doubly curved and not one sphere: a per-vertex curvature here would be the "
                           "tessellation's and not the part's, so none is given")


def _opening_match(patch: WallPatch, openings: list, diag: float) -> str | None:
    if patch.surface != "plane":
        return None
    c = np.asarray(patch.centroid)
    for o in openings:
        area = float(o.area or 0.0)
        if area <= 0:
            continue
        if (np.linalg.norm(np.asarray(o.centroid) - c) <= 0.01 * diag
                and abs(patch.area / area - 1.0) <= 0.05):
            return str(o.id)
    return None


#: The included-angle window a crease threshold can sit in, `tessellation.BAND_WINDOW`'s numbers.
WINDOW = (20.0, 175.0)
#: When no gap separates two populations of edges, the surface is smooth only if every edge in the window is
#: within this many degrees of flat: all facets of curved faces. Anything sharper with no gap is refused.
FACETS_ONLY_DEG = 150.0


def crease_band(mesh) -> tuple[tuple[float, float] | None, str]:
    """The empty band of included angle the crease threshold sits in, or None and why not.

    WHY NOT `FeatureEdgeSpectrum.widest_empty_band` AS IT STANDS. That band is the widest run with no edge in it
    ANYWHERE in the window, and on a coarse part it is the run below every edge: on `ahmed_variant_001` (160
    triangles) it was 20 to 90 degrees, so the threshold sat at 55, the body's 90 degree base edges were on the
    facet side, and the whole Ahmed body came back as one patch. A threshold has to sit BETWEEN two populations
    to separate them, so this takes the widest empty band with an edge on each side of it. When there is none,
    the surface is one population: smooth (every edge within `FACETS_ONLY_DEG` of flat, no creases) or refused
    (edges spread down into sharp angles with no gap anywhere, the accordion case)."""
    ang = np.degrees(np.asarray(mesh.face_adjacency_angles, dtype=float))
    if not len(ang):
        return (WINDOW[0], WINDOW[1]), ""
    faces = np.asarray(mesh.faces)
    adj = np.asarray(mesh.face_adjacency)
    from geometry_agent.facts.tessellation import _wound_against
    against = _wound_against(faces, adj, np.asarray(mesh.face_adjacency_edges))
    included = np.clip(180.0 - ang[~against], 0.0, 180.0)
    lo, hi = WINDOW
    inside = np.sort(included[(included >= lo) & (included <= hi)])
    if len(inside):
        # the gaps between neighbouring edges, and the one between the flattest edge and the top of the window:
        # above that are the flat and near-flat facets, so a band there makes every edge in the window a crease
        # (a box). The run below the sharpest edge is never a candidate: it separates nothing from everything
        tops = np.append(inside[1:], hi)
        gaps = tops - inside
        k = int(np.argmax(gaps))
        if gaps[k] >= MIN_BAND_DEG:
            return (float(inside[k]), float(tops[k])), ""
    if not len(inside) or float(inside[0]) >= FACETS_ONLY_DEG:
        # one population, all near flat: a smooth surface with no crease. The band is everything below it
        top = float(inside[0]) if len(inside) else hi
        return (lo, top), ""
    return None, (f"no band of {MIN_BAND_DEG:.0f} degrees or more separates two populations of edges, and the "
                  f"sharpest edge is at {float(inside[0]):.0f} degrees: the creases and the facets are not "
                  "separable here, so any threshold would decide the partition rather than the part")


def partition(mesh, facts=None, spectrum=None, region_of: np.ndarray | None = None) -> WallPartition:
    """The wall cut at its creases, or a refusal saying why it cannot be cut honestly.

    `spectrum` is the facts' `FeatureEdgeSpectrum`; when it is None (a document measured before it existed)
    the spectrum is measured here from the same mesh with the same function."""
    faces = np.asarray(mesh.faces)
    if not len(faces):
        return WallPartition(status="refused", why="no mesh")
    if spectrum is None:
        from geometry_agent.facts.tessellation import feature_edge_spectrum
        spectrum = feature_edge_spectrum(mesh)
    if spectrum.inconsistent_edges:
        return WallPartition(status="refused",
                             why=(f"{spectrum.inconsistent_edges} edges join faces wound against each other, so "
                                  "their angle cannot be read and a crease there cannot be decided"))
    band, why = crease_band(mesh)
    if band is None:
        return WallPartition(status="refused", why=why)
    included = 0.5 * (band[0] + band[1])
    labels = _labels(mesh, 180.0 - included)
    area_f = np.asarray(mesh.area_faces, dtype=float)
    total = float(area_f.sum()) or 1.0
    per_label = np.bincount(labels, weights=area_f)
    order = np.argsort(-per_label)
    order = order[per_label[order] > 0]
    ids = {int(lab): f"w{k + 1}" for k, lab in enumerate(order)}
    v = np.asarray(mesh.vertices, dtype=np.float64)
    fn = np.asarray(mesh.face_normals, dtype=np.float64)
    diag = float(np.linalg.norm(v.max(axis=0) - v.min(axis=0))) or 1.0
    openings = list(getattr(facts, "openings", []) or [])
    region = region_of if region_of is not None and len(region_of) == len(faces) else None
    patches: list[WallPatch] = []
    for k, lab in enumerate(order[:MAX_LISTED]):
        sel = np.flatnonzero(labels == lab)
        vi = np.unique(faces[sel].ravel())
        pv = v[vi]
        centroid = (mesh.triangles_center[sel] * area_f[sel, None]).sum(axis=0) / (area_f[sel].sum() or 1.0)
        p = WallPatch(id=ids[int(lab)], faces=int(len(sel)), area=float(per_label[lab]),
                      area_fraction=float(per_label[lab] / total), centroid=_vec(centroid),
                      bbox_min=_vec(pv.min(axis=0)), bbox_max=_vec(pv.max(axis=0)), surface="unfitted",
                      region_id=(f"r{int(np.bincount(region[sel]).argmax()) + 1}" if region is not None else ""))
        if k < MAX_FITTED:
            _fit(p, pv, fn[sel], area_f[sel])
        p.opening_id = _opening_match(p, openings, diag)
        patches.append(p)
    # neighbours and borders, over the crease edges between listed patches
    adj = np.asarray(mesh.face_adjacency)
    la, lb = labels[adj[:, 0]], labels[adj[:, 1]]
    across = la != lb
    by_id = {p.id: p for p in patches}
    opening_of = {p.id: p.opening_id for p in patches if p.opening_id}
    pairs = {(int(a), int(b)) for a, b in zip(la[across], lb[across])}
    for a, b in pairs:
        pa, pb = ids.get(a), ids.get(b)
        if pa in by_id and pb in by_id:
            if pb not in by_id[pa].neighbours:
                by_id[pa].neighbours.append(pb)
            if pa not in by_id[pb].neighbours:
                by_id[pb].neighbours.append(pa)
            if pb in opening_of and opening_of[pb] not in by_id[pa].borders:
                by_id[pa].borders.append(opening_of[pb])
            if pa in opening_of and opening_of[pa] not in by_id[pb].borders:
                by_id[pb].borders.append(opening_of[pa])
    for p in patches:
        p.neighbours.sort(key=lambda s: int(s[1:]))
        p.borders.sort()
    radii = [(p.radius, p.id) for p in patches if p.radius]
    smallest = min(radii) if radii else (None, None)
    return WallPartition(status="measured", crease_included_deg=float(included), band=(float(band[0]), float(band[1])),
                         patches=patches, patches_total=int(len(order)),
                         area_listed_fraction=float(per_label[order[:MAX_LISTED]].sum() / total),
                         smallest_radius=smallest[0], smallest_radius_patch=smallest[1])
