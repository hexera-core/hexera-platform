"""Entity names the CAD author left in the file. Free evidence when present, silent when absent.

STEP carries names on faces, shells, solids and products. An STL carries at most one: the `solid NAME` line of an
ASCII file, or whatever printable text an exporter put in the 80-byte binary header (most write a banner, which
is not a name). An OBJ names its objects and groups (`o`, `g`)."""
from __future__ import annotations

import re
from pathlib import Path

from geometry_agent.facts.schema import NamedEntity

_ENTITY = re.compile(
    r"#\d+\s*=\s*(ADVANCED_FACE|MANIFOLD_SOLID_BREP|SHELL_BASED_SURFACE_MODEL|PRODUCT|CLOSED_SHELL|OPEN_SHELL|FACE_SURFACE)"
    r"\s*\(\s*'([^']*)'",
    re.I,
)

_ROLES: list[tuple[re.Pattern, str]] = [
    (re.compile(r"\b(inlet|intake|in_?\d*|entry|supply)\b", re.I), "inlet"),
    (re.compile(r"\b(outlet|exhaust|exit|out_?\d*|discharge|return)\b", re.I), "outlet"),
    (re.compile(r"\b(sym|symmetry|mirror)\w*", re.I), "symmetry"),
    (re.compile(r"\b(far ?field|domain|box|tunnel|freestream)\b", re.I), "farfield"),
    (re.compile(r"\b(interface|coupled|ami|contact)\b", re.I), "interface"),
    (re.compile(r"\b(rotor|rotating|impeller|mrf|propeller)\b", re.I), "rotating_zone"),
    (re.compile(r"\b(wall|body|solid|blade|hub|casing|housing)\b", re.I), "wall"),
]

#: Header text an exporter writes for every file: a banner, not the part's name. Matched at the start of the
#: header after whitespace; anything else printable is taken as a name.
_STL_BANNER = re.compile(
    r"^(binary\s*stl|stl\b|solid\s*$|exported|created|generated|written|produced|file\s*type|numpy-stl|trimesh|"
    r"openscad|blender|solidworks|autodesk|fusion|meshlab|meshmixer|3d\s*systems|materialise|color\s*=|material\s*=|"
    r"visual\s*=|stlb|stla|ascii|vcg|magics|netfabb|cura|prusa|inventor|catia|creo|ptc|siemens|nx\b|rhino|"
    r"freecad|onshape|shapr|tinkercad|sketchup|matlab|gmsh|openfoam|paraview|vtk)",
    re.I,
)
#: How much of an STL is read to tell ASCII from binary and find the solid line.
_STL_PROBE_BYTES = 1024
#: How much of an OBJ is scanned for object and group names.
_OBJ_SCAN_BYTES = 64 << 20


def implied_role(name: str) -> str | None:
    norm = re.sub(r"[_\-.:/]+", " ", name)
    norm = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", norm)
    for pat, role in _ROLES:
        if pat.search(norm):
            return role
    return None


def extract_names(path: Path, limit: int = 64) -> list[NamedEntity]:
    suffix = path.suffix.lower()
    if suffix in {".step", ".stp"}:
        return _step_names(path, limit)
    if suffix == ".stl":
        return _stl_names(path)
    if suffix == ".obj":
        return _obj_names(path, limit)
    return []


def _step_names(path: Path, limit: int) -> list[NamedEntity]:
    try:
        text = path.read_text(errors="ignore")
    except OSError:
        return []
    seen: set[tuple[str, str]] = set()
    out: list[NamedEntity] = []
    for m in _ENTITY.finditer(text):
        entity, name = m.group(1).upper(), m.group(2).strip()
        if not name or (entity, name) in seen or name.lower() in {"none", "null", ""}:
            continue
        seen.add((entity, name))
        out.append(NamedEntity(name=name, entity=entity, implied_role=implied_role(name)))
        if len(out) >= limit:
            break
    return out


def _clean_name(raw: str) -> str | None:
    """Printable, non-empty, not an exporter banner, not a bare file name of the generic kind."""
    name = "".join(ch for ch in raw if ch.isprintable()).strip().strip("\x00").strip()
    if not name or not any(ch.isalnum() for ch in name):
        return None
    if _STL_BANNER.match(name):
        return None
    return name


def stl_solid_name(path: Path) -> str | None:
    """The `solid NAME` of an ASCII STL, or the printable text of a binary STL's 80-byte header when it is not an
    exporter banner. None when the file names nothing."""
    try:
        with path.open("rb") as f:
            head = f.read(_STL_PROBE_BYTES)
    except OSError:
        return None
    if not head:
        return None
    if head.lstrip().lower().startswith(b"solid") and b"facet" in head.lower():
        first = head.lstrip().split(b"\n", 1)[0].decode("latin-1")
        return _clean_name(first[len("solid"):])
    header = head[:80].decode("latin-1")
    return _clean_name(header)


def _stl_names(path: Path) -> list[NamedEntity]:
    name = stl_solid_name(path)
    if name is None:
        return []
    return [NamedEntity(name=name, entity="STL_SOLID", implied_role=implied_role(name))]


_OBJ_NAME = re.compile(rb"^\s*([og])\s+(.+?)\s*$", re.M)


def _obj_names(path: Path, limit: int) -> list[NamedEntity]:
    try:
        with path.open("rb") as f:
            data = f.read(_OBJ_SCAN_BYTES)
    except OSError:
        return []
    seen: set[tuple[str, str]] = set()
    out: list[NamedEntity] = []
    for m in _OBJ_NAME.finditer(data):
        entity = "OBJ_OBJECT" if m.group(1) == b"o" else "OBJ_GROUP"
        name = _clean_name(m.group(2).decode("latin-1"))
        if name is None or (entity, name) in seen or name.lower() in {"default", "off"}:
            continue
        seen.add((entity, name))
        out.append(NamedEntity(name=name, entity=entity, implied_role=implied_role(name)))
        if len(out) >= limit:
            break
    return out
