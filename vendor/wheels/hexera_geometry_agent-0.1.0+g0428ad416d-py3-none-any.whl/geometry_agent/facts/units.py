"""What unit the file claims, and which units would make the size plausible for the stated purpose."""
from __future__ import annotations

import re
from pathlib import Path

from geometry_agent.facts.schema import UnitEvidence

TO_METRES = {"m": 1.0, "mm": 1e-3, "cm": 1e-2, "in": 0.0254, "ft": 0.3048}

PLAUSIBLE_DIAG_M = {
    "internal_cfd": (0.005, 5.0),
    "external_cfd": (0.05, 150.0),
    "conjugate_heat_transfer": (0.005, 5.0),
    "structural": (0.001, 50.0),
}

#: The unit context of a STEP file normally sits in the first entities. Creo writes it after the geometry (at
#: 37 MB of a 42 MB assembly), so a declaration found past this many bytes is reported as `step_body`.
STEP_HEADER_BYTES = 200_000
#: Files are scanned in windows of this size, overlapped by STEP_UNIT_OVERLAP so a declaration split across a
#: window boundary is still seen whole; a 42 MB file is a dozen regex passes over bytes, no decoding.
STEP_SCAN_WINDOW = 8 << 20
STEP_UNIT_OVERLAP = 4096

_STEP_UNIT = re.compile(rb"SI_UNIT\s*\(\s*(\.\w+\.|\$)\s*,\s*\.(METRE|INCH|FOOT)\.\s*\)", re.I)
_STEP_CONV = re.compile(rb"CONVERSION_BASED_UNIT\s*\(\s*'([^']+)'", re.I)


def _unit_in(chunk: bytes) -> str | None:
    m = _STEP_CONV.search(chunk)
    if m:
        name = m.group(1).lower()
        if b"inch" in name:
            return "in"
        if b"foot" in name or b"feet" in name:
            return "ft"
    m = _STEP_UNIT.search(chunk)
    if not m:
        return None
    prefix, base = m.group(1).upper(), m.group(2).upper()
    if base == b"INCH":
        return "in"
    if base == b"FOOT":
        return "ft"
    return {b".MILLI.": "mm", b".CENTI.": "cm", b"$": "m"}.get(prefix, "m")


def declared_unit(path: Path) -> tuple[str | None, str]:
    """The length unit a STEP file declares and where it was found: `step_header` within the first
    STEP_HEADER_BYTES, `step_body` anywhere after (the whole file is scanned in windows), `none` otherwise."""
    if path.suffix.lower() not in {".step", ".stp"}:
        return None, "none"
    try:
        with path.open("rb") as f:
            head = f.read(STEP_HEADER_BYTES)
            unit = _unit_in(head)
            if unit is not None:
                return unit, "step_header"
            tail = head[-STEP_UNIT_OVERLAP:]
            while True:
                chunk = f.read(STEP_SCAN_WINDOW)
                if not chunk:
                    return None, "none"
                unit = _unit_in(tail + chunk)
                if unit is not None:
                    return unit, "step_body"
                tail = chunk[-STEP_UNIT_OVERLAP:]
    except OSError:
        return None, "none"


def unit_evidence(path: Path, bbox_diagonal: float, reference_diagonal: float | None = None) -> UnitEvidence:
    """Which units make the part a plausible size for each purpose. `reference_diagonal` is the body the question
    is really about when the file mixes scales (the fluid body beside a stray bracket in another unit): the
    plausibility is judged on it instead of the whole file's bounding box."""
    declared, source = declared_unit(path)
    candidates: list[tuple[str, float]] = []
    plausible: dict[str, list[str]] = {p: [] for p in PLAUSIBLE_DIAG_M}
    ref = reference_diagonal if reference_diagonal and reference_diagonal > 0 else bbox_diagonal
    for unit, f in TO_METRES.items():
        diag_m = ref * f
        score = 0.0
        for purpose, (lo, hi) in PLAUSIBLE_DIAG_M.items():
            if lo <= diag_m <= hi:
                plausible[purpose].append(unit)
                score += 1.0
        if declared == unit:
            score += 2.0
        candidates.append((unit, score))
    order = {"mm": 0, "m": 1, "in": 2, "cm": 3, "ft": 4}
    candidates.sort(key=lambda c: (-c[1], order[c[0]]))
    return UnitEvidence(declared=declared, declared_source=source, candidates=candidates, plausible_for_purpose=plausible)
