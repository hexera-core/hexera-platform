"""Principal axes, mirror and rotational symmetry, and which end is blunt: the geometric evidence for identity
and orientation.

How a symmetry is scored: a seeded surface sample is reflected (or rotated) and the fraction of it that lands
within SYMMETRY_TOL_OF_DIAG of the surface is the score, with the surface held as a k-d tree over a dense
point cloud (`_SurfaceDistance`; never a bulk closest-point query). Every query carries the tolerance as its
distance upper bound: the answer needed is "within tol or not", and an unbounded nearest-neighbour search for
a point thrown deep inside a thin shell (a half-turn about a transverse axis does that to every sample) visits
thousands of equidistant leaves, 0.7 s per call against 4 ms bounded.

Mirror planes. Three things changed from the plain "score the three principal normals" rule:
  * A plane is accepted only if every sizeable body passes it on its own (`_MirrorTest.accept`): on a 2.7 m
    rocket tube three small fins cannot drag an area-weighted score below the threshold, so y = 0 scored 0.93
    with a fin pointing at -y and nothing at +y. The score reported for a plane is the weakest body's.
  * When two principal variances are within DEGENERATE_VARIANCE_REL of each other, the eigenvectors in the
    plane they span are arbitrary (a square duct, a disc, anything axisymmetric), so mirror normals are also
    searched inside that plane: the projected world axes, a coarse sweep every SWEEP_STEP_DEG, and a refinement
    of each peak in SWEEP_REFINE_DEG steps. The principal frame is realigned to the best normal found, so
    `principal` and `symmetry_scores` describe a canonical frame, and every accepted plane is reported with its
    world normal in `symmetry_normals` (one per entry of `symmetry_planes`; the int is the nearest principal
    axis, repeated when a disc has six planes).
  * A body that passes every direction in the sweep (more than AXISYMMETRIC_PLANES distinct normals) is
    axisymmetric about the third axis; it reports two orthogonal in-plane planes, world-aligned when possible,
    instead of thirty-six.

Rotational order. Scores are computed for every order in ROTATION_ORDERS about an axis and an order is
accepted only when it is within ROTATION_SCORE_MARGIN of the best order's score (and over ROTATION_SCORE_MIN);
the highest accepted order is reported. A disc plenum carrying 61 nozzles on a hex lattice passes every order
at the disc's share of the area (0.90) and only 2, 3 and 6 at 1.00; the old rule (highest order over 0.9)
called it 12-fold. Besides the per-body search the whole assembly is rotated about its own principal axes and
about the axis of each axisymmetric body: three fins at 120 degrees are three 2-fold plates on their own and a
3-fold set together. The higher sub-axisymmetric order wins (assembly on ties); the per-body result is kept
when the whole assembly only shows the axisymmetric order (a small hex nut on a big round shaft).

Constants (why these values):
  SYMMETRY_TOL_OF_DIAG 0.01     a reflected sample point counts when within 1% of the diagonal of the surface.
  SYMMETRY_SCORE_MIN 0.92       92% of the sample must land: tessellation and sampling noise take a few percent.
  ROTATION_SCORE_MIN 0.9        as above for rotations, a little looser because blade tips are thin.
  ROTATION_SCORE_MARGIN 0.03    orders scoring within 0.03 of the best are equally supported by the surface.
  DEGENERATE_VARIANCE_REL 0.02  variances within 2% are equal for an area-weighted covariance of a sampled mesh.
  SWEEP_STEP_DEG 2              90 evaluations. A disc's rim reflected in a plane one degree off moves 1.7% of
                                the diagonal, past the tolerance, so a real plane between grid angles scores
                                low but still peaks against its neighbours; the peaks are what get refined.
  SWEEP_SEED_MIN 0.3            a grid peak below this is sampling noise on a body with no plane there.
  MAX_SWEEP_SEEDS 24            peaks refined, best first; twice the largest rotation order tested.
  SWEEP_REFINE_DEG (1, .25, .1) hill-climb steps that pin a plane to 0.1 degrees, inside the tolerance for a
                                body whose radius is half its diagonal.
  PLATEAU_STEP_DEG 0.5          a refined peak sits somewhere on a plateau (a 12-face box scores 1.0 for two
  PLATEAU_DROP 0.02             degrees either side of its true plane, three thin fins on a 2.7 m tube for
  PLATEAU_MAX_DEG 10            eight); the plateau is walked in half-degree steps, up to ten degrees each
                                way, while the score stays within 0.02 of the peak (a 3000-point sample is
                                noisy to about 0.01) and its centre is taken as the plane; when a projected
                                world axis lies on that plateau it is taken instead (a square duct's mid-plane
                                is x = 0 exactly, not 0.1 degrees off it), and on a tie between accepted
                                normals the frame is realigned to the most world-aligned one.
  PLANE_MERGE_DEG 5             normals closer than this are one plane found twice; the tightest pattern
                                tested (12-fold) puts planes 15 degrees apart.
  AXISYMMETRIC_PLANES 12        more distinct in-plane mirror normals than the largest rotation order tested
                                means every direction works: the body is round about the third axis.
  AXISYMMETRIC_GRID_FRACTION .8 the same conclusion from the sweep itself: a 12-fold body passes about a
                                third of the grid angles (twelve plateaux of a few degrees), a round one all.
  REGION_MIN_SAMPLES 200        the fewest sample points on which a body's own score is trusted to veto a plane.
  RESIDUAL_MIN_POINTS 100       the fewest off-axis sample points (3% of the sample) that count as features
                                worth testing a plane against; fewer is tessellation noise on a round body.
  MAX_SYMMETRY_REGIONS 16       bodies checked one by one for a plane, largest first; the rest are covered by
                                the whole-surface sample (an assembly of 400 bodies stays cheap).
"""
from __future__ import annotations

import numpy as np
import trimesh
from scipy.spatial import cKDTree
from trimesh.transformations import rotation_matrix

from geometry_agent.facts.schema import Axes
from geometry_agent.facts.stubs import _chain_segments, _loop_area_normal

SYMMETRY_TOL_OF_DIAG = 0.01
#: A flat or slender body's mirror test must not be looser than a fraction of its smallest extent: at 1% of a
#: 6.7 m hull's diagonal (68 mm) almost every reflected point of a 0.4 m deep hull lands on the surface and a
#: false mid-length plane appears. The tolerance never drops below twice the surface cloud's spacing, so a thin
#: fin plate is still tested at the resolution the cloud can support.
SYMMETRY_TOL_OF_MIN_EXTENT = 0.05
CLOUD_SPACING_FLOOR = 2.0


def _symmetry_tol(mesh: trimesh.Trimesh, dist: _SurfaceDistance | None = None) -> float:
    ext = np.asarray(mesh.extents, dtype=float)
    diag = float(np.linalg.norm(ext))
    positive = ext[ext > 1e-9 * diag] if diag > 0 else ext
    smallest = float(positive.min()) if len(positive) else diag
    tol = min(SYMMETRY_TOL_OF_DIAG * diag, SYMMETRY_TOL_OF_MIN_EXTENT * smallest)
    if dist is not None and dist.spacing > 0:
        tol = max(tol, CLOUD_SPACING_FLOOR * dist.spacing)
    return max(tol, 1e-9 * diag)
SYMMETRY_SCORE_MIN = 0.92
ROTATION_SCORE_MIN = 0.9
ROTATION_SCORE_MARGIN = 0.03
ROTATION_ORDERS = range(2, 13)
END_FRACTION = 0.06
SAMPLE_POINTS = 3000
CLOUD_MIN_SAMPLES = 60_000
CLOUD_MAX_POINTS = 250_000
DEGENERATE_VARIANCE_REL = 0.02
SWEEP_STEP_DEG = 2.0
SWEEP_REFINE_DEG = (1.0, 0.25, 0.1)
SWEEP_SEED_MIN = 0.3
MAX_SWEEP_SEEDS = 24
PLATEAU_STEP_DEG = 0.5
PLATEAU_DROP = 0.02
PLATEAU_MAX_DEG = 10.0
PLANE_MERGE_DEG = 5.0
AXISYMMETRIC_PLANES = 12
AXISYMMETRIC_GRID_FRACTION = 0.8
REGION_MIN_SAMPLES = 200
RESIDUAL_MIN_POINTS = 100
MAX_SYMMETRY_REGIONS = 16
MAX_ROTATION_REGIONS = 8
#: Whole-assembly rotation is also tried about the axes of this many axisymmetric bodies (largest first).
MAX_ASSEMBLY_AXES = 2


PRINCIPAL_CHUNK = 400_000


_PRINCIPAL_ATTR = "_geometry_agent_principal"


def _principal(mesh: trimesh.Trimesh) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Area-weighted centroid and the exact second moments of the surface. Treating each triangle as a point mass
    at its centre is wrong on coarse triangulations (a box built from 44 big triangles came out 20 degrees off
    its own edges); the exact moment of a triangle with centred vertices v0, v1, v2 is
    (A/12) (sum v v^T + s s^T) with s = v0 + v1 + v2.

    Kept on the mesh once computed: the symmetry stage asked for the same mesh's moments twice, and on a
    4.36M-face part each pass was five seconds of the same arithmetic. Copies are returned, so a caller that
    flips a vector does not change the next caller's answer."""
    cached = getattr(mesh, _PRINCIPAL_ATTR, None)
    if cached is not None and cached[0] == len(mesh.faces):
        return tuple(a.copy() for a in cached[1])
    out = _principal_of(mesh)
    try:
        setattr(mesh, _PRINCIPAL_ATTR, (len(mesh.faces), tuple(a.copy() for a in out)))
    except AttributeError:
        pass
    return out


def _principal_of(mesh: trimesh.Trimesh) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    A = np.asarray(mesh.area_faces, dtype=float)
    total = float(A.sum()) or 1.0
    w = A / total
    mean = np.average(mesh.triangles_center, axis=0, weights=w)
    cov = np.zeros((3, 3))
    tri = mesh.triangles
    for start in range(0, len(tri), PRINCIPAL_CHUNK):
        d = np.asarray(tri[start:start + PRINCIPAL_CHUNK], dtype=float) - mean
        wk = w[start:start + PRINCIPAL_CHUNK] / 12.0
        s = d.sum(axis=1)
        cov += np.einsum("f,fij,fik->jk", wk, d, d) + np.einsum("f,fj,fk->jk", wk, s, s)
    vals, vecs = np.linalg.eigh(cov)
    order = np.argsort(vals)[::-1]
    vals, vecs = vals[order], vecs[:, order]
    for k in range(3):
        if vecs[np.argmax(np.abs(vecs[:, k])), k] < 0:
            vecs[:, k] *= -1
    if np.linalg.det(vecs) < 0:
        vecs[:, 2] *= -1
    return mean, vals, vecs


class _SurfaceDistance:
    """Distance from points to the surface, as distance to a dense point cloud on it: vertices, face centres and
    a uniform surface sample, in a k-d tree. Within half the sample spacing of exact, which is inside the
    symmetry tolerance. trimesh's exact closest-point query gathers every candidate triangle per query point and
    on a plate of 100 thin tubes (20k faces) that was 19 million candidates and 7 GB; it is not used anywhere.
    `upper` bounds the search: distances at or past it come back as inf, which is all a threshold test needs
    and what keeps a query for points far off the surface from walking the whole tree."""

    def __init__(self, mesh: trimesh.Trimesh, seed: int = 0):
        area = float(mesh.area)
        diag = float(np.linalg.norm(mesh.extents))
        # enough samples that the cloud spacing sits inside the symmetry tolerance: 4 points per tolerance square
        tol = SYMMETRY_TOL_OF_DIAG * diag
        wanted = 4.0 * area / (tol * tol) if tol > 0 else 0.0
        n_samples = int(min(CLOUD_MAX_POINTS, max(CLOUD_MIN_SAMPLES, 4 * len(mesh.faces), wanted)))
        samples, _ = trimesh.sample.sample_surface(mesh, n_samples, seed=seed)
        cloud = np.vstack([mesh.vertices, mesh.triangles_center, samples])
        if len(cloud) > 2 * CLOUD_MAX_POINTS:
            cloud = cloud[:: len(cloud) // (2 * CLOUD_MAX_POINTS) + 1]
        self.spacing = float(np.sqrt(area / max(len(cloud), 1)))
        self.tree = cKDTree(cloud)

    def __call__(self, pts: np.ndarray, upper: float | None = None) -> np.ndarray:
        if upper is None:
            return self.tree.query(pts)[0]
        return self.tree.query(pts, distance_upper_bound=upper)[0]

    def within(self, pts: np.ndarray, tol: float) -> float:
        """Fraction of `pts` within `tol` of the surface."""
        if len(pts) == 0:
            return 0.0
        return float(np.mean(self(pts, upper=tol) < tol))


def _reflect(pts: np.ndarray, mean: np.ndarray, n: np.ndarray) -> np.ndarray:
    return pts - 2 * np.outer((pts - mean) @ n, n)


class _MirrorTest:
    """Mirror-plane scoring for one mesh. A plane's score is the weakest of: the whole-surface sample, each
    sizeable body's own sample, and the residual sample (the points that do not land on the surface after a
    30 degree turn about an axisymmetric body's axis: the fins on a rocket tube, the fittings on a round
    injector head). Each of those can veto a plane the area-weighted whole would have passed."""

    def __init__(self, mesh: trimesh.Trimesh, dist: _SurfaceDistance, pts: np.ndarray, tol: float, seed: int,
                 axes_of_revolution: list[tuple[np.ndarray, np.ndarray]] = ()):
        from geometry_agent.facts.regions import region_meshes
        self.dist, self.pts, self.tol = dist, pts, tol
        parts = region_meshes(mesh)
        self.region_pts: list[np.ndarray] = []
        if len(parts) > 1:
            total = float(mesh.area)
            order = sorted(range(len(parts)), key=lambda k: -float(parts[k].area))[:MAX_SYMMETRY_REGIONS]
            for k in order:
                p = parts[k]
                if len(p.faces) < 4:
                    continue
                n = int(np.clip(SAMPLE_POINTS * float(p.area) / max(total, 1e-18), REGION_MIN_SAMPLES, SAMPLE_POINTS))
                self.region_pts.append(trimesh.sample.sample_surface(p, n, seed=seed)[0])
        for point, axis in axes_of_revolution:
            R = rotation_matrix(2 * np.pi / max(ROTATION_ORDERS), axis, point=point)
            off = dist(trimesh.transform_points(pts, R), upper=tol) >= tol
            if off.sum() >= RESIDUAL_MIN_POINTS:
                self.region_pts.append(pts[off])

    def whole(self, mean: np.ndarray, n: np.ndarray) -> float:
        return self.dist.within(_reflect(self.pts, mean, n), self.tol)

    def accept(self, mean: np.ndarray, n: np.ndarray) -> tuple[bool, float]:
        """(passes, score): the score is the weakest of the whole surface, every sizeable body, the residual."""
        s = self.whole(mean, n)
        if s < SYMMETRY_SCORE_MIN:
            return False, s
        for rp in self.region_pts:
            s = min(s, self.dist.within(_reflect(rp, mean, n), self.tol))
            if s < SYMMETRY_SCORE_MIN:
                return False, s
        return True, s

    def score(self, mean: np.ndarray, n: np.ndarray) -> float:
        return self.accept(mean, n)[1]


def _symmetry_scores(pts: np.ndarray, dist: _SurfaceDistance, mean: np.ndarray, vecs: np.ndarray, tol: float) -> np.ndarray:
    scores = np.zeros(3)
    for k in range(3):
        scores[k] = dist.within(_reflect(pts, mean, vecs[:, k]), tol)
    return scores


def _degenerate_pairs(vals: np.ndarray) -> list[tuple[int, int]]:
    pairs = []
    top = float(max(vals.max(), 1e-18))
    for i, j in ((0, 1), (1, 2)):
        if abs(vals[i] - vals[j]) <= DEGENERATE_VARIANCE_REL * max(top, 1e-18) and vals[i] > 0:
            pairs.append((i, j))
    return pairs


def _in_plane(e1: np.ndarray, e2: np.ndarray, deg: float) -> np.ndarray:
    t = np.radians(deg)
    return np.cos(t) * e1 + np.sin(t) * e2


def _sweep_plane(test: _MirrorTest, mean: np.ndarray, e1: np.ndarray, e2: np.ndarray) -> tuple[list[tuple[float, float]], bool]:
    """Mirror normals inside the plane spanned by e1, e2 as (angle_deg, whole-surface score), refined to
    SWEEP_REFINE_DEG[-1], centred on their plateau and merged within PLANE_MERGE_DEG, plus whether the body is
    round in this plane (at least AXISYMMETRIC_GRID_FRACTION of the grid passes). Angles live in [0, 180):
    n and -n are one plane."""
    cache: dict[float, float] = {}

    def score_at(deg: float) -> float:
        deg = round(deg % 180.0, 3)
        if deg not in cache:
            cache[deg] = test.score(mean, _in_plane(e1, e2, deg))
        return cache[deg]

    grid = np.arange(0.0, 180.0, SWEEP_STEP_DEG)
    prof = np.array([score_at(a) for a in grid])
    axisymmetric = float(np.mean(prof >= SYMMETRY_SCORE_MIN)) >= AXISYMMETRIC_GRID_FRACTION
    peaks = [float(grid[m]) for m in range(len(grid))
             if prof[m] >= SWEEP_SEED_MIN and prof[m] >= prof[m - 1] and prof[m] >= prof[(m + 1) % len(grid)]]
    world_angles: list[float] = []
    for world in np.eye(3):
        proj = np.array([float(world @ e1), float(world @ e2)])
        if np.linalg.norm(proj) > 0.5:
            world_angles.append(float(np.degrees(np.arctan2(proj[1], proj[0]))) % 180.0)
    seeds = sorted(peaks + world_angles, key=lambda a: -score_at(a))[:MAX_SWEEP_SEEDS]
    found: list[tuple[float, float]] = []
    for a in seeds:
        if any(_angle_gap(a, f) <= SWEEP_STEP_DEG for f, _ in found):
            continue
        best_a, best_s = a, score_at(a)
        for step in SWEEP_REFINE_DEG:
            improved = True
            while improved:
                improved = False
                for cand in (best_a - step, best_a + step):
                    s = score_at(cand)
                    if s > best_s + 1e-9:
                        best_a, best_s, improved = cand % 180.0, s, True
        if best_s < SYMMETRY_SCORE_MIN:
            continue
        # a plane's score is flat across a plateau as wide as the tolerance allows; its centre is the plane
        floor = best_s - PLATEAU_DROP
        lo = hi = 0.0
        while lo > -PLATEAU_MAX_DEG and score_at(best_a + lo - PLATEAU_STEP_DEG) >= floor:
            lo -= PLATEAU_STEP_DEG
        while hi < PLATEAU_MAX_DEG and score_at(best_a + hi + PLATEAU_STEP_DEG) >= floor:
            hi += PLATEAU_STEP_DEG
        centre = (best_a + (lo + hi) / 2) % 180.0
        # a projected world axis on the plateau is the plane: a duct's mid-plane is x = 0, not 0.1 degrees off
        on_plateau = [w for w in world_angles if _angle_gap(w, centre) <= (hi - lo) / 2 + 1e-9 and score_at(w) >= floor]
        best_a = min(on_plateau, key=lambda w: _angle_gap(w, centre)) if on_plateau else centre
        best_s = score_at(best_a)
        if any(_angle_gap(best_a, f) <= PLANE_MERGE_DEG for f, _ in found):
            continue
        found.append((best_a, best_s))
    return sorted(found), axisymmetric


def _angle_gap(a: float, b: float) -> float:
    d = abs(a - b) % 180.0
    return min(d, 180.0 - d)


def _realign(vecs: np.ndarray, i: int, j: int, n: np.ndarray) -> np.ndarray:
    """Replace the degenerate pair (i, j) of the frame by `n` and its in-plane perpendicular, keeping the third
    axis and a right-handed frame."""
    k = 3 - i - j
    out = vecs.copy()
    out[:, i] = n / max(float(np.linalg.norm(n)), 1e-12)
    perp = np.cross(out[:, k], out[:, i])
    out[:, j] = perp / max(float(np.linalg.norm(perp)), 1e-12)
    if np.linalg.det(out) < 0:
        out[:, j] *= -1
    return out


def _mirror_planes(test: _MirrorTest, mean: np.ndarray, vals: np.ndarray, vecs: np.ndarray) -> tuple[np.ndarray, np.ndarray, list[int], list[np.ndarray]]:
    """(realigned frame, per-axis scores, plane indices, plane normals)."""
    extra: list[np.ndarray] = []
    for i, j in _degenerate_pairs(vals):
        e1, e2 = vecs[:, i], vecs[:, j]
        found, axisymmetric = _sweep_plane(test, mean, e1, e2)
        if not found:
            continue
        normals = [_in_plane(e1, e2, a) for a, _ in found]
        if axisymmetric or len(found) > AXISYMMETRIC_PLANES:
            # round about the third axis: keep two orthogonal in-plane planes, world-aligned when one is
            world = [w for w in np.eye(3) if np.linalg.norm([w @ e1, w @ e2]) > 0.5]
            first = None
            for w in world:
                p = (w @ e1) * e1 + (w @ e2) * e2
                p /= np.linalg.norm(p)
                if test.score(mean, p) >= SYMMETRY_SCORE_MIN:
                    first = p
                    break
            if first is None:
                first = normals[int(np.argmax([s for _, s in found]))]
            normals = [first]
        accepted = [n for n in normals if test.accept(mean, n)[0]]
        if not accepted:
            continue
        # the frame is realigned to the best-scoring normal; among equals (to sampling noise) the one nearest
        # a world axis, so a rocket with fins at -90/30/150 keeps x = 0 as a principal plane
        best = max(accepted, key=lambda n: (round(test.accept(mean, n)[1], 2), float(np.max(np.abs(n)))))
        vecs = _realign(vecs, i, j, best)
        for n in accepted:
            if _angle_between(n, vecs[:, i]) > PLANE_MERGE_DEG and _angle_between(n, vecs[:, j]) > PLANE_MERGE_DEG:
                extra.append(n)
    scores = np.zeros(3)
    planes: list[int] = []
    normals_out: list[np.ndarray] = []
    for k in range(3):
        ok, s = test.accept(mean, vecs[:, k])
        scores[k] = s
        if ok:
            planes.append(k)
            normals_out.append(vecs[:, k].copy())
    for n in extra:
        if any(_angle_between(n, m) <= PLANE_MERGE_DEG for m in normals_out):
            continue
        planes.append(int(np.argmax(np.abs(vecs.T @ n))))
        normals_out.append(n)
    return vecs, scores, planes, normals_out


def _angle_between(a: np.ndarray, b: np.ndarray) -> float:
    c = abs(float(a @ b)) / max(float(np.linalg.norm(a) * np.linalg.norm(b)), 1e-12)
    return float(np.degrees(np.arccos(min(1.0, c))))


def _rotation_scores(pts: np.ndarray, dist: _SurfaceDistance, point: np.ndarray, axis: np.ndarray, tol: float) -> dict[int, float]:
    out = {}
    for order in ROTATION_ORDERS:
        R = rotation_matrix(2 * np.pi / order, axis, point=point)
        out[order] = dist.within(trimesh.transform_points(pts, R), tol)
    return out


def _pick_order(scores: dict[int, float]) -> tuple[int | None, float]:
    """Highest order whose score is within ROTATION_SCORE_MARGIN of the best and over ROTATION_SCORE_MIN."""
    if not scores:
        return None, 0.0
    best = max(scores.values())
    floor = max(ROTATION_SCORE_MIN, best - ROTATION_SCORE_MARGIN)
    ok = [o for o, s in scores.items() if s >= floor]
    if not ok:
        return None, 0.0
    order = max(ok)
    return order, scores[order]


def _rotational_symmetry(pts: np.ndarray, dist: _SurfaceDistance, mean: np.ndarray, vecs: np.ndarray, tol: float) -> tuple[int | None, int | None, float]:
    """Highest order N such that rotating the surface by 2*pi/N about a principal axis lands on itself. Blades,
    bolt circles and nozzle arrays show it; a plain pipe is axisymmetric and shows every order, which is reported
    as order 12 (the largest tested) about its axis."""
    best_axis, best_order, best_score = None, None, 0.0
    for k in range(3):
        order, score = _pick_order(_rotation_scores(pts, dist, mean, vecs[:, k], tol))
        if order is not None and (best_order is None or order > best_order or (order == best_order and score > best_score)):
            best_axis, best_order, best_score = k, order, score
    return best_axis, best_order, best_score


def _section_area(mesh: trimesh.Trimesh, origin: np.ndarray, normal: np.ndarray) -> float:
    """Total enclosed area of the closed loops where the plane cuts the surface. Pure numpy; no Path machinery."""
    segs = trimesh.intersections.mesh_plane(mesh, plane_normal=normal, plane_origin=origin)
    if segs is None or len(segs) == 0:
        return 0.0
    tol = 1e-6 * float(np.linalg.norm(mesh.extents)) + 1e-12
    return float(sum(_loop_area_normal(lp) for lp in _chain_segments(np.asarray(segs), tol)))


def _blunt_end(mesh: trimesh.Trimesh, mean: np.ndarray, axis: np.ndarray) -> tuple[int, float]:
    proj = (mesh.vertices - mean) @ axis
    lo, hi = float(proj.min()), float(proj.max())
    span = hi - lo
    if span <= 0:
        return 0, 0.0
    a_lo, a_hi = (_section_area(mesh, mean + station * axis, axis)
                  for station in (lo + END_FRACTION * span, hi - END_FRACTION * span))
    top = max(a_lo, a_hi)
    if top <= 0:
        return 0, 0.0
    conf = abs(a_hi - a_lo) / top
    sign = 1 if a_hi > a_lo else -1
    return (sign if conf > 0.25 else 0), float(conf)


def rotational_symmetry_of(mesh: trimesh.Trimesh, seed: int = 0, dist: _SurfaceDistance | None = None) -> tuple[int | None, int | None, float]:
    """(principal axis index, order, score) for one body. `dist` may be passed when the caller already holds
    the body's surface cloud."""
    if len(mesh.faces) < 4:
        return None, None, 0.0
    mean, _vals, vecs = _principal(mesh)
    dist = dist or _SurfaceDistance(mesh)
    tol = _symmetry_tol(mesh, dist)
    pts, _ = trimesh.sample.sample_surface(mesh, SAMPLE_POINTS, seed=seed)
    return _rotational_symmetry(pts, dist, mean, vecs, tol)


class _PerRegionRotation:
    """Rotational symmetry per body: each body's (axis index, order), the highest N-fold order any body shows
    below the axisymmetric limit (a bladed rotor next to its round shroud reports the blades), the
    axisymmetric result if any body is round, and the axes of revolution of the round bodies (point, world
    direction), largest first. Sampling the whole assembly alone would let a big round casing outvote a small
    rotor, which is why each body is searched on its own."""

    def __init__(self, mesh: trimesh.Trimesh, seed: int, dist: _SurfaceDistance | None):
        from geometry_agent.facts.regions import region_meshes
        parts = region_meshes(mesh)
        order = sorted(range(len(parts)), key=lambda k: -float(parts[k].area))[:MAX_ROTATION_REGIONS]
        self.per: list[tuple[int | None, int | None]] = [(None, None)] * len(parts)
        self.best = (None, None, 0.0)
        self.axisym = (None, None, 0.0)
        self.axes_of_revolution: list[tuple[np.ndarray, np.ndarray]] = []
        for k in order:
            ax, n, score = rotational_symmetry_of(parts[k], seed, dist if parts[k] is mesh else None)
            self.per[k] = (ax, n)
            if n is None:
                continue
            if n < max(ROTATION_ORDERS) and (self.best[1] is None or n > self.best[1]):
                self.best = (ax, n, score)
            elif n == max(ROTATION_ORDERS):
                r_mean, _r_vals, r_vecs = _principal(parts[k])
                self.axes_of_revolution.append((r_mean, r_vecs[:, ax]))
                if self.axisym[1] is None:
                    self.axisym = (ax, n, score)


def _assembly_rotation(per: _PerRegionRotation, mesh: trimesh.Trimesh, dist: _SurfaceDistance, pts: np.ndarray,
                       mean: np.ndarray, vecs: np.ndarray) -> tuple[int | None, int | None, float]:
    """The one figure worth reporting for the whole file. The whole assembly is rotated about its principal
    axes and about the axes of its round bodies, which is what finds three fins at 120 degrees (each a 2-fold
    plate on its own). The higher sub-axisymmetric order of assembly and per-body wins (assembly on ties); the
    per-body result stands when the assembly only shows the axisymmetric order (a small hex nut on a big round
    shaft), and the axisymmetric order is reported when nothing else is."""
    whole = (None, None, 0.0)
    if len(per.per) > 1:
        tol = _symmetry_tol(mesh, dist)
        candidates = [(mean, vecs[:, k], k) for k in range(3)]
        for point, axis in per.axes_of_revolution[:MAX_ASSEMBLY_AXES]:
            candidates.append((point, axis, int(np.argmax(np.abs(vecs.T @ axis)))))
        for point, axis, k in candidates:
            n, score = _pick_order(_rotation_scores(pts, dist, point, axis, tol))
            if n is None:
                continue
            if n < max(ROTATION_ORDERS) and (whole[1] is None or whole[1] == max(ROTATION_ORDERS) or n > whole[1]
                                             or (n == whole[1] and score > whole[2])):
                whole = (k, n, score)
            elif n == max(ROTATION_ORDERS) and whole[1] is None:
                whole = (k, n, score)
    sub_whole = whole if whole[1] is not None and whole[1] < max(ROTATION_ORDERS) else None
    sub_part = per.best if per.best[1] is not None else None
    if sub_whole and (sub_part is None or sub_whole[1] >= sub_part[1]):
        return sub_whole
    if sub_part:
        return sub_part
    if per.axisym[1] is not None:
        return per.axisym
    return whole


def _rotational_summary(mesh: trimesh.Trimesh, seed: int, dist: _SurfaceDistance | None = None, pts: np.ndarray | None = None,
                        mean: np.ndarray | None = None, vecs: np.ndarray | None = None) -> tuple[int | None, int | None, float, list[tuple[int | None, int | None]]]:
    """Per-body and whole-assembly rotational symmetry in one call (see _PerRegionRotation, _assembly_rotation)."""
    per = _PerRegionRotation(mesh, seed, dist)
    if dist is None or pts is None or mean is None or vecs is None:
        chosen = per.best if per.best[1] is not None else per.axisym
    else:
        chosen = _assembly_rotation(per, mesh, dist, pts, mean, vecs)
    return chosen[0], chosen[1], chosen[2], per.per


def detect_axes(mesh: trimesh.Trimesh, seed: int = 0) -> Axes:
    return detect_axes_full(mesh, seed)[0]


def detect_axes_full(mesh: trimesh.Trimesh, seed: int = 0) -> tuple[Axes, list[tuple[int | None, int | None]]]:
    """The Axes record plus each region's (rotational axis, order), so callers that keep regions can stamp them
    without running the symmetry search twice."""
    mean, vals, vecs = _principal(mesh)
    pts, _ = trimesh.sample.sample_surface(mesh, SAMPLE_POINTS, seed=seed)
    dist = _SurfaceDistance(mesh)
    tol = _symmetry_tol(mesh, dist)
    per = _PerRegionRotation(mesh, seed, dist)
    test = _MirrorTest(mesh, dist, pts, tol, seed, per.axes_of_revolution[:MAX_ASSEMBLY_AXES])
    vecs, scores, planes, normals = _mirror_planes(test, mean, vals, vecs)
    rot_axis, rot_order, rot_score = _assembly_rotation(per, mesh, dist, pts, mean, vecs)
    per_region = per.per
    slender = float(np.sqrt(max(vals[0], 1e-18) / max(vals[1], 1e-18)))
    sign, conf = _blunt_end(mesh, mean, vecs[:, 0])
    return Axes(
        principal=tuple(tuple(float(v) for v in vecs[:, k]) for k in range(3)),
        variance=tuple(float(v) for v in vals),
        slenderness=slender,
        symmetry_scores=tuple(float(s) for s in scores),
        symmetry_planes=planes,
        blunt_end_sign=int(sign),
        blunt_end_confidence=conf,
        rotational_axis=rot_axis,
        rotational_order=rot_order,
        rotational_score=rot_score,
        symmetry_normals=[tuple(float(v) for v in n) for n in normals],
    ), per_region
