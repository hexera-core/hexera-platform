"""Wall thickness and gaps between surfaces, by chords that must prove what they crossed.

A CHORD is a ray from a face centre along its normal to the first surface it meets: inward it crosses the solid,
outward it crosses the space outside it. The old measurement took every chord at its word, and three facts the
builder was sent were wrong because of it:

  min_gap          the outward chord from a bore wall crosses the bore and meets the far side of the same bore.
                   0.04989 was reported as a narrow gap on a 0.04989 bore, on every pipe.
  thickness_median the inward chord from a pipe's end annulus runs down the WALL, not across it, and meets the
                   other end: the length of the pipe. The sample was every face with equal weight whenever the
                   part had fewer faces than the sample size, so the many small triangles of the two end annuli
                   pulled the median to half the length.
  thickness_min    the minimum over 1,500 seeded faces: a draw, 35 per cent apart across eight seeds on one file.

So every chord here passes three tests before it is a measurement, and each is geometry, not a threshold fitted
to a corpus:

  FACING           the surface met must face back at the one the chord left, within FACING_DEG of opposite.
                   Inward that is Shapira's test that the ray left the solid and did not graze into its outside;
                   outward it is the mesher's own condition that the two surfaces are "sufficiently parallel".
  THE BALL         the chord is a width only if a ball of BALL_FRACTION of its half-length fits at its midpoint:
                   six probes square to the chord must all run at least that far. A chord down the length of a
                   wall has the wall's own sides a wall-thickness away at its midpoint and fails; a chord across
                   the wall has the wall running on either side and passes. This is the test the axial rays of a
                   pipe's end annulus fail.
  SELF-EXCLUSION   (gaps only) the two surfaces must be DIFFERENT surfaces facing each other, not one surface
                   curving round to face itself across its own passage. A bore, a round or square duct: the
                   surface wraps the chord's midpoint, so along some line square to the chord it is met on BOTH
                   sides within ENCLOSED_SIDE chord-lengths. Two bodies, two branch pipes, a slot, an annulus and
                   a pinch point leave the midpoint open to the side and are gaps. One of the lines probed is the
                   direction the surface bends in at the chord's start: near a bore's mouth every other line
                   escapes through the mouth, and a filleted bracket's 16 mm bore read as a 16.2 mm gap until
                   that line was added.

WHY NOT THE SAME CONNECTED SMOOTH SURFACE for self-exclusion, which is how snappyHexMesh's `gapSelf` reads on a
named surface: an STL is one surface, and on a mesh the smooth patches join far-apart places through any
junction whose dihedral angle is small. An equal-bore tee's branch and run meet at zero dihedral on its flanks,
so a patch rule calls the gap between two such branches "self" and drops it. Enclosure is local and does not.

EVERYTHING HERE IS DETERMINISTIC. There is no seed. Up to RAY_FACE_CAP faces every face casts its chords and the
minimum is taken over all of them; up to DISTRIBUTION_FACES every face is tested and the percentiles are area
weighted over all of them; past either, the faces are an even stride or a systematic area-proportional sample,
the same faces on every run of a byte-identical file, and the record says the minimum was not exhaustive.
"""
from __future__ import annotations

import numpy as np
import trimesh
from scipy.spatial import cKDTree

#: Two surfaces face each other when their normals are within this many degrees of opposite. It is our value,
#: set where a wedge-shaped gap stops being a gap: a chord along one normal meeting a wall 30 degrees off is
#: already 15 per cent longer than the distance between them.
FACING_DEG = 30.0
FACING_COS = float(np.cos(np.radians(FACING_DEG)))
#: The ball at a chord's midpoint must have at least this fraction of the chord's half-length. At 0.5 a chord
#: counts when the part is no narrower than half the chord across it at the midpoint, which admits a wedge up
#: to sixty degrees included and rejects a chord down a wall longer than twice the wall is thick.
BALL_FRACTION = 0.5
#: Probes square to the chord, evenly spaced: three lines through the midpoint, and two more along the surface's
#: principal directions at the chord's start (`_bend` and the line square to it). A plane at distance h from the
#: midpoint is met within h / cos(30 degrees) by the nearest of the six.
PROBES = 6
#: A chord whose midpoint the surface closes in on from both sides within this many chord lengths, along some
#: line square to it, is a passage (a bore, a duct), not a gap between two surfaces. A round bore through its
#: axis is met at half a chord each way; a rectangular duct is a passage up to 2.5 times as wide as it is high
#: and a narrow gap across its height past that. BOTH SIDES, and not their sum, because of the bore at a tee: at
#: the junction the line round the bore meets the wall at half a chord on one side and runs a whole chord into
#: the branch on the other, a sum of 1.5 chords, and a sum rule called a 345.7 bore a 345.66 gap there.
ENCLOSED_SIDE = 1.25
#: How far along each principal line a chord that did not close is tried again, as a fraction of the chord. The
#: ball test has just shown the midpoint's surroundings empty to BALL_FRACTION of a half chord (a quarter
#: chord), so the shifted point is still in the open.
SHIFT_OF_CHORD = 0.25
#: The bend direction is read across edges smoother than this, the angle a feature edge starts at (features.
#: SHARP_DEG): across a sharp edge the surface does not bend, it stops and another one starts.
BEND_SMOOTH_DEG = 60.0
#: Rays start this fraction of the part's diagonal off their face, and a hit nearer than that is a graze of
#: the face's own neighbourhood and is stepped past. The loader merges vertices at 1e-7 of the diagonal.
LIFT_OF_DIAG = 1e-6
#: Faces that cast chords for the minima. Past this, an even stride over the face index, and the record says so.
RAY_FACE_CAP = 1_500_000
#: Faces whose chords are fully tested (ball, enclosure) for the percentiles and the clusters. Past this, a
#: systematic sample: every face whose cumulative area crosses one of this many evenly spaced marks.
DISTRIBUTION_FACES = 200_000
#: When the faces were sampled, chords outside the sample shorter than the sample's own minimum are tested in
#: ascending order for the minimum, this many at most.
MIN_SEARCH_CAP = 50_000
MIN_SEARCH_BATCH = 2048
#: Clusters reported, largest area first.
MAX_CLUSTERS = 8
#: A graze or a stuck ray is stepped past at most this many times.
MAX_STEPS = 6


# --------------------------------------------------------------------------------------------------------------
# rays
# --------------------------------------------------------------------------------------------------------------

def _first_hits(mesh: trimesh.Trimesh, origins: np.ndarray, dirs: np.ndarray, own: np.ndarray | None = None,
                allowed: np.ndarray | None = None) -> tuple[np.ndarray, np.ndarray]:
    """Distance from each origin along its direction to the first face that is not `own`, is `allowed`, and is
    more than a lift away; and that face. inf and -1 where the ray leaves the part. A hit that does not count is
    stepped past and the ray goes on, so debris or a graze never hides the surface behind it."""
    n = len(origins)
    dist = np.full(n, np.inf)
    tri = np.full(n, -1, dtype=np.int64)
    if n == 0 or len(mesh.faces) == 0:
        return dist, tri
    start = np.asarray(origins, dtype=float)
    dirs = np.asarray(dirs, dtype=float)
    dirs = dirs / np.maximum(np.linalg.norm(dirs, axis=1), 1e-300)[:, None]
    step = LIFT_OF_DIAG * float(np.linalg.norm(mesh.extents))
    at = start + dirs * step
    live = np.arange(n)
    cast = _caster(mesh)
    for _ in range(MAX_STEPS):
        if len(live) == 0:
            break
        idx_tri, idx_ray, loc = cast(at[live], dirs[live])
        if len(idx_ray) == 0:
            break
        rays = live[np.asarray(idx_ray, dtype=np.int64)]
        idx_tri = np.asarray(idx_tri, dtype=np.int64)
        d = np.einsum("ij,ij->i", loc - start[rays], dirs[rays])
        bad = d < step
        if own is not None:
            bad |= idx_tri == own[rays]
        if allowed is not None:
            bad |= ~allowed[idx_tri]
        good = ~bad
        dist[rays[good]] = d[good]
        tri[rays[good]] = idx_tri[good]
        live = rays[bad]
        at[live] = loc[bad] + dirs[live] * step
    return dist, tri


def _caster(mesh: trimesh.Trimesh):
    """First hits as (triangle, ray, location), straight from embree when trimesh's intersector is the embree one.

    trimesh's `intersects_id` copies and re-normalises every batch and keeps the bookkeeping for multiple hits
    that a first hit never uses: on a 1M-face part it was 7.2 of the 8.7 seconds this module spent casting, for
    2.4 seconds of embree. Here the scene is asked for the first triangle and the hit is the ray's crossing of
    that triangle's plane, which is how trimesh places it too. Without embree, trimesh's own call is used."""
    ray = mesh.ray
    scene = getattr(ray, "_scene", None)
    if scene is None or not hasattr(scene, "run"):
        def fallback(o, d):
            return ray.intersects_id(o, d, multiple_hits=False, return_locations=True)
        return fallback
    corner = np.asarray(mesh.triangles)[:, 0, :]
    normals = np.asarray(mesh.face_normals)

    def cast(o: np.ndarray, d: np.ndarray):
        hit = np.asarray(scene.run(o, d), dtype=np.int64)
        rays = np.flatnonzero(hit >= 0)
        tri = hit[rays]
        nrm = normals[tri]
        den = np.einsum("ij,ij->i", d[rays], nrm)
        ok = np.abs(den) > 1e-12
        rays, tri, nrm, den = rays[ok], tri[ok], nrm[ok], den[ok]
        t = np.einsum("ij,ij->i", corner[tri] - o[rays], nrm) / den
        return tri, rays, o[rays] + d[rays] * t[:, None]
    return cast


def _square_basis(axis: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    a = np.asarray(axis, dtype=float)
    helper = np.where((np.abs(a[:, 0]) < 0.9)[:, None], [[1.0, 0.0, 0.0]], [[0.0, 1.0, 0.0]])
    u = np.cross(a, helper)
    u /= np.maximum(np.linalg.norm(u, axis=1), 1e-300)[:, None]
    v = np.cross(a, u)
    return u, v


def _bend(mesh: trimesh.Trimesh, faces: np.ndarray, axis: np.ndarray) -> np.ndarray:
    """Per face, the direction square to its chord in which the surface around it turns most: the principal
    direction of its neighbours' normals minus its own. Across a cylinder that is round the bore; on a flat face
    it is nothing, and the first probe direction stands in. A fixed set of probe directions misses the one line
    that matters near a bore's mouth, where every line but the exact transverse one escapes through the mouth:
    measured on a filleted bracket, whose bore read as a 16.2 mm gap 1.5 mm above its end."""
    u, _ = _square_basis(axis)
    adj = np.asarray(mesh.face_adjacency)
    if len(faces) == 0 or len(adj) == 0:
        return u
    fn = np.asarray(mesh.face_normals)
    pos = np.full(len(mesh.faces), -1, dtype=np.int64)
    pos[faces] = np.arange(len(faces))
    # only the SMOOTH neighbours, weighted by the edge they share: a CAD strip down a bore meets its two side
    # neighbours along its whole length and turns a few degrees at each, and meets the flange or the junction at
    # its ends across a sharp edge. Unweighted, the sharp ends won and the bend pointed down the bore
    # (measured on a tee: a 345.7 bore read as a 345.66 gap)
    smooth = np.asarray(mesh.face_adjacency_angles) < np.radians(BEND_SMOOTH_DEG)
    ev = np.asarray(mesh.face_adjacency_edges)
    verts = np.asarray(mesh.vertices)
    shared = np.linalg.norm(verts[ev[:, 0]] - verts[ev[:, 1]], axis=1)
    cov = np.zeros((len(faces), 3, 3))
    for a, b in ((0, 1), (1, 0)):
        k = pos[adj[:, a]]
        on = (k >= 0) & smooth
        diff = (fn[adj[on, b]] - fn[adj[on, a]]) * np.sqrt(shared[on])[:, None]
        np.add.at(cov, k[on], diff[:, :, None] * diff[:, None, :])
    proj = np.eye(3)[None] - axis[:, :, None] * axis[:, None, :]
    cov = proj @ cov @ proj
    vals, vecs = np.linalg.eigh(cov)
    bend = vecs[:, :, -1]
    flat = vals[:, -1] <= 1e-12
    bend[flat] = u[flat]
    return bend


def _probes(mesh: trimesh.Trimesh, mids: np.ndarray, axis: np.ndarray, allowed: np.ndarray | None,
            bend: np.ndarray | None = None) -> np.ndarray:
    """(n, PROBES + 4) distances from each midpoint to the surface along directions square to its chord. Columns
    k and k + PROBES/2 are opposite for k < PROBES/2; the last four are the two ways along `bend` and the two
    ways along the line square to both it and the chord. Both principal lines, because the one that closes
    round a bore is the bore's own and not always the sharper bend: where a bore meets its filleted mouth the
    fillet bends harder along the axis, and a filleted bracket's 16 mm bore read as a 16.2 mm gap 2 mm above
    its end until the second line was probed."""
    if len(mids) == 0:
        return np.zeros((0, PROBES + 4))
    u, v = _square_basis(axis)
    ang = 2.0 * np.pi * np.arange(PROBES) / PROBES
    dirs = np.cos(ang)[None, :, None] * u[:, None, :] + np.sin(ang)[None, :, None] * v[:, None, :]
    b = u if bend is None else bend
    c = np.cross(axis, b)
    c /= np.maximum(np.linalg.norm(c, axis=1), 1e-300)[:, None]
    dirs = np.concatenate([dirs, b[:, None, :], -b[:, None, :], c[:, None, :], -c[:, None, :]], axis=1).reshape(-1, 3)
    origins = np.repeat(mids, PROBES + 4, axis=0)
    d, _ = _first_hits(mesh, origins, dirs, allowed=allowed)
    return d.reshape(len(mids), PROBES + 4)


def _ball_ok(probe: np.ndarray, chord: np.ndarray) -> np.ndarray:
    return probe.min(axis=1) >= BALL_FRACTION * chord / 2.0


def _enclosed(probe: np.ndarray, chord: np.ndarray) -> np.ndarray:
    half = PROBES // 2
    reach = np.concatenate([np.maximum(probe[:, :half], probe[:, half:PROBES]),
                            np.maximum(probe[:, PROBES], probe[:, PROBES + 1])[:, None],
                            np.maximum(probe[:, PROBES + 2], probe[:, PROBES + 3])[:, None]], axis=1)
    return reach.min(axis=1) <= ENCLOSED_SIDE * chord


# --------------------------------------------------------------------------------------------------------------
# which faces
# --------------------------------------------------------------------------------------------------------------

def ray_faces(pool: np.ndarray, cap: int = RAY_FACE_CAP) -> tuple[np.ndarray, bool]:
    """Faces that cast chords for the minima: all of `pool`, or an even stride over it past `cap`."""
    if len(pool) <= cap:
        return pool, True
    stride = int(np.ceil(len(pool) / cap))
    return pool[::stride], False


def distribution_faces(areas: np.ndarray, pool: np.ndarray, n: int = DISTRIBUTION_FACES) -> tuple[np.ndarray, np.ndarray, bool]:
    """(faces, weights, every face): every face of `pool` weighted by its area, or, past `n`, a systematic
    area-proportional sample: the face under each of n evenly spaced marks along the cumulative area, weighted by
    how many marks fell on it. No random number is drawn, so the same file gives the same faces every run."""
    if len(pool) <= n:
        return pool, np.asarray(areas[pool], dtype=float), True
    cum = np.cumsum(np.asarray(areas[pool], dtype=float))
    total = float(cum[-1]) if len(cum) else 0.0
    if total <= 0:
        stride = int(np.ceil(len(pool) / n))
        picked = pool[::stride]
        return picked, np.ones(len(picked)), False
    marks = (np.arange(n) + 0.5) * (total / n)
    at = np.minimum(np.searchsorted(cum, marks, side="right"), len(pool) - 1)
    faces, counts = np.unique(pool[at], return_counts=True)
    return faces, counts.astype(float) * (total / n), False


def weighted_percentile(values: np.ndarray, weights: np.ndarray, q: float) -> float:
    """The q-th percentile of `values` under `weights`: the smallest value whose cumulative weight reaches q per
    cent of the total. A face's area is its say in the answer, so ten thousand end-ring slivers do not outvote
    the barrel."""
    order = np.argsort(values, kind="stable")
    v, w = values[order], weights[order]
    cum = np.cumsum(w)
    target = q / 100.0 * float(cum[-1])
    return float(v[min(int(np.searchsorted(cum, target, side="left")), len(v) - 1)])


# --------------------------------------------------------------------------------------------------------------
# chords
# --------------------------------------------------------------------------------------------------------------

class Chords:
    """Every tested chord of one side (inward or outward) for one set of faces."""

    def __init__(self, mesh: trimesh.Trimesh, faces: np.ndarray, inward: bool, allowed: np.ndarray | None):
        self.faces = np.asarray(faces, dtype=np.int64)
        normals = np.asarray(mesh.face_normals)[self.faces]
        self.axis = -normals if inward else normals
        self.start = np.asarray(mesh.triangles_center)[self.faces]
        self.length, self.hit = _first_hits(mesh, self.start, self.axis, own=self.faces, allowed=allowed)
        met = self.hit >= 0
        # A CHORD ACROSS A FOLD MEASURES THE TRIANGLES, NOT THE PART. When the face met shares a vertex with the
        # face the chord left, the chord runs across the corner the two make, and its length is where the face
        # centre happens to sit times the tangent of the angle: it shrinks without limit as the file is refined.
        # A blade row's trailing wedge read 0.0006 mm this way on a 580 mm part. It is not a measurement.
        if met.any():
            tri = np.asarray(mesh.faces)
            a, b = tri[self.faces[met]], tri[self.hit[met]]
            fold = (a[:, :, None] == b[:, None, :]).any(axis=(1, 2))
            idx = np.flatnonzero(met)[fold]
            self.length[idx] = np.inf
            self.hit[idx] = -1
            self.folds = int(len(idx))
            met = self.hit >= 0
        else:
            self.folds = 0
        self.facing = np.zeros(len(self.faces), dtype=bool)
        if met.any():
            dots = np.einsum("ij,ij->i", np.asarray(mesh.face_normals)[self.hit[met]], normals[met])
            # inward the far side must be an exit (its outward normal against the origin's): Shapira's 90
            # degrees; outward the two surfaces must face each other within FACING_DEG
            self.facing[met] = dots < 0.0 if inward else dots <= -FACING_COS
        self.inward = inward


def _test(mesh: trimesh.Trimesh, ch: Chords, sel: np.ndarray, allowed: np.ndarray | None) -> tuple[np.ndarray, np.ndarray]:
    """(ball passes, surface closes round the midpoint) for the chords at positions `sel`."""
    if len(sel) == 0:
        return np.zeros(0, dtype=bool), np.zeros(0, dtype=bool)
    chord = ch.length[sel]
    axis = ch.axis[sel]
    mids = ch.start[sel] + axis * (chord / 2.0)[:, None]
    bend = None if ch.inward else _bend(mesh, ch.faces[sel], axis)
    probe = _probes(mesh, mids, axis, allowed, bend)
    ball, enclosed = _ball_ok(probe, chord), _enclosed(probe, chord)
    if not ch.inward:
        # A BORE'S MOUTH. Two millimetres above the open end of a filleted 16 mm bore every line that tilts a few
        # degrees toward the mouth leaves the part, and only the exact transverse line closes. So a chord that
        # passed the ball and did not close is tried again a quarter chord along each principal line, inside the
        # ball the test just proved empty: one of those points is deeper in the bore and closes. Between two
        # different surfaces the shifted points are as open as the first.
        todo = np.flatnonzero(ball & ~enclosed)
        if len(todo):
            c = np.cross(axis[todo], bend[todo])
            c /= np.maximum(np.linalg.norm(c, axis=1), 1e-300)[:, None]
            step = (SHIFT_OF_CHORD * chord[todo])[:, None]
            for shift in (bend[todo], -bend[todo], c, -c):
                again = _probes(mesh, mids[todo] + shift * step, axis[todo], allowed, bend[todo])
                enclosed[todo] |= _enclosed(again, chord[todo])
    return ball, enclosed


def _accepted(ch: Chords, ball: np.ndarray, enclosed: np.ndarray) -> np.ndarray:
    return ball & ~enclosed if not ch.inward else ball


# --------------------------------------------------------------------------------------------------------------
# clusters
# --------------------------------------------------------------------------------------------------------------

def _groups(mesh: trimesh.Trimesh, faces: np.ndarray, hits: np.ndarray, every_face: bool, total_area: float,
            n_sampled: int) -> list[np.ndarray]:
    """Connected groups among `faces` (positions into it): by shared edges when every face was tested, else by
    nearness (sampled faces are rarely neighbours), within twice the spacing of the sample. A chord also joins
    its own face to the face it met when both are in the set, so the two sides of one gap are one place and
    not two."""
    n = len(faces)
    if n == 0:
        return []
    pos = np.full(len(mesh.faces), -1, dtype=np.int64)
    pos[faces] = np.arange(n)
    links = []
    if every_face:
        adj = np.asarray(mesh.face_adjacency)
        if len(adj):
            a, b = pos[adj[:, 0]], pos[adj[:, 1]]
            keep = (a >= 0) & (b >= 0)
            links.append(np.stack([a[keep], b[keep]], axis=1))
    else:
        spacing = 2.0 * float(np.sqrt(total_area / max(n_sampled, 1)))
        links.append(cKDTree(np.asarray(mesh.triangles_center)[faces]).query_pairs(r=spacing, output_type="ndarray"))
    other = pos[hits]
    across = other >= 0
    links.append(np.stack([np.flatnonzero(across), other[across]], axis=1))
    edges = np.vstack([lk for lk in links if len(lk)]) if any(len(lk) for lk in links) else np.zeros((0, 2), dtype=np.int64)
    return [np.asarray(g, dtype=np.int64) for g in trimesh.graph.connected_components(edges, nodes=np.arange(n), min_len=1)]


# --------------------------------------------------------------------------------------------------------------
# the two measurements
# --------------------------------------------------------------------------------------------------------------

class Result:
    """What one side measured. `values` are the accepted chord lengths over the distribution faces, with their
    weights; `minimum` is over every ray face (exhaustive or not); `rejected_fraction` is the share of the
    distribution's weight whose chord met a facing surface and then failed the ball (or, for gaps, was a
    passage)."""

    def __init__(self) -> None:
        self.values = np.zeros(0)
        self.weights = np.zeros(0)
        self.faces = np.zeros(0, dtype=np.int64)
        self.hit_faces = np.zeros(0, dtype=np.int64)
        self.minimum: float | None = None
        self.minimum_face: int | None = None
        self.exhaustive = True
        self.faces_cast = 0
        self.faces_total = 0
        self.every_face = True
        self.rejected_fraction = 0.0
        self.passage_fraction = 0.0
        self.oblique_fraction = 0.0
        self.tested = 0


def measure_side(mesh: trimesh.Trimesh, pool: np.ndarray, inward: bool, allowed: np.ndarray | None,
                 ray_cap: int = RAY_FACE_CAP, dist_cap: int = DISTRIBUTION_FACES) -> Result:
    """Chords from `pool` on one side, tested, with the minimum over every ray face."""
    out = Result()
    out.faces_total = int(len(pool))
    if len(pool) == 0:
        return out
    areas = np.asarray(mesh.area_faces, dtype=float)
    dist_faces, weights, every = distribution_faces(areas, pool, dist_cap)
    out.every_face = every
    d = Chords(mesh, dist_faces, inward, allowed)
    cand = np.flatnonzero(d.facing & np.isfinite(d.length))
    ball, enclosed = _test(mesh, d, cand, allowed)
    ok = _accepted(d, ball, enclosed)
    total_w = float(weights.sum()) or 1.0
    out.rejected_fraction = float(weights[cand[~ball]].sum()) / total_w
    out.oblique_fraction = float(weights[(d.hit >= 0) & ~d.facing].sum()) / total_w
    if not inward:
        out.passage_fraction = float(weights[cand[ball & enclosed]].sum()) / total_w
    good = cand[ok]
    out.values, out.weights, out.faces, out.hit_faces = d.length[good], weights[good], d.faces[good], d.hit[good]
    out.tested = int(len(cand))
    if len(good):
        k = int(np.argmin(out.values))
        out.minimum, out.minimum_face = float(out.values[k]), int(out.faces[k])
    if every:
        out.faces_cast = int(len(pool))
        return out
    # the sample saw a subset: every face in the ray set casts, and any facing chord shorter than the sample's
    # own minimum is tested in ascending order, up to MIN_SEARCH_CAP of them
    rays, exhaustive = ray_faces(pool, ray_cap)
    out.faces_cast = int(len(rays))
    r = Chords(mesh, rays, inward, allowed)
    bound = out.minimum if out.minimum is not None else np.inf
    order = np.flatnonzero(r.facing & (r.length < bound))
    order = order[np.argsort(r.length[order], kind="stable")]
    capped = len(order) > MIN_SEARCH_CAP
    order = order[:MIN_SEARCH_CAP]
    for s in range(0, len(order), MIN_SEARCH_BATCH):
        chunk = order[s:s + MIN_SEARCH_BATCH]
        b, e = _test(mesh, r, chunk, allowed)
        acc = _accepted(r, b, e)
        out.tested += int(len(chunk))
        if acc.any():
            k = chunk[int(np.argmax(acc))]
            out.minimum, out.minimum_face = float(r.length[k]), int(r.faces[k])
            capped = False
            break
    out.exhaustive = bool(exhaustive and not capped)
    return out


def clusters(mesh: trimesh.Trimesh, res: Result, below: float, region_of: np.ndarray) -> list[dict]:
    """Groups of accepted chords shorter than `below`: where they are, how big, how narrow. Largest area first."""
    sel = res.values < below
    if not sel.any():
        return []
    faces = res.faces[sel]
    vals = res.values[sel]
    w = res.weights[sel]
    hits = res.hit_faces[sel]
    areas = np.asarray(mesh.area_faces, dtype=float)
    total = float(areas.sum())
    groups = _groups(mesh, faces, hits, res.every_face, total, len(res.faces))
    centres = np.asarray(mesh.triangles_center)
    tri = np.asarray(mesh.triangles)
    out = []
    for idx in groups:
        gw = w[idx]
        c = centres[faces[idx]]
        corners = tri[faces[idx]].reshape(-1, 3)
        lo, hi = corners.min(axis=0), corners.max(axis=0)
        pairs, inverse = np.unique(np.stack([region_of[faces[idx]], region_of[hits[idx]]], axis=1), axis=0,
                                   return_inverse=True)
        pair = pairs[int(np.argmax(np.bincount(inverse.reshape(-1), weights=gw)))]
        out.append({
            "faces": int(len(idx)), "min": float(vals[idx].min()),
            "median": weighted_percentile(vals[idx], gw, 50.0), "max": float(vals[idx].max()),
            "centroid": tuple(float(v) for v in np.average(c, axis=0, weights=gw)),
            "extent": tuple(float(v) for v in hi - lo), "area": float(gw.sum()),
            "regions": (f"r{pair[0] + 1}", f"r{pair[1] + 1}"),
        })
    out.sort(key=lambda r: -r["area"])
    return out[:MAX_CLUSTERS]


# --------------------------------------------------------------------------------------------------------------
# feature lines
# --------------------------------------------------------------------------------------------------------------

#: Consecutive feature edges belong to one line when the line turns less than this at the vertex they share.
#: A 48-sided circle turns 7.5 degrees an edge and is one line; a square rim turns 90 and is four.
LINE_TURN_DEG = 45.0


def feature_lines(vertices: np.ndarray, edges: np.ndarray) -> int:
    """How many feature LINES a set of mesh edges forms: chains joined end to end at vertices where exactly two
    of them meet and the chain turns less than LINE_TURN_DEG. A box has twelve whatever its triangle count, a
    cylinder's end circle one. Splitting a triangle into four adds collinear vertices, which join, so the count
    does not move when the file is refined and the shape is not."""
    edges = np.asarray(edges, dtype=np.int64).reshape(-1, 2)
    m = len(edges)
    if m == 0:
        return 0
    ends = edges.reshape(-1)
    owner = np.repeat(np.arange(m), 2)
    order = np.argsort(ends, kind="stable")
    ends_s, owner_s = ends[order], owner[order]
    starts = np.concatenate([[0], np.nonzero(np.diff(ends_s))[0] + 1])
    counts = np.diff(np.concatenate([starts, [len(ends_s)]]))
    two = starts[counts == 2]
    e1, e2, v = owner_s[two], owner_s[two + 1], ends_s[two]
    o1 = np.where(edges[e1, 0] == v, edges[e1, 1], edges[e1, 0])
    o2 = np.where(edges[e2, 0] == v, edges[e2, 1], edges[e2, 0])
    verts = np.asarray(vertices, dtype=float)
    d1 = verts[v] - verts[o1]
    d2 = verts[o2] - verts[v]
    cos = np.einsum("ij,ij->i", d1, d2) / np.maximum(np.linalg.norm(d1, axis=1) * np.linalg.norm(d2, axis=1), 1e-300)
    link = cos >= np.cos(np.radians(LINE_TURN_DEG))
    from scipy.sparse import coo_matrix
    from scipy.sparse.csgraph import connected_components
    graph = coo_matrix((np.ones(int(link.sum()), dtype=np.int8), (e1[link], e2[link])), shape=(m, m))
    n, _ = connected_components(graph, directed=False)
    return int(n)
