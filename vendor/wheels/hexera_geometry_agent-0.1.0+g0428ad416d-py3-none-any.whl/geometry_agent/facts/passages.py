"""How many separate passages one cut across the flow crosses.

The flow profile (`reconcile/profile.py`) answers `restricted`, `clear` or `unreadable` about "the passage", and
on a part with several it answers about their SUM without saying so: a block with two parallel bores and one
with three give byte-identical profiles, and a 91-tube bundle is called restricted at its tubesheet. The profile
already builds, at every station, the boolean image of what the cut passes through. The number of
DISCONNECTED flow regions in that image is the number of passages the cut crosses, and it costs a labelling of
an image the profile has in hand. Measured on `eval/hard_real` with the profile's own masks: 37 on a 37-tube
bundle, 91 on a 91-tube one, 2 on two separate tubes, 1 on a distributor and a tee.

This file counts; the refusal is the profile's to make, and the rule it should apply is `refuses`: more than
one passage in the cut means neither `clear` nor `restricted` is a statement about any passage in the part.

WHICH REGIONS ARE FLOW depends on what the file's material is, and it is the same sign question the profile
answers by representation:

    the material is the fluid (fluid domain, annular fluid)   each connected piece of material is a passage
    the material is the wall (wall shell)                     each void the material closes around is one

Connectivity follows `vision/render.enclosed_regions`, so a passage here and a lettered void there cannot
disagree: empty space four-connected, material eight-connected. A void that reaches the edge of the image is
the room around the part and is not a passage.
"""
from __future__ import annotations

import numpy as np

#: Stations at each end that are not read, as the profile's own END_GUARD: the first and last station sit half a
#: step inside the part, where a mouth's chamfer or a flange can split or merge regions for reasons that have
#: nothing to do with how many passages run through it.
END_GUARD = 2
#: A region smaller than this many pixels of the probe is not counted: a single pixel is the rasteriser, not a
#: passage.
MIN_REGION_PX = 2

_CROSS = np.array([[0, 1, 0], [1, 1, 1], [0, 1, 0]], dtype=bool)
_BOX = np.ones((3, 3), dtype=bool)


def count_passages(mask: np.ndarray, material_is_flow: bool) -> int:
    """How many disconnected flow regions one cut's boolean image holds (see the module note for which)."""
    from scipy import ndimage
    m = np.asarray(mask, dtype=bool)
    if m.ndim != 2 or m.size == 0:
        return 0
    if material_is_flow:
        lab, n = ndimage.label(m, structure=_BOX)
        if n == 0:
            return 0
        sizes = np.bincount(lab.reshape(-1), minlength=n + 1)[1:]
        return int(np.count_nonzero(sizes >= MIN_REGION_PX))
    if not m.any():
        return 0
    lab, n = ndimage.label(~m, structure=_CROSS)
    if n == 0:
        return 0
    border = np.unique(np.concatenate([lab[0, :], lab[-1, :], lab[:, 0], lab[:, -1]]))
    sizes = np.bincount(lab.reshape(-1), minlength=n + 1)
    inside = np.ones(n + 1, dtype=bool)
    inside[0] = False
    inside[border] = False
    return int(np.count_nonzero(inside & (sizes >= MIN_REGION_PX)))


def passage_count(per_station: list[int] | np.ndarray) -> int | None:
    """The passage count of a part from its stations' counts: the median over the stations that carry any flow,
    END_GUARD stations in from each end. None when no station carries flow, which is not the same as one."""
    counts = np.asarray(per_station, dtype=int)
    inner = counts[END_GUARD:len(counts) - END_GUARD] if len(counts) > 2 * END_GUARD else counts
    live = inner[inner > 0]
    if len(live) == 0:
        return None
    return int(np.median(live))


def refuses(count: int | None) -> bool:
    """True when a single-passage verdict cannot be given: more than one passage crosses the cut."""
    return count is not None and count > 1
