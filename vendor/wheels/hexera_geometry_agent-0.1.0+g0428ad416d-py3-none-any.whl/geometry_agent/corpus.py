"""Parametric geometry families with ground truth derived from how each part was built.

Every case is a function of a few dimensions, so the expected answers (how many ports, where, how long each
stub is, which risks must fire) are computed from the same numbers that built the mesh. Ports are described by
position, not by opening id, because ids follow measured area and the evaluator matches them by nearest centroid.

Families: distributors and collectors, swept elbows and S-bends, tees, crosses and wyes, contractions,
diffusers, reducers, venturis and nozzles, microchannel arrays, rotors with hub, shroud and rotating zone,
wings with slat and flap, bluff bodies with wheels, fuselage plus wing plus nacelles, plus devious variants
(off-axis, millimetre files, pinholes and seams, wall solids instead of fluids, sealed cavities, near-touching
bodies) and adversarial briefs that contradict the file."""
from __future__ import annotations

import json
import math
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np
import trimesh
from trimesh.transformations import rotation_matrix

from geometry_agent.synthetic import _cyl, _union, naca0012

SECTIONS = 48


# ---- primitives ----------------------------------------------------------------------------------------------

def _box(extents, center=(0.0, 0.0, 0.0)) -> trimesh.Trimesh:
    b = trimesh.creation.box(extents=extents)
    b.apply_translation(center)
    return b


def _axis_frame(axis: str) -> np.ndarray:
    """Rotation taking local +Z to the requested world axis."""
    if axis == "z":
        return np.eye(4)
    if axis == "x":
        return rotation_matrix(np.pi / 2, [0, 1, 0])
    if axis == "y":
        return rotation_matrix(-np.pi / 2, [1, 0, 0])
    raise ValueError(axis)


def revolve_closed(profile: list[tuple[float, float]], axis: str = "x", origin=(0.0, 0.0, 0.0),
                   sections: int = SECTIONS) -> trimesh.Trimesh:
    """Watertight solid of revolution. `profile` is (station, radius) pairs along the axis, radius > 0, stations
    increasing; the two ends are closed with flat caps. Built directly so it is always closed and consistently
    oriented, which trimesh.creation.revolve is not for open profiles."""
    stations = np.asarray([p[0] for p in profile], dtype=float)
    radii = np.asarray([p[1] for p in profile], dtype=float)
    ang = np.linspace(0, 2 * np.pi, sections, endpoint=False)
    rings = []
    for s, r in zip(stations, radii):
        rings.append(np.column_stack([r * np.cos(ang), r * np.sin(ang), np.full(sections, s)]))
    verts = [np.vstack(rings)]
    faces = []
    n = sections
    for k in range(len(stations) - 1):
        a, b = k * n, (k + 1) * n
        for i in range(n):
            j = (i + 1) % n
            faces.append([a + i, b + i, b + j])
            faces.append([a + i, b + j, a + j])
    c0 = len(stations) * n
    c1 = c0 + 1
    verts.append(np.array([[0.0, 0.0, stations[0]], [0.0, 0.0, stations[-1]]]))
    last = (len(stations) - 1) * n
    for i in range(n):
        j = (i + 1) % n
        faces.append([c0, j, i])
        faces.append([c1, last + i, last + j])
    m = trimesh.Trimesh(np.vstack(verts), np.asarray(faces), process=True)
    m.apply_transform(_axis_frame(axis))
    m.apply_translation(origin)
    m.merge_vertices()
    trimesh.repair.fix_normals(m)
    return m


def sweep_circle(path: np.ndarray, radius: float) -> trimesh.Trimesh:
    from shapely.geometry import Point
    circle = Point(0, 0).buffer(radius, resolution=12)
    m = trimesh.creation.sweep_polygon(circle, np.asarray(path, dtype=float))
    m.merge_vertices()
    trimesh.repair.fix_normals(m)
    return m


def bend_path(d: float, leg: float, radius: float, angle_deg: float, n_arc: int = 24) -> np.ndarray:
    """Straight leg along +x, an arc of the given radius turning towards +y, then a straight leg."""
    a = np.radians(angle_deg)
    pts = [np.array([0.0, 0.0, 0.0]), np.array([leg, 0.0, 0.0])]
    center = np.array([leg, radius, 0.0])
    for t in np.linspace(0, a, n_arc + 1)[1:]:
        pts.append(center + radius * np.array([np.sin(t), -np.cos(t), 0.0]))
    end_dir = np.array([np.cos(a), np.sin(a), 0.0])
    pts.append(pts[-1] + leg * end_dir)
    return np.array(pts)


def _rotate_offaxis(m: trimesh.Trimesh, seed: int = 0) -> trimesh.Trimesh:
    m = m.copy()
    m.apply_transform(rotation_matrix(np.radians(37 + 11 * seed), [0, 0, 1]))
    m.apply_transform(rotation_matrix(np.radians(20 + 7 * seed), [1, 0, 0]))
    m.apply_translation([0.31, -0.12, 0.07])
    return m


def _transform_point(p, m_before: trimesh.Trimesh, m_after: trimesh.Trimesh):
    return p


# ---- case description ----------------------------------------------------------------------------------------

@dataclass
class Case:
    name: str
    family: str
    purpose: str
    build: Callable[[], trimesh.Trimesh]
    expected: dict[str, Any] = field(default_factory=dict)
    brief: str = ""
    note: str = ""

    def write(self, out: Path) -> Path:
        d = out / self.name
        d.mkdir(parents=True, exist_ok=True)
        geo = d / "geometry.stl"
        if not geo.exists():
            self.build().export(geo)
        exp = {"purpose": self.purpose, "family": self.family, **self.expected}
        if self.brief:
            exp["brief"] = self.brief
        if self.note:
            exp["note"] = self.note
        (d / "expected.json").write_text(json.dumps(exp, indent=1, default=float))
        return d


def port(near, role: str, d: float | None = None, stub: float | None = None, kind: str = "cap",
         classification: str = "port_candidate", needs_model: bool = False, stub_tol: float | None = None) -> dict[str, Any]:
    p = {"near": [float(v) for v in near], "role": role, "kind": kind, "class": classification, "needs_model": needs_model}
    if d is not None:
        p["hydraulic_diameter"] = float(d)
    if stub is not None:
        p["stub_over_d"] = float(stub)
    if stub_tol is not None:
        p["stub_tol"] = float(stub_tol)
    return p


#: A stub ends where the section changes by 20% or drifts by 0.3 diameters, so a gentle bend or a slow taper
#: lets the march run a diameter or so past the straight run. Cases built on those shapes say so.
GENTLE_STUB_TOL = 1.6


# ---- internal flow families ----------------------------------------------------------------------------------

def _header(n: int, stub_over_d: float, d_main: float, d_branch: float, end_over_d: float, pitch_over_d: float):
    """A header pipe with n branches on top. The header runs end_over_d main diameters past the first and last
    branch so its own ends carry long stubs; branch stubs are stub_over_d branch diameters."""
    end = end_over_d * d_main
    pitch = pitch_over_d * d_main
    main_len = 2 * end + (n - 1) * pitch
    xs = [end + k * pitch for k in range(n)]
    main = _cyl(d_main / 2, main_len, "x", (0, 0, 0))
    branches = [_cyl(d_branch / 2, d_main / 2 + stub_over_d * d_branch, "y", (x, 0, 0)) for x in xs]
    tip = d_main / 2 + stub_over_d * d_branch
    return _union([main] + branches), main_len, xs, tip


def distributor(n: int, stub_over_d: float, d_main: float = 0.10, d_branch: float = 0.04, end_over_d: float = 6.0,
                pitch_over_d: float = 2.0):
    """One large supply end, n small branch outlets along +y, the far end blanked."""
    mesh, main_len, xs, tip = _header(n, stub_over_d, d_main, d_branch, end_over_d, pitch_over_d)
    # the two big ends are identical; a brief that says "the large end is the supply" leaves which one open
    ports = [port((0, 0, 0), "any", d_main, end_over_d, needs_model=True), port((main_len, 0, 0), "any", d_main, end_over_d, needs_model=True)]
    ports += [port((x, tip, 0), "outlet", d_branch, stub_over_d, needs_model=True) for x in xs]
    expect = ["velocity_spread"] if d_main / d_branch > 2 else []
    forbid = []
    if stub_over_d < 5:
        expect.append("short_stub")
    else:
        forbid.append("short_stub")
    exp = {"openings": n + 2, "regions": 1, "watertight": True, "ports": ports, "expect_risks": expect, "forbid_risks": forbid,
           "model_roles_any_of_by_position": [[[0, 0, 0], "inlet"], [[main_len, 0, 0], "inlet"]]}
    return mesh, exp


def collector(n: int, stub_over_d: float, d_main: float = 0.10, d_branch: float = 0.03, end_over_d: float = 6.0,
              pitch_over_d: float = 1.5):
    mesh, main_len, xs, tip = _header(n, stub_over_d, d_main, d_branch, end_over_d, pitch_over_d)
    ports = [port((x, tip, 0), "inlet", d_branch, stub_over_d, needs_model=True) for x in xs]
    ports += [port((0, 0, 0), "any", d_main, end_over_d, needs_model=True), port((main_len, 0, 0), "any", d_main, end_over_d, needs_model=True)]
    exp = {"openings": n + 2, "regions": 1, "watertight": True, "ports": ports,
           "model_roles_any_of_by_position": [[[0, 0, 0], "outlet"], [[main_len, 0, 0], "outlet"]]}
    return mesh, exp


def elbow_swept(d: float, r_over_d: float, angle: float, leg_over_d: float):
    leg = leg_over_d * d
    path = bend_path(d, leg, r_over_d * d, angle)
    mesh = sweep_circle(path, d / 2)
    ports = [port(path[0], "inlet", d, leg_over_d, needs_model=True, stub_tol=GENTLE_STUB_TOL),
             port(path[-1], "outlet", d, leg_over_d, needs_model=True, stub_tol=GENTLE_STUB_TOL)]
    exp = {"openings": 2, "regions": 1, "watertight": True, "ports": ports}
    if leg_over_d < 5:
        exp["expect_risks"] = ["short_stub"]
    else:
        exp["forbid_risks"] = ["short_stub"]
    return mesh, exp


def s_bend(d: float, offset_over_d: float, leg_over_d: float, span_over_d: float = 6.0):
    leg, off, span = leg_over_d * d, offset_over_d * d, span_over_d * d
    t = np.linspace(0, 1, 40)
    mid = np.column_stack([leg + t * span, off * (1 - np.cos(np.pi * t)) / 2, np.zeros_like(t)])
    path = np.vstack([[[0, 0, 0]], mid, [[leg + span + leg, off, 0]]])
    mesh = sweep_circle(path, d / 2)
    ports = [port(path[0], "inlet", d, leg_over_d, needs_model=True, stub_tol=GENTLE_STUB_TOL),
             port(path[-1], "outlet", d, leg_over_d, needs_model=True, stub_tol=GENTLE_STUB_TOL)]
    exp = {"openings": 2, "regions": 1, "watertight": True, "ports": ports}
    exp["expect_risks" if leg_over_d < 5 else "forbid_risks"] = ["short_stub"]
    return mesh, exp


def tee(d: float, run_over_d: float, branch_over_d: float, equal: bool = True):
    L = run_over_d * d * 2
    main = _cyl(d / 2, L, "x", (0, 0, 0))
    db = d if equal else d / 2
    branch = _cyl(db / 2, d / 2 + branch_over_d * db, "y", (L / 2, 0, 0))
    mesh = _union([main, branch])
    ports = [port((0, 0, 0), "inlet", d, run_over_d, needs_model=True), port((L, 0, 0), "outlet", d, run_over_d, needs_model=True),
             port((L / 2, d / 2 + branch_over_d * db, 0), "outlet", db, branch_over_d, needs_model=True)]
    exp = {"openings": 3, "regions": 1, "watertight": True, "ports": ports}
    exp["expect_risks" if min(run_over_d, branch_over_d) < 5 else "forbid_risks"] = ["short_stub"]
    if not equal:
        exp.setdefault("expect_risks", [])
        if "velocity_spread" not in exp["expect_risks"]:
            exp["expect_risks"] = exp.get("expect_risks", []) + (["velocity_spread"] if d / db > 2 else [])
    return mesh, exp


def cross(d: float, leg_over_d: float):
    L = leg_over_d * d
    a = _cyl(d / 2, 2 * L + d, "x", (-L - d / 2, 0, 0))
    b = _cyl(d / 2, 2 * L + d, "y", (0, -L - d / 2, 0))
    mesh = _union([a, b])
    ends = [(-L - d / 2, 0, 0), (L + d / 2, 0, 0), (0, -L - d / 2, 0), (0, L + d / 2, 0)]
    ports = [port(e, "opening_unknown", d, leg_over_d, needs_model=True) for e in ends]
    exp = {"openings": 4, "regions": 1, "watertight": True, "ports": ports}
    exp["expect_risks" if leg_over_d < 5 else "forbid_risks"] = ["short_stub"]
    return mesh, exp


def wye(d: float, leg_over_d: float, angle_deg: float = 45.0):
    """Two legs merge at the origin into one trunk along +x; the second leg comes in at angle_deg from the first."""
    L = leg_over_d * d
    leg_a = _cyl(d / 2, L + d, "x", (-(L + d), 0, 0))
    leg_b = _cyl(d / 2, L + d, "x", (-(L + d), 0, 0))
    leg_b.apply_transform(rotation_matrix(np.radians(angle_deg), [0, 0, 1]))
    trunk = _cyl(d / 2, L + d, "x", (-d, 0, 0))
    mesh = _union([leg_a, leg_b, trunk])
    a = np.radians(angle_deg)
    end_b = (-(L + d) * np.cos(a), -(L + d) * np.sin(a), 0.0)
    ports = [port((-(L + d), 0, 0), "inlet", d, leg_over_d, needs_model=True, stub_tol=GENTLE_STUB_TOL),
             port(end_b, "inlet", d, leg_over_d, needs_model=True, stub_tol=GENTLE_STUB_TOL),
             port((L, 0, 0), "outlet", d, leg_over_d, needs_model=True, stub_tol=GENTLE_STUB_TOL)]
    exp = {"openings": 3, "regions": 1, "watertight": True, "ports": ports}
    return mesh, exp


def _pipe_profile(d_in: float, d_out: float, l_in: float, l_mid: float, l_out: float) -> list[tuple[float, float]]:
    return [(0.0, d_in / 2), (l_in, d_in / 2), (l_in + l_mid, d_out / 2), (l_in + l_mid + l_out, d_out / 2)]


def conical_diffuser(d_in: float, area_ratio: float, half_angle_deg: float, run_over_d: float = 4.0):
    d_out = d_in * math.sqrt(area_ratio)
    l_mid = (d_out - d_in) / 2 / math.tan(math.radians(half_angle_deg))
    l_in, l_out = run_over_d * d_in, run_over_d * d_out
    mesh = revolve_closed(_pipe_profile(d_in, d_out, l_in, l_mid, l_out), "x")
    total = l_in + l_mid + l_out
    ports = [port((0, 0, 0), "inlet", d_in, run_over_d, needs_model=True, stub_tol=GENTLE_STUB_TOL),
             port((total, 0, 0), "outlet", d_out, run_over_d, needs_model=True, stub_tol=GENTLE_STUB_TOL)]
    exp = {"openings": 2, "regions": 1, "watertight": True, "ports": ports, "forbid_risks": ["ring_faces_present"]}
    if run_over_d < 5:
        exp["expect_risks"] = ["short_stub"]
    else:
        exp["forbid_risks"].append("short_stub")
    return mesh, exp


def reducer(d_in: float, d_out: float, run_over_d: float = 6.0):
    l_mid = (d_in - d_out) / 2 / math.tan(math.radians(15))
    mesh = revolve_closed(_pipe_profile(d_in, d_out, run_over_d * d_in, l_mid, run_over_d * d_out), "x")
    total = run_over_d * d_in + l_mid + run_over_d * d_out
    ports = [port((0, 0, 0), "inlet", d_in, run_over_d, needs_model=True, stub_tol=GENTLE_STUB_TOL),
             port((total, 0, 0), "outlet", d_out, run_over_d, needs_model=True, stub_tol=GENTLE_STUB_TOL)]
    exp = {"openings": 2, "regions": 1, "watertight": True, "ports": ports, "forbid_risks": ["short_stub", "ring_faces_present"]}
    if d_in / d_out > 2:
        exp["expect_risks"] = ["velocity_spread"]
    return mesh, exp


def sudden_contraction(d_in: float, d_out: float, run_over_d: float = 6.0):
    l_in, l_out = run_over_d * d_in, run_over_d * d_out
    big = _cyl(d_in / 2, l_in, "x", (0, 0, 0))
    small = _cyl(d_out / 2, l_out, "x", (l_in, 0, 0))
    mesh = _union([big, small])
    ports = [port((0, 0, 0), "inlet", d_in, run_over_d, needs_model=True), port((l_in + l_out, 0, 0), "outlet", d_out, run_over_d, needs_model=True),
             port((l_in, 0, 0), "wall", None, None, kind="ring", classification="ring")]
    exp = {"openings": 3, "regions": 1, "watertight": True, "ports": ports, "expect_risks": ["ring_faces_present"],
           "forbid_risks": ["short_stub"]}
    return mesh, exp


def venturi(d: float, beta: float, run_over_d: float = 5.0):
    dt = beta * d
    l_conv = (d - dt) / 2 / math.tan(math.radians(10.5))
    l_div = (d - dt) / 2 / math.tan(math.radians(3.5))
    prof = [(0.0, d / 2), (run_over_d * d, d / 2), (run_over_d * d + l_conv, dt / 2), (run_over_d * d + l_conv + dt, dt / 2),
            (run_over_d * d + l_conv + dt + l_div, d / 2), (2 * run_over_d * d + l_conv + dt + l_div, d / 2)]
    mesh = revolve_closed(prof, "x")
    total = prof[-1][0]
    ports = [port((0, 0, 0), "inlet", d, run_over_d, needs_model=True, stub_tol=GENTLE_STUB_TOL),
             port((total, 0, 0), "outlet", d, run_over_d, needs_model=True, stub_tol=GENTLE_STUB_TOL)]
    exp = {"openings": 2, "regions": 1, "watertight": True, "ports": ports, "forbid_risks": ["short_stub", "ring_faces_present", "velocity_spread"],
           "symmetry_planes_min": 2}
    return mesh, exp


def nozzle(d_in: float, d_exit: float, run_over_d: float = 3.0):
    l_conv = (d_in - d_exit) / 2 / math.tan(math.radians(30))
    prof = [(0.0, d_in / 2), (run_over_d * d_in, d_in / 2), (run_over_d * d_in + l_conv, d_exit / 2),
            (run_over_d * d_in + l_conv + 1.0 * d_exit, d_exit / 2)]
    mesh = revolve_closed(prof, "x")
    ports = [port((0, 0, 0), "inlet", d_in, run_over_d, needs_model=True, stub_tol=GENTLE_STUB_TOL),
             port((prof[-1][0], 0, 0), "outlet", d_exit, 1.0, needs_model=True, stub_tol=GENTLE_STUB_TOL)]
    exp = {"openings": 2, "regions": 1, "watertight": True, "ports": ports, "expect_risks": ["short_stub", "velocity_spread"]}
    return mesh, exp


def microchannel(nx: int, ny: int, d: float, pitch: float, length: float, plenums: bool, port_d: float | None = None):
    """nx*ny parallel channels. With plenums: two boxes join them and each box has one port, so the fluid is
    one body with two openings. Without: nx*ny disconnected tubes."""
    tubes = []
    for i in range(nx):
        for j in range(ny):
            tubes.append(_cyl(d / 2, length, "x", (0, (i - (nx - 1) / 2) * pitch, (j - (ny - 1) / 2) * pitch)))
    if not plenums:
        mesh = trimesh.util.concatenate(tubes)
        exp = {"regions": nx * ny, "watertight": True, "expect_risks": ["region_purpose_mismatch"], "openings": 2 * nx * ny}
        return mesh, exp
    pd = port_d or d * 3
    w = max(nx, ny) * pitch + d
    depth = 2 * d
    pin = _box((depth, w, w), (-depth / 2, 0, 0))
    pout = _box((depth, w, w), (length + depth / 2, 0, 0))
    port_in = _cyl(pd / 2, 4 * pd, "x", (-depth - 4 * pd, 0, 0))
    port_out = _cyl(pd / 2, 4 * pd, "x", (length + depth, 0, 0))
    mesh = _union([pin, pout, port_in, port_out] + tubes)
    ports = [port((-depth - 4 * pd, 0, 0), "inlet", pd, 4.0, needs_model=True), port((length + depth + 4 * pd, 0, 0), "outlet", pd, 4.0, needs_model=True)]
    exp = {"regions": 1, "watertight": True, "ports": ports, "forbid_risks": ["region_purpose_mismatch"], "port_candidates": 2}
    if w / depth <= 10:
        exp["planar_faces_min"] = 8   # the plenums' narrow sides are flat faces; past 10:1 aspect they are not opening candidates at all
    return mesh, exp


def pipe_solid_wall_rect(w: float, h: float, t: float, length: float):
    """A rectangular duct's sheet metal, no fluid inside."""
    outer = _box((length, w + 2 * t, h + 2 * t), (length / 2, 0, 0))
    inner = _box((length + 0.02, w, h), (length / 2, 0, 0))
    m = trimesh.boolean.difference([outer, inner], engine="manifold")
    m.merge_vertices()
    exp = {"regions": 1, "watertight": True, "expect_risks_any": ["wall_shell_to_carve", "solid_wall_representation"],
           "forbid_risks": ["short_stub", "velocity_spread"],
           "port_candidates": 0}
    return m, exp


def fluid_with_sealed_bubble(d: float = 0.05, length: float = 0.5):
    p = _cyl(d / 2, length, "x", (0, 0, 0))
    bubble = trimesh.creation.icosphere(subdivisions=2, radius=d / 5)
    bubble.apply_translation([length / 2, 0, 0])
    m = trimesh.boolean.difference([p, bubble], engine="manifold")
    m.merge_vertices()
    exp = {"regions": 2, "watertight": True, "nested": [["r2", "r1"]], "expect_risks": ["nested_bodies"], "openings_min": 2}
    return m, exp


def two_pipes_near_touching(d: float = 0.05, gap: float = 0.001, length: float = 0.5):
    a = _cyl(d / 2, length, "x", (0, 0, 0))
    b = _cyl(d / 2, length, "x", (0, d + gap, 0))
    m = trimesh.util.concatenate([a, b])
    exp = {"regions": 2, "watertight": True, "expect_risks": ["region_purpose_mismatch"],
           "gap_between_regions_between": [gap * 0.5, gap * 3.0]}
    return m, exp


def pipe_with_pinhole_and_seam(d: float = 0.05, length: float = 0.5):
    from geometry_agent.synthetic import pipe
    m = pipe(d, length)
    for _ in range(2):
        m = m.subdivide()
    wall = np.where(np.abs(m.face_normals[:, 0]) < 0.5)[0]
    cx = m.triangles_center[wall]
    pin = wall[np.argsort(np.abs(cx[:, 0] - length * 0.3) + np.abs(cx[:, 2] - d / 2) + np.abs(cx[:, 1]))[:2]]
    # one contiguous strip of faces along the bottom line between 0.55 L and 0.7 L: an unstitched seam
    on_bottom = (np.abs(cx[:, 1]) < 0.02 * d) & (cx[:, 2] < -0.45 * d)
    in_span = (cx[:, 0] > length * 0.55) & (cx[:, 0] < length * 0.7)
    seam = wall[on_bottom & in_span]
    keep = np.ones(len(m.faces), dtype=bool)
    keep[pin] = False
    keep[seam] = False
    m.update_faces(keep)
    m.remove_unreferenced_vertices()
    exp = {"watertight": False, "expect_risks": ["not_watertight", "surface_holes"], "holes_min": 2,
           "ports": [port((0, 0, 0), "inlet", d, 10.0, needs_model=True), port((length, 0, 0), "outlet", d, 10.0, needs_model=True)]}
    return m, exp


# ---- external and rotating families ------------------------------------------------------------------------------

def rotor_hub_shroud_zone(blades: int = 6, r_tip: float = 0.15, r_hub: float = 0.04, chord: float = 0.05,
                          zone_margin: float = 0.02, shroud_t: float = 0.01, tip_gap: float = 0.005):
    """Hub plus radial blades, a cylindrical rotating-zone fluid body around them, and an annular shroud outside."""
    hub = trimesh.creation.cylinder(radius=r_hub, height=chord * 1.5, sections=SECTIONS)
    parts = [hub]
    for i in range(blades):
        b = trimesh.creation.box(extents=(r_tip - r_hub + 0.005, 0.006, chord))
        b.apply_translation([r_hub + (r_tip - r_hub) / 2, 0, 0])
        b.apply_transform(rotation_matrix(2 * np.pi * i / blades, [0, 0, 1]))
        parts.append(b)
    rotor = _union(parts)
    zone = trimesh.creation.cylinder(radius=r_tip + zone_margin, height=chord * 2.5, sections=SECTIONS)
    shroud = trimesh.creation.annulus(r_min=r_tip + tip_gap + zone_margin, r_max=r_tip + tip_gap + zone_margin + shroud_t, height=chord * 4, sections=SECTIONS)
    m = trimesh.util.concatenate([shroud, zone, rotor])
    exp = {"regions": 3, "watertight": True, "nested_min": 1, "rotational_symmetry_order": blades,
           "expect_risks": ["multi_body_external"]}
    return m, exp


def ducted_rotor_single_zone(blades: int = 5, r_tip: float = 0.12, r_hub: float = 0.03, chord: float = 0.04):
    hub = trimesh.creation.cylinder(radius=r_hub, height=chord * 1.5, sections=SECTIONS)
    parts = [hub]
    for i in range(blades):
        b = trimesh.creation.box(extents=(r_tip - r_hub + 0.004, 0.005, chord))
        b.apply_translation([r_hub + (r_tip - r_hub) / 2, 0, 0])
        b.apply_transform(rotation_matrix(2 * np.pi * i / blades, [0, 0, 1]))
        parts.append(b)
    m = _union(parts)
    exp = {"regions": 1, "watertight": True, "rotational_symmetry_order": blades, "expect_risks": ["rotor_topology"]}
    return m, exp


def wing_slat_flap(chord: float = 0.3, span: float = 0.2, gap: float = 0.006):
    main = naca0012(chord=chord * 0.7, span=span)
    slat = naca0012(chord=chord * 0.12, span=span)
    slat.apply_transform(rotation_matrix(np.radians(25), [0, 0, 1]))
    slat.apply_translation([-chord * 0.12 - gap, -chord * 0.03, 0])
    flap = naca0012(chord=chord * 0.25, span=span)
    flap.apply_transform(rotation_matrix(np.radians(-25), [0, 0, 1]))
    flap.apply_translation([chord * 0.7 + gap, -chord * 0.02, 0])
    m = trimesh.util.concatenate([main, slat, flap])
    exp = {"regions": 3, "watertight": True, "expect_risks": ["multi_body_external", "knife_edge"],
           "gap_between_regions_between": [gap * 0.4, gap * 2.5], "forbid_risks": ["region_purpose_mismatch"]}
    return m, exp


def car_body_wheels(L: float = 1.0, W: float = 0.4, H: float = 0.3, wheel_r: float = 0.08, wheel_w: float = 0.06, gap: float = 0.004):
    body = _box((L, W, H), (L / 2, 0, wheel_r + gap + H / 2))
    wheels = []
    for x in (0.2 * L, 0.8 * L):
        for y in (-W / 2 - wheel_w / 2 + 0.01, W / 2 + wheel_w / 2 - 0.01):
            w = trimesh.creation.cylinder(radius=wheel_r, height=wheel_w, sections=SECTIONS)
            w.apply_transform(rotation_matrix(np.pi / 2, [1, 0, 0]))
            w.apply_translation([x, y, wheel_r])
            wheels.append(w)
    m = trimesh.util.concatenate([body] + wheels)
    exp = {"regions": 5, "watertight": True, "expect_risks": ["multi_body_external"], "forbid_risks": ["region_purpose_mismatch"],
           "ground_plane_z": 0.0}
    return m, exp


def fuselage_wing_nacelles(L: float = 3.0, r: float = 0.18, span: float = 3.0, chord: float = 0.5, one_body: bool = True):
    fus = trimesh.creation.capsule(radius=r, height=L - 2 * r, count=[24, 24])
    fus.apply_transform(rotation_matrix(np.pi / 2, [0, 1, 0]))
    fus.apply_translation([L / 2, 0, 0])
    wing = naca0012(chord=chord, span=span, n=50)
    wing.apply_transform(rotation_matrix(np.pi / 2, [1, 0, 0]))
    wing.apply_translation([L * 0.45, 0, -r * 0.2])
    nacelles = []
    for y in (-span * 0.3, span * 0.3):
        n = trimesh.creation.annulus(r_min=0.05, r_max=0.08, height=0.4, sections=32)
        n.apply_transform(rotation_matrix(np.pi / 2, [0, 1, 0]))
        n.apply_translation([L * 0.4, y, -r * 0.2 - 0.12])
        nacelles.append(n)
    if one_body:
        pylons = []
        for y in (-span * 0.3, span * 0.3):
            pylons.append(_box((0.25, 0.02, 0.16), (L * 0.42, y, -r * 0.2 - 0.06)))
        m = _union([fus, wing] + nacelles + pylons)
        exp = {"regions": 1, "watertight": True, "forbid_risks": ["multi_body_external"], "symmetry_planes_min": 1}
    else:
        m = trimesh.util.concatenate([fus, wing] + nacelles)
        exp = {"regions": 4, "watertight": True, "expect_risks": ["multi_body_external"]}
    return m, exp


# ---- the corpus ----------------------------------------------------------------------------------------------

def _case(name, family, purpose, builder, brief="", note="", roles_any_at=None, all_roles_any=False, **overrides) -> Case:
    """`roles_any_at`: positions whose role the brief leaves open (the evaluator then accepts any role there);
    `all_roles_any`: the brief contradicts the purpose so no port role can be expected."""
    def build():
        return builder()[0]
    _, exp = builder()
    exp = {**exp, **overrides}
    for p in exp.get("ports", []):
        if all_roles_any or any(math.dist(p["near"], q) < 1e-9 for q in (roles_any_at or [])):
            p["role"] = "any"
    return Case(name=name, family=family, purpose=purpose, build=build, expected=exp, brief=brief, note=note)


def _scaled(builder, scale: float):
    def inner():
        m, exp = builder()
        m = m.copy()
        m.apply_scale(scale)
        exp = json.loads(json.dumps(exp, default=float))
        for p in exp.get("ports", []):
            p["near"] = [v * scale for v in p["near"]]
            if "hydraulic_diameter" in p:
                p["hydraulic_diameter"] *= scale
        if "gap_between_regions_between" in exp:
            exp["gap_between_regions_between"] = [v * scale for v in exp["gap_between_regions_between"]]
        if "model_roles_any_of_by_position" in exp:
            exp["model_roles_any_of_by_position"] = [[[v * scale for v in near], role] for near, role in exp["model_roles_any_of_by_position"]]
        return m, exp
    return inner


def _offaxis(builder, seed: int = 0):
    def inner():
        m, exp = builder()
        T = np.eye(4)
        T = rotation_matrix(np.radians(37 + 11 * seed), [0, 0, 1]) @ T
        T = rotation_matrix(np.radians(20 + 7 * seed), [1, 0, 0]) @ T
        T[:3, 3] += [0.31, -0.12, 0.07]
        m = m.copy()
        m.apply_transform(T)
        exp = json.loads(json.dumps(exp, default=float))
        for p in exp.get("ports", []):
            p["near"] = list((T @ np.array([*p["near"], 1.0]))[:3])
        if "model_roles_any_of_by_position" in exp:
            exp["model_roles_any_of_by_position"] = [[list((T @ np.array([*near, 1.0]))[:3]), role]
                                                     for near, role in exp["model_roles_any_of_by_position"]]
        exp.pop("symmetry_planes_min", None)
        return m, exp
    return inner


def build_cases() -> list[Case]:
    cases: list[Case] = []
    add = cases.append
    ic = "internal_cfd"
    ec = "external_cfd"

    add(_case("distributor_3_long", "manifold", ic, lambda: distributor(3, 6.0),
              brief="Distribution header: the large end is the supply, three branch nozzles on top are the outlets, the far end is blanked."))
    add(_case("distributor_5_short", "manifold", ic, lambda: distributor(5, 1.5),
              brief="Supply manifold with five short branch outlets. Large end feeds it; other large end is capped."))
    add(_case("distributor_8_long", "manifold", ic, lambda: distributor(8, 6.0, d_main=0.12, d_branch=0.025, pitch_over_d=1.2),
              brief="Eight-nozzle distribution header, supplied from the large end, blanked at the far end."))
    add(_case("collector_6", "manifold", ic, lambda: collector(6, 6.0),
              brief="Return collector: six small branches are inlets feeding the header; one large end is the outlet, the other is blanked."))
    add(_case("elbow_swept_r1p5", "bend", ic, lambda: elbow_swept(0.05, 1.5, 90, 6.0), brief="Long-radius 90 degree pipe elbow; flow enters at the +x leg end."))
    add(_case("elbow_tight_r0p75", "bend", ic, lambda: elbow_swept(0.05, 0.75, 90, 6.0), brief="Short-radius 90 degree elbow."))
    add(_case("elbow_45_short_legs", "bend", ic, lambda: elbow_swept(0.05, 1.0, 45, 2.0), brief="45 degree bend with short tangents."))
    add(_case("s_bend", "bend", ic, lambda: s_bend(0.05, 3.0, 6.0), brief="Offset S-bend between two parallel pipe runs."))
    add(_case("s_bend_short_legs", "bend", ic, lambda: s_bend(0.05, 3.0, 1.0), brief="Offset S-bend with almost no straight run at either end."))
    add(_case("tee_equal", "junction", ic, lambda: tee(0.05, 6.0, 6.0), brief="Equal tee: flow enters the run at -x and splits between the run outlet and the branch."))
    add(_case("tee_reducing_short_branch", "junction", ic, lambda: tee(0.05, 6.0, 1.5, equal=False), brief="Reducing tee with a very short branch outlet."))
    add(_case("cross_4way", "junction", ic, lambda: cross(0.05, 6.0), brief="Four-way cross; which legs are inlets is not decided yet."))
    add(_case("wye_45", "junction", ic, lambda: wye(0.05, 6.0), brief="45 degree wye merging two streams into one trunk."))
    add(_case("conical_diffuser_7deg", "area_change", ic, lambda: conical_diffuser(0.05, 4.0, 7.0), brief="Conical diffuser, area ratio 4."))
    add(_case("conical_diffuser_20deg", "area_change", ic, lambda: conical_diffuser(0.05, 4.0, 20.0), brief="Wide-angle conical diffuser; separation expected."))
    add(_case("reducer_2to1", "area_change", ic, lambda: reducer(0.10, 0.05), brief="Concentric reducer from 100 to 50."))
    add(_case("reducer_3to1", "area_change", ic, lambda: reducer(0.15, 0.05), brief="Concentric reducer 3:1."))
    add(_case("sudden_contraction", "area_change", ic, lambda: sudden_contraction(0.10, 0.05), brief="Sudden contraction; the step shoulder is a wall."))
    add(_case("venturi_beta0p5", "area_change", ic, lambda: venturi(0.10, 0.5), brief="Classical venturi, beta 0.5."))
    add(_case("nozzle_convergent", "area_change", ic, lambda: nozzle(0.10, 0.03), brief="Convergent nozzle exhausting to atmosphere at the small end."))
    add(_case("microchannel_4x4_plenums", "microchannel", ic, lambda: microchannel(4, 4, 0.002, 0.004, 0.05, True),
              brief="Cold plate: sixteen 2 mm channels between an inlet plenum and an outlet plenum, each with one port."))
    add(_case("microchannel_6x6_no_plenums", "microchannel", ic, lambda: microchannel(6, 6, 0.002, 0.004, 0.05, False),
              brief="Microchannel array, 36 channels.", note="no plenums: 36 disconnected tubes; the file is not one fluid body"))
    add(_case("microchannel_10x10_plenums", "microchannel", ic, lambda: microchannel(10, 10, 0.001, 0.002, 0.04, True, port_d=0.006),
              brief="100-channel cold plate with plenums.", note="scale: many facets, planar plenum faces must not become ports"))
    add(_case("duct_wall_solid_rect", "representation", ic, lambda: pipe_solid_wall_rect(0.2, 0.1, 0.004, 0.8),
              brief="Rectangular HVAC duct, 200 by 100, flow along it.", note="the file is the sheet metal, not the air"))
    add(_case("fluid_with_sealed_bubble", "representation", ic, lambda: fluid_with_sealed_bubble(),
              brief="Straight pipe.", note="a sealed void inside the fluid: dead volume"))
    add(_case("two_pipes_near_touching", "representation", ic, lambda: two_pipes_near_touching(),
              brief="Straight pipe.", note="two bodies 1 mm apart, neither connected"))
    add(_case("pipe_pinhole_and_seam", "repair", ic, lambda: pipe_with_pinhole_and_seam(),
              brief="Straight pipe, flow from -x to +x."))
    add(_case("distributor_offaxis_mm", "devious", ic, _scaled(_offaxis(lambda: distributor(3, 1.5)), 1000.0),
              brief="Distribution manifold with three branch outlets, supplied from the large end.", unit_best_guess="mm",
              note="rotated and in millimetres"))
    add(_case("venturi_offaxis", "devious", ic, _offaxis(lambda: venturi(0.10, 0.5), seed=1), brief="Venturi meter."))
    add(_case("rotor_hub_shroud_zone", "rotating", ec, lambda: rotor_hub_shroud_zone(),
              brief="Six-blade fan rotor with a cylindrical rotating zone body around it and a shroud ring outside. Run as MRF."))
    add(_case("ducted_rotor_single_zone", "rotating", ec, lambda: ducted_rotor_single_zone(),
              brief="Five-blade rotor, 3000 rpm about z.", note="rotating machinery with one zone: cannot rotate"))
    add(_case("wing_slat_flap", "external", ec, lambda: wing_slat_flap(), brief="Three-element high-lift wing section: slat, main, flap."))
    add(_case("car_body_wheels", "external", ec, lambda: car_body_wheels(), brief="Bluff car-like body with four wheels on the ground plane z=0."))
    add(_case("fuselage_wing_nacelles_one_body", "external", ec, lambda: fuselage_wing_nacelles(one_body=True),
              brief="Transport aircraft: fuselage, wing, two underwing nacelles, single body."))
    add(_case("fuselage_wing_nacelles_bodies", "external", ec, lambda: fuselage_wing_nacelles(one_body=False),
              brief="Transport aircraft exported as separate bodies.", note="wing and nacelles are separate, unjoined bodies"))
    far_2 = distributor(2, 6.0)[1]["ports"][1]["near"]
    add(_case("brief_wrong_outlet_count", "adversarial", ic, lambda: distributor(2, 6.0),
              brief="Manifold with one inlet and four outlets.", expect_brief_conflicts_min=1, model_required=["brief conflicts"],
              roles_any_at=[far_2], note="file has two branches and two big ends (three outlets at most), brief says four"))
    add(_case("brief_wrong_size", "adversarial", ic, lambda: venturi(0.10, 0.5),
              brief="Venturi with a 500 mm throat and 100 mm pipe.", expect_brief_conflicts_min=1, model_required=["brief conflicts"],
              note="throat is 50 in file units; a 500 mm throat contradicts the 100 mm pipe either way"))
    add(_case("brief_wrong_purpose", "adversarial", ec, lambda: reducer(0.10, 0.05),
              brief="External aerodynamics of this wing section at 60 m/s.", expect_brief_conflicts_min=1, model_required=["brief conflicts"],
              all_roles_any=True, forbid_risks=["ring_faces_present"],
              note="a pipe reducer submitted as external aero; the purpose is the user's, so the ends become walls"))
    far_3 = [v * 1000.0 for v in distributor(3, 6.0)[1]["ports"][1]["near"]]
    add(_case("brief_wrong_units", "adversarial", ic, _scaled(lambda: distributor(3, 6.0), 1000.0),
              brief="Manifold, 4 inch main, 1.5 inch branches.", unit_assumed="mm",
              roles_any_at=[far_3], unit_best_guess="mm",
              note="800 file units long; the inch sizes match the bores only in mm: unit evidence, not a conflict (plan v2)"))
    return cases


def write_corpus(out: Path, only: list[str] | None = None) -> Path:
    out.mkdir(parents=True, exist_ok=True)
    for c in build_cases():
        if only and c.name not in only:
            continue
        c.write(out)
    return out


def case_names() -> list[str]:
    return [c.name for c in build_cases()]
