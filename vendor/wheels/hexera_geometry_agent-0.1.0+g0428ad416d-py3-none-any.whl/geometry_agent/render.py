"""Flat-shaded views with X/Y/Z arrows and labelled openings. matplotlib only, so it runs headless anywhere.

`render_direction` is the CLI's single-view path (one direction, an optional focus on one opening) and the
matplotlib fallback of the vision renderer. `render_eight` delegates to `geometry_agent.vision.render`,
which loads the mesh once, labels the openings once, decimates large parts and caches by content hash, and
which draws a cutaway beside the eight."""
from __future__ import annotations

from pathlib import Path

import numpy as np

from geometry_agent.facts.load import load_mesh
from geometry_agent.facts.openings import detect_openings

DIRECTIONS = {
    "+x": (0, 0), "-x": (0, 180), "+y": (0, 90), "-y": (0, -90), "+z": (90, 0), "-z": (-90, 0),
    "iso": (30, 45), "iso2": (30, -135),
}
EIGHT_VIEWS = ["+x", "-x", "+y", "-y", "+z", "-z", "iso", "iso2"]


def _fig(mesh, elev: float, azim: float, focus=None, labels=True, title: str = "", openings=None):
    """A matplotlib figure of `mesh` from (elev, azim) with the triad and the opening labels drawn in 3D.
    `openings` are labelled when given; otherwise they are detected here (one detection per figure, which is
    why the vision renderer passes them in)."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from mpl_toolkits.mplot3d.art3d import Poly3DCollection

    fig = plt.figure(figsize=(7, 7), dpi=110)
    ax = fig.add_subplot(111, projection="3d")
    tris = mesh.vertices[mesh.faces]
    light = np.array([0.4, 0.5, 0.75])
    shade = 0.45 + 0.55 * np.clip(mesh.face_normals @ light, 0, 1)
    colors = np.column_stack([shade * 0.75, shade * 0.8, shade * 0.9, np.ones_like(shade)])
    coll = Poly3DCollection(tris, facecolors=colors, edgecolors="none", shade=False)
    ax.add_collection3d(coll)

    lo, hi = mesh.bounds
    c = (lo + hi) / 2
    r = float(np.max(hi - lo)) / 2
    if focus is not None:
        c = np.asarray(focus)
        r = r / 3
    ax.set_xlim(c[0] - r, c[0] + r)
    ax.set_ylim(c[1] - r, c[1] + r)
    ax.set_zlim(c[2] - r, c[2] + r)
    ax.set_box_aspect((1, 1, 1))

    origin = lo - 0.18 * (hi - lo)
    L = 0.6 * r
    for vec, col, name in (((L, 0, 0), "red", "X"), ((0, L, 0), "green", "Y"), ((0, 0, L), "blue", "Z")):
        ax.quiver(*origin, *vec, color=col, arrow_length_ratio=0.15, linewidth=2)
        ax.text(*(origin + np.array(vec) * 1.15), name, color=col, fontsize=11, weight="bold")

    if labels:
        for o in (openings if openings is not None else detect_openings(mesh))[:12]:
            ax.text(*o.centroid, o.id, color="black", fontsize=9, weight="bold",
                    bbox={"boxstyle": "round,pad=0.2", "fc": "yellow", "alpha": 0.8, "lw": 0})
    ax.view_init(elev=elev, azim=azim)
    ax.set_axis_off()
    ax.set_title(title, fontsize=10)
    return fig


def render_direction(path: str | Path, direction: str, out_dir: str | Path, focus=None) -> Path:
    mesh = load_mesh(Path(path))
    elev, azim = DIRECTIONS[direction]
    fig = _fig(mesh, elev, azim, focus=focus, title=f"{Path(path).name}  view {direction}")
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    p = out / f"{Path(path).stem}_{direction.replace('+', 'p').replace('-', 'm')}{'_focus' if focus is not None else ''}.png"
    fig.savefig(p, bbox_inches="tight")
    import matplotlib.pyplot as plt
    plt.close(fig)
    return p


def render_eight(path: str | Path, out_dir: str | Path, purpose: str = "internal_cfd") -> list[Path]:
    """The views the vision model is shown, through the cached vision renderer (one load, one opening
    detection): the six axis views, two isometrics and the cutaway. The name is older than the cutaway and is
    kept because the CLI's `render` command is what a person runs to see what the model saw, and the answer has
    to be the same set.

    IT MEASURES NOW, and that is the cost of the stops view becoming a default on 2026-09-16. The stops
    detector reads which openings the measurement calls a way in or out and whether the mesh is the material,
    and `render_views` raises rather than drawing a blank panel when it is not told. Dropping the view here
    instead would have been the cheaper change and the wrong one: the command exists to show a person what the
    model saw, so a set that quietly differs from the model's by one picture is the one failure it must not
    have. `purpose` is what the representation is read for and `internal_cfd` is the CLI's default elsewhere.
    """
    from geometry_agent.agent.catalog import representation
    from geometry_agent.facts.measure import measure
    from geometry_agent.vision.render import DEFAULT_VIEWS, render_views
    from geometry_agent.vision.terminus import mouths_from_openings, solid_from_representation
    facts = measure(str(path), purpose=purpose)
    labels = [(o.id, tuple(o.centroid)) for o in facts.openings]
    return render_views(path, out_dir=out_dir, views=list(DEFAULT_VIEWS), labels=labels,
                        mouths=mouths_from_openings(facts.openings),
                        solid=solid_from_representation(representation(facts, purpose)))
