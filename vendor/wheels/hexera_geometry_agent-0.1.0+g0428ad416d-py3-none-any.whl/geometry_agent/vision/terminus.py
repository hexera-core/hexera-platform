"""Where a passage stops at a wall, found from the mesh and the measured openings, and drawn.

The ceiling study counted 34 misses on "where a passage stops" and found 19 of them in no view at all: every
one of the 14 tee and wye dead legs, and 5 fluid-domain closed header ends. On a tee the run's cap sits exactly
at the branch split with no stub, so the cap face is edge-on in the views along the run and occluded by the
branches in the views across it. No prompt and no second reader reaches a feature that is in none of the
pictures. This module finds those places and draws a picture of them.

THE RULE, and it never reads a brief, a family name or an answer key.

The measurement already knows where every mouth is. A `ring` is an annulus, which is a pipe end with a bore
behind it; a `cap` the measurement classified `port_candidate` has a tube of its own size behind it and is
where the model was cut for meshing. What is left is a flat face that is not a mouth, and one of those is a
STOP when

  1. a run of open passage lies BEHIND it, at least its own hydraulic diameter deep. On a wall shell the march
     crosses one thin wall first, because the outer face of an end cap is the face the measurement names and
     the passage is on the far side of the cap material;
  2. nothing lies AHEAD of it within that same depth. A mixer element and a baffle also present a flat face
     with passage behind, and the passage continues on the other side of them; a stop is where it does not.

Clause 2 is measured over the depth clause 1 found rather than against a constant, so it carries no tuned
number: a passage that stops has to stop for at least as far as it ran.

WHAT THIS CANNOT SEE, and it is a real limit with a number on it. On a fluid domain a closed end and a port
face are the same geometry: a flat disc of the passage's own bore, with the passage behind it and nothing
ahead. `find_stops` therefore returns nothing at all on a fluid domain, and the corpus says why: without that
gate the detector draws 120 panels on the 322 parts and 15 of them land on an opening the brief declares a
port, every one of the 15 on a fluid domain. Gated, it draws 46 and none. The information is not in the
geometry and no threshold reaches it. See docs/vision.md.

THE DRAWING. One panel per stop: the plane that contains the stop's own normal and the passage running into
it, filled by parity the way the strip and the cutaway are filled, cropped to a window around the stop. Green
is material the cut passed through and white is empty, which is the language the strip already uses and the
prompt already explains. A dead leg then reads as a bore that runs into a solid block, which is a difference of
shape and not of shading; the shaded views can only offer shading, and that is why they lose here.

ON since 2026-09-16, and since 2026-09-23 there is no switch: the held-out number that turned it on is the
manifold's closed header end, 12, 12, 13 and 13 of the 13 held out against 2, 4, 3, 3 for the default without
it, which is the row this project had never moved. On luna, the shipped reader, the same view is worth much
less and the honest reading is in `docs/vision.md`: its two whole-corpus draws both scored 4, inside the
default's own 2 to 4. It costs one view of seventeen, 3.5 per cent of a luna pass.

It is drawn from the MEASUREMENT: `render.render_views` raises rather than drawing a blank panel unless it is
handed the measured openings and the representation. A caller with no measurement asks for the views it wants
by name instead, which is what the renderer's own tests do.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

#: The view's name, when it is drawn.
STOPS = "stops"
#: Bumped whenever `find_stops` decides differently or `stops_frame` draws differently, and written into the
#: render manifest so a cached stops view can say which rule drew it. `RENDER_VERSION` deliberately does not
#: move for this: the stops view is off by default, so bumping it would redraw every cached entry in the
#: project to change a picture almost nobody is asking for. This cost a pass already. Two cases of a 322-part
#: run were served pictures drawn by the rule before the fluid-domain gate went in, because nothing in the
#: manifest could tell the two apart, and the arm had to be re-asked for them.
#: 1: the two clauses, the fluid-domain gate, the plane read off the wall's own points, the probe just past
#:    the wall.
#: 2: the gate's input changed source. `find_stops` is byte-identical; what moved is that `bench.mouths_for`
#:    now reads `representation_blind` rather than `representation`, and the latter was measured WITH the
#:    brief and the declared ports. 25 rows flip their `solid` argument and one of them, mini_housing_006,
#:    changes what is drawn. The rule version moves for it because this manifest cannot otherwise tell the two
#:    pictures apart, which is the same hazard that cost a pass at version 1: a caller does not care whether
#:    the decision changed inside the function or at its argument, only that it changed.
#: 3: `is_mouth` stopped reading `classification`. One panel changes over the whole corpus and it is
#:    manifold_006's closed header end, which takes the wall-model manifold row from 14 of 15 to 15 of 15.
#:    See `is_mouth` for what it costs and for how thin the evidence that it costs nothing actually is.
STOPS_RULE = 3

#: A stop must have at least this much open passage behind it, in its own hydraulic diameters. One diameter,
#: because a face with less passage behind it than its own width is a side of a body and not the end of a
#: passage: the flat top of a rectangular duct has the duct's own height behind it and that is what this
#: rejects.
DEPTH_OVER_D = 1.0
#: On a wall shell the march from the named face crosses the cap's own material first. A crossing thicker than
#: this many of the face's own diameters is not a wall, it is a solid body, and the face is its side.
WALL_OVER_D = 0.75
#: How many points of the face are marched. The face of a dead leg is a sliver split in two by the branches, so
#: one ray from its centroid can miss the bore entirely.
SAMPLES = 9
#: At most this many stops are drawn. Ordered by the depth of passage behind them, which puts the dead leg of a
#: run ahead of a 4 mm pocket.
MAX_STOPS = 4
#: The window drawn around a stop, in multiples of the passage's own half width, and where along that window
#: the stop itself sits. 0.62 leaves most of the frame for the passage that runs into it and a clear margin of
#: nothing on the far side, which is the half of the picture that says the passage does not continue.
WINDOW_OVER_HALF_WIDTH = 1.5
STOP_AT_FRACTION = 0.68
#: How far past the wall the passage is measured, in the wall's own diameters. Short on purpose: what sets the
#: panel's scale is the passage AT the stop and not the passage somewhere else along it.
PROBE_OVER_D = 0.25


@dataclass(frozen=True)
class Stop:
    """One place where a passage stops at a wall.

    `opening_id` is the measurement's own id for the face, so a reader can tie the panel back to the labels on
    the shaded views. `up` is the direction the wall itself runs in, which fixes the plane the panel is cut on.
    `depth` is how much open passage runs into it in millimetres, and `half_width` is half the passage's width
    across the panel, which sets the window."""
    opening_id: str
    point: tuple[float, float, float]
    normal: tuple[float, float, float]
    up: tuple[float, float, float]
    depth: float
    half_width: float
    diameter: float


@dataclass(frozen=True)
class Mouth:
    """What the detector needs to know about one measured opening. Built by the caller from the facts, which is
    the only place `classification` exists: `detect_openings_with_faces` leaves it at its default."""
    id: str
    kind: str
    classification: str
    centroid: tuple[float, float, float]
    normal: tuple[float, float, float]
    hydraulic_diameter: float
    area: float


def is_mouth(m: Mouth) -> bool:
    """What the measurement calls a way in or out. A ring is an annulus and has a bore behind it.

    THIS READS `kind` AND NOT `classification`, AND THE SECOND HALF WAS REMOVED ON EVIDENCE. It used to be
    `m.kind == "ring" or m.classification == "port_candidate"`. The two terms are not the same kind of claim.
    `kind` is a statement about the SHAPE of the face the measurement found: a ring is an annulus and an
    annulus has a bore behind it, which is a fact about the geometry. `classification` is the measurement's
    BELIEF about what a face is for, and on a wall shell that belief is sometimes wrong: a closed header end
    with a short stub behind it looks to the classifier exactly like a tube that was cut for meshing.

    It cost a case on the one row this whole view exists for. `manifold__manifold_006` has a real closed header
    end, full bore blocked over four stations by the door-5 measurement, and the classifier calls it
    `port_candidate`, so the old line dropped it before either clause ran. It was the ONLY wall-model manifold
    closed end the detector missed: 14 of 15 with the term, 15 of 15 without it.

    What it costs, counted over all 322 parts by `eval/vision/stops_gate.py` and NOT asserted:

        panels drawn                      44 with the term, 45 without
        panels at a DECLARED port          0 with the term,  0 without
        the one panel that differs        manifold_006 o2, whose brief names a closed end

    And the number that says whether that zero means anything, because a rule that is never tempted has not
    resisted anything: dropping the term newly offers 83 openings to the two clauses, and 6 of those 83 are
    declared ports, all of them in the `annular` family across 3 parts. The clauses reject all 6. Six chances
    is a thin test and it is the honest size of the evidence here, so it is written down rather than rounded up
    into "no false walls in 322 parts".

    The fluid-domain case, where a port face and a closed end really are the same geometry and no rule can tell
    them apart, is NOT what this term was protecting: `find_stops` returns nothing at all on a fluid domain
    before `is_mouth` is ever reached. That gate is still there and is still the load-bearing one."""
    return m.kind == "ring"


def _bbox_exit(point: np.ndarray, direction: np.ndarray, bounds: np.ndarray) -> float:
    """How far the ray runs before it leaves the part's bounding box. The bound on an open march: a bore that
    leaves through a mouth has no far wall to hit and its depth would otherwise read as zero."""
    t = np.inf
    for k in range(3):
        d = float(direction[k])
        if abs(d) < 1e-12:
            continue
        for face in (float(bounds[0][k]), float(bounds[1][k])):
            s = (face - float(point[k])) / d
            if s > 0:
                t = min(t, s)
    return float(t) if np.isfinite(t) else float(np.linalg.norm(bounds[1] - bounds[0]))


def _hits(mesh, point: np.ndarray, direction: np.ndarray, eps: float) -> np.ndarray:
    """Every surface crossing along the ray, as sorted distances from `point`. Started `eps` along so the face
    the ray leaves is not counted as the first thing it meets."""
    loc, _, _ = mesh.ray.intersects_location(np.array([point + eps * direction]), np.array([direction]),
                                             multiple_hits=True)
    if not len(loc):
        return np.zeros(0)
    t = np.sort(np.linalg.norm(loc - point, axis=1))
    return t[t > 0.5 * eps]


def _face_points(mesh, face_indices: np.ndarray, count: int = SAMPLES) -> np.ndarray:
    """The centres of the triangles of the face, largest first. The largest rather than a random draw so the
    same part measures the same twice, and centres rather than vertices so no ray starts on an edge."""
    tris = np.asarray(mesh.vertices)[np.asarray(mesh.faces)[np.asarray(face_indices, dtype=np.int64)]]
    if not len(tris):
        return np.zeros((0, 3))
    areas = 0.5 * np.linalg.norm(np.cross(tris[:, 1] - tris[:, 0], tris[:, 2] - tris[:, 0]), axis=1)
    order = np.argsort(-areas)
    return tris[order[:count] if count else order].mean(axis=1)


def _behind(mesh, p: np.ndarray, n: np.ndarray, dh: float, solid: bool, eps: float,
            bounds: np.ndarray) -> tuple[float, float]:
    """The open passage behind one point of the face, and the wall crossed to reach it, in millimetres. A depth
    of zero means there is no passage there.

    On a wall shell the first crossing is the cap's own material and the passage starts after it; a first
    crossing thicker than `WALL_OVER_D` diameters is not a wall and the face is the side of a solid. On a fluid
    domain the passage starts at the face and there is no wall to cross."""
    t = _hits(mesh, p, -n, eps)
    limit = _bbox_exit(p, -n, bounds)
    if not solid:
        return (float(t[0]) if len(t) else limit), 0.0
    if not len(t) or t[0] > WALL_OVER_D * dh:
        return 0.0, 0.0
    wall = float(t[0])
    return (float(t[1] - wall) if len(t) > 1 else max(limit - wall, 0.0)), wall


def _ahead(mesh, p: np.ndarray, n: np.ndarray, eps: float) -> float:
    """How far ahead of one point of the face the part comes back, or infinity. On a wall shell the first thing
    ahead is ambient and a crossing means another body of the part; on a fluid domain it means fluid again,
    which is a passage that did not stop."""
    t = _hits(mesh, p, n, eps)
    return float(t[0]) if len(t) else float("inf")


def _across(n: np.ndarray) -> np.ndarray:
    """One direction across the march. Deterministic, so the same part measures the same twice."""
    r = np.array([1.0, 0.0, 0.0]) if abs(float(n[0])) < 0.9 else np.array([0.0, 1.0, 0.0])
    r = r - n * float(r @ n)
    return r / max(float(np.linalg.norm(r)), 1e-12)


def _reach(mesh, p: np.ndarray, d: np.ndarray, eps: float, bounds: np.ndarray) -> float:
    t = _hits(mesh, p, d, eps)
    return float(t[0]) if len(t) else _bbox_exit(p, d, bounds)


def spread_direction(points: np.ndarray, n: np.ndarray) -> np.ndarray:
    """The direction across the march that the face itself runs in.

    The cut has to go through the wall or the panel is a picture of the hole beside it. A tee's cap is not a
    disc: the two branches eat the middle of it and leave two slivers at the top and the bottom of the bore, so
    the plane that shows the cap is the one that contains the line between those slivers, and the plane at
    right angles to it passes through the gap and draws nothing. Read off the face's own points rather than off
    the part's bounding box, which is what got this wrong: the box said cut across the thin direction and the
    thin direction was the one with no cap in it."""
    rel = np.asarray(points, dtype=np.float64) - np.asarray(points, dtype=np.float64).mean(axis=0)
    rel = rel - np.outer(rel @ n, n)
    if len(rel) < 2 or not np.isfinite(rel).all() or float(np.abs(rel).max()) <= 0:
        return _across(n)
    w = np.linalg.eigh(rel.T @ rel)[1][:, -1]
    w = w - n * float(w @ n)
    ln = float(np.linalg.norm(w))
    return w / ln if ln > 1e-9 else _across(n)


def _centre_and_half_width(mesh, p: np.ndarray, up: np.ndarray, eps: float,
                           bounds: np.ndarray) -> tuple[np.ndarray, float]:
    """The middle of the passage at `p` along one direction, and half its width there.

    Measured along the panel's own up direction and not in three dimensions, because it sets the panel's scale
    and a chord out of the plane the panel is drawn on is not on the panel. One centring step: the face of a
    dead leg is a sliver at the edge of the bore it caps, so a window centred on the face is a window of wall."""
    q = np.asarray(p, dtype=np.float64)
    half = 0.0
    for _ in range(2):
        plus, minus = _reach(mesh, q, up, eps, bounds), _reach(mesh, q, -up, eps, bounds)
        half = 0.5 * (plus + minus)
        q = q + up * 0.5 * (plus - minus)
    return q, float(half)


def _passes(mesh, m: Mouth, fidx: np.ndarray, solid: bool, eps: float,
            bounds: np.ndarray) -> tuple[float, float] | None:
    """The two clauses, on one measured face. Returns the depth of passage behind it and the thickness of wall
    in front of that passage, or None when the face is not a stop."""
    dh = max(float(m.hydraulic_diameter), 1e-9)
    n = np.asarray(m.normal, dtype=np.float64)
    ln = float(np.linalg.norm(n))
    if ln <= 0:
        return None
    n = n / ln
    pts = _face_points(mesh, fidx)
    if not len(pts):
        return None
    marched = [_behind(mesh, p, n, dh, solid, eps, bounds) for p in pts]
    depth = float(np.median([d for d, _ in marched]))
    if depth < DEPTH_OVER_D * dh:
        return None
    # the passage has to stop for at least as far as it ran. No constant of its own: the depth behind sets the
    # reach, so a mixer element with the bore continuing on the other side of it is not a stop
    aheads = np.array([_ahead(mesh, p, n, eps) for p in pts])
    if float(np.mean(aheads < depth)) > 0.5:
        return None
    return depth, float(np.median([w for _, w in marched]))


def _merge_coplanar(hits: list[tuple[Mouth, float, float, np.ndarray]]
                    ) -> list[tuple[list[Mouth], float, float, np.ndarray, np.ndarray, np.ndarray]]:
    """One wall, not one face. The cap of a tee's dead leg is split in two by the branches that cross it, and
    two half-caps drawn on their own are two pictures of the same thing, each centred on a sliver at the edge
    of the bore. Faces with the same normal in the same plane become one wall at their area-weighted centre,
    and their points are pooled so the panel's plane is cut through all of it."""
    groups: dict[tuple, list[tuple[Mouth, float, float, np.ndarray]]] = {}
    for m, depth, wall, pts in hits:
        n = np.asarray(m.normal, dtype=np.float64)
        n = n / max(float(np.linalg.norm(n)), 1e-12)
        dh = max(float(m.hydraulic_diameter), 1e-9)
        key = (tuple(np.round(n, 2)), round(float(np.asarray(m.centroid) @ n) / (WALL_OVER_D * dh)))
        groups.setdefault(key, []).append((m, depth, wall, pts))
    out = []
    for members in groups.values():
        weight = np.array([max(m.area, 1e-12) for m, _, _, _ in members])
        centre = (np.array([m.centroid for m, _, _, _ in members]).T * weight).sum(axis=1) / weight.sum()
        n = np.asarray(members[0][0].normal, dtype=np.float64)
        out.append(([m for m, _, _, _ in members], max(d for _, d, _, _ in members),
                    max(w for _, _, w, _ in members), centre,
                    n / max(float(np.linalg.norm(n)), 1e-12),
                    np.concatenate([p for _, _, _, p in members])))
    return out


def find_stops(mesh, mouths: list[Mouth], faces_of: list[np.ndarray], solid: bool,
               max_stops: int = MAX_STOPS) -> list[Stop]:
    """Every place a passage stops at a wall, widest passage first.

    `mouths` and `faces_of` are the measured openings and the faces each is made of, in the same order.
    `solid` says whether the mesh is the material (a wall shell or a solid body) or the fluid itself.

    ON A FLUID DOMAIN IT FINDS NOTHING, ON PURPOSE, AND THIS IS THE LOAD-BEARING LINE IN THE FILE. When the
    mesh is the fluid, a closed end and a port face are the same geometry: a flat disc of the passage's own
    bore, with the passage behind it and nothing ahead, and both come back `port_candidate` or both come back
    `planar_face` depending on what is behind them. There is no rule that finds one without inventing the
    other, and the corpus says so with a number: run without this gate, the detector draws 120 panels, 15 of
    them at an opening the brief declares a port, and every one of those 15 is a fluid domain. Gated, it draws
    46 and none. The information is not in the geometry, so the honest answer is to draw nothing rather than to
    guess, and a threshold cannot be loosened into this. Two of the three rows the ceiling study wanted are
    fluid-domain rows and this is why they stay unreachable.

    A solid end cap presents two faces, one to each side, and both can pass the two clauses. They are the same
    wall and one picture of it is enough.

    Nothing here reads a brief, a family or a declared role. `tests/test_vision_terminus.py` pins that."""
    v = np.asarray(mesh.vertices, dtype=np.float64)
    if not len(v) or not solid:
        return []
    bounds = np.array([v.min(axis=0), v.max(axis=0)])
    eps = max(float(np.linalg.norm(bounds[1] - bounds[0])) * 1e-5, 1e-9)
    hits: list[tuple[Mouth, float, float, np.ndarray]] = []
    for m, fidx in zip(mouths, faces_of):
        if is_mouth(m):
            continue
        got = _passes(mesh, m, fidx, solid, eps, bounds)
        if got is not None:
            hits.append((m, got[0], got[1], _face_points(mesh, fidx, count=0)))
    found: list[Stop] = []
    for members, depth, wall, raw, n, pts in _merge_coplanar(hits):
        dh = max(float(np.median([m.hydraulic_diameter for m in members])), 1e-9)
        up = np.cross(np.cross(n, spread_direction(pts, n)), n)
        up = up / max(float(np.linalg.norm(up)), 1e-12)
        # just past the wall and no further. Probing half way down the passage measured the wrong place on
        # every passage that changes section: a reducer's large end read the bore half way along its taper, so
        # the window came out narrower than the mouth it was drawn for and the panel was all material
        probe = raw - n * (wall + min(PROBE_OVER_D * dh, 0.25 * depth))
        centre, half = _centre_and_half_width(mesh, probe, up, eps, bounds)
        found.append(Stop(opening_id="+".join(sorted(m.id for m in members)),
                          point=tuple(float(x) for x in centre + n * float((raw - centre) @ n)),
                          normal=tuple(float(x) for x in n),
                          up=tuple(float(x) for x in up),
                          depth=depth, half_width=max(half, 0.5 * dh), diameter=dh))
    return _one_per_wall(found)[:max_stops]


def _one_per_wall(found: list[Stop]) -> list[Stop]:
    """The two faces of one cap reduced to the side with the wider passage, then widest passage first."""
    keep: list[Stop] = []
    for s in sorted(found, key=lambda s: (-s.depth, s.opening_id)):
        n, p = np.asarray(s.normal), np.asarray(s.point)
        twin = any(float(np.asarray(k.normal) @ n) < -0.9
                   and abs(float((np.asarray(k.point) - p) @ n)) <= WALL_OVER_D * max(s.diameter, k.diameter)
                   and float(np.linalg.norm((np.asarray(k.point) - p) - n * ((np.asarray(k.point) - p) @ n)))
                   <= max(s.half_width, k.half_width)
                   for k in keep)
        if not twin:
            keep.append(s)
    return keep


#: The caption under the panels. It says what the DRAWING is and never what the drawing means: round one's
#: `internals` variant told the model in words what the measurement knew and the score fell from 61 of 72 to 48
#: at p = 0.001. "one end of a passage" is as far as this goes, and an end is a mouth or a wall for the reader
#: to say which.
STOPS_CAPTION = ("each panel is a lengthwise cut at one end of a passage, which runs in from the panel's left")
STOPS_LEGEND = "green = material where that cut passed through it, white = empty; panels are not to one scale"
#: Panels across, at each count. One column up to two stops, because a passage that runs in from the left and
#: stops needs a panel wider than it is tall and two side by side would each be taller than wide.
STOPS_COLS = {1: 1, 2: 1, 3: 2, 4: 2}


def stops_frame(vertices: np.ndarray, faces: np.ndarray, max_px: int, found: list[Stop]):
    """The stops view: one filled lengthwise cut per stop, cropped to the passage that runs into it.

    Filled by parity like the strip and the cutaway, so a wall across a bore is a shape and not a shade. Each
    panel carries its own scale, which is the opposite of the strip's rule and for the opposite reason: the
    strip exists to say how a passage CHANGES and one scale is the whole signal, while a panel here exists to
    say what one place looks like and a 24 mm sliver at the end of a 356 mm bore drawn at the part's scale is
    two pixels."""
    from geometry_agent.vision.render import SUPERSAMPLE, ViewFrame, paint_section, section_fill

    px = int(max_px) * SUPERSAMPLE
    frame = ViewFrame(name=STOPS, rgb=np.full((px, px, 3), 255, dtype=np.uint8))
    v = np.asarray(vertices, dtype=np.float64)
    if not len(v) or not len(faces) or not found:
        return frame
    cols = STOPS_COLS.get(len(found), 2)
    rows = int(np.ceil(len(found) / cols))
    top, bottom = int(0.10 * px), int(0.09 * px)
    pw, ph = px // cols, (px - top - bottom) // rows
    rule = np.array([214, 214, 214], dtype=np.uint8)
    for i, stop in enumerate(found):
        col, row = i % cols, i // cols
        x0, y0 = col * pw, top + row * ph
        n = np.asarray(stop.normal, dtype=np.float64)
        up = np.asarray(stop.up, dtype=np.float64)
        m = np.cross(n, up)
        span = 2.0 * WINDOW_OVER_HALF_WIDTH * max(stop.half_width, 0.5 * stop.diameter)
        centre = np.asarray(stop.point, dtype=np.float64) - n * (STOP_AT_FRACTION - 0.5) * span
        per_px = span / max(min(pw, ph), 1)
        a = np.stack([n / per_px, -up / per_px])
        b = np.array([pw / 2.0, ph / 2.0]) - a @ centre
        mask = section_fill(v, faces, np.asarray(stop.point, dtype=np.float64), m, a, b, pw, ph)
        panel = frame.rgb[y0:y0 + ph, x0:x0 + pw]
        panel[0, :] = panel[-1, :] = panel[:, 0] = panel[:, -1] = rule
        paint_section(panel, mask)
        frame.captions.append((f"end {i + 1}", (x0 + 8) / SUPERSAMPLE, (y0 + ph - 0.045 * px) / SUPERSAMPLE))
    return frame


#: The representation names that mean the mesh IS the fluid rather than the material around it. Spelled here
#: rather than in each caller because the stops rule reads `solid` the wrong way round if the two callers ever
#: disagree, and until the view became a default there were two spellings of it: the bench's own tuple and
#: nothing at all on the agent path, which never passed the argument.
FLUID_REPRESENTATIONS = ("fluid_domain", "annular_fluid")


def solid_from_representation(representation: str | None) -> bool:
    """Whether the mesh is the material, from the representation name the caller measured.

    The caller decides WHICH representation to ask about and that is not a detail: the bench uses the one
    measured with no brief and no declared ports, because on the bench a brief is the answer key. A real run
    has a brief and is entitled to it, so `tools` passes `catalog.representation`'s answer. Both then spell
    the fluid test the same way, which is what this function is for."""
    return str(representation or "") not in FLUID_REPRESENTATIONS


def mouths_from_openings(openings) -> list[Mouth]:
    """The facts' openings as the detector wants them. Kept here so both call sites spell it the same way."""
    return [Mouth(id=str(o.id), kind=str(o.kind), classification=str(o.classification),
                  centroid=tuple(float(x) for x in o.centroid),
                  normal=tuple(float(x) for x in o.normal),
                  hydraulic_diameter=float(o.hydraulic_diameter or 0.0),
                  area=float(o.area or 0.0)) for o in openings]
