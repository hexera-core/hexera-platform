"""What the vision model is asked, and how its answer is made safe to hand to the analyst: parsed into a
fixed-vocabulary record and scrubbed of every number, because nothing seen in a picture is a measurement."""
from __future__ import annotations

import json
import os
import re
from typing import Any

#: WHAT THE READER IS SENT, and there is one of it.
#:
#: This text was thirty-two prompts until 2026-09-23: a baseline `v1` and thirty-one named transforms of it, so
#: that an A/B was one edit that could be read in a line of code, plus the machinery that chose between them
#: from the environment and six guards that refused a prompt describing a picture the renderer was not drawing.
#: Every one of those experiments is decided. What is left is the winner, written out, and the guards are gone
#: with the settings they guarded: there is one picture now and one prompt for it, so the two cannot disagree.
#: The tag `surveyor-v1-precleanup` holds all thirty-two and the transforms that built them.
#:
#: WHAT THIS ONE IS, in the names the benchmark records use. It is `swept_two`, which is `v1` with the stops
#: view explained and asked about, the strip's violet letters explained and asked about, the six un-packed
#: panels explained, and `orientation` and `symmetry` taken out. The last of those is a measurement: four luna
#: draws against six of the prompt that kept them (`eval/vision/results/z_look/reports/two_prompt.md`,
#: `docs/look_hardening.md`) put false statements in the stored document at 496 to 532 against 541 to 582, ports
#: guessed on non-ports at 5 to 11 against 15 to 23 and the catch-all identity at 79 to 83 against 84 to 93, all
#: clean sweeps at p = 0.0095, for 11 per cent fewer output tokens, with the named failure and the held-out rows
#: inside the control band. `orientation` and `symmetry` are the two fields `trust.py` records and no builder
#: ever receives, so nothing downstream lost a reader. Dropping `sharp_edges` as well was measured and killed:
#: it takes the sharp-rim place from recall 0.99 to 0.07 or less and nothing else supplies one.
#:
#: DO NOT EDIT THIS TEXT to change what the reader is asked. Every number in `docs/vision.md` is against a prompt
#: sha, and an edit here makes every one of them a number about something else. `floor.SWEPT_TWO_PASSES` is the
#: band this one has to stay inside.
SYSTEM = """You are looking at rendered views of one CAD part, made for a CFD meshing pipeline. Each image is one view and its title names it: +x means seen from the +X side, -z from below, iso an oblique view, and section a cutaway with the half nearest you removed so the inside shows. The coloured arrows in the corner are the part's own axes: red is +X, green is +Y, blue is +Z; a filled dot means that axis points toward you, a ring means it points away. Yellow labels (o1, o2, ...) mark the openings the measuring code found, each at its centre; a grey label is an opening behind the surface in that view. One view is titled stops: its panels are cuts taken lengthwise along the part, each centred on one end of a passage, with the passage running in from the left of the panel; a panel says where to look and nothing about what is there. On the strip of cuts, violet letters (A, B, ...) mark places inside the cuts, in order along the flow; a letter says where to look and nothing about what is there. The views named panel1, panel2 and so on are those same cuts again, one to an image and several times larger; each one's title says which of the strip's cuts it is, and it carries the same letters at the same places. They are all drawn at the same scale as each other and as the strip, so a shape that shrinks from one to the next is a passage that narrows. The shading is plain and there is no scale.

The part has already been measured. Every size, area, angle and count is known to the engineer reading you and is not what you are for. You are for what a measurement cannot say: what the thing is, what its surfaces and openings look like, and what is inside it.

Answer as one JSON object and nothing else, with exactly these fields:
- looks_like: a short noun phrase for what the object is, in the words a CFD engineer uses (a branched distribution manifold, a pipe elbow, a shell-and-tube exchanger, a wing with a flap, a car body, a bracket, a sheet-metal duct).
- confidence: one of low, medium, high. high only if you would name it to an engineer without hedging and every view agrees; medium if you would name it with a hedge; low if you are guessing or the views show a surface you cannot resolve.
- openings_seen: a list with one entry per labelled opening you can see, plus any opening you see without a label, each an object {"id": "o3" or "unlabelled", "looks_like": one of open end / flange face / hole / cap / lip / unsure (an end ringed by a raised flat collar is a flange face), "mouth": one of protruding / flush / recessed / unsure (does it stand out on a stub or a nozzle, sit flat in the wall around it, or sit down in a pocket), "likely_role": one of inlet / outlet / not a port / unsure, "why": a few words}. Leave likely_role unsure unless the shape makes it plain; two mouths of the same shape do not tell you which is which.
- internal_features: a list of short phrases for what the cutaway shows inside and the outside hides: a baffle, a vane, a tube bundle, a core or plug in the passage, a step or sudden widening, a blind pocket, a wall between two passages; empty when the inside is plain or nothing is visible. The cut is left open, so in that view you are seeing the far half from the inside.
- sharp_edges: a list of short phrases for knife edges and lips, each saying where: a trailing edge, a throat lip, a sharp mouth rim, a sharp corner where the surface turns abruptly; empty when every edge looks rounded or chamfered.
- attachments: a list of short phrases for flanges, bosses, brackets, stems, lugs, mounting features; empty when none.
- thin_parts: a list of short phrases for plates, fins, vanes, sheet walls, thin shells, and any wall the cutaway shows getting thinner along its length; empty when none.
- defects: a list of short phrases for anything in the file that does not belong to the part the flow sees: stray bodies, duplicate or overlapping shells, plates that meet without joining, floating fragments, sketch lines, obviously missing faces, a fixture or stand or bolt that is not part of the flow; empty when none.
- marks_seen: one entry per violet letter on the strip of cuts, in the order they are lettered, each a string that begins with the letter and a colon: what is at that exact place and nothing else, in a few words (an open bore; a ring of material around a hole; a body standing in the passage with a gap around it; a thin wall across the passage; a cluster of small bores; solid material; a second passage beside the main one). Answer every letter and no others, and answer for the place the ring is drawn on, not for the part as a whole. Where the mark is too small or too faint to read, write the letter and "cannot tell from these views": that is an expected answer on some of them and it is worth more than a guess.
- stops_seen: one entry per panel on the stops view, in the order they are captioned (end 1, end 2, ...), each a string that begins with the caption and a colon: what happens to the passage at that place and nothing else, in a few words (it opens out into a wider space; it runs into a wall of material and goes no further; it narrows and carries on; it splits; it reaches the edge of the model and leaves). Answer every panel and no others, and answer for that panel, not for the part as a whole. Where the panel is too small or too faint to read, write the caption and "cannot tell from these views": that is an expected answer on some of them and it is worth more than a guess.
- notes: anything else an engineer about to mesh this part should know from looking at it.

Rules: never state a dimension, size, ratio or angle, not even a rough one; count in words (one, two, several, many), never in digits; say "unsure" freely and leave a list empty rather than filling it; describe only what is visible in these images; an opening's role is a guess from its shape and placement, never a certainty; do not invent features the images do not show."""

#: The name this prompt has carried in every benchmark record since 2026-09-18, kept so a record taken then and
#: a record taken now join on it. It is a NAME and no longer a choice: nothing reads an environment variable to
#: get here.
VARIANT = "swept_two"
#: What `_no_stops` makes of it, which is the same text this project shipped before the stops view existed. It
#: is the one other prompt this module can produce and it is reachable only through `GEOMETRY_AGENT_VISION_GHOST_FIELDS=off`.
WITHHELD_VARIANT = "panels_swept_two"


def field_line(text: str, name: str) -> str:
    """The one line of a prompt that asks for `name`. Every field is a single line."""
    for line in text.split("\n"):
        if line.startswith(f"- {name}:"):
            return line
    raise KeyError(f"no field {name!r} in this prompt")


def drop_fields(text: str, *names: str) -> str:
    """The prompt without those fields."""
    for n in names:
        field_line(text, n)
    drop = tuple(f"- {n}:" for n in names)
    return "\n".join(ln for ln in text.split("\n") if not ln.startswith(drop))


#: The sentence in `SYSTEM` that explains the stops view, and the field that asks about its panels. Spelled out
#: here because `_no_stops` takes both out together: a prompt carrying one half would describe a picture that is
#: not being sent, or ask for a field whose explanation has gone.
_STOPS_SENTENCE = (" One view is titled stops: its panels are cuts taken lengthwise along the part, each "
                   "centred on one end of a passage, with the passage running in from the left of the panel; "
                   "a panel says where to look and nothing about what is there.")


def describes_stops(text: str) -> bool:
    """Whether this prompt tells the model what the stops view is."""
    return _STOPS_SENTENCE.strip() in text


def asks_per_stop(text: str) -> bool:
    """Whether this prompt asks for one answer per panel of the stops view."""
    return "- stops_seen:" in text


def asks_per_mark(text: str) -> bool:
    """Whether this prompt asks for an answer at each violet letter."""
    return "- marks_seen:" in text


def marks_for_prompt(marks: list[str] | None, system: str | None = None) -> list[str]:
    """The letters the user message is allowed to name, which is none unless the prompt asks about them."""
    return list(marks or []) if asks_per_mark(system if system is not None else SYSTEM) else []


def variant_of(text: str) -> str:
    """Which prompt this is, read off the text rather than off a setting. Two are reachable and everything else
    is `custom`, which is what a caller that built its own text gets."""
    if text == SYSTEM:
        return VARIANT
    return WITHHELD_VARIANT if text == _no_stops(SYSTEM) else "custom"


IMPRESSION_FIELDS = ("looks_like", "confidence", "orientation", "openings_seen", "internal_features",
                     "could_not_check", "sharp_edges", "attachments", "thin_parts", "defects",
                     "cannot_tell", "marks_seen", "stops_seen", "walk", "symmetry", "notes")
OPENING_FIELDS = ("id", "looks_like", "mouth", "likely_role", "why")
CONFIDENCES = ("low", "medium", "high")
ROLES = ("inlet", "outlet", "not a port", "unsure")
OPENING_LOOKS = ("open end", "flange face", "hole", "cap", "lip", "unsure")
#: There is no `build` field, and the omission is a measurement. It was asked for (solid / hollow shell / open
#: surface / several bodies), because what a mesher does with a part turns on it, and over 18 looks at seven
#: parts of four representations the answer came back "hollow shell" 18 times: on two wall shells, where it is
#: right, and on two models of a fluid volume and two external solids, where it is not. The cut is left open on
#: purpose, so the camera always sees the inside of the far skin, and a solid cut that way looks like a shell to
#: anything reading the shading. A field with one answer is not evidence. What would bring it back is a capped
#: section, where a solid is a filled face and a shell is a band: until then the representation is measured
#: (catalog.representation) and the picture is told rather than asked (MODEL_KIND, below).

#: How a mouth sits in the surface around it: a protruding mouth takes a port extension straight out, a flush one
#: cannot be extended without cutting the wall it sits in, and a recessed one means the port patch is down a pocket.
MOUTHS = ("protruding", "flush", "recessed", "unsure")
#: The lists whose entries are phrases; empty is a real answer and is kept as one. `cannot_tell` is one of
#: them and is in the record whatever the prompt asked for, empty on every variant that does not ask, so
#: one consumer reads one record shape.
#: `marks_seen` is one of them, and it is a list of plain strings rather than a list of objects on purpose: it
#: is then scrubbed, blocked and read for meaning by the code that already handles every other phrase field,
#: and a denial written into it is a denial the existing detectors can see. A field shaped differently from
#: every other would have moved the sentence "the passage is plain" somewhere nothing was reading.
#: `could_not_check` is one of them for the same reason and with one more: it is the field the door arms
#: exist to add, and the round-one failure was a winning arm moving its answers into a field no detector read.
#: A phrase list is read by `internals.denies`, by `denial.denials` where it is asked for, and by
#: `stance.texts` whatever it is called, so a denial written into it cannot hide there.
#: `stops_seen` is one of them by the same argument: one plain string per panel, so a sentence written into it
#: is scrubbed, blocked and read for meaning by everything that already reads a phrase. It is empty on every
#: variant that does not ask for it, so one consumer still reads one record shape.
#: `walk` is one of them by the same argument again, and with the one that matters most here: the third thing
#: each entry carries is what is at that cut, in the reply's own words, so a denial written at a named cut is
#: read by `stance.texts` exactly as a denial written anywhere else. A traversal whose answers no detector
#: could see would be round one's losing move in a new costume.
PHRASE_FIELDS = ("internal_features", "could_not_check", "sharp_edges", "attachments", "thin_parts",
                 "defects", "cannot_tell", "marks_seen", "stops_seen", "walk")
NUMBER_MARK = "[n]"

#: A numeric token: digits with optional sign, decimal or thousands separators and exponent, not preceded by a
#: letter (so opening ids o12, and risk or question ids, survive) and not part of a longer identifier.
_NUMBER = re.compile(r"(?<![A-Za-z0-9_])[-+]?\d+(?:[.,]\d+)*(?:[eE][-+]?\d+)?(?![A-Za-z0-9_]*[A-Za-z]\d)")
_ID = re.compile(r"^[oOqQkKrR]\d+$")


#: What the run has already measured about the kind of model this is, said to the model before it looks.
#:
#: This is not a reading of the picture and it is not a number: `catalog.representation` decides it from the
#: outer bodies' openings and the purpose, and the analyst is told the same thing in the measurements. Saying it
#: here costs about forty-five tokens and it is the single largest correction measured on this prompt. Without
#: it the model reads every part as internal flow, because that is what the prompt's own vocabulary is made of
#: (labelled openings, likely_role inlet or outlet), and on an external body it invents ports that do not exist.
#:
#: Measured 2026-09-14, eight parts, the same nine images and the same system prompt, the file name neutralised:
#: on the four external cases the description went from "a rectangular duct with rounded ends and side ports"
#: (the Ahmed body), "a tapered duct with two ends" (a wing) and "a branched distribution manifold" (a
#: three-bladed rotor) to "a blunt-nosed aerodynamic body with a flat base", "a streamlined external-flow body"
#: and "a three-bladed propeller or fan with a central hub and radial arms". Those four parts carry eighteen
#: measured openings between them; twelve had been given a flow role by guess, and with the line not one of the
#: eighteen was, which is right, because an external body has no ports. On the two fluid-domain cases and the
#: one wall shell retested it changed neither the identity nor a role, so the gain measured here is the external
#: one and nothing is claimed beyond it.
MODEL_KIND = {
    "external": ("This model is a SOLID BODY in an external-flow case: the air goes AROUND its outside and never "
                 "through it. It has no inlet and no outlet. The labelled marks are features of its surface (a "
                 "blunt base, a cut end, a hole, a joint), not ports, so answer 'not a port' unless a mark is "
                 "plainly a duct mouth."),
    "fluid_domain": ("This model IS THE FLUID VOLUME, not the hardware: its outer surface is the wet wall and its "
                     "flat end faces are the ports. You are looking at the shape of the air or water, so a "
                     "solid-looking lump is a passage and a dent in it is a body the flow goes around."),
    "annular_fluid": ("This model IS THE FLUID VOLUME of an annular passage: the flow runs in the gap between an "
                      "outer wall and an inner body, and the end rings are the ports."),
    "wall_shell": ("This model is the HARDWARE, and the flow goes through the cavity inside it. The labelled "
                   "marks are the mouths of that cavity where it reaches the outer surface."),
}


def user_prompt(views: list[str], labelled: list[str], question: str | None = None, focus_opening_id: str | None = None,
                file_name: str | None = None, representation: str | None = None,
                marks: list[str] | None = None) -> str:
    parts = []
    kind = MODEL_KIND.get(str(representation or ""))
    if kind:
        # first, so it is read before the view list and before the word "openings" sets the frame
        parts.append(kind)
    parts.append(f"{len(views)} views of {file_name or 'the part'}, in this order: {', '.join(views)}.")
    parts.append("Labelled openings: " + (", ".join(labelled) if labelled else "none") + ".")
    # the letters, named the same way the openings are, and only when the prompt asks about them: a caller
    # passes what the renderer drew and `marks_for_prompt` decides whether the message may name it
    if marks:
        parts.append("Lettered marks: " + ", ".join(marks) + ". Say what is at each one.")
    if focus_opening_id:
        parts.append(f"Pay particular attention to opening {focus_opening_id}: say what it looks like and what it seems to be for.")
    if question:
        parts.append(f"The analyst asks: {question.strip()} Answer inside notes, in words.")
    parts.append("Reply with the JSON object only.")
    return "\n".join(parts)


def _keep(match: re.Match, text: str) -> bool:
    """Numeric tokens that are words in disguise: 2D and 3D."""
    tok = match.group(0)
    after = text[match.end():match.end() + 1]
    return tok in ("2", "3") and after in ("d", "D") and not text[match.end() + 1:match.end() + 2].isalpha()


def scrub_numbers(text: str) -> str:
    """Every numeric token replaced with [n]; opening ids (o3), other ids and the axis names stay."""
    if not text:
        return text
    return _NUMBER.sub(lambda m: m.group(0) if _keep(m, text) else NUMBER_MARK, text)


def numbers_in(text: str) -> set[float]:
    """The numeric tokens a reply carried before scrubbing, as floats, so the checker can name any of them
    that turns up in a plan as having come from the picture."""
    out: set[float] = set()
    for m in _NUMBER.finditer(text or ""):
        if _keep(m, text):
            continue
        try:
            out.add(float(m.group(0).replace(",", "")))
        except ValueError:
            continue
    return out


def scrub(obj: Any) -> Any:
    """The scrub applied through a parsed reply: strings are scrubbed, bare numbers become [n], structure kept."""
    if isinstance(obj, bool) or obj is None:
        return obj
    if isinstance(obj, (int, float)):
        return NUMBER_MARK
    if isinstance(obj, str):
        return scrub_numbers(obj)
    if isinstance(obj, dict):
        return {str(k): scrub(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [scrub(v) for v in obj]
    return scrub_numbers(str(obj))


def json_object(text: str) -> dict | None:
    """The JSON object in a reply, through code fences and surrounding prose, or None when there is none."""
    body = (text or "").strip()
    fence = re.search(r"```(?:json)?\s*(.*?)```", body, re.S)
    if fence:
        body = fence.group(1).strip()
    start = body.find("{")
    if start >= 0:
        try:
            obj, _ = json.JSONDecoder().raw_decode(body[start:])
            if isinstance(obj, dict):
                return obj
        except ValueError:
            end = body.rfind("}")
            if end > start:
                try:
                    obj = json.loads(body[start:end + 1])
                    if isinstance(obj, dict):
                        return obj
                except ValueError:
                    pass
    return None


def parse_reply(text: str) -> dict:
    """The JSON object in a reply, through code fences and surrounding prose; when there is none, the whole
    reply, scrubbed, becomes the notes."""
    obj = json_object(text)
    return obj if obj is not None else {"notes": scrub_numbers(text or "")}


def _phrases(v: Any) -> list[str]:
    if v is None or v == "":
        return []
    if isinstance(v, str):
        return [v.strip()] if v.strip() and v.strip().lower() not in ("none", "n/a") else []
    if isinstance(v, dict):
        return [", ".join(f"{k}: {x}" for k, x in v.items())]
    if isinstance(v, (list, tuple)):
        out: list[str] = []
        for x in v:
            out += _phrases(x)
        return out
    return [str(v)]


def _text(v: Any, default: str = "unsure") -> str:
    if v is None or v == "" or v == []:
        return default
    if isinstance(v, str):
        return v.strip() or default
    if isinstance(v, (list, tuple)):
        return "; ".join(_phrases(v)) or default
    if isinstance(v, dict):
        return "; ".join(f"{k}: {x}" for k, x in v.items()) or default
    return str(v)


def _choice(v: Any, allowed: tuple[str, ...], default: str) -> str:
    s = _text(v, default).lower()
    for a in allowed:
        if a in s:
            return a
    return default


def _opening(v: Any) -> dict:
    if not isinstance(v, dict):
        return {"id": "unlabelled", "looks_like": "unsure", "mouth": "unsure", "likely_role": "unsure",
                "why": _text(v, "")}
    oid = _text(v.get("id") or v.get("opening") or v.get("label"), "unlabelled")
    return {"id": oid if _ID.match(oid) else "unlabelled",
            "looks_like": _choice(v.get("looks_like") or v.get("what"), OPENING_LOOKS, "unsure"),
            "mouth": _choice(v.get("mouth") or v.get("sits"), MOUTHS, "unsure"),
            "likely_role": _choice(v.get("likely_role") or v.get("role"), ROLES, "unsure"),
            "why": _text(v.get("why") or v.get("reason"), "")}


def normalise_impression(obj: dict) -> dict:
    """The reply forced into the fixed record: every field present, choices from the fixed vocabularies, lists
    of phrases where lists are expected. Unknown fields are dropped."""
    src = obj if isinstance(obj, dict) else {}
    openings = src.get("openings_seen") or src.get("openings") or []
    if isinstance(openings, dict):
        openings = [{"id": k, **(v if isinstance(v, dict) else {"why": v})} for k, v in openings.items()]
    out = {
        "looks_like": _text(src.get("looks_like") or src.get("object")),
        "confidence": _choice(src.get("confidence"), CONFIDENCES, "low"),
        "orientation": _text(src.get("orientation")),
        "openings_seen": [_opening(o) for o in (openings if isinstance(openings, list) else [openings])],
    }
    for f in PHRASE_FIELDS:
        out[f] = _phrases(src.get(f))
    out["symmetry"] = _text(src.get("symmetry"))
    out["notes"] = _text(src.get("notes"), "")
    return out


def impression_from_reply(text: str) -> tuple[dict, set[float]]:
    """A reply turned into the scrubbed, normalised impression plus the numbers it carried before the scrub."""
    return scrub(normalise_impression(parse_reply(text))), numbers_in(text)


# ---------------------------------------------------------------------------------------------------------------
# WHAT A PROMPT ASKED, AND WHETHER A REPLY ANSWERED IT.
#
# The record is fixed-shape on purpose (`normalise_impression`): a consumer reads one shape whatever the prompt
# was, and a field nobody asked for comes back at its empty value. That is safe only while a reader can tell an
# empty value that was ANSWERED from one that was never asked for or never written, and there is one field where
# the difference is the whole product: an empty `internal_features` is relied on to mean the passage is plain
# (`trust.PLAIN_INSIDE_WHY`). A reply that is not a JSON object normalises to exactly that, and so does a reply
# that forgot the field. Both used to come back as a look.
#
# Measured before the rule was written, off the cached replies: of 2,898 real replies (luna and astra, nine
# full draws, seventeen views) none was anything but a JSON object, and none omitted a field its prompt asked
# for. So refusing either costs nothing on the corpus and turns two silent lies into two loud failures.
# ---------------------------------------------------------------------------------------------------------------
#: Keys `normalise_impression` accepts in place of a field's own name, so a reply that used one has answered.
FIELD_ALIASES = {"looks_like": ("looks_like", "object"), "openings_seen": ("openings_seen", "openings")}
NOT_AN_OBJECT = "the reply was not the JSON object the prompt asks for"
MISSING_FIELDS = "the reply left out {fields}, which the prompt asks for; an absent field would read as an empty one"


def asked_fields(system: str | None = None) -> tuple[str, ...]:
    """The record's fields this system prompt asks for, in record order. Every field is a line of its own that
    begins "- name:", which is what `field_line` already relies on."""
    text = system if system is not None else SYSTEM
    return tuple(f for f in IMPRESSION_FIELDS if f"- {f}:" in text)


def not_asked(system: str | None = None) -> tuple[str, ...]:
    """The record's fields this prompt never asks for. Each one is in every record at its empty value, and a
    reader must not take that value as the look's answer."""
    asked = set(asked_fields(system))
    return tuple(f for f in IMPRESSION_FIELDS if f not in asked)


def reply_problem(text: str, system: str | None = None) -> str | None:
    """Why this reply must not be read as a look, or None when it may be. Two reasons, both about silence
    arriving wearing a finding: no JSON object at all, or an object missing a field the prompt asked for."""
    obj = json_object(text)
    if obj is None:
        return NOT_AN_OBJECT
    missing = [f for f in asked_fields(system) if not any(k in obj for k in FIELD_ALIASES.get(f, (f,)))]
    if missing:
        return MISSING_FIELDS.format(fields=", ".join(missing))
    return None


# ---------------------------------------------------------------------------------------------------------------
# The block that rides in the opening message. The look runs as the run starts and its impression travels with the
# measurements, clearly labelled and clearly separated, the way the platform's mesh reviewer hands back what it saw
# of a finished mesh. The analyst never spends a round asking for it, and never has to know it should have asked.
# ---------------------------------------------------------------------------------------------------------------
BLOCK_HEADER = "WHAT THE PART LOOKS LIKE ({n} rendered views read by a vision model; words only, every digit removed):"
#: The header when the look was attempted and did not work. The analyst is told, in one line, so it does not spend
#: a round calling look_at_views to find out for itself.
FAILED_BLOCK = "WHAT THE PART LOOKS LIKE: the look at the rendered views failed ({reason}). Decide from the measurements."
#: The rule that rides under the block. It is not a section of the system prompt: the prompt is what every run
#: reads, and a run without a vision model has no impression to govern. `loop.opening_messages` appends it under
#: the block, exactly as it appends MEMORY_RULE under a memory block, so `prompt_sha256` does not move.
VISION_RULE = ("That is a look at pictures, not a measurement. Every number it carried was removed before you saw it, "
               "and the checker refuses a plan number that only the picture had. It may inform object.type, an "
               "evidence string written as 'visual impression: ...', a role's confidence or a question's wording. It "
               "may not change a measured class (port_candidate, planar_face, hole, ring, interface), any measured "
               "number, or the unit. An identity whose only evidence is the picture stays at confidence "
               "{cap} or below. Call look_at_views only to settle something this description does not answer.")

_EMPTY = "none seen"


def _opening_line(o: dict) -> str:
    # a class the row does not carry prints nothing: `trust.model_safe` takes `looks_like` out of every opening,
    # and "unsure" printed in its place would be the look saying it could not tell, which it did not say
    bits = [str(o.get("id") or "unlabelled")] + ([str(o.get("looks_like") or "unsure")] if "looks_like" in o else [])
    mouth = o.get("mouth")
    if mouth and mouth != "unsure":
        bits.append(f"mouth {mouth}")
    role = o.get("likely_role")
    if role and role != "unsure":
        bits.append(f"likely {role}")
    why = (o.get("why") or "").strip()
    line = " ".join([bits[0], ", ".join(bits[1:])]) if len(bits) > 1 else bits[0]
    return f"{line} ({why})" if why else line


def impression_block(impression: dict, views: int = 9, model: str | None = None, provider: str | None = None,
                     system: str | None = None) -> str:
    """The impression as the opening message carries it: labelled lines, not JSON, because it is prose evidence
    sitting next to a JSON packet of measurements and the difference should be visible at a glance.

    A line is written only for a field `system` asked for (the run's prompt when None). The record carries
    every field whatever was asked, at its empty value when it was not, and "sharp edges: none seen" printed
    for a field nobody asked about is a statement that the look searched and found nothing, which it did not."""
    imp = impression or {}
    asked = set(asked_fields(system))
    head = BLOCK_HEADER.format(n=views)
    if model:
        # BLOCK_HEADER closes with "):", so the model goes in before both characters, not before one of them
        head = head[:-2] + f"; {model}" + (f" via {provider}" if provider else "") + "):"
    lines = [head,
             f"looks_like: {imp.get('looks_like') or 'unsure'} (confidence {imp.get('confidence') or 'low'})"]
    # A FIELD THE IMPRESSION DOES NOT CARRY PRINTS NOTHING. `trust.model_safe` takes the recorded fields OUT, and
    # "not part of the flow, or broken: none apparent" printed for an absent `defects` is a claim the look never
    # made. A normalised impression carries every field, so a full record prints exactly what it printed before
    if "orientation" in asked and "orientation" in imp:
        lines.append(f"orientation: {imp.get('orientation') or 'unsure'}")
    openings = imp.get("openings_seen") or []
    lines.append("openings: " + ("; ".join(_opening_line(o) for o in openings) if openings else _EMPTY))
    for field, label in (("internal_features", "inside (from the cutaway)"), ("sharp_edges", "sharp edges"),
                         ("attachments", "attachments"), ("thin_parts", "thin parts"),
                         ("defects", "not part of the flow, or broken")):
        if field not in asked or field not in imp:
            continue
        vals = imp.get(field) or []
        lines.append(f"{label}: " + ("; ".join(str(v) for v in vals) if vals else _EMPTY))
    if "symmetry" in asked and "symmetry" in imp:
        lines.append(f"symmetry: {imp.get('symmetry') or 'unsure'}")
    # last of the labelled lines and only when there is one: it is the look's own list of what these pictures
    # do not settle, and it is the one line here an analyst can turn straight into a question for the customer.
    # Empty on every prompt that does not ask for it, and an empty list is not printed, so the block a run that
    # never asked produces is the block it produced before the field existed.
    if imp.get("cannot_tell"):
        lines.append("cannot tell from these views: " + "; ".join(str(v) for v in imp["cannot_tell"]))
    # the third answer, and the same rule again: empty on every prompt that does not ask, and an empty list is
    # not printed, so the block a run that never asked produces is the block it produced before the field
    # existed. It sits under the inside line rather than with the doubts, because it is the other half of that
    # line: what the empty list above does NOT cover
    if imp.get("could_not_check"):
        lines.append("could not check from these views: " + "; ".join(str(v) for v in imp["could_not_check"]))
    # the same rule as `cannot_tell`: printed only when a mark was asked about, so a run that drew no letters
    # produces the block it produced before they existed
    if imp.get("marks_seen"):
        lines.append("at the marked places: " + "; ".join(str(v) for v in imp["marks_seen"]))
    # and the same rule again for the panels of the stops view
    if imp.get("stops_seen"):
        lines.append("where each passage ends: " + "; ".join(str(v) for v in imp["stops_seen"]))
    notes = (imp.get("notes") or "").strip()
    if notes:
        lines.append(f"notes: {notes}")
    return "\n".join(lines)


def failed_block(reason: str) -> str:
    return FAILED_BLOCK.format(reason=(reason or "no reason given").strip())


# ---------------------------------------------------------------------------------------------------------------
# THE CRITIC: the same pictures with the task taken away. A PROTOTYPE, OFF BY DEFAULT.
#
# The literature's strongest single result for this project's failure (docs/research_exhaustive.md E1, the
# Inattentional Gap, arXiv 2606.26529, read at abstract level): conditioning a model on a narrow task
# suppresses its reporting of plainly visible things, by up to 0.92 across seven models, and in a 24-scenario
# probe an independent open-ended reader with NO TASK restored every finding the task-conditioned one omitted.
# Every picture and prompt change this project has tried VARIED the task; none removed it.
#
# So this is not a field and not a variant. It is a second system prompt with no schema, no field list, no
# part shortlist and no question about any place: what the pictures are, and "say what you see". What it may
# not do is the one rule every look obeys, carry a number, and that rule is a scrub applied afterwards as well
# as a sentence here. Its words are kept apart from the impression (`look.look_at_geometry(critic=True)` puts
# them in `block["critic"]`), so nothing it says reaches a model or moves a tier until four draws say it should.
#
# What it must NOT become is the yes-machine: asking the model about each place directly was measured at 92 per
# cent yes on real cases and 88 per cent on empty ones. So the prompt names no place and no kind of feature.
# ---------------------------------------------------------------------------------------------------------------
CRITIC_SYSTEM = (
    "You are looking at rendered views of one object. Each image's title names the view. Describe everything "
    "you see in these images, outside and inside, in plain sentences. Never state a number, a size, a ratio or "
    "an angle; count in words.")


def critic_user_prompt(views: list[str]) -> str:
    """The message beside the pictures: which views they are, and nothing about the part."""
    return f"{len(views)} views, in this order: {', '.join(views)}."


def critic_from_reply(text: str) -> str:
    """The critic's words, scrubbed of every number. Free text on purpose: there is no record to fill."""
    return scrub_numbers((text or "").strip())


# ---------------------------------------------------------------------------------------------------------------
# GHOST FIELDS: a field is described only when THIS PART'S pictures can support it.
#
# THE BUG, measured before anything was built. `_stops` puts the stops sentence and the `stops_seen` field into
# the system prompt, which is one string for the whole run. `terminus.find_stops` draws a panel on 32 of the
# 322 export parts, and `terminus.stops_frame` returns a BLANK WHITE FRAME for the other 290: the view is still
# in the set, still titled, still captioned, and carries nothing at all. So on 290 parts the model is handed a
# sentence explaining a picture that is empty and a field demanding "one entry per panel on the stops view, in
# the order they are captioned".
#
# What that costs, counted off the cached replies in `eval/vision/results` and not guessed at:
#
#   reader          arm                 panels drawn   wrote stops_seen   of those, on a part with NO panel
#   gpt-6-astra     combo_sa x4         32             32 32 32 32        0 0 0 0
#   gpt-5.6-sol     combo_ss x4         32             32 32 32 32        0 0 0 0
#   gpt-5.6-luna    t2:stops_a          32             138               106
#   gpt-5.6-luna    t2:stops_full_b     32             140               108
#   gpt-5.6-luna    t_stops:looks       32              85                54
#
# On `t2:stops_a` that is 606 invented entries against 45 real ones, so 93 per cent of everything this field
# carries on luna is written about a blank picture. They are not nonsense and they are not an unsubstituted
# template: they are six identical sentences at a time ("end [n]: it runs into a wall of material and goes no
# further" six times over on a part with no panels), which is what a model writes when it has a slot, a caption
# format and nothing to read. `stops_seen` is a `PHRASE_FIELD`, so every one of those sentences is read by
# `stance.texts`, by `internals.denies` and by `holdout`, which is where the damage is.
#
# THE FIX IS THE SCHEMA AND NOT THE MODEL. The prompt asks for a field whose picture is not there. This takes
# the field out for the parts whose picture is not there, and takes the empty picture out with it, because
# `stops_mismatch` is right that describing a view and drawing it are one decision. A part that HAS panels is
# untouched, so 32 of 322 parts see byte-identical inputs and the arm can only move on the other 290.
#
# `_no_stops(system_for("panels_stops"))` is byte-identical to `system_for("panels")`, and the same for
# `marks_stops` -> `marks` and `stops` -> `v1`. That is the pin: a part with no panel is sent exactly the
# prompt this project shipped before the stops view existed, not a new third text.
#
# OFF BY DEFAULT. `GEOMETRY_AGENT_VISION_GHOST_FIELDS=off` switches the ghost fields off, which is what turns
# this arm on; the default `on` keeps the shipped behaviour of describing them regardless.
# ---------------------------------------------------------------------------------------------------------------
GHOST_ENV = "GEOMETRY_AGENT_VISION_GHOST_FIELDS"
#: "on" means a field is described whether or not this part's pictures can support it, which is what ships.
DEFAULT_GHOST_FIELDS = "on"


def ghost_fields_on(env=None) -> bool:
    """Whether a field may be described on a part whose pictures cannot support it. True is the shipped
    behaviour; `GEOMETRY_AGENT_VISION_GHOST_FIELDS=off` is the arm.

    `env.get(GHOST_ENV, DEFAULT_GHOST_FIELDS)` and not `or`, for the reason `stops_from_env` writes out at
    length: `or` reads the variable set to the empty string as absent, and a shell holding
    `GEOMETRY_AGENT_VISION_GHOST_FIELDS=` would then silently take the default."""
    env = env if env is not None else os.environ
    value = str(env.get(GHOST_ENV, DEFAULT_GHOST_FIELDS)).strip().lower()
    if value in ("on", "1", "true", "yes"):
        return True
    if value in ("off", "0", "false", "no", ""):
        return False
    raise ValueError(f"{GHOST_ENV} is {value!r}; it is 'on' or 'off'")


def _no_stops(text: str) -> str:
    """This prompt with both halves of the stops taken out: the sentence that explains the view and the field
    that asks about its panels.

    Checked rather than assumed, like every other edit in this file. A prompt left carrying one half would be
    describing a picture that is not being sent, or asking for a field whose explanation has gone."""
    if not describes_stops(text):
        return text
    out = drop_fields(text.replace(_STOPS_SENTENCE, "", 1), "stops_seen")
    if describes_stops(out) or asks_per_stop(out):
        raise AssertionError("the stops half did not come out of this prompt cleanly")
    return out


#: Every field this module can withhold, and the two things it takes to withhold one: the test that says
#: whether THIS part's pictures support it, and the edit that takes it out of the prompt.
#:
#: There is one entry and the audit is why. All thirteen field lines of the shipped prompt were counted against
#: what the renderer actually drew on each of the 322 export parts, off `t2:stops_a`'s own records:
#:
#:   marks_seen      6, 7 or 8 letters on every one of 322 parts. Never unsupported.
#:   openings_seen   0 labelled openings on 11 parts, and the field still asks for "any opening you see
#:                   without a label", so the picture supports it; the user message already says "none".
#:   stops_seen      0 panels on 290 of 322 parts.
#:   the other ten   read off views that are drawn on every part (the eight shaded, the cutaway, the strip).
#:
#: So exactly one of the thirteen is a ghost, and the table is here rather than in a commit message because
#: "audit them all" was the instruction and "one" is the answer.
WITHHOLD = {
    "stops_seen": (lambda part: not (part or {}).get("stopped"), _no_stops),
}


def withheld_for(part: dict | None, system: str | None = None, env=None) -> tuple[str, ...]:
    """Which fields this part's pictures cannot support, in the order `WITHHOLD` declares them.

    `part` is the render manifest, or anything else carrying the same keys; a caller with no manifest passes
    None and nothing is withheld, which is the shipped behaviour."""
    if ghost_fields_on(env) or part is None:
        return ()
    text = system if system is not None else SYSTEM
    out = []
    for name, (unsupported, edit) in WITHHOLD.items():
        if f"- {name}:" in text and unsupported(part):
            out.append(name)
            text = edit(text)
    return tuple(out)


def system_for_part(part: dict | None, system: str | None = None, env=None) -> str:
    """The system prompt for ONE part: the run's prompt with every field this part's pictures cannot support
    taken out, along with the sentence that explains the picture it would have read."""
    text = system if system is not None else SYSTEM
    for name in withheld_for(part, text, env):
        text = WITHHOLD[name][1](text)
    return text


#: `terminus.STOPS`, spelled again rather than imported: this module is strings and a parser, and `terminus`
#: brings numpy with it. `test_vision_ghost_fields.py` pins the two spellings together.
STOPS_VIEW = "stops"

#: Which view each withheld field was going to be read off, so a caller can drop the picture with the words.
#: A view named here is dropped ONLY when its field is withheld, so a part that keeps the field keeps the view.
FIELD_VIEW = {"stops_seen": STOPS_VIEW}


def views_for_part(views: list[str], part: dict | None, system: str | None = None, env=None) -> list[str]:
    """The views actually sent for this part. A picture whose field has been withheld goes with it: a view in
    the set that no sentence in the prompt explains is the mismatch `stops_mismatch` exists to refuse, and an
    empty panel drawn and sent is what this whole switch is about."""
    drop = {FIELD_VIEW[n] for n in withheld_for(part, system, env) if n in FIELD_VIEW}
    return [v for v in views if v not in drop]


def paths_for_part(paths: list, views: list[str], part: dict | None, system: str | None = None, env=None) -> list:
    """The rendered files for `views`, less the ones whose field has been withheld. The two lists are paired by
    position, which is the contract `render_views` already has with its caller."""
    keep = set(views_for_part(list(views), part, system, env))
    return [p for p, v in zip(paths, views) if v in keep]
