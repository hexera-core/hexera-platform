"""One entry point: a file and its measurements go in, a look comes back.

Until this module there was no such thing. The agent loop assembled render + client + prompt itself
(`loop.attach_look` over `tools.look_at_views`) and the eval bench assembled the same three a second time,
so a third caller, the platform, would have assembled them a third time and the three would have drifted.
`look_at_geometry` is that assembly, once, in the package that owns the pieces.

WHAT IT PROMISES, because a caller outside this package has no way to check any of it for itself.

  It never raises. Not for a missing key, not for a provider that is down, not for a reply that is not
  JSON, not for a file this machine cannot render, not for a bad argument, not for a bug in the block
  builder, not for anything a thread can throw. Every one of those comes back as a block whose `status` is
  `failed` and whose `reason` says why, because each of them is a look that was TAKEN and brought no reading
  back. The one state that is not `failed` is no reader configured at all: nothing looked and nothing could
  have, so that one is `not_attempted` (`NO_CLIENT`). The one thing it does not swallow is the
  caller's OWN KeyboardInterrupt arriving on the caller's thread while it waits: that is the caller's
  signal, not the look failing.

  It never reads a reply it should not. A reply cut off at the output ceiling (`client.VisionTruncated`,
  or `finish_reason` `length` from a client that did not raise), a reply withheld by the provider, a reply
  that is not a JSON object, and a reply that left out a field the prompt asked for are all refused with a
  reason. Each of those used to come back `ok`, and each normalises to an empty `internal_features`, which
  is the one value the builder is told to rely on as "the passage is plain".

  It describes the picture it actually drew. The prompt is chosen at CALL time from the same environment the
  renderer reads at call time, and a prompt and picture that disagree (the six guards the bench refuses on:
  section, marks, panels, door, stops, walk) are refused before a cent is spent. A caller-supplied view list
  that is not the set the prompt describes is refused for the same reason.

  It carries a wall-clock deadline and returns rather than blocks. The work runs on a daemon thread and
  the deadline is joined; a look still open at the deadline is abandoned and the block says so. The thread
  is not killed, because there is no safe way to kill one mid-render, but nothing waits on it and nothing
  reads what it eventually produces.

  It reuses the render cache. `render.render_views` is keyed by the file's content hash, so a second job
  on the same bytes pays for no triangle.

  Every digit is scrubbed. `prompt.impression_from_reply` does it, and it is the reason the look may ride
  next to a table of measurements without anyone having to check which numbers came from where.

  The file name is NOT shown to the model by default. The whole trust table in `trust.py` was measured
  with the name hidden, and the name is worth a large slice of the identity score on a corpus whose file
  names say what the part is. Showing it would make the tiers describe a run nobody made.

  It says which prompt it asked. `block["prompt"]` carries the variant, the system prompt's sha and
  `not_asked`: the record's fields this prompt never asks for. Each of those is in the impression at its
  empty value, and a reader must not take that value as the look's answer.

PORTED TO work/complete, 2026-09-17. This module was written on work/look-channel against a renderer that
drew nine views and nothing else. The renderer it runs against now draws the default set in
`render.default_views()` (seventeen: the lettered strip, the six un-packed panels and the stops view), and the
stops view cannot be drawn without the measured openings and the representation. So the assembly below is
the same assembly `agent.tools.look_at_views` makes on the agent's own path, step for step: the
representation is measured BEFORE the render because the stops detector needs it, the mouths come from the
measured openings, the per-part prompt edit and view list come from `prompt.system_for_part` and
`views_for_part` (identities at the shipped default), the letters are named only when the prompt asks about
them, and the renderer's own record of where it drew the letters and which openings got a stops panel rides
in the block as `drawn`, because `hexera.planner_block` cannot place a finding at a letter without it.
`tests/test_look_entry.py::test_the_platform_look_and_the_agent_look_are_assembled_the_same_way` pins the two
paths together, since three copies of one assembly drifting apart is the reason this module exists.

The one deliberate difference from the agent's path is the file name, above: the agent shows it and this
does not, and the trust tiers were measured with it hidden.
"""
from __future__ import annotations

import hashlib
import threading
import time
from pathlib import Path
from typing import Any

#: The three states a look can be in, from the module that owns the vocabulary.
#:
#: AT MODULE SCOPE HERE AND NOT IN `vision/trust.py`, and the difference is not taste. `contract/marks.py` reads
#: `trust.IDENTITY_CONFIDENCE_MAX` at module scope, so contract already imports `vision.trust` and an import of
#: contract at the top of THAT file fails on both orders. Nothing in contract imports this module, so this edge
#: closes no loop; both import orders are checked. `_block` still imports `hexera` inside the function for the
#: other reason, which is that `hexera` imports half of this package.
from geometry_agent.contract.survey import LOOK_NOT_ATTEMPTED
from geometry_agent.vision import client as vision_client
from geometry_agent.vision import prompt as vprompt
from geometry_agent.vision import render as vrender
from geometry_agent.vision import terminus as vterminus

#: The default wall clock for one look, render included. The provider adapter's own timeout is 180 s with
#: four retries, so without a deadline here a busy provider can hold a caller for minutes; a caller that
#: cares about its own budget passes its own.
DEFAULT_DEADLINE_S = 180.0

#: WHY THIS IS `not_attempted` AND NOT `failed`. Nothing looked at the part and nothing could have: there is no
#: reader in this environment. A look that was taken and brought no reading back is a different fact, and the
#: platform's own no-reader path (`application/geometry_vision.py`) has always said `not_attempted` here while
#: this said `failed`, so one deployment reported two things for one state. `agent.hexera.look_block` refuses a
#: status that is not one of the three, which is why this constant sits beside the status it goes out with.
NO_CLIENT = "no vision model is configured in this environment"
TIMED_OUT = "the look was still open after {seconds:.0f}s and was abandoned"
EMPTY_REPLY = "the vision model returned no description"
BAD_VIEWS = ("the views asked for are not the set this prompt describes ({detail}); a picture the prompt "
             "does not explain, or a sentence about a picture that is not sent, is refused rather than drawn")

#: The one line that travels with an impression wherever it goes.
CAVEAT = ("a vision model's words from rendered views. It is not a measurement and it carries no number: "
          "every digit was removed before any reader saw it.")

#: The label and the keys `hexera.look_block` writes, spelled here only for `_bare_block`, the block of last
#: resort when that function itself cannot be imported or raises. A test pins the two shapes together.
FALLBACK_LABEL = "VISUAL IMPRESSION (a vision model's words from nine rendered views; not a measurement)"


def look_at_geometry(path: str | Path, facts: Any = None, *, client: Any = None, provider: str = "auto",
                     deadline_s: float | None = DEFAULT_DEADLINE_S, purpose: str = "internal_cfd",
                     brief: str | None = None, declared: list[dict] | None = None,
                     representation: str | None = None, views: list[str] | None = None,
                     max_px: int = 768, render_dir: str | Path | None = None,
                     cache_root_dir: str | Path | None = None,
                     file_name: str | None = None, question: str | None = None,
                     critic: bool = False) -> dict[str, Any]:
    """Look at `path` and return the look block. Never raises.

    `facts` is the measurement of this same file (`facts.measure.measure`, or a `GeometryFacts` rebuilt
    from a stored document). It is not decoration: the openings it carries become the labels drawn on the
    views, so the ids the model names are the ids the measurement uses and a reader can join the two
    without guessing. It also settles the representation, which is the single largest correction measured
    on this prompt: without it every part reads as internal flow and an external body comes back with
    invented ports.

    `views` is for a caller that wants the default set in a different order; any other set is refused,
    because the prompt describes the default set and nothing else.

    `critic` asks the same pictures a second time with the task taken away (`prompt.CRITIC_SYSTEM`), and puts
    the scrubbed words in `block["critic"]`, apart from the impression, where nothing reads them. A PROTOTYPE,
    off unless a caller passes True.

    The return value is `hexera.look_block(...)`, so a caller hands it straight to
    `hexera.report_measured(look=...)` and has nothing left to assemble.
    """
    started = time.perf_counter()
    try:
        return _look(path, facts, client, provider, deadline_s, purpose, brief, declared, representation,
                     views, max_px, render_dir, cache_root_dir, file_name, question, critic, started)
    except Exception as exc:  # noqa: BLE001 - the last net: nothing a look does reaches a caller as an exception
        return _safe_block(None, status="failed", reason=f"the look could not run: {_why(exc)}",
                           seconds=_since(started))


def _since(started: float) -> float:
    return round(time.perf_counter() - started, 3)


def _look(path, facts, client, provider, deadline_s, purpose, brief, declared, representation, views,
          max_px, render_dir, cache_root_dir, file_name, question, critic, started) -> dict[str, Any]:
    try:
        chosen = client if client is not None else vision_client.vision_client_from_env(provider)
    except Exception as exc:  # noqa: BLE001 - a bad provider name is a look that did not happen
        return _safe_block(None, status="failed", reason=f"the vision client could not be built: "
                                                          f"{type(exc).__name__}: {str(exc)[:200]}",
                           seconds=_since(started))
    if chosen is None:
        return _safe_block(None, status=LOOK_NOT_ATTEMPTED, reason=NO_CLIENT, seconds=_since(started))

    args = (Path(path), facts, chosen, None if views is None else list(views), int(max_px), render_dir,
            cache_root_dir, purpose, brief, declared, representation, file_name, question, bool(critic))
    limit = float(deadline_s) if deadline_s else 0.0
    if limit <= 0:
        try:
            return _timed(_describe(*args), _since(started))
        except Exception as exc:  # noqa: BLE001 - nothing reaches a caller
            return _safe_block(None, status="failed", reason=_why(exc), seconds=_since(started))

    box: dict[str, Any] = {}

    def work() -> None:
        try:
            box["out"] = _describe(*args)
        except BaseException as exc:  # noqa: BLE001 - a look never ends a caller's job, whatever it throws
            box["exc"] = exc

    worker = threading.Thread(target=work, name="geometry-agent-look", daemon=True)
    worker.start()
    worker.join(limit)
    if worker.is_alive():
        # Not killed. There is no safe way to stop a thread inside a native render, so it is left to
        # finish into a cache nobody is waiting on, and this call is over.
        return _safe_block(None, status="failed", reason=TIMED_OUT.format(seconds=limit), seconds=_since(started))
    if "exc" in box:
        return _safe_block(None, status="failed", reason=_why(box["exc"]), seconds=_since(started))
    out = box.get("out")
    if not isinstance(out, dict):
        return _safe_block(None, status="failed", reason=EMPTY_REPLY, seconds=_since(started))
    return _timed(out, _since(started))


def _why(exc: BaseException) -> str:
    return f"{type(exc).__name__}: {str(exc)[:300]}"


def _timed(block: dict[str, Any], elapsed: float) -> dict[str, Any]:
    block["seconds"] = elapsed
    return block


def _bare_block(*, status: str, reason: str = "", views: list[str] | None = None,
                seconds: float | None = None) -> dict[str, Any]:
    """The block with no impression, built with nothing imported, for when `hexera.look_block` is the thing
    that failed. The same keys `look_block(None, ...)` writes."""
    out: dict[str, Any] = {"status": status, "label": FALLBACK_LABEL, "is_measurement": False, "impression": None,
                           "views": list(views or []), "model": "", "provider": "", "seconds": seconds,
                           "caveat": CAVEAT}
    if reason:
        out["reason"] = str(reason)
    return out


def _block(impression: dict | None, *, status: str, reason: str = "", model: str = "", provider: str = "",
           views: list[str] | None = None, seconds: float | None = None,
           usage: dict[str, Any] | None = None, drawn: dict[str, Any] | None = None) -> dict[str, Any]:
    """The block, through `hexera.look_block`, which is the one definition of its shape.

    Imported inside the function on purpose. `hexera` imports a good deal of this package and the platform
    imports `hexera`; a module-level import here would put a cycle between the two halves of the look for
    no gain, since this is called at most a handful of times per file.
    """
    from geometry_agent.agent.hexera import look_block

    return look_block(impression, status=status, reason=reason, model=model, provider=provider,
                      views=list(views or []), seconds=seconds, caveat=CAVEAT, usage=usage, drawn=drawn)


def _safe_block(impression: dict | None, **kw: Any) -> dict[str, Any]:
    """`_block`, and when even that raises, the bare block with the reason that made it raise appended. Only
    a block with no impression is ever built here, so nothing the model said can be lost by the fallback."""
    try:
        return _block(impression, **kw)
    except Exception as exc:  # noqa: BLE001 - the block builder failing is still a look that did not happen
        reason = "; ".join(r for r in (str(kw.get("reason") or ""), f"the block could not be built: {_why(exc)}")
                           if r)
        return _bare_block(status=str(kw.get("status") or "failed"), reason=reason, views=kw.get("views"),
                           seconds=kw.get("seconds"))


def _representation(facts: Any, purpose: str, brief: str | None, declared: list[dict] | None) -> str | None:
    """What kind of model this is, measured rather than seen. None when there is nothing to read it from."""
    if facts is None:
        return None
    try:
        from geometry_agent.agent import catalog

        return str(catalog.representation(facts, purpose, brief, declared=declared))  # type: ignore[arg-type]
    except Exception:  # noqa: BLE001 - the look is worth having without the one line of context
        return None


def _labels(facts: Any) -> list[tuple[str, tuple[float, float, float]]] | None:
    """The measured openings as render labels, so the model names the ids the measurement named."""
    openings = getattr(facts, "openings", None)
    if not openings:
        return None
    out: list[tuple[str, tuple[float, float, float]]] = []
    for o in openings:
        try:
            out.append((str(o.id), tuple(float(c) for c in o.centroid)))  # type: ignore[arg-type]
        except (AttributeError, TypeError, ValueError):
            continue
    return out or None


def _stops_inputs(facts: Any, representation: str | None) -> tuple[list, bool]:
    """What the stops view needs and a pile of triangles cannot know: which measured openings are mouths, and
    whether the mesh is the material or the fluid. Spelled with `terminus`'s own two helpers, which are the
    ones `agent.tools.look_at_views` uses, so the two paths draw the same panel.

    With no measurement there are no mouths, the detector finds no stop, and the view is the blank frame the
    shipped renderer draws on every part without one (290 of 322 in the export corpus). That is the shipped
    behaviour, not a new one."""
    mouths: list = []
    openings = getattr(facts, "openings", None) if facts is not None else None
    if openings:
        try:
            mouths = vterminus.mouths_from_openings(openings)
        except (AttributeError, TypeError, ValueError):
            mouths = []
    return mouths, vterminus.solid_from_representation(representation)


def _drawn(manifest: dict) -> dict[str, Any]:
    """The renderer's record of where it put the letters and which openings got a stops panel, read the way
    `agent.tools.look_at_views` reads it into `ToolContext.vision_drawn`. Taken off the manifest of the SAME
    render the look read, so a finding cannot be placed at a letter from a different picture."""
    return {"marks": list(manifest.get("mark_places") or []),
            "stops": list(manifest.get("stop_places") or manifest.get("stopped") or [])}


def _says_anything(impression: dict) -> bool:
    """A reply that normalised to nothing at all is a failed look, not a look that saw nothing.

    The difference matters downstream: an empty `internal_features` is a finding worth relying on (0 false
    obstructions on 103 plain-passage cases), and a truncated or refused reply normalises to the same empty
    list. One of those two is evidence and the other is silence, so silence is called what it is here.
    """
    if (impression.get("looks_like") or "unsure") != "unsure":
        return True
    if impression.get("openings_seen"):
        return True
    if (impression.get("notes") or "").strip():
        return True
    return any(impression.get(f) for f in vprompt.PHRASE_FIELDS)


def run_prompt() -> tuple[str | None, str]:
    """The system prompt for a look taken NOW, and the reason there is none.

    There is never a reason now, and the signature keeps the second value because the callers read it. This
    used to choose a prompt from the environment and then run six guards to refuse a picture and a prompt that
    disagreed, which was a real failure and not a hypothetical one: nothing in a reply says which pictures the
    model was shown, so a mismatched pass yields numbers that look ordinary and mean nothing. With one picture
    and one prompt there is nothing left for the two to disagree about, which is what deleting the render
    switches bought here.
    """
    return vprompt.SYSTEM, ""


def _view_problem(wanted: list[str] | None, default: list[str]) -> str | None:
    """Why a caller's view list cannot be sent with this prompt, or None when it can."""
    if wanted is None:
        return None
    extra = [v for v in wanted if v not in default]
    missing = [v for v in default if v not in wanted]
    if not extra and not missing and len(wanted) == len(default):
        return None
    bits = []
    if missing:
        bits.append("missing " + ", ".join(missing))
    if extra:
        bits.append("not described " + ", ".join(extra))
    if not bits:
        bits.append("a view is asked for twice")
    return BAD_VIEWS.format(detail="; ".join(bits))


def _sha(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


def _describe(path: Path, facts: Any, client: Any, views: list[str] | None, max_px: int,
              render_dir: str | Path | None, cache_root_dir: str | Path | None, purpose: str,
              brief: str | None, declared: list[dict] | None, representation: str | None,
              file_name: str | None, question: str | None, critic: bool = False) -> dict[str, Any]:
    """Render, ask, normalise. Runs on the worker thread; every failure is a block, never an exception.

    Step for step the assembly `agent.tools.look_at_views` makes, so what the platform stores is the look the
    agent would have taken of the same file with the same name hidden."""
    default = list(vrender.default_views())
    problem = _view_problem(views, default)
    if problem:
        return _safe_block(None, status="failed", reason=problem, views=views)
    views = list(views or default)
    run_system, mismatch = run_prompt()
    if run_system is None:
        return _safe_block(None, status="failed", reason=mismatch, views=views)
    labels = _labels(facts)
    # measured BEFORE the render and used twice, as on the agent's path: the stops detector needs it to read a
    # mouth the right way round, and the message needs it so an external body does not come back with ports
    rep = representation or _representation(facts, purpose, brief, declared)
    mouths, solid = _stops_inputs(facts, rep)
    try:
        paths = vrender.render_views(path, out_dir=render_dir, max_px=max_px, views=views, labels=labels,
                                     mouths=mouths, solid=solid, cache_root_dir=cache_root_dir)
    except Exception as exc:  # noqa: BLE001 - a file this machine cannot render is a look that did not happen
        return _safe_block(None, status="failed", reason=f"rendering failed: {_why(exc)}", views=views)
    try:
        manifest = vrender.read_manifest(vrender.cache_dir_for(path, cache_root_dir)) or {}
    except Exception:  # noqa: BLE001 - the manifest is how the labels are named, never how they are drawn
        manifest = {}
    labelled = manifest.get("labelled") or [oid for oid, _ in (labels or [])[:vrender.MAX_LABELS]]
    # the per-part prompt and view list (work/vf-fields). All three are identities at the shipped default,
    # and `paths_for_part` is handed the ORIGINAL view list because `render_views` returns one file per view
    # in the order it was asked for
    system = vprompt.system_for_part(manifest, system=run_system)
    paths = vprompt.paths_for_part(paths, views, manifest, system=run_system)
    views = vprompt.views_for_part(views, manifest, system=run_system)
    # the letters are named in the message only when THIS PART'S prompt asks about them
    marks = vprompt.marks_for_prompt(manifest.get("marked"), system)
    user = vprompt.user_prompt(views, list(labelled), question=question, file_name=file_name,
                               representation=rep, marks=marks)
    asked = {"variant": vprompt.variant_of(system), "system_sha256": _sha(system),
             "not_asked": list(vprompt.not_asked(system))}
    try:
        reply = client.describe(paths, user, system=system)
    except vision_client.VisionTruncated as exc:
        return _asked(_safe_block(None, status="failed", reason=str(exc), views=views), asked)
    except Exception as exc:  # noqa: BLE001 - a provider that is down is a look that did not happen
        return _asked(_safe_block(None, status="failed", reason=f"the vision model failed: {_why(exc)}",
                                  views=views), asked)
    model = str(getattr(reply, "model", "") or "")
    provider = str(getattr(reply, "provider", "") or "")
    usage = getattr(reply, "usage", None)
    usage = usage if isinstance(usage, dict) else None
    # the client's own refusal, applied again to whatever came back: a client someone else wrote need not
    # raise on a cut-off reply, and one that does not is held to the same rule here
    refused = vision_client.refusal(reply)
    text = getattr(reply, "text", "")
    if not refused and not isinstance(text, str):
        refused = f"the reply's text is a {type(text).__name__}, not a string"
    if not refused:
        refused = vprompt.reply_problem(text, system) if text.strip() else None
    if refused:
        return _asked(_safe_block(None, status="failed", reason=refused, views=views, model=model,
                                  provider=provider, usage=usage), asked)
    try:
        impression, _numbers = vprompt.impression_from_reply(text)
    except Exception as exc:  # noqa: BLE001 - a reply of the wrong shape is a look that did not work
        return _asked(_safe_block(None, status="failed", reason=f"the reply could not be read: {_why(exc)}",
                                  views=views, model=model, provider=provider, usage=usage), asked)
    if not _says_anything(impression):
        return _asked(_safe_block(None, status="failed", reason=EMPTY_REPLY, views=views, model=model,
                                  provider=provider, usage=usage), asked)
    block = _block(impression, status="ok", views=views, model=model, provider=provider, usage=usage,
                   drawn=_drawn(manifest))
    warning = manifest.get("warning")
    if warning:
        block["render_warning"] = str(warning)
    if critic:
        block["critic"] = _critic(client, paths, views)
    return _asked(block, asked)


def _critic(client: Any, paths: list, views: list[str]) -> dict[str, Any]:
    """The same pictures with the task taken away, held to the same refusals as the look. Only ever run after
    a look that worked, so a failed critic costs the block nothing but this key."""
    try:
        reply = client.describe(paths, vprompt.critic_user_prompt(views), system=vprompt.CRITIC_SYSTEM)
    except Exception as exc:  # noqa: BLE001 - the critic failing is recorded, never raised
        return {"status": "failed", "reason": _why(exc)}
    usage = getattr(reply, "usage", None)
    out: dict[str, Any] = {"model": str(getattr(reply, "model", "") or ""),
                           "provider": str(getattr(reply, "provider", "") or ""),
                           "usage": usage if isinstance(usage, dict) else {}}
    text = getattr(reply, "text", "")
    refused = vision_client.refusal(reply) or (None if isinstance(text, str) else "the reply is not text")
    if refused or not str(text).strip():
        return {"status": "failed", "reason": refused or EMPTY_REPLY, **out}
    return {"status": "ok", "text": vprompt.critic_from_reply(text), **out}


def _asked(block: dict[str, Any], asked: dict[str, Any]) -> dict[str, Any]:
    block["prompt"] = dict(asked)
    return block


__all__ = ["BAD_VIEWS", "CAVEAT", "DEFAULT_DEADLINE_S", "EMPTY_REPLY", "NO_CLIENT", "TIMED_OUT",
           "look_at_geometry", "run_prompt"]
