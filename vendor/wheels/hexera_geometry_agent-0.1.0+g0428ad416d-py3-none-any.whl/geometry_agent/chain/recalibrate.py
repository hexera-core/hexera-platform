"""WHAT THE LEDGER FEEDS: four recalibrations, each with the support it needs before it is justified.

Nothing here changes anything. Every function returns a PROPOSAL with its support, the support it needed, and
whether it got there. Shipping a threshold, editing a trust tier and changing a question list are all on
`docs/learning_loop.md` section 5's never-automated list and they stay there. What this module removes is the
part that was actually missing: knowing, from the record, that the case for a change exists.

THE FOUR, and what each one is allowed to move.

  TRUST DEMOTION        a `vision/trust.py` field the customer keeps contradicting drops a tier. One way.
  VOCABULARY WIDENING   a customer names a thing in words the accept list lacks, so the list gains a synonym.
                        It never loses one.
  QUESTION RETIREMENT   a question customers answer the same way more often than four in five, tested and
                        not eyeballed, becomes a stated assumption with a default rather than a question. It
                        is never deleted: a retired question keeps its topic and its record, so a later
                        contradiction can bring it back.
  THRESHOLD PROPOSAL    a monitor threshold. PROPOSED ONLY, and it goes through `docs/thresholds.md` and the
                        sweep's own gate like every other threshold in this package.

RATCHETING, WHICH IS WHAT MAKES THIS DIFFERENT FROM TRAINING. A tier that gets demoted stays demoted. A
synonym that gets added stays added. Neither regresses, nothing is fitted, no model is touched, and the whole
state is a few dozen lines of JSON a person can read. `apply_ratchet` refuses a proposal that would move
anything back.

WHERE THE SUPPORT NUMBERS COME FROM, and not one of them is a number I liked.

  0.07   the per-opening role disagreement between three runs of the same agent on the same case
         (docs/eval_protocol.md 5.1: per-opening role agreement 0.93). This is the rate at which this
         pipeline contradicts ITSELF on a role with nothing changed, so it is the null a contradiction has
         to beat.
  0.24   the rate at which the same three runs disagree about how many questions to ask (agreement 0.76).
         A term that arrives once may have arrived down a path another run would not have taken.
  0.80   not measured: the strictest null worth testing a retirement against. A question four customers in
         five answer the same way is still worth asking, so a retirement has to beat 0.8, not 0.5.
  15, 8  `eval/calib/sweep.py` MIN_SIDE and MIN_POSITIVE: the smallest labelled support this project has
         ever let a calibrated decision rest on. Anything that changes behaviour clears this too.
  0.222  eight byte-identical passes of one configuration span 94 to 104 on the old hold-out, so one draw
         against one control cannot reach significance at all. Nothing here is a single-draw comparison;
         every count below is over distinct parts and is deterministic given the ledger.

AND THE THING THAT WOULD MAKE ALL OF IT WORTHLESS: counting a default as an answer. Every collector in this
file reaches a value through `resolution.answer_of`, which raises on anything that is not an `Answered`.
`tests/test_chain_recalibrate.py::test_a_ledger_of_pure_defaults_proposes_nothing` pins it.
"""
from __future__ import annotations

import json
import re
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass, field
from math import comb
from pathlib import Path
from typing import Any

from geometry_agent.chain.resolution import Answered, Stated, answer_of, is_answer
from geometry_agent.chain.schema import JobRecord, topic_of

RECALIBRATE_SCHEMA = "geometry_agent.chain.recalibrate.v1"

# ---------------------------------------------------------------------------------------------------------------
# the measured nulls
# ---------------------------------------------------------------------------------------------------------------

#: docs/eval_protocol.md 5.1, panel 2026-09-09: roles, per opening (mean) 0.93 across three runs.
ROLE_SELF_DISAGREEMENT = 0.07
ROLE_SELF_DISAGREEMENT_FROM = ("docs/eval_protocol.md 5.1: three runs of the same agent on the same 30 cases "
                               "agree on 0.93 of openings, so 0.07 is this pipeline contradicting itself")

#: The same panel: question count identical 0.76 across three runs.
QUESTION_PATH_FLIP = 0.24
QUESTION_PATH_FLIP_FROM = ("docs/eval_protocol.md 5.1: three runs agree on the question count on 0.76 of "
                           "cases, so 0.24 of the time a question arrives down a path another run skips")

#: Not measured. The strictest null worth testing a retirement against, stated as a judgement and labelled one.
RETIREMENT_NULL = 0.80
RETIREMENT_NULL_FROM = ("a judgement, not a measurement: a question four customers in five answer the same "
                        "way is still worth asking, so a retirement must beat 0.8 and not 0.5")

#: eval/calib/sweep.py MIN_SIDE / MIN_POSITIVE.
MIN_PARTS = 15
MIN_POSITIVE = 8
MIN_PARTS_FROM = ("eval/calib/sweep.py MIN_SIDE=15 and MIN_POSITIVE=8: the smallest labelled support this "
                  "project lets any calibrated decision rest on")

#: Eight byte-identical passes span 94 to 104, so one draw against one control cannot reach p below this.
SINGLE_DRAW_P_FLOOR = 0.222

ALPHA = 0.05

#: SYNTHESIS C15, and the fix it measured. The ratchet is one way and the ledger GROWS, and it is read whenever
#: somebody runs `--apply`. Read after every job, a field that is fine (contradicted at exactly the 0.07 null) is
#: falsely demoted with probability 0.089 by 100 scored parts, 0.135 by 200 and 0.238 by 1,000, against 0.047,
#: 0.042 and 0.039 read once (`eval/synth/ratchet_peeking.py`, exact, no simulation), and a false demotion is
#: permanent. So the demotion gate is read only as the scored count crosses one of these seven pre-declared
#: looks, each at ALPHA / 7 (Bonferroni over the looks), which bounds the family-wise rate at ALPHA whatever the
#: habit of whoever runs `--apply`. The cost is power and the same file prints it: a field truly contradicted at
#: 0.25 is still demoted with probability 0.92 by 60 parts; one at 0.15 falls from 0.88 to 0.29 at 100 parts and
#: recovers to 0.66 by 200. The looks already spent live in the ratchet state (`looks`), so a look is never
#: re-spent by a second run over the same ledger.
DEMOTION_LOOKS: tuple[int, ...] = (15, 30, 60, 120, 240, 480, 960)
DEMOTION_ALPHA = ALPHA / len(DEMOTION_LOOKS)
DEMOTION_LOOKS_FROM = ("docs/synthesis.md C15 and eval/synth/ratchet_peeking.py: seven pre-declared looks at "
                       "alpha / 7, because a one-way ratchet read after every job is continuous monitoring with "
                       "the undo button removed")


def demotion_look(scored: int, last_look: int = 0) -> int | None:
    """The look this read spends: the largest pre-declared count at or under `scored` that is past `last_look`.

    None between looks, which is the common case and is not a failure: the evidence is kept and read at the next
    count. Past the last look the gate stays closed: seven reads were declared and seven were spent.
    """
    reached = [n for n in DEMOTION_LOOKS if int(last_look or 0) < n <= int(scored)]
    return max(reached) if reached else None


def _tail(k: int, n: int, q: float) -> float:
    """P(X >= k) under Binomial(n, q). Exact; n here is in the tens."""
    return sum(comb(n, i) * q ** i * (1.0 - q) ** (n - i) for i in range(k, n + 1))


def smallest_n(q: float, *, unanimous: bool = False, alpha: float = ALPHA, cap: int = 200) -> int:
    """The smallest n at which the decision rule can reach `alpha` against a null rate `q`.

    `unanimous=False` asks for a majority (k = ceil(n/2)), which is the shape of "repeatedly contradicted".
    `unanimous=True` asks for all n, which is the shape of "always answered the same way". Derived here
    rather than written down, so the floors move if the measured nulls do and nobody has to remember to
    change a constant.
    """
    for n in range(1, cap + 1):
        k = n if unanimous else (n + 1) // 2
        if _tail(k, n, q) <= alpha:
            return n
    return cap


#: Derived at import from the measured nulls above. Printed in every report.
N_CONTRADICTION = smallest_n(ROLE_SELF_DISAGREEMENT)
N_VOCABULARY = smallest_n(QUESTION_PATH_FLIP, unanimous=True)
N_RETIREMENT = smallest_n(RETIREMENT_NULL, unanimous=True)

#: The floor each rule actually applies: the statistical one AND, where the change moves behaviour, the
#: project's own MIN_PARTS. Widening an accept list moves no boundary and costs a synonym if it is wrong, so
#: it is the one rule that does not carry MIN_PARTS.
REQUIRED = {
    "trust_demotion": {"parts": max(N_CONTRADICTION, MIN_PARTS), "positives": MIN_POSITIVE},
    "vocabulary_widening": {"parts": N_VOCABULARY, "positives": N_VOCABULARY},
    "question_retirement": {"parts": max(N_RETIREMENT, MIN_PARTS), "positives": max(N_RETIREMENT, MIN_PARTS)},
    "threshold_proposal": {"parts": MIN_PARTS, "positives": MIN_POSITIVE},
}


# ---------------------------------------------------------------------------------------------------------------
# evidence and proposals
# ---------------------------------------------------------------------------------------------------------------

@dataclass(frozen=True, slots=True)
class Evidence:
    """One record's contribution to one rule. Always from an `Answered`, never from a default."""

    rule: str
    subject: str
    part_key: str
    job_key: str
    case: str = ""
    said: str = ""
    answered: str = ""
    agrees: bool | None = None


@dataclass(frozen=True, slots=True)
class Proposal:
    """A case for a change, with the support it has and the support it needed.

    `justified` is the only boolean here and it is never `applied`: applying is a person's job.
    """

    rule: str
    subject: str
    change: str
    support: int = 0
    distinct_parts: int = 0
    #: How many DIFFERENT families the support comes from. On a generated corpus this is the number that
    #: matters and it is usually tiny, because the parts are template twins. On customer files it is unknown
    #: and reported as 0 rather than guessed.
    distinct_families: int = 0
    positives: int = 0
    #: How many parts the rule could have fired on, which is not how many it did. A contradiction count with
    #: no denominator says nothing: see `_finish`.
    scored_parts: int = 0
    #: The one-sided binomial p of this support against the rule's measured null, where the rule has one.
    #: None for a rule whose floor is a count and not a rate.
    p_value: float | None = None
    required_parts: int = 0
    required_positives: int = 0
    #: The alpha this read was held to: ALPHA, or DEMOTION_ALPHA on a demotion read at a pre-declared look.
    alpha: float = ALPHA
    #: The pre-declared look a demotion read spent (`DEMOTION_LOOKS`), or None when it fell between looks.
    look_at: int | None = None
    justified: bool = False
    why_not: str = ""
    #: Filled when the support is real but narrow in a way a reader must see before acting on it. The one
    #: that fires on this project's own corpus: every supporting part is the same template.
    caveat: str = ""
    basis: tuple[str, ...] = ()
    evidence: tuple[Evidence, ...] = field(default_factory=tuple)

    def as_row(self) -> dict[str, Any]:
        row = asdict(self)
        row.pop("evidence", None)
        return row


def _answered(record: JobRecord) -> list[Answered]:
    """Every confirmation on a record, and nothing else. The one door into the learning path."""
    if record.intake is None:
        return []
    return [r for r in record.intake.resolutions if is_answer(r)]


def _stated(record: JobRecord) -> list[Stated]:
    return [r for r in (record.intake.resolutions if record.intake else []) if isinstance(r, Stated)]


def _finish(rule: str, subject: str, change: str, evidence: list[Evidence], positives: int,
            basis: tuple[str, ...], *, denominator: int | None = None,
            p_value: float | None = None, alpha: float = ALPHA, look_at: int | None = None,
            between_looks: str = "") -> Proposal:
    """Three conditions, and the third is the one a bare count cannot express.

    `denominator` is how many parts the rule could have fired on, which is NOT the same as how many it did.
    When it is given, `parts` is measured against it: a rule needs `MIN_PARTS` parts to have been SCORED, not
    `MIN_PARTS` parts to have agreed with it. When `p_value` is given it has to clear `ALPHA` as well, and
    that is the condition that stops 17 contradictions out of 1,000 reading like 17 out of 30.
    """
    need = REQUIRED[rule]
    parts = {e.part_key for e in evidence}
    #: The corpus family, which exists only because we generated the corpus. EMPTY ON A CUSTOMER FILE, so
    #: `distinct_families` is 0 there and every rule that would like to group by family cannot. Reported as 0
    #: rather than guessed.
    fams = {e.case.split("__", 1)[0] for e in evidence if e.case}
    scored = denominator if denominator is not None else len(parts)
    ok = scored >= need["parts"] and positives >= need["positives"] and not between_looks
    if ok and p_value is not None:
        ok = p_value <= alpha
    why = ""
    if not ok:
        bits = []
        if between_looks:
            bits.append(between_looks)
        if scored < need["parts"]:
            bits.append(f"{scored} distinct parts against {need['parts']} needed")
        if positives < need["positives"]:
            bits.append(f"{positives} against {need['positives']} needed")
        if p_value is not None and p_value > alpha and not between_looks:
            bits.append(f"p = {p_value:.3g} against {alpha:.3g} needed, so the rate is inside the noise")
        why = "; ".join(bits)
    caveat = ""
    if ok and len(fams) == 1:
        caveat = (f"every supporting part is from one family ({sorted(fams)[0]}). On a generated corpus that "
                  "is one template answering the same way N times, which is not N customers agreeing")
    return Proposal(rule=rule, subject=subject, change=change, support=len(evidence),
                    distinct_parts=len(parts), distinct_families=len(fams), positives=positives,
                    scored_parts=scored, p_value=p_value,
                    required_parts=need["parts"], required_positives=need["positives"], alpha=alpha,
                    look_at=look_at, justified=ok, why_not=why, caveat=caveat, basis=basis,
                    evidence=tuple(evidence))


# ---------------------------------------------------------------------------------------------------------------
# 1. trust demotion
# ---------------------------------------------------------------------------------------------------------------

TRUST_BASIS = (ROLE_SELF_DISAGREEMENT_FROM, MIN_PARTS_FROM, DEMOTION_LOOKS_FROM,
               "a demotion is one way: vision/trust.py tiers go down on evidence and never up on it")


def trust_demotions(records: list[JobRecord], *, looks_taken: dict[str, int] | None = None) -> list[Proposal]:
    """A look field the customer keeps contradicting drops a tier.

    Only openings where the look ASSERTED a role and the customer ANSWERED are counted. An abstention is not
    a contradiction, and a default is not an answer. At most one contradiction per part counts, so a
    twenty-opening manifold cannot demote a tier on its own: that is the same grouping the sweeps use when
    they hold twins together.
    """
    by_field: dict[str, list[Evidence]] = defaultdict(list)
    for record in records:
        if record.look is None:
            continue
        said = {o.id: o.role_said for o in record.look.openings_seen if not o.abstained}
        if not said:
            continue
        hit = None
        for answer in _answered(record):
            oid = topic_and_subject(answer.field)[1]
            if topic_of(answer.field) != "role" or oid not in said:
                continue
            agrees = _same_role(said[oid], answer_of(answer))
            ev = Evidence(rule="trust_demotion", subject="openings_seen[].likely_role",
                          part_key=record.part_key, job_key=record.key, case=record.case,
                          said=said[oid], answered=answer_of(answer), agrees=agrees)
            if not agrees and hit is None:
                hit = ev
            by_field["openings_seen[].likely_role"].append(ev)
        if hit is not None:
            by_field["openings_seen[].likely_role#contradicted"].append(hit)
    out: list[Proposal] = []
    for f in sorted({k.split("#", 1)[0] for k in by_field}):
        seen = by_field.get(f, [])
        bad = by_field.get(f + "#contradicted", [])
        if not seen:
            continue
        #: THE DENOMINATOR, and the first version of this function did not have one. A count of
        #: contradictions with no count of what was scored says nothing: 17 contradicted parts out of 30 is a
        #: field that is wrong half the time, and 17 out of 1,000 is a field that is right 98 per cent of the
        #: time and looks identical in the numerator. The gate is the RATE against the measured self-
        #: disagreement rate, and the two counts are both in the sentence a reader sees.
        scored_parts = len({e.part_key for e in seen})
        bad_parts = len({e.part_key for e in bad})
        p = _tail(bad_parts, scored_parts, ROLE_SELF_DISAGREEMENT) if scored_parts else 1.0
        last = int((looks_taken or {}).get(f, 0) or 0)
        look = demotion_look(scored_parts, last)
        upcoming = next((n for n in DEMOTION_LOOKS if n > max(last, scored_parts)), None)
        between = "" if look is not None else (
            f"between pre-declared looks: {scored_parts} parts scored, the last look spent was at {last}, the next "
            f"is at {upcoming if upcoming is not None else 'none (all seven are spent)'}")
        out.append(_finish("trust_demotion", f,
                           f"demote {f} one tier: the customer contradicted it on {bad_parts} of "
                           f"{scored_parts} parts where it said anything, against the {ROLE_SELF_DISAGREEMENT} "
                           f"this pipeline contradicts itself at (one-sided binomial p = {p:.3g}, read at the "
                           f"look at {look} parts against alpha / {len(DEMOTION_LOOKS)})",
                           bad, bad_parts, TRUST_BASIS, denominator=scored_parts, p_value=p,
                           alpha=DEMOTION_ALPHA, look_at=look, between_looks=between))
    return out


def topic_and_subject(field_name: str) -> tuple[str, str]:
    head, _, tail = str(field_name).partition(":")
    return head, tail


def _same_role(said: str, answered: str) -> bool:
    a = str(said or "").strip().lower().replace(" ", "_")
    b = str(answered or "").strip().lower().replace(" ", "_")
    return a == b or (a in ("not_a_port", "no_flow") and b in ("wall", "closed_end", "not_a_port"))


# ---------------------------------------------------------------------------------------------------------------
# 2. vocabulary widening
# ---------------------------------------------------------------------------------------------------------------

VOCAB_BASIS = (QUESTION_PATH_FLIP_FROM,
               "widening an accept list moves no boundary and costs one synonym if it is wrong, so it does "
               "not carry the MIN_PARTS floor that a behaviour change does",
               "a widened list never narrows: a synonym once added stays added")

#: A trailing enumeration is a numbering, not a word. `outlet_1`, `outlet 2` and `outlet-3` are all the
#: customer writing `outlet` three times, and a vocabulary rule that does not strip them proposes one synonym
#: per port on every multi-port part. Found by running the replay, which produced six of them before this.
_ENUMERATED = re.compile(r"^(.*?)[\s_\-]*\d+$")


def normalise_term(word: str) -> str:
    """What a customer's word is, once a numbering is taken off it. Never used on a role, only on a word."""
    term = str(word or "").strip().lower().replace("-", "_").replace(" ", "_")
    m = _ENUMERATED.match(term)
    return (m.group(1).strip("_") or term) if m else term


def vocabulary_gaps(records: list[JobRecord], accept: dict[str, tuple[str, ...]]) -> list[Proposal]:
    """A word a customer used that our accept list for that topic has no slot for.

    `accept` is per topic, because "mm" is a fine answer to a unit question and a nonsense answer to a role
    question, and one flat list would report every unit as a missing role. A topic with no accept list has
    nothing to widen and is skipped rather than flagged.

    `Answered.verbatim` is what they typed and `Stated.brief_value` is what the brief said. Both count here
    and NOWHERE ELSE in this module: a `Stated` is the customer's words without the customer's confirmation,
    which is enough to say "this word exists" and not enough to say "this port is an outlet".
    """
    slots = {str(k): {str(a).strip().lower() for a in v} for k, v in (accept or {}).items()}
    by_term: dict[tuple[str, str], list[Evidence]] = defaultdict(list)
    for record in records:
        rows: list[tuple[str, str, str]] = []
        for a in _answered(record):
            rows.append((a.field, a.verbatim or answer_of(a), answer_of(a)))
        for s in _stated(record):
            rows.append((s.field, s.brief_value, s.brief_value))
        for fieldname, word, mapped in rows:
            topic = topic_of(fieldname)
            if topic not in slots:
                continue
            term = normalise_term(word)
            if not term or term in slots[topic]:
                continue
            by_term[(topic, term)].append(
                Evidence(rule="vocabulary_widening", subject=term, part_key=record.part_key,
                         job_key=record.key, case=record.case, answered=str(mapped)))
    out: list[Proposal] = []
    for (topic, term), ev in sorted(by_term.items()):
        mapped = Counter(e.answered for e in ev).most_common(1)[0][0]
        parts = len({e.part_key for e in ev})
        p = QUESTION_PATH_FLIP ** parts
        out.append(_finish("vocabulary_widening", f"{topic}:{term}",
                           f"add {term!r} to the {topic} accept list as a synonym for {mapped!r}: "
                           f"{parts} distinct parts used it (p = {p:.3g} that every one of them arrived down "
                           "a question path another run would have skipped)",
                           ev, parts, VOCAB_BASIS, denominator=parts, p_value=p))
    return out


# ---------------------------------------------------------------------------------------------------------------
# 3. question retirement
# ---------------------------------------------------------------------------------------------------------------

RETIRE_BASIS = (RETIREMENT_NULL_FROM, MIN_PARTS_FROM,
                "retired is not deleted: the topic keeps its record, and one contradiction brings it back")


def question_retirements(records: list[JobRecord]) -> list[Proposal]:
    """A topic every customer answers the same way becomes a stated assumption, not a question.

    Counted over ANSWERED resolutions only. A topic every customer SKIPS is not a candidate for retirement:
    it may be a question nobody understands, and retiring it would bake our default in as though they had
    agreed with it. That is the whole failure this package is built against, so it is worth saying in code:
    the defaults are counted, they are reported, and they do not contribute to the support.
    """
    by_topic: dict[str, list[Evidence]] = defaultdict(list)
    skipped: Counter[str] = Counter()
    for record in records:
        for a in _answered(record):
            by_topic[topic_of(a.field)].append(
                Evidence(rule="question_retirement", subject=topic_of(a.field), part_key=record.part_key,
                         job_key=record.key, case=record.case, answered=answer_of(a)))
        for r in (record.intake.resolutions if record.intake else []):
            if not is_answer(r):
                skipped[topic_of(r.field)] += 1
    out: list[Proposal] = []
    for topic, ev in sorted(by_topic.items()):
        answers = Counter(e.answered for e in ev)
        top, n_top = answers.most_common(1)[0]
        agreeing = [e for e in ev if e.answered == top]
        #: The test is not "unanimous", it is "more concentrated than the null". P(X >= n_top) under
        #: Binomial(n, 0.80) asks whether these customers agree MORE than four in five would by chance, which
        #: is the question a retirement actually turns on. Unanimity on 15 clears it (0.8^15 = 0.035) and 14
        #: of 17 does not, which is the right answer both times.
        p = _tail(n_top, len(ev), RETIREMENT_NULL)
        change = (f"retire the {topic} question: {n_top} of {len(ev)} confirmations said {top!r} "
                  f"(one-sided binomial p = {p:.3g} against a null of {RETIREMENT_NULL}). "
                  f"State it as an assumption with {top!r} as the default and keep the topic on the record. "
                  f"{skipped[topic]} resolutions of this topic were defaults or were never asked, and are "
                  "NOT counted here")
        out.append(_finish("question_retirement", topic, change, agreeing, n_top, RETIRE_BASIS,
                           denominator=len({e.part_key for e in ev}), p_value=p))
    return out


# ---------------------------------------------------------------------------------------------------------------
# 4. threshold proposal
# ---------------------------------------------------------------------------------------------------------------

THRESHOLD_BASIS = (MIN_PARTS_FROM,
                   f"one draw against one control cannot reach p below {SINGLE_DRAW_P_FLOOR}, so a threshold "
                   "move needs four draws and this ledger supplies none of them",
                   "docs/thresholds.md owns the move; this is a note that the case exists")


def threshold_proposals(records: list[JobRecord], monitor_field: str = "dispute") -> list[Proposal]:
    """PROPOSE ONLY. Where a monitor keeps raising a dispute a customer keeps settling the same way, say so.

    This never returns a number. A threshold value comes from `eval/calib/sweep.py` with its two baselines and
    its cross-validation, on four draws, and nothing in a job ledger substitutes for that. What the ledger
    can say, and nothing else can, is that the rule keeps firing on real files and the answer keeps being the
    same, which is the case for spending the machine time on a sweep.
    """
    ev: list[Evidence] = []
    settled: Counter[str] = Counter()
    for record in records:
        for a in _answered(record):
            if topic_of(a.field) != monitor_field:
                continue
            settled[answer_of(a)] += 1
            ev.append(Evidence(rule="threshold_proposal", subject=monitor_field, part_key=record.part_key,
                               job_key=record.key, case=record.case, answered=answer_of(a)))
    if not ev:
        return []
    top, n_top = settled.most_common(1)[0]
    parts = len({e.part_key for e in ev})
    change = (f"the {monitor_field} monitor fired on {parts} parts a customer settled, and {n_top} of "
              f"{len(ev)} settled it {top!r}. Run the sweep; do not move anything from this row")
    return [_finish("threshold_proposal", monitor_field, change, ev, n_top, THRESHOLD_BASIS,
                    denominator=parts)]


# ---------------------------------------------------------------------------------------------------------------
# the ratchet
# ---------------------------------------------------------------------------------------------------------------

#: Which way each rule is allowed to move. The whole of the ratchet is this table plus `apply_ratchet`.
DIRECTION = {"trust_demotion": "down_only", "vocabulary_widening": "grow_only",
             "question_retirement": "reversible_on_contradiction", "threshold_proposal": "no_change"}


def apply_ratchet(state: dict[str, Any] | None, proposals: list[Proposal]) -> dict[str, Any]:
    """Fold justified proposals into a ratchet state that only moves one way.

    The state is a small readable dict, not a model: `{"demoted": {...}, "synonyms": {...},
    "retired": {...}, "proposed": [...]}`. A proposal that is not `justified` lands in `proposed` and changes
    nothing. A justified demotion of a field already demoted is a no-op rather than a second step, because a
    tier that could be demoted twice by the same evidence arriving twice is not a ratchet.
    """
    out: dict[str, Any] = {"schema": RECALIBRATE_SCHEMA, "demoted": {}, "synonyms": {}, "retired": {},
                           "looks": {}, "proposed": [], "history": []}
    if isinstance(state, dict):
        for k in ("demoted", "synonyms", "retired"):
            out[k] = {kk: dict(vv) if isinstance(vv, dict) else vv for kk, vv in (state.get(k) or {}).items()}
        out["looks"] = {kk: int(vv) for kk, vv in (state.get("looks") or {}).items()}
        out["history"] = list(state.get("history") or [])
    at = _now()
    # a look is SPENT when it is read, whatever the read found: a gate re-read at the same count on the same
    # evidence is the continuous monitoring C15 measured, one peek at a time
    for p in proposals:
        if p.rule == "trust_demotion" and p.look_at is not None:
            out["looks"][p.subject] = max(int(out["looks"].get(p.subject, 0)), int(p.look_at))

    def _record(kind: str, subject: str, p: Proposal) -> None:
        out["history"].append({"at": at, "kind": kind, "subject": subject, "change": p.change,
                               "parts": p.distinct_parts, "families": p.distinct_families,
                               "positives": p.positives, "caveat": p.caveat})

    for p in proposals:
        if not p.justified:
            out["proposed"].append(p.as_row())
            continue
        if p.rule == "trust_demotion":
            if p.subject not in out["demoted"]:
                out["demoted"][p.subject] = {"why": p.change, "parts": p.distinct_parts, "since": at,
                                             "caveat": p.caveat}
                _record("demoted", p.subject, p)
        elif p.rule == "vocabulary_widening":
            topic, _, term = p.subject.partition(":")
            bucket = out["synonyms"].setdefault(topic, {})
            if term not in bucket:
                bucket[term] = {"maps_to": p.evidence[0].answered if p.evidence else "",
                                "parts": p.distinct_parts, "since": at, "caveat": p.caveat}
                _record("synonym", p.subject, p)
        elif p.rule == "question_retirement":
            if p.subject not in out["retired"]:
                out["retired"][p.subject] = {"why": p.change, "parts": p.distinct_parts, "since": at,
                                             "caveat": p.caveat}
                _record("retired", p.subject, p)
        else:
            out["proposed"].append(p.as_row())
    return out


def _now() -> str:
    from geometry_agent.chain.resolution import now

    return now()


def load_ratchet(path: str | Path) -> dict[str, Any]:
    """The ratchet state from disk, or an empty one. A file that will not parse is an error, not an empty
    state: silently starting from nothing is how a ratchet quietly un-ratchets."""
    p = Path(path)
    if not p.exists():
        return {"schema": RECALIBRATE_SCHEMA, "demoted": {}, "synonyms": {}, "retired": {}, "proposed": [],
                "history": []}
    return json.loads(p.read_text(encoding="utf-8"))


def save_ratchet(path: str | Path, state: dict[str, Any], *, previous: dict[str, Any] | None = None) -> int:
    """Write the state, refusing any write that would move something back.

    THIS IS THE RATCHET, and it is four lines. A state that has lost a demotion, a synonym or a retirement
    since `previous` is refused with the entries named. Nothing in this package can quietly un-demote a tier,
    including a caller that reconstructed the state from a smaller ledger.
    """
    if previous:
        lost: list[str] = []
        for key in ("demoted", "retired"):
            lost += [f"{key}:{k}" for k in (previous.get(key) or {}) if k not in (state.get(key) or {})]
        for topic, terms in (previous.get("synonyms") or {}).items():
            have = (state.get("synonyms") or {}).get(topic) or {}
            lost += [f"synonyms:{topic}:{t}" for t in terms if t not in have]
        # a look spent is spent: a state that has forgotten one would let the same count be read again
        for subject, n in (previous.get("looks") or {}).items():
            if int((state.get("looks") or {}).get(subject, 0) or 0) < int(n):
                lost.append(f"looks:{subject}")
        if lost:
            raise ValueError("this write would move the ratchet back on " + ", ".join(sorted(lost))
                             + ". A tier that gets demoted stays demoted and a synonym that gets added stays "
                               "added; if one of these is genuinely wrong, a person removes it by hand and "
                               "says why in the history.")
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(state, indent=1, default=str)
    p.write_text(text, encoding="utf-8")
    return len(text)


def all_proposals(records: list[JobRecord], accept: dict[str, tuple[str, ...]],
                  state: dict[str, Any] | None = None) -> list[Proposal]:
    """Every rule over the records. `state` is the ratchet state, whose `looks` say which demotion looks are
    already spent; without it every look is unspent, which is right only for a ledger read for the first time."""
    looks = state.get("looks") if isinstance(state, dict) else None
    return (trust_demotions(records, looks_taken=looks) + vocabulary_gaps(records, accept)
            + question_retirements(records) + threshold_proposals(records))


__all__ = ["ALPHA", "DEMOTION_ALPHA", "DEMOTION_LOOKS", "DIRECTION", "Evidence", "MIN_PARTS", "MIN_POSITIVE", "N_CONTRADICTION", "N_RETIREMENT",
           "N_VOCABULARY", "Proposal", "QUESTION_PATH_FLIP", "RECALIBRATE_SCHEMA", "REQUIRED",
           "RETIREMENT_NULL", "ROLE_SELF_DISAGREEMENT", "SINGLE_DRAW_P_FLOOR", "all_proposals",
           "load_ratchet", "normalise_term", "save_ratchet",
           "apply_ratchet", "demotion_look", "question_retirements", "smallest_n", "threshold_proposals",
           "trust_demotions",
           "vocabulary_gaps"]
