"""The two write-ups that go to the builder, and the rule that survives the boundary.

REHAAN'S DESIGN, in his words: intake's write-up and the geometry agent's write-up both go to the builder, and
the surveyor's information goes in WITH the geometry agent's. So there are two blocks and not three, and the
survey rides inside the second one.

    from_intake     what the customer settled, and what nobody settled. TWO SEPARATE KEYS, never merged.
    from_geometry   what the agent decided to do, with the measurement it decided against and the look's
                    relied-on claims inside it.

THE RULE THAT HAS TO SURVIVE THE BOUNDARY, and this is the only reason this file is not one f-string. The
ledger keeps an answer and a default apart by type. The moment the two reach the builder as one dict of port
roles, that distinction stops at the ledger door and the builder acts on our guess believing it was confirmed.
So `from_intake` has `confirmed` and `assumed` as two keys with two meanings, and no function in this module
ever merges them:

    confirmed   the customer was asked and replied. Build to it.
    assumed     nobody said. Build to it too, because a builder has to be told something, AND report back on
                it, because a thing the builder reports on is a thing that can be confirmed next time.

`read_as` says that in the block, so a consumer that has never read this file still branches correctly.

WHAT IS NOT IN EITHER BLOCK. The recorded tier of `vision/trust.py`: defects, the per-opening class,
orientation, symmetry, `notes` and `likely_role`. They are stripped by `trust.for_model`, which is the module
that owns the rule, and not by a list written here that could drift from it. `defects` alone raised three to
five false alarms on clean files and caught neither of the two files with a real defect.

NO BUILDER SETTING IS NAMED HERE. The survey describes places and measurements; the builder owns its own
controls. `hexera.planner_block` is the typed channel that carries the measured numbers into the planner
message after the `request_txt[:2000]` cut, and this block references it rather than restating it.
"""
from __future__ import annotations

from typing import Any

from geometry_agent.chain.resolution import (
    Answered,
    Defaulted,
    Stated,
    Unasked,
    Unresolved,
    answer_of,
)
from geometry_agent.chain.schema import JobRecord, Look, plan_drift
from geometry_agent.vision import trust

HANDOVER_SCHEMA = "geometry_agent.chain.handover.v1"

#: The sentence a consumer branches on without having read this module.
READ_AS = ("`confirmed` is what the customer said and `assumed` is what nobody said. Build to both. REPORT "
           "BACK on anything under `assumed`: a default that gets reported becomes a question that gets "
           "answered, and a default that is treated as an answer becomes a fact nobody ever checked.")

#: Budgets, matched to the channel the block rides in. `hexera.BUILDER_BLOCK_MAX_CHARS` is 2400 and
#: `HEADER_MAX_CHARS` 500; the prose here is the shorter of the two because the typed block carries the detail.
WRITE_UP_MAX_CHARS = 1200


# ---------------------------------------------------------------------------------------------------------------
# intake's write-up
# ---------------------------------------------------------------------------------------------------------------

def intake_block(record: JobRecord) -> dict[str, Any]:
    """What intake settled and what it did not, as two keys that are never merged.

    `confirmed` comes through `answer_of`, so it can only ever hold an `Answered`. Everything else lands in
    `assumed` with the reason it is an assumption, and `open` holds a question still waiting.
    """
    confirmed: dict[str, Any] = {}
    assumed: dict[str, dict[str, str]] = {}
    from_brief: dict[str, dict[str, str]] = {}
    still_open: list[str] = []
    # the second intake and the third, in order: a trade answered at the third lands under `confirmed` exactly as
    # a role answered at the second does, and a trade skipped lands under `assumed`
    resolutions = [*(record.intake.resolutions if record.intake else ()),
                   *(record.trade.resolutions if record.trade else ())]
    if resolutions:
        for r in resolutions:
            if isinstance(r, Answered):
                confirmed[r.field] = answer_of(r)
            elif isinstance(r, Defaulted):
                assumed[r.field] = {"value": r.assumed, "why": "asked, and the customer did not answer",
                                    "from": r.default_from}
            elif isinstance(r, Unasked):
                assumed[r.field] = {"value": r.assumed,
                                    "why": f"never asked ({r.why_not_asked or 'no reason recorded'})",
                                    "from": r.default_from}
            elif isinstance(r, Stated):
                from_brief[r.field] = {"value": r.brief_value, "why": "the brief says so and nobody confirmed it",
                                       "quote": r.quote}
            elif isinstance(r, Unresolved):
                still_open.append(r.field)
    return {
        "schema": HANDOVER_SCHEMA,
        "read_as": READ_AS,
        "confirmed": confirmed,
        "assumed": assumed,
        #: Kept apart from both. The brief is the customer's words without the customer's confirmation, and
        #: P4.4 already ruled that a brief naming a question's subject does not answer it.
        "from_the_brief": from_brief,
        "still_open": still_open,
        "questions_asked": (len(record.intake.asked) if record.intake else 0)
                           + (len(record.trade.asked) if record.trade else 0),
        "write_up": record.intake.write_up if record.intake else "",
        "counts": record.intake.counts if record.intake else {},
    }


# ---------------------------------------------------------------------------------------------------------------
# the geometry agent's write-up, with the survey inside it
# ---------------------------------------------------------------------------------------------------------------

def _impression_of(look: Look | None) -> dict[str, Any] | None:
    """The impression fields the record kept, back in the shape `vision.trust` reads.

    Rebuilt rather than stored twice. `trust.for_model` then decides what may go in front of a model, which
    keeps the rule in the module that measured it instead of in a list here that could drift from it.
    """
    if look is None:
        return None
    return {
        "looks_like": look.looks_like, "confidence": look.confidence,
        "attachments": list(look.attachments),
        "internal_features": list(look.internal_features),
        "openings_seen": [{"id": o.id, "looks_like": o.looks_like, "mouth": o.mouth,
                           "likely_role": o.role_said, "why": o.why} for o in look.openings_seen],
    }


def geometry_block(record: JobRecord, restated: dict[str, Any] | None = None,
                   typed: dict[str, Any] | None = None) -> dict[str, Any]:
    """What the agent decided to do, with the measurement and the look inside it.

    THE SURVEY GOES HERE, per Rehaan, and not in a block of its own. `measured` is the authoritative half:
    what the geometry IS, which the agent may not re-decide. `decided` is the agent's half: what to do about
    it. `drift` is every authoritative field the plan restated differently, which should be empty and is
    reported rather than enforced.
    """
    survey, plan = record.survey, record.plan
    measured: dict[str, Any] = {}
    if survey is not None:
        measured = {
            "representation": survey.representation, "purpose": survey.purpose,
            "unit": survey.unit, "unit_basis": survey.unit_basis,
            "measurement_status": survey.planner_block_status,
            "openings": [{"id": o.id, "kind": o.kind, "shape": o.shape,
                          "hydraulic_diameter": o.hydraulic_diameter, "bore_diameter": o.bore_diameter,
                          "tilt_deg": o.tilt_deg, "on_bbox_face": o.on_bbox_face, "centroid": o.centroid}
                         for o in survey.openings],
            "bbox_extent": survey.bbox_extent, "bodies": survey.bodies, "watertight": survey.watertight,
            "forecast_cells": survey.forecast_cells, "forecast_basis": list(survey.forecast_basis),
            "stated_cell_cap": survey.stated_cell_cap,
            "authoritative": list(survey.authoritative),
            "read_as": ("measured, not inferred. These are the facts the plan was made against and they are "
                        "not re-derived downstream. The numbers the planner reads are in "
                        "hexera.planner_block, which rides after the request_txt cut"),
        }
    decided: dict[str, Any] = {}
    if plan is not None:
        decided = {"fidelity": plan.fidelity, "engine": plan.engine, "cell_estimate": plan.cell_estimate,
                   "refinement_regions": plan.refinement_regions,
                   "used_confirmations": list(plan.used_confirmations), "risks": plan.risks,
                   "write_up": plan.write_up, "policy": plan.policy}
    # ONE PATH FOR THE LOOK (work/z-deliver NEEDS 7). When the builder's typed block is at hand the look and the
    # survey are ITS `look` and `survey`, composed once by `hexera.planner_block`. Only a caller holding the record
    # alone (the ledger's CLI) gets the record's own view, through the same `trust.for_model` rule
    if isinstance(typed, dict):
        look: Any = typed.get("look")
        survey_block: Any = typed.get("survey")
    else:
        look = trust.for_model(_impression_of(record.look), model=record.look.model if record.look else "",
                               provider=record.look.provider if record.look else "")
        survey_block = None
    out = {
        "schema": HANDOVER_SCHEMA,
        "measured": measured,
        "look": look,
        "decided": decided,
        "drift": plan_drift(survey, restated if restated is not None else (plan.restates if plan else None)),
    }
    if survey_block is not None:
        out["survey"] = survey_block
    return out


# ---------------------------------------------------------------------------------------------------------------
# the handover
# ---------------------------------------------------------------------------------------------------------------

def builder_handover(record: JobRecord, restated: dict[str, Any] | None = None,
                     typed: dict[str, Any] | None = None) -> dict[str, Any]:
    """The two write-ups, side by side, with the survey inside the second. `typed` is the builder's typed block
    (`hexera.planner_block`), whose look and survey this carries when given."""
    return {"schema": HANDOVER_SCHEMA, "key": record.key, "part_key": record.part_key,
            "provenance": record.provenance,
            "from_intake": intake_block(record),
            "from_geometry": geometry_block(record, restated, typed)}


def write_up(record: JobRecord, limit: int = WRITE_UP_MAX_CHARS) -> str:
    """The prose version, for a channel that carries no dict. Confirmed and assumed stay two paragraphs.

    Short on purpose and cut at `limit` from the end, so the first sentence of each half survives the cut: a
    block whose last line is the one that says which roles were assumed is a block whose truncation is the
    failure.
    """
    block = builder_handover(record)
    intake, geom = block["from_intake"], block["from_geometry"]
    lines: list[str] = []
    measured = geom.get("measured") or {}
    if measured:
        lines.append(f"MEASURED: {measured.get('representation') or 'representation unknown'}, "
                     f"{len(measured.get('openings') or [])} openings, unit {measured.get('unit') or '?'} "
                     f"({measured.get('unit_basis') or 'no basis'}).")
    if intake["confirmed"]:
        lines.append("CONFIRMED by the customer: "
                     + "; ".join(f"{k} = {v}" for k, v in sorted(intake["confirmed"].items())) + ".")
    else:
        lines.append("CONFIRMED by the customer: nothing.")
    if intake["assumed"]:
        lines.append("ASSUMED, nobody confirmed these, report back on them: "
                     + "; ".join(f"{k} = {v['value']}" for k, v in sorted(intake["assumed"].items())) + ".")
    if intake["from_the_brief"]:
        lines.append("FROM THE BRIEF, not confirmed: "
                     + "; ".join(f"{k} = {v['value']}" for k, v in sorted(intake["from_the_brief"].items())) + ".")
    decided = geom.get("decided") or {}
    if decided:
        lines.append(f"PLANNED: {decided.get('fidelity') or 'fidelity unset'} on "
                     f"{decided.get('engine') or 'no engine'}, "
                     f"{decided.get('refinement_regions') or 0} refinement regions.")
    if geom.get("drift"):
        lines.append(f"DRIFT: the plan restated {', '.join(sorted(geom['drift']))} differently from the "
                     "measurement.")
    text = "\n".join(lines)
    return text if len(text) <= limit else text[: max(0, limit - 3)] + "..."


__all__ = ["HANDOVER_SCHEMA", "READ_AS", "WRITE_UP_MAX_CHARS", "builder_handover", "geometry_block",
           "intake_block", "write_up"]
