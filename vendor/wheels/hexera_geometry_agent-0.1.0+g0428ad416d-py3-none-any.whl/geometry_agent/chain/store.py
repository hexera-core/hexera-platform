"""Where a job record lives: one append-only JSONL of stage events, folded into records on read.

WHY EVENTS AND NOT ROWS. The stages arrive hours apart and sometimes never. The survey lands at upload, intake
lands when the customer replies, the plan lands when the agent finishes and the mesh lands when the builder
does, if it does. A row rewritten in place would mean the ledger's own history is the thing we lose first, and
`docs/learning_loop.md` section 5 already lists editing or deleting records as never automated. So the file
only ever grows, one line per stage, and `records()` folds them: the last event for a (key, stage) wins and
the earlier ones stay on disk.

PROVENANCE IS ON EVERY EVENT AND NOT ONLY ON THE FILE. A simulated job and a live job can sit in one file
without the reports confusing them, because `summary()` splits by provenance before it prints anything and
refuses to print a single headline over a mixed file. Eight times in this project a measuring tool has had the
same blind spot as the thing it measured; a ledger whose report pools a replay with a customer would be the
ninth, and the split is in the code rather than in a convention.

WHAT THIS DROPS, asked before any number from it is believed:
  - An event whose JSON will not parse is COUNTED as `unreadable` and reported, never skipped silently.
  - An event for an unknown stage is counted as `unknown_stage` and reported the same way.
  - A resolution payload that fails `resolution.from_json` fails the whole record load LOUDLY, because the
    refusal it is failing on is the one that stops a default being read as an answer.
"""
from __future__ import annotations

import json
import os
import tempfile
from collections.abc import Iterable, Iterator
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any

from geometry_agent.chain.resolution import now
from geometry_agent.chain.resolution import to_json as resolution_to_json
from geometry_agent.chain.schema import (
    STAGES,
    Intake,
    JobRecord,
    Look,
    Mesh,
    Plan,
    Survey,
    Uncertainty,
    job_key,
)
from geometry_agent.chain.schema import (
    from_json as record_from_json,
)

LEDGER_SCHEMA = "geometry_agent.chain.ledger.v1"

#: `live` is a real customer job. `simulation` is a replay of something we generated. `heuristic` is a
#: stand-in policy standing where a model would be. Nothing pools them.
PROVENANCE = ("live", "simulation", "heuristic")


def _payload(stage: str, value: Any) -> Any:
    if stage == "uncertainty":
        return [asdict(u) for u in value]
    if stage in ("intake", "trade"):
        return {"asked": [asdict(q) for q in value.asked],
                "resolutions": [resolution_to_json(r) for r in value.resolutions],
                "turns": value.turns, "write_up": value.write_up}
    if is_dataclass(value) and not isinstance(value, type):
        return asdict(value)
    return value


class JobLedger:
    """The store. Open it on a path, put stages on it, read records back."""

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self._pending: list[dict[str, Any]] = []
        self._meta: dict[str, dict[str, str]] = {}

    # ---- writing -------------------------------------------------------------------------------------

    def open_job(self, part_key: str, job_id: str, *, provenance: str = "live", case: str = "") -> str:
        """Start a job. Returns its key. Writes no event: a job with no stage on it is not a record."""
        if provenance not in PROVENANCE:
            raise ValueError(f"provenance must be one of {PROVENANCE}, not {provenance!r}")
        key = job_key(part_key, job_id)
        self._meta[key] = {"part_key": str(part_key), "job_id": str(job_id), "provenance": provenance,
                           "case": str(case)}
        return key

    def put(self, key: str, stage: str, value: Any, *, at: str = "") -> dict[str, Any]:
        """One stage of one job. Appends; never edits. Returns the event exactly as it will be written, so a
        caller can show the row a stage wrote without reading the file back."""
        if stage not in STAGES:
            raise ValueError(f"stage must be one of {STAGES}, not {stage!r}")
        meta = self._meta.get(key)
        if meta is None:
            raise KeyError(f"{key} was never opened: call open_job first, so the record carries a provenance")
        event = {"schema": LEDGER_SCHEMA, "at": at or now(), "event": stage, "key": key, **meta,
                 "payload": _payload(stage, value)}
        self._pending.append(event)
        return event

    def flush(self) -> int:
        """Append the pending events. Returns how many lines were written."""
        if not self._pending:
            return 0
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open("a", encoding="utf-8") as fh:
            for event in self._pending:
                fh.write(json.dumps(event, default=str, sort_keys=False) + "\n")
        n = len(self._pending)
        self._pending = []
        return n

    def rewrite(self, events: Iterable[dict[str, Any]]) -> int:
        """Replace the file with `events`, atomically.

        The ONE operation that is not append-only, and it exists for one caller: a replay that reruns from
        scratch and must not double every count. It is never used on a `live` file and `replay_corpus.py`
        passes `--fresh` to reach it, so a customer ledger cannot be rewritten by a flag nobody typed.
        """
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=str(self.path.parent), suffix=".tmp")
        n = 0
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                for event in events:
                    fh.write(json.dumps(event, default=str) + "\n")
                    n += 1
            os.replace(tmp, self.path)
        except BaseException:
            Path(tmp).unlink(missing_ok=True)
            raise
        return n

    # ---- reading -------------------------------------------------------------------------------------

    def events(self) -> Iterator[dict[str, Any]]:
        if not self.path.exists():
            return
        with self.path.open(encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    yield json.loads(line)
                except json.JSONDecodeError:
                    yield {"event": "__unreadable__"}

    def records(self) -> dict[str, JobRecord]:
        """Fold the events into records. Last event per (key, stage) wins."""
        folded, _ = self.records_and_health()
        return folded

    def records_and_health(self) -> tuple[dict[str, JobRecord], dict[str, int]]:
        raw: dict[str, dict[str, Any]] = {}
        health = {"events": 0, "unreadable": 0, "unknown_stage": 0}
        for event in self.events():
            health["events"] += 1
            stage = event.get("event")
            if stage == "__unreadable__":
                health["unreadable"] += 1
                continue
            if stage not in STAGES:
                health["unknown_stage"] += 1
                continue
            key = str(event.get("key") or "")
            row = raw.setdefault(key, {"key": key, "part_key": event.get("part_key") or "",
                                       "job_id": event.get("job_id") or "",
                                       "provenance": event.get("provenance") or "live",
                                       "case": event.get("case") or "",
                                       "created_at": event.get("at") or now(), "uncertainties": []})
            row["updated_at"] = event.get("at") or now()
            payload = event.get("payload")
            row["uncertainties" if stage == "uncertainty" else stage] = payload
        return ({k: record_from_json(v) for k, v in raw.items()}, health)

    # ---- reporting -----------------------------------------------------------------------------------

    def summary(self) -> dict[str, Any]:
        """Counts, SPLIT BY PROVENANCE BEFORE ANYTHING ELSE. There is no pooled headline in this dict."""
        records, health = self.records_and_health()
        out: dict[str, Any] = {"schema": LEDGER_SCHEMA, "path": str(self.path), "health": health,
                               "by_provenance": {}}
        for prov in PROVENANCE:
            rows = [r for r in records.values() if r.provenance == prov]
            if not rows:
                continue
            counts = {"jobs": len(rows), "parts": len({r.part_key for r in rows}),
                      "complete": sum(1 for r in rows if r.complete),
                      "uncertainties": sum(len(r.uncertainties) for r in rows),
                      "questions": sum(len(r.intake.asked) for r in rows if r.intake),
                      "stages": {s: sum(1 for r in rows if s in r.stages_present) for s in STAGES}}
            res = {"answered": 0, "defaulted": 0, "stated": 0, "unasked": 0, "unresolved": 0}
            for r in rows:
                if r.intake:
                    for k, v in r.intake.counts.items():
                        res[k] = res.get(k, 0) + v
            counts["resolutions"] = res
            out["by_provenance"][prov] = counts
        return out


def merge_key(record: JobRecord) -> str:
    """The key a later pass joins on. Named so nobody invents a second spelling of it."""
    return record.key


__all__ = ["LEDGER_SCHEMA", "PROVENANCE", "Intake", "JobLedger", "JobRecord", "Look", "Mesh", "Plan",
           "Survey", "Uncertainty", "merge_key"]
