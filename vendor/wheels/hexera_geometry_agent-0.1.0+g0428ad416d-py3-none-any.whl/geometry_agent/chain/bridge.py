"""THE SURVEYOR'S ABSTENTIONS ARE INTAKE'S QUESTIONS. This file is that sentence as code.

The two lists already existed and were never connected. `vision/trust.py` puts `likely_role` in the RECORDED
tier because the look abstains on most mouths and is a coin where it does not, so today the abstention is
discarded as a non-answer. It is not a non-answer. It is the question.

    "I can see four openings. Two run through the part. On o3 I cannot tell, and it is a 12 mm circular
     mouth on the underside." IS the question "which of these is the drain".

WHAT EACH HALF CONTRIBUTES TO A QUESTION, and it matters which. Every NUMBER in a question here comes from the
MEASUREMENT: the look never produces a number, every digit is scrubbed before we see it, and a count is a
digit. Every qualitative framing comes from the look: which mouths it could see at all, what it could not
tell. A question is the two channels side by side with the source of each named, and never a blend.

WHAT IS NOT ASKED ABOUT, and the argument is `reconcile/verdict.QUESTION_ORDER`'s own: a question whose answer
has nowhere to go is a question that stops the form being filled in. Symmetry, orientation, the per-opening
class and defects are all RECORDED in `vision.trust` because the measurement has them exactly, so a customer's
answer would change nothing that is allowed to act on it. None of them raises an uncertainty here.

THE QUESTION BUDGET. `QUESTION_LIMIT` is 5, and 5 is not a number I liked: it is the p90 of what the
platform's own intake actually asked across the 322 export conversations (mean 2.16, median 2, p90 5, max 16).
An uncertainty past the budget is recorded as `Unasked`, with its own resolution type, so the ledger can tell
a customer who skipped a question from one who was never shown it.

NOTHING HERE IS ON BY DEFAULT. These are pure functions over a measurement document. No module under `agent/`
calls them.
"""
from __future__ import annotations

from typing import Any

from geometry_agent.chain.schema import Question, Uncertainty, question_id

#: The p90 of the intake questions asked over the 322 export conversations, measured, not chosen. Mean 2.16,
#: median 2, p75 3, p90 5, p95 6, max 16.
QUESTION_LIMIT = 5
QUESTION_LIMIT_WHY = ("the p90 of what the platform's own intake asked over the 322 corpus export "
                      "conversations: mean 2.16, median 2, p75 3, p90 5, max 16")

#: What a role answer may be. `PURPOSE_ROLES` in `agent/hexera.py` is the closed list the handover speaks, and
#: this mirrors the internal-flow entry. A word outside it is what the vocabulary rule in `recalibrate.py`
#: exists to catch, so the options offered are deliberately the closed list and the answer is kept verbatim
#: as well.
ROLE_OPTIONS = ("inlet", "outlet", "wall", "closed_end", "symmetry", "not_a_port")

#: The unit words the measurement layer converts, mirrored from `hexera.UNIT_TO_M` and pinned against it by
#: `tests/test_chain_ledger.py`. Mirrored rather than imported so this module stays importable without the
#: agent, which matters because the bridge runs at upload, before any agent does.
UNIT_OPTIONS = ("m", "mm", "cm", "in", "ft")

#: The accept vocabulary per topic. A topic that is not in here has nothing to widen, and
#: `recalibrate.vocabulary_gaps` skips it rather than reporting every value it sees as a missing word.
ACCEPT_VOCABULARY: dict[str, tuple[str, ...]] = {"role": ROLE_OPTIONS, "unit": UNIT_OPTIONS}

#: The order questions are asked in, lower first. There is no measurement behind the exchange rate between
#: kinds, so this is an ORDER and never a score, exactly as `hexera._planner_places` says of its own severity.
#: `dispute` sits AHEAD of `role` for one structural reason and not a judgement about importance:
#: `reconcile.verdict.question` returns AT MOST ONE dispute by construction, so a dispute can never crowd the
#: roles out, while a six-port part's roles would crowd the dispute out every time. It is also the only kind
#: here no other channel can raise.
KIND_RANK = {"unit": 0.0, "budget": 1.0, "dispute": 1.5, "role": 2.0, "opening_unmeasured": 4.0,
             "opening_unseen": 5.0}

#: Per kind: what an answer here would be a labelled example of, and whether answering changes the mesh.
#: An empty `teaches` is not a reason not to ask; it is a reason not to count the answer in a learning report.
KIND_TEACHES = {
    "role": "the role of one opening on a real part, at zero annotation cost, from a question we were asking anyway",
    "unit": "which unit a file of this format and this size actually was",
    "fluid_side": "which side of the surface is the fluid on a file whose shape reads the same both ways",
    "budget": "what a customer trades when the envelope does not fit their stated cap",
    "dispute": "which of the measurement and the look is right at a place where neither outranks the other",
    "opening_unmeasured": "an opening the measurement did not find, which is the one thing no measurement can supply",
    "opening_unseen": "what the look misses, on a part where somebody checked",
}
KIND_EFFECT = {"role": "changes_bc", "unit": "changes_mesh", "fluid_side": "changes_mesh", "budget": "changes_mesh", "dispute": "changes_mesh",
               "opening_unmeasured": "changes_mesh", "opening_unseen": "advisory"}


def _fmt_mm(value: Any) -> str:
    return "" if not isinstance(value, int | float) else f"{float(value):.4g}"


def _seen_index(look: dict[str, Any] | None) -> dict[str, dict[str, Any]]:
    imp = ((look or {}).get("impression") or look or {}) if look else {}
    out: dict[str, dict[str, Any]] = {}
    for row in (imp.get("openings_seen") or []):
        if isinstance(row, dict):
            out[str(row.get("id") or "unlabelled")] = row
    return out


def _abstained(row: dict[str, Any] | None) -> bool:
    if row is None:
        return True
    return str(row.get("likely_role") or "").strip().lower() in ("", "unsure", "unknown", "cannot tell")


def role_uncertainties(document: dict[str, Any], look: dict[str, Any] | None,
                       declared: dict[str, str] | None = None) -> list[Uncertainty]:
    """One per opening whose role neither the customer nor the survey has settled.

    THE THREE STATES, and only the third is a question:
      declared      the customer already said. Settled, and the survey does not argue with it.
      called        the look named a role. NOT settled: `likely_role` is a coin where it guesses, so a call
                    is asked about too, and the question says the look's guess is a guess.
      abstained     the look declined, or never saw the mouth at all. The question this file exists for.
    """
    declared = {str(k): str(v) for k, v in (declared or {}).items()}
    seen = _seen_index(look)
    rows = [r for r in (document.get("openings") or []) if isinstance(r, dict)]
    n_seen = len([oid for oid in seen if oid != "unlabelled"])
    out: list[Uncertainty] = []
    for row in rows:
        oid = str(row.get("id") or "")
        if not oid or oid in declared:
            continue
        said = seen.get(oid)
        abstained = _abstained(said)
        known = {"shape": row.get("shape"), "kind": row.get("kind"),
                 "hydraulic_diameter_m": row.get("hydraulic_diameter_m"),
                 "bore_diameter_m": row.get("bore_diameter_m"), "tilt_deg": row.get("tilt_deg"),
                 "on_bbox_face": row.get("on_bbox_face"), "centroid_m": row.get("centroid_m"),
                 "measured_by": "the measurement. Every number in this question is measured; the look "
                                "produces no numbers and every digit is scrubbed before we see it"}
        if abstained:
            because = ("the look could see this mouth and declined to say what it is for"
                       if said is not None else
                       "the measurement found this mouth and the look did not name it at all")
        else:
            because = (f"the look calls it {said.get('likely_role')}, and a role call from the picture is "
                       "right about half the time, so it is a suggestion and not an answer")
        size = _fmt_mm(row.get("hydraulic_diameter_m"))
        where = "on a face of the bounding box" if row.get("on_bbox_face") else "inside the envelope"
        ask = (f"I can see {n_seen or len(rows)} openings on this part. "
               f"Opening {oid} is a {row.get('shape') or 'planar'} mouth"
               + (f", {size} m across" if size else "") + f", {where}. {because.capitalize()}. "
               "What is it for?")
        out.append(Uncertainty(
            id=f"role:{oid}", kind="role", subject=oid, known=known, unsettled_because=because, ask=ask,
            default="opening_unknown",
            default_from="agent/schema.py Role: the opening stays unknown and the builder is told so, "
                         "because a role comes from the customer or from nowhere (vision/trust.py)",
            teaches=KIND_TEACHES["role"], effect=KIND_EFFECT["role"],
            rank=KIND_RANK["role"] + (0.0 if abstained else 0.5)))
    return out


def unmeasured_openings(document: dict[str, Any], look: dict[str, Any] | None) -> list[Uncertainty]:
    """The look named a mouth the measurement has no label for.

    `vision/trust.py` on `openings_seen[].id`: an id of `unlabelled` is the look reporting a mouth the
    measurement did not find, which is the one thing here no measurement can supply. That is worth a question
    on its own, and it is the only uncertainty in this file the measurement could not have raised alone.
    """
    seen = _seen_index(look)
    if "unlabelled" not in seen:
        return []
    row = seen["unlabelled"]
    return [Uncertainty(
        id="opening_unmeasured:unlabelled", kind="opening_unmeasured", subject="unlabelled",
        known={"look_says": row.get("looks_like") or "", "why": row.get("why") or "",
               "measured_openings": len(document.get("openings") or [])},
        unsettled_because="the look reports a mouth the measurement did not find",
        ask="The pictures show an opening the measurement did not pick up"
            + (f" ({row.get('looks_like')})" if row.get("looks_like") else "")
            + ". Is there one there?",
        default="no: the measurement's opening list stands",
        default_from="the measurement, which is the instrument and outranks the picture on what is there",
        teaches=KIND_TEACHES["opening_unmeasured"], effect=KIND_EFFECT["opening_unmeasured"],
        rank=KIND_RANK["opening_unmeasured"])]


def unit_uncertainty(document: dict[str, Any]) -> list[Uncertainty]:
    """The file carries no confirmed unit, so every length in the handover is a number with no scale.

    This is first in the order because it is the 1,000x error the measurement layer exists to avoid, and
    because `planner_block` goes `degraded` on it, which is the one status the platform already branches on.
    """
    block = document.get("planner_block") or {}
    unit = document.get("unit") or {}
    basis = str(unit.get("basis") or "")
    if str(block.get("status") or "") != "degraded" and basis not in ("guess", ""):
        return []
    candidates = unit.get("candidates") or []
    return [Uncertainty(
        id="unit:file", kind="unit", subject="file",
        known={"assumed": unit.get("assumed"), "basis": basis, "candidates": candidates,
               "declared_in_file": unit.get("declared"), "plausible_for_purpose": unit.get("plausible_for_purpose")},
        unsettled_because="nothing in the file states a unit and nobody has confirmed one",
        ask="This file carries no unit. I am reading it as "
            + f"{unit.get('assumed') or 'millimetres'}"
            + (f", and {', '.join(str(c) for c in candidates)} would also fit. " if candidates else ". ")
            + "Which is it?",
        default=str(unit.get("assumed") or "mm"),
        default_from="facts/units.py: the most plausible candidate for the stated purpose",
        teaches=KIND_TEACHES["unit"], effect=KIND_EFFECT["unit"], rank=KIND_RANK["unit"])]


def budget_uncertainty(document: dict[str, Any]) -> list[Uncertainty]:
    """ASK ONCE, AS A REAL TRADE, and only when the envelope genuinely does not fit.

    The number is `forecast.cells_high`, which is `tools.estimate_builder_cells`, the emulator that reproduces
    the builder's own sizing. NEVER `tools.refined_cell_estimate`, whose median is 1.86x and max 576x. If the
    envelope fits the cap the customer already stated, nothing is asked at all: that is the whole design of
    the forecast, and a question asked where the answer is already known is the false alarm this project has
    measured 223 of.
    """
    forecast = document.get("forecast") or {}
    cap = forecast.get("cell_cap")
    high = forecast.get("cells_high")
    if not isinstance(cap, int | float) or not cap or not isinstance(high, int | float):
        return []
    if float(high) <= float(cap):
        return []
    return [Uncertainty(
        id="budget:cap", kind="budget", subject="cap",
        known={"cells_high": int(high), "cell_cap": int(cap), "over_by": round(float(high) / float(cap), 2),
               "basis": list(forecast.get("basis") or []), "calibration": forecast.get("calibration")},
        unsettled_because="resolving this part properly costs more cells than the budget you stated",
        ask=f"Resolving this part at the size its smallest feature needs comes to about {int(high):,} cells, "
            f"and you asked for under {int(cap):,}. I can stay inside your cap and resolve that feature more "
            "coarsely, or go over it. Which do you want?",
        default="stay inside the stated cap",
        default_from="the customer's own brief, which stated the cap",
        teaches=KIND_TEACHES["budget"], effect=KIND_EFFECT["budget"], rank=KIND_RANK["budget"])]


def dispute_uncertainties(reconciliation_question: dict[str, Any] | None) -> list[Uncertainty]:
    """The ONE question `reconcile/verdict.question` already builds, carried into this vocabulary.

    Nothing is re-derived here. That module decided which disputes are worth asking about and what the
    cautious default is; this wraps its output so the ledger holds one shape of question and not two.
    """
    q = reconciliation_question
    if not isinstance(q, dict) or not q.get("about"):
        return []
    return [Uncertainty(
        id=f"dispute:{q.get('claim') or q['about']}", kind="dispute", subject=str(q.get("about")),
        known={"look_says": q.get("ask"), "why_not_settled": q.get("why_not_settled"),
               "others_on_the_record": q.get("others_on_the_record")},
        unsettled_because=str(q.get("why_not_settled") or "the two sources disagree and neither outranks the other"),
        ask=str(q.get("ask") or ""), default=str(q.get("default") or ""),
        default_from="reconcile/verdict.question: the more cautious reading, because under-resolving a feature "
                     "that is there costs a wrong answer and over-resolving one that is not costs cells",
        teaches=KIND_TEACHES["dispute"], effect=KIND_EFFECT["dispute"], rank=KIND_RANK["dispute"])]


def unseen_openings(document: dict[str, Any], look: dict[str, Any] | None) -> list[Uncertainty]:
    """Measured mouths the look never named. Recorded, and BELOW the budget by default.

    The look's one real failure is a closing clause asserting that what it did not mention is not there, and
    69 per cent of what it misses is plainly visible in the pictures it was given (docs/vision.md). So a miss
    is worth recording. It is not worth a customer's attention: the measurement already has the opening, and
    an answer would confirm something we are not in doubt about. It ranks last and is normally `Unasked`.
    """
    seen = _seen_index(look)
    if look is None:
        return []
    missed = [str(r.get("id")) for r in (document.get("openings") or [])
              if isinstance(r, dict) and str(r.get("id") or "") and str(r.get("id")) not in seen]
    if not missed:
        return []
    return [Uncertainty(
        id="opening_unseen:set", kind="opening_unseen", subject=",".join(missed),
        known={"missed": missed, "measured": len(document.get("openings") or []), "seen": len(seen)},
        unsettled_because="the look did not name these mouths, and its own weakest habit is treating what it "
                          "did not mention as not there",
        ask="", default="the measurement's opening list stands",
        default_from="the measurement, which found them",
        teaches=KIND_TEACHES["opening_unseen"], effect=KIND_EFFECT["opening_unseen"],
        rank=KIND_RANK["opening_unseen"])]


def uncertainties(document: dict[str, Any], look: dict[str, Any] | None = None,
                  declared: dict[str, str] | None = None,
                  reconciliation_question: dict[str, Any] | None = None) -> list[Uncertainty]:
    """Everything the survey could not settle, ranked, on one part.

    `document` is `hexera.report_measured(...)`. `look` is its `look` block or a raw impression. `declared` is
    `{opening_id: role}` for whatever the customer already said. `reconciliation_question` is
    `reconcile.verdict.question(...)` where step 4 has run.
    """
    out: list[Uncertainty] = []
    out += unit_uncertainty(document)
    out += budget_uncertainty(document)
    out += role_uncertainties(document, look, declared)
    out += dispute_uncertainties(reconciliation_question)
    out += unmeasured_openings(document, look)
    out += unseen_openings(document, look)
    out.sort(key=_order)
    return out


def _order(u: Uncertainty) -> tuple[float, float, str]:
    """Rank first, then the measured size, then the id.

    The rank between KINDS is an order with no measurement behind it and is treated as such. Within one kind
    the second key IS measured: a wide mouth carries more flow than a narrow one, so where the budget cuts the
    list it cuts the smallest holes and not whichever id sorts last.
    """
    size = u.known.get("hydraulic_diameter_m") or u.known.get("bore_diameter_m") or 0.0
    return (u.rank, -float(size) if isinstance(size, int | float) else 0.0, u.id)


def questions(uncerts: list[Uncertainty], key: str, limit: int = QUESTION_LIMIT,
              at: str = "") -> tuple[list[Question], list[Uncertainty]]:
    """The questions to ask, and the uncertainties left over.

    Returns `(asked, not_asked)`. An uncertainty with no `ask` text is never asked whatever the budget: that
    is how `opening_unseen` stays a record rather than a question. The leftovers become `Unasked`
    resolutions, which is a different thing from a customer skipping, and the ledger keeps them apart.
    """
    askable = [u for u in uncerts if u.ask]
    asked = askable[:max(0, int(limit))]
    taken = {u.id for u in asked}
    return ([Question(id=question_id(key, u.id), uncertainty_id=u.id, topic=u.kind, ask=u.ask,
                      options=ROLE_OPTIONS if u.kind == "role" else (),
                      default=u.default, default_from=u.default_from, effect=u.effect, asked_at=at)
             for u in asked],
            [u for u in uncerts if u.id not in taken])


__all__ = ["ACCEPT_VOCABULARY", "KIND_EFFECT", "KIND_RANK", "KIND_TEACHES", "QUESTION_LIMIT", "QUESTION_LIMIT_WHY", "ROLE_OPTIONS",
           "budget_uncertainty", "dispute_uncertainties", "questions", "role_uncertainties",
           "UNIT_OPTIONS", "uncertainties", "unit_uncertainty", "unmeasured_openings", "unseen_openings"]
