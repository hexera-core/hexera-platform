"""The chain ledger: one job's whole path through the four agents, in one joinable record.

    SURVEY -> UNCERTAINTY -> INTAKE -> PLAN -> MESH

Read `resolution.py` first. Everything else in this package rests on the one rule it enforces: a default is
not a confirmation, and the two are different types so nothing downstream can confuse them.

Nothing in this package is called from `agent/`, `facts/` or `vision/`. It is off by default and flips no
default.

ONE OF THREE `Uncertainty` TYPES IN THIS TREE (`contract/survey.py`, `ask/schema.py`, `chain/schema.py`), and they
were left separate on purpose when work/complete was integrated: none is on the shipped path, and merging them
means choosing the question budget and when a monitor alert becomes a question, which are defaults. The merged
record is `docs/synthesis.md` appendix B; `docs/integration.md` section 3 says what must survive building it.
"""
from __future__ import annotations

from geometry_agent.chain.resolution import (
    Answered,
    Defaulted,
    DefaultIsNotAnAnswer,
    Stated,
    Unasked,
    Unresolved,
    answer_of,
    is_answer,
)
from geometry_agent.chain.schema import JOB_SCHEMA, JobRecord, Survey, Uncertainty
from geometry_agent.chain.store import JobLedger

__all__ = ["JOB_SCHEMA", "Answered", "DefaultIsNotAnAnswer", "Defaulted", "JobLedger", "JobRecord", "Stated",
           "Survey", "Unasked", "Uncertainty", "Unresolved", "answer_of", "is_answer"]
