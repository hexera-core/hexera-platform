"""Read the job ledger from a terminal: what is in it, what it would recalibrate, what a builder would get.

    python -m geometry_agent.chain.cli floors
    python -m geometry_agent.chain.cli summary   --ledger eval/chain/simulated_jobs.jsonl
    python -m geometry_agent.chain.cli proposals --ledger eval/chain/simulated_jobs.jsonl
    python -m geometry_agent.chain.cli proposals --ledger ... --ratchet eval/chain/ratchet.json --apply
    python -m geometry_agent.chain.cli handover  --ledger ... --key <job key>

`--apply` is the only command that writes, and what it writes is the ratchet state: the demotions, synonyms
and retirements that have cleared their support floor, plus a history line each. It NEVER edits a record, it
never changes a threshold and it never touches `vision/trust.py`. `save_ratchet` refuses any write that would
move the ratchet back, so a run against a smaller ledger cannot un-demote a tier.

A ledger holding both `live` and `simulation` records prints them apart and refuses a pooled headline, and
`proposals` refuses to mix them at all: pass `--provenance` to choose.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from geometry_agent.chain import handover, recalibrate
from geometry_agent.chain.bridge import ACCEPT_VOCABULARY, QUESTION_LIMIT, QUESTION_LIMIT_WHY
from geometry_agent.chain.store import JobLedger


def _records(path: str, provenance: str | None):
    records = list(JobLedger(path).records().values())
    if provenance:
        records = [r for r in records if r.provenance == provenance]
    return records


def cmd_floors() -> int:
    print("SUPPORT FLOORS, derived at import from what this project measured\n")
    print(f"{'rule':<22} {'parts':>6} {'positives':>10}  derived from")
    for rule, need in recalibrate.REQUIRED.items():
        print(f"{rule:<22} {need['parts']:>6} {need['positives']:>10}")
    print()
    print(f"role self-disagreement between three runs   {recalibrate.ROLE_SELF_DISAGREEMENT}")
    print(f"  {recalibrate.ROLE_SELF_DISAGREEMENT_FROM}")
    print(f"question-count flip between three runs      {recalibrate.QUESTION_PATH_FLIP}")
    print(f"  {recalibrate.QUESTION_PATH_FLIP_FROM}")
    print(f"the null a retirement must beat             {recalibrate.RETIREMENT_NULL}")
    print(f"  {recalibrate.RETIREMENT_NULL_FROM}")
    print(f"minimum labelled support                    {recalibrate.MIN_PARTS} / {recalibrate.MIN_POSITIVE}")
    print(f"  {recalibrate.MIN_PARTS_FROM}")
    print(f"smallest p on one draw against one control  {recalibrate.SINGLE_DRAW_P_FLOOR}")
    print("  a threshold move needs four draws, and a job ledger supplies none of them")
    print()
    print(f"question budget                             {QUESTION_LIMIT}")
    print(f"  {QUESTION_LIMIT_WHY}")
    return 0


def cmd_summary(path: str) -> int:
    print(json.dumps(JobLedger(path).summary(), indent=1))
    return 0


def cmd_proposals(path: str, provenance: str | None, ratchet_path: str | None, apply: bool) -> int:
    records = _records(path, provenance)
    if not records:
        print("no records")
        return 1
    provs = {r.provenance for r in records}
    if len(provs) > 1:
        print(f"this ledger holds {sorted(provs)} and they are not pooled. "
              "Pass --provenance to choose one.", file=sys.stderr)
        return 2
    prov = provs.pop()
    if prov != "live":
        print(f"### {prov.upper()}: these records are not customer jobs and nothing below is a measurement "
              "of one.\n")
    # the ratchet state is read BEFORE the proposals, because it says which demotion looks are already spent
    # (C15): without it a second run over the same ledger would read the same look again
    previous = recalibrate.load_ratchet(ratchet_path) if ratchet_path else None
    proposals = recalibrate.all_proposals(records, ACCEPT_VOCABULARY, previous)
    print(f"{len(records)} records, provenance {prov}\n")
    print(f"{'rule':<22} {'subject':<36} {'support':>8} {'parts':>6} {'fam':>4} {'need':>6}  verdict")
    for p in proposals:
        verdict = "JUSTIFIED" if p.justified else f"no: {p.why_not}"
        if p.caveat:
            verdict += "  [one family only]"
        print(f"{p.rule:<22} {p.subject:<36} {p.positives:>8} {p.distinct_parts:>6} "
              f"{p.distinct_families:>4} {p.required_positives:>6}  {verdict}")
    if not apply:
        return 0
    if ratchet_path is None:
        print("--apply needs --ratchet", file=sys.stderr)
        return 2
    previous = previous if previous is not None else recalibrate.load_ratchet(ratchet_path)
    state = recalibrate.apply_ratchet(previous, proposals)
    recalibrate.save_ratchet(ratchet_path, state, previous=previous)
    moved = len(state["history"]) - len(previous.get("history") or [])
    print(f"\nratchet written to {ratchet_path}: {moved} new entries, "
          f"{len(state['demoted'])} demoted, {sum(len(v) for v in state['synonyms'].values())} synonyms, "
          f"{len(state['retired'])} retired, {len(state['proposed'])} proposed and not applied")
    return 0


def cmd_handover(path: str, key: str) -> int:
    records = JobLedger(path).records()
    record = records.get(key)
    if record is None:
        print(f"no record {key!r}. Keys look like: "
              + ", ".join(sorted(records)[:3]), file=sys.stderr)
        return 1
    print(handover.write_up(record))
    print()
    print(json.dumps(handover.builder_handover(record), indent=1, default=str))
    return 0


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="geometry_agent.chain.cli", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("floors")
    for name in ("summary", "proposals", "handover"):
        p = sub.add_parser(name)
        p.add_argument("--ledger", required=True, type=str)
        if name == "proposals":
            p.add_argument("--provenance", default=None, choices=["live", "simulation", "heuristic"])
            p.add_argument("--ratchet", default=None, type=str)
            p.add_argument("--apply", action="store_true")
        if name == "handover":
            p.add_argument("--key", required=True, type=str)
    args = ap.parse_args(argv)
    if args.cmd == "floors":
        return cmd_floors()
    if not Path(args.ledger).exists():
        print(f"no ledger at {args.ledger}", file=sys.stderr)
        return 1
    if args.cmd == "summary":
        return cmd_summary(args.ledger)
    if args.cmd == "proposals":
        return cmd_proposals(args.ledger, args.provenance, args.ratchet, args.apply)
    return cmd_handover(args.ledger, args.key)


if __name__ == "__main__":
    raise SystemExit(main())
