"""A DEFAULT IS NOT A CONFIRMATION, enforced by type and not by convention.

WHY THIS FILE IS ONE FILE AND NOT A FIELD ON A RECORD. This package exists so that jobs teach us something.
The only thing a job can teach us is what a customer actually said. If a skipped question is stored in the
same shape as an answered one, with a `value` and a flag beside it, then every consumer that forgets to read
the flag learns our own guess back. That is the identity-override fault arriving at system scale: the identity
file could only ever flatter the arm it was written from because the thing being scored and the thing doing
the scoring were the same object. A ledger that stores defaults as answers scores our defaults against our
defaults and reports agreement.

So there is no flag. There are five types, they share no attribute that carries an answer, and the one
accessor the learning path may use takes `Answered` and nothing else.

    Answered    the customer was asked and replied. THE ONLY ONE THAT TEACHES. `.value` lives here and
                nowhere else in this module.
    Defaulted   the customer was asked and did not reply, so our default stands. `.assumed`, never `.value`.
    Stated      the brief already said it and nobody was asked. `.brief_value`. It is not an answer: this
                project already ruled at P4.4 that a brief naming a question's subject does not answer it
                (docs/learning_loop.md 9.3). It may widen a vocabulary, because it is the customer's own
                words, and it may do nothing else.
    Unasked     the survey raised it and we never put it to the customer, because the question budget was
                spent or because an answer would have had nowhere to go. `.assumed`. Distinct from
                `Defaulted`: a customer who skipped a question saw it, and one who was never shown it did
                not, and only the first is weak evidence that the subject did not matter to them.
    Unresolved  asked, still open when this record was written. Carries no value at all.

THE TWO LOCKS, because one is a convention.

  1. THE ATTRIBUTE NAME. Only `Answered` has `.value`. The other four raise `DefaultIsNotAnAnswer` on it, and
     that exception is deliberately NOT an `AttributeError`, so `getattr(r, "value", None)` raises instead of
     quietly handing back `None` and letting a caller treat a default as a missing answer.
  2. THE WIRE TAG. `to_json` writes `resolution`, `from_json` refuses a payload with no tag or an unknown
     one, and each type's payload key differs, so hand-editing a stored `defaulted` to say `answered` fails
     on the missing `value` rather than producing a fabricated confirmation.

`tests/test_chain_resolution.py` pins both locks and pins that no new type may be added without an entry in
`RESOLUTION_TYPES` and a payload key of its own.
"""
from __future__ import annotations

from dataclasses import dataclass, fields
from datetime import UTC, datetime
from typing import Any

RESOLUTION_SCHEMA = "geometry_agent.chain.resolution.v1"

ANSWERED = "answered"
DEFAULTED = "defaulted"
STATED = "stated"
UNASKED = "unasked"
UNRESOLVED = "unresolved"
RESOLUTIONS = (ANSWERED, DEFAULTED, STATED, UNASKED, UNRESOLVED)

#: What each word means to a consumer, carried in the record so a reader never has to have read this file.
RESOLUTION_MEANING = {
    ANSWERED: "the customer was asked and replied: ground truth on this part, and the only kind that teaches",
    DEFAULTED: "the customer was asked and did not reply: our own guess stands, and it teaches nothing",
    STATED: "the brief said it and nobody was asked: the customer's words, not the customer's confirmation",
    UNASKED: "we raised it and never asked: our own guess stands, and the customer never saw the question",
    UNRESOLVED: "asked and still open: no value of any kind",
}

#: The attribute names that mean "somebody confirmed this". Reading one off anything but an `Answered` is the
#: mistake this module exists to make impossible, so it raises rather than returning None.
ANSWER_ONLY_ATTRS = frozenset({"value", "answer", "answered_value", "answered_by", "verbatim", "confirmed"})


class DefaultIsNotAnAnswer(Exception):
    """Raised when something that is not an `Answered` is read as though it were.

    NOT an `AttributeError` on purpose. `getattr(obj, "value", None)` swallows `AttributeError` and hands the
    caller `None`, which is how a default becomes a missing answer becomes, three functions later, a label.
    """


class _NotAnAnswer:
    """The four non-answers. Shares no field with `Answered`; supplies the guard and nothing else."""

    __slots__ = ()

    def __getattr__(self, name: str) -> Any:
        if name in ANSWER_ONLY_ATTRS:
            raise DefaultIsNotAnAnswer(
                f"{type(self).__name__} has no {name!r}: this is a {getattr(type(self), 'resolution', '?')}, "
                "not an answer. A default is not a confirmation. If you want what we assumed, read the field "
                "that says so; if you want what the customer said, there is nothing here to read.")
        raise AttributeError(name)


@dataclass(frozen=True, slots=True)
class Answered:
    """The customer was asked and replied. The only resolution the learning path may read."""

    resolution = ANSWERED
    field: str
    value: str
    question_id: str
    #: Who replied. A record whose answer came from an operator resolving a monitor alert is still an answer,
    #: and saying which is how a later pass can weight them differently without guessing.
    answered_by: str = "customer"
    #: What they actually typed, kept unnormalised. This is the only place a word we have no slot for can
    #: survive, and it is what the vocabulary rule reads.
    verbatim: str = ""
    at: str = ""

    def __post_init__(self) -> None:
        if not str(self.field) or not str(self.value):
            raise ValueError("an Answered needs a field and a value: an empty answer is an Unresolved")


@dataclass(frozen=True, slots=True)
class Defaulted(_NotAnAnswer):
    """Asked, skipped, our default applied."""

    resolution = DEFAULTED
    field: str
    #: NOT `value`. See the module docstring.
    assumed: str
    question_id: str
    #: Where the default came from, so a later reader can tell our catalog's fallback from a rule's own.
    default_from: str = ""
    at: str = ""


@dataclass(frozen=True, slots=True)
class Stated(_NotAnAnswer):
    """The brief already said it. Nobody was asked, so nobody confirmed."""

    resolution = STATED
    field: str
    brief_value: str
    #: The sentence it was read out of, so a human can check the reading.
    quote: str = ""
    at: str = ""


@dataclass(frozen=True, slots=True)
class Unasked(_NotAnAnswer):
    """Raised by the survey and never put to the customer."""

    resolution = UNASKED
    field: str
    assumed: str
    #: `budget` when the question list was already full, `no_home` when an answer would change nothing that is
    #: allowed to act on it (reconcile/verdict.py's whitelist argument), `policy` when a rule forbade asking.
    why_not_asked: str = ""
    default_from: str = ""
    at: str = ""


@dataclass(frozen=True, slots=True)
class Unresolved(_NotAnAnswer):
    """Asked and still open. Carries no value of any kind, assumed or otherwise."""

    resolution = UNRESOLVED
    field: str
    question_id: str
    at: str = ""


Resolution = Answered | Defaulted | Stated | Unasked | Unresolved

RESOLUTION_TYPES: dict[str, type] = {
    ANSWERED: Answered,
    DEFAULTED: Defaulted,
    STATED: Stated,
    UNASKED: Unasked,
    UNRESOLVED: Unresolved,
}

#: The payload key that carries each type's value, and it differs per type on purpose: a stored `defaulted`
#: relabelled `answered` by hand fails to load because it has no `value`.
VALUE_KEY: dict[str, str | None] = {
    ANSWERED: "value",
    DEFAULTED: "assumed",
    STATED: "brief_value",
    UNASKED: "assumed",
    UNRESOLVED: None,
}


def now() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")


def is_answer(r: Any) -> bool:
    """True only for `Answered`. Every branch that decides whether something teaches goes through here."""
    return isinstance(r, Answered)


def answer_of(r: Any) -> str:
    """THE ONLY ACCESSOR THE LEARNING PATH MAY USE.

    Takes an `Answered` and returns what the customer said. Raises `DefaultIsNotAnAnswer` on anything else,
    including a raw dict, because a dict is how a default gets in.
    """
    if isinstance(r, Answered):
        return r.value
    kind = getattr(type(r), "resolution", None) or type(r).__name__
    raise DefaultIsNotAnAnswer(
        f"answer_of() was handed a {kind}. Only an Answered teaches. If you are counting what we assumed, "
        "call assumed_of(); if you are counting how often we had to assume, call is_answer() and count the "
        "False side.")


def assumed_of(r: Any) -> str:
    """What we assumed, for the two types that assume. Never an answer, and it says so by its name."""
    if isinstance(r, Defaulted | Unasked):
        return r.assumed
    raise TypeError(f"assumed_of() takes a Defaulted or an Unasked, not {type(r).__name__}")


def stated_of(r: Any) -> str:
    """What the brief said. Feeds the vocabulary rule and nothing else."""
    if isinstance(r, Stated):
        return r.brief_value
    raise TypeError(f"stated_of() takes a Stated, not {type(r).__name__}")


def effective_value(r: Resolution) -> str | None:
    """What the pipeline ACTS on, which is not the same question as what it may learn from.

    The builder has to be told something whether or not anybody confirmed it. This is that something, and it
    is a separate function from `answer_of` for exactly that reason: acting on a default is correct, learning
    from one is not.
    """
    if isinstance(r, Answered):
        return r.value
    if isinstance(r, Defaulted | Unasked):
        return r.assumed
    if isinstance(r, Stated):
        return r.brief_value
    return None


def to_json(r: Resolution) -> dict[str, Any]:
    """The wire form. The tag is written first and always."""
    kind = getattr(type(r), "resolution", None)
    if kind not in RESOLUTION_TYPES:
        raise TypeError(f"{type(r).__name__} is not a resolution type")
    out: dict[str, Any] = {"resolution": kind}
    for f in fields(r):  # type: ignore[arg-type]
        out[f.name] = getattr(r, f.name)
    return out


def from_json(payload: Any) -> Resolution:
    """The wire form back, with the tag believed only as far as the payload supports it.

    Two refusals, and both are the point of the file:
      - no `resolution` key, or one that is not in `RESOLUTION_TYPES`: refused. There is no default tag,
        because a default tag would be `answered` for whoever wrote the first caller.
      - a tag whose own value key is absent: refused. That is what stops a stored default from being
        promoted to an answer by editing one string.
    """
    if not isinstance(payload, dict):
        raise ValueError("a resolution is a dict with a 'resolution' tag")
    kind = payload.get("resolution")
    if kind not in RESOLUTION_TYPES:
        raise ValueError(f"unknown or missing resolution tag {kind!r}: one of {RESOLUTIONS} is required, and "
                         "there is no default because the default would be 'answered'")
    cls = RESOLUTION_TYPES[kind]
    key = VALUE_KEY[kind]
    if key is not None and not payload.get(key):
        raise ValueError(f"a {kind!r} resolution carries its value in {key!r} and this payload has none: "
                         "a relabelled record is not a confirmation")
    names = {f.name for f in fields(cls)}  # type: ignore[arg-type]
    extra = set(payload) - names - {"resolution"}
    if extra:
        raise ValueError(f"a {kind!r} resolution has no field(s) {sorted(extra)}: refusing rather than "
                         "dropping them, because the field being dropped could be the one that says this is "
                         "not an answer")
    return cls(**{k: v for k, v in payload.items() if k in names})  # type: ignore[return-value]


def tally(resolutions: list[Resolution]) -> dict[str, int]:
    """How many of each, by tag. The headline number of any ledger report is `answered` against the rest."""
    out = dict.fromkeys(RESOLUTIONS, 0)
    for r in resolutions:
        kind = getattr(type(r), "resolution", None)
        if kind in out:
            out[kind] += 1
    return out


__all__ = ["ANSWERED", "ANSWER_ONLY_ATTRS", "DEFAULTED", "RESOLUTIONS", "RESOLUTION_MEANING",
           "RESOLUTION_SCHEMA", "RESOLUTION_TYPES", "STATED", "UNASKED", "UNRESOLVED", "VALUE_KEY",
           "Answered", "DefaultIsNotAnAnswer", "Defaulted", "Resolution", "Stated", "Unasked", "Unresolved",
           "answer_of", "assumed_of", "effective_value", "from_json", "is_answer", "now", "stated_of",
           "tally", "to_json"]
