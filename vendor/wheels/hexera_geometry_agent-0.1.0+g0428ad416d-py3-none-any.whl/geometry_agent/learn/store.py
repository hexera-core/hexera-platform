"""Where the learning loop's files live, and the few readers every module shares.

The split file names the locked cases; a record's file name carries its case name, so a module can list the
learning records without opening a locked one. The facts cache is read directly by its key and never written:
a miss is an error here, not a measurement, so the loop can run beside a live evaluation without touching its
cache directory.
"""
from __future__ import annotations

import hashlib
import json
import os
from functools import lru_cache
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[3]
EVAL = ROOT / "eval"
OUTCOMES_DIR = EVAL / "outcomes"
LEDGER = EVAL / "ledger.jsonl"
LEDGER_LOCKED = EVAL / "ledger_locked.jsonl"
SPLIT_FILE = EVAL / "split" / "export_split.json"
LABELS_JSON = EVAL / "labels" / "export_labels.json"
KIND_LABELS = EVAL / "learn" / "kind_labels.json"
CALIB_DIR = EVAL / "calib"
SWEEPS_DIR = CALIB_DIR / "sweeps"
FEATURES_CSV = CALIB_DIR / "features.csv"
FEATURES_LOCKED_CSV = CALIB_DIR / "features_locked.csv"
CELL_CORRECTION = CALIB_DIR / "cell_correction.json"
MINUTES_BINS = CALIB_DIR / "minutes_bins.json"
RULE_CARDS_JSON = EVAL / "rule_cards.json"
RULE_CARDS_MD = ROOT / "docs" / "rule_cards.md"
THRESHOLDS_JSON = ROOT / "src" / "geometry_agent" / "agent" / "thresholds.json"
CASES_DIR = EVAL / "corpus_export_cases"
#: The facts cache the export corpus was measured into. Overridable so a test never touches it.
DEFAULT_CACHE_DIR = Path(os.environ.get("GEOMETRY_AGENT_LEARN_CACHE_DIR", str(ROOT.parent / "geometry_agent" / ".facts_cache_export2")))


def read_json(path: Path) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path: Path, doc: Any) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(doc, indent=1, sort_keys=False) + "\n", encoding="utf-8")
    return path


def read_split(split_file: Path = SPLIT_FILE) -> dict[str, Any]:
    """The frozen split, or an empty one when none exists yet (every record is then unassigned)."""
    p = Path(split_file)
    if not p.exists():
        return {"learning": [], "locked": [], "group_of": {}, "sha256": None}
    return read_json(p)


def split_side(case: str, split: dict[str, Any]) -> str | None:
    if case in set(split.get("locked", [])):
        return "locked"
    if case in set(split.get("learning", [])):
        return "learning"
    return None


def locked_groups(split: dict[str, Any]) -> set[str]:
    group_of = split.get("group_of", {})
    return {group_of.get(n, n) for n in split.get("locked", [])}


def case_of_record_path(path: Path) -> str:
    """`<facts_sha[:12]>__<family>__<case>.json` -> `<family>__<case>`."""
    stem = Path(path).stem
    return stem.split("__", 1)[1] if "__" in stem else stem


def record_paths(outcomes_dir: Path = OUTCOMES_DIR, split_file: Path = SPLIT_FILE, side: str = "learning") -> list[Path]:
    """Record files on one side of the split, chosen by file name alone so no locked record is ever opened to
    find out that it is locked. `side` is learning, locked, or all."""
    d = Path(outcomes_dir)
    if not d.is_dir():
        return []
    split = read_split(split_file)
    locked = set(split.get("locked", []))
    learning = set(split.get("learning", []))
    out = []
    for p in sorted(d.glob("*.json")):
        case = case_of_record_path(p)
        if side == "all":
            out.append(p)
        elif side == "locked" and case in locked:
            out.append(p)
        elif side == "learning" and case in learning:
            out.append(p)
    return out


def labels_by_case(labels_json: Path = LABELS_JSON) -> dict[str, dict[str, Any]]:
    doc = read_json(labels_json)
    return {r["case"]: r for r in doc["cases"]}


def labels_meta(labels_json: Path = LABELS_JSON) -> dict[str, Any]:
    doc = read_json(labels_json)
    return {"label_version": doc.get("label_version"), "definition": doc.get("definition"), "counts": doc.get("counts")}


@lru_cache(maxsize=4096)
def file_sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def facts_cache_path(source: str | Path, purpose: str, cache_dir: str | Path) -> Path:
    from geometry_agent.facts.schema import FACTS_SCHEMA_VERSION
    return Path(cache_dir) / f"{file_sha256(str(source))}.{purpose}.v{FACTS_SCHEMA_VERSION}.json"


class FactsCacheMiss(FileNotFoundError):
    """The cache holds no measurement for this file and purpose. The loop never measures: measuring writes a
    cache file, and the cache may belong to a live run in another checkout."""


def cached_facts(source: str | Path, purpose: str, cache_dir: str | Path):
    """GeometryFacts from the cache by content hash, read-only."""
    from geometry_agent.facts.measure import read_cached
    p = facts_cache_path(source, purpose, cache_dir)
    if not p.exists():
        raise FactsCacheMiss(f"no cached facts for {Path(source).name} ({purpose}) under {cache_dir}")
    # the learning half replays against a fixed cache on purpose; a stale revision is kept and said once
    return read_cached(p, reader="learn.store")[0]


def facts_sha256(facts) -> str:
    """The identity of one measurement: sha256 of its canonical JSON (timings excluded, they differ per run)."""
    doc = facts.model_dump(mode="json")
    doc.pop("timings", None)
    return hashlib.sha256(json.dumps(doc, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()


def load_eval_script(relpath: str):
    """A script under eval/ (the sweep, the minutes bins) as a module, by path: they live beside their outputs
    and are not part of the package."""
    import importlib.util
    p = ROOT / relpath
    spec = importlib.util.spec_from_file_location(p.stem, p)
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    p = Path(path)
    if not p.exists():
        return []
    rows = []
    with p.open(encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> Path:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("w", encoding="utf-8") as fh:
        for r in rows:
            fh.write(json.dumps(r, sort_keys=True) + "\n")
    return p
