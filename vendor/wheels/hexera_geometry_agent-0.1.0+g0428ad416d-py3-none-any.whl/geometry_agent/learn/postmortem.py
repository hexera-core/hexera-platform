"""The post-mortem: every warning a record carries, and every warning the feature bank says could have fired,
scored by audience against what happened (docs/dev_plan.md, P2).

Builder warnings are scored against the label component eval/learn/kind_labels.json names for their kind.
User warnings are never scored on a mesh label: only the deterministic false-alarm scorer (the brief already
settles the subject) and recorded corrections can judge them. Verdicts:

    hit          fired and the component is true; grade A at the named patch (the worst patch is among the
                 warning's patches), grade B at case level. Until worst patches exist every hit is grade B.
    miss         the component is true and the kind did not fire: `silent` when a bank feature is past a
                 candidate cutoff at that location (the rule exists but was not given), `unexplained` otherwise.
    false_alarm  fired, the component is false, and nothing acted on it (dropped or absent).
    acted        fired, acted on by the builder, and clean: never a false alarm.
    untestable   no label for the component, outside the kind's stratum, or a user warning with no correction.
    clean        the kind did not fire and the component is false (a true negative; counted, never a card line).

Where no agent ran (the corpus export) the catalog is run on the cached facts with the declared ports and the
brief, and every row is stamped policy `heuristic` with `stand_in: true`, so an aggregator can refuse it. Rows
for learning records go to eval/ledger.jsonl, rows for locked records to eval/ledger_locked.jsonl, and a record
on neither side (blind, dose, unassigned) is counted and skipped.
"""
from __future__ import annotations

import re
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from geometry_agent.agent import catalog, grounding
from geometry_agent.learn import features, store
from geometry_agent.learn.schema import AgentWarning, OutcomeRecord

#: The catalog constant each kind's threshold reads; the card shows thresholds.json's value in force when the
#: key exists there, else the module constant.
KIND_THRESHOLD_KEY: dict[str, str] = {
    "short_stub": "STUB_OK_OVER_D", "short_inlet_run": "STUB_OK_OVER_D", "inlet_run_developing": "INLET_DEVELOPED_OVER_D",
    "tiny_port": "TINY_PORT_FRACTION", "port_resolution": "PORT_CELLS_MIN", "gap_resolution": "GAP_CELLS_MIN",
    "near_touching": "GAP_CELLS_MIN", "thin_feature": "THIN_CELLS_MIN", "velocity_spread": "VELOCITY_RATIO_MAX",
    "diffuser_angle": "DIFFUSER_ANGLE_MAX_DEG", "role_assumed": "SAME_BORE_BAND", "non_manifold_surface": "NON_MANIFOLD_EDGES_MIN",
    "rotor_topology": "ROTOR_MIN_BLADES", "declared_port_unmatched": "AREA_MATCH_BAND", "ambiguous_openings": "MANY_CANDIDATES",
    "tilted_circular_mouth": "GRID_ALIGNED_TILT_DEG", "budget_forecast": "BUDGET_FORECAST_OVER_CAP",
    "gmsh_size": "GMSH_ELEMENTS_ACROSS_MIN",
}
#: Candidate cutoffs the bank fires at (the dev plan's starting points; the sweep decides what they become).
BANK_CUTOFFS: dict[str, float] = {
    "GRID_ALIGNED_TILT_DEG": features.GRID_ALIGNED_TILT_DEG,
    "BUDGET_FORECAST_OVER_CAP": 1.0,
    "GMSH_ELEMENTS_ACROSS_MIN": 3.0,
    "PORT_CELLS_MIN": float(getattr(catalog, "PORT_CELLS_MIN", 8.0)),
    "GAP_CELLS_MIN": float(getattr(catalog, "GAP_CELLS_MIN", 3.0)),
}
#: Measurement keys that name where a catalog risk is.
LOCATION_KEYS = ("opening_id", "ring_ids", "hole_ids", "cluster_id", "wide_id", "narrow_id", "inlet_ids", "outlet_ids", "ids")
#: The high-precision false-alarm patterns (dev plan P4.2, checker R9): a question the brief already ANSWERS. Read
#: from the checker rather than retyped: three hand-typed copies of this table (here, R9 and the scorer) are what
#: let "fixed pressure outlet" stand as a short-stub answer until P4.4, and the ledger's verdict must be the same
#: reading the checker acts on. The instrument that audits the rule is the one copy that stays independent
#: (eval/live/question_scorer.py).
BRIEF_SETTLES: dict[str, re.Pattern[str]] = dict(grounding.R9_SETTLES)
UNIT_IN_BRIEF = re.compile(r"\d+(?:\.\d+)?\s*(?:mm|millimet(?:re|er)s?|cm|m\b|met(?:re|er)s?|in\b|inch(?:es)?|ft|feet|foot)", re.I)


def threshold_value(key: str | None) -> float | None:
    """The value in force for a threshold key: thresholds.json when it carries the key, else the catalog
    constant, else the bank's candidate cutoff."""
    if not key:
        return None
    if store.THRESHOLDS_JSON.exists():
        try:
            table = store.read_json(store.THRESHOLDS_JSON)
            entry = table.get(key)
            if isinstance(entry, dict) and "value" in entry:
                return float(entry["value"])
        except (OSError, ValueError):
            pass
    if hasattr(catalog, key):
        return float(getattr(catalog, key))
    return BANK_CUTOFFS.get(key)


def read_kind_labels(path: Path = store.KIND_LABELS) -> dict[str, Any]:
    return store.read_json(path)


def _ids(measurement: dict[str, Any]) -> list[str]:
    out: list[str] = []
    for k in LOCATION_KEYS:
        v = measurement.get(k)
        if isinstance(v, str):
            out.append(v)
        elif isinstance(v, list):
            out.extend(str(x) for x in v if isinstance(x, str))
    return out


def _scalars(measurement: dict[str, Any]) -> dict[str, Any]:
    return {k: v for k, v in measurement.items() if isinstance(v, int | float | str | bool) or v is None}


def catalog_warnings(facts, record: OutcomeRecord, kinds: dict[str, Any]) -> list[AgentWarning]:
    """The stand-in: the catalog on the cached facts with the record's declared ports and brief."""
    g = record.geometry
    risks = catalog.detect_risks(facts, g.purpose, "standard", cell_cap=g.cell_cap, declared=g.declared or None,  # type: ignore[arg-type]
                                 brief=record.intake.brief)
    out = []
    for r in risks:
        spec = kinds.get(r.kind, {})
        out.append(AgentWarning(kind=r.kind, audience=spec.get("audience", "user"), severity=r.severity,
                                threshold_key=KIND_THRESHOLD_KEY.get(r.kind), measurement=_scalars(r.measurement),
                                location=_ids(r.measurement), requires_user_decision=r.requires_user_decision))
    return out


def bank_candidates(bank: dict[str, Any], record: OutcomeRecord) -> dict[str, dict[str, Any]]:
    """kind -> {location, measurement} for every candidate rule the bank says could have fired."""
    case = bank["case"]
    ports = bank["ports"]
    out: dict[str, dict[str, Any]] = {}
    rep, eng = record.geometry.representation, record.geometry.engine
    tilted = [p for p in ports if p["shape"] == "circle" and not p["grid_aligned"]]
    if rep == "carve" and eng == "snappy" and tilted:
        out["tilted_circular_mouth"] = {"location": [p["port_id"] for p in tilted],
                                        "measurement": {"max_tilt_circular_deg": case["max_tilt_circular_deg"], "n_tilted_circular": len(tilted),
                                                        "cutoff": BANK_CUTOFFS["GRID_ALIGNED_TILT_DEG"]}}
    ref = case.get("refined_estimate_over_cap")
    if ref is not None and ref > BANK_CUTOFFS["BUDGET_FORECAST_OVER_CAP"]:
        out["budget_forecast"] = {"location": [], "measurement": {"refined_estimate_over_cap": ref, "tier_estimate_over_cap": case["tier_estimate_over_cap"],
                                                                    "cell_correction": case["cell_correction"], "min_bore_over_extent": case["min_bore_over_extent"],
                                                                    "min_bore_in_band": case["min_bore_in_band"], "cutoff": BANK_CUTOFFS["BUDGET_FORECAST_OVER_CAP"]}}
    c24 = case.get("smallest_port_cells_across_24")
    if c24 is not None and c24 < BANK_CUTOFFS["PORT_CELLS_MIN"]:
        out["port_resolution"] = {"location": [case["smallest_port_id"]], "measurement": {"smallest_port_cells_across_24": c24, "frame": "builder",
                                                                                          "cutoff": BANK_CUTOFFS["PORT_CELLS_MIN"]}}
    gap = case.get("gap_over_wall_cell")
    if gap is not None and gap < BANK_CUTOFFS["GAP_CELLS_MIN"]:
        out["gap_resolution"] = {"location": [], "measurement": {"gap_over_wall_cell": gap, "frame": "builder", "cutoff": BANK_CUTOFFS["GAP_CELLS_MIN"]}}
    gm = case.get("gmsh_default_elements_across_smallest_port")
    if eng == "gmsh" and gm is not None and gm < BANK_CUTOFFS["GMSH_ELEMENTS_ACROSS_MIN"]:
        out["gmsh_size"] = {"location": [case["smallest_port_id"]], "measurement": {"gmsh_default_elements_across_smallest_port": gm,
                                                                                    "cutoff": BANK_CUTOFFS["GMSH_ELEMENTS_ACROSS_MIN"]}}
    return out


def in_stratum(spec: dict[str, Any], record: OutcomeRecord) -> bool:
    s = spec.get("stratum") or {}
    g = record.geometry
    return all(getattr(g, k, None) == v for k, v in s.items())


def worst_patch_of(record: OutcomeRecord) -> str | None:
    for a in reversed(record.builder.attempts):
        if a.quality.worst_patch:
            return a.quality.worst_patch
    return None


def acted_on(record: OutcomeRecord, kind: str) -> bool:
    """Evidence the builder acted on a warning: an attempt whose fidelity block names the kind. Never true in
    the export; the harness ingester fills fidelity."""
    return any(bool(a.fidelity.get(kind)) for a in record.builder.attempts)


def brief_settles(warning: AgentWarning, record: OutcomeRecord) -> str | None:
    """The brief phrase that ANSWERS a user warning's question, or None. P4.4: a phrase that names the question's
    subject is not an answer to it, so the short-run kinds are settled only by a brief that declines a geometry
    change; the kind is read through the stub set so short_inlet_run and inlet_run_developing are judged like
    short_stub, as the checker judges them."""
    brief = record.intake.brief or ""
    kind = "short_stub" if warning.kind in grounding.STUB_QUESTION_KINDS else warning.kind
    pat = BRIEF_SETTLES.get(kind)
    if pat:
        m = pat.search(brief)
        if m:
            return m.group(0)
    if warning.kind == "unit_unknown":
        m = UNIT_IN_BRIEF.search(brief)
        if m:
            return m.group(0)
    if warning.kind in ("role_assumed", "ambiguous_openings") and record.geometry.declared:
        return "declared ports"
    return None


def _label(record: OutcomeRecord, component: str | None):
    if not component:
        return None
    return getattr(record.labels, component, None)


def _grade(warning_location: list[str], port_names: dict[str, str], worst_patch: str | None) -> str:
    if worst_patch and any(port_names.get(i) == worst_patch or i == worst_patch for i in warning_location):
        return "A"
    return "B"


def score_record(record: OutcomeRecord, facts, kind_labels: dict[str, Any], bank: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    """Every ledger row for one record."""
    kinds: dict[str, Any] = kind_labels.get("kinds", {})
    if bank is None:
        ctx = features.CaseContext(case=record.geometry.case, purpose=record.geometry.purpose, brief=record.intake.brief,
                                   declared=record.geometry.declared, representation=record.geometry.representation,
                                   engine=record.geometry.engine, cell_cap=record.geometry.cell_cap, family=record.geometry.family)
        bank = features.compute(facts, ctx)
    port_names = {p["port_id"]: p["name"] for p in bank["ports"] if p.get("name")}
    if record.agent.present:
        given = list(record.agent.warnings)
        policy, stand_in = record.agent.policy, False
    else:
        given = catalog_warnings(facts, record, kinds)
        policy, stand_in = "heuristic", True
    candidates = bank_candidates(bank, record)
    worst = worst_patch_of(record)
    base = {
        "date": datetime.now(UTC).date().isoformat(), "job_key": record.job_key, "case": record.geometry.case,
        "family": record.geometry.family, "group": record.geometry.group, "split": record.split, "source": record.source,
        "representation": record.geometry.representation, "engine": record.geometry.engine, "policy": policy,
        "stand_in": stand_in, "features_hash": bank["case"]["features_hash"], "features_version": bank["case"]["features_version"],
        "label_version": record.labels.label_version, "split_sha256": record.split_sha256,
        "prompt_sha256": record.agent.prompt_sha256, "thresholds_sha256": record.agent.thresholds_sha256,
        "platform_revision": record.builder.platform_revision, "kind_labels_version": kind_labels.get("version"),
    }
    rows: list[dict[str, Any]] = []
    fired_kinds: dict[str, list[AgentWarning]] = {}
    for w in given:
        fired_kinds.setdefault(w.kind, []).append(w)

    # builder kinds: one row per kind in the map, fired or not, inside the stratum; fired ones outside it too
    for kind, spec in kinds.items():
        if spec.get("audience") != "builder":
            continue
        fired = fired_kinds.get(kind, [])
        inside = in_stratum(spec, record)
        if not fired and not inside:
            continue
        component = spec.get("component")
        value = _label(record, component)
        cand = candidates.get(kind)
        loc = sorted({i for w in fired for i in w.location})
        row = {**base, "kind": kind, "audience": "builder", "component": component, "component_value": value,
               "in_stratum": inside, "fired": bool(fired), "fired_by": ("agent" if record.agent.present else "catalog") if fired else None,
               "location": loc, "measurement": (fired[0].measurement if fired else {}),
               "threshold_key": (fired[0].threshold_key or KIND_THRESHOLD_KEY.get(kind)) if fired else KIND_THRESHOLD_KEY.get(kind),
               "bank_fired": cand is not None, "bank_location": cand["location"] if cand else [],
               "bank_measurement": cand["measurement"] if cand else {}, "grade": None, "miss_kind": None}
        row["threshold_value"] = threshold_value(row["threshold_key"])
        if not inside:
            row.update(verdict="untestable", reason=f"outside the kind's stratum {spec.get('stratum')}")
        elif value is None:
            row.update(verdict="untestable", reason=f"no label for {component} on this case")
        elif fired and value:
            row.update(verdict="hit", grade=_grade(loc, port_names, worst),
                       reason="fired and the component is true" + ("" if worst else "; grade B: no worst patch recorded yet"))
        elif fired and not value:
            if acted_on(record, kind):
                row.update(verdict="acted", reason="fired, the builder acted on it, and the mesh is clean")
            else:
                row.update(verdict="false_alarm", reason="fired, the component is false, nothing acted on it")
        elif value:
            silent = cand is not None
            row.update(verdict="miss", miss_kind="silent" if silent else "unexplained",
                       reason=("a bank feature is past the candidate cutoff at that location" if silent
                               else "no bank feature past a candidate cutoff"))
        else:
            row.update(verdict="clean", reason="did not fire and the component is false")
        rows.append(row)

    # user and note kinds: one row per fired warning
    for w in given:
        spec = kinds.get(w.kind, {})
        audience = spec.get("audience", w.audience or "user")
        if audience == "builder":
            continue
        row = {**base, "kind": w.kind, "audience": audience, "component": None, "component_value": None, "in_stratum": True,
               "fired": True, "fired_by": "agent" if record.agent.present else "catalog", "location": list(w.location),
               "measurement": w.measurement, "threshold_key": w.threshold_key or KIND_THRESHOLD_KEY.get(w.kind),
               "bank_fired": False, "bank_location": [], "bank_measurement": {}, "grade": None, "miss_kind": None,
               "severity": w.severity, "requires_user_decision": w.requires_user_decision}
        row["threshold_value"] = threshold_value(row["threshold_key"])
        phrase = brief_settles(w, record) if w.requires_user_decision else None
        if phrase:
            row.update(verdict="false_alarm", reason=f"the brief already settles it: {phrase!r}")
        elif acted_on(record, w.kind):
            row.update(verdict="acted", reason="a recorded correction accepted it")
        elif not w.requires_user_decision:
            row.update(verdict="untestable", reason="advisory: no decision asked, no correction recorded")
        else:
            row.update(verdict="untestable", reason="no user answer recorded; never scored on a mesh label")
        rows.append(row)
    return rows


def _merge(existing: list[dict[str, Any]], new_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Rows for a re-scored job replace the old ones; every other job's rows stay."""
    replaced = {r["job_key"] for r in new_rows}
    kept = [r for r in existing if r.get("job_key") not in replaced]
    out = kept + new_rows
    out.sort(key=lambda r: (str(r.get("case")), str(r.get("kind")), str(r.get("job_key"))))
    return out


def run(outcomes_dir: Path = store.OUTCOMES_DIR, split_file: Path = store.SPLIT_FILE, cache_dir: Path = store.DEFAULT_CACHE_DIR,
        kind_labels_path: Path = store.KIND_LABELS, ledger: Path = store.LEDGER, ledger_locked: Path = store.LEDGER_LOCKED,
        sides: tuple[str, ...] = ("learning", "locked")) -> dict[str, Any]:
    """Score every record on the given sides and rewrite the two ledgers. Learning rows never touch the locked
    ledger and locked rows never touch the learning one."""
    kind_labels = read_kind_labels(kind_labels_path)
    summary: dict[str, Any] = {"sides": {}, "skipped": Counter(), "missing_facts": []}
    for side in sides:
        target = ledger if side == "learning" else ledger_locked
        new_rows: list[dict[str, Any]] = []
        verdicts: Counter = Counter()
        n = 0
        for p in store.record_paths(outcomes_dir, split_file, side):
            record = OutcomeRecord.model_validate_json(p.read_text(encoding="utf-8"))
            if record.split != side:
                summary["skipped"][record.split] += 1
                continue
            try:
                facts = store.cached_facts(record.geometry.source_path, record.geometry.purpose, cache_dir)
            except (store.FactsCacheMiss, FileNotFoundError):
                summary["missing_facts"].append(record.geometry.case)
                continue
            rows = score_record(record, facts, kind_labels)
            new_rows.extend(rows)
            n += 1
            for r in rows:
                if r["audience"] == "builder":
                    verdicts[(r["kind"], r["verdict"])] += 1
        merged = _merge(store.read_jsonl(target), new_rows)
        store.write_jsonl(target, merged)
        summary["sides"][side] = {"records": n, "rows": len(new_rows), "ledger": str(target), "ledger_rows": len(merged),
                                  "builder_verdicts": {f"{k}:{v}": c for (k, v), c in sorted(verdicts.items())}}
    summary["skipped"] = dict(summary["skipped"])
    return summary
