"""Two calibrated tables the channel builder reads: minutes per cells bin and the per-representation cell
correction. Both are fitted on LEARNING records only and written with provenance (n, date, split sha); the
readers here never fit, they only look up.

    minutes_for_cells(cells, engine) -> {"typical": median minutes, "p90": ..., "n": ..., "bin": ...}
    cell_correction(representation) -> multiplier on the standard-tier estimate (1.0 when unfitted)
"""
from __future__ import annotations

import statistics
from datetime import UTC, datetime
from functools import lru_cache
from pathlib import Path
from typing import Any

from geometry_agent.learn import store
from geometry_agent.learn.schema import OutcomeRecord

CELL_BINS: tuple[tuple[str, float, float], ...] = (
    ("under_0.5M", 0.0, 500_000.0),
    ("0.5_to_1M", 500_000.0, 1_000_000.0),
    ("1_to_2M", 1_000_000.0, 2_000_000.0),
    ("over_2M", 2_000_000.0, float("inf")),
)
#: The export names representations carve, fluid_domain and external; the catalog says wall_shell,
#: fluid_domain, annular_fluid and external. Both vocabularies resolve to the fitted key.
REPRESENTATION_ALIASES = {
    "carve": "carve", "wall_shell": "carve", "body_surface": "carve",
    "fluid_domain": "fluid_domain", "fluid": "fluid_domain", "annular_fluid": "fluid_domain",
    "external": "external",
}


def cells_bin(cells: float | int) -> str:
    for name, lo, hi in CELL_BINS:
        if lo <= cells < hi:
            return name
    return CELL_BINS[-1][0]


def _p90(values: list[float]) -> float:
    xs = sorted(values)
    if len(xs) == 1:
        return xs[0]
    k = 0.9 * (len(xs) - 1)
    i = int(k)
    frac = k - i
    return xs[i] if i + 1 >= len(xs) else xs[i] + (xs[i + 1] - xs[i]) * frac


def _summary(values: list[float]) -> dict[str, Any]:
    if not values:
        return {"n": 0, "median": None, "p90": None}
    return {"n": len(values), "median": round(statistics.median(values), 2), "p90": round(_p90(values), 2)}


def fit_minutes_bins(records: list[OutcomeRecord], split_sha256: str | None = None) -> dict[str, Any]:
    """Minutes per dispatched attempt, binned by the cells the attempt delivered, per engine and pooled. Attempts
    that were dispatched but delivered no mesh are their own row (`no_mesh`): the minutes the stack paid for a
    pass that did not succeed. Only learning records are passed in by the caller."""
    per_engine: dict[str, dict[str, list[float]]] = {}
    for rec in records:
        if rec.split != "learning":
            continue
        for a in rec.builder.attempts:
            if not a.dispatched or a.seconds is None or a.seconds <= 0:
                continue
            eng = a.engine or rec.geometry.engine or "unknown"
            minutes = a.seconds / 60.0
            name = cells_bin(a.quality.cells) if a.quality.cells else "no_mesh"
            for key in (eng, "all"):
                per_engine.setdefault(key, {}).setdefault(name, []).append(minutes)
    table = {}
    for eng, bins in per_engine.items():
        table[eng] = {name: _summary(bins.get(name, [])) for name, _, _ in CELL_BINS}
        table[eng]["no_mesh"] = _summary(bins.get("no_mesh", []))
        table[eng]["all_dispatched"] = _summary([m for v in bins.values() for m in v])
    return {
        "version": 1, "date": datetime.now(UTC).date().isoformat(), "split": "learning", "split_sha256": split_sha256,
        "records": sum(1 for r in records if r.split == "learning"),
        "bins": [{"name": n, "cells_min": lo, "cells_max": (None if hi == float("inf") else hi)} for n, lo, hi in CELL_BINS],
        "basis": "minutes = finished_utc - started_utc of each dispatched attempt in runs.json; cells from the attempt's score",
        "table": table,
    }


@lru_cache(maxsize=8)
def _load(path: str) -> dict[str, Any] | None:
    p = Path(path)
    if not p.exists():
        return None
    return store.read_json(p)


def reload() -> None:
    _load.cache_clear()


def minutes_for_cells(cells: float | int, engine: str = "snappy", path: Path = store.MINUTES_BINS) -> dict[str, Any]:
    """The forecast basis for one mesh: typical (median) and p90 minutes of learning-half attempts in the same
    cells bin on the same engine, with n so a thin bin is visible. Falls back to the pooled table when the
    engine has no rows; typical is None when nothing was fitted."""
    doc = _load(str(path))
    name = cells_bin(cells)
    out = {"cells": int(cells), "bin": name, "engine": engine, "typical": None, "p90": None, "n": 0, "basis": None}
    if not doc:
        return out
    table = doc.get("table", {})
    for key in (engine, "all"):
        row = table.get(key, {}).get(name)
        if row and row.get("n"):
            out.update({"typical": row["median"], "p90": row["p90"], "n": row["n"], "engine": key,
                        "basis": f"{doc.get('split')} records, split {str(doc.get('split_sha256'))[:8]}, {doc.get('date')}"})
            return out
    return out


def fit_cell_correction(records: list[OutcomeRecord], split_sha256: str | None = None,
                        label_version: int | None = None) -> dict[str, Any]:
    """The median of the delivered cells over the standard-tier estimate, per representation, on learning
    records that delivered a mesh. The multiplier turns the facts layer's estimate into the builder's count."""
    ratios: dict[str, list[float]] = {}
    for rec in records:
        if rec.split != "learning":
            continue
        est = rec.geometry.tier_estimates.get("standard")
        cells = rec.labels.cells
        rep = REPRESENTATION_ALIASES.get(rec.geometry.representation or "", rec.geometry.representation)
        if not est or not cells or not rep:
            continue
        ratios.setdefault(rep, []).append(cells / est)
    fitted = {}
    for rep, xs in sorted(ratios.items()):
        xs = sorted(xs)
        fitted[rep] = {"multiplier": round(statistics.median(xs), 3), "n": len(xs),
                       "p25": round(xs[len(xs) // 4], 3), "p75": round(xs[(3 * len(xs)) // 4], 3),
                       "min": round(xs[0], 3), "max": round(xs[-1], 3)}
    return {
        "version": 1, "date": datetime.now(UTC).date().isoformat(), "split": "learning", "split_sha256": split_sha256,
        "label_version": label_version, "records": sum(1 for r in records if r.split == "learning"),
        "basis": "median over learning records of delivered cells / standard-tier estimate (facts layer, diagonal/80)",
        "by_representation": fitted,
    }


def cell_correction(representation: str | None, path: Path = store.CELL_CORRECTION) -> float:
    """The multiplier for one representation, 1.0 when nothing was fitted for it."""
    doc = _load(str(path))
    if not doc or not representation:
        return 1.0
    rep = REPRESENTATION_ALIASES.get(representation, representation)
    row = doc.get("by_representation", {}).get(rep)
    return float(row["multiplier"]) if row and row.get("multiplier") else 1.0


def cell_correction_info(representation: str | None, path: Path = store.CELL_CORRECTION) -> dict[str, Any]:
    doc = _load(str(path))
    rep = REPRESENTATION_ALIASES.get(representation or "", representation)
    row = (doc or {}).get("by_representation", {}).get(rep) if doc else None
    return {"representation": rep, "multiplier": float(row["multiplier"]) if row else 1.0, "n": row["n"] if row else 0,
            "date": doc.get("date") if doc else None, "split_sha256": doc.get("split_sha256") if doc else None,
            "source": str(path) if row else "none (unfitted, multiplier 1.0)"}
