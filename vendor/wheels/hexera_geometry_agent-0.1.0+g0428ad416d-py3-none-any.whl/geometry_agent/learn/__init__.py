"""The learning loop (docs/dev_plan.md, section 3b): outcome records, the feature bank, the post-mortem ledger,
rule cards and calibration, plus the threshold-governance builder's replay_regression and rules.json.

One idempotent command does the ingest, the calibration tables, the feature bank, the post-mortem, the ledgers
and the rule cards; nothing else writes those files:

    python -m geometry_agent.learn.ingest eval/corpus_export_cases --source corpus_export

A locked record and the locked ledger are read by the post-mortem (which writes them) and the look script only;
tests/test_learn_isolation.py holds the feature bank, the sweep and the rule cards to that.
"""
