"""OutcomeRecord v1: what the agent predicted for one geometry, what the builder did, what the reviewer said,
and the labels the label script gave the case (docs/dev_plan.md, P0).

A record is written once per job by an ingester and never edited by hand. Its split is assigned at ingest by
`assign_split` and is the only thing that decides which ledger its post-mortem rows land in: a geometry or a
group already on the locked list is locked whatever source it came from, so a re-export or a harness rerun of a
locked case can never leak into calibration; blind and dose records are never learning.
"""
from __future__ import annotations

from datetime import UTC, datetime
from typing import Any, Literal

from pydantic import BaseModel, Field

OUTCOME_SCHEMA_VERSION = 1

Split = Literal["learning", "locked", "blind", "dose", "unassigned"]
#: `live` is a recorded live-model evaluation run (learn/ingest_live.py): the agent's own warnings and questions
#: on a case the corpus export already labelled, with no new mesh.
Source = Literal["corpus_export", "sample_export", "harness", "dose", "blind", "live"]
Policy = Literal["live", "heuristic", "replay", "none"]
Audience = Literal["builder", "user", "note"]


class Geometry(BaseModel):
    case: str
    source_path: str
    sha256: str
    facts_sha256: str
    facts_schema_version: int
    family: str | None = None
    group: str | None = None
    representation: str | None = None
    engine: str | None = None
    purpose: str
    unit: str | None = None
    cell_cap: int | None = None
    declared: list[dict[str, Any]] = Field(default_factory=list)
    bbox_extent: tuple[float, float, float] | None = None
    n_openings: int = 0
    #: The facts layer's own count per tier (draft, standard, max) with the standard tier's base and surface
    #: cell, so calibration reads records and never the cache.
    tier_estimates: dict[str, int] = Field(default_factory=dict)
    base_size: float | None = None
    surface_cell: float | None = None


class AgentWarning(BaseModel):
    kind: str
    audience: Audience
    severity: str | None = None
    threshold_key: str | None = None
    measurement: dict[str, Any] = Field(default_factory=dict)
    #: Opening, region or cluster ids the warning is about; empty when it is about the whole case.
    location: list[str] = Field(default_factory=list)
    builder_frame: dict[str, Any] = Field(default_factory=dict)
    effect: str | None = None
    requires_user_decision: bool = False


class AgentQuestion(BaseModel):
    id: str
    kind: str | None = None
    text: str
    default: str | None = None
    effect: str | None = None
    relates_to: list[str] = Field(default_factory=list)


class AgentBlock(BaseModel):
    present: bool = False
    policy: Policy = "none"
    prompt_sha256: str | None = None
    thresholds_sha256: str | None = None
    features_sha256: str | None = None
    model: str | None = None
    rounds: int | None = None
    seconds: float | None = None
    header_keys: dict[str, Any] = Field(default_factory=dict)
    warnings: list[AgentWarning] = Field(default_factory=list)
    questions: list[AgentQuestion] = Field(default_factory=list)


class Quality(BaseModel):
    cells: int | None = None
    max_skewness: float | None = None
    max_non_orthogonality_deg: float | None = None
    skew_fraction: float | None = None
    skew_faces: int | None = None
    layer_coverage: float | None = None
    fatal: bool | None = None
    wall_faces: int | None = None
    failed_gate: str | None = None
    #: The patch carrying the worst skew face, once a harness bundle or step 8 writes it. None until then, and
    #: every hit is grade B while it is None.
    worst_patch: str | None = None


class Attempt(BaseModel):
    index: int
    status: str
    dispatched: bool = False
    engine: str | None = None
    job_id: str | None = None
    episode: str | None = None
    intake: str | None = None
    turns: int | None = None
    started: str | None = None
    finished: str | None = None
    seconds: float | None = None
    strategy: dict[str, Any] | None = None
    prior_feedback: str | None = None
    #: Per header key, whether the builder's authored value matched the agent's (P3); empty until a harness run.
    fidelity: dict[str, Any] = Field(default_factory=dict)
    quality: Quality = Field(default_factory=Quality)


class BuilderBlock(BaseModel):
    platform_revision: str | None = None
    attempts: list[Attempt] = Field(default_factory=list)


class ReviewerBlock(BaseModel):
    verdict: str | None = None
    feedback: str | None = None


class Labels(BaseModel):
    """A copy of the label script's row. Never recomputed here: eval/labels/build_labels.py is the one source."""
    label_version: int | None = None
    split: str | None = None
    final_status: str | None = None
    first_dispatched_status: str | None = None
    first_attempt_failed: bool | None = None
    never_ran: bool | None = None
    ever_succeeded: bool | None = None
    failed: bool | None = None
    cells: int | None = None
    cell_cap: int | None = None
    over_budget: bool | None = None
    max_non_ortho: float | None = None
    max_skewness: float | None = None
    poor_non_ortho: bool | None = None
    poor_skew: bool | None = None
    poor_70_4: bool | None = None
    poor_65_4: bool | None = None
    quality_label_eligible: bool | None = None
    #: Components the export cannot carry yet (wall faces zero, a carve leak); None until a harness bundle.
    wall_faces_zero_or_leak: bool | None = None


class IntakeBlock(BaseModel):
    turns: int | None = None
    first_dispatched_turns: int | None = None
    questions: list[str] = Field(default_factory=list)
    questions_by_topic: dict[str, int] = Field(default_factory=dict)
    brief: str | None = None


class OutcomeRecord(BaseModel):
    schema_version: int = OUTCOME_SCHEMA_VERSION
    job_key: str
    source: Source
    split: Split = "unassigned"
    split_sha256: str | None = None
    ingested: str = Field(default_factory=lambda: datetime.now(UTC).isoformat(timespec="seconds"))
    geometry: Geometry
    agent: AgentBlock = Field(default_factory=AgentBlock)
    builder: BuilderBlock = Field(default_factory=BuilderBlock)
    reviewer: ReviewerBlock = Field(default_factory=ReviewerBlock)
    labels: Labels = Field(default_factory=Labels)
    intake: IntakeBlock = Field(default_factory=IntakeBlock)

    @property
    def file_stem(self) -> str:
        return f"{self.geometry.facts_sha256[:12]}__{self.geometry.case}"


def job_key(source: str, case: str, facts_sha256: str, job_id: str | None = None) -> str:
    """One key per job: the source, the case, the measurement's identity, and the platform job when there is one
    (a harness rerun of a case is a new job; a second ingest of the same export is the same job)."""
    key = f"{source}/{facts_sha256[:12]}__{case}"
    return f"{key}@{job_id}" if job_id else key


INTAKE_TOPICS = (
    ("seed", ("seed",)),
    ("unit", ("unit", "millimet", "millimeter", " mm ", "inches")),
    ("port", ("inlet", "outlet", "port", "opening", "diameter", "plane")),
    ("engine", ("engine", "snappyhexmesh", "gmsh", "cfmesh", "select")),
)


def intake_topic(question: str) -> str:
    """The topic docs/corpus_export.md counts intake re-asks under: seed, unit, port, engine, other."""
    q = f" {question.lower()} "
    for topic, words in INTAKE_TOPICS:
        if any(w in q for w in words):
            return topic
    return "other"


def assign_split(record: OutcomeRecord, split_file: Any, locked_shas: set[str] | None = None) -> Split:
    """The record's side, and the rule that gave it (written into the record).

    1. A geometry sha, a group or a case already on the locked list is locked, whatever the source.
    2. Sources blind and dose are never learning: they keep their own name.
    3. Otherwise the split file's side for the case name.
    4. Unassigned when the split does not know the case.
    """
    from geometry_agent.learn.store import locked_groups, read_split, split_side
    split = read_split(split_file) if not isinstance(split_file, dict) else split_file
    locked_cases = set(split.get("locked", []))
    g = record.geometry
    if g.case in locked_cases or (g.group and g.group in locked_groups(split)) or (locked_shas and g.sha256 in locked_shas):
        side: Split = "locked"
    elif record.source in ("blind", "dose"):
        side = record.source  # type: ignore[assignment]
    else:
        side = split_side(g.case, split) or "unassigned"  # type: ignore[assignment]
    record.split = side
    record.split_sha256 = split.get("sha256")
    return side
