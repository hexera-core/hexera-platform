"""Case memory (docs/dev_plan.md, P7): what happened to parts that measured like this one.

The index is built from OutcomeRecords whose split is `learning`, never from `expected.json` and never from a
locked record. The record supplies the case's identity, its declaration and its outcome; the cached facts supply
the measurement, exactly as `learn/postmortem.py` reads them. Nothing here opens a locked record; the leak probe
(eval/memory/leak_probe.py) is the one reader of the locked side, and it reads a locked record's `geometry` block
alone, never its labels.

Three rules the design turns on.

1. The descriptors are family-free. Family alone predicts most of the mesh label on this corpus (docs/eval_protocol.md,
   section 3), so a descriptor that encoded the family would retrieve the family and the block would be a family
   classifier wearing a memory costume. What a neighbour is chosen by is representation, purpose, port count, bore
   ratios, stub bands, mouth tilt, the narrowest mouth dimension in builder cells, bore over extent in builder
   cells, junction angle, a thin-plate flag and the forecast over the cap. Family is carried on the entry for the
   diversity cap and for the leak probe, and is never a term in the distance.

2. Silence is a valid answer. The distance is Gower-style with a hard gate on representation and purpose, a
   per-family diversity cap so three neighbours are not three tee_wyes, and a distance cap under which fewer than
   two neighbours means no block at all. An unusual part gets nothing, which is the honest answer.

3. No absolute length leaves a remembered case. The presenter writes ratios, counts, degrees and outcome numbers,
   and `absolute_lengths` names every number that may not appear so `check_block` can prove it. Every number the
   block does show is recorded in the run's separate memory set (`tools.ToolContext.memory_numbers`), never in the
   measurement ledger, so a millimetre from another part cannot enter this plan.
"""
from __future__ import annotations

import hashlib
import json
import math
import random
import re
from dataclasses import asdict, dataclass, field, replace
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from geometry_agent.learn import calibration, features, store
from geometry_agent.learn.schema import OutcomeRecord

MEMORY_VERSION = 1
#: Where the built index lives. Regenerated from the records like the feature tables, so it is gitignored.
INDEX_JSON = store.EVAL / "memory" / "index.json"

# ---------------------------------------------------------------------------------------------------------------
# The descriptors. `gate` must match exactly or the entry is not a candidate; `categorical` and `boolean` score 0
# or 1; `numeric` scores the scaled absolute difference, clipped at 1. A descriptor missing on either side is
# dropped from that pair and its weight comes off the denominator (Gower's own treatment of a missing value), and
# a pair that shares less than MIN_SHARED_WEIGHT of the total weight has no distance at all.
# ---------------------------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class Descriptor:
    name: str
    kind: str
    weight: float = 1.0
    #: log1p on the strictly non-negative heavy-tailed measures: without it a tilt of 0.2 and a tilt of 0.6
    #: differ by nothing on a scale a 40 degree mouth sets, and the whole tilt signal lives under one degree.
    transform: str = "none"


DESCRIPTORS: tuple[Descriptor, ...] = (
    Descriptor("representation", "gate"),
    Descriptor("purpose", "gate"),
    Descriptor("engine", "categorical", 1.5),
    Descriptor("n_ports", "numeric", 1.0, "log1p"),
    Descriptor("min_bore_over_extent", "numeric", 1.0),
    Descriptor("bore_spread", "numeric", 0.75, "log1p"),
    Descriptor("min_stub_over_d", "numeric", 1.0, "log1p"),
    Descriptor("min_outlet_stub_over_d", "numeric", 0.75, "log1p"),
    Descriptor("max_tilt_circular_deg", "numeric", 1.5, "log1p"),
    Descriptor("tilted_circular_fraction", "numeric", 1.0),
    Descriptor("min_mouth_dim_builder_cells", "numeric", 1.0, "log1p"),
    Descriptor("smallest_port_builder_cells", "numeric", 1.0, "log1p"),
    Descriptor("min_junction_angle_deg", "numeric", 0.75),
    Descriptor("thin_plate", "boolean", 0.75),
    Descriptor("estimate_over_cap", "numeric", 1.25, "log1p"),
)
DESCRIPTOR_BY_NAME = {d.name: d for d in DESCRIPTORS}
GATES = tuple(d.name for d in DESCRIPTORS if d.kind == "gate")
SCORED = tuple(d for d in DESCRIPTORS if d.kind != "gate")
TOTAL_WEIGHT = sum(d.weight for d in SCORED)

#: How many neighbours a block shows.
NEIGHBOURS = 3
#: At most this many neighbours from one family, so three neighbours are not three tee_wyes.
MAX_PER_FAMILY = 1
#: Beyond this Gower distance a case is not a neighbour. Fewer than MIN_NEIGHBOURS inside it means no block.
#: Fitted leave-one-out on the learning half (docs/memory.md, section 5.1): it is where the neighbour count
#: saturates (116 of the 121 blocks carry all three) and where the neighbours' own majority is at its best.
DISTANCE_CAP = 0.2
MIN_NEIGHBOURS = 2
#: A pair must share at least this fraction of the scored weight for its distance to mean anything.
MIN_SHARED_WEIGHT = 0.6
#: The robust scale of a numeric descriptor is its p95 minus its p5 over the index, never its full range: one
#: outlier would otherwise set the scale and every real difference would round to zero.
SCALE_LO, SCALE_HI = 0.05, 0.95
SCALE_FLOOR = 1e-9

#: The stub bands the presenter speaks in (dev plan P7, "stub bands"); the distance stays continuous. The band
#: names carry no digits: a band edge is a threshold of this code, not a measurement of the remembered part, and
#: every digit in a block has to be a number of the remembered part so the memory set can hold all of them.
STUB_BANDS = ((2.0, "shorter than two bores"), (5.0, "two to five bores"), (float("inf"), "five bores or more"))
#: The engine words a brief may use, for the query side where no `expected.json` declares one.
ENGINE_WORDS = ((re.compile(r"snappy", re.I), "snappy"), (re.compile(r"\bgmsh\b", re.I), "gmsh"),
                (re.compile(r"cfmesh", re.I), "cfmesh"))
#: The planner keys a remedy may name (the seven the snappy renderer reads, docs/handover_consumers.md).
STRATEGY_KEYS = ("quality", "cells_across_diameter", "surface_level", "feature_level", "n_layers", "first_layer_rel",
                 "max_cells")
#: eval/split/make_split.py's own group key, so a twin is recognised from a case name or from a file name alone.
GROUP_KEY = re.compile(r"^(.*?_\d{3})")


def group_stem(name: str | None) -> str | None:
    """The twin key of a case name, a group or a file stem. `bend_elbow__bend_elbow_003`, its fluid twin
    `bend_elbow_003_fluid` and the bare stem `bend_elbow_003` all reduce to `bend_elbow_003`, which is how the
    split folds a twin into its group. At run time the agent knows the file, not the case name, so this is what
    makes the twin test work on the query side as well as on the index side."""
    if not name:
        return None
    tail = str(name).replace("\\", "/").rsplit("/", 1)[-1].split("__")[-1]
    m = GROUP_KEY.match(tail)
    return m.group(1) if m else tail


def _norm_representation(value: Any) -> str | None:
    """The export says carve, fluid_domain, external; the catalog says wall_shell, annular_fluid and the rest.
    Both vocabularies resolve through the same alias map the calibration tables use."""
    if not value:
        return None
    return calibration.REPRESENTATION_ALIASES.get(str(value), str(value))


def engine_from_brief(brief: str | None) -> str | None:
    """The engine a brief names, or None. On the index side the record declares it; on the query side, at run
    time, the brief is all there is, and a silent brief leaves the descriptor missing rather than guessed."""
    text = brief or ""
    for pattern, name in ENGINE_WORDS:
        if pattern.search(text):
            return name
    return None


# ---------------------------------------------------------------------------------------------------------------
# Descriptors from one measured case.
# ---------------------------------------------------------------------------------------------------------------
def descriptors_from_bank(bank: dict[str, Any], representation: Any, engine: str | None, purpose: str) -> dict[str, Any]:
    """The family-free descriptor row for one case, from `features.compute`. Everything here is a ratio, a count,
    an angle or a class; no absolute length survives."""
    case, ports = bank["case"], bank["ports"]
    bores = [p["bore"] for p in ports if p.get("bore")]
    wall_cell = case.get("wall_cell_24")
    mouth_dims = [p["min_in_plane_dim"] / wall_cell for p in ports
                  if wall_cell and p.get("min_in_plane_dim")] if wall_cell else []
    circular = [p for p in ports if p["shape"] == "circle"]
    estimate = case.get("refined_estimate_over_cap")
    if estimate is None:
        estimate = case.get("tier_estimate_over_cap")
    thin = case.get("thin_over_wall_cell")
    return {
        "representation": _norm_representation(representation) or _norm_representation(case.get("catalog_representation")),
        "purpose": purpose,
        "engine": engine,
        "n_ports": float(case["n_ports"]) if case.get("n_ports") is not None else None,
        "min_bore_over_extent": case.get("min_bore_over_extent"),
        "bore_spread": (max(bores) / min(bores)) if bores and min(bores) > 0 else None,
        "min_stub_over_d": case.get("min_stub_over_d"),
        "min_outlet_stub_over_d": case.get("min_outlet_stub_over_d"),
        "max_tilt_circular_deg": case.get("max_tilt_circular_deg"),
        "tilted_circular_fraction": (case["n_tilted_circular"] / len(circular)) if circular else None,
        "min_mouth_dim_builder_cells": min(mouth_dims) if mouth_dims else None,
        "smallest_port_builder_cells": case.get("smallest_port_cells_across_24"),
        "min_junction_angle_deg": case.get("min_junction_angle_deg"),
        "thin_plate": (thin < 1.0) if thin is not None else None,
        "estimate_over_cap": estimate,
    }


def _round_descriptors(row: dict[str, Any]) -> dict[str, Any]:
    return {k: (round(v, 6) if isinstance(v, float) else v) for k, v in row.items()}


# ---------------------------------------------------------------------------------------------------------------
# The outcome summary carried beside the descriptors.
# ---------------------------------------------------------------------------------------------------------------
def attempts_to_deliver(record: OutcomeRecord) -> tuple[int | None, bool]:
    """Dispatched attempts up to and including the first that succeeded, and whether a mesh was ever delivered.
    An undispatched attempt cost the stack nothing and is not counted."""
    dispatched = 0
    for a in record.builder.attempts:
        if not a.dispatched:
            continue
        dispatched += 1
        if str(a.status) == "succeeded":
            return dispatched, True
    return (dispatched or None), False


def worst_patch_role_shape(record: OutcomeRecord, bank: dict[str, Any]) -> tuple[str | None, str | None]:
    """The role and mouth shape of the patch carrying the worst skew face, when a record has one. No export
    record does (the platform does not write it yet), so this is None until a harness bundle or step 8 fills it."""
    patch = next((a.quality.worst_patch for a in reversed(record.builder.attempts) if a.quality.worst_patch), None)
    if not patch:
        return None, None
    for p in bank["ports"]:
        if p.get("name") == patch or p.get("port_id") == patch:
            return p.get("role"), p.get("shape")
    return None, None


def strategy_delta(record: OutcomeRecord) -> dict[str, list[Any]]:
    """What changed between the last failing attempt and the passing one after it, over the planner's own keys.
    Empty when the record has fewer than two attempts with a strategy, which is every export record today: the
    export's runs.json carries no `.last_plan.json` (dev plan, ask 2)."""
    with_strategy = [a for a in record.builder.attempts if isinstance(a.strategy, dict) and a.strategy]
    passing = next((a for a in with_strategy if str(a.status) == "succeeded"), None)
    if passing is None:
        return {}
    failing = [a for a in with_strategy if a.index < passing.index and str(a.status) != "succeeded"]
    if not failing:
        return {}
    before, after = failing[-1].strategy or {}, passing.strategy or {}
    return {k: [before.get(k), after.get(k)] for k in STRATEGY_KEYS
            if k in before or k in after if before.get(k) != after.get(k)}


def outcome_summary(record: OutcomeRecord, bank: dict[str, Any]) -> dict[str, Any]:
    """The label components, what the mesh measured, how many passes it took, the worst patch and the remedy."""
    lb = record.labels
    quality = next((a.quality for a in reversed(record.builder.attempts)
                    if a.quality.max_skewness is not None or a.quality.cells is not None), None)
    n_attempts, delivered = attempts_to_deliver(record)
    role, shape = worst_patch_role_shape(record, bank)
    cap = record.geometry.cell_cap or lb.cell_cap
    return {
        "poor_70_4": lb.poor_70_4, "poor_skew": lb.poor_skew, "poor_non_ortho": lb.poor_non_ortho,
        "over_budget": lb.over_budget, "first_attempt_failed": lb.first_attempt_failed, "never_ran": lb.never_ran,
        "failed": lb.failed, "quality_label_eligible": lb.quality_label_eligible,
        "max_skewness": lb.max_skewness if lb.max_skewness is not None else (quality.max_skewness if quality else None),
        "max_non_orthogonality_deg": lb.max_non_ortho if lb.max_non_ortho is not None else (
            quality.max_non_orthogonality_deg if quality else None),
        "cells_over_cap": round(lb.cells / cap, 3) if (lb.cells and cap) else None,
        "attempts_to_deliver": n_attempts, "delivered": delivered,
        "worst_patch_role": role, "worst_patch_shape": shape,
        "strategy_delta": strategy_delta(record),
    }


def absolute_lengths(record: OutcomeRecord, bank: dict[str, Any] | None = None) -> set[float]:
    """Every number of a remembered case that may never appear in a block: its lengths, areas, cell counts and
    cell estimates. `check_block` holds the presenter to this, and docs/memory.md states the rule."""
    out: set[float] = set()
    g = record.geometry
    for v in list(g.bbox_extent or ()) + [g.base_size, g.surface_cell, g.cell_cap]:
        if isinstance(v, int | float) and not isinstance(v, bool):
            out.add(float(v))
    out |= {float(v) for v in g.tier_estimates.values()}
    for d in g.declared or []:
        for key in ("area", "bore_diameter", "hydraulic_diameter"):
            v = d.get(key)
            if isinstance(v, int | float) and not isinstance(v, bool):
                out.add(float(v))
    for a in record.builder.attempts:
        for v in (a.quality.cells, a.quality.wall_faces, a.quality.skew_faces):
            if isinstance(v, int | float) and not isinstance(v, bool):
                out.add(float(v))
    if record.labels.cells:
        out.add(float(record.labels.cells))
    if bank:
        for p in bank["ports"]:
            for key in ("bore", "min_in_plane_dim"):
                v = p.get(key)
                if isinstance(v, int | float) and not isinstance(v, bool):
                    out.add(float(v))
        for key in ("extent_max", "inlet_bore", "wall_cell_24", "min_bore", "tier_estimate"):
            v = bank["case"].get(key)
            if isinstance(v, int | float) and not isinstance(v, bool):
                out.add(float(v))
    return {v for v in out if v not in (0.0, 1.0)}


# ---------------------------------------------------------------------------------------------------------------
# The index.
# ---------------------------------------------------------------------------------------------------------------
@dataclass
class MemoryEntry:
    case: str
    family: str | None
    group: str | None
    sha256: str
    facts_sha256: str
    split: str
    platform_revision: str | None
    descriptors: dict[str, Any]
    outcome: dict[str, Any]
    forbidden: list[float] = field(default_factory=list)

    @classmethod
    def from_dict(cls, doc: dict[str, Any]) -> MemoryEntry:
        return cls(**{k: doc.get(k) for k in cls.__dataclass_fields__})


@dataclass
class MemoryIndex:
    version: int
    built: str
    split_sha256: str | None
    label_version: int | None
    features_hash: str
    entries: list[MemoryEntry] = field(default_factory=list)
    scales: dict[str, float] = field(default_factory=dict)
    skipped: dict[str, int] = field(default_factory=dict)

    @property
    def sha256(self) -> str:
        """The index's identity: its version, the split it was built from and every entry's case and descriptors.
        A result can say which index it ran under without carrying the index."""
        payload = json.dumps({"version": self.version, "split": self.split_sha256, "features": self.features_hash,
                              "entries": [[e.case, sorted(e.descriptors.items(), key=lambda kv: kv[0])] for e in self.entries]},
                             sort_keys=True, default=str)
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:16]

    def to_dict(self) -> dict[str, Any]:
        return {"version": self.version, "built": self.built, "split_sha256": self.split_sha256,
                "label_version": self.label_version, "features_hash": self.features_hash, "sha256": self.sha256,
                "n_entries": len(self.entries), "descriptors": [asdict(d) for d in DESCRIPTORS],
                "distance_cap": DISTANCE_CAP, "neighbours": NEIGHBOURS, "max_per_family": MAX_PER_FAMILY,
                "min_neighbours": MIN_NEIGHBOURS, "scales": self.scales, "skipped": self.skipped,
                "entries_list": [asdict(e) for e in self.entries]}

    @classmethod
    def from_dict(cls, doc: dict[str, Any]) -> MemoryIndex:
        idx = cls(version=doc["version"], built=doc["built"], split_sha256=doc.get("split_sha256"),
                  label_version=doc.get("label_version"), features_hash=doc.get("features_hash", ""),
                  entries=[MemoryEntry.from_dict(e) for e in doc.get("entries_list", [])],
                  scales=doc.get("scales", {}), skipped=doc.get("skipped", {}))
        return idx


def _percentile(values: list[float], q: float) -> float:
    xs = sorted(values)
    if not xs:
        return 0.0
    if len(xs) == 1:
        return xs[0]
    k = q * (len(xs) - 1)
    i = int(k)
    frac = k - i
    return xs[i] if i + 1 >= len(xs) else xs[i] + (xs[i + 1] - xs[i]) * frac


def _transformed(name: str, value: Any) -> float | None:
    d = DESCRIPTOR_BY_NAME.get(name)
    if d is None or value is None or isinstance(value, str):
        return None
    x = float(value)
    if d.transform == "log1p":
        return math.log1p(max(0.0, x))
    return x


def fit_scales(rows: list[dict[str, Any]]) -> dict[str, float]:
    """The robust spread of every numeric descriptor over the index, in its transformed units."""
    scales: dict[str, float] = {}
    for d in SCORED:
        if d.kind != "numeric":
            continue
        xs = [t for t in (_transformed(d.name, r.get(d.name)) for r in rows) if t is not None]
        spread = _percentile(xs, SCALE_HI) - _percentile(xs, SCALE_LO) if xs else 0.0
        scales[d.name] = max(spread, SCALE_FLOOR)
    return scales


def build_index(outcomes_dir: Path = store.OUTCOMES_DIR, split_file: Path = store.SPLIT_FILE,
                cache_dir: Path = store.DEFAULT_CACHE_DIR, labels_json: Path = store.LABELS_JSON) -> MemoryIndex:
    """The index from the learning records. `store.record_paths` picks the side by file name, so no locked record
    is opened to find out that it is locked, and a record whose own split is not `learning` is skipped by name."""
    split = store.read_split(split_file)
    label_version = None
    if Path(labels_json).exists():
        label_version = store.labels_meta(labels_json).get("label_version")
    entries: list[MemoryEntry] = []
    skipped: dict[str, int] = {"not_learning": 0, "no_facts": 0, "no_descriptors": 0}
    for p in store.record_paths(outcomes_dir, split_file, "learning"):
        record = OutcomeRecord.model_validate_json(Path(p).read_text(encoding="utf-8"))
        if record.split != "learning":
            skipped["not_learning"] += 1
            continue
        try:
            facts = store.cached_facts(record.geometry.source_path, record.geometry.purpose, cache_dir)
        except (store.FactsCacheMiss, FileNotFoundError):
            skipped["no_facts"] += 1
            continue
        bank = features.compute(facts, _context_of(record))
        row = _round_descriptors(descriptors_from_bank(bank, record.geometry.representation,
                                                       record.geometry.engine, record.geometry.purpose))
        if not row.get("representation") or not row.get("purpose"):
            skipped["no_descriptors"] += 1
            continue
        entries.append(MemoryEntry(
            case=record.geometry.case, family=record.geometry.family, group=record.geometry.group,
            sha256=record.geometry.sha256, facts_sha256=record.geometry.facts_sha256, split=record.split,
            platform_revision=record.builder.platform_revision, descriptors=row,
            outcome=outcome_summary(record, bank), forbidden=sorted(absolute_lengths(record, bank))))
    idx = MemoryIndex(version=MEMORY_VERSION, built=datetime.now(UTC).isoformat(timespec="seconds"),
                      split_sha256=split.get("sha256"), label_version=label_version,
                      features_hash=features.features_hash(), entries=entries,
                      scales=fit_scales([e.descriptors for e in entries]), skipped=skipped)
    return idx


def _context_of(record: OutcomeRecord) -> features.CaseContext:
    g = record.geometry
    return features.CaseContext(case=g.case, purpose=g.purpose, brief=record.intake.brief, declared=g.declared,
                                representation=g.representation, engine=g.engine, cell_cap=g.cell_cap, family=g.family)


def write_index(index: MemoryIndex, path: Path = INDEX_JSON) -> Path:
    return store.write_json(Path(path), index.to_dict())


def read_index(path: Path = INDEX_JSON) -> MemoryIndex:
    return MemoryIndex.from_dict(store.read_json(Path(path)))


# ---------------------------------------------------------------------------------------------------------------
# The query side: what is being asked about. Built from a record (the probe) or from a live run's facts (the agent).
# ---------------------------------------------------------------------------------------------------------------
@dataclass
class Query:
    descriptors: dict[str, Any]
    case: str | None = None
    family: str | None = None
    group: str | None = None
    sha256: str | None = None
    facts_sha256: str | None = None


def query_from_facts(facts, purpose: str, brief: str | None = None, declared: list[dict[str, Any]] | None = None,
                     representation: str | None = None, engine: str | None = None, cell_cap: int | None = None,
                     case: str | None = None, family: str | None = None, group: str | None = None,
                     sha256: str | None = None, facts_sha256: str | None = None) -> Query:
    """The query for one measured part. `representation` and `engine` are taken when known (a record declares
    both) and otherwise inferred: the catalog decides the representation, and the brief is the only evidence of
    the engine, so a silent brief leaves that descriptor missing instead of guessed.

    The representation is resolved before the descriptors are read, not after. `features.compute` picks the
    per-representation cell correction from the context it is handed (carve 1.09, external 0.84, fluid 4.3), so a
    context with no representation scores `estimate_over_cap` uncorrected while every index entry, built from a
    record that declares one, is corrected. The agent knows no declared representation at run time, so without
    this the query and the index would measure that descriptor on two different scales, worst on fluid domains
    where the correction is 4.3. The catalog's own verdict is what the entry's representation gate already uses.
    """
    ctx = features.CaseContext(case=case or "query", purpose=purpose, brief=brief, declared=list(declared or []),
                               representation=representation, engine=engine, cell_cap=cell_cap, family=family)
    bank = features.compute(facts, ctx)
    if representation is None:
        inferred = bank["case"].get("catalog_representation")
        if inferred:
            ctx = replace(ctx, representation=inferred)
            bank = features.compute(facts, ctx)
    row = _round_descriptors(descriptors_from_bank(bank, representation, engine or engine_from_brief(brief), purpose))
    return Query(descriptors=row, case=case, family=family, group=group, sha256=sha256, facts_sha256=facts_sha256)


def query_from_record(record: OutcomeRecord, facts) -> Query:
    """The query for a case that already has a record. Only the `geometry` block is read: a locked record's
    labels and outcome are never opened by retrieval or by the leak probe."""
    g = record.geometry
    return query_from_facts(facts, g.purpose, record.intake.brief, g.declared, g.representation, g.engine,
                            g.cell_cap, g.case, g.family, g.group, g.sha256, g.facts_sha256)


# ---------------------------------------------------------------------------------------------------------------
# Distance and selection.
# ---------------------------------------------------------------------------------------------------------------
def gated(query: dict[str, Any], entry: dict[str, Any]) -> bool:
    """The hard gate: representation and purpose must match. A carve's memory never holds an external body."""
    return all(query.get(g) is not None and query.get(g) == entry.get(g) for g in GATES)


def distance(query: dict[str, Any], entry: dict[str, Any], scales: dict[str, float]) -> tuple[float | None, float]:
    """Gower distance over the scored descriptors and the share of weight the two rows had in common. None when
    they shared less than `MIN_SHARED_WEIGHT`: a distance computed on two descriptors is not a distance."""
    total = 0.0
    shared = 0.0
    for d in SCORED:
        a, b = query.get(d.name), entry.get(d.name)
        if a is None or b is None:
            continue
        if d.kind == "categorical":
            delta = 0.0 if a == b else 1.0
        elif d.kind == "boolean":
            delta = 0.0 if bool(a) == bool(b) else 1.0
        else:
            ta, tb = _transformed(d.name, a), _transformed(d.name, b)
            if ta is None or tb is None:
                continue
            delta = min(1.0, abs(ta - tb) / max(scales.get(d.name, SCALE_FLOOR), SCALE_FLOOR))
        shared += d.weight
        total += d.weight * delta
    if shared <= 0 or shared / TOTAL_WEIGHT < MIN_SHARED_WEIGHT:
        return None, shared / TOTAL_WEIGHT if TOTAL_WEIGHT else 0.0
    return round(total / shared, 4), round(shared / TOTAL_WEIGHT, 3)


@dataclass
class Neighbour:
    entry: MemoryEntry
    distance: float
    shared: float

    @property
    def poor(self) -> bool | None:
        return self.entry.outcome.get("poor_70_4")


def _same_part(query: Query, entry: MemoryEntry) -> bool:
    """A case is never its own neighbour, and neither is a twin: the same geometry under another representation
    or engine. Four tests, any of which is enough: the case name, the split's group key (reduced to its stem so
    a file name answers it too), the geometry's file hash and the measurement's hash."""
    q_stem = group_stem(query.group or query.case)
    e_stem = group_stem(entry.group or entry.case)
    return bool((query.case and query.case == entry.case)
                or (q_stem and e_stem and q_stem == e_stem)
                or (query.sha256 and entry.sha256 and query.sha256 == entry.sha256)
                or (query.facts_sha256 and entry.facts_sha256 and query.facts_sha256 == entry.facts_sha256))


def ranked(index: MemoryIndex, query: Query, apply_gate: bool = True, drop_self: bool = True) -> list[Neighbour]:
    """Every candidate with a distance, nearest first. The leak probe reads this before any cap, so it sees what
    retrieval would reach for and not only what it would show."""
    out: list[Neighbour] = []
    for e in index.entries:
        if drop_self and _same_part(query, e):
            continue
        if apply_gate and not gated(query.descriptors, e.descriptors):
            continue
        d, shared = distance(query.descriptors, e.descriptors, index.scales)
        if d is None:
            continue
        out.append(Neighbour(entry=e, distance=d, shared=shared))
    out.sort(key=lambda n: (n.distance, n.entry.case))
    return out


def select(candidates: list[Neighbour], k: int = NEIGHBOURS, distance_cap: float = DISTANCE_CAP,
           max_per_family: int = MAX_PER_FAMILY, pair_outcomes: bool = True) -> tuple[list[Neighbour], bool]:
    """The neighbours a block may show, and whether the pairing rule had to act.

    Nearest first inside the distance cap, at most `max_per_family` from one family. Then the pairing rule: when
    the chosen set is all poor or all clean and the other outcome exists among the remaining candidates under the
    same two caps, the farthest chosen neighbour is swapped for the nearest neighbour of the other outcome, so the
    block is never an argument for one outcome.
    """
    inside = [n for n in candidates if n.distance <= distance_cap]
    chosen: list[Neighbour] = []
    per_family: dict[str, int] = {}
    for n in inside:
        fam = n.entry.family or n.entry.case
        if per_family.get(fam, 0) >= max_per_family:
            continue
        chosen.append(n)
        per_family[fam] = per_family.get(fam, 0) + 1
        if len(chosen) >= k:
            break
    if not pair_outcomes or len(chosen) < 2:
        return chosen, False
    outcomes = {bool(n.poor) for n in chosen if n.poor is not None}
    if len(outcomes) != 1:
        return chosen, False
    want = not outcomes.pop()
    picked = {n.entry.case for n in chosen}
    families = {n.entry.family or n.entry.case for n in chosen}
    dropped = chosen[-1]
    dropped_family = dropped.entry.family or dropped.entry.case
    families.discard(dropped_family)
    for n in inside:
        fam = n.entry.family or n.entry.case
        if n.entry.case in picked or n.poor is None or bool(n.poor) != want:
            continue
        if fam in families and per_family.get(fam, 0) >= max_per_family:
            continue
        return chosen[:-1] + [n], True
    return chosen, False


# ---------------------------------------------------------------------------------------------------------------
# The presenter: one line per neighbour, in ratios and words.
# ---------------------------------------------------------------------------------------------------------------
HEADER = ("REMEMBERED CASES: parts that measured like this one, and what the builder's mesh did to them. These are "
          "OTHER parts. Nothing here is a measurement of this geometry: use them to decide what to check, and cite "
          "no number from them. Every number below is refused by the checker if it appears in your plan.")
NO_BLOCK_REASON = {
    "too_few": "fewer than two learning cases sit inside the distance cap",
    "no_index": "no memory index was loaded",
    "gate": "no learning case shares this representation and purpose",
}


def _band(value: float | None) -> str | None:
    if value is None:
        return None
    for edge, name in STUB_BANDS:
        if value < edge:
            return name
    return STUB_BANDS[-1][1]


class _Line:
    """A presented line and the numbers it carries. Every number goes through `num`, so the block can prove what
    it showed and the run can record exactly those in its memory set.

    Both forms of a number are recorded: the value the index holds and the value the text prints. They differ
    once a ratio is written to three figures, and it is the printed form a model would copy, so the printed form
    has to be in the set the checker reads."""

    def __init__(self) -> None:
        self.parts: list[str] = []
        self.numbers: list[float] = []

    def num(self, value: float, fmt: str = "{:g}") -> str:
        text = fmt.format(value)
        self.numbers.append(round(float(value), 6))
        try:
            self.numbers.append(float(text))
        except ValueError:
            pass
        return text

    def add(self, text: str | None) -> None:
        if text:
            self.parts.append(text)

    def join(self, sep: str = "; ") -> str:
        return sep.join(self.parts)


def describe_part(entry: MemoryEntry, line: _Line) -> str:
    """What the remembered part was like, in ratios and words."""
    d = entry.descriptors
    line.add(f"{d.get('representation')} on {d.get('engine') or 'an unrecorded engine'}")
    if d.get("n_ports") is not None:
        line.add(f"{line.num(d['n_ports'], '{:.0f}')} ports")
    if d.get("min_bore_over_extent") is not None:
        line.add(f"smallest bore {line.num(d['min_bore_over_extent'], '{:.3g}')} of the extent")
    smallest_cells = d.get("smallest_port_builder_cells")
    if smallest_cells is not None:
        line.add(f"{line.num(smallest_cells, '{:.3g}')} builder cells across it")
    mouth = d.get("min_mouth_dim_builder_cells")
    if mouth is not None and not (smallest_cells and abs(mouth - smallest_cells) <= 0.02 * smallest_cells):
        # on a circular mouth the narrowest in-plane dimension is the bore, and the clause would say it twice
        line.add(f"narrowest mouth dimension {line.num(mouth, '{:.3g}')} cells")
    if d.get("bore_spread") is not None and d["bore_spread"] > 1.05:
        line.add(f"bores {line.num(d['bore_spread'], '{:.3g}')}x apart")
    tilt = d.get("max_tilt_circular_deg")
    if tilt is not None:
        frac = d.get("tilted_circular_fraction")
        if tilt < features.GRID_ALIGNED_TILT_DEG:
            line.add("every circular mouth on the grid")
        else:
            clause = f"circular mouths tilted to {line.num(tilt, '{:.3g}')} deg"
            if frac is not None and frac >= 1.0:
                clause += ", every one of them off the grid"
            elif frac:
                clause += f", {line.num(frac, '{:.2g}')} of them off the grid"
            line.add(clause)
    band = _band(d.get("min_outlet_stub_over_d") if d.get("min_outlet_stub_over_d") is not None else d.get("min_stub_over_d"))
    if band:
        line.add(f"shortest run {band}")
    if d.get("min_junction_angle_deg") is not None:
        line.add(f"junction at {line.num(d['min_junction_angle_deg'], '{:.3g}')} deg")
    if d.get("thin_plate"):
        line.add("metal thinner than one builder cell")
    if d.get("estimate_over_cap") is not None:
        line.add(f"forecast {line.num(d['estimate_over_cap'], '{:.3g}')}x its own cap")
    return line.join()


def describe_outcome(entry: MemoryEntry, line: _Line) -> str:
    """What happened to it, with the verdict spelled out and the remedy clause when the record has one."""
    o = entry.outcome
    if o.get("never_ran"):
        verdict = "NEVER RAN (the stack never dispatched it)"
    elif o.get("failed"):
        verdict = "FAILED (it ran and never delivered a mesh)"
    elif o.get("poor_70_4"):
        # the limits themselves (skewness 4, non-orthogonality 70) are thresholds of the label script and sit in
        # the prompt already; printing them here would put a digit in the block that is nobody's measurement
        why = []
        if o.get("poor_skew") and o.get("max_skewness") is not None:
            why.append(f"max skewness {line.num(o['max_skewness'], '{:.3g}')}, over the limit")
        elif o.get("poor_skew"):
            why.append("max skewness over the limit")
        if o.get("poor_non_ortho") and o.get("max_non_orthogonality_deg") is not None:
            why.append(f"non-orthogonality {line.num(o['max_non_orthogonality_deg'], '{:.4g}')} deg, over the limit")
        verdict = "POOR MESH, " + " and ".join(why) if why else "POOR MESH"
    elif o.get("poor_70_4") is False:
        skew = o.get("max_skewness")
        verdict = "CLEAN MESH" + (f" (max skewness {line.num(skew, '{:.3g}')})" if skew is not None else "")
    else:
        verdict = "NO MESH LABEL (this case carries none)"
    line.add(verdict)
    if o.get("over_budget") and o.get("cells_over_cap") is not None:
        line.add(f"over its cell budget at {line.num(o['cells_over_cap'], '{:.3g}')}x the cap")
    elif o.get("over_budget"):
        line.add("over its cell budget")
    n = o.get("attempts_to_deliver")
    if n:
        line.add(f"delivered on pass {line.num(n, '{:.0f}')}" if o.get("delivered")
                 else f"{line.num(n, '{:.0f}')} passes and no mesh")
    if o.get("first_attempt_failed"):
        line.add("its first pass failed")
    if o.get("worst_patch_role"):
        shape = o.get("worst_patch_shape")
        line.add(f"the worst cell sat at the {o['worst_patch_role']}" + (f"'s {shape} mouth" if shape else ""))
    delta = o.get("strategy_delta") or {}
    if delta:
        moves = ", ".join(f"{k} {before} to {after}" for k, (before, after) in sorted(delta.items()))
        line.add(f"what fixed it: {moves}")
    line.add(f"platform revision {entry.platform_revision or 'not recorded'}")
    return line.join()


def present(neighbours: list[Neighbour], mode: str = "on") -> dict[str, Any]:
    """The block: a header, one entry per neighbour written in two clauses, and the numbers it showed."""
    lines: list[str] = [HEADER]
    numbers: list[float] = []
    shown: list[dict[str, Any]] = []
    for i, n in enumerate(neighbours, start=1):
        part_line, outcome_line = _Line(), _Line()
        part = describe_part(n.entry, part_line)
        outcome = describe_outcome(n.entry, outcome_line)
        # A letter, not a number: every digit in a block has to be a number of a remembered part, so that the
        # memory set holds all of them and a list marker is never mistaken for a measurement. The distance itself
        # is not shown either: it stays in the block's metadata for the ledger and the probe, because a real
        # neighbour's distance is always inside the cap and the placebo's is not, and a block that printed it
        # would tell the model which arm it is in.
        lines.append(f"{chr(64 + i)}. It was like this: {part}.")
        lines.append(f"   What happened: {outcome}.")
        numbers += part_line.numbers + outcome_line.numbers
        shown.append({"case": n.entry.case, "family": n.entry.family, "distance": n.distance,
                      "poor_70_4": n.entry.outcome.get("poor_70_4"), "shared": n.shared})
    # 0 and 1 are dropped: grounding treats 0 as always traceable, and a bare 1 is a unit vector's component and
    # every second count, so poisoning it would name a legitimate number as a memory of another part
    kept = sorted({v for v in numbers if v not in (0.0, 1.0)})
    return {"mode": mode, "text": "\n".join(lines), "numbers": kept, "neighbours": shown,
            "n_neighbours": len(neighbours)}


def check_block(block: dict[str, Any], entries: list[MemoryEntry]) -> list[str]:
    """Every violation of the presenter's contract: an absolute length, area, cell count or cell estimate of a
    remembered case that reached the block. The presenter never reads one, and this proves it."""
    forbidden: set[float] = set()
    for e in entries:
        forbidden |= {float(v) for v in (e.forbidden or [])}
    bad = []
    for v in block.get("numbers", []):
        for f in forbidden:
            if f and abs(v - f) <= max(1e-9, 1e-6 * abs(f)):
                bad.append(f"{v!r} is an absolute measurement of a remembered case ({f!r})")
                break
    return bad


# ---------------------------------------------------------------------------------------------------------------
# Recall: the one call the run makes, and the shuffled placebo that runs through the same presenter.
# ---------------------------------------------------------------------------------------------------------------
def recall(index: MemoryIndex | None, query: Query, mode: str = "on", k: int = NEIGHBOURS,
           distance_cap: float = DISTANCE_CAP, max_per_family: int = MAX_PER_FAMILY,
           min_neighbours: int = MIN_NEIGHBOURS, seed: int = 20260908) -> dict[str, Any] | None:
    """The memory block for one part, or None when memory has nothing to say.

    `mode` off returns None. `mode` on retrieves. `mode` shuffled is the placebo: it asks the real retrieval
    whether a block would be shown and how many neighbours it would carry, then fills those slots with random
    learning cases from the same gated pool and hands them to the same presenter. Shown exactly as often as real
    memory and worded exactly the same way, it isolates the one thing under test: whether the neighbours being
    similar is what does the work, or whether a confident-sounding block is enough.
    """
    if mode == "off" or index is None or not index.entries:
        return None
    candidates = ranked(index, query)
    chosen, paired = select(candidates, k, distance_cap, max_per_family)
    if len(chosen) < min_neighbours:
        return None
    if mode == "shuffled":
        chosen = _shuffled(index, query, len(chosen), seed)
        paired = False
        if len(chosen) < min_neighbours:
            return None
    block = present(chosen, mode=mode)
    block.update(paired=paired, index_sha256=index.sha256, distance_cap=distance_cap,
                 candidates_inside_cap=sum(1 for n in candidates if n.distance <= distance_cap))
    return block


def _shuffled(index: MemoryIndex, query: Query, n: int, seed: int) -> list[Neighbour]:
    """`n` random learning cases, from the gated pool when it holds enough and from the whole index otherwise.
    Seeded by the case name, so the placebo arm is reproducible and a rerun shows the same block."""
    pool = [e for e in index.entries if not _same_part(query, e) and gated(query.descriptors, e.descriptors)]
    if len(pool) < n:
        pool = [e for e in index.entries if not _same_part(query, e)]
    if len(pool) < n:
        return []
    rng = random.Random(f"{seed}:{query.case or query.facts_sha256 or ''}")
    picked = rng.sample(sorted(pool, key=lambda e: e.case), n)
    out = []
    for e in picked:
        d, shared = distance(query.descriptors, e.descriptors, index.scales)
        # the real distance is kept for the arm's own record: it is how a reader sees that the placebo's
        # neighbours were not neighbours. It is never presented, in this arm or the real one.
        out.append(Neighbour(entry=e, distance=d if d is not None else float("inf"), shared=shared))
    return out


class CaseMemory:
    """The provider a run carries: an index, a mode and the caps, with one method the loop calls.

    It is handed to `agent.run.analyze(memory=...)` and sits on the ToolContext. The agent package never imports
    this module; it calls `block_for(ctx)` and records the numbers the block returns in the run's separate memory
    set, never in the measurement ledger.
    """

    def __init__(self, index: MemoryIndex | None, mode: str = "on", k: int = NEIGHBOURS,
                 distance_cap: float = DISTANCE_CAP, max_per_family: int = MAX_PER_FAMILY,
                 min_neighbours: int = MIN_NEIGHBOURS, seed: int = 20260908) -> None:
        self.index = index
        self.mode = mode
        self.k = k
        self.distance_cap = distance_cap
        self.max_per_family = max_per_family
        self.min_neighbours = min_neighbours
        self.seed = seed

    @property
    def stamp(self) -> str:
        return self.mode

    def block_for(self, ctx: Any) -> dict[str, Any] | None:
        """The block for the part a ToolContext holds, or None. Never raises into the loop: memory is an extra,
        and a run must not fail because the index could not answer."""
        if self.mode == "off" or self.index is None:
            return None
        try:
            # the run knows the file, not the case name: the file's stem carries the twin key (`group_stem`) and
            # its sha256 carries the identity, which is what keeps a twin and the part itself out of its own block
            source = str(getattr(ctx.facts, "source_path", "") or "")
            query = query_from_facts(ctx.facts, ctx.purpose, ctx.brief, ctx.declared, None, None, ctx.cell_cap,
                                     case=Path(source).stem if source else None,
                                     sha256=getattr(ctx.facts, "sha256", None))
            return recall(self.index, query, self.mode, self.k, self.distance_cap, self.max_per_family,
                          self.min_neighbours, self.seed)
        except Exception:  # noqa: BLE001 - a memory failure is silence, never a failed run
            return None


def main(argv: list[str] | None = None) -> int:
    """`python -m geometry_agent.learn.memory build [--outcomes D] [--split F] [--cache-dir D] [--out F]`."""
    import argparse
    ap = argparse.ArgumentParser(prog="python -m geometry_agent.learn.memory", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("command", choices=["build", "show"])
    ap.add_argument("--outcomes", default=str(store.OUTCOMES_DIR))
    ap.add_argument("--split", default=str(store.SPLIT_FILE))
    ap.add_argument("--cache-dir", default=str(store.DEFAULT_CACHE_DIR))
    ap.add_argument("--labels", default=str(store.LABELS_JSON))
    ap.add_argument("--out", default=str(INDEX_JSON))
    a = ap.parse_args(argv)
    if a.command == "build":
        idx = build_index(Path(a.outcomes), Path(a.split), Path(a.cache_dir), Path(a.labels))
        path = write_index(idx, Path(a.out))
        poor = sum(1 for e in idx.entries if e.outcome.get("poor_70_4"))
        print(f"memory index v{idx.version} {idx.sha256}: {len(idx.entries)} learning entries "
              f"({poor} poor, {len(idx.entries) - poor} clean or unlabelled), skipped {idx.skipped} -> {path}")
        return 0
    idx = read_index(Path(a.out))
    print(f"memory index v{idx.version} {idx.sha256}: {len(idx.entries)} entries, built {idx.built}, "
          f"split {idx.split_sha256}, features {idx.features_hash}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
