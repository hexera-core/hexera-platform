"""A recorded live-model run as OutcomeRecords: the agent's own warnings and questions on cases the corpus
export already labelled (docs/dev_plan.md P4.3, docs/learning_loop.md section 6).

    python -m geometry_agent.learn.ingest <results_dir> --source live --recordings <dir> [--cache-dir DIR]

Every per-case result JSON stamped `policy: live` (eval/run_eval.py --results-dir) becomes one record with
`agent.present` true: the stamp's policy, prompt hash, thresholds hash and model id, the run's rounds and
seconds, the plan's warnings (kind, audience from catalog.KIND_AUDIENCE when the kind is there and else from
the list the warning sits in, threshold key, measurement, location, effect when the plan carries one) and its
questions. The warnings are read from all three lists a plan can carry: `simulation_warnings` for the user and
`mesh_warnings` for the builder (plan schema 3, where the four calibrated builder kinds live), and `risks` for
the schema 2 plans that carry a kind there. The plan is read from the recording the way eval/judge.py reads it:
the last submitted plan, salvaged through `loop.read_plan_arguments` when the call arrived malformed, with
every amendment recorded after it applied. A result without a recording falls back to the judgment's risk
kinds and question lines. Labels are copied from the labels file, the split from the split file (a locked
case is locked whatever the run), the builder block stays empty (no new mesh was built), the geometry block is
the export's, and the job key is `live/<facts sha>__<case>@<run directory name>`. Records go to
eval/outcomes_live/<run>/ so a live record never overwrites the export's record of the same case; ingesting
twice changes nothing.

The post-mortem then scores the live warnings (learn/postmortem.run on that directory): learning rows into
eval/ledger.jsonl, locked rows into eval/ledger_locked.jsonl, merged by job key so a re-ingest replaces its own
rows and nothing else. The rule cards are regenerated from the learning ledger. `summary_table` reports the
per-kind verdict counts of the run on the learning half beside the catalog stand-in's rows.
"""
from __future__ import annotations

import json
import os
import re
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from geometry_agent.agent import catalog
from geometry_agent.learn import postmortem, rule_cards, store
from geometry_agent.learn.ingest_corpus_export import load_case, record_for_case, write_record
from geometry_agent.learn.schema import (
    OUTCOME_SCHEMA_VERSION,
    AgentBlock,
    AgentQuestion,
    AgentWarning,
    BuilderBlock,
    OutcomeRecord,
    assign_split,
    job_key,
)

RECORDINGS_ENV = "GEOMETRY_AGENT_RECORDINGS_DIR"
OUTCOMES_LIVE_DIR = store.EVAL / "outcomes_live"
#: The catalog's audience words against the record's (schema.Audience): info is a note.
AUDIENCE_WORD = {"user": "user", "builder": "builder", "info": "note", "note": "note"}
#: The corpus word for a representation against the catalog's.
CATALOG_REPRESENTATION = {"carve": "wall_shell", "fluid_domain": "fluid_domain", "external": "external"}
JUDGMENT_QUESTION = re.compile(r"^\[([^\]]*)\]\s*(.*?)(?:\s*\(default: (.*)\))?$", re.S)


@dataclass
class LiveIngestReport:
    run: str = ""
    results: int = 0
    records: int = 0
    written: int = 0
    unchanged: int = 0
    skipped_policy: Counter = field(default_factory=Counter)
    no_plan: int = 0
    no_recording: int = 0
    missing_case: list[str] = field(default_factory=list)
    missing_facts: list[str] = field(default_factory=list)
    missing_labels: list[str] = field(default_factory=list)
    split_counts: Counter = field(default_factory=Counter)
    warning_kinds: Counter = field(default_factory=Counter)
    questions: int = 0
    paths: list[Path] = field(default_factory=list)
    outcomes_dir: Path | None = None

    def summary(self) -> str:
        parts = [f"run {self.run}: {self.results} live results, {self.records} records ({self.written} written, {self.unchanged} unchanged)",
                 "split " + (", ".join(f"{k} {v}" for k, v in sorted(self.split_counts.items())) or "none"),
                 f"{sum(self.warning_kinds.values())} warnings over {len(self.warning_kinds)} kinds, {self.questions} questions"]
        if self.no_plan:
            parts.append(f"{self.no_plan} without a plan (no warnings, counted)")
        if self.no_recording:
            parts.append(f"{self.no_recording} without a recording (kinds from the judgment only)")
        if self.skipped_policy:
            parts.append("skipped " + ", ".join(f"{n} {k}" for k, n in sorted(self.skipped_policy.items())))
        if self.missing_case:
            parts.append(f"no case directory for {len(self.missing_case)}: {self.missing_case[:5]}")
        if self.missing_facts:
            parts.append(f"no cached facts for {len(self.missing_facts)}: {self.missing_facts[:5]}")
        if self.missing_labels:
            parts.append(f"no label row for {len(self.missing_labels)}: {self.missing_labels[:5]}")
        return "; ".join(parts)


def load_results(results_dir: Path) -> list[dict[str, Any]]:
    """Every per-case result JSON in name order; files that are not results are skipped."""
    rows = []
    for p in sorted(Path(results_dir).glob("*.json")):
        try:
            r = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        if isinstance(r, dict) and "case" in r:
            rows.append(r)
    return rows


def policy_of(result: dict[str, Any]) -> str:
    stamp = result.get("stamp")
    if isinstance(stamp, dict) and stamp.get("policy"):
        return str(stamp["policy"])
    return "unstamped"


def default_recordings_dir(results_dir: Path) -> Path:
    """The recordings a results directory pairs with: <root>/live/<name> when the results live under a `live`
    directory (eval/results/live/<name>), else <root>/<name> (eval/results/<name>); the root is
    $GEOMETRY_AGENT_RECORDINGS_DIR, else the `recordings` directory beside the results' own `results` directory."""
    results_dir = Path(results_dir).resolve()
    live = results_dir.parent.name == "live"
    results_root = results_dir.parents[1] if live else results_dir.parent
    root = Path(os.environ[RECORDINGS_ENV]) if os.environ.get(RECORDINGS_ENV) else results_root.parent / "recordings"
    return root / "live" / results_dir.name if live else root / results_dir.name


def read_recording(path: Path) -> dict[str, Any] | None:
    try:
        d = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return d if isinstance(d, dict | list) else None


def _plan_call_arguments(name: str, args: dict[str, Any]) -> dict[str, Any]:
    """The arguments the loop acted on: a `__malformed__` payload read back through `loop.read_plan_arguments`
    (a whole plan closed one bracket too many, or the largest valid prefix of one cut off at the output limit),
    and on a submission the fields that fell out of the plan put back beside it.

    Without this the ingester saw none of it. 121 of the plan calls of learning_v3_r4 arrived malformed, across
    109 of its 159 cases, and the loop salvaged every one; an ingester that skips them reads a different run
    from the one that happened."""
    from geometry_agent.agent.loop import merge_stray_plan_fields, read_plan_arguments

    if "__malformed__" in args:
        read, _kind, _surplus = read_plan_arguments(args.get("__malformed__"))
        args = read or {}
    if name == "submit_geometry_plan":
        args, _moved = merge_stray_plan_fields(args)
    return args


def plan_from_recording(rec: dict[str, Any] | list | None) -> dict[str, Any] | None:
    """The last submitted plan with every amendment recorded after it applied (loop v3), as eval/judge.py reads
    it, with a malformed call salvaged as the loop salvages it; None when the recording holds no submission.

    The amendments are not optional: 116 of the 159 cases of learning_v3_r4 end on one."""
    if rec is None:
        return None
    turns = rec if isinstance(rec, list) else rec.get("turns", [])
    plan = None
    for t in turns:
        for tc in (t.get("tool_calls") or []) if isinstance(t, dict) else []:
            name = tc.get("name")
            if name not in ("submit_geometry_plan", "amend_geometry_plan"):
                continue
            args = _plan_call_arguments(name, tc.get("arguments") if isinstance(tc.get("arguments"), dict) else {})
            if name == "submit_geometry_plan":
                if isinstance(args.get("plan"), dict):
                    plan = args["plan"]
            elif plan is not None:
                from geometry_agent.agent.tools import apply_plan_edits
                amended, errors = apply_plan_edits(plan, args.get("edits"))
                if not errors:
                    plan = amended
    return plan


def header_keys_from_recording(rec: dict[str, Any] | list | None) -> dict[str, Any]:
    """The handover header's keys when the recording carries one (`handover` or `header` at the top level, a
    dict with a `strategy` or `keys` block, or the header dict itself); the live recordings of 2026-09-09 carry
    none, so this is usually empty."""
    if not isinstance(rec, dict):
        return {}
    block = rec.get("handover") if isinstance(rec.get("handover"), dict) else rec.get("header")
    if not isinstance(block, dict):
        return {}
    for key in ("strategy", "keys", "header"):
        inner = block.get(key)
        if isinstance(inner, dict):
            return {k: v for k, v in inner.items() if isinstance(v, int | float | str | bool | dict | list) or v is None}
    return {k: v for k, v in block.items() if isinstance(v, int | float | str | bool) or v is None}


def audience_for(kind: str, requires_user_decision: bool, representation: str | None) -> str:
    """catalog.KIND_AUDIENCE when the kind is there (thin_feature on a wall shell's metal is a note through
    catalog.audience_of), else user when the risk asks a decision and note otherwise."""
    table = getattr(catalog, "KIND_AUDIENCE", {})
    if kind in table:
        rep = CATALOG_REPRESENTATION.get(representation or "", representation)
        fn = getattr(catalog, "audience_of", None)
        word = fn(kind, rep) if fn is not None else table[kind]
        return AUDIENCE_WORD.get(str(word), "note")
    return "user" if requires_user_decision else "note"


def threshold_key_for(kind: str) -> str | None:
    table = getattr(catalog, "KIND_THRESHOLD", {})
    return table.get(kind) or postmortem.KIND_THRESHOLD_KEY.get(kind)


def mesh_audience_for(kind: str, representation: str | None) -> str:
    """A mesh warning is addressed to the builder by the list it sits in. A kind the catalog knows keeps the
    catalog's own audience, so thin_feature on a wall shell's metal stays the cost note the stand-in calls it;
    a kind the analyst invented is the builder's."""
    if kind in getattr(catalog, "KIND_AUDIENCE", {}):
        return audience_for(kind, False, representation)
    return "builder"


def _mesh_location(warning: dict[str, Any]) -> list[str]:
    loc = warning.get("location") if isinstance(warning.get("location"), dict) else {}
    out = [str(x) for x in (loc.get("patch_ids") or []) if isinstance(x, str)]
    if isinstance(loc.get("region_id"), str):
        out.append(loc["region_id"])
    return out


def warnings_from_mesh_list(plan: dict[str, Any], representation: str | None) -> list[AgentWarning]:
    """The plan's `mesh_warnings`: the builder list of plan schema 3, in the builder's frame.

    This list is where the four calibrated builder kinds live (tilted_circular_mouth, budget_forecast,
    seed_point, gmsh_size: catalog.NEW_BUILDER_KINDS). A reader that looks only at `risks` counts none of them,
    and under schema 3 it counts nothing at all, because R34 writes a catalog risk as `{id, user_decision}` with
    no kind in it. The size block and the builder cells become the measurement, the patch ids the location, the
    target the builder frame."""
    out = []
    for w in plan.get("mesh_warnings") or []:
        if not isinstance(w, dict) or not w.get("kind"):
            continue
        kind = str(w["kind"])
        size = w.get("size") if isinstance(w.get("size"), dict) else {}
        cells = w.get("builder_cells") if isinstance(w.get("builder_cells"), dict) else {}
        target = w.get("target") if isinstance(w.get("target"), dict) else {}
        measurement: dict[str, Any] = dict(postmortem._scalars(size))
        measurement.update({f"builder_{k}": v for k, v in postmortem._scalars(cells).items()})
        if isinstance(w.get("cost_cells"), int):
            measurement["cost_cells"] = w["cost_cells"]
        measurement["detected_by"] = str(w.get("detected_by") or "catalog")
        measurement["warning_list"] = "mesh_warnings"
        out.append(AgentWarning(
            kind=kind, audience=mesh_audience_for(kind, representation),  # type: ignore[arg-type]
            severity=w.get("severity") if isinstance(w.get("severity"), str) else None,
            threshold_key=threshold_key_for(kind), measurement=measurement, location=_mesh_location(w),
            builder_frame=postmortem._scalars(target), effect=None, requires_user_decision=False))
    return out


def warnings_from_simulation_list(plan: dict[str, Any], representation: str | None) -> list[AgentWarning]:
    """The plan's `simulation_warnings`: the user list of plan schema 3. A warning that carries a question asks a
    decision, whether the checker left the question in `questions` or settled it from the brief (P4.4), so the
    post-mortem's false-alarm reading can reach it; one without a question is advisory."""
    out = []
    for w in plan.get("simulation_warnings") or []:
        if not isinstance(w, dict) or not w.get("kind"):
            continue
        kind = str(w["kind"])
        decision = isinstance(w.get("question"), str) and bool(w["question"].strip())
        measurement = dict(postmortem._scalars(w.get("measurement") if isinstance(w.get("measurement"), dict) else {}))
        threshold = w.get("threshold") if isinstance(w.get("threshold"), dict) else {}
        # the key the plan claimed is kept beside the catalog's own, never instead of it: a model may write a key
        # no governed table holds ("SHORT_STUB_D" for STUB_OK_OVER_D), and the ledger reads values by the key
        if threshold.get("key") is not None:
            measurement["plan_threshold_key"] = threshold.get("key")
        if threshold.get("value") is not None:
            measurement["plan_threshold_value"] = threshold.get("value")
        measurement["warning_list"] = "simulation_warnings"
        out.append(AgentWarning(
            kind=kind, audience=audience_for(kind, decision, representation),  # type: ignore[arg-type]
            severity=w.get("severity") if isinstance(w.get("severity"), str) else None,
            threshold_key=threshold_key_for(kind), measurement=measurement, location=postmortem._ids(measurement),
            builder_frame={}, effect=w.get("effect") if isinstance(w.get("effect"), str) else None,
            requires_user_decision=decision))
    return out


def warnings_from_risks(plan: dict[str, Any], representation: str | None, covered: set[str]) -> list[AgentWarning]:
    """The plan's `risks` as warnings, for the schema 2 plans that carry a kind in them. A risk already carried
    by one of the two schema 3 lists (matched by `provenance.risk_id`) is not counted twice."""
    out = []
    for r in plan.get("risks") or []:
        if not isinstance(r, dict) or not r.get("kind") or str(r.get("id") or "") in covered:
            continue
        kind = str(r["kind"])
        decision = bool(r.get("requires_user_decision"))
        measurement = r.get("measurement") if isinstance(r.get("measurement"), dict) else {}
        target = r.get("target") if isinstance(r.get("target"), dict) else {}
        out.append(AgentWarning(
            kind=kind, audience=audience_for(kind, decision, representation),  # type: ignore[arg-type]
            severity=r.get("severity"), threshold_key=threshold_key_for(kind),
            measurement=postmortem._scalars(measurement), location=postmortem._ids(measurement),
            builder_frame=dict(target), effect=r.get("effect") if isinstance(r.get("effect"), str) else None,
            requires_user_decision=decision))
    return out


def _covered_risk_ids(plan: dict[str, Any]) -> set[str]:
    out: set[str] = set()
    for key in ("simulation_warnings", "mesh_warnings"):
        for w in plan.get(key) or []:
            prov = w.get("provenance") if isinstance(w, dict) and isinstance(w.get("provenance"), dict) else {}
            if isinstance(prov.get("risk_id"), str):
                out.add(prov["risk_id"])
    return out


def warnings_from_plan(plan: dict[str, Any], representation: str | None) -> list[AgentWarning]:
    """Every warning the plan carries: the two schema 3 lists and, for a schema 2 plan, its `risks`.

    `risks` alone is not the plan's warnings. Under schema 3 the model's own output is `simulation_warnings` for
    the user and `mesh_warnings` for the builder, and `risks` holds `{id, user_decision}` with no kind (R34).
    Reading `risks` alone reported the builder rules firing 0 times on every live run there has been."""
    covered = _covered_risk_ids(plan)
    return (warnings_from_simulation_list(plan, representation)
            + warnings_from_mesh_list(plan, representation)
            + warnings_from_risks(plan, representation, covered))


def warnings_from_judgment(result: dict[str, Any]) -> list[AgentWarning]:
    """Kinds only, from the judgment's risk_kinds, for a result without a recording."""
    j = result.get("judgment") if isinstance(result.get("judgment"), dict) else {}
    out = []
    for kind in j.get("risk_kinds") or []:
        kind = str(kind)
        out.append(AgentWarning(kind=kind, audience=audience_for(kind, False, None), threshold_key=threshold_key_for(kind)))  # type: ignore[arg-type]
    return out


def question_kinds(plan: dict[str, Any]) -> dict[Any, Any]:
    """risk id -> kind. A schema 2 plan says it in `risks`; a schema 3 plan says it in the simulation warning
    whose `provenance.risk_id` names the risk, because R34 leaves no kind in `risks` at all."""
    kinds = {r.get("id"): r.get("kind") for r in plan.get("risks") or [] if isinstance(r, dict) and r.get("kind")}
    for w in plan.get("simulation_warnings") or []:
        if not isinstance(w, dict) or not w.get("kind"):
            continue
        prov = w.get("provenance") if isinstance(w.get("provenance"), dict) else {}
        for rid in [prov.get("risk_id"), w.get("id")] + [x for x in (w.get("also_settles") or []) if isinstance(x, str)]:
            if isinstance(rid, str):
                kinds.setdefault(rid, w["kind"])
    return kinds


def questions_from_plan(plan: dict[str, Any]) -> list[AgentQuestion]:
    kinds = question_kinds(plan)
    out = []
    for i, q in enumerate(plan.get("questions") or []):
        if not isinstance(q, dict):
            continue
        relates = [str(q.get("relates_to"))] if q.get("relates_to") else []
        relates += [str(x) for x in (q.get("also_settles") or []) if isinstance(x, str)]
        out.append(AgentQuestion(id=str(q.get("id") or f"q{i + 1}"), kind=kinds.get(q.get("relates_to")), text=str(q.get("text") or ""),
                                 default=q.get("default") if isinstance(q.get("default"), str) else None,
                                 effect=q.get("effect") if isinstance(q.get("effect"), str) else None, relates_to=relates))
    return out


def questions_from_judgment(result: dict[str, Any]) -> list[AgentQuestion]:
    """The judgment's question lines ("[k3+k4] text (default: x)"): ids and text, no kind."""
    j = result.get("judgment") if isinstance(result.get("judgment"), dict) else {}
    out = []
    for i, line in enumerate(j.get("questions") or []):
        m = JUDGMENT_QUESTION.match(str(line))
        ids = (m.group(1) if m else "").replace("+", ",").split(",")
        out.append(AgentQuestion(id=f"q{i + 1}", text=(m.group(2) if m else str(line)).strip(), default=(m.group(3) if m else None),
                                 relates_to=[x for x in ids if x]))
    return out


def agent_block(result: dict[str, Any], plan: dict[str, Any] | None, rec: dict[str, Any] | list | None,
                representation: str | None) -> AgentBlock:
    stamp = result.get("stamp") if isinstance(result.get("stamp"), dict) else {}
    if plan is not None:
        warnings, questions = warnings_from_plan(plan, representation), questions_from_plan(plan)
    elif isinstance(result.get("judgment"), dict):
        warnings, questions = warnings_from_judgment(result), questions_from_judgment(result)
    else:
        warnings, questions = [], []
    return AgentBlock(present=True, policy="live", prompt_sha256=stamp.get("prompt_sha256"), thresholds_sha256=stamp.get("thresholds_sha256"),
                      features_sha256=None, model=stamp.get("model"), rounds=result.get("rounds"),
                      seconds=float(result["seconds"]) if isinstance(result.get("seconds"), int | float) else None,
                      header_keys=header_keys_from_recording(rec), warnings=warnings, questions=questions)


def record_for_result(result: dict[str, Any], rec: dict[str, Any] | list | None, case_dir: Path, exp: dict[str, Any], facts,
                      label_row: dict[str, Any] | None, group_of: dict[str, str], run: str) -> OutcomeRecord:
    """The export's geometry, labels and intake with the live agent block; builder empty; job key by run."""
    base = record_for_case(case_dir, exp, facts, label_row, None, group_of)
    plan = plan_from_recording(rec)
    return OutcomeRecord(
        schema_version=OUTCOME_SCHEMA_VERSION, job_key=job_key("live", base.geometry.case, base.geometry.facts_sha256, run),
        source="live", geometry=base.geometry, agent=agent_block(result, plan, rec, exp.get("representation")),
        builder=BuilderBlock(), labels=base.labels, intake=base.intake,
    )


def ingest(results_dir: Path, recordings_dir: Path | None = None, cases_dir: Path = store.CASES_DIR, labels_json: Path = store.LABELS_JSON,
           split_file: Path = store.SPLIT_FILE, cache_dir: Path = store.DEFAULT_CACHE_DIR, outcomes_dir: Path | None = None,
           only: set[str] | None = None) -> LiveIngestReport:
    """Every live-stamped result under results_dir becomes one record under outcomes_dir (default
    eval/outcomes_live/<run>). Heuristic, replay and unstamped results are counted and skipped: they are a
    self-check, never a result (docs/dev_plan.md, principle 4)."""
    results_dir = Path(results_dir)
    run = results_dir.name
    rec_dir = Path(recordings_dir) if recordings_dir else default_recordings_dir(results_dir)
    out_dir = Path(outcomes_dir) if outcomes_dir else OUTCOMES_LIVE_DIR / run
    report = LiveIngestReport(run=run, outcomes_dir=out_dir)
    labels = store.labels_by_case(labels_json) if Path(labels_json).exists() else {}
    split = store.read_split(split_file)
    locked_names = set(split.get("locked", []))
    group_of = split.get("group_of", {})
    rows = load_results(results_dir)
    if only:
        rows = [r for r in rows if r["case"] in only]
    loaded = []
    locked_shas: set[str] = set()
    for r in rows:
        policy = policy_of(r)
        if policy != "live":
            report.skipped_policy[policy] += 1
            continue
        report.results += 1
        case = str(r["case"])
        case_dir = Path(cases_dir) / case
        exp = load_case(case_dir) if case_dir.is_dir() else None
        if exp is None:
            report.missing_case.append(case)
            continue
        try:
            facts = store.cached_facts(exp["source"], exp.get("purpose", "internal_cfd"), cache_dir)
        except (store.FactsCacheMiss, FileNotFoundError, KeyError):
            report.missing_facts.append(case)
            continue
        loaded.append((r, case_dir, exp, facts))
        if case in locked_names:
            locked_shas.add(facts.sha256)
    for r, case_dir, exp, facts in loaded:
        case = case_dir.name
        row = labels.get(case)
        if row is None:
            report.missing_labels.append(case)
        rec_path = rec_dir / f"{case}.json"
        rec = read_recording(rec_path) if rec_path.exists() else None
        if rec is None:
            report.no_recording += 1
        record = record_for_result(r, rec, case_dir, exp, facts, row, group_of, run)
        if not isinstance(r.get("judgment"), dict):
            report.no_plan += 1
        assign_split(record, split, locked_shas)
        path, changed = write_record(record, out_dir)
        report.records += 1
        report.written += int(changed)
        report.unchanged += int(not changed)
        report.split_counts[record.split] += 1
        for w in record.agent.warnings:
            report.warning_kinds[w.kind] += 1
        report.questions += len(record.agent.questions)
        report.paths.append(path)
    return report


def _is_live_row(row: dict[str, Any], run: str) -> bool:
    return str(row.get("job_key", "")).startswith("live/") and str(row.get("job_key", "")).endswith(f"@{run}")


def verdict_counts(ledger: Path, run: str | None = None, split: str = "learning") -> dict[str, dict[str, Any]]:
    """kind -> verdict counts on one side of the ledger: the run's rows when `run` is given, else the catalog
    stand-in's (source corpus_export)."""
    rows = [r for r in store.read_jsonl(ledger) if r.get("split") == split]
    rows = [r for r in rows if (_is_live_row(r, run) if run else r.get("source") == "corpus_export")]
    out: dict[str, dict[str, Any]] = {}
    for r in rows:
        c = out.setdefault(str(r["kind"]), {"audience": r.get("audience"), "n": 0, "fires": 0, "hit": 0, "miss": 0, "miss_silent": 0,
                                            "miss_unexplained": 0, "false_alarm": 0, "acted": 0, "untestable": 0, "clean": 0})
        c["n"] += 1
        c["fires"] += int(bool(r.get("fired")))
        v = str(r.get("verdict"))
        if v in c:
            c[v] += 1
        if v == "miss":
            c["miss_silent" if r.get("miss_kind") == "silent" else "miss_unexplained"] += 1
    return out


def summary_table(ledger: Path, run: str | list[str], split: str = "learning") -> str:
    """Each run's per-kind verdicts beside the stand-in's, as a markdown table (docs/learning_loop.md). One run,
    or several: a pooled row over two runs of different prompts is nobody's number, so they stay apart."""
    runs = [run] if isinstance(run, str) else list(run)
    tables = [(f"live {r}", verdict_counts(ledger, r, split)) for r in runs]
    tables.append(("heuristic stand-in", verdict_counts(ledger, None, split)))
    kinds = sorted({k for _label, t in tables for k in t},
                   key=lambda k: ({"builder": 0, "note": 1, "user": 2}.get(
                       next(t[k]["audience"] for _label, t in tables if k in t), 3), k))
    lines = ["| kind | audience | policy | n | fires | hit | miss (silent / unexplained) | false alarm | acted | untestable | clean |",
             "|---|---|---|---|---|---|---|---|---|---|---|"]
    for k in kinds:
        for label, table in tables:
            c = table.get(k)
            if c is None:
                continue
            lines.append(f"| {k} | {c['audience']} | {label} | {c['n']} | {c['fires']} | {c['hit']} | {c['miss']} ({c['miss_silent']} / {c['miss_unexplained']}) | "
                         f"{c['false_alarm']} | {c['acted']} | {c['untestable']} | {c['clean']} |")
    return "\n".join(lines) + "\n"


def run(results_dir: Path, recordings_dir: Path | None = None, cases_dir: Path = store.CASES_DIR, labels_json: Path = store.LABELS_JSON,
        split_file: Path = store.SPLIT_FILE, cache_dir: Path = store.DEFAULT_CACHE_DIR, outcomes_dir: Path | None = None,
        kind_labels_path: Path = store.KIND_LABELS, ledger: Path = store.LEDGER, ledger_locked: Path = store.LEDGER_LOCKED,
        sweeps_dir: Path = store.SWEEPS_DIR, rule_cards_json: Path = store.RULE_CARDS_JSON, rule_cards_md: Path = store.RULE_CARDS_MD,
        skip_postmortem: bool = False, log=print) -> dict[str, Any]:
    """The live branch of the one command: records, the post-mortem on them (both ledgers, by split), the cards."""
    report = ingest(results_dir, recordings_dir, cases_dir, labels_json, split_file, cache_dir, outcomes_dir)
    out: dict[str, Any] = {"ingest": report.summary(), "outcomes_dir": str(report.outcomes_dir), "run": report.run}
    log(f"records: {report.summary()}")
    if report.records == 0:
        return out
    if not skip_postmortem:
        pm = postmortem.run(report.outcomes_dir, split_file, cache_dir, kind_labels_path, ledger, ledger_locked)  # type: ignore[arg-type]
        out["postmortem"] = pm
        for side, s in pm["sides"].items():
            log(f"post-mortem {side}: {s['records']} records, {s['rows']} rows -> {s['ledger']} ({s['ledger_rows']} rows)")
        cards = rule_cards.write_cards(ledger, sweeps_dir, kind_labels_path, rule_cards_json, rule_cards_md)
        out["rule_cards"] = cards
        log(f"rule cards: {cards['cards']} kinds from {cards['ledger_rows']} ledger rows -> {cards['md']}, {cards['json']}")
        out["verdicts"] = verdict_counts(ledger, report.run)
        out["table"] = summary_table(ledger, report.run)
        log(out["table"])
    return out
