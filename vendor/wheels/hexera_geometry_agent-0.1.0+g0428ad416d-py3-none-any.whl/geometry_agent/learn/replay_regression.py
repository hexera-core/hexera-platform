"""Replay every stored transcript through the current checker with the current thresholds, without a network.

A recording (agent/client.py RecordingClient) holds the model's turns and, in the newer format, the whole
conversation the model saw. Replaying one means: rebuild the tool context from the case's facts, feed the
recorded tool calls to the tools again (so the ledger holds what the model could cite), and hand every recorded
submit_geometry_plan to grounding.check_with_hints as it stands today. A transcript that was accepted when it
was made and is rejected now is a regression: the checker, the catalog or a threshold changed what it accepts.
`geometry-agent thresholds ship` runs this first and refuses on any regression (docs/thresholds.md).

Tools that need the mesh (probe_section, section_profile, render_view) take their result from the recorded
transcript when it has one, so a replay never loads a STEP file; without a transcript they run against the
geometry when it is on disk. look_at_views records nothing, as in the live loop. The facts come from the corpus
case directory (found by the recording's case name under the corpus roots) through the facts cache, or from the
cache alone by the facts hash the transcript carries; nothing is written anywhere.

A plan call whose arguments would not parse is salvaged exactly as the loop salvages it (loop.read_plan_arguments,
loop.merge_stray_plan_fields), because the run it is replaying was scored on the salvaged plan. Skipping those
calls is not a conservative reading of the transcript: it removes the plan every later amendment edits, so a run
whose accepted plan came through a salvage cannot reach acceptance at all, and its amendments are rejected for
"nothing to amend".

    python -m geometry_agent.learn.replay_regression [--recordings D] [--facts-cache D] [--corpus-root D ...]
                                                    [--only name,name] [--split unlocked|learning|locked|all]
                                                    [--json out.json] [--quiet]

Exit 1 on any newly rejected transcript. `--split` defaults to `unlocked`: the gate a threshold move must pass
never reads a locked export case (docs/eval_protocol.md, section 2), and the summary says how many recordings
that held out. GEOMETRY_AGENT_RECORDINGS_DIR names the recordings when the checkout has none (they are
gitignored); GEOMETRY_AGENT_FACTS_CACHE names the cache; GEOMETRY_AGENT_CORPUS_ROOTS adds corpus roots
(os.pathsep separated)."""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

RECORDINGS_ENV = "GEOMETRY_AGENT_RECORDINGS_DIR"
FACTS_CACHE_ENV = "GEOMETRY_AGENT_FACTS_CACHE"
CORPUS_ROOTS_ENV = "GEOMETRY_AGENT_CORPUS_ROOTS"
ROOT = Path(__file__).resolve().parents[3]
DEFAULT_RECORDINGS = ROOT / "eval" / "recordings"
DEFAULT_CORPUS_ROOTS = tuple(ROOT / "eval" / d for d in (
    "corpus_export_cases", "corpus_hard", "corpus_families", "corpus_complex_all", "corpus_complex", "corpus_real",
    "corpus_jobs", "corpus"))
DEFAULT_SPLIT_FILE = ROOT / "eval" / "split" / "export_split.json"
#: Which side of the export split a replay may read. `unlocked` is the default and the only one a threshold
#: change may cite: every recording except one of a locked export case (docs/eval_protocol.md, section 2). A
#: recording of a case outside the export corpus has no side and is kept by `unlocked` and by `all`.
SPLIT_CHOICES = ("unlocked", "learning", "locked", "all")
#: Tools whose result needs the mesh; replayed from the transcript when it holds them.
MESH_TOOLS = frozenset({"probe_section", "section_profile", "render_view"})
GEOMETRY_SUFFIXES = {".stl", ".step", ".stp", ".obj", ".ply"}
_NOTE_STARTS = ("Everything measured about the file is below", "The summary below was measured by code",
                "The measurements below are what the tools would return")
#: The paragraphs of the request that are the checker's own and not the customer's words. The brief is read as
#: everything after "User's brief:", so a block added to the request lands inside it unless it is named here:
#: the key row (`prompt.builder_keys_block`) is generated from `catalog.DIRECTIVE_KEYS` and a replay that carried
#: it into the brief would re-measure a brief nobody wrote, and `unit_from_brief` would read its numbers.
_NOT_THE_BRIEF = ("BUILDER KEYS",)


@dataclass
class Verdict:
    recording: str
    case: str | None
    accepted_before: bool
    accepted_now: bool | None
    new_rejections: list[str] = field(default_factory=list)
    note: str = ""
    submissions: int = 0
    seconds: float = 0.0
    facts_source: str = ""

    @property
    def regressed(self) -> bool:
        return self.accepted_before and self.accepted_now is False

    @property
    def improved(self) -> bool:
        return (not self.accepted_before) and self.accepted_now is True

    def line(self) -> str:
        tag = ("NEW REJECTION" if self.regressed else "skipped" if self.accepted_now is None else "improved" if self.improved
               else "ok" if self.accepted_now else "still rejected")
        before = "yes" if self.accepted_before else "no"
        now = "-" if self.accepted_now is None else ("yes" if self.accepted_now else "no")
        out = f"{tag:14s} {self.recording}  before {before} now {now}  {self.seconds:.1f}s"
        if self.note:
            out += f"  [{self.note}]"
        if self.regressed:
            for msg in self.new_rejections[:6]:
                out += f"\n               - {msg[:220]}"
        return out


@dataclass
class Report:
    verdicts: list[Verdict]
    thresholds_sha256: str
    prompt_sha256: str
    recordings_dir: str
    split: str = "all"
    excluded_by_split: int = 0

    @property
    def regressed(self) -> list[Verdict]:
        return [v for v in self.verdicts if v.regressed]

    @property
    def exit_code(self) -> int:
        return 1 if self.regressed else 0

    def summary(self) -> dict[str, Any]:
        vs = self.verdicts
        return {"transcripts": len(vs), "accepted_before": sum(v.accepted_before for v in vs),
                "accepted_now": sum(v.accepted_now is True for v in vs), "newly_rejected": len(self.regressed),
                "newly_accepted": sum(v.improved for v in vs), "skipped": sum(v.accepted_now is None for v in vs),
                "split": self.split, "excluded_by_split": self.excluded_by_split,
                "thresholds_sha256": self.thresholds_sha256, "prompt_sha256": self.prompt_sha256,
                "recordings_dir": self.recordings_dir}

    def summary_line(self) -> str:
        s = self.summary()
        held = f", {s['excluded_by_split']} held out by --split {self.split}" if s["excluded_by_split"] else ""
        return (f"{s['transcripts']} transcripts under {self.recordings_dir} (--split {self.split}{held}): "
                f"{s['accepted_before']} accepted when made, "
                f"{s['accepted_now']} accepted now, {s['newly_rejected']} newly rejected, {s['newly_accepted']} newly accepted, "
                f"{s['skipped']} skipped\nthresholds {self.thresholds_sha256[:12]}  prompt {self.prompt_sha256[:12]}")

    def text(self, verbose: bool = True) -> str:
        """Every verdict (or only the regressions) and the summary."""
        lines = [v.line() for v in self.verdicts if verbose or v.regressed]
        return "\n".join(lines + ["", self.summary_line()]).lstrip("\n")

    def to_json(self) -> dict[str, Any]:
        return {"summary": self.summary(), "verdicts": [asdict(v) for v in self.verdicts]}


def recordings_dir(path: str | Path | None = None) -> Path:
    if path:
        return Path(path)
    env = os.environ.get(RECORDINGS_ENV)
    return Path(env) if env else DEFAULT_RECORDINGS


def find_recordings(root: str | Path | None = None) -> list[Path]:
    r = recordings_dir(root)
    if not r.is_dir():
        return []
    return sorted(p for p in r.rglob("*.json") if p.is_file())


def split_sides(split_file: str | Path | None = None) -> dict[str, str]:
    """case name -> learning or locked, from the frozen split; empty when there is no split file."""
    p = Path(split_file) if split_file else DEFAULT_SPLIT_FILE
    try:
        doc = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return {**dict.fromkeys(doc.get("learning") or [], "learning"), **dict.fromkeys(doc.get("locked") or [], "locked")}


def keep_for_split(path: Path, sides: dict[str, str], split: str) -> bool:
    """Whether a recording belongs to the side asked for. The case is the recording's file name, which is how
    every live run names them; a name the split does not know is outside the export corpus and has no side."""
    if split == "all":
        return True
    side = sides.get(Path(path).stem)
    if split == "unlocked":
        return side != "locked"
    return side == split


def corpus_roots(extra: list[str | Path] | None = None) -> list[Path]:
    roots = [Path(p) for p in (extra or [])]
    env = os.environ.get(CORPUS_ROOTS_ENV)
    if env:
        roots += [Path(p) for p in env.split(os.pathsep) if p]
    roots += list(DEFAULT_CORPUS_ROOTS)
    return roots


def find_case_dir(name: str, roots: list[Path]) -> Path | None:
    """The corpus directory of a case by name: directly under a root, or one level down (eval/corpus_complex
    keeps its cases under a family directory)."""
    for root in roots:
        if not root.is_dir():
            continue
        d = root / name
        if (d / "expected.json").is_file():
            return d
        for fam in sorted(p for p in root.iterdir() if p.is_dir()):
            d = fam / name
            if (d / "expected.json").is_file():
                return d
    return None


def _geometry_in(case_dir: Path, exp: dict) -> Path | None:
    src = exp.get("source")
    if src:
        p = Path(src)
        return p if p.exists() else None
    for p in sorted(case_dir.iterdir()):
        if p.suffix.lower() in GEOMETRY_SUFFIXES:
            return p
    return None


def parse_request(content: str) -> dict[str, Any]:
    """The request the model saw (agent/prompt.py user_prompt plus the measurements): purpose, fidelity, cell
    cap, declared ports, brief, and the facts hash from the measurement packet."""
    head, _, tail = content.partition("\n\nMEASUREMENTS:\n")
    facts_sha = None
    if tail:
        m = re.search(r'"facts_sha256":\s*"([0-9a-f]{64})"', tail)
        facts_sha = m.group(1) if m else None
    paragraphs = head.split("\n\n")
    if len(paragraphs) > 1 and paragraphs[-1].startswith(_NOTE_STARTS):
        paragraphs = paragraphs[:-1]
    head = "\n\n".join(p for p in paragraphs if not p.startswith(_NOT_THE_BRIEF))
    out: dict[str, Any] = {"purpose": None, "fidelity": "standard", "cell_cap": None, "declared": None, "brief": "",
                           "facts_sha256": facts_sha}
    lines = head.split("\n")
    for i, line in enumerate(lines):
        if line.startswith("Purpose: "):
            out["purpose"] = line[len("Purpose: "):].strip()
        elif line.startswith("Requested fidelity: "):
            out["fidelity"] = line[len("Requested fidelity: "):].strip()
        elif line.startswith("Cell cap: "):
            try:
                out["cell_cap"] = int(line[len("Cell cap: "):].replace(",", "").strip())
            except ValueError:
                out["cell_cap"] = None
        elif line.startswith("Ports the user declared: "):
            try:
                out["declared"] = json.loads(line[len("Ports the user declared: "):])
            except ValueError:
                out["declared"] = None
        elif line.startswith("User's brief: "):
            brief = "\n".join([line[len("User's brief: "):]] + lines[i + 1:])
            out["brief"] = "" if brief.strip() == "(none)" else brief
            break
    return out


def load_recording(path: Path) -> dict[str, Any]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    if isinstance(data, list):
        return {"turns": data, "transcript": None, "exit": None, "case": None}
    data.setdefault("turns", [])
    data.setdefault("transcript", None)
    return data


#: The plan schema version of a recording made before RecordingClient stamped `plan_schema_version` (every stored
#: transcript of the schema 2 era: prompt v2, the P4.1 runs, the noise-floor panels).
UNSTAMPED_SCHEMA_VERSION = 2


def recorded_schema_version(rec: dict[str, Any]) -> int:
    """The plan schema version the recording's run advertised in its submit tool: the `plan_schema_version` stamp
    (agent/client.py RecordingClient, added with schema 3), else UNSTAMPED_SCHEMA_VERSION. A submitted plan that
    writes no `schema_version` is judged under this version on replay, so the schema 3 rules (R2 to R12) never
    reach a transcript made under schema 2."""
    v = rec.get("plan_schema_version")
    try:
        return int(v) if v is not None else UNSTAMPED_SCHEMA_VERSION
    except (TypeError, ValueError):
        return UNSTAMPED_SCHEMA_VERSION


def _request_for(rec: dict[str, Any], case_dir: Path | None) -> dict[str, Any]:
    """What the run was asked: the transcript's own user message first (what the model actually saw), the case's
    expected.json when the recording predates transcripts."""
    transcript = rec.get("transcript") or []
    user = next((m for m in transcript if m.get("role") == "user"), None)
    if user and isinstance(user.get("content"), str) and user["content"].startswith("Purpose: "):
        return parse_request(user["content"])
    if case_dir is not None:
        exp = json.loads((case_dir / "expected.json").read_text(encoding="utf-8"))
        return {"purpose": exp.get("purpose"), "fidelity": exp.get("fidelity", "standard"), "cell_cap": exp.get("cell_cap"),
                "declared": exp.get("declared"), "brief": exp.get("brief", ""), "facts_sha256": None}
    return {"purpose": None, "fidelity": "standard", "cell_cap": None, "declared": None, "brief": "", "facts_sha256": None}


def _facts_for(case_dir: Path | None, request: dict[str, Any], caches: list[Path]):
    """The case's GeometryFacts and where they came from: the cache entry for the case's geometry, a fresh
    measurement of an STL/OBJ/PLY (seconds, no cache written), or the cache entry named by the transcript's facts
    hash when no case directory exists. A STEP with no cache entry is not measured here (minutes, and the run
    would want the cache written): the transcript is skipped with the reason."""
    from geometry_agent.facts import load as fload
    from geometry_agent.facts.measure import measure
    from geometry_agent.facts.schema import FACTS_SCHEMA_VERSION

    purpose = request.get("purpose")
    if not purpose:
        return None, "no purpose in the recording and no case directory"

    def cached(sha: str):
        for c in caches:
            f = c / f"{sha}.{purpose}.v{FACTS_SCHEMA_VERSION}.json"
            if f.is_file():
                from geometry_agent.facts.measure import read_cached
                got, current = read_cached(f, reader="replay_regression")
                return got, f"cache {f.name[:12]}" + ("" if current else f" (revision {got.measurement_revision})")
        return None, None

    if case_dir is not None:
        exp = json.loads((case_dir / "expected.json").read_text(encoding="utf-8"))
        geo = _geometry_in(case_dir, exp)
        if geo is not None:
            facts, src = cached(fload.sha256_of(geo))
            if facts is not None:
                return facts, src
            if geo.suffix.lower() in {".stl", ".obj", ".ply"}:
                return measure(geo, purpose=purpose, cache_dir=None), "measured (no cache entry)"
            return None, f"no cache entry for {geo.name} and a STEP is not measured during replay"
    sha = request.get("facts_sha256")
    if sha:
        facts, src = cached(sha)
        if facts is not None:
            return facts, src
        return None, f"no case directory and no cache entry for facts {sha[:12]}"
    return None, "no case directory and the recording carries no facts hash"


def replay_turns(rec: dict[str, Any], facts, request: dict[str, Any]) -> tuple[bool | None, list[str], int, list[str]]:
    """Feed the recorded tool calls to the tools and every recorded submission to the checker. Returns the last
    submission's verdict (None when nothing was submitted), its errors, the submission count and notes."""
    from geometry_agent.agent import grounding, tools
    from geometry_agent.agent.loop import LoopConfig, merge_stray_plan_fields, read_plan_arguments
    from geometry_agent.agent.tools import AMEND, LOOK, SUBMIT, ToolContext

    ctx = ToolContext(facts=facts, purpose=request["purpose"], fidelity=request.get("fidelity") or "standard",
                      cell_cap=request.get("cell_cap"), declared=request.get("declared"), brief=request.get("brief") or "")
    cfg = LoopConfig()
    packet = tools.facts_packet(ctx)
    if len(json.dumps(packet, default=str)) > cfg.inline_facts_chars:
        packet = tools.get_facts_summary(ctx)
    ctx.ledger.record(tools._round(packet))
    ctx.ledger.calls.append("facts_packet")
    recorded = {m.get("tool_call_id"): m.get("content") for m in (rec.get("transcript") or []) if m.get("role") == "tool"}
    made_under = recorded_schema_version(rec)
    roles_called = False
    submissions = 0
    last: tuple[bool | None, list[str]] = (None, [])
    notes: list[str] = []
    for turn in rec.get("turns") or []:
        for tc in turn.get("tool_calls") or []:
            name, args = tc.get("name"), tc.get("arguments")
            if not isinstance(args, dict):
                continue
            if "__malformed__" in args:
                if name not in (SUBMIT, AMEND):
                    continue
                # the loop salvages a plan call whose arguments would not parse, so the replay must too: a run
                # whose accepted plan came through a salvage can otherwise never reach acceptance here, and every
                # amendment after it is judged against no plan at all ("nothing to amend"). 121 of the plan calls
                # of learning_v3_r4 arrived this way, across 109 of its 159 cases
                read, _kind, _surplus = read_plan_arguments(args.get("__malformed__"))
                if read is None:
                    notes.append(f"{name}: arguments unreadable even after the salvage")
                    continue
                args = read
            if name in (SUBMIT, AMEND):
                submissions += 1
                if name == SUBMIT:
                    # the fields that fell out of a plan closed one field early belong back inside it (loop v3)
                    args, _moved = merge_stray_plan_fields(args)
                    plan_obj = args.get("plan")
                    if not isinstance(plan_obj, dict):
                        last = (False, ["plan must be an object"])
                        continue
                    if plan_obj.get("schema_version") is None:
                        # a plan that writes no version is the version its run's submit tool advertised, not
                        # today's (grounding.plan_version reads an absent version as the current one)
                        plan_obj = {**plan_obj, "schema_version": made_under}
                else:
                    # an amendment edits the plan the run last submitted, exactly as the loop does (agent/loop.py)
                    if ctx.last_plan is None:
                        last = (False, ["nothing to amend: no plan was submitted before this amendment"])
                        continue
                    plan_obj, edit_errors = tools.apply_plan_edits(ctx.last_plan, args.get("edits"))
                    if edit_errors:
                        last = (False, edit_errors)
                        continue
                ctx.last_plan = plan_obj
                if not roles_called:
                    last = (False, ["call list_risks with your assigned roles before submitting"])
                    continue
                plan, errors, _hints = grounding.check_with_hints(plan_obj, ctx)
                last = (plan is not None, errors)
                if plan is not None:
                    return True, [], submissions, notes
                continue
            if name == LOOK:
                continue
            if name in MESH_TOOLS:
                content = recorded.get(tc.get("id"))
                if isinstance(content, str):
                    try:
                        result = json.loads(content)
                    except ValueError:
                        result = None
                    if isinstance(result, dict):
                        ctx.ledger.record(result)
                        ctx.ledger.calls.append(name)
                        # and the call log a rule reads, exactly as run_tool would have written it (P4.3e)
                        ctx.ledger.log_call(name, args if isinstance(args, dict) else {}, result)
                        continue
                if Path(facts.source_path).exists():
                    try:
                        tools.run_tool(ctx, name, args)
                    except Exception as exc:  # noqa: BLE001 - a probe that cannot run is a note, not a crash of the suite
                        notes.append(f"{name} failed on replay: {type(exc).__name__}")
                else:
                    notes.append(f"{name} result unavailable (no transcript and the geometry is not on disk)")
                continue
            try:
                tools.run_tool(ctx, name, args)
            except Exception as exc:  # noqa: BLE001
                notes.append(f"{name} failed on replay: {type(exc).__name__}")
                continue
            if name == "list_risks" and args.get("roles") is not None:
                roles_called = True
    return last[0], last[1], submissions, notes


def replay_recording(path: str | Path, cache_dir: str | Path | None = None, roots: list[Path] | None = None,
                     facts=None) -> Verdict:
    """One recording through the current checker. `facts` bypasses the lookup (tests, or a caller that has them)."""
    path = Path(path)
    t0 = time.perf_counter()
    rel = str(path)
    try:
        rec = load_recording(path)
    except (OSError, ValueError) as exc:
        return Verdict(rel, None, False, None, note=f"unreadable: {type(exc).__name__}", seconds=time.perf_counter() - t0)
    case = rec.get("case") or path.stem
    accepted_before = rec.get("exit") == "submitted"
    if rec.get("exit") is None and not any(tc.get("name") == "submit_geometry_plan"
                                            for t in rec.get("turns") or [] for tc in t.get("tool_calls") or []):
        return Verdict(rel, case, False, None, note="never finished (no exit, no submission)", seconds=time.perf_counter() - t0)
    case_dir = find_case_dir(case, roots if roots is not None else corpus_roots()) if facts is None else None
    request = _request_for(rec, case_dir)
    source = "given"
    if facts is None:
        caches = [Path(c) for c in ([cache_dir] if cache_dir else []) if c]
        env_cache = os.environ.get(FACTS_CACHE_ENV)
        if env_cache:
            caches.append(Path(env_cache))
        try:
            facts, source = _facts_for(case_dir, request, caches)
        except Exception as exc:  # noqa: BLE001 - a broken cache entry or geometry is a skip with its reason
            return Verdict(rel, case, accepted_before, None, note=f"facts failed: {type(exc).__name__}: {str(exc)[:120]}",
                           seconds=time.perf_counter() - t0)
        if facts is None:
            return Verdict(rel, case, accepted_before, None, note=source or "no facts", seconds=time.perf_counter() - t0)
    elif not request.get("purpose"):
        request["purpose"] = getattr(facts, "purpose", None) or "internal_cfd"
    try:
        accepted_now, errors, submissions, notes = replay_turns(rec, facts, request)
    except Exception as exc:  # noqa: BLE001 - a crash inside the replay is reported per transcript, never hidden
        return Verdict(rel, case, accepted_before, False if accepted_before else None,
                       new_rejections=[f"replay crashed: {type(exc).__name__}: {str(exc)[:200]}"] if accepted_before else [],
                       note=f"replay crashed: {type(exc).__name__}", seconds=time.perf_counter() - t0, facts_source=source or "")
    note = "; ".join(notes)
    if accepted_now is None:
        note = ("no submission in the recording; " + note).strip("; ")
    # the rejection messages travel on every rejected verdict; the verdict's `regressed` property and the
    # report's exit code are what decide whether they count against anything
    new = errors if accepted_now is False else []
    return Verdict(rel, case, accepted_before, accepted_now, new_rejections=new, note=note, submissions=submissions,
                   seconds=round(time.perf_counter() - t0, 2), facts_source=source or "")


def run(recordings: str | Path | None = None, cache_dir: str | Path | None = None, roots: list[str | Path] | None = None,
        only: list[str] | None = None, workers: int = 1, progress=None, thresholds=None, split: str = "unlocked",
        split_file: str | Path | None = None) -> Report:
    """Replay every recording under `recordings` (see recordings_dir) and report. `progress` is called with each
    Verdict as it lands. `thresholds` (a Thresholds) replays under those values instead of the ones in force,
    which is how the ship command measures a proposed move: `delta(run(), run(thresholds=proposed))`.

    `split` defaults to `unlocked`, so the gate a threshold move must pass never reads a locked export case
    (docs/eval_protocol.md, section 2); `all` asks for the locked ones back, and the report says how many were
    held out either way."""
    from geometry_agent.agent import prompt
    from geometry_agent.agent import thresholds as th

    if split not in SPLIT_CHOICES:
        raise ValueError(f"split must be one of {', '.join(SPLIT_CHOICES)}")
    if thresholds is not None:
        with th.override(thresholds):
            return run(recordings, cache_dir, roots, only=only, workers=workers, progress=progress, split=split,
                       split_file=split_file)
    rdir = recordings_dir(recordings)
    paths = find_recordings(rdir)
    if only:
        wanted = set(only)
        paths = [p for p in paths if p.stem in wanted or p.name in wanted]
    sides = split_sides(split_file)
    kept = [p for p in paths if keep_for_split(p, sides, split)]
    excluded = len(paths) - len(kept)
    paths = kept
    all_roots = corpus_roots(list(roots) if roots else None)
    verdicts: list[Verdict] = []

    def one(p: Path) -> Verdict:
        v = replay_recording(p, cache_dir=cache_dir, roots=all_roots)
        try:
            v.recording = str(p.relative_to(rdir))
        except ValueError:
            pass
        return v

    if workers > 1 and len(paths) > 1:
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=workers) as pool:
            for v in pool.map(one, paths):
                verdicts.append(v)
                if progress:
                    progress(v)
    else:
        for p in paths:
            v = one(p)
            verdicts.append(v)
            if progress:
                progress(v)
    return Report(verdicts=verdicts, thresholds_sha256=th.thresholds_sha256(), prompt_sha256=prompt.prompt_sha256(),
                  recordings_dir=str(rdir), split=split, excluded_by_split=excluded)


def delta(before: Report, after: Report) -> list[Verdict]:
    """The transcripts accepted under `before` and rejected under `after`: what a proposed threshold move breaks,
    with the checker held fixed, so drift the recordings already carry does not count against the move."""
    now = {v.recording: v for v in after.verdicts}
    out = []
    for b in before.verdicts:
        a = now.get(b.recording)
        if b.accepted_now is True and a is not None and a.accepted_now is False:
            out.append(Verdict(a.recording, a.case, True, False, new_rejections=list(a.new_rejections) or ["rejected under the proposed value"],
                               note=a.note, submissions=a.submissions, seconds=a.seconds, facts_source=a.facts_source))
    return out


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="replay_regression", description=__doc__.split("\n\n")[0])
    ap.add_argument("--recordings", default=None, help=f"recordings root (default ${RECORDINGS_ENV} or eval/recordings)")
    ap.add_argument("--facts-cache", default=None, help=f"facts cache dir (also ${FACTS_CACHE_ENV}); read only")
    ap.add_argument("--corpus-root", action="append", default=[], help="extra corpus root to find case dirs in (repeatable)")
    ap.add_argument("--only", default=None, help="comma-separated recording names")
    ap.add_argument("--split", default="unlocked", choices=SPLIT_CHOICES,
                    help="which side of the export split to replay (default unlocked: every recording except a locked "
                         "export case, the only set a threshold move may cite)")
    ap.add_argument("--split-file", default=None, help=f"the frozen split (default {DEFAULT_SPLIT_FILE})")
    ap.add_argument("--workers", type=int, default=1)
    ap.add_argument("--json", default=None, help="write the report here")
    ap.add_argument("--quiet", action="store_true", help="print only regressions and the summary")
    ap.add_argument("--proposed", default=None,
                    help="a thresholds JSON to compare against: replays under the values in force and under this file, and "
                         "exits 1 only on transcripts the proposed values reject that the current ones accept")
    a = ap.parse_args(argv)
    only = a.only.split(",") if a.only else None
    progress = (lambda v: print(v.line(), flush=True)) if not a.quiet else None
    report = run(a.recordings, a.facts_cache, a.corpus_root, only=only, workers=a.workers, progress=progress,
                 split=a.split, split_file=a.split_file)
    # verbose mode printed every verdict as it landed; the regressions are repeated under the summary either way
    print("\n" + report.text(verbose=False))
    out: dict[str, Any] = report.to_json()
    code = report.exit_code
    if a.proposed:
        from geometry_agent.agent import thresholds as th
        proposed = run(a.recordings, a.facts_cache, a.corpus_root, only=only, workers=a.workers, thresholds=th.load(a.proposed),
                       split=a.split, split_file=a.split_file)
        broken = delta(report, proposed)
        print(f"\nunder {a.proposed} (thresholds {proposed.thresholds_sha256[:12]}): {proposed.summary()['accepted_now']} accepted, "
              f"{len(broken)} accepted now but rejected under the proposed values")
        for v in broken:
            print(v.line())
        out["proposed"] = {"summary": proposed.summary(), "broken": [asdict(v) for v in broken]}
        code = 1 if broken else 0
    if a.json:
        Path(a.json).write_text(json.dumps(out, indent=1), encoding="utf-8")
    return code


if __name__ == "__main__":
    sys.exit(main())
