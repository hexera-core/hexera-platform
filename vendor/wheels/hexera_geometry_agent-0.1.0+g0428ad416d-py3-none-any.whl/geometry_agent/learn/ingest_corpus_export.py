"""The pipeline corpus export as OutcomeRecords: one per keyed case under eval/corpus_export_cases.

    python -m geometry_agent.learn.ingest eval/corpus_export_cases --source corpus_export

No agent ran in the export, so `agent.present` is false and the post-mortem scores the catalog on the cached
facts instead (stamped heuristic). The builder's attempts come from runs.json beside the STEP file. Labels are
copied from eval/labels/export_labels.json and never recomputed. Ingesting twice changes nothing: a record whose
content is unchanged keeps its first ingest date and is not rewritten.
"""
from __future__ import annotations

import json
import re
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

from geometry_agent.learn import store
from geometry_agent.learn.schema import (
    OUTCOME_SCHEMA_VERSION,
    AgentBlock,
    Attempt,
    BuilderBlock,
    Geometry,
    IntakeBlock,
    Labels,
    OutcomeRecord,
    Quality,
    assign_split,
    intake_topic,
    job_key,
)

GROUP_KEY = re.compile(r"^(.*?_\d{3})")
LABEL_COMPONENTS = ("poor_70_4", "poor_skew", "poor_non_ortho", "over_budget", "first_attempt_failed", "never_ran", "failed")


def group_key(case_name: str) -> str:
    """Kept identical to eval/labels/build_labels.py; the labels row's group wins when present."""
    family, sep, rest = case_name.partition("__")
    if not sep:
        family, rest = "", case_name
    m = GROUP_KEY.match(rest)
    stem = m.group(1) if m else rest
    return f"{family}__{stem}" if family else stem


@dataclass
class IngestReport:
    records: int = 0
    written: int = 0
    unchanged: int = 0
    missing_facts: list[str] = field(default_factory=list)
    missing_labels: list[str] = field(default_factory=list)
    missing_runs: int = 0
    split_counts: Counter = field(default_factory=Counter)
    label_counts: Counter = field(default_factory=Counter)
    paths: list[Path] = field(default_factory=list)

    def summary(self) -> str:
        parts = [f"{self.records} records ({self.written} written, {self.unchanged} unchanged)",
                 "split " + ", ".join(f"{k} {v}" for k, v in sorted(self.split_counts.items())),
                 "labels " + ", ".join(f"{k} {self.label_counts.get(k, 0)}" for k in LABEL_COMPONENTS)]
        if self.missing_facts:
            parts.append(f"no cached facts for {len(self.missing_facts)}: {self.missing_facts[:5]}")
        if self.missing_labels:
            parts.append(f"no label row for {len(self.missing_labels)}: {self.missing_labels[:5]}")
        if self.missing_runs:
            parts.append(f"no runs.json for {self.missing_runs}")
        return "; ".join(parts)


def _seconds(started: str | None, finished: str | None) -> float | None:
    if not started or not finished:
        return None
    try:
        return (datetime.fromisoformat(finished) - datetime.fromisoformat(started)).total_seconds()
    except ValueError:
        return None


def attempts_from_runs(runs: list[dict[str, Any]]) -> list[Attempt]:
    out = []
    for r in runs:
        score = r.get("score") or {}
        out.append(Attempt(
            index=int(r.get("run", len(out) + 1)), status=str(r.get("status")), dispatched=r.get("intake") == "dispatched",
            engine=r.get("engine"), job_id=r.get("job_id"), episode=r.get("episode"), intake=r.get("intake"),
            turns=r.get("turns"), started=r.get("started_utc"), finished=r.get("finished_utc"),
            seconds=_seconds(r.get("started_utc"), r.get("finished_utc")),
            quality=Quality(cells=score.get("cells"), max_skewness=score.get("max_skewness"),
                            max_non_orthogonality_deg=score.get("max_non_orthogonality_deg")),
        ))
    return out


def labels_from_row(row: dict[str, Any] | None) -> Labels:
    if row is None:
        return Labels()
    keep = {k: v for k, v in row.items() if k in Labels.model_fields}
    return Labels(**keep)


def record_for_case(case_dir: Path, exp: dict[str, Any], facts, label_row: dict[str, Any] | None,
                    runs: list[dict[str, Any]] | None, group_of: dict[str, str]) -> OutcomeRecord:
    case = case_dir.name
    outcome = exp.get("outcome") or {}
    std = next((e for e in facts.cell_estimates if e.tier == "standard"), None)
    fsha = store.facts_sha256(facts)
    questions = [q for q in (outcome.get("intake_questions") or []) if isinstance(q, str)]
    geometry = Geometry(
        case=case, source_path=str(exp.get("source")), sha256=facts.sha256, facts_sha256=fsha,
        facts_schema_version=facts.schema_version, family=exp.get("family"),
        group=(label_row or {}).get("group") or group_of.get(case) or group_key(case),
        representation=exp.get("representation"), engine=exp.get("engine"), purpose=str(exp.get("purpose")),
        unit=exp.get("unit_declared"), cell_cap=exp.get("cell_cap"), declared=list(exp.get("declared") or []),
        bbox_extent=tuple(facts.bbox.extent), n_openings=len(facts.openings),
        tier_estimates={e.tier: int(e.cells) for e in facts.cell_estimates},
        base_size=std.base_size if std else None, surface_cell=std.surface_cell if std else None,
    )
    return OutcomeRecord(
        schema_version=OUTCOME_SCHEMA_VERSION, job_key=job_key("corpus_export", case, fsha), source="corpus_export",
        geometry=geometry, agent=AgentBlock(present=False, policy="none"),
        builder=BuilderBlock(platform_revision=None, attempts=attempts_from_runs(runs or [])),
        labels=labels_from_row(label_row),
        intake=IntakeBlock(turns=outcome.get("intake_turns"), first_dispatched_turns=outcome.get("first_dispatched_turns"),
                           questions=questions, questions_by_topic=dict(Counter(intake_topic(q) for q in questions)),
                           brief=exp.get("brief")),
    )


def _same_apart_from_date(existing: Path, record: OutcomeRecord) -> str | None:
    """The existing record's ingest date when its content equals the new record's; None otherwise."""
    try:
        old = json.loads(existing.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    new = record.model_dump(mode="json")
    stamp = old.get("ingested")
    old.pop("ingested", None)
    new.pop("ingested", None)
    return stamp if old == new else None


def write_record(record: OutcomeRecord, outcomes_dir: Path) -> tuple[Path, bool]:
    """Returns the path and whether the file changed."""
    outcomes_dir = Path(outcomes_dir)
    outcomes_dir.mkdir(parents=True, exist_ok=True)
    path = outcomes_dir / f"{record.file_stem}.json"
    if path.exists():
        stamp = _same_apart_from_date(path, record)
        if stamp is not None:
            record.ingested = stamp
            return path, False
    path.write_text(record.model_dump_json(indent=1) + "\n", encoding="utf-8")
    return path, True


def load_case(case_dir: Path) -> dict[str, Any] | None:
    p = Path(case_dir) / "expected.json"
    if not p.exists():
        return None
    return store.read_json(p)


def runs_for(exp: dict[str, Any]) -> list[dict[str, Any]] | None:
    src = exp.get("source")
    if not src:
        return None
    p = Path(src).parent / "runs.json"
    if not p.exists():
        return None
    doc = store.read_json(p)
    return doc if isinstance(doc, list) else None


def ingest(cases_dir: Path = store.CASES_DIR, labels_json: Path = store.LABELS_JSON, split_file: Path = store.SPLIT_FILE,
           cache_dir: Path = store.DEFAULT_CACHE_DIR, outcomes_dir: Path = store.OUTCOMES_DIR,
           only: set[str] | None = None) -> IngestReport:
    """Every keyed case under cases_dir becomes one record. The locked sha list is the shas of the locked cases in
    this very export, so a twin that shares a locked case's file is locked with it."""
    cases_dir = Path(cases_dir)
    report = IngestReport()
    labels = store.labels_by_case(labels_json) if Path(labels_json).exists() else {}
    split = store.read_split(split_file)
    locked_names = set(split.get("locked", []))
    group_of = split.get("group_of", {})
    dirs = sorted(p for p in cases_dir.iterdir() if p.is_dir() and (p / "expected.json").exists())
    if only:
        dirs = [d for d in dirs if d.name in only]
    loaded: list[tuple[Path, dict[str, Any], Any]] = []
    locked_shas: set[str] = set()
    for d in dirs:
        exp = load_case(d)
        try:
            facts = store.cached_facts(exp["source"], exp.get("purpose", "internal_cfd"), cache_dir)
        except (store.FactsCacheMiss, FileNotFoundError, KeyError):
            report.missing_facts.append(d.name)
            continue
        loaded.append((d, exp, facts))
        if d.name in locked_names:
            locked_shas.add(facts.sha256)
    for d, exp, facts in loaded:
        row = labels.get(d.name)
        if row is None:
            report.missing_labels.append(d.name)
        runs = runs_for(exp)
        if runs is None:
            report.missing_runs += 1
        record = record_for_case(d, exp, facts, row, runs, group_of)
        assign_split(record, split, locked_shas)
        path, changed = write_record(record, outcomes_dir)
        report.records += 1
        report.written += int(changed)
        report.unchanged += int(not changed)
        report.split_counts[record.split] += 1
        for k in LABEL_COMPONENTS:
            if getattr(record.labels, k):
                report.label_counts[k] += 1
        report.paths.append(path)
    return report
