"""The feature bank (docs/dev_plan.md, P2): every number a calibrated rule may be fitted on, computed from the
cached facts and the case's declaration, in the builder's frame where the builder has one.

Two frames. The agent's surface cell is diagonal/80/4; the builder's wall cell is the declared inlet bore over
cells_across (24 by default, 16 and 40 as the sweep's neighbours), sized from the declared inlet only, and the
port cap sits one level coarser than the wall. Every "cells across" here is stated in the builder's frame; the
agent-frame numbers stay in the catalog.

FEATURES_VERSION and features_hash() stamp every row so a sweep or a ledger row can say which bank it was
computed under. A feature that is only an estimate says so in a `_method` column beside it.
"""
from __future__ import annotations

import csv
import hashlib
import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from geometry_agent.agent import catalog
from geometry_agent.facts.schema import GeometryFacts
from geometry_agent.learn import calibration, store

FEATURES_VERSION = 1
#: A mouth whose normal is within this of a coordinate axis is grid-aligned for snappy's castellation.
GRID_ALIGNED_TILT_DEG = 0.5
#: The builder refines everything within this fraction of the extent of the wall one level finer.
BAND_OVER_EXTENT = 0.08
#: A bore under this fraction of the extent sits entirely inside the near-wall band (twice the band).
BORE_IN_BAND_OVER_EXTENT = 2 * BAND_OVER_EXTENT
BUILDER_CELLS_ACROSS = (16, 24, 40)
BUILDER_CELLS_ACROSS_DEFAULT = 24
#: The port cap is one level coarser than the wall in the builder's renderer, hard-wired.
CAP_LEVEL_DELTA = -1
#: gmsh's default characteristic size as a fraction of the bounding diagonal.
GMSH_DEFAULT_SIZE_OF_DIAGONAL = 0.04
AXES = ((1.0, 0.0, 0.0), (0.0, 1.0, 0.0), (0.0, 0.0, 1.0))
AXIS_NAMES = ("x", "y", "z")

PORT_COLUMNS = (
    "case", "port_id", "name", "role", "kind", "shape", "tilt_deg", "grid_axis", "grid_aligned", "on_bbox_face",
    "bbox_side", "bore", "min_in_plane_dim", "bore_over_extent", "stub_over_d", "terminated_by", "junction_angle_deg",
    "junction_partner", "cap_level_delta", "cells_across_16", "cells_across_24", "cells_across_40",
)
CASE_COLUMNS = (
    "case", "family", "representation", "catalog_representation", "engine", "purpose", "n_ports", "n_declared",
    "extent_max", "inlet_bore", "inlet_bore_source", "wall_cell_24", "min_bore", "min_bore_over_extent",
    "min_bore_in_band", "smallest_port_id", "smallest_port_cells_across_16", "smallest_port_cells_across_24",
    "smallest_port_cells_across_40", "n_circular", "n_rectangular", "n_annular", "max_tilt_deg", "max_tilt_circular_deg",
    "n_tilted_circular", "all_grid_aligned", "min_stub_over_d", "min_outlet_stub_over_d", "min_junction_angle_deg",
    "band_coverage_fraction", "band_coverage_method", "thin_over_wall_cell", "gap_over_wall_cell",
    "tier_estimate", "tier_estimate_over_cap", "cell_correction", "refined_estimate_over_cap",
    "gmsh_default_elements_across_smallest_port", "features_version", "features_hash",
)


def features_hash() -> str:
    """The bank's identity: its version and the ordered column names. A new column or a renamed one changes it;
    a constant change bumps FEATURES_VERSION by hand."""
    text = f"v{FEATURES_VERSION}:" + ",".join(CASE_COLUMNS) + "|" + ",".join(PORT_COLUMNS)
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


@dataclass
class CaseContext:
    """What the feature bank needs beside the facts. Built from expected.json (features_for) or from a record
    (the post-mortem); never from a locked record inside this module."""
    case: str
    purpose: str = "internal_cfd"
    brief: str | None = None
    declared: list[dict[str, Any]] = field(default_factory=list)
    representation: str | None = None
    engine: str | None = None
    cell_cap: int | None = None
    family: str | None = None


def _norm(v) -> float:
    return math.sqrt(sum(c * c for c in v))


def tilt_of(normal) -> tuple[float, str]:
    """Degrees between a mouth normal and the nearest coordinate axis, and that axis."""
    n = _norm(normal)
    if n <= 0:
        return 90.0, "x"
    best = None
    for name, ax in zip(AXIS_NAMES, AXES):
        c = abs(sum(a * b for a, b in zip(normal, ax))) / n
        deg = math.degrees(math.acos(max(-1.0, min(1.0, c))))
        if best is None or deg < best[0]:
            best = (deg, name)
    return round(best[0], 4), best[1]


def port_shape(o, rep: str) -> str:
    if o.kind == "ring":
        if rep == "annular_fluid":
            return "annulus"
        return "circle" if o.shape == "circle" else ("rectangle" if o.shape == "rectangle" else "other")
    return {"circle": "circle", "rectangle": "rectangle"}.get(o.shape, "other")


def port_bore(o, rep: str) -> float:
    """The length the builder divides: a ring's bore on a wall shell, an annulus's hydraulic diameter, a cap's."""
    if o.kind == "ring" and o.bore_diameter:
        if rep == "annular_fluid":
            return max(0.0, o.hydraulic_diameter - o.bore_diameter)
        return o.bore_diameter
    return o.hydraulic_diameter


def min_in_plane_dim(o, rep: str) -> float:
    if o.kind == "ring" and o.bore_diameter:
        if rep == "annular_fluid":
            return max(0.0, (o.hydraulic_diameter - o.bore_diameter) / 2.0)
        lo, hi = min(o.width, o.height), max(o.width, o.height)
        return o.bore_diameter * (lo / hi if hi > 0 else 1.0)
    return min(o.width, o.height) if o.width and o.height else o.hydraulic_diameter


def match_declared(facts: GeometryFacts, ports: list, declared: list[dict[str, Any]], rep: str) -> dict[str, dict[str, Any]]:
    """opening id -> the declaration it carries (name, role, bore), by the catalog's own area band and location
    rule (catalog._match keeps only the leftovers, so the pairing is redone here with the same scores)."""
    remaining = {o.id: o for o in ports}
    out: dict[str, dict[str, Any]] = {}
    for d in declared or []:
        best = None
        for oid, o in remaining.items():
            score = 0.0
            area = d.get("area")
            if area:
                o_area = catalog.port_area(facts, o, rep)  # type: ignore[arg-type]
                if o_area <= 0 or abs(o_area / area - 1.0) > catalog.AREA_MATCH_BAND:
                    continue
                score += abs(o_area / area - 1.0)
            near = d.get("near")
            if near:
                dist = math.dist(near, o.centroid)
                if dist > catalog.NEAR_MATCH_OVER_D * o.hydraulic_diameter:
                    continue
                score += dist / max(o.hydraulic_diameter, 1e-9)
            if best is None or score < best[0]:
                best = (score, oid)
        if best is not None:
            out[best[1]] = d
            del remaining[best[1]]
    return out


def declared_bore(d: dict[str, Any]) -> float | None:
    if d.get("bore_diameter"):
        return float(d["bore_diameter"])
    if d.get("area"):
        return math.sqrt(4.0 * float(d["area"]) / math.pi)
    return None


def inlet_bore_for(ports_rows: list[dict[str, Any]], declared: list[dict[str, Any]]) -> tuple[float | None, str]:
    """The builder sizes its wall cell from the declared inlet only; the largest port stands in when none."""
    for d in declared or []:
        if d.get("role") == "inlet":
            b = declared_bore(d)
            if b:
                return b, "declared_inlet"
    bores = [r["bore"] for r in ports_rows if r.get("bore")]
    if bores:
        return max(bores), "largest_port"
    return None, "none"


def junction_angles(facts: GeometryFacts, ports: list, bores: dict[str, float]) -> dict[str, tuple[float, str]]:
    """Where two stubs end within one bore of each other, the angle between their inward directions: the
    junction each port runs into. Each port keeps its nearest partner."""
    ends = {}
    for o in ports:
        s = facts.stub(o.id)
        if s is not None and s.end_point and s.inward_direction:
            ends[o.id] = (s.end_point, s.inward_direction)
    out: dict[str, tuple[float, str]] = {}
    ids = list(ends)
    best_dist: dict[str, float] = {}
    for i, a in enumerate(ids):
        for b in ids[i + 1:]:
            pa, da = ends[a]
            pb, db = ends[b]
            dist = math.dist(pa, pb)
            if dist > max(bores.get(a, 0.0), bores.get(b, 0.0)):
                continue
            c = sum(x * y for x, y in zip(da, db)) / max(_norm(da) * _norm(db), 1e-12)
            ang = round(math.degrees(math.acos(max(-1.0, min(1.0, c)))), 3)
            for me, other in ((a, b), (b, a)):
                if me not in best_dist or dist < best_dist[me]:
                    best_dist[me] = dist
                    out[me] = (ang, other)
    return out


def band_coverage(facts: GeometryFacts, rep: str, purpose: str, port_rows: list[dict[str, Any]]) -> tuple[float | None, str]:
    """The fraction of the fluid volume inside the builder's near-wall band (BAND_OVER_EXTENT of the extent).
    No stage measures it, so it is estimated and the method is named beside it: for a fluid body the slab
    bound (surface area times the band over the volume); for a wall shell, whose cavity is not measured, the
    tube formula on each port's bore; for an external body the band around the body over the far-field box."""
    t = BAND_OVER_EXTENT * max(facts.bbox.extent)
    if purpose == "external_cfd" or rep == "external":
        est = next((e for e in facts.cell_estimates if e.tier == "standard"), None)
        if est and est.domain_volume > 0:
            return round(min(1.0, facts.total_surface_area * t / est.domain_volume), 6), "surface_area_times_band_over_domain_volume"
        return None, "none"
    if rep == "wall_shell":
        bores = [r["bore"] for r in port_rows if r.get("bore")]
        if not bores:
            return None, "none"
        fr = [1.0 - max(0.0, 1.0 - 2.0 * t / b) ** 2 for b in bores]
        return round(sum(fr) / len(fr), 6), "tube_from_port_bores"
    vol = facts.total_volume
    if vol and vol > 0:
        return round(min(1.0, facts.total_surface_area * t / vol), 6), "surface_area_times_band_over_volume"
    return None, "none"


def _r(x, nd=6):
    return None if x is None else round(float(x), nd)


def compute(facts: GeometryFacts, ctx: CaseContext) -> dict[str, Any]:
    """The per-case row and the per-port rows for one geometry. Deterministic: the same facts and context give
    the same numbers, with no date or path inside."""
    rep = catalog.representation(facts, ctx.purpose, ctx.brief, declared=ctx.declared)  # type: ignore[arg-type]
    ports = catalog.port_openings(facts, rep, ctx.declared)
    decl = match_declared(facts, ports, ctx.declared, rep)
    extent = max(facts.bbox.extent)
    bores = {o.id: port_bore(o, rep) for o in ports}
    junctions = junction_angles(facts, ports, bores)
    port_rows: list[dict[str, Any]] = []
    for o in ports:
        tilt, axis = tilt_of(o.normal)
        s = facts.stub(o.id)
        d = decl.get(o.id, {})
        j = junctions.get(o.id)
        port_rows.append({
            "case": ctx.case, "port_id": o.id, "name": d.get("name"), "role": d.get("role"), "kind": o.kind,
            "shape": port_shape(o, rep), "tilt_deg": tilt, "grid_axis": axis, "grid_aligned": tilt < GRID_ALIGNED_TILT_DEG,
            "on_bbox_face": bool(o.on_bbox_face), "bbox_side": o.bbox_side, "bore": _r(bores[o.id]),
            "min_in_plane_dim": _r(min_in_plane_dim(o, rep)), "bore_over_extent": _r(bores[o.id] / extent if extent else None),
            "stub_over_d": _r(s.length_over_diameter if s else None, 4), "terminated_by": s.terminated_by if s else None,
            "junction_angle_deg": j[0] if j else None, "junction_partner": j[1] if j else None,
            "cap_level_delta": CAP_LEVEL_DELTA,
        })
    inlet_bore, inlet_src = inlet_bore_for(port_rows, ctx.declared)
    wall_cells = {n: (inlet_bore / n if inlet_bore else None) for n in BUILDER_CELLS_ACROSS}
    for r in port_rows:
        for n in BUILDER_CELLS_ACROSS:
            wc = wall_cells[n]
            r[f"cells_across_{n}"] = _r(r["bore"] / wc if (wc and r["bore"]) else None, 3)
    smallest = min(port_rows, key=lambda r: r["bore"]) if port_rows else None
    circular = [r for r in port_rows if r["shape"] == "circle"]
    est = next((e for e in facts.cell_estimates if e.tier == "standard"), None)
    tier = int(est.cells) if est else None
    corr = calibration.cell_correction(ctx.representation)
    cov, cov_method = band_coverage(facts, rep, ctx.purpose, port_rows)
    wc24 = wall_cells[BUILDER_CELLS_ACROSS_DEFAULT]
    thick = facts.features.thickness_min
    gap = facts.features.min_gap
    outlet_stubs = [r["stub_over_d"] for r in port_rows if r["role"] == "outlet" and r["stub_over_d"] is not None]
    stubs = [r["stub_over_d"] for r in port_rows if r["stub_over_d"] is not None]
    gmsh_size = GMSH_DEFAULT_SIZE_OF_DIAGONAL * facts.bbox.diagonal
    case_row: dict[str, Any] = {
        "case": ctx.case, "family": ctx.family, "representation": ctx.representation, "catalog_representation": rep,
        "engine": ctx.engine, "purpose": ctx.purpose, "n_ports": len(port_rows), "n_declared": len(ctx.declared or []),
        "extent_max": _r(extent), "inlet_bore": _r(inlet_bore), "inlet_bore_source": inlet_src, "wall_cell_24": _r(wc24),
        "min_bore": smallest["bore"] if smallest else None,
        "min_bore_over_extent": smallest["bore_over_extent"] if smallest else None,
        "min_bore_in_band": (smallest["bore_over_extent"] < BORE_IN_BAND_OVER_EXTENT) if smallest and smallest["bore_over_extent"] is not None else None,
        "smallest_port_id": smallest["port_id"] if smallest else None,
        "smallest_port_cells_across_16": smallest["cells_across_16"] if smallest else None,
        "smallest_port_cells_across_24": smallest["cells_across_24"] if smallest else None,
        "smallest_port_cells_across_40": smallest["cells_across_40"] if smallest else None,
        "n_circular": len(circular), "n_rectangular": sum(r["shape"] == "rectangle" for r in port_rows),
        "n_annular": sum(r["shape"] == "annulus" for r in port_rows),
        "max_tilt_deg": max((r["tilt_deg"] for r in port_rows), default=None),
        "max_tilt_circular_deg": max((r["tilt_deg"] for r in circular), default=None),
        "n_tilted_circular": sum(not r["grid_aligned"] for r in circular),
        "all_grid_aligned": all(r["grid_aligned"] for r in port_rows) if port_rows else None,
        "min_stub_over_d": min(stubs) if stubs else None,
        "min_outlet_stub_over_d": min(outlet_stubs) if outlet_stubs else None,
        "min_junction_angle_deg": min((r["junction_angle_deg"] for r in port_rows if r["junction_angle_deg"] is not None), default=None),
        "band_coverage_fraction": cov, "band_coverage_method": cov_method,
        "thin_over_wall_cell": _r(thick / wc24 if (wc24 and thick) else None, 4),
        "gap_over_wall_cell": _r(gap / wc24 if (wc24 and gap) else None, 4),
        "tier_estimate": tier,
        "tier_estimate_over_cap": _r(tier / ctx.cell_cap if (tier and ctx.cell_cap) else None, 4),
        "cell_correction": corr,
        "refined_estimate_over_cap": _r(tier * corr / ctx.cell_cap if (tier and ctx.cell_cap) else None, 4),
        "gmsh_default_elements_across_smallest_port": _r(smallest["bore"] / gmsh_size if (smallest and gmsh_size > 0) else None, 3),
        "features_version": FEATURES_VERSION, "features_hash": features_hash(),
    }
    return {"case": case_row, "ports": port_rows}


def context_from_expected(case: str, exp: dict[str, Any]) -> CaseContext:
    return CaseContext(case=case, purpose=str(exp.get("purpose", "internal_cfd")), brief=exp.get("brief"),
                       declared=list(exp.get("declared") or []), representation=exp.get("representation"),
                       engine=exp.get("engine"), cell_cap=exp.get("cell_cap"), family=exp.get("family"))


def features_for(case: str, cases_dir: Path = store.CASES_DIR, cache_dir: Path = store.DEFAULT_CACHE_DIR) -> dict[str, Any]:
    """The bank for one keyed case, from its expected.json and the cached facts. Never opens a record."""
    exp = store.read_json(Path(cases_dir) / case / "expected.json")
    facts = store.cached_facts(exp["source"], exp.get("purpose", "internal_cfd"), cache_dir)
    return compute(facts, context_from_expected(case, exp))


def _write_csv(path: Path, rows: list[dict[str, Any]], columns: tuple[str, ...]) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=columns)
        w.writeheader()
        for r in rows:
            w.writerow({k: ("" if r.get(k) is None else r.get(k)) for k in columns})
    return path


def read_features_csv(path: Path = store.FEATURES_CSV) -> list[dict[str, Any]]:
    """The per-case table with numbers typed back (empty -> None, True/False, floats)."""
    p = Path(path)
    if not p.exists():
        return []
    out = []
    with p.open(newline="", encoding="utf-8") as fh:
        for row in csv.DictReader(fh):
            typed: dict[str, Any] = {}
            for k, v in row.items():
                if v == "" or v is None:
                    typed[k] = None
                elif v in ("True", "False"):
                    typed[k] = v == "True"
                else:
                    try:
                        f = float(v)
                        typed[k] = int(f) if f.is_integer() and "." not in v else f
                    except ValueError:
                        typed[k] = v
            out.append(typed)
    return out


def write_bank(cases_dir: Path = store.CASES_DIR, cache_dir: Path = store.DEFAULT_CACHE_DIR, split_file: Path = store.SPLIT_FILE,
               out_csv: Path = store.FEATURES_CSV, out_locked_csv: Path = store.FEATURES_LOCKED_CSV,
               only: set[str] | None = None) -> dict[str, Any]:
    """features.csv for the learning (and unassigned) cases and features_locked.csv for the locked ones, decided
    by case name from the split file. Port rows go beside each in features_ports.csv / features_ports_locked.csv."""
    split = store.read_split(split_file)
    locked = set(split.get("locked", []))
    learn_rows, learn_ports, lock_rows, lock_ports, missing = [], [], [], [], []
    for d in sorted(p for p in Path(cases_dir).iterdir() if p.is_dir() and (p / "expected.json").exists()):
        if only and d.name not in only:
            continue
        try:
            bank = features_for(d.name, cases_dir, cache_dir)
        except (store.FactsCacheMiss, FileNotFoundError):
            missing.append(d.name)
            continue
        if d.name in locked:
            lock_rows.append(bank["case"])
            lock_ports.extend(bank["ports"])
        else:
            learn_rows.append(bank["case"])
            learn_ports.extend(bank["ports"])
    out_csv, out_locked_csv = Path(out_csv), Path(out_locked_csv)
    _write_csv(out_csv, learn_rows, CASE_COLUMNS)
    _write_csv(out_csv.with_name(out_csv.stem + "_ports.csv"), learn_ports, PORT_COLUMNS)
    _write_csv(out_locked_csv, lock_rows, CASE_COLUMNS)
    _write_csv(out_locked_csv.with_name(out_locked_csv.stem + "_ports.csv"), lock_ports, PORT_COLUMNS)
    return {"learning_rows": len(learn_rows), "locked_rows": len(lock_rows), "missing_facts": missing,
            "features_hash": features_hash(), "features_version": FEATURES_VERSION,
            "csv": str(out_csv), "locked_csv": str(out_locked_csv)}
