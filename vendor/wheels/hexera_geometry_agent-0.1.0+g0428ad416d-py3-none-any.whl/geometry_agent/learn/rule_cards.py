"""Rule cards, generated from the learning ledger and the sweep files on every ingest (docs/dev_plan.md, P2):
docs/rule_cards.md for people, eval/rule_cards.json for code. One card per warning kind.

Reads eval/ledger.jsonl (learning rows), eval/calib/sweeps/*.json (fitted on learning rows), kind_labels.json and
agent/thresholds.json when it exists. Never the locked ledger, a locked record or the locked feature table.
Until worst patches exist every hit is grade B and every card says so. builder_policy_sensitivity is null until
the strict counterfactual runs (P5).

Two things every card says in words, at its top, because a column a reader can miss is not a finding:
`baseline_says` is what the sweep concluded against a guess from the case's family (every calibrated rule in
the corpus today ties that guess or loses to it), and `within_family_says` names the families the rule gives the
same answer on every case of. `meta.stamp` carries the agent git sha and a hash of the catalog kind tables, and
`stamp_mismatch` reports a card file built against a different catalog, so a stale file is detectable rather
than remembered (tests/test_instruments.py refuses one).
"""
from __future__ import annotations

import hashlib
import json
from collections import Counter, defaultdict
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from geometry_agent.agent import catalog
from geometry_agent.learn import store
from geometry_agent.learn.postmortem import BANK_CUTOFFS, KIND_THRESHOLD_KEY

#: The sweep each kind's threshold is fitted by (the first is the card's mcc_cv; the rest are listed).
KIND_SWEEPS: dict[str, list[str]] = {
    "tilted_circular_mouth": ["port_tilt"],
    "budget_forecast": ["tier_estimate_over_cap", "min_bore_over_extent"],
    "port_resolution": ["smallest_port_cells_across_24"],
    "gap_resolution": ["gap_over_wall_cell"],
    "thin_feature": ["thin_over_wall_cell"],
    "short_stub": ["min_outlet_stub_over_d"],
}
#: Kinds whose threshold lives in the bank, stated in the builder's frame.
BUILDER_FRAME_KINDS = {"tilted_circular_mouth", "budget_forecast", "gmsh_size", "seed_point"}
#: Kinds that report a measured fact with no threshold to calibrate.
FACT_KINDS = {"not_watertight", "surface_holes", "nested_bodies", "region_purpose_mismatch", "solid_wall_representation",
              "wall_shell_to_carve", "annular_ports", "ring_faces_present", "multi_body_external", "external_domain",
              "symmetry_opportunity", "solid_fluid_pair", "unshared_interface", "no_shared_interface", "internal_void",
              "export_debris", "inconsistent_normals", "surface_2d", "undeclared_opening", "unit_unknown", "unit_implausible",
              "operating_point_missing", "cell_cap", "knife_edge"}
GRADE_NOTE = "every hit is grade B (case level) until worst patches exist; grade A needs the worst patch among the warning's patches"
#: The catalog tables a card's kind, audience and threshold key are read from. The stamp is over these, so a
#: commit that changes one of them makes every committed card detectably stale (docs/learning_loop.md, section 8:
#: the cards said the flagship calibrated rule had never fired for two days because nobody re-ran the ingest).
STAMPED_CATALOG_TABLES = ("KIND_AUDIENCE", "KIND_THRESHOLD", "MESH_WARNING_KINDS", "CALIBRATED_KINDS")
#: A card whose baseline verdict is one of these has not earned its place: it must say so in words, at the top of
#: the card, not in a column.
LOSING_VERDICTS = ("ties_family_only", "loses_to_family_only", "not_scored")


def catalog_kinds_sha256() -> str:
    """A hash of the catalog kind tables the cards are built from, canonical and order independent."""
    doc: dict[str, Any] = {}
    for name in STAMPED_CATALOG_TABLES:
        table = getattr(catalog, name, None)
        if isinstance(table, dict):
            doc[name] = dict(sorted(table.items()))
        elif table is not None:
            doc[name] = sorted(table)
    return hashlib.sha256(json.dumps(doc, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()


def current_stamp() -> dict[str, Any]:
    """What the checkout would write today: the agent git sha and the catalog kind hash."""
    from geometry_agent.evaluate import agent_git_sha
    return {"agent_git_sha": agent_git_sha(), "catalog_kinds_sha256": catalog_kinds_sha256(),
            "stamped_tables": list(STAMPED_CATALOG_TABLES)}


def stamp_mismatch(doc: dict[str, Any]) -> list[str]:
    """Why a card file is STALE against this checkout, one line each; empty when it is not.

    Only the catalog kind hash decides this. The git sha moves on every commit, including commits that touch
    nothing the cards read, so it is a note (`stamp_note`) and never a failure: a gate that cried wolf on every
    commit would be turned off within a week, and the thing it must catch is a change to the tables themselves."""
    stamp = doc.get("meta", {}).get("stamp") if isinstance(doc.get("meta"), dict) else None
    if not isinstance(stamp, dict):
        return ["the card file carries no stamp: regenerate it (python -m geometry_agent.learn.ingest ...)"]
    now = current_stamp()
    if stamp.get("catalog_kinds_sha256") != now["catalog_kinds_sha256"]:
        return [f"catalog kind tables {', '.join(STAMPED_CATALOG_TABLES)} hash to {now['catalog_kinds_sha256'][:12]} in this "
                f"checkout, the cards were built at {str(stamp.get('catalog_kinds_sha256'))[:12]}: the cards are stale, "
                "re-run the ingest (docs/learning_loop.md, section 2)"]
    return []


def stamp_note(doc: dict[str, Any]) -> str | None:
    """The cards were built at another commit, with the kind tables unchanged: worth saying, never a failure."""
    stamp = doc.get("meta", {}).get("stamp") if isinstance(doc.get("meta"), dict) else None
    if not isinstance(stamp, dict) or stamp_mismatch(doc):
        return None
    now = current_stamp()
    if stamp.get("agent_git_sha") and now["agent_git_sha"] and stamp["agent_git_sha"] != now["agent_git_sha"]:
        return (f"the cards were built at agent {str(stamp['agent_git_sha'])[:12]}, the checkout is at "
                f"{str(now['agent_git_sha'])[:12]}; the kind tables are unchanged, so the cards still hold")
    return None


def baseline_verdict(primary: dict[str, Any] | None) -> tuple[str, str]:
    """What the sweep says about this rule against a family-only guess, as (slug, one sentence).

    The sentence exists because a column a reader can miss is not a finding. Every calibrated rule in the corpus
    today ties the family baseline or loses to it, and the card has to open with that."""
    if primary is None:
        return "not_scored", ("No sweep has scored this kind against a label, so nothing here says whether it beats a guess "
                              "from the case's family.")
    if primary.get("simulation_rule"):
        return "simulation_rule", ("A simulation rule: it is never scored against a mesh label, so it has no baseline to beat. "
                                   "The numbers below are counts, not performance.")
    cv = (primary.get("cv_grouped") or {}).get("mcc")
    fam = ((primary.get("baselines") or {}).get("family_only") or {})
    fam_mcc = (fam.get("logo") or {}).get("mcc")
    agree = fam.get("agreement_with_rule") or {}
    if primary.get("verdict") == "beats_baselines":
        return "beats_baselines", (f"Beats both baselines: grouped cross-validated MCC {cv} against family-only {fam_mcc} and "
                                   "flag-everything 0.0.")
    if primary.get("ties_family_baseline_grouped"):
        tail = ""
        if agree.get("identical"):
            tail = (f" On the learning half the two predictors agree on all {agree.get('n')} cases, so the rule flags exactly the "
                    "cases the family label would have flagged and adds nothing to it.")
        elif agree.get("n"):
            tail = f" They differ on {agree.get('different')} of {agree.get('n')} cases."
        return "ties_family_only", (f"DOES NOT BEAT THE BASELINE. It ties the family-only guess: grouped cross-validated MCC {cv}, "
                                    f"the same as predicting from the case's family alone.{tail}")
    return "loses_to_family_only", (f"DOES NOT BEAT THE BASELINE. It loses to the family-only guess: grouped cross-validated MCC "
                                    f"{cv} against family-only {fam_mcc}. Predicting from the case's family alone is better than "
                                    "this rule.")


def within_family_note(primary: dict[str, Any] | None) -> str | None:
    """What the rule does inside the families that carry both labels, in words. A rule that fires on every case
    of a family, or on none, has separated nothing there."""
    if primary is None or primary.get("simulation_rule"):
        return None
    wf = primary.get("within_family") or {}
    if not wf:
        return None
    def separates(v: dict[str, Any]) -> bool | None:
        """A sweep written before the flag existed still carries the counts it is read from; a block with
        neither says nothing and is left out rather than reported as a blindness it may not have."""
        if isinstance(v.get("separates"), bool):
            return v["separates"]
        if isinstance(v.get("n_fire"), int) and isinstance(v.get("n"), int):
            return 0 < v["n_fire"] < v["n"]
        return None

    blind = [f"{fam} (fires on {v['n_fire']} of {v['n']})" for fam, v in sorted(wf.items()) if separates(v) is False]
    if not blind:
        return "Inside every family that carries both labels it fires on some cases and not others."
    seeing = sorted(f for f, v in wf.items() if separates(v))
    tail = f" It does separate inside {', '.join(seeing)}." if seeing else ""
    return ("It separates nothing inside " + ", ".join(blind)
            + ": every case there gets the same answer, so the rule is carrying the family label, not the geometry." + tail)


def run_of(job_key: Any) -> str:
    """Which run a ledger row came from: `live/<sha>__<case>@<run>` names it, anything else is its source."""
    key = str(job_key or "")
    if key.startswith("live/") and "@" in key:
        return key.rsplit("@", 1)[1]
    return key.split("/", 1)[0] or "unknown"


def _thresholds_table() -> dict[str, Any]:
    if store.THRESHOLDS_JSON.exists():
        try:
            return store.read_json(store.THRESHOLDS_JSON)
        except (OSError, ValueError):
            return {}
    return {}


def threshold_for(kind: str, table: dict[str, Any]) -> dict[str, Any]:
    key = KIND_THRESHOLD_KEY.get(kind)
    if not key:
        return {"threshold_key": None, "threshold_value": None, "threshold_source": None, "rule_class": "measured_fact" if kind in FACT_KINDS else None}
    entry = table.get(key) if isinstance(table, dict) else None
    if isinstance(entry, dict) and "value" in entry:
        return {"threshold_key": key, "threshold_value": entry.get("value"), "threshold_source": "agent/thresholds.json",
                "rule_class": entry.get("rule_class"), "threshold_status": entry.get("status"),
                "threshold_unit_or_frame": entry.get("unit_or_frame")}
    if hasattr(catalog, key):
        return {"threshold_key": key, "threshold_value": getattr(catalog, key), "threshold_source": "catalog constant",
                "rule_class": "physics_rule"}
    return {"threshold_key": key, "threshold_value": BANK_CUTOFFS.get(key), "threshold_source": "bank candidate cutoff",
            "rule_class": "calibrated"}


def read_sweeps(sweeps_dir: Path = store.SWEEPS_DIR) -> dict[str, list[dict[str, Any]]]:
    """rule -> its sweep documents, oldest first."""
    out: dict[str, list[dict[str, Any]]] = defaultdict(list)
    d = Path(sweeps_dir)
    if not d.is_dir():
        return {}
    for p in sorted(d.glob("*.json")):
        try:
            doc = store.read_json(p)
        except (OSError, ValueError):
            continue
        if doc.get("split") != "learning":
            continue
        doc["_file"] = p.name
        out[doc.get("rule", p.stem)].append(doc)
    for docs in out.values():
        docs.sort(key=lambda x: (x.get("date") or "", x["_file"]))
    return dict(out)


def _sweep_summary(doc: dict[str, Any]) -> dict[str, Any]:
    if doc.get("simulation_rule"):
        return {"file": doc["_file"], "date": doc.get("date"), "verdict": doc.get("verdict"), "n": doc.get("n_rows_with_measure"),
                "counts": [{"threshold": c["threshold"], "n_fire": c["n_fire"], "n": c["n"]} for c in doc.get("candidates", [])
                           if c["threshold"] in (2.0, 5.0)]}
    b = doc.get("best") or {}
    fam = (doc.get("baselines") or {}).get("family_only") or {}
    return {"file": doc["_file"], "date": doc.get("date"), "verdict": doc.get("verdict"), "n": doc.get("n"), "n_positive": doc.get("n_positive"),
            "base_rate": doc.get("base_rate"), "best_threshold": b.get("threshold"), "fires": b.get("n_fire"), "precision": b.get("precision"),
            "recall": b.get("recall"), "lift": b.get("lift"), "mcc": b.get("mcc"),
            "mcc_cv_grouped": (doc.get("cv_grouped") or {}).get("mcc"), "mcc_cv_family": (doc.get("cv") or {}).get("mcc"),
            "threshold_band_grouped": (doc.get("cv_grouped") or {}).get("threshold_band"),
            "family_baseline_mcc_grouped": (fam.get("logo") or {}).get("mcc"), "family_baseline_mcc_in_sample": (fam.get("in_sample") or {}).get("mcc"),
            "family_baseline_mcc_lofo": (fam.get("lofo") or {}).get("mcc"),
            "family_baseline_agreement": fam.get("agreement_with_rule"),
            "flag_everything": (doc.get("baselines") or {}).get("flag_everything"), "within_family": doc.get("within_family")}


def build_cards(ledger: Path = store.LEDGER, sweeps_dir: Path = store.SWEEPS_DIR, kind_labels_path: Path = store.KIND_LABELS) -> dict[str, Any]:
    rows = store.read_jsonl(ledger)
    rows = [r for r in rows if r.get("split") == "learning"]
    kind_labels = store.read_json(kind_labels_path) if Path(kind_labels_path).exists() else {"kinds": {}}
    kinds_spec: dict[str, Any] = kind_labels.get("kinds", {})
    sweeps = read_sweeps(sweeps_dir)
    thresholds = _thresholds_table()
    by_kind: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for r in rows:
        by_kind[r["kind"]].append(r)
    for k in kinds_spec:
        by_kind.setdefault(k, [])
    cards = []
    for kind in sorted(by_kind):
        krows = by_kind[kind]
        spec = kinds_spec.get(kind, {})
        verdicts = Counter(r["verdict"] for r in krows)
        miss_kinds = Counter(r.get("miss_kind") for r in krows if r["verdict"] == "miss")
        audience = spec.get("audience") or (krows[0]["audience"] if krows else "user")
        fires = sum(bool(r.get("fired")) for r in krows)
        hit, miss, fa, acted, unt, clean = (verdicts.get(v, 0) for v in ("hit", "miss", "false_alarm", "acted", "untestable", "clean"))
        testable = hit + miss + fa + acted + clean
        fired_testable = hit + fa + acted
        poor_given_fire = round(hit / fired_testable, 4) if fired_testable else None
        poor_given_not = round(miss / (miss + clean), 4) if (miss + clean) else None
        base = (hit + miss) / testable if testable else None
        lift = round(poor_given_fire / base, 3) if (poor_given_fire is not None and base) else None
        thr = threshold_for(kind, thresholds)
        sweep_docs = [(name, sweeps.get(name, [])) for name in KIND_SWEEPS.get(kind, [])]
        latest = [(name, docs[-1]) for name, docs in sweep_docs if docs]
        primary = latest[0][1] if latest else None
        history = [{"sweep": name, **_sweep_summary(d)} for name, docs in sweep_docs for d in docs]
        misses = [r for r in krows if r["verdict"] == "miss"]
        misses.sort(key=lambda r: (r.get("date") or "", r["case"]), reverse=True)
        verdict_slug, verdict_says = baseline_verdict(primary)
        card = {
            "kind": kind, "audience": audience, "component": spec.get("component"),
            "baseline_verdict": verdict_slug, "baseline_says": verdict_says,
            "within_family_says": within_family_note(primary),
            # a kind with no threshold key at all is one the analyst invented in its own run: it is not a physics
            # rule, it is uncalibrated, and calling it physics_rule put 20 agent kinds in the wrong column
            "rule_class": thr.get("rule_class") or ("calibrated" if kind in BUILDER_FRAME_KINDS
                                                    else "physics_rule" if thr.get("threshold_key") else "uncalibrated"),
            "threshold_key": thr.get("threshold_key"), "threshold_value": thr.get("threshold_value"), "threshold_source": thr.get("threshold_source"),
            "threshold_status": thr.get("threshold_status"),
            "frame": "builder" if (kind in BUILDER_FRAME_KINDS or audience == "builder") else "agent",
            "stratum": spec.get("stratum") or {}, "n": len(krows), "records": len({r["job_key"] for r in krows}), "fires": fires,
            "bank_fires": sum(bool(r.get("bank_fired")) for r in krows),
            "hit": hit, "hit_grades": dict(Counter(r.get("grade") for r in krows if r["verdict"] == "hit")),
            "miss": miss, "miss_silent": miss_kinds.get("silent", 0), "miss_unexplained": miss_kinds.get("unexplained", 0),
            "false_alarm": fa, "acted": acted, "untestable": unt, "clean": clean,
            "poor_given_fire": poor_given_fire, "poor_given_not": poor_given_not, "base_rate": round(base, 4) if base is not None else None, "lift": lift,
            "mcc_cv": ((primary.get("cv_grouped") or {}).get("mcc") if primary and not primary.get("simulation_rule") else None),
            "mcc_cv_family": ((primary.get("cv") or {}).get("mcc") if primary and not primary.get("simulation_rule") else None),
            "family_baseline": ((primary.get("baselines") or {}).get("family_only", {}).get("logo", {}).get("mcc") if primary and not primary.get("simulation_rule") else None),
            "family_baseline_agreement": ((primary.get("baselines") or {}).get("family_only", {}).get("agreement_with_rule")
                                          if primary and not primary.get("simulation_rule") else None),
            "within_family": (primary.get("within_family") if primary and not primary.get("simulation_rule") else None),
            "flag_everything_baseline": ((primary.get("baselines") or {}).get("flag_everything") if primary and not primary.get("simulation_rule") else None),
            "sweep_verdict": primary.get("verdict") if primary else None,
            "builder_policy_sensitivity": None,
            "last_fit": primary.get("date") if primary else None,
            "history": history,
            "recent_misses": [{"case": r["case"], "miss_kind": r.get("miss_kind"), "bank_location": r.get("bank_location"), "date": r.get("date")} for r in misses[:5]],
            "false_alarm_reasons": dict(Counter(r.get("reason") for r in krows if r["verdict"] == "false_alarm").most_common(3)),
            "policy": dict(Counter(r.get("policy") for r in krows)),
            # the ledger pools every run it has ingested, so the card says which; a pooled rate over two runs of
            # different prompts is nobody's number (docs/audit_2026-09-11.md, finding 4)
            "runs": dict(Counter(run_of(r.get("job_key")) for r in krows)),
            "grade_note": GRADE_NOTE,
        }
        cards.append(card)
    order = {"builder": 0, "note": 1, "user": 2}
    cards.sort(key=lambda c: (order.get(c["audience"], 3), -c["fires"], c["kind"]))
    meta = {
        "generated": datetime.now(UTC).isoformat(timespec="seconds"), "stamp": current_stamp(),
        "ledger": str(ledger), "ledger_rows": len(rows),
        "records": len({r["job_key"] for r in rows}), "split": "learning",
        "split_sha256": next((r.get("split_sha256") for r in rows), None),
        "features_hash": sorted({r.get("features_hash") for r in rows if r.get("features_hash")}),
        "label_version": sorted({r.get("label_version") for r in rows if r.get("label_version") is not None}),
        "policies": dict(Counter(r.get("policy") for r in rows)), "stand_in_rows": sum(bool(r.get("stand_in")) for r in rows),
        "runs": dict(Counter(run_of(r.get("job_key")) for r in rows)),
        "kind_labels_version": kind_labels.get("version"), "grade_note": GRADE_NOTE,
        "does_not_beat_baselines": sorted(c["kind"] for c in cards if c["baseline_verdict"] in LOSING_VERDICTS
                                          and c["baseline_verdict"] != "not_scored"),
        "unscored_kinds": sorted(c["kind"] for c in cards if c["baseline_verdict"] == "not_scored"),
    }
    return {"meta": meta, "cards": cards}


def _fmt(x: Any) -> str:
    if x is None:
        return ""
    if isinstance(x, float):
        return f"{x:.4g}"
    if isinstance(x, dict | list):
        return json.dumps(x)
    return str(x)


def render_markdown(doc: dict[str, Any]) -> str:
    m = doc["meta"]
    stamp = m.get("stamp") or {}
    scored = [c for c in doc["cards"] if c.get("baseline_verdict") not in (None, "not_scored", "simulation_rule")]
    losing = [c for c in scored if c["baseline_verdict"] in LOSING_VERDICTS]
    lines = ["# Rule cards", "",
             f"Generated {m['generated']} from {m['ledger_rows']} learning-ledger rows over {m['records']} records "
             f"(split {str(m.get('split_sha256'))[:8]}, features {', '.join(m.get('features_hash') or [])}, labels v{', '.join(str(v) for v in m.get('label_version') or [])}, "
             f"kind_labels v{m.get('kind_labels_version')}). Policies in the rows: {m['policies']}; rows by run: {m.get('runs')}; "
             f"{m['stand_in_rows']} rows are the catalog stand-in "
             "(no agent ran in the export) and count as development-set consistency, not results. A card pools every run in the "
             "ledger, so read its `runs` field before reading its rate: two runs of different prompts pooled into one number is "
             "nobody's number.", "",
             f"Built at agent {str(stamp.get('agent_git_sha'))[:12]}, catalog kind tables "
             f"{str(stamp.get('catalog_kinds_sha256'))[:12]} (over {', '.join(stamp.get('stamped_tables') or [])}). "
             "tests/test_instruments.py refuses a card file whose stamp does not match the checkout, so a commit that "
             "changes those tables makes these numbers detectably stale rather than quietly wrong.", "",
             f"Grades: {m['grade_note']}.", ""]
    lines += ["## What these rules are worth", ""]
    if not scored:
        lines += ["No kind here has been scored against a label by a sweep yet.", ""]
    else:
        lines += [f"{len(losing)} of the {len(scored)} kinds a sweep has scored do not beat a guess from the case's family. "
                  "Every rule below opens with its own verdict in words; this is the list.", ""]
        for c in sorted(losing, key=lambda x: x["kind"]):
            lines.append(f"- **{c['kind']}**: {c['baseline_says']}")
        won = [c for c in scored if c not in losing]
        if won:
            lines.append("")
            for c in sorted(won, key=lambda x: x["kind"]):
                lines.append(f"- {c['kind']}: {c['baseline_says']}")
        lines.append("")
    unscored = sorted((c for c in doc["cards"] if c.get("baseline_verdict") == "not_scored" and c["fires"]),
                      key=lambda x: (-x["fires"], x["kind"]))
    if unscored:
        lines += ["Fired and never scored against a baseline (no sweep names them, so nothing here says whether they are worth "
                  "their false alarms):", ""]
        for c in unscored[:20]:
            lines.append(f"- {c['kind']}: {c['fires']} fires, {c['hit']} hit, {c['false_alarm']} false alarm, {c['untestable']} untestable")
        if len(unscored) > 20:
            lines.append(f"- and {len(unscored) - 20} more")
        lines.append("")
    lines += ["## Summary", "",
              "| kind | audience | class | frame | threshold | n | fires | hit | miss (silent / unexplained) | false alarm | acted | untestable | clean | P(poor given fire) | P(poor given not) | lift | MCC CV grouped | family baseline | sweep verdict |",
              "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for c in doc["cards"]:
        thr = f"{c['threshold_key']} = {_fmt(c['threshold_value'])}" if c["threshold_key"] else ""
        lines.append(f"| {c['kind']} | {c['audience']} | {c['rule_class'] or ''} | {c['frame']} | {thr} | {c['n']} | {c['fires']} | {c['hit']} | "
                     f"{c['miss']} ({c['miss_silent']} / {c['miss_unexplained']}) | {c['false_alarm']} | {c['acted']} | {c['untestable']} | {c['clean']} | "
                     f"{_fmt(c['poor_given_fire'])} | {_fmt(c['poor_given_not'])} | {_fmt(c['lift'])} | {_fmt(c['mcc_cv'])} | {_fmt(c['family_baseline'])} | {c['sweep_verdict'] or ''} |")
    lines.append("")
    lines.append("## Cards")
    for c in doc["cards"]:
        lines += ["", f"### {c['kind']}", "", f"**{c.get('baseline_says') or ''}**"]
        if c.get("within_family_says"):
            lines += ["", c["within_family_says"]]
        lines += ["", "| field | value |", "|---|---|"]
        for k in ("baseline_verdict", "audience", "component", "rule_class", "frame", "stratum", "threshold_key", "threshold_value",
                  "threshold_source", "threshold_status",
                  "n", "records", "fires", "bank_fires", "hit", "hit_grades", "miss", "miss_silent", "miss_unexplained", "false_alarm", "acted",
                  "untestable", "clean", "poor_given_fire", "poor_given_not", "base_rate", "lift", "mcc_cv", "mcc_cv_family", "family_baseline",
                  "family_baseline_agreement", "flag_everything_baseline", "sweep_verdict", "builder_policy_sensitivity", "last_fit",
                  "policy", "runs"):
            lines.append(f"| {k} | {_fmt(c.get(k))} |")
        if c["history"]:
            lines += ["", "history:", "", "| sweep | date | file | n | best threshold | fires | precision | recall | lift | MCC | MCC CV grouped | MCC CV family | family grouped | verdict |",
                      "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
            for h in c["history"]:
                if "counts" in h:
                    lines.append(f"| {h['sweep']} | {h['date']} | {h['file']} | {h.get('n')} | counts {_fmt(h['counts'])} | | | | | | | | | {h['verdict']} |")
                else:
                    lines.append(f"| {h['sweep']} | {h['date']} | {h['file']} | {h.get('n')} | {_fmt(h.get('best_threshold'))} | {_fmt(h.get('fires'))} | {_fmt(h.get('precision'))} | "
                                 f"{_fmt(h.get('recall'))} | {_fmt(h.get('lift'))} | {_fmt(h.get('mcc'))} | {_fmt(h.get('mcc_cv_grouped'))} | {_fmt(h.get('mcc_cv_family'))} | "
                                 f"{_fmt(h.get('family_baseline_mcc_grouped'))} | {h.get('verdict')} |")
        if c["recent_misses"]:
            lines += ["", "recent misses: " + "; ".join(f"{x['case']} ({x['miss_kind']}{', at ' + ','.join(x['bank_location']) if x.get('bank_location') else ''})" for x in c["recent_misses"])]
        if c["false_alarm_reasons"]:
            lines += ["", "false-alarm reasons: " + "; ".join(f"{v} x {k}" for k, v in c["false_alarm_reasons"].items())]
        lines.append("")
        lines.append(f"grades: {c['grade_note']}.")
    return "\n".join(lines) + "\n"


def write_cards(ledger: Path = store.LEDGER, sweeps_dir: Path = store.SWEEPS_DIR, kind_labels_path: Path = store.KIND_LABELS,
                out_json: Path = store.RULE_CARDS_JSON, out_md: Path = store.RULE_CARDS_MD) -> dict[str, Any]:
    doc = build_cards(ledger, sweeps_dir, kind_labels_path)
    store.write_json(out_json, doc)
    Path(out_md).parent.mkdir(parents=True, exist_ok=True)
    Path(out_md).write_text(render_markdown(doc), encoding="utf-8")
    return {"cards": len(doc["cards"]), "json": str(out_json), "md": str(out_md), "ledger_rows": doc["meta"]["ledger_rows"]}
