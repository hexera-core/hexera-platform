"""The budget trade: the one question that cannot be asked until a plan exists.

REHAAN'S RULE. Intake fires a third time ONLY for a question that did not exist at the second, and the budget
trade is the canonical one. At the second intake there is no plan, so the only envelope there is is the facts-only
one, which reads low (median 0.52x delivered over 263 corpus meshes, `hexera.FACTS_ONLY_CALIBRATION`) and is asked
about only when even that low reading is over the stated cap (`uncertainty.budget_uncertainty`). Once the plan
exists, the envelope is what resolving the places THIS PLAN names costs by the builder's own sizing, and that
figure can be over the customer's budget where the facts-only one was not. That is a new question. It is asked
ONCE, as a real trade, with a default.

THE NUMBER, and it is not negotiable either: `tools.estimate_builder_cells` through `hexera.forecast`, run on the
strategy the builder would take for this plan (`hexera.builder_strategy`). NEVER `tools.refined_cell_estimate`,
whose median is 1.86x the delivered cells and whose max is 576x, and never `mesh_plan.cell_estimate_refined`,
which the checker writes from it into every plan (187,414,362 on `bend_elbow_001` against an envelope of 689,900).
`tests/test_chain_job.py` makes `refined_cell_estimate` raise and runs the whole chain.

WHAT "PROPERLY" MEANS HERE, measured and not asserted. `hexera.builder_strategy` walks `cells_across_diameter`
down until the corrected forecast sits under the cap it is given. Given the customer's cap, it has already traded
resolution for cells and the envelope can never read over; so the trade compares the strategy under the builder's
own hard limit (`hexera.MAX_CELLS_CAP`), which is what resolving the smallest port at the port floor costs, against
the stated budget, and says what holding the budget does to the smallest port, from the capped strategy's own
numbers. Both sides of the trade are the emulator's; neither is a prediction of the finished mesh.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from geometry_agent.agent import hexera

#: The late question's own id. Different from the second intake's `u_budget` on purpose: they are different
#: questions about the same decision, and `contract.intake.binds_late` refuses this one by TOPIC whenever the
#: second intake had the other, asked or held.
TRADE_ID = "u_budget_planned"

#: The kind in `ask.schema.KINDS`; the ledger's topic is `budget`.
TRADE_KIND = "budget_envelope"


@dataclass(frozen=True)
class Envelope:
    """Both sides of the trade, from the emulator, with the basis that says so."""
    cells_high: int
    cells_low: int
    held_cells_high: int | None
    cap: int | None
    #: What holding the budget does to the smallest port, in the capped strategy's own numbers.
    held_cells_across: int | None
    proper_cells_across: int | None
    held_notes: tuple[str, ...] = ()
    basis: tuple[str, ...] = ()
    source: str = "tools.estimate_builder_cells via hexera.forecast on hexera.builder_strategy for this plan"

    @property
    def over(self) -> bool:
        return self.cap is not None and self.cells_high > self.cap

    def as_dict(self) -> dict[str, Any]:
        return {"cells_high": self.cells_high, "cells_low": self.cells_low, "held_cells_high": self.held_cells_high,
                "cap": self.cap, "held_cells_across": self.held_cells_across,
                "proper_cells_across": self.proper_cells_across, "held_notes": list(self.held_notes),
                "basis": list(self.basis), "source": self.source}


def _inlet(plan: Any, facts: Any) -> str | None:
    return next((i for i in plan.flow.inlet_ids if facts.opening(i) is not None), None)


def planned_envelope(plan: Any, facts: Any, *, representation: str, engine: str, cap: int | None,
                     unit: str | None = None, brief: str | None = None) -> Envelope:
    """What resolving this plan's places costs, and what holding the stated budget does instead.

    `representation` is the SURVEY's, passed in: this never calls `hexera.representation_of`, which lets one
    region role the model wrote override the measurement.
    """
    axis = hexera._snap_axis(plan.flow.axis)
    inlet = _inlet(plan, facts)
    proper = hexera.builder_strategy(plan, facts, engine, None, representation, unit, brief)
    fc = hexera.forecast(facts, {**proper["keys"], "flow_axis": axis}, representation, proper["engine"], None,
                         inlet_id=inlet)
    held_high, held_across, notes = None, None, ()
    if cap:
        held = hexera.builder_strategy(plan, facts, engine, cap, representation, unit, brief)
        held_fc = hexera.forecast(facts, {**held["keys"], "flow_axis": axis}, representation, held["engine"], cap,
                                  inlet_id=inlet)
        held_high = int(held_fc["cells_high"])
        held_across = held["keys"].get("cells_across_diameter")
        notes = tuple(str(n) for n in held.get("notes") or ())
    return Envelope(cells_high=int(fc["cells_high"]), cells_low=int(fc["cells_low"]), held_cells_high=held_high,
                    cap=int(cap) if cap else None, held_cells_across=held_across,
                    proper_cells_across=proper["keys"].get("cells_across_diameter"), held_notes=notes,
                    basis=tuple(str(b) for b in fc.get("basis") or ()))


@dataclass
class Trade:
    """The late question, ready for `contract.survey.Uncertainty` and for the ledger."""
    id: str
    kind: str
    text: str
    options: list[str]
    default: str
    default_is: str
    because: str
    envelope: dict[str, Any] = field(default_factory=dict)

    def value_of(self, option: str) -> int | None:
        """The budget an answer sets. `hold` keeps the stated one, `raise` takes the envelope."""
        low = str(option or "").strip().lower()
        if low.startswith("hold"):
            return self.envelope.get("cap")
        if low.startswith("raise"):
            return self.envelope.get("cells_high")
        return None


def _millions(n: int | None) -> str:
    return "?" if not n else f"{n / 1e6:.2g} million"


def trade_question(env: Envelope) -> Trade | None:
    """The trade, when the envelope genuinely does not fit the stated budget; None otherwise.

    None when there is no stated budget too: an absent budget is not a cap to trade against, and inventing one
    is the error `OWNERS['cell_budget']` refuses.
    """
    if not env.over or env.cap is None:
        return None
    hold = f"hold {env.cap:,}"
    raise_to = f"raise to about {env.cells_high:,}"
    cost = ""
    if env.held_cells_across and env.proper_cells_across and env.held_cells_across < env.proper_cells_across:
        cost = (f" Holding it, the mesher sizes the bore at {env.held_cells_across} cells across instead of "
                f"{env.proper_cells_across}.")
    text = (f"You asked me to keep this under {_millions(env.cap)} cells. The plan resolves the places this part "
            f"needs, and by the mesher's own sizing that comes to about {_millions(env.cells_high)}.{cost} I can "
            f"hold your number and resolve them coarser, or go to about {_millions(env.cells_high)}. Which would "
            "you rather?")
    return Trade(id=TRADE_ID, kind=TRADE_KIND, text=text, options=[hold, raise_to], default=hold,
                 default_is="operation",
                 because="the cell ceiling decides how finely the places the plan names get resolved, and the "
                         "customer set it, so only the customer can move it",
                 envelope=env.as_dict())


__all__ = ["Envelope", "TRADE_ID", "TRADE_KIND", "Trade", "planned_envelope", "trade_question"]
