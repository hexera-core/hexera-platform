"""The surveyor's abstentions are intake's questions.

The look already declines to name a role on six of every seven mouths, the measurement never names a role at
all, and the two lists of things nobody is sure about have never been connected to the list of things the
customer is asked. This package is that connection.

IT IS ON THE CHAIN. `chain/job.py` imports `ask.intake` and `ask.trade` and step 4 of `run_job` is `ask_intake`,
so the sentence that used to stand here, that nothing in the shipping path imports this package, is no longer
true and was the reason two fixes went in without anybody checking what they changed downstream. What is true is
narrower and is worth keeping separate: the PLATFORM does not call the chain yet, so no customer sees these
questions today. Every claim in this package about being off by default has to say which of the two it means.

    ask.uncertainty   what the surveyor declined to settle, read out of `hexera.report_measured`
    ask.settle        what already answered it: a declared port at the mouth, or a phrase that selects an option
    ask.consequence   whether the answer would change what the builder does, worked out by branching
    ask.say           the question written the way a person asks it, one question and one default
    ask.record        what has to be stored for the answer to come back as a label
    ask.intake        the four cuts, in order, and the short list that comes out

ONE OF THREE `Uncertainty` TYPES IN THIS TREE (`contract/survey.py`, `ask/schema.py`, `chain/schema.py`), and
this is the SOURCE of the other two: `chain/job.merged_records` builds the ledger's from these and
`chain/job.contract_uncertainties` builds the builder handoff's. They stay three because they have three
cardinalities, one per abstention here, one per place in the ledger, one per unanswered question in the
handoff, and because this is the only one carrying `measurement`, which `ask.consequence` branches to decide
whether a question is put at all. `chain/schema.Uncertainty`'s docstring states that in full. What they share is
ONE vocabulary through `chain.schema.canonical_kind`, and `tests/test_chain_ledger.py` asserts all three map
onto it one to one, so a kind added to one package and not the others fails there.
"""
from geometry_agent.ask.intake import Asked, ask_intake
from geometry_agent.ask.schema import ASK_SCHEMA, Consequence, Question, Uncertainty

__all__ = ["ASK_SCHEMA", "Asked", "Consequence", "Question", "Uncertainty", "ask_intake"]
