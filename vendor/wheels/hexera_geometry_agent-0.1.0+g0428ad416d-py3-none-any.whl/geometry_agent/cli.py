"""geometry-agent: measure | risks | analyze | render | fixtures | eval | thresholds (show | propose | ship)"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

PURPOSES = ["internal_cfd", "external_cfd", "conjugate_heat_transfer", "structural"]
TIERS = ["draft", "standard", "max"]


def _declared(arg: str | None) -> list[dict] | None:
    if not arg:
        return None
    p = Path(arg)
    return json.loads(p.read_text() if p.exists() else arg)


def cmd_measure(a) -> int:
    from geometry_agent.facts.measure import measure
    f = measure(a.file, purpose=a.purpose, cache_dir=a.cache_dir)
    print(f.model_dump_json(indent=1 if not a.compact else None))
    return 0


def cmd_risks(a) -> int:
    from geometry_agent.agent.catalog import detect_risks
    from geometry_agent.facts.measure import measure
    f = measure(a.file, purpose=a.purpose, cache_dir=a.cache_dir)
    roles = json.loads(a.roles) if a.roles else None
    rs = detect_risks(f, a.purpose, a.fidelity, a.cell_cap, _declared(a.declared), roles)
    if a.json:
        print(json.dumps([r.model_dump() for r in rs], indent=1))
    else:
        for r in rs:
            tag = f" [{r.measurement.get('opening_id')}]" if r.measurement.get("opening_id") else ""
            print(f"{r.id:4s} {r.severity:8s} {r.kind}{tag}\n      {r.consequence}\n      -> {r.recommendation}")
        if not rs:
            print("no risks detected")
    return 0


def cmd_analyze(a) -> int:
    from geometry_agent.agent.run import analyze
    client = None
    if a.heuristic:
        from geometry_agent.agent.reference import ReferencePolicy
        client = ReferencePolicy()
    else:
        from geometry_agent.agent.client import client_from_env
        try:
            client = client_from_env(a.provider)
        except Exception as exc:
            print(f"{exc}; or use --heuristic", file=sys.stderr)
            return 2
        print(f"model: {client.model} @ {client.base_url}", file=sys.stderr)
        if a.record:
            from geometry_agent.agent.client import RecordingClient
            client = RecordingClient(client, Path(a.record))
    vision = None
    if a.vision == "on":
        from geometry_agent.vision.client import vision_client_from_env
        vision = vision_client_from_env()
        if vision is None:
            print("no vision provider configured (ANTHROPIC_API_KEY or DEEPINFRA_API_KEY, or "
                  "GEOMETRY_AGENT_VISION_PROVIDER); continuing without look_at_views", file=sys.stderr)
        else:
            print(f"vision: {vision.model} ({vision.provider})", file=sys.stderr)
    r = analyze(a.file, purpose=a.purpose, brief=a.brief, fidelity=a.fidelity, cell_cap=a.cell_cap,
                declared=_declared(a.declared), client=client, cache_dir=a.cache_dir, render_dir=a.render_dir, vision=vision)
    out = r.model_dump(mode="json")
    if r.ok and a.handover:
        from geometry_agent.agent.hexera import handover
        from geometry_agent.facts.measure import measure
        facts = measure(a.file, purpose=a.purpose, cache_dir=a.cache_dir)
        out["hexera"] = handover(r.plan, facts, unit=a.unit)
        Path(a.handover).write_text(json.dumps(out["hexera"], indent=1, default=str))
    if a.out:
        Path(a.out).write_text(json.dumps(out, indent=1, default=str))
    if a.json or not r.ok:
        print(json.dumps(out if a.json else {k: out[k] for k in ("ok", "exit", "reason", "rounds", "tool_calls")}, indent=1))
    else:
        p = r.plan
        print(f"== {p.object.type} (confidence {p.object.confidence:.2f})\n{p.summary_for_user}\n")
        print("PATCHES");  [print(f"  {x.id:10s} {x.role:16s} D_h={x.hydraulic_diameter:.4g} conf={x.confidence:.2f}") for x in p.patches]
        print("RISKS");    [print(f"  {k.id:4s} {k.severity:8s} {k.kind}") for k in p.risks]
        print("QUESTIONS"); [print(f"  {q.id} ({q.relates_to}): {q.text[:140]}\n        options: {q.options}") for q in p.questions]
        mp = p.mesh_plan
        print(f"MESH PLAN  {mp.fidelity}, base {mp.base_size:.4g}, ~{mp.cell_estimate:,} cells, "
              f"{len(mp.refinement_regions)} refinement regions, {len(mp.layer_targets)} layer targets")
        print(f"\nFOR THE BUILDER\n{p.summary_for_builder}")
        print(f"\n({r.rounds} rounds, {r.tool_calls} tool calls, {r.grounding_rejections} grounding rejections)")
    return 0 if r.ok else 1


def cmd_render(a) -> int:
    from geometry_agent.render import render_direction, render_eight
    if a.direction:
        print(render_direction(a.file, a.direction, a.out))
    else:
        for p in render_eight(a.file, a.out):
            print(p)
    return 0


def cmd_fixtures(a) -> int:
    from geometry_agent.synthetic import write_all
    for name, p in write_all(Path(a.out)).items():
        print(f"{name:16s} {p}")
    return 0


def cmd_eval(a) -> int:
    from geometry_agent.evaluate import run_corpus
    report = run_corpus(Path(a.corpus), heuristic=not a.model, cache_dir=a.cache_dir, provider=a.provider)
    print(json.dumps(report, indent=1) if a.json else report["text"])
    return 0 if report["failed"] == 0 else 1


# --- thresholds: the one governed path to a rule parameter (docs/thresholds.md) ------------------------------------

def _thresholds_show(a) -> int:
    from geometry_agent.agent import prompt
    from geometry_agent.agent import thresholds as th
    table = th.read_table(a.file)
    rows = th.rows(table)
    T = th.from_table(table)
    if a.json:
        print(json.dumps({"file": str(th.thresholds_path(a.file)), "thresholds_sha256": th.thresholds_sha256(T),
                          "prompt_sha256": prompt.prompt_sha256(T), "rows": rows}, indent=1))
        return 0
    if a.markdown:
        print("| key | value | default | unit or frame | class | audience | stratum | status |")
        print("|---|---|---|---|---|---|---|---|")
        for r in rows:
            print(f"| `{r['key']}` | {r['value']} | {r['default']} | {r['unit_or_frame']} | {r['rule_class']} | {r['audience']} | "
                  f"{r['stratum']} | {r['status']} |")
        return 0
    print(f"{'key':32s} {'value':>10s} {'default':>10s} {'class':13s} {'audience':9s} {'stratum':15s} {'status':9s} {'n':>5s} {'fitted':11s} proposed")
    for r in rows:
        print(f"{r['key']:32s} {r['value']!s:>10s} {r['default']!s:>10s} {r['rule_class']:13s} {r['audience']:9s} {r['stratum']:15s} "
              f"{r['status']:9s} {str(r['n'] if r['n'] is not None else '-'):>5s} {str(r['fitted_at'] or '-'):11s} "
              f"{r['proposed_value'] if r['proposed_value'] is not None else ''}")
    print(f"\nfile {th.thresholds_path(a.file)}\nthresholds sha256 {th.thresholds_sha256(T)}\nprompt sha256 {prompt.prompt_sha256(T)}")
    return 0


def _thresholds_propose(a) -> int:
    from geometry_agent.agent import thresholds as th
    table = th.read_table(a.file)
    sweep_path = Path(a.sweep)
    try:
        sweep = json.loads(sweep_path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        print(f"cannot read sweep file {sweep_path}: {exc}", file=sys.stderr)
        return 2
    if not isinstance(sweep, dict):
        print(f"sweep file {sweep_path} must hold a JSON object", file=sys.stderr)
        return 2
    try:
        entry = th.propose(table, a.key, float(a.value), sweep, sweep_file=str(sweep_path))
    except th.ThresholdsError as exc:
        print(str(exc), file=sys.stderr)
        return 2
    th.write_table(table, a.file)
    prov = entry["provenance"]
    print(f"{a.key}: proposed {prov['proposed_value']} (value in force stays {entry['value']}); status {entry['status']}; "
          f"n {prov.get('n')}, fires {prov.get('fires')}, lift {prov.get('lift')}, mcc_cv {prov.get('mcc_cv')}, band {prov.get('band')}, "
          f"sweep {prov.get('sweep_file')}")
    refusals = th.ship_refusals(table, a.key, override_physics=False)
    if refusals:
        print("ship would refuse now:\n  - " + "\n  - ".join(refusals))
    return 0


def _thresholds_ship(a) -> int:
    from geometry_agent.agent import prompt
    from geometry_agent.agent import thresholds as th
    from geometry_agent.learn import replay_regression
    table = th.read_table(a.file)
    refusals = th.ship_refusals(table, a.key, override_physics=a.override_physics)
    if refusals:
        print(f"refusing to ship {a.key}:\n  - " + "\n  - ".join(refusals), file=sys.stderr)
        return 2
    current = th.from_table(table)
    before_t, before_p = th.thresholds_sha256(current), prompt.prompt_sha256(current)
    proposed_table = json.loads(json.dumps(table))
    proposed_table[a.key]["value"] = table[a.key]["provenance"]["proposed_value"]
    proposed = th.from_table(proposed_table)
    print(f"replay regression before shipping {a.key} (recordings {replay_regression.recordings_dir(a.recordings_dir)}) ...", flush=True)
    with th.override(current):
        now = replay_regression.run(a.recordings_dir, a.facts_cache, a.corpus_root, workers=a.workers)
    print("under the values in force: " + now.summary_line().replace("\n", "; "))
    after = replay_regression.run(a.recordings_dir, a.facts_cache, a.corpus_root, workers=a.workers, thresholds=proposed)
    # every transcript accepted when it was made and rejected under the proposed value is a new rejection; the ones
    # the current value also rejects are drift the recordings already carry, not the move's doing, and only those
    # can be waved past with --allow-drift
    broken = replay_regression.delta(now, after)
    drift = [v for v in after.regressed if v.recording not in {b.recording for b in broken}]
    print(f"under the proposed value: {after.summary()['accepted_now']} accepted, {len(broken)} newly rejected by the move, "
          f"{len(drift)} already rejected before it")
    if broken:
        print("\n".join(v.line() for v in broken))
        print(f"refusing to ship {a.key}: {len(broken)} transcript(s) accepted under the current value are rejected under "
              f"{proposed_table[a.key]['value']}", file=sys.stderr)
        return 1
    if drift:
        print("\n".join(v.line() for v in drift))
        if not a.allow_drift:
            print(f"refusing to ship {a.key}: {len(drift)} transcript(s) accepted when recorded are rejected by the current checker "
                  "under the current value as well (drift the recordings carry, not this move). Fix the checker or re-record them, "
                  "or pass --allow-drift to ship past them", file=sys.stderr)
            return 1
        print(f"note: shipping past {len(drift)} transcript(s) of drift on --allow-drift", file=sys.stderr)
    if not now.verdicts:
        print("note: no recordings were replayed (none found); the regression gate had nothing to check", file=sys.stderr)
    try:
        record = th.ship(table, a.key, signed_by=a.signed_by, override_physics=a.override_physics)
    except th.ThresholdsError as exc:
        print(str(exc), file=sys.stderr)
        return 2
    th.write_table(table, a.file)
    after = th.from_table(table)
    print(f"shipped {a.key}: {record['from']} -> {record['to']} on {record['date']}"
          + (f", signed by {record['signed_by']}" if record["signed_by"] else ""))
    print(f"thresholds sha256 {before_t} -> {th.thresholds_sha256(after)}")
    print(f"prompt sha256     {before_p} -> {prompt.prompt_sha256(after)}")
    print("prompt rule sentences regenerated:")
    for key, sentence in prompt.rule_sentences(after).items():
        print(f"  {key}: {sentence}")
    return 0


def cmd_thresholds(a) -> int:
    return {"show": _thresholds_show, "propose": _thresholds_propose, "ship": _thresholds_ship}[a.action](a)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="geometry-agent")
    ap.add_argument("--cache-dir", default=None)
    sub = ap.add_subparsers(dest="cmd", required=True)

    m = sub.add_parser("measure", help="deterministic facts as JSON")
    m.add_argument("file"); m.add_argument("--purpose", choices=PURPOSES, default="internal_cfd"); m.add_argument("--compact", action="store_true")
    m.set_defaults(fn=cmd_measure)

    r = sub.add_parser("risks", help="failure catalog, no model")
    r.add_argument("file"); r.add_argument("--purpose", choices=PURPOSES, required=True)
    r.add_argument("--fidelity", choices=TIERS, default="standard"); r.add_argument("--cell-cap", type=int)
    r.add_argument("--declared", help="JSON list or path: [{name, role, area, near}]"); r.add_argument("--roles", help='JSON {"o1":"inlet",...}')
    r.add_argument("--json", action="store_true"); r.set_defaults(fn=cmd_risks)

    an = sub.add_parser("analyze", help="full agent run: plan + questions")
    an.add_argument("file"); an.add_argument("--purpose", choices=PURPOSES, required=True); an.add_argument("--brief", default="")
    an.add_argument("--fidelity", choices=TIERS, default="standard"); an.add_argument("--cell-cap", type=int)
    an.add_argument("--declared"); an.add_argument("--heuristic", action="store_true", help="no model: deterministic reference policy")
    an.add_argument("--provider", choices=["auto", "anthropic", "deepseek", "deepinfra", "generic"], default="auto",
                    help="which env vars to read: the stack's DEEPSEEK_*/DEEPINFRA_* or GEOMETRY_AGENT_*")
    an.add_argument("--record", help="record model responses to this JSON for replay"); an.add_argument("--render-dir")
    an.add_argument("--out", help="write the full AnalysisResult JSON here"); an.add_argument("--json", action="store_true")
    an.add_argument("--handover", help="also write the plan in Hexera's vocabulary (patches, port declaration, domain, engine hints) to this JSON")
    an.add_argument("--unit", choices=["m", "mm", "cm", "in", "ft"], default=None, help="override the plan's unit call for the millimetre port declaration")
    an.add_argument("--vision", choices=["off", "on"], default="off",
                    help="on: attach the vision model from the environment (GEOMETRY_AGENT_VISION_PROVIDER, ANTHROPIC_API_KEY, "
                         "DEEPINFRA_API_KEY) so the model may call look_at_views once")
    an.set_defaults(fn=cmd_analyze)

    rd = sub.add_parser("render", help="axis-arrow views (8 fixed, or one --direction)")
    rd.add_argument("file"); rd.add_argument("--out", default="renders"); rd.add_argument("--direction", choices=["+x", "-x", "+y", "-y", "+z", "-z", "iso", "iso2"])
    rd.set_defaults(fn=cmd_render)

    fx = sub.add_parser("fixtures", help="write the synthetic fixture set")
    fx.add_argument("--out", default="tests/_fixtures"); fx.set_defaults(fn=cmd_fixtures)

    ev = sub.add_parser("eval", help="score a corpus dir of <case>/geometry.* + expected.json")
    ev.add_argument("corpus"); ev.add_argument("--model", action="store_true", help="use the configured model instead of the heuristic policy")
    ev.add_argument("--provider", choices=["auto", "anthropic", "deepseek", "deepinfra", "generic"], default="auto")
    ev.add_argument("--json", action="store_true"); ev.set_defaults(fn=cmd_eval)

    th = sub.add_parser("thresholds", help="governed rule parameters: show the table, propose a value from a sweep, ship it")
    th.add_argument("--file", default=None, help="thresholds JSON (default $GEOMETRY_AGENT_THRESHOLDS_FILE or the package's own)")
    tsub = th.add_subparsers(dest="action", required=True)
    ts = tsub.add_parser("show", help="print the table with both hashes")
    ts.add_argument("--json", action="store_true"); ts.add_argument("--markdown", action="store_true", help="the docs table")
    tp = tsub.add_parser("propose", help="record a proposed value with provenance from a sweep file; changes no value")
    tp.add_argument("key"); tp.add_argument("value", type=float)
    tp.add_argument("--sweep", required=True, help="JSON from eval/calib/sweep.py: n, fires, lift, mcc_cv, band, baselines, ...")
    tsh = tsub.add_parser("ship", help="move a proposed value into force: replay regression first, history entry, both hashes")
    tsh.add_argument("key"); tsh.add_argument("--signed-by", default=None)
    tsh.add_argument("--override-physics", action="store_true", help="a physics rule moves only with this and a sign-off")
    tsh.add_argument("--allow-drift", action="store_true",
                     help="ship past transcripts the current checker already rejects under the current value (never past ones the move rejects)")
    tsh.add_argument("--recordings-dir", default=None, help="recordings for the replay regression (default $GEOMETRY_AGENT_RECORDINGS_DIR or eval/recordings)")
    tsh.add_argument("--facts-cache", default=None, help="facts cache the replay reads (never written)")
    tsh.add_argument("--corpus-root", action="append", default=[], help="extra corpus root for the replay (repeatable)")
    tsh.add_argument("--workers", type=int, default=1)
    th.set_defaults(fn=cmd_thresholds)

    a = ap.parse_args(argv)
    return a.fn(a)


if __name__ == "__main__":
    sys.exit(main())
