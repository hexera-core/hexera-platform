"""What a person reads the morning after, and the switch that stops a run starting.

The package had no logging at all: 26,507 lines, not one `import logging`, so a run that took nine hours or
refused a file left nothing behind but its result JSON. This module is the minimum that fixes that, not an
observability project. These boundaries emit, and nothing else does:

    run.start / run.end          a run beginning and ending, with its exit, its rounds and its seconds
    case.end                     the eval's own line, which names the case the pair above belonged to
    model.retry / model.failed   a provider call retried after a transient status, and one that gave up
    measure.miss / .refused      a cache miss that paid for a measurement, and a measurement stopped at its deadline
    run.refused / run.deadline   the kill switch or the size ceiling, and a case that spent its wall clock

Every line is `name key=value ...` on the `geometry_agent` logger, which a host configures like any other
library logger (`observe.setup()` is the one-liner for a harness that has none). Two rules the callers keep:
a field never carries customer geometry (a file is named by its size and its suffix, never by its path, and no
measurement, brief or opening count is ever a field), and a value that looks like a credential is replaced by
`***` before the line is formatted, so a header or a URL with a key in it cannot reach the log by accident.
"""
from __future__ import annotations

import logging
import os
import re
import sys
from pathlib import Path
from typing import Any

LOGGER_NAME = "geometry_agent"
log = logging.getLogger(LOGGER_NAME)

#: The kill switch: set it and `agent.run.analyze` refuses to start, whatever the caller asks for. The one
#: variable an operator needs when a run has to stop and the queue cannot be reached.
DISABLE_ENV = "GEOMETRY_AGENT_DISABLED"
#: Level for `setup()`; `off` silences the package logger entirely.
LOG_ENV = "GEOMETRY_AGENT_LOG"
#: A file to append the lines to, in addition to stderr.
LOG_FILE_ENV = "GEOMETRY_AGENT_LOG_FILE"
TRUE = ("1", "true", "on", "yes")
OFF = ("0", "false", "off", "no", "none", "")

#: A value that looks like a credential never reaches a line: an sk- token, a bearer header, anything a key or
#: token was assigned to in a URL or a header dump, and a long hex digest. Field names are the callers' own, so
#: this guards the value, which is what leaks. It deliberately does not scrub every long word: a case name is
#: forty characters of letters and underscores and the log is unreadable without it.
SECRET_RE = re.compile(r"(sk-[A-Za-z0-9_\-]{8,}"
                       r"|bearer\s+\S+"
                       r"|\b(?:api[-_]?key|access[-_]?token|auth|token|key|secret)\s*[=:]\s*[^\s&,;]+"
                       r"|\b[A-Fa-f0-9]{32,}\b)", re.IGNORECASE)
#: Fields whose name alone says the value must not be logged, whatever it looks like.
SECRET_FIELDS = frozenset({"api_key", "key", "authorization", "token", "secret", "headers", "brief", "path"})
MAX_VALUE_CHARS = 120


def _scrub(name: str, value: Any) -> str:
    if name in SECRET_FIELDS:
        return "***"
    if isinstance(value, float):
        text = f"{value:.1f}" if abs(value) >= 0.1 else f"{value:.3g}"
    else:
        text = str(value)
    text = SECRET_RE.sub("***", text)
    if len(text) > MAX_VALUE_CHARS:
        text = text[:MAX_VALUE_CHARS] + "..."
    return text.replace("\n", " ").replace("\r", " ")


def line(name: str, **fields: Any) -> str:
    """The event as one line: `name key=value key=value`, in the order the caller wrote them."""
    parts = [f"{k}={_scrub(k, v)}" for k, v in fields.items() if v is not None]
    return " ".join([name, *parts])


def event(name: str, level: int = logging.INFO, **fields: Any) -> None:
    if log.isEnabledFor(level):
        log.log(level, line(name, **fields))


def info(name: str, **fields: Any) -> None:
    event(name, logging.INFO, **fields)


def warning(name: str, **fields: Any) -> None:
    event(name, logging.WARNING, **fields)


def file_id(path, size: int | None = None) -> dict[str, Any]:
    """How a file is named in a log line: its suffix and its size, never its path or its name. Nothing here
    reads the file."""
    p = Path(path)
    try:
        size = p.stat().st_size if size is None else size
    except OSError:
        size = None
    return {"suffix": p.suffix.lower(), "bytes": size}


def disabled(env: dict | None = None) -> bool:
    """True when the kill switch is set. Read on every `analyze()`, so setting it stops the next case of a run
    already in flight rather than only the next run."""
    return (env or os.environ).get(DISABLE_ENV, "").strip().lower() in TRUE


def setting(name: str, default: float, env: dict | None = None) -> float:
    """A numeric knob from the environment: unset gives the default, `off`/`none`/`0` gives 0.0 (the caller
    reads that as "no limit"), and a value that is not a number is a warning and the default, because a typo
    in a deadline must not silently become no deadline."""
    raw = (env or os.environ).get(name)
    if raw is None:
        return default
    text = raw.strip().lower()
    if text in OFF:
        return 0.0
    try:
        value = float(text)
    except ValueError:
        warning("env.unreadable", var=name, value=text, using=default)
        return default
    return max(0.0, value)


def setup(level: str | None = None, stream: Any = None) -> logging.Logger:
    """Send the package's lines somewhere. A host that configures logging itself never calls this: the records
    propagate to the root logger like any library's. Returns the package logger either way."""
    want = (level or os.environ.get(LOG_ENV) or "info").strip().lower()
    if want in OFF:
        log.setLevel(logging.CRITICAL + 1)
        return log
    log.setLevel(getattr(logging, want.upper(), logging.INFO))
    fmt = logging.Formatter("%(asctime)s %(levelname).1s %(message)s", datefmt="%Y-%m-%dT%H:%M:%S")
    if not any(getattr(h, "_geometry_agent", False) for h in log.handlers):
        h = logging.StreamHandler(stream or sys.stderr)
        h.setFormatter(fmt)
        h._geometry_agent = True
        log.addHandler(h)
    path = os.environ.get(LOG_FILE_ENV)
    if path and not any(isinstance(h, logging.FileHandler) for h in log.handlers):
        fh = logging.FileHandler(path, encoding="utf-8")
        fh.setFormatter(fmt)
        fh._geometry_agent = True
        log.addHandler(fh)
    return log
