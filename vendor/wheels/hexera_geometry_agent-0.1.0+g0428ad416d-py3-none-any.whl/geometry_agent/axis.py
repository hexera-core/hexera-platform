"""THE ONE FLOW-AXIS SNAP, and the one threshold it uses.

A flow direction reaches the builder as a signed axis letter: `snappy_runner.py:311-335 domain_from_strategy`
builds the domain around `flow_axis`, and it reads `+x` and the rest and nothing else. Two modules turned a
vector into that letter and each carried its own copy of the cutoff: `agent.hexera._snap_axis` and
`contract.given._plan_flow_direction`, whose docstring said in words that its `0.9` was hexera's number written
out again "so the contract package stays free of the agent it constrains". It was right about the boundary and
the cost was a literal in two files that nothing compared. This module is the neutral home both can import: it
imports nothing of the package, so the contract stays free of the agent and the number has one place to live.

WHY IT REFUSES. A vector that is not mostly one of the three axes names no direction the builder can trace, so
it poses none and nothing is compared against it. That is `AXIS_SNAP`: the dominant component must carry at
least this much of the unit vector, which is 25.8 degrees off the axis.

WHAT THIS IS NOT. It is not the gate on whether a single-axis area profile means anything: that is
`reconcile.profile.trust`, it is a different question about a different axis, and its own cutoff is the angle a
mouth's normal may lie from the fitted flow axis.
"""
from __future__ import annotations

import math
from typing import Any

#: How much of a unit vector the dominant component must carry before the vector names an axis.
AXIS_SNAP = 0.9

#: The three letters, in the order a component index means.
LETTERS = "xyz"


def degrees_off() -> float:
    """The angle `AXIS_SNAP` is, for a report that wants to print it rather than the cosine."""
    return float(math.degrees(math.acos(AXIS_SNAP)))


def snap(axis: Any, *, flip: bool = False) -> str | None:
    """`axis` as a signed axis letter (`+x`, `-z`), or None when it is not mostly one of the three.

    `flip` reverses the sign, which is what a plan's `direction_sign` does to its own `flow.axis`.
    Returns None for anything that is not three numbers, because a malformed direction is not a direction.
    """
    if axis is None:
        return None
    try:
        xyz = [float(c) for c in axis]
    except (TypeError, ValueError):
        return None
    if len(xyz) != 3:
        return None
    k = max(range(3), key=lambda i: abs(xyz[i]))
    if abs(xyz[k]) < AXIS_SNAP:
        return None
    sign = "+" if xyz[k] > 0 else "-"
    if flip:
        sign = "-" if sign == "+" else "+"
    return sign + LETTERS[k]


def unit(letter: str | None) -> list[float] | None:
    """A signed axis letter back to a unit vector, or None when it is not one. `snap`'s inverse."""
    text = str(letter or "").strip().lower()
    if len(text) != 2 or text[0] not in "+-" or text[1] not in LETTERS:
        return None
    out = [0.0, 0.0, 0.0]
    out[LETTERS.index(text[1])] = 1.0 if text[0] == "+" else -1.0
    return out


__all__ = ["AXIS_SNAP", "LETTERS", "degrees_off", "snap", "unit"]
