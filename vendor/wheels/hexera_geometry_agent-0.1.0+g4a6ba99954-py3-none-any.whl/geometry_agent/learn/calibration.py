"""The calibrated tables the channel builder reads: minutes per cells bin, the per-representation cell
correction, and the PER-ENGINE correction of the builder emulator's forecast. All are fitted on LEARNING
records only and written with provenance (n, date, split sha); the readers here never fit, they only look up.

    minutes_for_cells(cells, engine) -> {"typical": median minutes, "p90": ..., "n": ..., "bin": ...}
    cell_correction(representation) -> multiplier on the standard-tier estimate (1.0 when unfitted)
    engine_cell_correction(engine, representation) -> multiplier on the EMULATOR's forecast (1.0 unless admitted)

WHY THE PER-ENGINE TABLE IS A THIRD TABLE AND NOT A COLUMN IN THE SECOND. `cell_correction` is fitted against
the facts layer's standard tier (diagonal/80) and `engine_cell_correction` against
`agent.tools.estimate_builder_cells`. They correct DIFFERENT ESTIMATORS of the same quantity, so one number
cannot serve both: `hexera.correction_info` already refuses to apply the first to the second for exactly that
reason, and pooling them into one file would have made that refusal impossible to express. The basis string on
each table names its estimator and `hexera.EMULATOR_BASIS_WORDS` is the gate.

WHERE A FITTED FACTOR MAY BE READ FROM, AND WHERE IT MAY NOT (docs/cell_forecast_correction.md, section 4).

  MAY:     learning records of the corpus export (`store.record_paths(side="learning")`), whose emulator
           forecast is recomputed from the read-only facts cache because the record does not carry it.
  MAY NOT: the locked half, and the `platform` side. `fit_engine_cell_correction` opens no file at all - the
           caller hands it samples - so the population is chosen at one place, `eval/calib/engine_cell_
           correction.py`, which selects the learning side by name and never touches
           `store.OUTCOMES_PLATFORM_DIR`.
  MONITOR: `monitor_engine_cell_correction` scores an ALREADY SHIPPED table against a fresh population, which
           is the one thing a platform record may be used for here. It returns a verdict and writes no table,
           so a real job can withdraw a factor that has stopped helping and can never set one.

EVERY GATE BELOW CAN REFUSE A FACTOR, AND THE THREE REFUSE ON DIFFERENT EVIDENCE. `MIN_RECORDS` is about how
many parts spoke; the median's confidence interval is about whether they agreed on the DIRECTION; the
within-factor score re-scores every part with the multiplier applied and is the only one that can fail while
the other two pass. Measured on the 132 learning cases that delivered a mesh, each gate refused a different
row (docs/cell_forecast_correction.md, section 3), which is why all three are here.
"""
from __future__ import annotations

import math
import statistics
from collections.abc import Iterable
from datetime import UTC, datetime
from functools import lru_cache
from pathlib import Path
from typing import Any, NamedTuple

from geometry_agent.learn import store
from geometry_agent.learn.schema import OutcomeRecord

CELL_BINS: tuple[tuple[str, float, float], ...] = (
    ("under_0.5M", 0.0, 500_000.0),
    ("0.5_to_1M", 500_000.0, 1_000_000.0),
    ("1_to_2M", 1_000_000.0, 2_000_000.0),
    ("over_2M", 2_000_000.0, float("inf")),
)
#: The export names representations carve, fluid_domain and external; the catalog says wall_shell,
#: fluid_domain, annular_fluid and external. Both vocabularies resolve to the fitted key.
REPRESENTATION_ALIASES = {
    "carve": "carve", "wall_shell": "carve", "body_surface": "carve",
    "fluid_domain": "fluid_domain", "fluid": "fluid_domain", "annular_fluid": "fluid_domain",
    "external": "external",
}


def cells_bin(cells: float | int) -> str:
    for name, lo, hi in CELL_BINS:
        if lo <= cells < hi:
            return name
    return CELL_BINS[-1][0]


def _quantile(values: list[float], f: float) -> float:
    xs = sorted(values)
    if len(xs) == 1:
        return xs[0]
    k = f * (len(xs) - 1)
    i = int(k)
    return xs[i] if i + 1 >= len(xs) else xs[i] + (xs[i + 1] - xs[i]) * (k - i)


def _p90(values: list[float]) -> float:
    return _quantile(values, 0.9)


def _summary(values: list[float]) -> dict[str, Any]:
    if not values:
        return {"n": 0, "median": None, "p90": None}
    return {"n": len(values), "median": round(statistics.median(values), 2), "p90": round(_p90(values), 2)}


def fit_minutes_bins(records: list[OutcomeRecord], split_sha256: str | None = None) -> dict[str, Any]:
    """Minutes per dispatched attempt, binned by the cells the attempt delivered, per engine and pooled. Attempts
    that were dispatched but delivered no mesh are their own row (`no_mesh`): the minutes the stack paid for a
    pass that did not succeed. Only learning records are passed in by the caller."""
    per_engine: dict[str, dict[str, list[float]]] = {}
    for rec in records:
        if rec.split != "learning":
            continue
        for a in rec.builder.attempts:
            if not a.dispatched or a.seconds is None or a.seconds <= 0:
                continue
            eng = a.engine or rec.geometry.engine or "unknown"
            minutes = a.seconds / 60.0
            name = cells_bin(a.quality.cells) if a.quality.cells else "no_mesh"
            for key in (eng, "all"):
                per_engine.setdefault(key, {}).setdefault(name, []).append(minutes)
    table = {}
    for eng, bins in per_engine.items():
        table[eng] = {name: _summary(bins.get(name, [])) for name, _, _ in CELL_BINS}
        table[eng]["no_mesh"] = _summary(bins.get("no_mesh", []))
        table[eng]["all_dispatched"] = _summary([m for v in bins.values() for m in v])
    return {
        "version": 1, "date": datetime.now(UTC).date().isoformat(), "split": "learning", "split_sha256": split_sha256,
        "records": sum(1 for r in records if r.split == "learning"),
        "bins": [{"name": n, "cells_min": lo, "cells_max": (None if hi == float("inf") else hi)} for n, lo, hi in CELL_BINS],
        "basis": "minutes = finished_utc - started_utc of each dispatched attempt in runs.json; cells from the attempt's score",
        "table": table,
    }


@lru_cache(maxsize=8)
def _load(path: str) -> dict[str, Any] | None:
    p = Path(path)
    if not p.exists():
        return None
    return store.read_json(p)


def reload() -> None:
    _load.cache_clear()


def minutes_for_cells(cells: float | int, engine: str = "snappy", path: Path = store.MINUTES_BINS) -> dict[str, Any]:
    """The forecast basis for one mesh: typical (median) and p90 minutes of learning-half attempts in the same
    cells bin on the same engine, with n so a thin bin is visible. Falls back to the pooled table when the
    engine has no rows; typical is None when nothing was fitted."""
    doc = _load(str(path))
    name = cells_bin(cells)
    out = {"cells": int(cells), "bin": name, "engine": engine, "typical": None, "p90": None, "n": 0, "basis": None}
    if not doc:
        return out
    table = doc.get("table", {})
    for key in (engine, "all"):
        row = table.get(key, {}).get(name)
        if row and row.get("n"):
            out.update({"typical": row["median"], "p90": row["p90"], "n": row["n"], "engine": key,
                        "basis": f"{doc.get('split')} records, split {str(doc.get('split_sha256'))[:8]}, {doc.get('date')}"})
            return out
    return out


def fit_cell_correction(records: list[OutcomeRecord], split_sha256: str | None = None,
                        label_version: int | None = None) -> dict[str, Any]:
    """The median of the delivered cells over the standard-tier estimate, per representation, on learning
    records that delivered a mesh. The multiplier turns the facts layer's estimate into the builder's count."""
    ratios: dict[str, list[float]] = {}
    for rec in records:
        if rec.split != "learning":
            continue
        est = rec.geometry.tier_estimates.get("standard")
        cells = rec.labels.cells
        rep = REPRESENTATION_ALIASES.get(rec.geometry.representation or "", rec.geometry.representation)
        if not est or not cells or not rep:
            continue
        ratios.setdefault(rep, []).append(cells / est)
    fitted = {}
    for rep, xs in sorted(ratios.items()):
        xs = sorted(xs)
        fitted[rep] = {"multiplier": round(statistics.median(xs), 3), "n": len(xs),
                       "p25": round(xs[len(xs) // 4], 3), "p75": round(xs[(3 * len(xs)) // 4], 3),
                       "min": round(xs[0], 3), "max": round(xs[-1], 3)}
    return {
        "version": 1, "date": datetime.now(UTC).date().isoformat(), "split": "learning", "split_sha256": split_sha256,
        "label_version": label_version, "records": sum(1 for r in records if r.split == "learning"),
        "basis": "median over learning records of delivered cells / standard-tier estimate (facts layer, diagonal/80)",
        "by_representation": fitted,
    }


def cell_correction(representation: str | None, path: Path = store.CELL_CORRECTION) -> float:
    """The multiplier for one representation, 1.0 when nothing was fitted for it."""
    doc = _load(str(path))
    if not doc or not representation:
        return 1.0
    rep = REPRESENTATION_ALIASES.get(representation, representation)
    row = doc.get("by_representation", {}).get(rep)
    return float(row["multiplier"]) if row and row.get("multiplier") else 1.0


def cell_correction_info(representation: str | None, path: Path = store.CELL_CORRECTION) -> dict[str, Any]:
    doc = _load(str(path))
    rep = REPRESENTATION_ALIASES.get(representation or "", representation)
    row = (doc or {}).get("by_representation", {}).get(rep) if doc else None
    return {"representation": rep, "multiplier": float(row["multiplier"]) if row else 1.0, "n": row["n"] if row else 0,
            "date": doc.get("date") if doc else None, "split_sha256": doc.get("split_sha256") if doc else None,
            "source": str(path) if row else "none (unfitted, multiplier 1.0)"}


# ---------------------------------------------------------------------------------------------------------------
# the per-engine correction of the builder emulator's forecast
# ---------------------------------------------------------------------------------------------------------------
#: Where the fitted table lives: INSIDE THE PACKAGE, beside the module that reads it, the way
#: `agent/thresholds.py` holds `thresholds.json` (`Path(__file__).with_name`).
#:
#: NOT under `store.CALIB_DIR`, and this is the difference between a correction that applies and one that only
#: exists. `store.ROOT` is `Path(__file__).resolve().parents[3]`, which is the repository from a source checkout
#: and `/usr/local/lib/python3.11` from the vendored wheel the stack installs, so `store.CALIB_DIR` in the
#: running container is `/usr/local/lib/python3.11/eval/calib`, which does not exist. Measured inside the live
#: api container at platform `3701858` with agent wheel `0.1.0+g1fb530cf5e`:
#:
#:     CALIB_DIR  /usr/local/lib/python3.11/eval/calib False
#:     cell_correction('external') = 1.0
#:     minutes_for_cells(1e6) = {'typical': None, 'n': 0}
#:
#: Both of the older tables are therefore unfitted in production however carefully they were fitted here
#: (docs/cell_forecast_correction.md section 5.3). A table named in `pyproject.toml`'s package-data travels in
#: the wheel and is found by `__file__`, which is why this one lives here.
ENGINE_CELL_CORRECTION = Path(__file__).with_name("engine_cell_correction.json")
#: The basis string, which `hexera.EMULATOR_BASIS_WORDS` checks before applying anything out of this file. Refit
#: against a different estimator and this sentence has to change with it, which turns that refusal back on.
ENGINE_BASIS = ("median over one sample per geometry of delivered cells / estimate_builder_cells cells_high, "
                "per engine and representation, on learning records that delivered a mesh")
#: The fewest geometries a factor may be fitted from. THIS NUMBER IS NOT A ROUND ONE AND IT IS NOT A TASTE.
#: A factor is a median, and the honest bound on a median is the two-sided order-statistic (sign test)
#: interval. At n = 12 the smallest interval reaching 95 percent coverage is [x(3), x(10)]: it drops the two
#: most extreme samples at each end, so no single freak part can be the bound. At n = 11 the same coverage
#: needs [x(2), x(10)], where the second sample IS the bound, and below n = 6 no interval exists at all. 12 is
#: therefore the smallest n at which the interval is a statement about the population rather than about its
#: extremes, and `tests/test_learn_engine_correction.py` proves that property of 12 rather than asserting it.
MIN_RECORDS = 12
#: The coverage the median's interval is computed at.
MEDIAN_CI_LEVEL = 0.95
#: "Close enough" for a cell forecast, and the yardstick the third gate scores with. Cells scale as the cube of
#: the mesh size, so 1.5x in cells is 1.14x in the cell the builder would have to choose to hit it: a forecast
#: inside 1.5x names the same mesh and one outside it does not. It is deliberately tighter than the 2x a reader
#: might reach for: at 2x the external row scored 30 of 31 BEFORE correction and the third gate would have had
#: nothing left to say.
WITHIN_FACTOR = 1.5


class CellSample(NamedTuple):
    """One part's forecast against what the builder delivered.

    `geometry` is the identity of the PART, and the caller's job is to make it the CAD file's own hash rather
    than the measurement's. Both the fit and the monitor collapse a geometry's samples to one before anything is
    counted, because otherwise one part counts many times, and that is not hypothetical in either direction:

      - of the 8 finished platform jobs in the local database that carry both a forecast and a delivered count,
        all 8 are one part (ahmed_variant_001, sha 9c8b9b95), and `eval/platform/summary_2026-09-25.json`
        published "n 5" for it with nothing saying it was one geometry;
      - `eval/outcomes` holds two records for each of the 322 corpus cases, same file and two measurement
        revisions, so keying on the facts sha doubled every n and moved the carve row's interval from
        [0.967, 1.484], which contains 1.0, to [1.024, 1.321], which does not.

    The second one would have shipped a multiplier on the strength of counting each part twice.
    """

    geometry: str
    engine: str
    representation: str
    forecast: float
    delivered: float
    case: str = ""


def _sign_test_interval(values: list[float], level: float = MEDIAN_CI_LEVEL) -> tuple[float | None, float | None, int | None]:
    """The two-sided order-statistic interval for the median: [x(k+1), x(n-k)] for the largest k whose coverage
    1 - 2 P(Bin(n, 0.5) <= k) still reaches `level`. None when no k reaches it, which is every n under 6."""
    xs = sorted(values)
    n = len(xs)
    if n < 6:
        return None, None, None
    best: int | None = None
    total = 2.0 ** n
    for k in range(n // 2):
        if 1.0 - 2.0 * (sum(math.comb(n, i) for i in range(k + 1)) / total) >= level:
            best = k
        else:
            break
    if best is None:
        return None, None, None
    return xs[best], xs[n - 1 - best], best


def _ratios_by_geometry(samples: Iterable[CellSample]) -> dict[tuple[str, str], dict[str, list[float]]]:
    """Every run's ratio, grouped by (engine, representation) then by geometry. Nothing is collapsed yet."""
    per: dict[tuple[str, str], dict[str, list[float]]] = {}
    for s in samples:
        if not s.forecast or not s.delivered or s.forecast <= 0 or s.delivered <= 0:
            continue
        rep = REPRESENTATION_ALIASES.get(s.representation or "", s.representation) or "unknown"
        per.setdefault((s.engine or "unknown", rep), {}).setdefault(s.geometry, []).append(s.delivered / s.forecast)
    return per


def _one_sample_per_geometry(samples: Iterable[CellSample]) -> dict[tuple[str, str], dict[str, float]]:
    """Ratios grouped by (engine, representation), one per geometry: the median of that geometry's own runs."""
    return {key: {g: statistics.median(rs) for g, rs in by_geom.items()}
            for key, by_geom in _ratios_by_geometry(samples).items()}


def _within(ratios: Iterable[float], multiplier: float, factor: float = WITHIN_FACTOR) -> int:
    """How many forecasts land inside `factor` of the delivered count once `multiplier` is applied."""
    return sum(1 for r in ratios if (1.0 / factor) <= (r / multiplier) <= factor)


def _engine_row(ratios: dict[str, float]) -> dict[str, Any]:
    """One (engine, representation) row: the candidate multiplier, its evidence, and the gate's verdict.

    The three gates in order, each carrying the words that say which one refused. A row is `applied` only when
    all three pass, and a refused row keeps its `candidate` so a reader can see the number that was not shipped.
    """
    xs = sorted(ratios.values())
    n = len(xs)
    median = statistics.median(xs)
    geomean = math.exp(statistics.fmean(math.log(x) for x in xs))
    p10, p90 = _quantile(xs, 0.10), _quantile(xs, 0.90)
    lo, hi, dropped = _sign_test_interval(xs)
    before, after = _within(xs, 1.0), _within(xs, median)
    row: dict[str, Any] = {
        "candidate": round(median, 4), "multiplier": 1.0, "applied": False, "n": n, "geometries": n,
        "median": round(median, 4), "geomean": round(geomean, 4), "p10": round(p10, 4), "p90": round(p90, 4),
        "min": round(xs[0], 4), "max": round(xs[-1], 4),
        "dispersion_p90_over_p10": round(p90 / p10, 2) if p10 else None,
        "median_ci": [round(lo, 4), round(hi, 4)] if lo is not None else None,
        "median_ci_level": MEDIAN_CI_LEVEL, "median_ci_drops_each_end": dropped,
        "within_factor": WITHIN_FACTOR, "within_raw": before, "within_corrected": after, "why": "",
    }
    if n < MIN_RECORDS:
        row["why"] = (f"{n} geometries is under the minimum of {MIN_RECORDS}, the smallest n whose "
                      f"{MEDIAN_CI_LEVEL:g} interval for the median drops the two most extreme samples at each "
                      f"end; 1.0 applied")
        return row
    if lo is None or hi is None:
        row["why"] = f"no {MEDIAN_CI_LEVEL:g} interval exists at n {n}; 1.0 applied"
        return row
    if lo <= 1.0 <= hi:
        row["why"] = (f"the {MEDIAN_CI_LEVEL:g} interval for the median is [{lo:.3f}, {hi:.3f}], which contains 1.0: "
                      f"these {n} geometries do not agree on the DIRECTION of the error, so there is no bias to "
                      f"correct and a multiplier of {median:.3f} would be a fact that lies; 1.0 applied")
        return row
    if after <= before:
        row["why"] = (f"applying {median:.3f} leaves {after} of {n} forecasts within {WITHIN_FACTOR:g}x of the "
                      f"delivered count against {before} of {n} raw, so the multiplier does not make the forecast "
                      f"better on the parts it was fitted from; 1.0 applied")
        return row
    row["multiplier"] = round(median, 4)
    row["applied"] = True
    row["why"] = (f"{n} geometries, median {median:.3f}, {MEDIAN_CI_LEVEL:g} interval [{lo:.3f}, {hi:.3f}] entirely "
                  f"{'above' if lo > 1.0 else 'below'} 1.0, and applying it takes {before} of {n} forecasts within "
                  f"{WITHIN_FACTOR:g}x of delivered to {after} of {n}")
    return row


def fit_engine_cell_correction(samples: Iterable[CellSample], split_sha256: str | None = None,
                               label_version: int | None = None, population: str = "learning") -> dict[str, Any]:
    """The per-engine correction of the emulator's forecast, from samples the caller chose.

    THIS FUNCTION OPENS NO FILE. The population is the caller's decision and is named in the document it
    returns, which is how the split stays governed in one place instead of in every reader.
    """
    by_key = _one_sample_per_geometry(samples)
    table = {f"{eng}/{rep}": _engine_row(ratios) for (eng, rep), ratios in sorted(by_key.items())}
    return {
        "version": 1, "date": datetime.now(UTC).date().isoformat(), "split": population,
        "split_sha256": split_sha256, "label_version": label_version,
        "geometries": sum(len(r) for r in by_key.values()),
        "basis": ENGINE_BASIS,
        "gates": {"min_records": MIN_RECORDS, "median_ci_level": MEDIAN_CI_LEVEL, "within_factor": WITHIN_FACTOR,
                  "rule": "a factor is applied only when it is fitted from at least min_records GEOMETRIES, when "
                          "its median's interval excludes 1.0, and when applying it raises the share of "
                          "forecasts within within_factor of the delivered count"},
        "by_engine": table,
    }


def engine_cell_correction(engine: str | None, representation: str | None, path: Path | None = None) -> float:
    """The admitted multiplier for one engine and representation, 1.0 when none was admitted."""
    return float(engine_cell_correction_info(engine, representation, path)["multiplier"])


def engine_cell_correction_info(engine: str | None, representation: str | None,
                                path: Path | None = None) -> dict[str, Any]:
    """The multiplier and everything a later reader needs to tell a corrected forecast from a raw one: the n it
    was fitted from, the interval, whether it was applied, and in words why not when it was not.

    An engine with no row at all is reported as such rather than as a bare 1.0: absence of a factor is not
    evidence that the forecast is unbiased for that engine, and the two have to read differently.

    `path` is resolved HERE and not in the signature. A default argument is bound at import, so a table path
    named in the signature cannot be redirected by a test or by a caller that has moved the calib directory, and
    the redirect fails silently by reading the shipped file instead - which is how the first version of
    `tests/test_learn_engine_correction.py` measured the real external multiplier while believing it had set 2.0.
    """
    path = Path(path) if path is not None else ENGINE_CELL_CORRECTION
    rep = REPRESENTATION_ALIASES.get(representation or "", representation)
    doc = _load(str(path))
    out: dict[str, Any] = {"engine": engine, "representation": rep, "multiplier": 1.0, "applied": False, "n": 0,
                           "basis": None, "why": "no fitted table", "source": "none (unfitted, multiplier 1.0)",
                           "date": None, "split": None, "split_sha256": None}
    if not doc:
        return out
    out.update({"basis": doc.get("basis"), "date": doc.get("date"), "split": doc.get("split"),
                "split_sha256": doc.get("split_sha256")})
    rows = doc.get("by_engine") or {}
    row = rows.get(f"{engine}/{rep}")
    if row is None:
        out["why"] = (f"the table carries no row for {engine}/{rep} (it has {', '.join(sorted(rows)) or 'none'}), "
                      f"so nothing is known about this engine's bias and 1.0 is applied")
        return out
    out.update({"n": row.get("n", 0), "applied": bool(row.get("applied")), "candidate": row.get("candidate"),
                "median_ci": row.get("median_ci"), "dispersion_p90_over_p10": row.get("dispersion_p90_over_p10"),
                "within_raw": row.get("within_raw"), "within_corrected": row.get("within_corrected"),
                "why": row.get("why") or "", "source": str(path)})
    if row.get("applied"):
        out["multiplier"] = float(row.get("multiplier") or 1.0)
    return out


def monitor_engine_cell_correction(samples: Iterable[CellSample], path: Path | None = None,
                                   population: str = "platform") -> dict[str, Any]:
    """Score the SHIPPED table against a fresh population. Fits nothing and writes nothing.

    This is the only thing a `platform` record may be used for here. A verdict needs `MIN_RECORDS` DISTINCT
    GEOMETRIES, for the reason `CellSample.geometry` gives: the local database's 8 finished jobs that carry both
    numbers are one part, and a median over them is a statement about that part. Below the minimum the row says
    `too_few` and still carries the numbers, which is the honest reading and is not a verdict.
    """
    path = Path(path) if path is not None else ENGINE_CELL_CORRECTION
    raw_by_key = _ratios_by_geometry(samples)
    rows: dict[str, Any] = {}
    for (eng, rep), by_geom in sorted(raw_by_key.items()):
        info = engine_cell_correction_info(eng, rep, path)
        m = float(info["multiplier"])
        xs = sorted(statistics.median(rs) for rs in by_geom.values())
        # The collapsed samples are what any verdict is taken on, and the runs behind them are what the reading
        # is. Reporting only the collapsed spread on one part would print min == max == the median and read as
        # five jobs agreeing, when the five ran from 1.492 to 3.649 on the same geometry.
        every = sorted(r for rs in by_geom.values() for r in rs)
        before, after = _within(xs, 1.0), _within(xs, m)
        row = {"geometries": len(xs), "rows_seen": len(every), "shipped_multiplier": m, "shipped_n": info["n"],
               "applied": info["applied"], "median": round(statistics.median(xs), 4),
               "min": round(xs[0], 4), "max": round(xs[-1], 4),
               "every_run_min": round(every[0], 4), "every_run_max": round(every[-1], 4),
               "within_factor": WITHIN_FACTOR, "within_raw": before, "within_shipped": after}
        if len(xs) < MIN_RECORDS:
            row["verdict"] = "too_few"
            row["why"] = (f"{len(every)} runs over {len(xs)} distinct geometries, ratios {every[0]:.3f} to "
                          f"{every[-1]:.3f}; {len(xs)} geometries is under the minimum of {MIN_RECORDS}, so the "
                          f"numbers are reported and no verdict is published")
        elif not info["applied"]:
            row["verdict"] = "nothing_shipped"
            row["why"] = f"no multiplier is applied for {eng}/{rep}: {info['why']}"
        elif after >= before:
            row["verdict"] = "still_helps"
            row["why"] = f"the shipped {m:g} takes {before} of {len(xs)} within {WITHIN_FACTOR:g}x to {after}"
        else:
            row["verdict"] = "withdraw"
            row["why"] = (f"the shipped {m:g} takes {before} of {len(xs)} within {WITHIN_FACTOR:g}x DOWN to {after}: "
                          f"it no longer helps on this population and should be refitted or withdrawn")
        rows[f"{eng}/{rep}"] = row
    return {"schema": "geometry_agent.learn.engine_correction_monitor.v1", "population": population,
            "date": datetime.now(UTC).date().isoformat(), "table": str(path), "fits_nothing": True,
            "geometries": sum(len(r) for r in raw_by_key.values()), "by_engine": rows}
