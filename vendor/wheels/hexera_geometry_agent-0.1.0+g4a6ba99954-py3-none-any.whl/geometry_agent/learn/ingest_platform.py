"""Finished jobs on the real platform as OutcomeRecords (docs/learning_loop.md section 10).

    python -m geometry_agent.learn.ingest <exports_dir> --source platform [--platform-outcomes DIR]

`<exports_dir>` holds one envelope per job, written by `meshpipeline.application.learning_export`
(`schema: meshpipeline.learning_export.v1`). This module never touches a database, never runs a model and never
measures geometry: everything it needs is in the envelope, and the only computation it does is the join that
turns a question and an answer into a label.

WHAT IT PRODUCES, per job:

  `answers`   one row per PLACE per survey question. `proposed` is what this platform would have done unasked,
              `answer` is what the human said, and `verdict` is `corrected` when they differ. That row is a
              labelled example on a real part, from a question we were going to ask anyway, at zero annotation
              cost - which is the entire argument of `geometry_agent.ask.record`, finally joined up.
  `platform`  the reviewer's verdict, the quality gate's measured numbers, the agent's cell forecast against
              the cells the builder delivered, and the look beside the representation the job settled on.
  `geometry`  the same block the corpus ingest writes, rebuilt from the envelope's own measurement document
              rather than from a facts cache - a real job's measurement IS its record.

THREE THINGS IT REFUSES TO DO, each because doing it would produce a number that lies:

  1. A DELEGATION IS NOT A CONFIRMATION. "you decide everything" is recorded on this platform as the
     customer's answer, with the customer's authority, and the value stored is this platform's own pick. Four
     of the eight local survey rows are like that. Scoring them as agreement would report the proposal correct
     on exactly the jobs where the customer said nothing about the substance, and the error would compound
     invisibly (`ask.record.RATCHET_RULES`, the fourth rule). The exporter flags each answer with
     `delegated`, computed by the platform's own `recommendation.choice_deferred` - the same predicate
     `geometry_survey.said_by_customer` used to accept the quote in the first place - and a row whose flag is
     ABSENT is `unknown_authority`, never a label.
  2. THE PER-PLACE PROPOSAL IS NOT THE QUESTION'S DEFAULT. `ask.record.answered` computes
     `default_overturned` against the question-level `default`, which on the role question is the sentence
     "treat o1 as the inlet and the other unplaced mouths as outlets". The answer is the word "inlet". So that
     function calls every role answer an overturn, including four of four the customer confirmed on job
     489fa1ab. The comparison here is `targets[].proposed` against the answer's machine `value`, per place.
  3. A PLATFORM RECORD IS NEITHER LEARNING NOR LOCKED. `assign_split` gives it the `platform` side and the
     records go to `eval/outcomes_platform/`, so no calibration table, feature bank, sweep, ledger or rule
     card can read one (`tests/test_learn_isolation.py`).

R2 (docs/dev_plan_v3.md section 3) applies here as everywhere: the stamps ride on the record
(`platform.platform_sha`, `agent_git_sha`, `facts_schema_version`, `step_model`, `survey_state_schema`) and two
batches taken under different stamps are not compared. The noise floor is the corpus panel's and nothing about
a platform batch is smaller than it, so a single batch is a reading and not a result.
"""
from __future__ import annotations

import json
import math
import re
import statistics
from collections import Counter
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from geometry_agent.learn import store
from geometry_agent.learn.schema import (
    DELTA_ADJUDICATED,
    LABEL_VERDICTS,
    LOOK_ROLE_ABSTENTIONS,
    LOOK_ROLE_WORDS,
    OUTCOME_SCHEMA_VERSION,
    ROLE_LABEL_VERDICTS,
    AgentBlock,
    AnswerOutcome,
    Attempt,
    BuilderBlock,
    Forecast,
    Geometry,
    IntakeBlock,
    Labels,
    LookAgreement,
    LookCounterfactual,
    OutcomeRecord,
    PlatformBlock,
    ProposalDelta,
    Quality,
    ReviewerBlock,
    SeenRole,
    assign_split,
    intake_topic,
    job_key,
)

EXPORT_SCHEMA = "meshpipeline.learning_export.v1"

#: The platform's word for a default that stood, in the survey row's `answered_by`. It is not an answer.
DEFAULT_TAKEN = "default_taken"
CUSTOMER = "customer"

#: The alert the reconciler raises when the look's lettered answers say the representation is wrong. It is the
#: ONE reading in this package that has been measured against a held-out ground truth, so it is the only thing
#: allowed to turn `representation_verdict` to `disagreed`, and it is re-run rather than restated.
REPRESENTATION_ALERT = "the_letters_say_the_representation_is_wrong"

_SPACE = re.compile(r"\s+")


def _norm(value: Any) -> str:
    """The comparison `ask.record._norm` uses, so a proposal and an answer that differ only in spelling of a
    machine value are not reported as a correction."""
    return _SPACE.sub(" ", str(value if value is not None else "").strip().lower().replace("_", " ")).strip()


@dataclass
class PlatformIngestReport:
    envelopes: int = 0
    records: int = 0
    written: int = 0
    unchanged: int = 0
    refused: dict[str, str] = field(default_factory=dict)
    absent: Counter = field(default_factory=Counter)
    split_counts: Counter = field(default_factory=Counter)
    verdicts: Counter = field(default_factory=Counter)
    label_rows: int = 0
    forecast_ratios: list[float] = field(default_factory=list)
    reviewer: Counter = field(default_factory=Counter)
    look_verdicts: Counter = field(default_factory=Counter)
    #: the look's per-mouth role score (`ROLE_VERDICTS`) pooled over the batch
    role_verdicts: Counter = field(default_factory=Counter)
    #: the without-the-look comparison: per-field verdicts, and the jobs it could not be computed on
    delta_verdicts: Counter = field(default_factory=Counter)
    counterfactual_jobs: int = 0
    counterfactual_refused: Counter = field(default_factory=Counter)
    counterfactual_unfaithful: int = 0
    paths: list[Path] = field(default_factory=list)
    outcomes_dir: Path | None = None

    def summary(self) -> str:
        parts = [f"{self.envelopes} envelopes, {self.records} records ({self.written} written, "
                 f"{self.unchanged} unchanged)",
                 "split " + (", ".join(f"{k} {v}" for k, v in sorted(self.split_counts.items())) or "none"),
                 f"{sum(self.verdicts.values())} answer rows, {self.label_rows} of them labels: "
                 + (", ".join(f"{k} {v}" for k, v in sorted(self.verdicts.items())) or "none"),
                 "reviewer " + (", ".join(f"{k} {v}" for k, v in sorted(self.reviewer.items())) or "none")]
        if self.forecast_ratios:
            rs = sorted(self.forecast_ratios)
            parts.append(f"delivered/forecast n {len(rs)}, median {statistics.median(rs):.3g}, "
                         f"min {rs[0]:.3g}, max {rs[-1]:.3g}")
        else:
            parts.append("delivered/forecast: no job carried both numbers")
        parts.append("look " + (", ".join(f"{k} {v}" for k, v in sorted(self.look_verdicts.items())) or "none"))
        parts.append("look roles per mouth: "
                     + (", ".join(f"{k} {v}" for k, v in sorted(self.role_verdicts.items())) or "none"))
        parts.append(f"without the look: {self.counterfactual_jobs} jobs computed, "
                     f"{self.counterfactual_unfaithful} whose replay does not reproduce the row; "
                     + (", ".join(f"{k} {v}" for k, v in sorted(self.delta_verdicts.items())) or "no fields"))
        if self.counterfactual_refused:
            parts.append("without the look not computed: "
                         + ", ".join(f"{k} {v}" for k, v in self.counterfactual_refused.most_common(3)))
        if self.refused:
            parts.append(f"refused {len(self.refused)}: "
                         + "; ".join(f"{k[:8]} {v}" for k, v in list(self.refused.items())[:3]))
        if self.absent:
            parts.append("absent halves " + ", ".join(f"{k} {v}" for k, v in self.absent.most_common(5)))
        return "; ".join(parts)


# -------------------------------------------------------------------------------------------------
# the envelope
# -------------------------------------------------------------------------------------------------

def load_envelopes(exports_dir: Path) -> list[tuple[Path, dict[str, Any]]]:
    """Every envelope in the directory, in name order. A file that is not one is skipped by its schema."""
    out = []
    for p in sorted(Path(exports_dir).glob("*.json")):
        try:
            doc = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        if isinstance(doc, dict) and doc.get("schema") == EXPORT_SCHEMA:
            out.append((p, doc))
    return out


def facts_of(env: dict[str, Any]):
    """GeometryFacts rebuilt from the envelope's own measurement document, and the digest the learning loop
    keys on.

    THE DIGEST IS COMPUTED HERE AND NEVER COPIED FROM THE ENVELOPE, because the platform's column of the same
    name is the FILE's sha256 (see `learning_export`'s docstring: every local row has
    `sha256 == facts_sha256`). `store.facts_sha256` hashes the measurement's canonical JSON with `timings`
    removed, which is what a record's file name and job key mean by the word.

    THE CHECK THAT CAN FAIL DIFFERENTLY FROM WHAT IT CHECKS. `facts.sha256` inside the document was written by
    the measurement, from the bytes it opened; `source.source_sha256` in the envelope was written by the API
    from the bytes as they streamed in, by different code in a different process. They must be equal, and a
    document that describes bytes other than the ones the job meshed is refused rather than recorded.
    """
    from geometry_agent.facts.schema import GeometryFacts
    m = env.get("measurement") or {}
    doc = m.get("document") or {}
    raw = doc.get("facts")
    if not isinstance(raw, dict):
        raise ValueError("the measurement document carries no facts block")
    facts = GeometryFacts.model_validate(raw)
    declared_by_the_api = str(((env.get("source") or {}).get("source_sha256")) or "")
    if declared_by_the_api and facts.sha256 != declared_by_the_api:
        raise ValueError(f"the measurement describes {facts.sha256[:12]} and the job meshed "
                         f"{declared_by_the_api[:12]}")
    return facts, store.facts_sha256(facts)


def geometry_of(env: dict[str, Any], facts, fsha: str) -> Geometry:
    comp = (env.get("survey") or {}).get("composed_for") or {}
    doc = ((env.get("measurement") or {}).get("document")) or {}
    src = env.get("source") or {}
    std = next((e for e in facts.cell_estimates if e.tier == "standard"), None)
    declared = comp.get("declared")
    return Geometry(
        case=str(env.get("case") or f"platform__{facts.sha256[:8]}"),
        source_path=str(src.get("original_filename") or ""),
        sha256=facts.sha256, facts_sha256=fsha, facts_schema_version=facts.schema_version,
        family="platform",
        #: every job on one uploaded file groups together, so a report can count parts and not jobs
        group=f"platform__{facts.sha256[:12]}",
        representation=comp.get("representation") or doc.get("representation"),
        engine=comp.get("engine") or doc.get("engine"),
        purpose=str(comp.get("purpose") or doc.get("purpose") or ""),
        unit=comp.get("unit") or (env.get("interpretation") or {}).get("unit"),
        cell_cap=comp.get("cell_cap"),
        declared=list(declared) if isinstance(declared, list) else [],
        bbox_extent=tuple(facts.bbox.extent), n_openings=len(facts.openings),
        tier_estimates={e.tier: int(e.cells) for e in facts.cell_estimates},
        base_size=std.base_size if std else None, surface_cell=std.surface_cell if std else None,
    )


# -------------------------------------------------------------------------------------------------
# the label: what we would have done, and what they said
# -------------------------------------------------------------------------------------------------

def _answers_for(answers: list[dict[str, Any]], qid: str) -> list[dict[str, Any]]:
    return [a for a in answers if isinstance(a, dict) and a.get("question_id") == qid]


def _pick(rows: list[dict[str, Any]], place: str | None) -> dict[str, Any] | None:
    """The answer that placed this target: a live one if there is one, else the last retired one.

    A role question's answers each name their mouth in `subject`; every other question's answer names none.

    A RETIRED ROW IS STILL THE ANSWER THE JOB RAN ON, in one of the two ways a row gets retired, and telling
    them apart is why `retired_because` travels. `geometry_survey._corrected` retires a row the customer
    themselves replaced (`retired_because: superseded`, with `superseded_by`) - there a live row exists and
    wins. `carry_answers` retires a row whose QUESTION the next composition no longer raises, with no
    `retired_because` - and that is what a settled question looks like: the fluid-side answer on job 489fa1ab
    is retired that way, and `composed_for.confirmed_representation` is the value it set. Reading only live
    rows would report that job as having answered nothing about the representation.
    """
    mine = list(rows) if place is None else [a for a in rows if str(a.get("subject") or "") == str(place)]
    live = [a for a in mine if not a.get("retired")]
    if live:
        return live[-1]
    return mine[-1] if mine else None


def quote_chooses(answer: dict[str, Any], place: str | None, n_places: int) -> bool:
    """Whether the customer's OWN WORDS name the option the answer was recorded as.

    THE THIRD GATE, AND IT WAS FOUND BY RUNNING THIS ON REAL JOBS. The first two gates are the platform's:
    `said_by_customer` proves the quote is in the customer's message, and `_canonical_option` proves the choice
    is one of the question's options. Neither connects the two. `_canonical_option` checks the option the MODEL
    passed, so a model may record "o4 is the inlet" and quote the word "go" as the evidence - and the platform
    is right to accept "go", because it is an instruction to proceed. The answer is then this pipeline's own
    pick with a customer quote stapled to it, which is the same failure as a delegation by a different route,
    and it is not visible in `answered_by`.

    MEASURED on the 8 finished jobs in the local database on 2026-09-25: of 32 role answers, 20 were recorded on
    a delegation and 12 on the bare quote "go", and none on words naming a mouth and a role. Without this gate
    the batch reported 8 confirmed and 8 corrected - a port-role correction rate of 0.5 over 16 "labels", every
    one of them ours.

    IT CAN FAIL DIFFERENTLY FROM WHAT IT CHECKS, which is the point: the platform asks whether the quote is in
    the message and this asks whether the quote contains the answer. A quote that passes one can fail the other,
    in both directions.

    DELIBERATELY CONSERVATIVE, and it will lose a real label rather than invent one. "the big one is the inlet"
    names the role and not the mouth, and on a question that named four mouths this returns False: one quote
    cannot be shown to have placed four mouths. A lost label costs one row; a fabricated one is read as ground
    truth and compounds. The place is required only where the question named more than one, because with one
    mouth there is nothing to be ambiguous about. `docs/learning_loop.md` section 10.5 carries the one platform
    change that retires this gate: record WHICH WORDS selected which option, at the moment the answer is taken.
    """
    words = _norm(answer.get("words"))
    if not words:
        return False
    candidates = [_norm(answer.get("option")), _norm(answer.get("value"))]
    if not any(c and c in words for c in candidates):
        return False
    return not (n_places > 1 and place and _norm(place) not in words)


def chose_it_themselves(answer: dict[str, Any] | None, place: str | None,
                        n_places: int) -> tuple[str | None, str, str]:
    """Whether this row is the customer's OWN choice, and when it is not, which of the four reasons.

    Returns `(None, "customer", "")` for a row that may be scored against a proposal. Separated from the
    comparison so the two paths that need it - a target with a stored proposal, and an answer whose record row
    was overwritten - apply exactly the same four gates and cannot drift apart.
    """
    if answer is None:
        return "not_a_label", "unanswered", "no answer was recorded for this place"
    by = str(answer.get("answered_by") or "")
    if answer.get("skipped"):
        return "not_a_label", "skipped", "the customer was asked and declined to answer"
    if by == DEFAULT_TAKEN:
        return "not_a_label", "defaulted", "the default stood; silence is not agreement"
    if by != CUSTOMER:
        return "not_a_label", by or "unanswered", f"the answer was recorded by {by or 'nobody'}"
    delegated = answer.get("delegated")
    if delegated is None:
        return ("unknown_authority", CUSTOMER,
                "the export does not say whether the quote was a delegation, so this row cannot be scored")
    if delegated:
        return ("not_a_label", "delegated",
                f"the quote {str(answer.get('words') or '')[:40]!r} is a standing delegation: the value is "
                "this platform's own pick and teaches nothing about the part")
    if not quote_chooses(answer, place, n_places):
        return ("quote_does_not_choose", CUSTOMER,
                f"the customer's words {str(answer.get('words') or '')[:40]!r} do not name "
                f"{str(answer.get('option') or answer.get('value'))[:40]!r}"
                + (f" for {place}" if n_places > 1 and place else "")
                + ", so the value is this pipeline's pick with their quote on it")
    return None, CUSTOMER, ""


def _verdict(answer: dict[str, Any] | None, proposed: Any, place: str | None = None,
             n_places: int = 1) -> tuple[str, str, str]:
    """(verdict, answered_by, why) for one place. Six outcomes, and the four that are not labels say why."""
    verdict, by, why = chose_it_themselves(answer, place, n_places)
    if verdict is not None:
        return verdict, by, why
    assert answer is not None                       # chose_it_themselves refuses a missing answer
    if proposed is None:
        return ("not_a_label", CUSTOMER,
                "nothing was proposed for this place, so there is no proposal to confirm or overturn")
    said, ours = _norm(answer.get("value")), _norm(proposed)
    if said == ours:
        return "confirmed", CUSTOMER, f"the customer chose the proposal ({ours})"
    return "corrected", CUSTOMER, f"we would have said {ours}; the customer said {said}"


def answer_outcomes(env: dict[str, Any]) -> list[AnswerOutcome]:
    """Every question this job asked, fanned out to one row per place, joined to what came back.

    A question the finder PUT but for which it stored no record row still gets a row, with `proposed` None and
    the verdict `not_a_label`. Dropping it would let a job whose questions carried no proposals report a clean
    agreement rate over the handful that did.
    """
    survey = env.get("survey") or {}
    asking = survey.get("asking") or {}
    records = asking.get("record") if isinstance(asking.get("record"), dict) else {}
    tiers = asking.get("tier") if isinstance(asking.get("tier"), dict) else {}
    answers = [a for a in (survey.get("answers") or []) if isinstance(a, dict)]
    out: list[AnswerOutcome] = []
    seen_qids: set[str] = set()
    for qid, row in sorted(records.items()):
        if not isinstance(row, dict):
            continue
        seen_qids.add(qid)
        rows = _answers_for(answers, qid)
        look = row.get("look") if isinstance(row.get("look"), dict) else {}
        said = look.get("said") if isinstance(look.get("said"), dict) else {}
        targets = [t for t in (row.get("targets") or []) if isinstance(t, dict)]
        if not targets:
            targets = [{"field": str(row.get("kind") or ""), "place": None, "proposed": row.get("default")}]
        n_places = sum(1 for t in targets if t.get("place"))
        for t in targets:
            place = t.get("place")
            answer = _pick(rows, place)
            verdict, by, why = _verdict(answer, t.get("proposed"), place, n_places)
            measurement = t.get("measurement") if isinstance(t.get("measurement"), dict) else {}
            out.append(AnswerOutcome(
                question_id=qid, question_key=row.get("question_key"), kind=str(row.get("kind") or ""),
                field=str(t.get("field") or ""), place=None if place is None else str(place),
                tier=str((measurement.get("consequence") or {}).get("tier") or tiers.get(qid) or "") or None,
                proposed=None if t.get("proposed") is None else str(t.get("proposed")),
                answer=None if answer is None else (None if answer.get("value") is None
                                                    else str(answer.get("value"))),
                answered_by=by, delegated=None if answer is None else answer.get("delegated"),
                verdict=verdict, why=why,
                words=str((answer or {}).get("words") or ""), at=(answer or {}).get("at"),
                retired=bool((answer or {}).get("retired")),
                retired_because=(answer or {}).get("retired_because"),
                superseded_by=(answer or {}).get("superseded_by"),
                options=[str(o) for o in (row.get("options") or [])],
                look_said=dict(said.get(str(place)) or {}) if place is not None else {},
                look_tiers={str(k): str(v) for k, v in (look.get("tiers") or {}).items()},
                measurement={k: v for k, v in measurement.items() if k != "consequence"},
                consequence=dict(measurement.get("consequence") or {}),
            ))
    # AN ANSWER WHOSE PROPOSAL IS GONE IS STILL RECORDED, and as its own verdict, so the denominator is
    # honest and the platform defect behind it is visible instead of being pooled with "nobody chose".
    for a in answers:
        qid = str(a.get("question_id") or "")
        if qid in seen_qids or not qid:
            continue
        refused, by, why = chose_it_themselves(a, str(a.get("subject") or "") or None, 1)
        out.append(AnswerOutcome(
            question_id=qid, kind=str(a.get("about") or ""), field=str(a.get("about") or ""),
            place=str(a.get("subject") or "") or None, proposed=None,
            answer=None if a.get("value") is None else str(a.get("value")),
            answered_by=by, delegated=a.get("delegated"),
            verdict=refused or "proposal_not_stored",
            why=(why or "the customer chose, and the record row carrying what we would have done unasked was "
                        "overwritten when the survey was recomposed, so this answer cannot be scored"),
            words=str(a.get("words") or ""), at=a.get("at"), retired=bool(a.get("retired")),
            retired_because=a.get("retired_because"), superseded_by=a.get("superseded_by")))
    return out


# -------------------------------------------------------------------------------------------------
# the forecast, the look, and the job
# -------------------------------------------------------------------------------------------------

def _as_int(value: Any) -> int | None:
    if isinstance(value, bool) or value is None:
        return None
    try:
        i = int(value)
    except (TypeError, ValueError):
        return None
    return i if i >= 0 else None


def delivered_cells(env: dict[str, Any]) -> int | None:
    """The cells the builder delivered, from the quality block the pipeline wrote, or None.

    `quality.cell_count` first, then the `cells` criterion. None when neither is there, and None stays None:
    a job whose payload could not be read has no delivered count and no ratio.
    """
    q = env.get("quality") or {}
    n = _as_int(q.get("cell_count"))
    if n:
        return n
    crit = q.get("criteria") if isinstance(q.get("criteria"), dict) else {}
    for key in ("cells", "cell_count"):
        n = _as_int((crit.get(key) or {}).get("measured"))
        if n:
            return n
    return None


def forecast_of(env: dict[str, Any]) -> Forecast:
    env_block = ((env.get("step") or {}).get("envelope")) or {}
    high = _as_int(env_block.get("cells_high"))
    cap = _as_int(env_block.get("cap"))
    delivered = delivered_cells(env)
    ratio = round(delivered / high, 4) if (delivered and high) else None
    return Forecast(
        source=env_block.get("source"), cells_low=_as_int(env_block.get("cells_low")), cells_high=high,
        cap=cap, proper_cells_across=_as_int(env_block.get("proper_cells_across")), delivered=delivered,
        delivered_over_forecast=ratio,
        # None when the job stated no budget. A platform ceiling is not a customer cap (57324d2).
        over_cap=None if (cap is None or delivered is None) else bool(delivered > cap))


def look_agreement(env: dict[str, Any], facts, answers: list[AnswerOutcome] | None = None) -> LookAgreement:
    """The look beside the settled representation AND beside every mouth's settled role.

    `representation_verdict` is one field a part and it goes `no_comparable_claim` on a part whose
    representation nobody confirmed, which on the first batch was 7 of 8 jobs - so on its own this block
    measured the look on almost nothing. `answers` brings the per-opening half (`role_rows`), which is n rows a
    part on `openings_seen[].likely_role`, the field that decides the boundary conditions and the one this
    block never scored.
    """
    doc = ((env.get("measurement") or {}).get("document")) or {}
    look = doc.get("look") if isinstance(doc.get("look"), dict) else {}
    imp = look.get("impression") if isinstance(look.get("impression"), dict) else {}
    comp = (env.get("survey") or {}).get("composed_for") or {}
    settled = comp.get("confirmed_representation") or comp.get("representation")
    at_look = doc.get("representation")
    out = LookAgreement(
        status=look.get("status"), model=look.get("model"), provider=look.get("provider"),
        seconds=look.get("seconds"), confidence=imp.get("confidence"), looks_like=imp.get("looks_like"),
        representation_at_look=None if at_look is None else str(at_look),
        settled_representation=None if settled is None else str(settled))
    rows = list(answers or [])
    if not imp:
        out.reconcile_why_not = "the look produced no impression, so there is nothing to reconcile"
        return _with_the_openings(out, env, facts, rows)
    if not at_look:
        out.reconcile_why_not = "the document records no representation the look was taken with"
        return _with_the_openings(out, env, facts, rows)
    try:
        from geometry_agent.reconcile import joint
        jt = joint.for_job(facts, str(at_look), look, case=str(env.get("case") or ""))
    except Exception as exc:                       # noqa: BLE001 - the absence is recorded, never guessed
        out.reconcile_why_not = f"step 4 could not be re-run ({type(exc).__name__}: {exc})"[:200]
        return _with_the_openings(out, env, facts, rows)
    if jt is None:
        out.reconcile_why_not = "there was no pair to reconcile"
        return _with_the_openings(out, env, facts, rows)
    kinds = sorted({str(getattr(a, "kind", "") or getattr(a, "name", "")) for a in jt.alerts})
    out.reconcile_ran = True
    out.contradictions = jt.contradictions
    out.readers = {str(k): bool(v) for k, v in (jt.readers or {}).items()}
    out.alert_kinds = [k for k in kinds if k]
    out.representation_verdict = "disagreed" if REPRESENTATION_ALERT in kinds else (
        "agreed" if settled and str(settled) == str(at_look) else "no_comparable_claim")
    return _with_the_openings(out, env, facts, rows)


# -------------------------------------------------------------------------------------------------
# the look, scored per opening, and the composition it was worth
# -------------------------------------------------------------------------------------------------

#: `openings[o5].role` as `ask.record.record_for` spells a target's field, and as `AnswerOutcome.field`
#: therefore spells it. One regex, so the delta rows and the answer rows join on one string.
OPENING_FIELD = re.compile(r"^openings\[(?P<id>[^\]]+)\]\.role$")

#: The forecast fields the DELIVERED MESH can adjudicate. Nothing else on a real job can price a forecast: the
#: customer is never asked what the cell count should be, so a moved forecast with no mesh behind it is a change
#: of unknown sign and is counted as one.
FORECAST_FIELDS: frozenset[str] = frozenset({"forecast.cells_low", "forecast.cells_high",
                                             "planner_block.agent_forecast_cells"})


def _role_of(entry: dict[str, Any]) -> tuple[str | None, str | None, bool]:
    """(the look's own word, that word in the survey's role vocabulary, whether it abstained)."""
    said = str(entry.get("likely_role") or "").strip()
    if said.lower() in LOOK_ROLE_ABSTENTIONS:
        return (said or None), None, True
    mapped = LOOK_ROLE_WORDS.get(said.lower())
    #: a word the look invented is not an abstention and is not a role either: it is recorded and scored as a
    #: claim against whatever settled, so a prompt drifting off its own vocabulary shows up as disagreement
    #: rather than disappearing into the abstention count
    return said, (mapped or said), False


def _settled_role(row: AnswerOutcome | None) -> tuple[str | None, str, bool]:
    """(the role that mouth ran with, who settled it, whether the CUSTOMER did).

    An answer that is a LABEL is the customer's own. An answer that is not - a delegation, a default, a quote
    that does not name the option - still gave the mouth the role the job ran with, and that role is this
    platform's own pick; `is_customer` False is what keeps the two out of one number.
    """
    if row is None:
        return None, "unanswered", False
    if row.verdict in LABEL_VERDICTS and row.answer is not None:
        return row.answer, CUSTOMER, True
    if row.answer is not None:
        return row.answer, row.answered_by or "unanswered", False
    if row.proposed is not None:
        return row.proposed, "proposed", False
    return None, row.answered_by or "unanswered", False


def _role_row_rank(row: AnswerOutcome) -> tuple[int, int, int]:
    """How much a role answer row is worth as the thing the look is scored against: a LABEL beats a value the
    customer did not choose, a live row beats a retired one, and an answer beats a bare proposal."""
    return (int(row.verdict in LABEL_VERDICTS), int(not row.retired), int(row.answer is not None))


def role_rows(env: dict[str, Any], answers: list[AnswerOutcome]) -> list[SeenRole]:
    """The look's role guess at every mouth it named, scored against what that mouth settled on.

    WHY THE SCORE IS SPLIT AND NOT AVERAGED. On the first batch every role answer was a delegation or the bare
    quote "go", so the role the job ran with was this platform's own proposal on all 32 mouths. A single
    "the look agreed" rate over those is a measurement of the look against us, and it would read as a
    measurement of the look against the part. So a mouth whose role the customer chose scores
    `agreed_with_the_customer` or `disagreed_with_the_customer`, a mouth whose role we picked scores
    `..._with_our_own_pick`, and `LookAgreement.role_verdicts` keeps the two counts apart by name.
    """
    doc = ((env.get("measurement") or {}).get("document")) or {}
    look = doc.get("look") if isinstance(doc.get("look"), dict) else {}
    imp = look.get("impression") if isinstance(look.get("impression"), dict) else {}
    by_opening: dict[str, AnswerOutcome] = {}
    for a in answers:
        m = OPENING_FIELD.match(a.field or "")
        if not m:
            continue
        # ONE ROW PER MOUTH, AND THE BEST ONE. A part surveyed more than once has a role row per question id
        # for the same mouth, and `answer_outcomes` keeps them all - the live one and the retired ones. Taking
        # whichever came last in question-id order would score the look against a retired answer on a job that
        # was recomposed, which is a value the job did not run on.
        prev = by_opening.get(m.group("id"))
        if prev is None or _role_row_rank(a) > _role_row_rank(prev):
            by_opening[m.group("id")] = a
    rows: list[SeenRole] = []
    for entry in imp.get("openings_seen") or []:
        if not isinstance(entry, dict):
            continue
        oid = str(entry.get("id") or "unlabelled")
        said, role, abstained = _role_of(entry)
        settled, by, is_customer = _settled_role(by_opening.get(oid))
        if abstained:
            verdict, why = "no_claim", ("the look was shown this mouth and declined to guess a role, which is "
                                        "the product of this field and not a miss")
        elif settled is None:
            verdict, why = "nothing_settled", ("the look guessed a role and nothing on this job ever settled "
                                               "one for this mouth, so there is nothing to score it against")
        else:
            agreed = _norm(role) == _norm(settled)
            if is_customer:
                verdict = "agreed_with_the_customer" if agreed else "disagreed_with_the_customer"
                why = (f"the look said {role!r} and the customer chose {settled!r}")
            else:
                verdict = "agreed_with_our_own_pick" if agreed else "disagreed_with_our_own_pick"
                why = (f"the look said {role!r} and the mouth ran as {settled!r}, which {by} settled: this is "
                       f"the look against this platform's own pick and is not evidence about the part")
        rows.append(SeenRole(opening=oid, look_said=said, look_role=role, abstained=abstained,
                             settled=settled, settled_by=by, verdict=verdict, why=why))
    return rows


def _with_the_openings(out: LookAgreement, env: dict[str, Any], facts,
                       answers: list[AnswerOutcome]) -> LookAgreement:
    """`out` with the per-opening half filled in. Separated so every early return of `look_agreement` gets it:
    a look that produced no impression still has to say that it scored nought mouths, rather than leaving the
    rows empty in a way a reader cannot tell from nought disagreements."""
    doc = ((env.get("measurement") or {}).get("document")) or {}
    look = doc.get("look") if isinstance(doc.get("look"), dict) else {}
    looked = bool(look.get("impression"))
    rows = role_rows(env, answers)
    measured = len(getattr(facts, "openings", None) or [])
    seen = sorted({r.opening for r in rows if r.opening != "unlabelled"})
    out.openings = rows
    out.role_verdicts = dict(Counter(r.verdict for r in rows))
    out.role_claims = sum(1 for r in rows if not r.abstained)
    out.role_abstentions = sum(1 for r in rows if r.abstained)
    out.seen_ids = seen
    out.measured_ids = measured
    #: None, NOT 0.0, on a look that brought nothing back, and None on a part with no measured opening. A look
    #: that failed saw no mouth because there was no look; reporting 0.0 there would put a deployment with no
    #: reader into the same column as a reader that missed every mouth, and a recall over nought mouths is not
    #: agreement either.
    out.seen_recall = round(len(seen) / measured, 4) if (looked and measured) else None
    out.unlabelled_seen = sum(1 for r in rows if r.opening == "unlabelled")
    return out


def _closer(field: str, with_look: str | None, no_look: str | None,
            delivered: int | None) -> tuple[str, str] | None:
    """Which of the two forecasts the delivered mesh vindicates, or None when it cannot say.

    The distance is |ln(forecast / delivered)|, so over-forecasting by 3x and under-forecasting by 3x are the
    same distance. dev_plan_v3 error 2 measured the corpus at median 1.86x OVER and the first platform batch at
    0.28 to 0.67 of delivered, which is why an asymmetric measure would pick a winner from the direction alone.
    """
    if field not in FORECAST_FIELDS or not delivered:
        return None
    try:
        a, b = float(with_look or "nan"), float(no_look or "nan")
    except (TypeError, ValueError):
        return None
    if not (a > 0 and b > 0) or a != a or b != b:
        return None
    da, db = abs(math.log(a / delivered)), abs(math.log(b / delivered))
    if da == db:
        return "equally_far_from_delivered", (f"both forecasts sit the same distance from the {delivered} cells "
                                              f"the builder delivered")
    if da < db:
        return "look_closer_to_delivered", (f"with the look {int(a)} and without it {int(b)} against {delivered} "
                                            f"delivered: the look moved the forecast towards the mesh")
    return "look_further_from_delivered", (f"with the look {int(a)} and without it {int(b)} against {delivered} "
                                           f"delivered: the look moved the forecast away from the mesh")


def counterfactual_of(env: dict[str, Any], answers: list[AnswerOutcome]) -> LookCounterfactual:
    """The exporter's computed without-the-look proposal, adjudicated field by field.

    THE EXPORTER COMPUTES AND THIS JUDGES, which is the same split the rest of this module keeps: the platform
    has the rows and the composition, and the verdicts and the split are the learning loop's. Nothing here
    recomposes anything - it reads `look_counterfactual.fields`, which the platform produced by running the
    composition twice under one build.
    """
    raw = env.get("look_counterfactual")
    if not isinstance(raw, dict):
        return LookCounterfactual(computed=False,
                                  why_not="this envelope carries no without-the-look composition; it was "
                                          "written before the exporter computed one")
    out = LookCounterfactual(
        computed=bool(raw.get("computed")), why_not=raw.get("why_not") or None,
        look_status=raw.get("look_status"), replay_faithful=raw.get("replay_faithful"),
        replay_checked=int(raw.get("replay_checked") or 0),
        replay_mismatch=[r for r in (raw.get("replay_mismatch") or []) if isinstance(r, dict)],
        recomposed_under=dict(raw.get("recomposed_under") or {}),
        job_measured_under=dict(raw.get("job_measured_under") or {}),
        same_build_as_the_job=raw.get("same_build_as_the_job"), seconds=raw.get("seconds"))
    if not out.computed:
        return out
    labels = {a.field: a for a in answers if a.verdict in LABEL_VERDICTS and a.field}
    delivered = delivered_cells(env)
    faithful = out.replay_faithful is not False
    for row in raw.get("fields") or []:
        if not isinstance(row, dict) or not row.get("field"):
            continue
        field = str(row["field"])
        a, b = row.get("with_look"), row.get("without_look")
        changed = bool(row.get("changed"))
        label = labels.get(field)
        delta = ProposalDelta(field=field, with_look=a, without_look=b, changed=changed,
                              customer=None if label is None else label.answer,
                              customer_verdict=None if label is None else label.verdict,
                              delivered=delivered if field in FORECAST_FIELDS else None)
        if not faithful:
            delta.verdict = "not_comparable"
            delta.why = ("the with-the-look recomposition does not reproduce the stored survey row, so this "
                         "difference is between two code versions and not between two compositions")
        elif not changed:
            delta.verdict = "changed_nothing"
            delta.why = "both compositions proposed the same value, so the look does not decide this field"
        elif label is not None and label.answer is not None:
            said = _norm(label.answer)
            with_ok, without_ok = _norm(a) == said, _norm(b) == said
            if with_ok and not without_ok:
                delta.verdict = "look_agreed_with_the_customer"
                delta.why = f"the look proposed {a!r}, the measurement alone {b!r}, and the customer chose {a!r}"
            elif without_ok and not with_ok:
                delta.verdict = "look_disagreed_with_the_customer"
                delta.why = f"the look proposed {a!r}, the measurement alone {b!r}, and the customer chose {b!r}"
            else:
                delta.verdict = "both_disagreed_with_the_customer"
                delta.why = (f"the look proposed {a!r} and the measurement alone {b!r}; the customer chose "
                             f"{label.answer!r}, which is neither")
        else:
            adjudicated = _closer(field, a, b, delivered)
            if adjudicated is not None:
                delta.verdict, delta.why = adjudicated
            else:
                delta.verdict = "changed_unadjudicated"
                delta.why = ("the look moved this field and nothing settled it: no customer label for it and "
                             "no delivered mesh to price it against, so the change has no sign")
        out.deltas.append(delta)
    out.fields_compared = len(out.deltas)
    out.fields_changed = sum(1 for d in out.deltas if d.changed)
    out.verdicts = dict(Counter(d.verdict for d in out.deltas))
    return out


def platform_block(env: dict[str, Any], facts, answers: list[AnswerOutcome] | None = None) -> PlatformBlock:
    job = env.get("job") or {}
    fr = job.get("final_result") or {}
    survey = env.get("survey") or {}
    step = env.get("step") or {}
    meas = env.get("measurement") or {}
    comp = survey.get("composed_for") or {}
    q = env.get("quality") or {}
    return PlatformBlock(
        export_schema=str(env.get("schema") or ""), job_id=str(job.get("job_id") or ""),
        session_id=survey.get("session_id"), status=str(job.get("status") or ""),
        outcome_code=fr.get("outcome_code"), failure_category=fr.get("failure_category"),
        failed_gate=fr.get("failed_gate") or None, attempts=_as_int(fr.get("attempts")),
        attempts_max=_as_int(fr.get("attempts_max")), review_execution=fr.get("review_execution"),
        engine=fr.get("engine") or comp.get("engine") or step.get("engine"),
        purpose=fr.get("purpose") or comp.get("purpose"),
        fidelity=fr.get("effective_mesh_fidelity") or step.get("fidelity"),
        created_at=job.get("created_at"), ended_at=job.get("ended_at"),
        stage=survey.get("stage"), survey_state_schema=survey.get("state_schema"),
        step_status=step.get("status") or None, step_exit=step.get("exit"),
        step_rounds=_as_int(step.get("rounds")), step_model=step.get("model"),
        step_provider=step.get("provider"),
        platform_sha=meas.get("platform_sha"), agent_git_sha=meas.get("agent_git_sha"),
        facts_schema_version=_as_int(meas.get("facts_schema_version")),
        measurement_revision=_as_int(meas.get("measurement_revision")),
        brief=comp.get("brief"), brief_sha=comp.get("brief_sha"),
        delegated_answers=sum(1 for a in (survey.get("answers") or [])
                              if isinstance(a, dict) and a.get("delegated")),
        forecast=forecast_of(env), look=look_agreement(env, facts, answers),
        counterfactual=counterfactual_of(env, list(answers or [])),
        quality_criteria=dict(q.get("criteria") or {}))


def _attempt(env: dict[str, Any]) -> list[Attempt]:
    """The job as one attempt, carrying the delivered mesh's own numbers.

    ONE, not `attempts`: the export reads a terminal job and the platform keeps no per-attempt quality row, so
    claiming N attempts with one set of numbers would attach the delivered mesh's quality to attempts that
    produced something else. `Attempt.index` is the attempt the review judged when the payload says which.
    """
    job = env.get("job") or {}
    fr = job.get("final_result") or {}
    q = env.get("quality") or {}
    crit = q.get("criteria") if isinstance(q.get("criteria"), dict) else {}

    def measured(key: str) -> Any:
        return (crit.get(key) or {}).get("measured")

    fatal = measured("fatal")
    return [Attempt(
        index=_as_int(q.get("attempt_reviewed")) or _as_int(fr.get("attempts")) or 1,
        status=str(job.get("status") or ""), dispatched=True,
        engine=fr.get("engine"), job_id=str(job.get("job_id") or ""),
        started=job.get("started_at"), finished=job.get("ended_at"),
        quality=Quality(cells=delivered_cells(env),
                        max_non_orthogonality_deg=measured("max_non_ortho"),
                        skew_fraction=measured("skew_fraction"),
                        layer_coverage=measured("layer_coverage_pct"),
                        wall_faces=_as_int(measured("wall_faces")),
                        fatal=None if fatal is None else bool(fatal),
                        failed_gate=fr.get("failed_gate") or None))]


def record_for_envelope(env: dict[str, Any]) -> OutcomeRecord:
    facts, fsha = facts_of(env)
    # computed ONCE and handed on: the per-opening role score and the counterfactual's adjudication both need
    # the label verdicts, and a second call would be a second chance for the two to disagree about what a
    # label is
    rows = answer_outcomes(env)
    job = env.get("job") or {}
    survey = env.get("survey") or {}
    fr = job.get("final_result") or {}
    comp = survey.get("composed_for") or {}
    asking = survey.get("asking") or {}
    texts = asking.get("text") if isinstance(asking.get("text"), dict) else {}
    asked = [str(q) for q in (survey.get("asked") or [])]
    questions = [str(texts.get(q) or q) for q in asked]
    step = env.get("step") or {}
    return OutcomeRecord(
        schema_version=OUTCOME_SCHEMA_VERSION,
        job_key=job_key("platform", str(env.get("case") or ""), fsha, str(job.get("job_id") or "")),
        source="platform", geometry=geometry_of(env, facts, fsha),
        # The step's own plan IS the agent block's evidence on this path; the warnings and questions a
        # recording carries are not stored on the row, so `warnings` stays empty rather than being inferred.
        agent=AgentBlock(present=bool(step.get("status")), policy="platform" if step.get("status") else "none",
                         model=step.get("model"), rounds=_as_int(step.get("rounds")),
                         header_keys={"representation": step.get("representation"),
                                      "exit": step.get("exit"), "trade": step.get("trade"),
                                      "unconfirmed_roles": step.get("unconfirmed_roles"),
                                      "sent_back_by_the_survey": step.get("sent_back_by_the_survey")}),
        builder=BuilderBlock(platform_revision=(env.get("measurement") or {}).get("platform_sha"),
                             attempts=_attempt(env)),
        reviewer=ReviewerBlock(verdict=fr.get("reviewer_verdict") or (env.get("quality") or {}).get(
            "review_verdict"), feedback=fr.get("review_execution")),
        # NO LABELS. `Labels` is a copy of eval/labels/build_labels.py's row and that script runs on the corpus
        # export. A platform job has no row there, and inventing one would make a real job look like a corpus
        # case to every reader that branches on `labels`. Every field stays None, which is what "this case is
        # not in the label file" has always meant.
        labels=Labels(),
        intake=IntakeBlock(turns=None, questions=questions,
                           questions_by_topic=dict(Counter(intake_topic(q) for q in questions)),
                           brief=comp.get("brief")),
        answers=rows, platform=platform_block(env, facts, rows))


# -------------------------------------------------------------------------------------------------
# the ingest
# -------------------------------------------------------------------------------------------------

def record_stem(record: OutcomeRecord) -> str:
    """ONE FILE PER JOB, not per part, which `OutcomeRecord.file_stem` cannot give.

    A customer meshes the same file more than once - five of the eight survey rows in the local database are
    the same bytes - and `file_stem` is the measurement digest and the case name, so every job on one part
    resolves to one path. Without the job id the second job overwrote the first: the ingest counted five records
    and one file existed, and the batch summary would have reported five jobs' worth of answers from whichever
    envelope happened to be read last. The job id's first eight characters are enough to separate them and keep
    the name readable; the record's `job_key` carries the whole id.
    """
    job = (record.platform.job_id if record.platform else "") or "nojob"
    return f"{record.geometry.facts_sha256[:12]}__{record.geometry.case}__{job[:8]}"


def ingest(exports_dir: Path, outcomes_dir: Path | None = None,
           split_file: Path = store.SPLIT_FILE) -> PlatformIngestReport:
    from geometry_agent.learn.ingest_corpus_export import write_record
    outcomes_dir = Path(outcomes_dir or store.OUTCOMES_PLATFORM_DIR)
    report = PlatformIngestReport(outcomes_dir=outcomes_dir)
    split = store.read_split(split_file)
    for path, env in load_envelopes(exports_dir):
        report.envelopes += 1
        jid = str((env.get("job") or {}).get("job_id") or path.stem)
        for why in env.get("absent") or []:
            report.absent[str(why)] += 1
        try:
            record = record_for_envelope(env)
        except (ValueError, KeyError, TypeError) as exc:
            report.refused[jid] = f"{type(exc).__name__}: {exc}"
            continue
        assign_split(record, split)
        p, changed = write_record(record, outcomes_dir, record_stem(record))
        report.records += 1
        report.written += int(changed)
        report.unchanged += int(not changed)
        report.split_counts[record.split] += 1
        report.paths.append(p)
        for a in record.answers:
            report.verdicts[a.verdict] += 1
            report.label_rows += int(a.is_label)
        report.reviewer[str(record.reviewer.verdict or "none")] += 1
        if record.platform is not None:
            ratio = record.platform.forecast.delivered_over_forecast
            if ratio is not None:
                report.forecast_ratios.append(ratio)
            report.look_verdicts[record.platform.look.representation_verdict] += 1
            for verdict, n in (record.platform.look.role_verdicts or {}).items():
                report.role_verdicts[verdict] += n
            cf = record.platform.counterfactual
            if cf.computed:
                report.counterfactual_jobs += 1
                report.counterfactual_unfaithful += int(cf.replay_faithful is False)
                for verdict, n in (cf.verdicts or {}).items():
                    report.delta_verdicts[verdict] += n
            else:
                #: the REASON, not a count of failures: "the look on this job is failed" and "the composition
                #: could not be run again" are different facts and a pooled number hides the second behind the
                #: first
                report.counterfactual_refused[str(cf.why_not or "no reason given")[:90]] += 1
    return report


#: A per-place field collapsed to its family, for a table that pools jobs. `openings[o5].role` on one part and
#: `openings[o12].role` on another are the same MEASUREMENT of the look and different columns, so the record
#: keeps the exact field and the batch table counts the family.
_PLACE_IN_FIELD = re.compile(r"\[[^\]]+\]")


def field_family(field: str) -> str:
    return _PLACE_IN_FIELD.sub("[]", str(field))


def look_value(records: list[OutcomeRecord]) -> dict[str, Any]:
    """What the look was worth on this batch, per field and per mouth, with every denominator beside it.

    THE WHOLE POINT OF THE BLOCK. Before this the question "does the Surveyor improve the pipeline" needed a
    study; here it is a table that any batch of real jobs rebuilds for nothing. Three rules it keeps:

      1. `changed_nothing` is REPORTED, not dropped. A field the look never moves is the cheapest thing to
         know about it, and a table that only showed the moved fields would make a look that changes almost
         nothing look like a look that is always deciding.
      2. NO RATE OVER A MIXED DENOMINATOR (R1). `adjudicated` counts only the fields a customer label or the
         delivered mesh could settle; `unadjudicated` is beside it by name. A change of unknown sign is never
         counted as the look helping.
      3. THE LOOK AGAINST THE CUSTOMER AND THE LOOK AGAINST US ARE TWO TABLES. `role_agreement_customer` has
         the label rows for a denominator and `role_agreement_our_own_pick` has the rest; pooling them would
         report the look agreeing with itself through our default on every job where nobody chose.
    """
    per_field: dict[str, Counter] = {}
    jobs_computed = jobs_absent = unfaithful = unchecked = 0
    why_not: Counter = Counter()
    roles: Counter = Counter()
    claims = abstentions = seen = measured = unlabelled = 0
    for rec in records:
        pl = rec.platform
        if pl is None:
            continue
        for verdict, n in (pl.look.role_verdicts or {}).items():
            roles[verdict] += n
        claims += pl.look.role_claims
        abstentions += pl.look.role_abstentions
        seen += len(pl.look.seen_ids)
        measured += pl.look.measured_ids
        unlabelled += pl.look.unlabelled_seen
        cf = pl.counterfactual
        if not cf.computed:
            jobs_absent += 1
            why_not[str(cf.why_not or "no reason given")[:90]] += 1
            continue
        jobs_computed += 1
        unfaithful += int(cf.replay_faithful is False)
        unchecked += int(cf.replay_faithful is None)
        for d in cf.deltas:
            per_field.setdefault(field_family(d.field), Counter())[d.verdict] += 1
    rows = []
    for name, c in sorted(per_field.items()):
        adjudicated = sum(c[v] for v in DELTA_ADJUDICATED)
        right = c["look_agreed_with_the_customer"] + c["look_closer_to_delivered"]
        rows.append({"field": name, "rows": sum(c.values()), "changed_nothing": c["changed_nothing"],
                     "changed": sum(c.values()) - c["changed_nothing"] - c["not_comparable"],
                     "adjudicated": adjudicated,
                     "look_right": right, "look_wrong": adjudicated - right,
                     "look_right_rate": round(right / adjudicated, 4) if adjudicated else None,
                     "unadjudicated": c["changed_unadjudicated"],
                     "both_wrong": c["both_disagreed_with_the_customer"],
                     #: the mesh spoke and said neither forecast was nearer. It is its own column so the
                     #: columns of one row ADD UP: rows = changed_nothing + not_comparable + adjudicated +
                     #: unadjudicated + both_wrong + equally_far, and a reader can see nothing was dropped.
                     "equally_far": c["equally_far_from_delivered"],
                     "not_comparable": c["not_comparable"]})
    label_rows = sum(roles[v] for v in ROLE_LABEL_VERDICTS)
    ours = roles["agreed_with_our_own_pick"] + roles["disagreed_with_our_own_pick"]
    return {
        "counterfactual": {
            "jobs_computed": jobs_computed, "jobs_not_computed": jobs_absent,
            "why_not": dict(why_not), "replay_not_faithful": unfaithful,
            #: a job whose stored row carried no field the replay could be checked on. Counted apart from
            #: `replay_not_faithful`, because "the check failed" and "there was nothing to check with" are
            #: different facts and pooling them would hide the second.
            "replay_not_checked": unchecked,
            "by_field": rows,
        },
        "look_roles": {
            "rows": sum(roles.values()), "verdicts": dict(roles),
            "claims": claims, "abstentions": abstentions,
            "abstention_rate": round(abstentions / (claims + abstentions), 4) if claims + abstentions else None,
            #: the only role number that is evidence about a part, with its own denominator
            "label_rows": label_rows,
            "role_agreement_customer": (round(roles["agreed_with_the_customer"] / label_rows, 4)
                                        if label_rows else None),
            #: and the one that is the look agreeing with this platform's own pick, never pooled with it
            "our_own_pick_rows": ours,
            "role_agreement_our_own_pick": (round(roles["agreed_with_our_own_pick"] / ours, 4) if ours else None),
            "nothing_settled": roles["nothing_settled"],
            "seen_ids": seen, "measured_ids": measured,
            "seen_recall": round(seen / measured, 4) if measured else None,
            "unlabelled_seen": unlabelled,
        },
    }


def look_value_table(doc: dict[str, Any]) -> str:
    cf, roles = doc["counterfactual"], doc["look_roles"]
    lines = [f"without the look: {cf['jobs_computed']} jobs recomputed, {cf['jobs_not_computed']} not, "
             f"{cf['replay_not_faithful']} whose replay does not reproduce the stored row, "
             f"{cf.get('replay_not_checked', 0)} the row could not check at all",
             "", "| proposal field | rows | look changed nothing | changed | adjudicated | look right | "
             "look wrong | right rate | unadjudicated | both wrong | equally far | not comparable |",
             "|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for r in cf["by_field"]:
        rate = "-" if r["look_right_rate"] is None else f"{r['look_right_rate']:.3g}"
        lines.append(f"| {r['field']} | {r['rows']} | {r['changed_nothing']} | {r['changed']} | "
                     f"{r['adjudicated']} | {r['look_right']} | {r['look_wrong']} | {rate} | "
                     f"{r['unadjudicated']} | {r['both_wrong']} | {r['equally_far']} | "
                     f"{r['not_comparable']} |")
    if not cf["by_field"]:
        lines.append("| - | 0 | 0 | 0 | 0 | 0 | 0 | - | 0 | 0 | 0 | 0 |")
    for reason, n in sorted(cf["why_not"].items()):
        lines.append(f"not recomputed on {n}: {reason}")
    rate = roles["role_agreement_customer"]
    ours = roles["role_agreement_our_own_pick"]
    lines += ["", f"look role per mouth: {roles['rows']} rows, {roles['claims']} guesses and "
                  f"{roles['abstentions']} abstentions"
                  + (f" (abstention rate {roles['abstention_rate']:.3g})" if roles["abstention_rate"] is not None
                     else ""),
              f"  against the CUSTOMER's confirmed role: n {roles['label_rows']}"
              + (f", agreement {rate:.3g}" if rate is not None else ", no rate - no mouth's role was a label"),
              f"  against this platform's OWN pick (not evidence about the part): n {roles['our_own_pick_rows']}"
              + (f", agreement {ours:.3g}" if ours is not None else ", no rate"),
              f"  the look guessed a role where nothing ever settled one: {roles['nothing_settled']}",
              f"  mouths seen {roles['seen_ids']} of {roles['measured_ids']} measured"
              + (f" (recall {roles['seen_recall']:.3g})" if roles["seen_recall"] is not None else "")
              + f", {roles['unlabelled_seen']} entries with no measured id",
              f"  verdicts: {roles['verdicts']}"]
    return "\n".join(lines)


def summary(report: PlatformIngestReport, records: list[OutcomeRecord]) -> dict[str, Any]:
    """The batch as a document, and the table the runbook reads.

    EVERY RATE CARRIES ITS DENOMINATOR AND ITS EXCLUSIONS (R1). `corrections` is over the LABEL rows alone and
    the three kinds of non-label are counted beside it by name, so a batch of delegated jobs reports zero
    labels rather than a clean agreement rate.
    """
    by_kind: dict[str, Counter] = {}
    for rec in records:
        for a in rec.answers:
            by_kind.setdefault(a.kind or "unknown", Counter())[a.verdict] += 1
    rows = []
    for kind, c in sorted(by_kind.items()):
        labels = c["confirmed"] + c["corrected"]
        rows.append({"kind": kind, "rows": sum(c.values()), "labels": labels,
                     "confirmed": c["confirmed"], "corrected": c["corrected"],
                     "correction_rate": round(c["corrected"] / labels, 4) if labels else None,
                     "not_a_label": c["not_a_label"], "unknown_authority": c["unknown_authority"],
                     "quote_does_not_choose": c["quote_does_not_choose"],
                     "proposal_not_stored": c["proposal_not_stored"]})
    ratios = sorted(report.forecast_ratios)
    stamps: Counter = Counter()
    for rec in records:
        p = rec.platform
        if p is not None:
            stamps[f"{p.platform_sha or 'none'}/{p.agent_git_sha or 'none'}/facts v"
                   f"{p.facts_schema_version}"] += 1
    return {
        "schema": "geometry_agent.learn.platform_summary.v1",
        "envelopes": report.envelopes, "records": report.records,
        "refused": dict(report.refused), "absent": dict(report.absent),
        "answers": dict(report.verdicts), "label_rows": report.label_rows,
        "by_kind": rows,
        "reviewer": dict(report.reviewer),
        "look": dict(report.look_verdicts),
        "forecast": {"n": len(ratios), "median": statistics.median(ratios) if ratios else None,
                     "min": ratios[0] if ratios else None, "max": ratios[-1] if ratios else None,
                     "over_forecast": sum(1 for r in ratios if r > 1.0),
                     "under_forecast": sum(1 for r in ratios if r < 1.0)},
        #: R2. Two batches whose stamp sets differ are not compared, and this is what says so.
        "stamps": dict(stamps),
        #: THE SURVEYOR'S OWN VALUE, per field and per mouth (`look_value`). It updates itself: every batch of
        #: real jobs rebuilds it, and no arm, no A/B and no extra model call pays for it.
        "look_value": look_value(records),
    }


def summary_table(doc: dict[str, Any]) -> str:
    lines = ["| question kind | rows | labels | confirmed | corrected | correction rate | not a label | "
             "unknown authority | quote does not choose | proposal not stored |",
             "|---|---|---|---|---|---|---|---|---|---|"]
    for r in doc["by_kind"]:
        rate = "-" if r["correction_rate"] is None else f"{r['correction_rate']:.3g}"
        lines.append(f"| {r['kind']} | {r['rows']} | {r['labels']} | {r['confirmed']} | {r['corrected']} | "
                     f"{rate} | {r['not_a_label']} | {r['unknown_authority']} | "
                     f"{r['quote_does_not_choose']} | {r['proposal_not_stored']} |")
    f = doc["forecast"]
    lines += ["", f"delivered/forecast: n {f['n']}"
              + (f", median {f['median']:.3g}, min {f['min']:.3g}, max {f['max']:.3g}, "
                 f"{f['over_forecast']} over, {f['under_forecast']} under" if f["n"] else
                 " - no job in this batch carried both numbers"),
              f"reviewer: {doc['reviewer']}", f"look vs settled representation: {doc['look']}",
              f"stamps: {doc['stamps']}", "", look_value_table(doc["look_value"])]
    return "\n".join(lines)


def run(exports_dir: Path, outcomes_dir: Path | None = None, split_file: Path = store.SPLIT_FILE,
        platform_dir: Path = store.PLATFORM_DIR, log=print) -> dict[str, Any]:
    if not Path(exports_dir).is_dir():
        raise FileNotFoundError(f"no export directory at {exports_dir}")
    report = ingest(exports_dir, outcomes_dir, split_file)
    log(f"platform records: {report.summary()}")
    records = [OutcomeRecord.model_validate_json(p.read_text(encoding="utf-8")) for p in report.paths]
    doc = summary(report, records)
    out = Path(platform_dir) / f"summary_{datetime.now(UTC).date().isoformat()}.json"
    store.write_json(out, doc)
    log(summary_table(doc))
    log(f"platform summary -> {out}")
    return {"ingest": report.summary(), "records": report.records, "outcomes_dir": str(report.outcomes_dir),
            "summary": str(out), "refused": dict(report.refused)}
