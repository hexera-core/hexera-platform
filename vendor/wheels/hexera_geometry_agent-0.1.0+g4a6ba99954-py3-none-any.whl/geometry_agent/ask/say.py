"""The questions, written the way a person asks them.

THE BAR, which is Rehaan's own example and is what every template here is measured against:

    I can see four openings. Two are clearly through-flow. The one on the side, o3, I cannot tell from the
    shape: is it an inlet, an outlet, or a drain?

Not a field dump. The shape of it is always the same three beats and they are in this order for a reason:

    WHAT I SAW      the measurement's own count and places, so the customer knows the machine looked
    WHAT I SETTLED  what is already accounted for, so the question is visibly the remainder and not the whole
    WHAT I CANNOT   one ask, with one default

ONE QUESTION, ONE DEFAULT. A part with four unplaced mouths gets ONE question naming all four, not four
questions, and one default covering all four. `UserQuestion.also_settles` has carried that convention since
schema 3 and this module keeps it: the grouping is in the text, the per-place answers are in the record.

WHERE THE WORDS COME FROM. Every noun and every number in a question here is the MEASUREMENT'S. The look
contributes exactly TWO clauses and both are statements about the PAIR rather than about the part: "I could not
see it in the pictures either" (`_blind`), for a mouth whose id is missing from `openings_seen`, which is the
relied-on tier; and "the pictures and the measurement read all four the same way" or "the pictures read o4
differently from the measurement" (`_agreement`), off `reconcile.verdict.by_place`. No `likely_role`, no
`looks_like`, no `defects` and no `notes` reach a customer through this file: those are the recorded tier and
`vision/trust.py:for_model` is what keeps them out of a prompt, while this file is what keeps them out of a
sentence. That is why the disagreement clause names the MOUTH and never what the pictures called it.

AND WHY AN AGREEMENT IS SAID AT ALL, which is the change that clause is part of. Measured on the 8 finished jobs
in the platform's own database (`learn.schema`, the `quote_does_not_choose` verdict): 16 role answers arrived on
the bare quote "go", 20 on a delegation and 0 on words naming a mouth and a role. A question that names four
mouths alike is answered "you decide"; a question that says what is already settled and asks about the one place
two sources read differently is a question a person answers. The role question is still ONE question covering
every unplaced mouth, because a role is not a measured field and `application/geometry_survey.role_problems`
refuses any role a customer did not confirm - what changed is what the sentence leads with.

THE DEFAULT RULE, from dev_plan_v3 finding 10, where 72 of 88 questions defaulted to "extend to 5D", an
operation the reader cannot perform, and 10 more named a control the reader does not have. Every default below
is one of two things and says which:

    acceptance  the reader accepts a reading. They can always do that.
    operation   this pipeline performs it. It is already what happens when nobody answers.

No default here asks for a CAD change.
"""
from __future__ import annotations

from typing import Any

from geometry_agent.ask.schema import Question

#: The role words a customer uses. `closed for this run` and `wall` are both here because they are different
#: answers: a blanked drain is a face the mesher caps, a wall is a face it never cuts.
ROLE_OPTIONS: tuple[str, ...] = ("inlet", "outlet", "wall", "closed for this run")

#: At most this many mouths are named in one question's text. The rest are counted, and every one of them is
#: still in `places` and still gets its own row in the record, so nothing is lost: what is capped is the
#: sentence, not the question. Four is the number in Rehaan's own example.
NAMED_IN_TEXT = 4

_WORDS = {1: "one", 2: "two", 3: "three", 4: "four", 5: "five", 6: "six", 7: "seven", 8: "eight", 9: "nine",
          10: "ten", 11: "eleven", 12: "twelve"}


def _n(k: int) -> str:
    return _WORDS.get(k, str(k))


def _size(m: dict[str, Any]) -> str:
    """A mouth's size in one clause, or nothing when the file's unit is not settled and there is no honest mm."""
    d = m.get("bore_diameter_mm") or m.get("hydraulic_diameter_mm")
    return f"{float(d):.0f} mm across" if d else ""


def _place(u: Any) -> str:
    """One mouth, named and placed: `o3, on the side of the body, 40 mm across`."""
    m = u.measurement or {}
    bits = [u.places[0] if u.places else "", str(m.get("where") or ""), _size(m)]
    return ", ".join(b for b in bits if b)


def _blind(us: list[Any]) -> str:
    """The one clause the look contributes, and only when a mouth it should have seen is missing from its list.

    `openings_seen` is the relied-on tier: which labelled mouths the look can see is 91 to 94 percent recall and
    Jaccard 1.00 on a repeat call. So a mouth absent from that set is a real finding about the PICTURES, which
    is worth a customer knowing, and it is not a claim about the mouth. Nothing else from the look reaches a
    sentence here.
    """
    unseen = [u for u in us if (u.measurement or {}).get("seen_by_the_look") is False]
    if not unseen:
        return ""
    if len(unseen) == 1:
        return " I could not see it as an open mouth in the pictures either."
    if len(unseen) == len(us):
        return " I could not see any of them as open mouths in the pictures either."
    return f" {_n(len(unseen)).capitalize()} of them I could not see in the pictures either."


#: The three words `reconcile.verdict.by_place` grades a place with, as they arrive on a role uncertainty's
#: `measurement["look_agreement"]`. Read, never re-derived: this module writes sentences and judges nothing.
_DISAGREED, _AGREED = "disagreed", "agreed"


def _pair_at(u: Any) -> str:
    return str((u.measurement or {}).get("look_agreement") or "")


def _reads_differently(us: list[Any]) -> list[Any]:
    """The mouths the pictures and the measurement read differently, in the order they were given."""
    return [u for u in us if _pair_at(u) == _DISAGREED]


def _sentence_order(open_us: list[Any]) -> list[Any]:
    """The same mouths, the ones the two sources read differently first. THE ORDER OF THE SENTENCE ONLY.

    `open_us` arrives ranked by `ask.consequence` and that ranking is NOT touched. `Question.places`, `covers`
    and the proposal below are all built from the list as it came, so the survey handoff this question becomes
    is field for field what it was and `application/geometry_step._inputs` still reproduces a row composed
    before this existed. What this changes is which mouths the SENTENCE names: at most `NAMED_IN_TEXT` fit in
    one, and a mouth the pictures and the measurement read differently is the one worth a customer's eye.

    WHY IT IS WORTH A REORDER AT ALL. Measured on the 8 finished jobs in the platform's own database
    (`learn.schema`, the `quote_does_not_choose` verdict): 16 role answers arrived on the bare quote "go", 20 on
    a delegation, and 0 on words that name a mouth and a role. A question that names four mouths alike invites
    "you decide"; one that names the place the two sources read differently is a question a person answers.

    AND HOW OFTEN IT FIRES TODAY, which is a number and not a hope: NEVER, on what is measured. Over the 162
    stored looks in that deployment, composed for internal_cfd, 22 parts carry a mouth the two sources read
    differently - 79 mouths in all - and ZERO of the 79 is a mouth this question names. The disagreements land
    on the faces the builder does not cut (a shell's shoulder rings, a domain's own caps) and the mouths it
    does cut are the ones the two sources agree about. So on that corpus this function returns its input
    unchanged and `_agreement` below is the clause that actually reaches a customer. It is kept because it is
    the correct order the day a disputed mouth IS a port, it costs one list comprehension, and
    `tests/test_ask_agreement.py` exercises both branches; if that number is still zero after a wider corpus,
    this is the first thing to delete.
    """
    hot = _reads_differently(open_us)
    if not hot:
        return list(open_us)
    rest = [u for u in open_us if u not in hot]
    return [*hot, *rest]


def _agreement(open_us: list[Any]) -> str:
    """The clause that STATES an agreement, and the one that points at a disagreement. `""` when nobody compared.

    THIS IS THE SECOND THING THE LOOK CONTRIBUTES TO A SENTENCE HERE, and the first (`_blind`) is its twin: that
    one says a mouth was missing from the pictures, this one says the pictures and the measurement read the same
    mouth the same way, or did not. Both are statements about the PAIR and neither is a claim about the part, so
    the rule at the top of this module holds: no `likely_role`, no `looks_like` and no `notes` reaches a
    customer through this file. `reconcile.verdict.Place.measured` exists for exactly that reason and is why the
    disagreement clause names the MOUTH and not what the pictures called it.

    SILENCE IS NOT AGREEMENT. A part where no per-opening claim survived to be checked gets no clause at all,
    because "the two sources agree" about a place nobody compared is the fact that lies this package is most
    careful about (`Joint.readers`).

    HOW OFTEN IT SAYS SOMETHING: 53 of the 162 stored looks in the platform's database have at least one mouth
    this question names that the two sources agree about, so 53 get the positive clause. The other 109 get
    nothing rather than a claim about a comparison nobody made.
    """
    graded = [u for u in open_us if _pair_at(u) in (_AGREED, _DISAGREED)]
    if not graded:
        return ""
    hot = _reads_differently(graded)
    calm = [u for u in graded if u not in hot]
    if not hot:
        if len(calm) == 1:
            return " The pictures and the measurement read it the same way, so the role is the only thing left."
        return (f" The pictures and the measurement read all {_n(len(calm))} the same way, so the role is the "
                f"only thing left.")
    names = ", ".join(u.places[0] for u in hot[:NAMED_IN_TEXT] if u.places)
    out = (f" The pictures read {names} differently from the measurement, so that is the one I would most like "
           f"your word on." if len(hot) == 1 else
           f" The pictures read {names} differently from the measurement, so those are the ones I would most "
           f"like your word on.")
    if calm:
        out += (f" They agree about the other {_n(len(calm))}." if len(calm) > 1
                else " They agree about the other one.")
    return out


def _proposed_roles(open_us: list[Any]) -> dict[str, str]:
    """`{place: role}` this question PROPOSES, which is what the mesher does when nobody answers, or `{}`.

    IT IS EACH UNCERTAINTY'S OWN `fallback` AND NOTHING DERIVED HERE. `uncertainty.port_role_uncertainties`
    sets that field from `tools.builder_inlet`, which mirrors `cad_tessellate.py:614` and `:631` - every planar
    face becomes a port and the widest is the inlet - and its own comment states the rule this proposal has to
    keep: "the default has to BE this, or a customer who answers nothing gets a different job from the one they
    get now". Recomputing the widest here would be a second reading of one fact, and the two could disagree on
    the part where it matters.

    `{}` when any covered mouth's fallback is not one of this question's own options. There is then a branch
    the proposal cannot spell in the words the answer has to be in, and half a proposal is not one.
    """
    out: dict[str, str] = {}
    for u in open_us:
        role = str(getattr(u, "fallback", "") or "")
        if role not in ROLE_OPTIONS:
            return {}
        for p in u.places:
            out[p] = role
    return out


def _proposal_sentence(roles: dict[str, str]) -> tuple[str, str]:
    """The proposal as `(the sentence a person reads, the mouth proposed as the inlet)`.

    Written FROM `roles`, so the words and the structure cannot say different things. The old sentence read
    `fallback_inlet` straight off the whole part and named it even on a question that does not cover that
    mouth, and otherwise said "the widest unplaced mouth" - which is a phrase no platform can act on, and on
    a question about one mouth is not even a statement about the mouth being asked about.
    """
    if not roles:
        return "treat the widest unplaced mouth as the inlet and the rest as outlets", ""
    inlet = next((p for p, r in roles.items() if r == "inlet"), "")
    rest = [p for p in roles if p != inlet]
    if inlet and rest:
        return f"treat {inlet} as the inlet and the other unplaced mouths as outlets", inlet
    if inlet:
        return f"treat {inlet} as the inlet", inlet
    named = "; ".join(f"{p} as {roles[p]}" for p in rest[:NAMED_IN_TEXT])
    more = f"; and {_n(len(rest) - NAMED_IN_TEXT)} more the same" if len(rest) > NAMED_IN_TEXT else ""
    return f"treat {named}{more}", ""


def port_roles(open_us: list[Any], settled: int, mouth_count: int, fallback_inlet: str) -> Question:
    """The one role question for a part, naming every mouth nothing has settled.

    `settled` is HOW MANY mouths a declaration or the brief already accounted for. The count is in the sentence
    because that is what makes the question the REMAINDER rather than the whole, and it is what a customer reads
    as the machine having understood their file. Four mouths give one question, not four.

    It is a count and not the list because the count is all this function ever read of it, and the caller was
    rebuilding the list of every other settled mouth once per settled mouth to hand it over.
    """
    #: the sentence names the mouths the two sources read differently first (`_sentence_order`); `open_us`
    #: itself, and therefore `places`, `covers` and the proposal below, stay in the finder's own ranking
    named = _sentence_order(open_us)[:NAMED_IN_TEXT]
    rest = len(open_us) - len(named)
    places = "; ".join(_place(u) for u in named)
    if rest > 0:
        places += f"; and {_n(rest)} more"
    plural = "s" if mouth_count != 1 else ""
    saw = f"I can see {_n(mouth_count)} opening{plural} on this part."
    pair = _agreement(open_us)

    if not settled and len(open_us) == mouth_count > 1:
        text = (f"{saw} Nothing you have sent names any of them: {places}.{_blind(named)}{pair}"
                " Which of these carries the incoming flow, and which are outlets?")
    elif len(open_us) == 1:
        where = (named[0].measurement or {}).get("where") or "on the body"
        known = (f" {_n(settled).capitalize()} of them you have already placed."
                 if settled else " It is not named in what you have sent.")
        text = (f"{saw}{known} The one {where}, {named[0].places[0]}, I cannot place from the shape."
                f"{_blind(named)}{pair} Is it an inlet, an outlet, or is it closed for this run?")
    else:
        known = (f" {_n(settled).capitalize()} of them you have already placed."
                 if settled else " None of them is named in what you have sent.")
        text = (f"{saw}{known} The other {_n(len(open_us))} I cannot place from the shape: {places}."
                f"{_blind(named)}{pair} Which of these carries the incoming flow, and which are outlets?")

    #: ONE PROPOSAL, WRITTEN TWICE FROM ONE READING. `default_roles` is the structure and `default` is the
    #: sentence, and the sentence is written from the structure - so a platform acting on the map and a person
    #: reading the words are given the same proposal by construction rather than by two writers agreeing.
    #:
    #: `fallback_inlet` is still taken, because it is what the old sentence said and callers pass it, but the
    #: proposal no longer depends on it: the per-mouth `fallback` it was derived from is read directly.
    roles = _proposed_roles(open_us)
    default, inlet = _proposal_sentence(roles)
    return Question(
        id="q_port_roles",
        kind="port_role",
        text=text,
        options=list(ROLE_OPTIONS),
        default=default,
        default_subject=inlet,
        default_roles=roles,
        default_is="operation",
        because=("the mesher cuts every flat face it finds as a port and sizes the whole mesh against the "
                 "widest one, so this decides which face carries the incoming condition and how fine the mesh "
                 "is everywhere"),
        tier="boundary", effect="changes_bc",
        places=[p for u in open_us for p in u.places],
        covers=[u.id for u in open_us],
    )


def unlabelled_mouth(u: Any) -> Question:
    count = int((u.measurement or {}).get("count") or 1)
    return Question(
        id="q_unlabelled_mouth", kind="unlabelled_mouth",
        text=(f"Looking at the pictures of this part I think there {'is' if count == 1 else 'are'} "
              f"{_n(count)} more opening{'' if count == 1 else 's'} than the measurement found. That is the one "
              "thing the pictures catch that the measurement cannot. Is there an opening I have missed?"),
        options=["no, that is all of them", "yes, there is another opening"],
        default="no, that is all of them, and the measurement's list stands",
        default_is="acceptance",
        because=("an opening nobody measured is a hole in the fluid volume: on a carve the cavity leaks into "
                 "the outside and the run is wasted"),
        tier="domain", effect="changes_mesh", places=[], covers=[u.id],
    )


def flow_direction(u: Any) -> Question:
    m = u.measurement or {}
    axis = str(m.get("longest_axis") or "x")
    default = str(u.fallback or "along +x")
    return Question(
        id="q_flow_direction", kind="flow_direction",
        text=(f"This is an external case, so I put a wind tunnel around the body and leave the long room "
              f"downstream. The shape does not tell me which end is the nose: the body is longest along {axis} "
              f"and neither end reads as the blunt one. Unless you say otherwise the flow runs {default}. Which "
              "way does the flow come at it?"),
        #: every direction, because the answer is often not the long axis (a wing spans y and flies along x)
        options=[*(list(u.branches) or ["along +x", "along -x"]), "it does not matter for this run"],
        default=f"take the flow {default}, which is what the mesher does when nobody says",
        default_is="operation",
        because=("the downstream room and the wake refinement go on whichever side I am told is behind the "
                 "body, and if that is the wrong side the refined cells sit in front of it"),
        tier="domain", effect="changes_mesh", places=[], covers=[u.id],
    )


def unit(u: Any) -> Question:
    # the uncertainty's own fallback, which is the measurement's most plausible unit (`plausible_unit`), so the
    # sentence and the default say the same thing the measurement does
    assumed = str(u.fallback or "mm")
    return Question(
        id="q_unit", kind="unit",
        text=("This file format carries no unit, so I cannot tell from the file whether it is in millimetres "
              f"or in metres. I am reading it as {assumed}. Is that right?"),
        options=sorted({assumed, "mm", "m", "in"}),
        default=f"read the file as {assumed}",
        default_is="acceptance",
        because=("every length I hand the mesher is in metres, so a unit that is out by a factor of a thousand "
                 "is a domain a thousand times too big and a first cell a thousand times too thin"),
        tier="domain", effect="changes_bc", places=[], covers=[u.id],
    )


#: The two answers to which side is the fluid, in a customer's words, keyed by `catalog.FLUID_SIDES`. The words are
#: the options; `fluid_side_of` reads a chosen option back to its key, which is what the representation is set by.
FLUID_SIDE_WORDS: dict[str, str] = {
    "through": "the fluid flows through the {bore}; the part is the solid around it",
    "is_fluid": "the part is the fluid itself, the volume the flow fills",
}


def _side_words(key: str, bores: int) -> str:
    return FLUID_SIDE_WORDS[key].format(bore="bores" if bores > 1 else "bore")


def fluid_side_of(option: str, bores: int = 1) -> str | None:
    """The `catalog.FLUID_SIDES` key a chosen option names, or None when it names neither."""
    said = str(option or "").strip().lower()
    for key in FLUID_SIDE_WORDS:
        if said in (key, _side_words(key, bores).lower(), _side_words(key, 1).lower(), _side_words(key, 2).lower()):
            return key
    return None


def fluid_side(u: Any) -> Question:
    """Which side of the surface is the fluid, asked the way a person would ask it.

    WHAT I SAW is the bores the measurement counted and the widest of them; WHAT I CANNOT is which side the flow is
    on, because the two readings are the same shape. The default is what the mesher does today, and the sentence
    says so, along with the one thing that waits for the answer."""
    m = u.measurement or {}
    bores = int(m.get("bores") or 0)
    widest = m.get("widest_bore_mm")
    size = f", {float(widest):.0f} mm across at the widest" if widest else ""
    if bores:
        saw = (f"I can see {_n(bores)} bore{'s' if bores > 1 else ''} running through this part{size}. From the "
               "shape alone I cannot tell which side of the surface is the fluid: the part could be solid metal with "
               f"the flow running through the bore{'s' if bores > 1 else ''}, or the file could be the fluid itself, "
               "the volume the flow fills.")
        ask = (f"Does the fluid flow through the bore{'s' if bores > 1 else ''} in this part, or is the part itself "
               "the fluid?")
    else:
        saw = ("I cannot find a mouth on this part that tells me which side of its surface the flow is on: it could "
               "be solid metal with the flow running through it, or the file could be the fluid itself.")
        ask = "Is the fluid inside passages through this part, or is the part itself the fluid?"
    keys = [k for k in ("through", "is_fluid") if k in (u.branches or ["through", "is_fluid"])]
    return Question(
        id="q_fluid_side", kind="fluid_side",
        text=f"{saw} {ask}",
        options=[_side_words(k, bores) for k in keys],
        default=("treat the part as the fluid itself, which is what the mesher does when nobody says; until you "
                 "say, nothing on the flow path is marked for extra cells"),
        default_is="operation",
        because=("the mesher fills whichever side it is told is the fluid, so the wrong answer meshes the metal as "
                 "the flow, and every junction and bend it is pointed at is on the wrong body"),
        tier="domain", effect="changes_mesh", places=[], covers=[u.id],
    )


def budget(u: Any) -> Question:
    m = u.measurement or {}
    cap, high = m.get("cell_cap"), m.get("cells_high")
    cap_txt = f"{int(cap) / 1e6:.2g} million" if cap else "the budget you set"
    high_txt = f"{int(high) / 1e6:.2g} million" if high else "more"
    return Question(
        id="q_budget", kind="budget_envelope",
        text=(f"You asked me to keep this under {cap_txt} cells. Resolving this part properly comes to at least "
              f"{high_txt}, and that figure is a floor rather than a guess: it is what the mesher's own sizing "
              "gives before any refinement is added. I can hold your number and mesh the small features "
              "coarser, or I can go over it. Which would you rather?"),
        options=["hold the budget", "raise the budget", "hold it and tell me what was lost"],
        default=f"hold {cap_txt} and mesh the smallest features coarser",
        default_is="operation",
        because="the cell ceiling is the one number that decides how much of this part gets resolved at all",
        tier="resolution", effect="changes_mesh", places=[], covers=[u.id],
    )


#: The two answers to a predicted dispatch refusal, in a customer's words, keyed by what each one MEANS to
#: whoever dispatches. The words are the options; `dispatch_of` reads a chosen option back to its key.
#:
#: IT IS A MAP AND NOT A POSITION, for the reason `ask.trade.Trade.value_of` exists: an index into an option
#: list was wrong on the third question the moment a third existed. And it is HERE rather than restated by the
#: caller, because the caller that needs it is the one that decides whether the job runs -
#: `meshpipeline.application.geometry_survey.dispatch_refusals` - and this question's answer is the only thing
#: that says so. `contract.marks.OWNERS` puts it plainly: the prediction is a measurement of the file against
#: the platform's rules, and the decision is the customer's. A decision nothing can read is not a decision.
DISPATCH_WORDS: dict[str, str] = {
    "send_back": "send it back now",
    "run_it": "try it anyway",
}

#: The uncertainty's own wording for the same two branches (`ask.uncertainty.dispatch_uncertainty`), which is
#: what `ask.record` stores as `proposed` and `branches`. Read too, so a reader holding either spelling of one
#: answer gets one meaning out of it.
_DISPATCH_ALIASES: dict[str, str] = {"send it back to be fixed": "send_back"}


def dispatch_of(option: str) -> str | None:
    """Which of `DISPATCH_WORDS` a chosen option names, or None when it names neither."""
    said = str(option or "").strip().lower()
    for key, words in DISPATCH_WORDS.items():
        if said in (key, words.lower()):
            return key
    return _DISPATCH_ALIASES.get(said)


def dispatch(u: Any) -> Question:
    reasons = str(u.abstention or "").split(";")
    first = reasons[0].strip() if reasons else ""
    return Question(
        id="q_dispatch", kind="dispatch_refusal",
        text=("Before I start: I do not think this file will get through the mesher as it stands. "
              + (f"{first}. " if first else "")
              + "I can send it back to you now rather than spend the run finding out. Shall I?"),
        options=list(DISPATCH_WORDS.values()),
        default=f"{DISPATCH_WORDS['send_back']}, before the run is spent",
        default_is="operation",
        because="the mesher raises on this before it starts, so the run produces nothing either way",
        tier="dispatch", effect="changes_mesh", places=[], covers=[u.id],
    )


def look_dispute(u: Any) -> Question:
    m = u.measurement or {}
    return Question(
        id="q_look_dispute", kind="look_dispute",
        #: `reconcile.verdict.question` already wrote this sentence and it was read on the corpus
        #: (eval/vision/results/reconcile/questions.md). Rewriting it here would be a second wording of one
        #: question with no reason to prefer either.
        text=str(m.get("ask") or "the pictures and the measurement disagree about this part."),
        options=["resolve it", "it is not there"],
        default="treat it as present and resolve it",
        default_is="operation",
        because=str(m.get("because") or "under-resolving a feature that is there costs a wrong answer, and "
                                        "over-resolving one that is not costs cells"),
        #: THE PLACE, which this question used to drop. `reconcile.verdict.question` and
        #: `monitor.Alert.subject` both name the mouth or the mark letter the disagreement is AT, and `places`
        #: was `[]`, so `chain.job._evidence` attached none of that place's measured marks and nothing
        #: downstream could tell which mouth the one real question was about.
        tier="resolution", effect="changes_mesh", places=list(u.places), covers=[u.id],
    )


#: kind -> the writer for one uncertainty. `port_role` is not here because it is written for a GROUP.
WRITERS = {
    "unlabelled_mouth": unlabelled_mouth,
    "flow_direction": flow_direction,
    "unit": unit,
    "fluid_side": fluid_side,
    "budget_envelope": budget,
    "dispatch_refusal": dispatch,
    "look_dispute": look_dispute,
}


def write(u: Any) -> Question | None:
    w = WRITERS.get(u.kind)
    return w(u) if w else None


__all__ = ["DISPATCH_WORDS", "FLUID_SIDE_WORDS", "NAMED_IN_TEXT", "ROLE_OPTIONS", "WRITERS", "budget",
           "dispatch", "dispatch_of", "flow_direction",
           "fluid_side", "fluid_side_of", "look_dispute", "port_roles", "unit", "unlabelled_mouth", "write"]
