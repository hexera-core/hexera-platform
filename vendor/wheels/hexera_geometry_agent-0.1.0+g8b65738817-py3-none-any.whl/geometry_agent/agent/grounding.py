"""Reject any plan whose numbers did not come from a measurement, and any plan that asks the user what the file,
the brief or the catalog already settled. The model interprets; it never originates a quantity, and it never
asks twice."""
from __future__ import annotations

import json
import math
import re
from typing import Any

from pydantic import ValidationError

from geometry_agent.agent import catalog
from geometry_agent.agent.schema import EFFECTS, MECHANISMS, PLAN_SCHEMA_VERSION, GeometryPlan, Risk
from geometry_agent.agent.thresholds import current as current_thresholds
from geometry_agent.agent.tools import AXIS_COMPONENT_SNAP, ToolContext
from geometry_agent.vision import trust as _vision_trust

#: The opening message writes every float to four significant figures (tools.PACKET_SIG_FIGS): a copy is within
#: 5e-4 of the measurement, and a value the model re-rounds after a factor within 1e-3. 5e-3 leaves that a margin
#: of five and still refuses a number one percent off; the nearest derivation factors are six percent apart.
REL_TOL = 5e-3
#: A flow axis within this many degrees of a coordinate axis or a principal axis is that measured direction.
#:
#: NOT THE SAME QUESTION AS `geometry_agent.axis.AXIS_SNAP`, and the two are not to be merged. This is a
#: CITATION tolerance: `_check_flow` requires every component of `flow.axis` to be a measured principal-axis
#: component or exactly plus or minus one, so a plan that wrote a direction three degrees off the measurement's
#: own number is rewritten to cite the measurement rather than rejected over a rounding. It answers "is this
#: the measured vector", so it is tight. `AXIS_SNAP` answers "does this vector name an axis letter the builder
#: can be handed", which is a different question with a different consequence, and
#: `reconcile.profile.AXIS_COS` answers a third one, about whether a cut across a line is across the flow.
#: Three questions, three cutoffs, each stated where it is decided; `geometry_agent/axis.py` carries the
#: boundary in full.
FLOW_AXIS_SNAP_DEG = 3.0
DERIVATION_FACTORS = [2.0**k for k in range(-14, 9)] + [3, 5, 6, 10, 15, 20, 1 / 3, 1 / 5, 1 / 10, 1 / 15, 1 / 20]
SYNTHETIC_PATCHES = {"walls", "farfield", "symmetry", "body", "hub", "shroud", "rotating_zone"}
#: Roles a patch may carry under any id (the user's patch name): they never stand for one measured opening.
NAMED_SYNTHETIC_ROLES = {"wall", "farfield", "symmetry", "interface"}
#: Roles whose patches take no prism layers: layers grow from walls.
NO_LAYER_ROLES = {"inlet", "outlet", "farfield", "symmetry"}
EXTENT_KEYS = ("upstream", "downstream", "lateral", "vertical")
REQUIRED_EXTENT_KEYS = ("upstream", "downstream", "lateral")
#: R35: a required extent is an absolute length in the plan's unit, so it is a multiple of the body's own longest
#: extent in that same unit. The standard multiples are the thresholds (5 L, 15 L, 5 L); these are the bounds
#: outside which the number is not a far-field length at all. Structural, not a catalog threshold: the low bound is
#: the body itself (a domain smaller than the body cannot enclose it) and the high bound is well clear of the
#: largest standard multiple, so only an arithmetic or unit fault reaches either.
EXTENT_OVER_L = (1.0, 50.0)
#: A confidence above this on a role or direction the plan still asks about is a guess dressed as knowledge.
ASKED_CONFIDENCE_MAX = 0.5
#: Region roles are required one per body only up to this many bodies; a 402-body assembly lists what matters.
REGION_ROLES_MAX = 12
#: A derived number must be stated in its derivation within this relative band.
DERIVED_MATCH_BAND = 0.05
UNIT_WORDS = {"mm", "cm", "m", "in", "ft"}

PROCEED = re.compile(r"do not ask|don'?t ask|no questions|without (asking )?questions|without asking|proceed without|"
                     r"sensible (engineering )?defaults|use (sensible |engineering )?defaults|just proceed", re.I)
SOLVER_SETUP_KINDS = re.compile(r"velocity_(unknown|missing|unspecified|needed)|inlet_velocity|freestream|reynolds|boundary_?cond|"
                                r"(^|_)bc(s)?(_|$)|inlet_profile|flow_split|metric|material|thermal_(bc|boundary|condition)|rpm|y_?plus|"
                                r"operating|fluid_prop|(^|_)loads?(_|$)|angle_of_attack|(^|_)aoa(_|$)|(^|_)mach(_|$)|quantity_of_interest", re.I)
STUB_KINDS = re.compile(r"stub|straight_run|(^|_)run(_|$)|develop|recovery|tangent", re.I)
CAPPED_KINDS = re.compile(r"capped|blanked|not_capped|open_end|dead_end_open", re.I)
BRIEF_CAPPED = re.compile(r"capped|blanked|closed|dead[- ]?end|blind", re.I)
BAD_OPTION = re.compile(r"\b(provide|specify|not sure|don'?t know|unknown - investigate|i will)\b|^\s*other\b|\(other\)", re.I)
JARGON = re.compile(r"checker|detector|catalog|port_candidate|opening_unknown|planar_face|^\s*ask:", re.I)
NEAR_WALL_REGION = re.compile(r"near[- ]?wall|boundary[- ]?layer|prism", re.I)
OPENING_ID = re.compile(r"\bo\d+\b")
#: A length written with a unit inside a question that asks what the unit is (schema 3; prompt v2 said it inline).
LENGTH_WITH_UNIT = re.compile(r"\d+(?:\.\d+)?\s*(?:mm|cm|m|in|ft)\b", re.I)
#: Catalog kinds whose question decides what an opening IS (its role); two of them on one opening is one question.
ROLE_DECISION_KINDS = {"undeclared_opening", "role_assumed", "declared_port_unmatched", "tiny_port"}
#: A `relates_to` that names the flow direction rather than a target the plan holds (R8's message, and the reason
#: it points at the role risk instead of only saying what the field is not).
DIRECTION_WORDS = re.compile(r"direction|inlet|outlet|flow|which way|upstream|downstream", re.I)
NUMBER = re.compile(r"-?\d+(?:,\d{3})*(?:\.\d+)?(?:[eE][-+]?\d+)?")
#: An evidence string that leans on a picture must say so in these words, so the builder can tell it from a measurement.
VISION_PREFIX = "visual impression:"
#: The same words wherever a sentence rather than a list entry carries the claim: a refinement's reason, a layer
#: target's reason, an extension's reason, an agent risk's prose, a mesh warning's why, the builder prose. An
#: evidence entry has to OPEN with VISION_PREFIX; a sentence need only carry these words, because a reason begins
#: with its own subject and "visual impression: the shoulder will starve of cells" is not English.
VISION_MARK = "visual impression"
#: The vision tool's name as a plan may write it in `object.identity.tests_run`. It measures nothing, so an entry
#: naming it is never a cited test (R38).
LOOK_TOOL = "look_at_views"
VISION_CITE = re.compile(r"look_at_views|visual impression|vision model|\bvisually\b|\brender(?:ed|s|ing)?\b|"
                         r"\b(?:the|from|in)\s+(?:images?|pictures?|views)\b", re.I)


ABS_TOL = 1.5e-6


def _close(a: float, b: float) -> bool:
    b = round(b, 6)
    if a == b or abs(a - b) < ABS_TOL:
        return True
    if b == 0:
        return False
    return abs(a / b - 1.0) < REL_TOL


def _measured(x: float, ledger: set[float]) -> bool:
    if x == 0.0 or x in ledger:
        return True
    return any(_close(x, v) for v in ledger)


def _derivable(x: float, ledger: set[float]) -> bool:
    if _measured(x, ledger):
        return True
    for v in ledger:
        if v == 0:
            continue
        r = x / v
        if any(abs(r / f - 1.0) < REL_TOL for f in DERIVATION_FACTORS):
            return True
    return False


def _plausible_first_cell(h: float, ledger: set[float]) -> bool:
    if h <= 0:
        return False
    lengths = [v for v in ledger if v > 0]
    return any(1e-5 * v <= h <= 0.02 * v for v in lengths)


def _vision_numbers(ctx: ToolContext) -> set[float]:
    """Every number the vision reply carried: the raw tokens kept on the context plus anything that survived
    into the impression text (the scrub leaves none, but the check does not rely on that)."""
    nums = set(getattr(ctx, "vision_numbers", None) or ())
    impression = getattr(ctx, "vision_impression", None)
    if impression:
        nums |= set(_numbers_in(json.dumps(impression)))
    return nums


def _untraced(x: float, ctx: ToolContext) -> str:
    """The reason an untraced number is refused: named as the picture's when the vision reply carried it."""
    if any(_close(float(x), v) for v in _vision_numbers(ctx) if v != 0):
        return " (this number came from the visual impression, not a measurement; only measured numbers may enter the plan)"
    return ""


ANCHOR_SNAP_OVER_D = 0.5


def _measured_points(facts) -> list[tuple[float, float, float]]:
    pts = [o.centroid for o in facts.openings]
    pts += [s.end_point for s in facts.stubs if s.end_point]
    pts += [c.centroid for c in facts.features.thin_clusters]
    return pts


def _point_segment_distance(p, a, b) -> float:
    ab = [b[i] - a[i] for i in range(3)]
    ap = [p[i] - a[i] for i in range(3)]
    denom = sum(v * v for v in ab)
    t = 0.0 if denom == 0 else max(0.0, min(1.0, sum(x * y for x, y in zip(ap, ab)) / denom))
    q = [a[i] + t * ab[i] for i in range(3)]
    return math.dist(p, q)


def _measured_segments(facts) -> list[tuple]:
    """Axes the geometry provides: each opening to the end of its stub, each pair of openings of one region
    (the axis of a straight run, the line between the two ends of a pipe), and each pair of stub ends of one
    region (the header between two junctions)."""
    segs = []
    ends = []
    for s in facts.stubs:
        o = facts.opening(s.opening_id)
        if o is not None and s.end_point:
            segs.append((o.centroid, s.end_point))
            ends.append((o.region_id, s.end_point))
    ops = facts.openings[:12]
    for i, a in enumerate(ops):
        for b in ops[i + 1:]:
            if a.region_id == b.region_id:
                segs.append((a.centroid, b.centroid))
    for i, (ra, pa) in enumerate(ends[:12]):
        for rb, pb in ends[i + 1:12]:
            if ra == rb:
                segs.append((pa, pb))
    return segs


EXTERNAL_DOMAIN_DEFAULT_OVER_L = 20.0


def _in_external_domain(anchor, facts, plan) -> bool:
    """An external case's refinement (a wake box, a near-body band) lives anywhere in the far-field domain the
    plan itself declares; the body's measured box, grown by the plan's extents, bounds it."""
    if plan.purpose != "external_cfd":
        return False
    L = max(facts.bbox.extent)
    ext = plan.mesh_plan.required_extents
    grow = max([v for v in ext.values() if isinstance(v, (int, float))] or [EXTERNAL_DOMAIN_DEFAULT_OVER_L * L])
    lo = [facts.bbox.min[i] - grow for i in range(3)]
    hi = [facts.bbox.max[i] + grow for i in range(3)]
    return all(lo[i] <= anchor[i] <= hi[i] for i in range(3))


def _anchored(anchor, facts, ledger: set[float], plan=None) -> bool:
    """A refinement anchor is a measured point, lies within half a bore of one, or within half a bore of a
    measured axis (an opening's stub, the line between two openings of the same body, the header between two
    junctions); for an external case it may be anywhere inside the declared domain. A refinement region is a
    fuzzy volume, so 'the middle of the run', 'the junction, give or take half a diameter' and 'the wake' are
    legitimate, checkable places to put it."""
    if all(_measured(c, ledger) for c in anchor):
        return True
    scale = max((o.hydraulic_diameter for o in facts.openings), default=0.0) or 0.02 * facts.bbox.diagonal
    tol = ANCHOR_SNAP_OVER_D * scale
    a = anchor
    if any(math.dist(a, p) <= tol for p in _measured_points(facts)):
        return True
    if any(_point_segment_distance(a, p, q) <= tol for p, q in _measured_segments(facts)):
        return True
    return plan is not None and _in_external_domain(a, facts, plan)


def _anchor_candidates(facts) -> str:
    """The measured points a refinement may be anchored on, named so a rejection is fixable in one turn."""
    parts = [f"{o.id} centroid {[round(c, 6) for c in o.centroid]}" for o in facts.openings[:12]]
    parts += [f"{s.opening_id} stub_ends_at {[round(c, 6) for c in s.end_point]}" for s in facts.stubs[:12] if s.end_point]
    parts += [f"cluster {c.id} centroid {[round(v, 6) for v in c.centroid]}" for c in facts.features.thin_clusters[:8]]
    return "; ".join(parts) if parts else "no measured points exist for this file"


def _risk_key(r: Risk | dict) -> tuple:
    d = r if isinstance(r, dict) else r.model_dump()
    m = d.get("measurement") or {}
    return (d.get("kind"), m.get("opening_id"), m.get("cluster_id"),
            m.get("declared", {}).get("name") if isinstance(m.get("declared"), dict) else None)


#: Measurement keys that list alternatives rather than the risk's subject (the candidates a declared port might
#: be); ids under them do not make two risks "about" the same opening.
ALTERNATIVE_KEYS = {"measured_candidates", "candidates", "ids", "plausible", "tiers_that_fit"}


def _ids_in(obj: Any) -> set[str]:
    """Every opening or region id a measurement names as its subject (opening_id, hole_ids, nested pairs), not
    the alternatives it lists."""
    out: set[str] = set()
    if isinstance(obj, str):
        if re.fullmatch(r"[or]\d+", obj):
            out.add(obj)
    elif isinstance(obj, dict):
        for k, v in obj.items():
            if k in ALTERNATIVE_KEYS:
                continue
            out |= _ids_in(v)
    elif isinstance(obj, (list, tuple)):
        for v in obj:
            out |= _ids_in(v)
    return out


def _role_ids(r: Risk) -> set[str]:
    """The openings whose role a role-decision risk is about."""
    m = r.measurement
    out = set()
    if m.get("opening_id"):
        out.add(m["opening_id"])
    for k in ("inlet_ids", "outlet_ids"):
        out |= {x for x in (m.get(k) or []) if isinstance(x, str)}
    return out


def _has_number(obj: Any) -> bool:
    if isinstance(obj, bool):
        return False
    if isinstance(obj, (int, float)):
        return True
    if isinstance(obj, dict):
        return any(_has_number(v) for v in obj.values())
    if isinstance(obj, (list, tuple)):
        return any(_has_number(v) for v in obj)
    return False


def _numbers_in(text: str) -> list[float]:
    out = []
    for tok in NUMBER.findall(text or ""):
        try:
            out.append(float(tok.replace(",", "")))
        except ValueError:
            continue
    return out


def _stated(value: float, numbers: list[float]) -> bool:
    if value == 0:
        return any(abs(n) < 1e-12 for n in numbers)
    return any(abs(n / value - 1.0) <= DERIVED_MATCH_BAND for n in numbers) or any(abs(n - value) <= 1e-9 for n in numbers)


#: A derivation id as derived_geometry and compare_roles return them (d1, d2, ...), cited in a derivation or a reason.
DERIVATION_ID = re.compile(r"\bd\d+\b")
DERIVATION_ID_KEYS = ("derivation_id", "derivation_ids")


def _derived_items(r: Risk) -> list[tuple[str, float, list[str]]]:
    """(key, value, derivation ids cited) for every numeric value in a risk's `derived`. A value is a number or
    {value, derivation_id}; a `derivation_id` (or `derivation_ids`) key in `derived` and every dN token in
    `derivation` cite for all of them, a value's own id for itself."""
    d = r.derived or {}
    shared: list[str] = []
    for k in DERIVATION_ID_KEYS:
        v = d.get(k)
        shared += [v] if isinstance(v, str) else [x for x in (v if isinstance(v, list) else []) if isinstance(x, str)]
    shared += DERIVATION_ID.findall(r.derivation or "")
    shared = list(dict.fromkeys(x for x in shared if DERIVATION_ID.fullmatch(x)))
    out = []
    for k, v in d.items():
        if k in DERIVATION_ID_KEYS:
            continue
        if isinstance(v, dict):
            val, own = v.get("value"), v.get("derivation_id")
            if isinstance(val, (int, float)) and not isinstance(val, bool):
                out.append((k, float(val), [own] if isinstance(own, str) and DERIVATION_ID.fullmatch(own) else shared))
        elif isinstance(v, (int, float)) and not isinstance(v, bool):
            out.append((k, float(v), shared))
    return out


DEFAULT_OPTIONS = {
    "short_stub": ["extend to 5D", "declare as inlet", "accept as is"],
    "undeclared_opening": ["closed end", "inlet", "outlet"],
    "region_purpose_mismatch": ["intentional (CHT)", "send to repair", "abort"],
    "not_watertight": ["send to repair", "rims are ports, cap them", "abort"],
    "surface_holes": ["send to repair", "one of these is a port", "abort"],
    "cell_cap": ["drop fidelity", "raise cap", "abort"],
    "declared_port_unmatched": ["pick from measured list", "correct declaration"],
    "ambiguous_openings": ["name the ports now"],
    "unit_implausible": ["confirm declared unit", "override unit"],
    "unit_unknown": ["mm", "m", "in", "cm", "ft"],
    "rotor_topology": ["add rotating zone", "run stationary"],
    "solid_wall_representation": ["upload the fluid body", "extract the bore in CAD", "abort"],
    "tiny_port": ["open port", "closed for this run", "defeature it"],
    "nested_bodies": ["inner body is the fluid", "change purpose to CHT", "remove the cavity"],
    "solid_fluid_pair": ["inner body is the fluid", "outer body is the fluid", "close the gap in CAD"],
    "no_shared_interface": ["fix in CAD", "change purpose", "abort"],
    "unshared_interface": ["glue the bodies in CAD", "change purpose", "abort"],
    "role_assumed": ["keep the assigned direction", "reverse it"],
    "non_manifold_surface": ["send to repair", "accept as is"],
}


def _catalog_question_text(r: dict) -> str:
    """The catalog's recommendation, addressed to the engineer: no 'Ask:' prefix, the openings named."""
    text = re.sub(r"^\s*ask:\s*", "", (r.get("recommendation") or "").strip(), flags=re.I)
    if not text:
        text = (r.get("consequence") or "").strip()
    return text


def _merge_role_questions(questions: list[dict], risks: list[dict]) -> list[dict]:
    """Two questions that ask what one opening IS (a tiny_port and an undeclared_opening on the same drain, a
    patch question beside a role risk) are one decision: the first keeps its text and options, the second's
    risk moves into its also_settles. Merging is mechanical; which options to offer stays the model's."""
    risk_by_id = {r.get("id"): r for r in risks}
    holder: dict[str, dict] = {}
    out: list[dict] = []
    for q in questions:
        target = q.get("relates_to")
        r = risk_by_id.get(target)
        if r is not None and r.get("kind") in ROLE_DECISION_KINDS:
            oid = (r.get("measurement") or {}).get("opening_id")
        elif r is None and isinstance(target, str) and OPENING_ID.fullmatch(target):
            oid = target
        else:
            oid = None
        if oid and oid in holder:
            host = holder[oid]
            extra = [x for x in ([target] if r is not None else []) + list(q.get("also_settles") or [])
                     if x and x != host.get("relates_to") and x not in (host.get("also_settles") or [])]
            host["also_settles"] = list(host.get("also_settles") or []) + extra
            continue
        if oid:
            holder[oid] = q
        out.append(q)
    return out


def _default_unit(ctx: ToolContext) -> dict[str, Any] | None:
    """The unit call the file or the brief settles by itself; None when only the model (or the user) can."""
    facts = ctx.facts
    if facts.units.declared:
        return {"declared": facts.units.declared, "assumed": facts.units.declared, "basis": "file"}
    settled, _why = catalog.unit_from_brief(facts, ctx.brief, ctx.purpose)
    if settled:
        return {"declared": None, "assumed": settled, "basis": "brief"}
    return None


def _default_seed_point(plan_obj: dict[str, Any], ctx: ToolContext) -> list[float] | None:
    """A point inside the fluid just inside the inlet (the first inlet patch, else the first port opening): what
    snappy's locationInMesh needs, computed from the port's centroid and inward direction."""
    facts = ctx.facts
    rep = catalog.representation(facts, ctx.purpose, ctx.brief, declared=ctx.declared, fluid_side=ctx.fluid_side)
    candidates = catalog.port_openings(facts, rep, ctx.declared)
    if not candidates:
        return None
    roles = {p.get("id"): p.get("role") for p in plan_obj.get("patches") or [] if isinstance(p, dict)}
    inlet = next((o for o in candidates if roles.get(o.id) == "inlet"), None) or \
        next((o for o in candidates if roles.get(o.id) == "outlet"), None) or candidates[0]
    seed = catalog.seed_point_for(facts, inlet, rep)
    return [round(c, 6) for c in seed] if seed else None


def _default_region_roles(ctx: ToolContext) -> list[dict[str, str]]:
    """Region roles nobody needs to be asked for: one body under internal flow is the fluid, every body under
    external flow is an obstacle in the far field, every body under structural is solid. Conjugate cases and
    multi-body internal cases are the model's call."""
    regions = ctx.facts.regions
    if len(regions) > REGION_ROLES_MAX:
        return []
    rep = catalog.representation(ctx.facts, ctx.purpose, ctx.brief, declared=ctx.declared, fluid_side=ctx.fluid_side)
    if ctx.purpose == "internal_cfd" and rep == "wall_shell":
        return [{"id": r.id, "role": "obstacle" if r.nested_in else "wall_shell",
                 "reason": "a centre body inside the wall shell" if r.nested_in else "the solid wall; the fluid cavity is carved inside it"}
                for r in regions]
    if ctx.purpose == "internal_cfd" and len(regions) == 1:
        return [{"id": regions[0].id, "role": "fluid", "reason": "the only body under internal flow"}]
    if ctx.purpose == "external_cfd":
        return [{"id": r.id, "role": "obstacle", "reason": "a body the far-field flow goes around"} for r in regions]
    if ctx.purpose == "structural":
        return [{"id": r.id, "role": "solid", "reason": "a solid part"} for r in regions]
    return []


def _snap_flow_axis(axis: Any, facts) -> tuple[list[float], bool] | None:
    """The measured direction within FLOW_AXIS_SNAP_DEG of the plan's flow axis, and whether it points the
    other way. A coordinate axis keeps the plan's sign (a unit vector is measured either way); a principal axis
    is returned exactly as measured (its components under AXIS_COMPONENT_SNAP written as 0, as the packet writes
    them), because only the measured signs are in the ledger, and the flip is folded into direction_sign by the
    caller so axis times sign still points the way the plan said. None when no measured direction is that
    close: the axis then stands and is checked as written."""
    try:
        v = [float(c) for c in axis]
    except (TypeError, ValueError):
        return None
    n = math.sqrt(sum(c * c for c in v))
    if len(v) != 3 or n <= 0 or not math.isfinite(n):
        return None
    units = [[1.0 if i == j else 0.0 for j in range(3)] for i in range(3)]
    principal = [[0.0 if abs(float(c)) < AXIS_COMPONENT_SNAP else float(c) for c in p] for p in facts.axes.principal]
    best, best_dot, is_unit = None, 0.0, False
    for c in units + principal:
        cn = math.sqrt(sum(x * x for x in c)) or 1.0
        d = sum(a * b for a, b in zip(v, c)) / (n * cn)
        if abs(d) > abs(best_dot):
            best, best_dot, is_unit = c, d, c in units
    if best is None or abs(best_dot) < math.cos(math.radians(FLOW_AXIS_SNAP_DEG)):
        return None
    if is_unit:
        sign = 1.0 if best_dot >= 0 else -1.0
        return [0.0 if c == 0 else sign * c for c in best], False
    return list(best), best_dot < 0


def _same_measure(got: Any, want: Any) -> bool:
    """A written patch number is a copy of the measured one: a scalar within REL_TOL, a vector component by
    component. A direction cosine the model rounded to four figures writes 0.0 for a 7e-06 component, which is
    the same direction, so a vector is also compared with a small absolute tolerance."""
    if isinstance(want, (list, tuple)):
        if not isinstance(got, (list, tuple)) or len(got) != len(want):
            return False
        return all(_close(float(a), float(b)) or abs(float(a) - float(b)) <= 1e-3 for a, b in zip(got, want))
    try:
        return _close(float(got), float(want))
    except (TypeError, ValueError):
        return False


def _short(v: Any) -> str:
    if isinstance(v, (list, tuple)):
        return "[" + ", ".join(f"{float(c):.6g}" for c in v) + "]"
    return f"{float(v):.6g}" if isinstance(v, (int, float)) else repr(v)


def _fill_patch_numbers(patches: list, facts, notes: list[str] | None = None) -> None:
    """Packet v2: a patch carries id, role, confidence, evidence and confirmed_by_user; area, centroid, normal
    and hydraulic_diameter come from the measured opening (zeros for a synthetic surface).

    R22 (P4.3b): a number the model wrote for a measured opening is a copy of a measurement, never a new
    quantity, so the measured value replaces it and the difference is logged; only an unknown id, a missing
    opening or a class violation is rejected (_check_patches). A ring port described by its bore instead of
    its ring face is left as written: the bore is the port's own measured diameter."""
    known = {o.id: o for o in facts.openings}
    log = notes if notes is not None else []
    for p in patches:
        if not isinstance(p, dict):
            continue
        o = known.get(p.get("id"))
        fills = ({"area": o.area, "centroid": list(o.centroid), "normal": list(o.normal), "hydraulic_diameter": o.hydraulic_diameter}
                 if o is not None else {"area": 0.0, "centroid": [0.0, 0.0, 0.0], "normal": [0.0, 0.0, 0.0], "hydraulic_diameter": 0.0})
        replaced: list[str] = []
        for k, v in fills.items():
            got = p.get(k)
            if got is None:
                p[k] = v
                continue
            if o is None or _same_measure(got, v):
                p[k] = v if o is not None else got
                continue
            if _ring_bore_form(o, k, got):
                continue
            replaced.append(f"{k} {_short(got)} -> {_short(v)}")
            p[k] = v
        if replaced and o is not None:
            log.append(f"R22 repair: patch {p.get('id')} carried numbers that are not the measurement ({'; '.join(replaced)}); the "
                       "measured values are used (the checker fills every measured patch number, so none is retyped)")


def _ring_bore_form(o, name: str, got: Any) -> bool:
    """A ring port may be given by its bore (the port's own diameter) or the bore's area instead of the ring face."""
    if o.kind != "ring" or not o.bore_diameter:
        return False
    if name == "hydraulic_diameter":
        return _same_measure(got, o.bore_diameter)
    if name == "area":
        return _same_measure(got, math.pi / 4 * o.bore_diameter ** 2)
    return False


# ---------------------------------------------------------------------------------------------------------------
# P4.3 repairs (dev plan P4.3; docs/plan_v3_rules.md, "P4.3 repairs"). The mechanical rejections of the P4.1
# learning-half run whose meaning is not in doubt are repaired in _normalise and logged in hints["warnings"] (the
# loop copies the notes into the trace), so they cost no round: R13 the region role of a single external body,
# R14 a lone id written where a list is asked for, R15 a direction_sign pointing from the outlets to the inlets.
# R16, the first-cell citation read in the plan's unit, is a checker reading (_cites_ok), not a repair.
# ---------------------------------------------------------------------------------------------------------------
EXTERNAL_PURPOSES = {"external_cfd"}
#: Region roles a single external body cannot carry: the far-field flow goes around it, so it is an obstacle.
EXTERNAL_SOLID_MISROLES = {"not_a_fluid_body", "wall_shell"}
#: An agent risk whose only content is that the external body is the solid (R13 drops it): by its kind, or by
#: what its consequence and recommendation say.
EXTERNAL_SOLID_KIND = re.compile(r"external[_ -]?(?:body|solid)|solid[_ -]?body|body[_ -]?(?:is[_ -]?)?solid|not[_ -]?a[_ -]?fluid|"
                                 r"single[_ -]?(?:solid[_ -]?)?body", re.I)
EXTERNAL_SOLID_TEXT = re.compile(r"(?:solid|body)\b[^.;]{0,60}\bmesh(?:ed)? around|not (?:a|the) fluid (?:domain|body|volume)|"
                                 r"not_a_fluid_body|nothing (?:is|can be) carved", re.I)
#: The rule's own tolerance on the sign (R15 and _check_flow): axis times sign may miss the inlet-to-outlet chord by
#: half a bore before it counts as backwards (a tangential inlet beside axial outlets is noise inside that band).
DIRECTION_SIGN_TOL_OVER_D = 0.5
#: A written value equal to the recorded one rounded to this many significant figures is the recorded value (R16):
#: the packet writes four (tools.PACKET_SIG_FIGS) and a model copying a tool result keeps three or four.
CITED_SIG_FIGS = (3, 4)

# ---------------------------------------------------------------------------------------------------------------
# P4.3b repairs (dev plan P4.3; docs/plan_v3_rules.md, "P4.3b repairs"). The six-case live smoke of prompt v3 and
# schema 3 rejected five of its six plans for what the catalog, the packet or the checker itself had written. Each
# is repaired in _normalise (or, for the second look, inside R10) and logged in hints["warnings"] like R13 to R17:
# R18 a copied catalog risk that asks no decision, R19 a cautious second-look no where the checker finds yes,
# R20 the builder summary's unit opening, R21 a measured opening of the one external body, R22 a measured patch
# number the model retyped (in _fill_patch_numbers), R23 a single id field written as a list of ids. R24 is not a
# repair: the messages that stated a rule without naming the form it accepts now name it.
# ---------------------------------------------------------------------------------------------------------------
#: The derivation _normalise writes on a catalog risk that asks no user decision, so nothing downstream reads a
#: gap where the catalog wrote none. It opens with "catalog:" the way an R9 repair opens with "brief:", which is
#: how synthesise_warnings reads `settled_by`.
NON_DECISION_DERIVATION = "catalog: {kind} asks no user decision; carried as the catalog measured it"
#: The builder summary opens with the unit ("Unit: mm, declared by the file"). The unit word may be written long.
BUILDER_UNIT_OPENING = re.compile(r"^\s*unit\s*:\s*(?:assumed\s+)?(mm|millimet\w*|cm|centimet\w*|m|met(?:re|er)s?|"
                                  r"in|inch(?:es)?|ft|feet|foot)\b", re.I)
_UNIT_SYNONYM = {"millimetre": "mm", "millimetres": "mm", "millimeter": "mm", "millimeters": "mm", "centimetre": "cm",
                 "centimetres": "cm", "centimeter": "cm", "centimeters": "cm", "metre": "m", "metres": "m", "meter": "m",
                 "meters": "m", "inch": "in", "inches": "in", "feet": "ft", "foot": "ft"}
#: A single id field (a question's relates_to) written as a list of ids: every part is an id (R23).
_ONE_ID = re.compile(r"^(?:k\d+|o\d+|d\d+|unit|purpose|fidelity|identity)$", re.I)

# ---------------------------------------------------------------------------------------------------------------
# P4.3d repairs (dev plan P4.3; docs/plan_v3_rules.md, "P4.3d repairs"). The learning-half live run of the finished
# v3 agent (eval/recordings/live/learning_v3_r1) failed every failing case on "3 submissions rejected", and the
# census of those rejections is a list of rules that judged the model for writing what the checker itself could
# work out: R25 a mesh warning of the model's own kind (the closed vocabulary is the calibrated one, not the only
# thing a builder can be told), R26 a dismissal carried by a named fact instead of a ledger number, R27 the
# redundant question R9 can drop instead of rejecting, R28 a layer target on a port, R29 required_extents keyed
# above and below, R30 a refinement region no finer than the cell already there, R31 a measured opening with no
# patch, R32 the schema 3 tail a truncated submission lost, R33 a refuting test naming a tool as `tool.op`.
# ---------------------------------------------------------------------------------------------------------------
#: What an agent-detected mesh warning may not claim in `provenance`: it is not calibrated and there is no sweep
#: behind it (R25). `rule_class` becomes AGENT_RULE_CLASS; everything else the model wrote is kept.
CALIBRATION_CLAIM_KEYS = ("threshold", "threshold_key", "sweep", "corpus_version", "fires", "lift", "mcc_cv", "fitted_at")
AGENT_RULE_CLASS = "agent_derived"
#: The schema 3 fields a model writes that a cut-off submission loses silently: named in the same rejection as the
#: required fields, so a truncation costs one round and not two (R32).
V3_TAIL_FIELDS = (("identity_hypotheses", "two or three first-turn hypotheses, each {type, prior, refuting_test}"),
                  ("agent_risks_considered", "at least two {mechanism, measurement, why_not} when you add no risk of your own"),
                  ("second_look", "one line per item of section 6, filled last"))
#: A tool written as the tool plus its op ("derived_geometry.taper", "derived_geometry:first_cell",
#: "derived_geometry taper"), which is the tool this run has (R33). The learning-half run wrote the space as often
#: as the dot: 8 of 18 refuting tests and 12 of 15 tests_run entries, so the separator is any of the three.
_DOTTED_TOOL = re.compile(r"^([A-Za-z_][A-Za-z0-9_]*)[\s.:]+([A-Za-z_][A-Za-z0-9_]*)$")
#: The keys that name the vertical extent by its half (R29): the model that writes both has written `vertical`.
VERTICAL_EXTENT_WORDS = ("above", "below", "up", "down", "top", "bottom")

# ---------------------------------------------------------------------------------------------------------------
# P4.3e (dev plan P4.3; docs/plan_v3_rules.md section 14). Over the learning-half run's 161 submissions `risks`
# was 4,557 characters of a 14,674-character plan, and almost all of it was the model copying back the catalog
# entries the checker computes for itself: when the model left one out, the rejection handed the whole entry over
# to be copied VERBATIM, which is the proof the text was never the model's to write. R34: a catalog risk in a plan
# carries the id, the decision, the reason for overriding it and the question id; kind, severity, measurement,
# consequence, recommendation, requires_user_decision, mechanism, effect and target are filled from the catalog
# run, matched by id, and a full entry the model wrote anyway is overwritten by the catalog's own values with a
# logged note, exactly as a patch's measured numbers are (R22).
# ---------------------------------------------------------------------------------------------------------------
#: What the catalog owns on a risk it detected: filled here, and overwritten when the plan wrote them (R34).
CATALOG_OWNED_FIELDS = ("kind", "severity", "measurement", "consequence", "recommendation", "requires_user_decision",
                        "mechanism", "effect", "target")
#: What a plan writes on a catalog risk, and all it needs to write: the id names the entry, the decision is the
#: analyst's, the derivation is the reason for overriding the catalog, the question id is the link when the plan
#: wrote the question itself. `derived` and `refuted_by` are the analyst's too: R4 tells a model whose own risk
#: restates a catalog one to put the extra reasoning into the catalog entry rather than raise a second risk.
MODEL_OWNED_RISK_FIELDS = ("id", "user_decision", "derivation", "question_id", "derived", "refuted_by")
#: The short form the missing-risk rejection asks for, in the message and in `hints["missing_catalog_risks"]`.
SHORT_RISK_FORM = '{{"id": "{id}", "user_decision": "{decision}"}}'
#: What counts as "the plan did not write this field": absent, or the empty value of its type.
UNWRITTEN = (None, "", {}, [])

def _unit_word(text: str) -> str:
    w = text.strip().lower()
    return _UNIT_SYNONYM.get(w, w)


def _builder_prose(summary: str) -> str:
    """The prose BUILDER_PROSE_MAX_CHARS counts: what follows the opening unit sentence (the dev plan's "at most
    600 characters of prose after the unit"), so the opening R20 prepends never costs the model its budget."""
    m = BUILDER_UNIT_OPENING.match(summary)
    if m is None:
        return summary
    stop = summary.find(".", m.end())
    return summary[stop + 1:].lstrip() if stop >= 0 else summary[m.end():].lstrip()


#: Ids are split on commas, semicolons and spaces ("o1, o2", "o1 o2"); feature names (preserve_features) carry
#: spaces ("trailing edge") and are split on commas and semicolons only.
_ID_SEP = re.compile(r"[,;\s]+")
_NAME_SEP = re.compile(r"\s*[,;]\s*")


def _split_ids(value: str, sep: re.Pattern = _ID_SEP) -> list[str]:
    return [s for s in sep.split(value.strip()) if s]


def _as_id_list(node: dict[str, Any], key: str, pointer: str, notes: list[str], sep: re.Pattern = _ID_SEP) -> dict[str, Any]:
    """`node` with `node[key]` read as a list when the model wrote one string ("o3", or "o1, o2") or an explicit
    null (the P4.1 run's "patch_ids": null on every sphere and box, which the schema refused as not a list),
    logged; the node itself when there is nothing to repair. A copy, never an edit of the submitted plan."""
    if key not in node:
        return node
    v = node[key]
    if v is None:
        notes.append(f"R14 repair: {pointer} was null; read as the empty list []")
        return {**node, key: []}
    if not isinstance(v, str):
        return node
    ids = _split_ids(v, sep)
    notes.append(f"R14 repair: {pointer} was the string {v!r}; read as the list {ids}")
    return {**node, key: ids}


def _as_one_id(node: dict[str, Any], key: str, pointer: str, notes: list[str], rest_key: str | None = None) -> dict[str, Any]:
    """R23: `node[key]` is one id; a model that wrote the whole set there ("k3,k4,k5") meant the first, with the
    others in `rest_key`. Only a string every part of which is an id is read this way: a free-text value with a
    comma in it is left for the rule to report."""
    v = node.get(key)
    if not isinstance(v, str):
        return node
    ids = _split_ids(v)
    if len(ids) < 2 or not all(_ONE_ID.match(i) for i in ids):
        return node
    first, rest = ids[0], ids[1:]
    out = {**node, key: first}
    if rest_key is not None:
        have = [x for x in (node.get(rest_key) or []) if isinstance(x, str)]
        out[rest_key] = list(dict.fromkeys([*have, *rest]))
    notes.append(f"R23 repair: {pointer} was the string {v!r}; {key} names one id, so it is {first!r}"
                 + (f" and {rest} {'is' if len(rest) == 1 else 'are'} in {rest_key}" if rest_key else ""))
    return out


def _repair_id_lists(plan_obj: dict[str, Any], notes: list[str]) -> None:
    """R14: every list-typed id field a model writes as one string, or as null, becomes the list it names: a
    refinement region's patch_ids, preserve_features, flow.inlet_ids and outlet_ids, a question's also_settles,
    a simulation warning's also_settles, a mesh warning's location.patch_ids, the identity's refuted list. (A
    layer target names one patch, patch_id, and has no list-typed field.) The schema's own validators read a
    string the same way; the repair here also reads null and logs both, so the transcript shows what the model
    wrote. R23 (P4.3b): the one id field on a question, relates_to, written as the list of ids it settles is the
    first of them, the rest in also_settles."""
    flow = plan_obj.get("flow")
    if isinstance(flow, dict):
        for k in ("inlet_ids", "outlet_ids"):
            flow = _as_id_list(flow, k, f"/flow/{k}", notes)
        plan_obj["flow"] = flow
    mp = plan_obj.get("mesh_plan")
    if isinstance(mp, dict):
        mp = _as_id_list(mp, "preserve_features", "/mesh_plan/preserve_features", notes, _NAME_SEP)
        rrs = mp.get("refinement_regions")
        if isinstance(rrs, list):
            mp = {**mp, "refinement_regions": [
                _as_id_list(rr, "patch_ids", f"/mesh_plan/refinement_regions/{i}/patch_ids", notes) if isinstance(rr, dict) else rr
                for i, rr in enumerate(rrs)]}
        plan_obj["mesh_plan"] = mp
    qs = plan_obj.get("questions")
    if isinstance(qs, list):
        fixed = []
        for i, q in enumerate(qs):
            if isinstance(q, dict):
                q = _as_id_list(q, "also_settles", f"/questions/{i}/also_settles", notes)
                q = _as_one_id(q, "relates_to", f"/questions/{i}/relates_to", notes, "also_settles")
            fixed.append(q)
        plan_obj["questions"] = fixed
    sws = plan_obj.get("simulation_warnings")
    if isinstance(sws, list):
        plan_obj["simulation_warnings"] = [
            _as_id_list(w, "also_settles", f"/simulation_warnings/{i}/also_settles", notes) if isinstance(w, dict) else w
            for i, w in enumerate(sws)]
    mws = plan_obj.get("mesh_warnings")
    if isinstance(mws, list):
        fixed = []
        for i, w in enumerate(mws):
            if isinstance(w, dict) and isinstance(w.get("location"), dict):
                w = {**w, "location": _as_id_list(w["location"], "patch_ids", f"/mesh_warnings/{i}/location/patch_ids", notes)}
            fixed.append(w)
        plan_obj["mesh_warnings"] = fixed
    obj = plan_obj.get("object")
    if isinstance(obj, dict) and isinstance(obj.get("identity"), dict):
        plan_obj["object"] = {**obj, "identity": _as_id_list(obj["identity"], "refuted", "/object/identity/refuted", notes)}


def _external_solid_justification(r: dict[str, Any]) -> bool:
    """An agent risk that carries nothing but the statement that the external body is the solid: no derived
    value, no opening named, and a kind or a consequence saying so."""
    if r.get("detected_by", "catalog") != "agent" or r.get("derived") or _ids_in(r.get("measurement") or {}):
        return False
    text = " ".join(str(r.get(k) or "") for k in ("consequence", "recommendation"))
    return bool(EXTERNAL_SOLID_KIND.search(str(r.get("kind") or "")) or EXTERNAL_SOLID_TEXT.search(text))


def _repair_external_solid(plan_obj: dict[str, Any], ctx: ToolContext, mp: dict[str, Any], patches: list,
                           risks: list[dict[str, Any]], questions: list[dict[str, Any]], notes: list[str]) -> None:
    """R13: under an external purpose, with exactly one watertight body and no inlet or outlet role, a region
    role of not_a_fluid_body (or wall_shell) is obstacle, the role the catalog gives every external body; an
    agent risk whose only content is that justification is dropped, with its question. The P4.1 live run
    labelled 33 external bodies not_a_fluid_body and no rule could accept the plan: the wall-file risk fires
    only on internal wall shells."""
    facts = ctx.facts
    if ctx.purpose not in EXTERNAL_PURPOSES or len(facts.regions) != 1 or not facts.regions[0].watertight:
        return
    roles = {p.get("role") for p in patches if isinstance(p, dict)}
    flow = plan_obj.get("flow") if isinstance(plan_obj.get("flow"), dict) else {}
    if roles & {"inlet", "outlet"} or flow.get("inlet_ids") or flow.get("outlet_ids"):
        return
    regions = mp.get("regions") if isinstance(mp.get("regions"), list) else []
    fixed = []
    for i, r in enumerate(regions):
        if isinstance(r, dict) and r.get("role") in EXTERNAL_SOLID_MISROLES:
            notes.append(f"R13 repair: /mesh_plan/regions/{i} ({r.get('id')}) role {r.get('role')!r} -> 'obstacle': under an external "
                         "purpose the one watertight body with no ports is the solid the far-field flow goes around")
            r = {**r, "role": "obstacle"}
        fixed.append(r)
    if regions:
        mp["regions"] = fixed
    dropped: set = set()
    kept = []
    for i, r in enumerate(risks):
        if _external_solid_justification(r):
            dropped.add(r.get("id"))
            notes.append(f"R13 repair: agent risk /risks/{i} ({r.get('id')}, {r.get('kind')}) dropped: its only content is that the "
                         "external body is the solid, which the obstacle role already states")
            continue
        kept.append(r)
    if not dropped:
        return
    risks[:] = kept
    left = []
    for q in questions:
        if q.get("relates_to") in dropped:
            notes.append(f"R13 repair: question {q.get('id')} dropped with the risk it asked about")
            continue
        also = [x for x in (q.get("also_settles") or []) if x not in dropped]
        if len(also) != len(q.get("also_settles") or []):
            q = {**q, "also_settles": also}
        left.append(q)
    questions[:] = left


def _repair_identity_confidence(plan_obj: dict[str, Any], ctx: ToolContext, notes: list[str]) -> None:
    """Lower an identity resting on the picture alone to the cap, instead of refusing the plan.

    ENFORCING A CAP MEANS WRITING THE CAP. The rule is that a name taken only from the look cannot
    carry more than `VISION_ONLY_CONFIDENCE_MAX`, because the reader's identity claims did not earn
    more over the corpus. Refusing the whole submission over it enforces nothing extra and throws
    away the flow, the patches, the risks and the mesh plan with it.

    Measured: on a part whose owner never said what it was, the model wrote 0.85, was refused three
    times, tried 0.70, was refused again, and the job was built with NO PLAN AT ALL - every other
    field of which was fine. The cap was upheld and the customer got less mesh for it.

    So the number is clamped here, with the reason in the notes and the way it could have been earned, and
    the checks below then pass on a plan that says exactly what the evidence supports.

    THREE THINGS STOP IT, and all three mean the plan named something that is not the picture:
    `_identity_support` reads the evidence strings (the customer's own words, a measurement, a declared
    fact - the usual answer and the commonest kind there is), `_cites_a_test` reads the citations, and
    `_looked` asks whether this run has an impression to lean on at all.

    A CITATION BUYS THE NUMBER BACK AND THEN HAS TO STAND UP TO R2. Where the cited reading is not a
    ledger number, R2 below refuses and the model gets a round to fix it, where clamping would have kept
    the plan silently. That is deliberate: a plan citing a measurement it did not take is not a confidence
    set too high, it is a fact that lies, and this repair exists to stop a NUMBER being refused over the
    cap, not to launder a claim.
    """
    obj = plan_obj.get("object")
    if not isinstance(obj, dict):
        return
    conf = obj.get("confidence")
    if not isinstance(conf, (int, float)) or isinstance(conf, bool):
        return
    if float(conf) <= VISION_ONLY_CONFIDENCE_MAX or _identity_support(obj) or _cites_a_test(obj):
        return
    if not _looked(ctx):
        # ONLY WHERE THE CAP HAS SOMETHING TO SAY. `_looked`'s own words: "with no look the cap has nothing
        # to say, and the existing R2 gates are the whole of the identity rule". Clamping regardless did two
        # wrong things at once. It wrote a note saying the only support named was the look on a run that never
        # looked, which is a fact that lies. And it lowered the number under 0.8 before R2 could ask for the
        # tests_run entry, so R2's refusal became unreachable on every run with no look and no named support:
        # a check disabled by a repair meant for a different rule, and the test that said so went red and was
        # read as stale. The error this repair replaces is gated on `_looked` too (R38), so ungated it was
        # also wider than the rule it exists to enforce.
        return
    obj["confidence"] = VISION_ONLY_CONFIDENCE_MAX
    ident = obj.get("identity")
    if isinstance(ident, dict) and isinstance(ident.get("confidence"), (int, float)):
        # the two must agree, and a later check says so
        ident["confidence"] = VISION_ONLY_CONFIDENCE_MAX
    # AND THE NOTE SAYS HOW IT COULD HAVE BEEN EARNED. R38's rejection used to name the refuting test to
    # call; clamping instead of refusing kept the plan and dropped that sentence on the floor, and the run
    # is accepted so there is no later turn to say it in. Carrying it here costs nothing and is the only
    # record of what this identity was short of.
    notes.append(f"object.confidence lowered to {VISION_ONLY_CONFIDENCE_MAX:g}: the only support named for "
                 f"{obj.get('type')!r} is the look, which does not carry more on its own. "
                 + _lift_words(plan_obj))


def _lift_words(plan_obj: dict[str, Any]) -> str:
    """What would have carried this identity past the cap, read off the plan's own hypotheses.

    The same sentence R38's rejection built, from the dict rather than the parsed plan, because the repair runs
    before parsing. Naming the CUSTOMER'S OWN WORDS first is deliberate and it is the usual answer: a brief that
    says what the part is costs nothing and is not a guess from a picture.
    """
    obj = plan_obj.get("object") or {}
    type_name = str(obj.get("type") or "")
    for h in (plan_obj.get("identity_hypotheses") or []):
        if not isinstance(h, dict) or str(h.get("type") or "").strip().lower() != type_name.strip().lower():
            continue
        rt = h.get("refuting_test")
        if not isinstance(rt, dict) or not str(rt.get("tool") or "").strip():
            continue
        args = ", ".join(f"{k}={v}" for k, v in (rt.get("args") or {}).items()
                         if not isinstance(v, (dict, list)))
        would = str(rt.get("would_refute_if") or "").strip() or "its reading says so"
        return (f"to carry more, name other support in object.evidence (the customer's own words about what the "
                f"part is, a measurement, or a declared fact), or call {rt.get('tool')}({args}), which would "
                f"refute {type_name!r} if {would}, and write its reading into object.identity.tests_run")
    return ("to carry more, name other support in object.evidence (the customer's own words about what the part "
            "is, a measurement, or a declared fact), or list the chosen type in identity_hypotheses with a "
            "refuting test, call it, and write its reading into object.identity.tests_run")


def _cites_a_test(obj: dict[str, Any]) -> bool:
    """Whether the plan cites a reading of its own, which is support the repair has to see.

    `_identity_support` reads the evidence STRINGS only, and it must: `contract.given.check_plan` accepts the
    same words, and the agent's repair and the platform's veto disagreeing about what counts is a plan the agent
    passes and the platform throws away. The citation is the other half. The checker has always counted it - R38
    read "vision-only" as naming the picture and naming no cited test - and the repair did not, so a confidence a
    real probe_section reading had earned was still lowered to the cap.

    The number is not verified here. R2 below still demands that a cited reading be a ledger number, and it can
    only do that on the confidence as the model wrote it, so a citation buys the plan its own number back and then
    has to stand up to the rule that asks whether the reading is real.
    """
    ident = obj.get("identity")
    tests = ident.get("tests_run") if isinstance(ident, dict) else None
    for t in tests or []:
        if not isinstance(t, dict):
            continue
        if str(t.get("tool") or "").strip() in ("", LOOK_TOOL):
            continue
        if isinstance(t.get("result_number"), (int, float)) and not isinstance(t.get("result_number"), bool):
            return True
    return False


def _identity_support(obj: dict[str, Any]) -> bool:
    """Whether the plan names support for the identity other than the picture.

    The same words `contract.given.check_plan` accepts, so the agent's own repair and the platform's
    veto cannot disagree about what counts - a customer naming their part is support, and it is the
    commonest kind there is.
    """
    evidence = " ".join(str(e) for e in (obj.get("evidence") or [])).lower()
    return any(w in evidence for w in ("measur", "opening", "facts.", "declared", "confirmed", "brief",
                                       "customer", "user said", "they said"))


def _repair_direction_sign(plan_obj: dict[str, Any], ctx: ToolContext, notes: list[str]) -> None:
    """R15: axis times direction_sign points from the inlets to the outlets; when it points the other way by
    more than DIRECTION_SIGN_TOL_OVER_D bores (the rule's own reading) and both sides have measured centroids,
    the sign is flipped and logged. The rule in _check_flow then fires only when the repair could not read the
    plan. Runs after the flow-axis snap, which may itself have folded a flip into the sign."""
    flow = plan_obj.get("flow")
    if not isinstance(flow, dict) or flow.get("direction_sign") not in (1, -1):
        return
    axis = flow.get("axis")
    if not isinstance(axis, (list, tuple)) or len(axis) != 3:
        return
    try:
        ax = [float(c) for c in axis]
    except (TypeError, ValueError):
        return
    known = {o.id: o for o in ctx.facts.openings}
    inlet_ids = [i for i in (flow.get("inlet_ids") or []) if isinstance(i, str) and i in known]
    outlet_ids = [i for i in (flow.get("outlet_ids") or []) if isinstance(i, str) and i in known]
    if not inlet_ids or not outlet_ids:
        return
    ins = [known[i].centroid for i in inlet_ids]
    outs = [known[i].centroid for i in outlet_ids]
    d = [sum(o[k] for o in outs) / len(outs) - sum(i[k] for i in ins) / len(ins) for k in range(3)]
    sign = int(flow["direction_sign"])
    along = sign * sum(d[k] * ax[k] for k in range(3))
    scale = max(known[i].hydraulic_diameter for i in inlet_ids + outlet_ids)
    if scale <= 0 or along >= -DIRECTION_SIGN_TOL_OVER_D * scale:
        return
    plan_obj["flow"] = {**flow, "direction_sign": -sign}
    notes.append(f"R15 repair: flow.direction_sign {sign} -> {-sign}: axis {[round(c, 4) for c in ax]} times {sign} pointed from the "
                 f"outlets {outlet_ids} toward the inlets {inlet_ids} by {-along / scale:.3g} bores")


def _same_catalog_field(got: Any, want: Any) -> bool:
    """Whether what the plan wrote for a catalog-owned field is the catalog's own value: numbers within REL_TOL,
    containers component by component, everything else by equality. Only the note reads this; the value written
    is the catalog's either way."""
    if isinstance(want, bool) or isinstance(got, bool):
        return got is want
    if isinstance(want, (int, float)) and isinstance(got, (int, float)):
        return _close(float(got), float(want))
    if isinstance(want, dict):
        return isinstance(got, dict) and set(got) == set(want) and all(_same_catalog_field(got[k], want[k]) for k in want)
    if isinstance(want, (list, tuple)):
        return (isinstance(got, (list, tuple)) and len(got) == len(want)
                and all(_same_catalog_field(a, b) for a, b in zip(got, want)))
    return got == want


def _catalog_entry(e: Risk) -> dict[str, Any]:
    """A catalog risk as a plan carries it: through JSON, so a measurement's tuple is the list a submitted plan
    would have written and the plan round-trips through JSON unchanged (tests/test_e2e.py)."""
    return json.loads(e.model_dump_json())


def _bind_catalog_risks(risks: list[dict[str, Any]], expected: list[Risk]) -> tuple[list[tuple[dict, Risk]], list[dict], set[str]]:
    """Every plan risk that claims the catalog, paired with the catalog entry it is: by (kind, subject) first, so a
    plan that writes the full entry binds exactly as it did before R34, then by id for an entry that wrote no kind,
    which is the short form and has nothing else to go on.

    Only the short form binds by id. A full entry that fails the key match is stale (it names a kind or a subject
    the catalog no longer raises) and its id may now belong to a different risk entirely: the catalog numbers k1
    upward in detection order, so a threshold move renumbers everything after the first rule that changed. Binding
    it by id would quietly turn one risk into another and hide the one that is really missing.

    Returns the pairs, the entries that bind to nothing, and the ids of the catalog risks now claimed."""
    by_key: dict[tuple, Risk] = {}
    for e in expected:
        by_key.setdefault(_risk_key(e), e)
    by_id = {e.id: e for e in expected}
    mine = [r for r in risks if r.get("detected_by", "catalog") == "catalog"]
    pairs: list[tuple[dict, Risk]] = []
    taken: set[str] = set()
    rest: list[dict] = []
    for r in mine:
        e = by_key.get(_risk_key(r)) if str(r.get("kind") or "") else None
        if e is not None and e.id not in taken:
            pairs.append((r, e))
            taken.add(e.id)
        else:
            rest.append(r)
    unbound: list[dict] = []
    for r in rest:
        e = None if str(r.get("kind") or "").strip() else by_id.get(str(r.get("id") or ""))
        if e is not None and e.id not in taken:
            pairs.append((r, e))
            taken.add(e.id)
        else:
            unbound.append(r)
    return pairs, unbound, taken


def _fill_catalog_risks(plan_obj: dict[str, Any], ctx: ToolContext, risks: list[dict[str, Any]],
                        notes: list[str], expected: list[Risk] | None = None) -> None:
    """R34: a catalog risk is written as its id and the analyst's decision; everything the catalog measured is
    filled here from the catalog run under the plan's own roles.

    Three things happen. A short entry receives the catalog's fields. A full entry the model wrote anyway keeps
    its id, decision, derivation and question id and has the rest overwritten by the catalog's values, logged:
    the plan is not a place to restate what code knows, and a measurement the model retyped was never its own
    (R22 does the same for a patch). A catalog risk that asks no user decision and is missing from the plan is
    added here rather than rejected, so the model never writes it at all; what is left for `_check_risks` to
    reject is a decision the plan has not answered, and an id the catalog did not produce."""
    expected = _expected_risks(plan_obj, ctx) if expected is None else expected
    if not expected:
        return
    pairs, _unbound, taken = _bind_catalog_risks(risks, expected)
    filled: list[str] = []
    overwritten: list[str] = []
    for r, e in pairs:
        entry = _catalog_entry(e)
        wrote = [k for k in CATALOG_OWNED_FIELDS if r.get(k) not in UNWRITTEN]
        changed: list[str] = []
        for k in CATALOG_OWNED_FIELDS:
            got = r.get(k)
            if got not in UNWRITTEN and not _same_catalog_field(got, entry.get(k)):
                changed.append(k)
            r[k] = entry.get(k)
        if not str(r.get("derivation") or "").strip() and str(entry.get("derivation") or "").strip():
            r["derivation"] = entry["derivation"]
        if not wrote:
            filled.append(str(r.get("id")))
        elif changed:
            overwritten.append(f"{r.get('id')} ({', '.join(changed)})")
    used = {str(r.get("id")) for r in risks if r.get("id")}
    added: list[str] = []
    for e in expected:
        # R36's risk asks a decision and is still added: `list_risks` ran before the plan existed, so the model
        # could not have been told about a budget the plan itself creates, and owing it would cost a round for
        # arithmetic the checker does. Every other decision the plan owes is still the plan's to write
        if e.id in taken or e.kind in catalog.NEW_BUILDER_KINDS:
            continue
        if e.requires_user_decision and not e.derivation.startswith(R36_DERIVATION):
            continue
        entry = _catalog_entry(e)
        if entry["id"] in used:
            n = 1
            while f"k{n}" in used:
                n += 1
            entry["id"] = f"k{n}"
        used.add(entry["id"])
        risks.append(entry)
        added.append(f"{entry['id']} ({e.kind})")
    if filled:
        notes.append(f"R34 repair: catalog risks {', '.join(filled)} were written as the id and the decision; kind, severity, "
                     "measurement, consequence, recommendation and the rest filled from the catalog run under this plan's roles")
    if overwritten:
        notes.append(f"R34 repair: catalog risks {', '.join(overwritten)} carried values that are not the catalog's; the catalog's "
                     "own values are used (the checker fills every catalog field, so none is retyped)")
    if added:
        notes.append(f"R34 repair: catalog risks {', '.join(added)} ask no user decision and were missing; added from the catalog "
                     "(a risk nobody has to decide is the catalog's to carry, not the model's to copy)")


def fill_catalog_risks(plan_obj: dict[str, Any], ctx: ToolContext, risks: list[dict[str, Any]],
                       notes: list[str] | None = None, expected: list[Risk] | None = None) -> None:
    """R34's fill, for a caller outside the checker: the risks are filled in place from the catalog run under the
    plan's own roles. `hexera.catalog_filled` uses it so a plan that reaches the handover without passing through
    the checker still says what kind each catalog risk is and which decisions are pending, and so that there is
    one copy of R34 and not a second one in the handover (docs/plan_v3_rules.md 15.2)."""
    _fill_catalog_risks(plan_obj, ctx, risks, [] if notes is None else notes, expected)


def _link_named_questions(questions: list[dict[str, Any]], risks: list[dict[str, Any]], notes: list[str]) -> None:
    """R34: a risk may name the question that settles it (`question_id`) instead of the question naming the risk.
    The link is written back onto the question's `also_settles`, because that is the one the confirm step, the
    simulation warnings and every rule already read: the model may write it either way round and nothing
    downstream has to learn a second form."""
    by_id = {q.get("id"): q for q in questions}
    linked: list[str] = []
    for r in risks:
        q = by_id.get(r.get("question_id"))
        rid = r.get("id")
        if q is None or not rid or q.get("relates_to") == rid or rid in (q.get("also_settles") or []):
            continue
        q["also_settles"] = list(q.get("also_settles") or []) + [rid]
        linked.append(f"{rid} -> {q.get('id')}")
    if linked:
        notes.append(f"R34 repair: risks naming their own question ({', '.join(linked)}) are listed in that question's "
                     "also_settles, which is the link the confirm step and the warnings read")


def _settle_non_decision_risks(risks: list[dict[str, Any]], notes: list[str]) -> None:
    """R18: a catalog risk whose `requires_user_decision` is false carries no decision to override. The packet and
    the prompt both say a catalog entry goes into the plan unchanged, so the model copies it forward with the
    catalog's own empty `derivation` (and, reading it correctly, `user_decision` continue) - and the override rule
    then rejected it in five of the six smoke cases. The rule now applies only where the catalog does ask a
    decision (`_check_risks`); here the decision and the catalog's own reason are filled so nothing downstream
    reads a gap where the catalog wrote none."""
    filled: list[str] = []
    for r in risks:
        if r.get("detected_by", "catalog") != "catalog" or r.get("requires_user_decision"):
            continue
        changed = False
        if r.get("user_decision", "pending") == "pending":
            r["user_decision"] = "continue"
            changed = True
        if len(str(r.get("derivation") or "").strip()) < 10:
            r["derivation"] = NON_DECISION_DERIVATION.format(kind=r.get("kind"))
            changed = True
        if changed:
            filled.append(str(r.get("id")))
    if filled:
        notes.append(f"R18 repair: catalog risks {', '.join(filled)} ask no user decision; user_decision 'continue' and the "
                     "catalog's own reason filled in (a catalog entry copied unchanged is never rejected for what the catalog wrote)")


def _repair_builder_unit_line(plan_obj: dict[str, Any], ctx: ToolContext, notes: list[str]) -> None:
    """R20: `summary_for_builder` opens with the unit. Prompt v3 lost the sentence that said so when it was cut to
    9,000 characters, and four of the six smoke plans were rejected for the missing opening. The exact opening the
    rule asks for is prepended when it is absent; the rule in `_check_unit` then fires only when the prose opens
    with a unit that contradicts the plan's own (the 600-character prose cap counts what follows the opening)."""
    sb = plan_obj.get("summary_for_builder")
    if not isinstance(sb, str) or not sb.strip():
        return
    unit = plan_obj.get("unit")
    assumed = unit.get("assumed") if isinstance(unit, dict) else None
    if not isinstance(assumed, str) or assumed not in UNIT_WORDS:
        return
    head = BUILDER_UNIT_OPENING.match(sb)
    if head is not None:
        return  # the plan wrote its own opening: the rule reads it and reports a contradiction
    declared = ctx.facts.units.declared
    opening = f"Unit: {assumed}, declared by the file. " if declared else f"Unit: assumed {assumed}, unconfirmed. "
    plan_obj["summary_for_builder"] = opening + sb.strip()
    notes.append(f"R20 repair: summary_for_builder did not open with the unit; {opening.strip()!r} prepended, the prose unchanged "
                 "(the prose cap counts what follows the opening)")


def _repair_external_openings(ctx: ToolContext, patches: list, notes: list[str]) -> None:
    """R21: under an external purpose on one body, every face of that body is a wall - the far-field flow goes
    around it, and a port on it is named by the brief or by a declared port. The smoke run's ahmed_variant_001
    spent its whole budget on four rim faces of the single solid it had left out of `patches`, so the checker
    gives each the wall patch instead of asking for it. A model that named a port keeps it: only openings with
    no patch at all are filled."""
    if ctx.purpose not in EXTERNAL_PURPOSES or len(ctx.facts.regions) != 1:
        return
    declared_ids: set[str] = set()
    if ctx.declared:
        rep = catalog.representation(ctx.facts, ctx.purpose, ctx.brief, declared=ctx.declared,
                                     fluid_side=ctx.fluid_side)
        declared_ids = set(catalog.declared_pairs(ctx.facts, catalog.port_openings(ctx.facts, rep, ctx.declared), ctx.declared, rep))
    have = {p.get("id") for p in patches if isinstance(p, dict)}
    added: list[str] = []
    for o in ctx.facts.openings:
        if o.id in have or o.id in declared_ids:
            continue
        where = f"on the {o.bbox_side} side of the bounding box" if o.bbox_side else "inside the body"
        patches.append({"id": o.id, "name": o.id, "role": "wall", "confidence": 1.0,
                        "evidence": [f"a {o.classification} face of the one external body, {where}; the far-field flow goes "
                                     "around the body, so every face of it is a wall (added by the checker)"]})
        added.append(o.id)
    if added:
        notes.append(f"R21 repair: {', '.join(added)} had no patch; each is a face of the one body an external case meshes "
                     "around, so each takes role wall (a port on an external body is named by the brief or a declared port)")


def _repair_measured_openings(plan_obj: dict[str, Any], ctx: ToolContext, patches: list, notes: list[str]) -> None:
    """R31: a measured opening the plan left out takes the wall patch, whatever the purpose, when the catalog says
    it cannot be a port under this representation (`catalog.port_openings`: a planar face or a seam on a fluid
    body, a ring on a fluid body, a face of an external solid). The static mixer's eighteen blade faces cost the
    learning-half run a round each for a role the prompt already states ("rings and holes are walls unless the
    catalog says wall shell or annular passage"). An opening the catalog does call a port candidate is left to the
    rule: that role is a decision, and R1's message names it. An external case is R21's, which reads the one body
    it meshes around and leaves the two-body case asking, as P4.3b decided."""
    facts = ctx.facts
    if ctx.purpose in EXTERNAL_PURPOSES:
        return
    rep = catalog.representation(facts, ctx.purpose, ctx.brief, declared=ctx.declared, fluid_side=ctx.fluid_side)
    ports = {o.id for o in catalog.port_openings(facts, rep, ctx.declared)}
    flow = plan_obj.get("flow") if isinstance(plan_obj.get("flow"), dict) else {}
    posed = {i for k in ("inlet_ids", "outlet_ids") for i in (flow.get(k) or []) if isinstance(i, str)}
    have = {p.get("id") for p in patches if isinstance(p, dict)}
    added: list[str] = []
    for o in facts.openings:
        if o.id in have or o.id in ports or o.id in posed:
            continue
        where = f"on the {o.bbox_side} side of the bounding box" if o.bbox_side else f"inside region {o.region_id}"
        patches.append({"id": o.id, "name": o.id, "role": "wall", "confidence": 1.0,
                        "evidence": [f"a {o.classification} {o.kind} face {where}; under representation {rep} the catalog does not "
                                     "count it as a port candidate, so it is wall (added by the checker)"]})
        added.append(o.id)
    if added:
        notes.append(f"R31 repair: {', '.join(added)} had no patch; none of them can carry a port role under representation "
                     f"{rep}, so each takes role wall (a port candidate the plan leaves out is still a rejection)")


def _wall_patch_for(patches: list) -> str | None:
    """The patch a layer target belongs on: the synthetic walls patch when the plan has one, else the first patch
    with role wall that is not a measured opening (the model's own name for the wall), else any wall patch."""
    walls = [p for p in patches if isinstance(p, dict) and p.get("role") == "wall"]
    for p in walls:
        if p.get("id") in SYNTHETIC_PATCHES:
            return str(p["id"])
    for p in walls:
        if not OPENING_ID.fullmatch(str(p.get("id") or "")):
            return str(p["id"])
    return str(walls[0]["id"]) if walls else None


def _repair_layer_targets(mp: dict[str, Any], patches: list, notes: list[str]) -> None:
    """R28: a layer target on a port (inlet, outlet, farfield, symmetry) names the wall patch instead. Layers grow
    from walls only, which is the rule the message already stated; which patch it means is not in doubt, because a
    plan has one wall patch. When the wall patch already carries a layer target the port's line is dropped (two
    targets on one patch are one target), and when the plan has no wall patch at all the synthetic `walls` patch is
    added the way a layer target naming `walls` already adds it."""
    targets = mp.get("layer_targets")
    if not isinstance(targets, list) or not targets:
        return
    role_of = {p.get("id"): p.get("role") for p in patches if isinstance(p, dict)}
    if not any(isinstance(lt, dict) and role_of.get(lt.get("patch_id")) in NO_LAYER_ROLES
               and (lt.get("n_layers") or 0) > 0 for lt in targets):
        return
    wall = _wall_patch_for(patches)
    if wall is None:
        wall = "walls"
        patches.append({"id": wall, "name": wall, "role": "wall", "confidence": 1.0,
                        "evidence": ["every surface that is not a declared port (added by the checker: layers grow from walls only)"]})
    out: list[Any] = []
    moved: list[str] = []
    dropped: list[str] = []
    for lt in targets:
        if not isinstance(lt, dict) or role_of.get(lt.get("patch_id")) not in NO_LAYER_ROLES or (lt.get("n_layers") or 0) <= 0:
            out.append(lt)
            continue
        port = str(lt.get("patch_id"))
        if any(isinstance(x, dict) and x.get("patch_id") == wall and (x.get("n_layers") or 0) > 0 for x in out + targets
               if x is not lt):
            dropped.append(port)
            continue
        out.append({**lt, "patch_id": wall})
        moved.append(port)
    mp["layer_targets"] = out
    if moved:
        notes.append(f"R28 repair: layer target{'s' if len(moved) > 1 else ''} on {', '.join(moved)} moved to the wall patch "
                     f"{wall!r}: layers grow from walls only, and the first cell and reason are kept as written")
    if dropped:
        notes.append(f"R28 repair: the layer target{'s' if len(dropped) > 1 else ''} on {', '.join(dropped)} dropped: the wall patch "
                     f"{wall!r} already carries one, and one layer spec per wall is what the builder takes")


def _repair_required_extents(plan_obj: dict[str, Any], ctx: ToolContext, mp: dict[str, Any], notes: list[str]) -> None:
    """R29: external flow uses exactly the four keys of EXTENT_KEYS. A model that writes `above` and `below` has
    said what `vertical` is (the larger of the two), and one that writes only three has left the fourth to the
    standard multiple of the body length; both are computable, so neither costs a round. Every value the model
    wrote under a standard key is kept: the brief's own box (8 L downstream, not the catalog's 15) is the user's."""
    if ctx.purpose not in EXTERNAL_PURPOSES:
        return
    ext = mp.get("required_extents")
    if not isinstance(ext, dict) or not ext:
        return
    T = current_thresholds()
    nums = {k: float(v) for k, v in ext.items() if isinstance(v, (int, float)) and not isinstance(v, bool)}
    # every key that names the vertical extent by its half; a key that names something else entirely is left for
    # the rule to report, because a value the checker cannot place is not a value it may drop
    said_vertical = [k for k in VERTICAL_EXTENT_WORDS if k in nums]
    out = {k: v for k, v in ext.items() if k not in said_vertical}
    from_words: list[str] = []
    if "vertical" not in out:
        if said_vertical:
            vertical = max(nums[k] for k in said_vertical)
            from_words.append(f"vertical {vertical:.6g} (the larger of {', '.join(said_vertical)})")
        elif isinstance(nums.get("lateral"), float):
            vertical = nums["lateral"]
            from_words.append(f"vertical {vertical:.6g} (the lateral extent: the same multiple of the body length)")
        else:
            vertical = T.EXTERNAL_LATERAL_OVER_L * max(ctx.facts.bbox.extent)
            from_words.append(f"vertical {vertical:.6g} ({T.EXTERNAL_LATERAL_OVER_L:g} L, the standard multiple)")
        out["vertical"] = vertical
    if out == ext:
        return
    mp["required_extents"] = out
    note = f"R29 repair: required_extents keyed {sorted(ext)} read as {sorted(out)}"
    if from_words:
        note += "; " + "; ".join(from_words)
    if said_vertical:
        note += f"; {', '.join(said_vertical)} is the vertical extent by another name"
    notes.append(note)


def _repair_refinement_sizes(plan_obj: dict[str, Any], ctx: ToolContext, mp: dict[str, Any], notes: list[str]) -> None:
    """R30: a refinement region coarser than the cell the tier (or the builder) already puts there refines nothing.
    That is a real fault, and the value it should carry is computable: one level finer than the limit it broke, and
    finer again until it is under every limit that applies. The region is clamped and logged rather than rejected,
    because the model chose the place (which is the judgement) and got the arithmetic of the tier wrong (which is
    not). A clamped size that is not derivable from a measurement is left as written for the rule to reject."""
    regions = mp.get("refinement_regions")
    if not isinstance(regions, list) or not regions:
        return
    facts, ledger = ctx.facts, ctx.ledger.numbers
    est = next((e for e in facts.cell_estimates if e.tier == mp.get("fidelity")), None)
    if est is None:
        return
    hs = est.surface_cell or catalog._surface_cell(facts, mp.get("fidelity"))
    rep = catalog.representation(facts, ctx.purpose, ctx.brief, declared=ctx.declared, fluid_side=ctx.fluid_side)
    frame = _builder_frame_for(plan_obj, ctx, rep)
    wall_cell = float(frame.get("wall_cell") or 0.0)
    clamped: list[str] = []
    for rr in regions:
        if not isinstance(rr, dict):
            continue
        size = rr.get("target_size")
        if not isinstance(size, (int, float)) or isinstance(size, bool) or size <= 0:
            continue
        if not _derivable(float(size), ledger):
            # the repair corrects the tier arithmetic, never the provenance: a size that came from nowhere keeps
            # its own rejection ("not derivable from a measurement"), which is the rule the clamp must not dodge
            continue
        limits = [("the base cell", float(est.base_size))]
        if rr.get("kind") in ("surface", "feature_edges") and hs:
            limits.append(("the surface cell the tier already puts there", float(hs)))
        if rr.get("kind") == "sphere" and wall_cell > 0 and ctx.purpose in INTERNAL:
            limits.append(("the builder's wall cell", wall_cell * (1.0 + REL_TOL)))
        broke = [(why, lim) for why, lim in limits if float(size) >= lim * (1 - REL_TOL)]
        if not broke:
            continue
        cap = min(lim for _why, lim in limits) * (1 - REL_TOL)
        # the coarsest value that is under every limit and still derivable from a measurement: one of the limits
        # (or the model's own size) halved, which keeps the cell count as low as the rules allow
        value = None
        for seed in (float(size), *[lim for _why, lim in limits]):
            v = seed
            for _ in range(12):
                v /= 2.0
                if v < cap:
                    if _derivable(v, ledger) and (value is None or v > value):
                        value = v
                    break
        if value is None:
            continue
        rr["target_size"] = value
        clamped.append(f"{rr.get('where')!r} {float(size):.6g} -> {value:.6g} (coarser than {broke[0][0]} {broke[0][1]:.6g})")
    if clamped:
        notes.append("R30 repair: " + "; ".join(clamped) + "; a region is written one level finer than the cell already "
                     "there, and the place you chose is kept")


def _split_tool_and_op(tool: Any, names: set[str]) -> tuple[str, str] | None:
    """`derived_geometry.taper`, `derived_geometry:taper` or `derived_geometry taper` as (tool, op), when the first
    half is a tool of this run. The run wrote all three separators and the space as often as the dot, so the
    reading is the separator's, not the dot's."""
    if not isinstance(tool, str) or tool.strip() in names:
        return None
    m = _DOTTED_TOOL.match(tool.strip())
    return (m.group(1), m.group(2)) if m is not None and m.group(1) in names else None


def _repair_refuting_tools(plan_obj: dict[str, Any], notes: list[str]) -> None:
    """R33: a refuting test naming `derived_geometry.taper` (or `derived_geometry taper`) names the tool this run
    has and the op it would call. The tool is the first half, which is what R2 reads; the op stays in the args.

    `object.identity.tests_run` is read the same way, and has to be: R2 matches the chosen type's refuting test
    against the tests actually run by tool name, so repairing one side and not the other turns a plan whose two
    halves agreed into a plan whose confidence is unsupported. The run wrote 15 tests_run entries that way."""
    names = _tool_names()
    hyps = plan_obj.get("identity_hypotheses")
    for i, h in enumerate(hyps if isinstance(hyps, list) else []):
        if not isinstance(h, dict) or not isinstance(h.get("refuting_test"), dict):
            continue
        rt = h["refuting_test"]
        split = _split_tool_and_op(rt.get("tool"), names)
        if split is None:
            continue
        tool, op = split
        args = rt.get("args") if isinstance(rt.get("args"), dict) else {}
        hyps[i] = {**h, "refuting_test": {**rt, "tool": tool, "args": {"op": op, **args}}}
        notes.append(f"R33 repair: /identity_hypotheses/{i}/refuting_test/tool was {rt.get('tool')!r}; the tool is {tool!r} and "
                     f"{op!r} is its op, which is now in args")
    obj = plan_obj.get("object")
    ident = obj.get("identity") if isinstance(obj, dict) and isinstance(obj.get("identity"), dict) else None
    tests = ident.get("tests_run") if ident is not None and isinstance(ident.get("tests_run"), list) else []
    for i, t in enumerate(tests):
        if not isinstance(t, dict):
            continue
        split = _split_tool_and_op(t.get("tool"), names)
        if split is None:
            continue
        tool, op = split
        notes.append(f"R33 repair: /object/identity/tests_run/{i}/tool was {t.get('tool')!r}; the tool is {tool!r} and {op!r} is "
                     "the op it called (an entry carries no args, so the op is dropped here and the ledger number stands)")
        tests[i] = {**t, "tool": tool}


def _fill_identity_tests(plan_obj: dict[str, Any], ctx: ToolContext, notes: list[str]) -> None:
    """R2 (P4.3e, docs/plan_v3_rules.md section 14): the reading of a refuting test the run actually made,
    written into `object.identity.tests_run` from the ledger's call log.

    The largest rejection left inside a failing case of the learning-half run was "the refuting test of X
    (list_openings()) must appear in object.identity.tests_run". Of its 148 last plans naming a chosen
    hypothesis, the model had called that refuting test in 95 and had its reading from the opening packet in the
    other 53, and in none of the 148 had the test never been run. The model ran the test and did not copy the
    number back into the field the rule reads, which is the same fault as a retyped patch number (R22) and a
    copied catalog risk (R34): the checker holds the answer while it rejects the plan for not restating it.

    What is filled and what is not. A reading is the ledger's: `tools.matching_calls` finds the calls the test
    names (by tool name or by derived op, held to the opening ids the test names), and `number_for` picks the one
    the `would_refute_if` sentence is about. A verdict is the model's wherever the checker cannot recompute it:
    29 percent of the run's sentences are comparisons `refuting_verdict` reads, and a reading that satisfies one
    is written `refutes` even though it costs the plan its confidence, because that is the test doing its work; a
    sentence the checker cannot read leaves the model's own claim standing as `supports`, which is R10's rule for
    a second-look line the checker cannot compute.

    Nothing already written is overwritten: an entry naming the tool keeps its verdict, and receives a
    `result_number` only when it had none. A packet call counts as run (`via` facts_packet): its reading was in
    the opening message in front of the model before its first turn, and `loop.opening_messages` prunes the
    summary-only path from the log so a reading the model never saw is not a test it has had the answer to."""
    from geometry_agent.agent import tools

    obj = plan_obj.get("object")
    if not isinstance(obj, dict):
        return
    hyps = [h for h in (plan_obj.get("identity_hypotheses") or []) if isinstance(h, dict)]
    if not hyps:
        return
    ident = obj.get("identity") if isinstance(obj.get("identity"), dict) else None
    tests = [dict(t) for t in (ident or {}).get("tests_run") or [] if isinstance(t, dict)]
    by_tool = {str(t.get("tool") or ""): t for t in tests}
    filled: list[str] = []
    for h in hyps:
        rt = h.get("refuting_test")
        if not isinstance(rt, dict):
            continue
        tool = str(rt.get("tool") or "").strip()
        said = str(rt.get("would_refute_if") or "")
        have = by_tool.get(tool)
        if not tool or (have is not None and have.get("result_number") is not None):
            continue
        reading = next((r for r in (tools.number_for(c, said, ledger=ctx.ledger.numbers)
                                    for c in tools.matching_calls(ctx, tool, rt.get("args"))) if r is not None), None)
        if reading is None:
            # the one case the rejection is about the model and not about bookkeeping: the test was never run
            continue
        name, value = reading
        if have is not None:
            have["result_number"] = value
            filled.append(f"{tool} ({name}={value:g}, verdict {have.get('verdict')} as written)")
            continue
        verdict = tools.refuting_verdict(said, value) or "supports"
        entry = {"tool": tool, "result_number": value, "verdict": verdict}
        tests.append(entry)
        by_tool[tool] = entry
        filled.append(f"{tool} ({name}={value:g}, {verdict})")
    if not filled:
        return
    # a fresh identity block and a fresh object: `_normalise` copies the plan one level deep, and a repair that
    # reached into the caller's nested dicts would fill a plan the caller still holds. When the plan wrote no
    # verdict at all the checker writes one, because every part of it is either the model's own word elsewhere in
    # the plan (object.type) or the ledger's (the readings)
    ident = dict(ident) if ident is not None else {"type": str(obj.get("type") or "")}
    ident["tests_run"] = tests
    plan_obj["object"] = {**obj, "identity": ident}
    notes.append(f"R2 repair: object.identity.tests_run filled from the ledger's call log for {', '.join(filled)}; "
                 "the run made the call, so the reading is the checker's to record and not the model's to copy back")


def _agent_mesh_warning(w: dict[str, Any]) -> bool:
    """A mesh warning the analyst derived itself: it says so, or it names a kind the catalog does not calibrate."""
    by = w.get("detected_by")
    if by in ("agent", "catalog"):
        return by == "agent"
    return str(w.get("kind") or "") not in catalog.MESH_WARNING_KINDS


def _repair_mesh_warnings(plan_obj: dict[str, Any], notes: list[str]) -> None:
    """R25: a mesh warning whose kind the catalog does not calibrate is the analyst's own, not an error. It is
    stamped `detected_by` "agent" and its provenance is stripped of any claim to a calibrated threshold or a sweep
    (it has neither), and the kinds are named in the log so the learning ledger can count them: a kind the model
    keeps writing is the evidence a new calibrated kind is wanted, which is how the vocabulary grows. What the
    warning is then held to is its structured fields (`_check_mesh_warnings`), not its name."""
    mws = plan_obj.get("mesh_warnings")
    if not isinstance(mws, list) or not mws:
        return
    kinds: list[str] = []
    stripped: set[str] = set()
    out: list[Any] = []
    for w in mws:
        if not isinstance(w, dict) or not _agent_mesh_warning(w):
            out.append(w)
            continue
        kind = str(w.get("kind") or "")
        prov = w.get("provenance") if isinstance(w.get("provenance"), dict) else {}
        claims = [k for k in CALIBRATION_CLAIM_KEYS if prov.get(k) not in (None, "", [], {})]
        clean = {k: v for k, v in prov.items() if k not in CALIBRATION_CLAIM_KEYS}
        clean["rule_class"] = AGENT_RULE_CLASS
        clean["detected_by"] = "agent"
        out.append({**w, "detected_by": "agent", "provenance": clean})
        if kind not in catalog.MESH_WARNING_KINDS:
            kinds.append(kind)
        if claims:
            stripped.add(kind)
    plan_obj["mesh_warnings"] = out
    if kinds:
        notes.append(f"R25: mesh warnings of your own kinds ({', '.join(sorted(set(kinds)))}) read as detected_by 'agent' and "
                     f"rule_class {AGENT_RULE_CLASS!r}; they are kept and held to their fields (location, size, target, why), "
                     "and the kinds are recorded for the calibration ledger")
    if stripped:
        notes.append(f"R25: {', '.join(sorted(stripped))} claimed a threshold or a sweep in provenance; an agent warning is not "
                     "calibrated, so the claim is dropped and the measurement you wrote in `size` stands on its own")


def _check_builder_items(plan: GeometryPlan, ctx: ToolContext, rep: str, errors: list[str]) -> None:
    """R40 and R41: what every item the builder reads has to answer, and the order and length of the list.

    R40, the four questions. WHERE is a location the facts know; WHAT TO DO is one key the renderer reads with a
    value it does not clamp away; WHAT IT COSTS is `cost_cells` against the cap; WHY is `why`, and `why` reports a
    measurement. A sentence that predicts the finished mesh is rejected by the word that makes it one: the builder
    can only disagree with a prediction, and the measurement is the argument. `severity` is how much attention the
    item is owed (`catalog.ATTENTION`) and must agree with the class and the tier the checker computed, so
    `blocking` and `info` have no meaning here.

    R41, the list. One directive per key, in tier order, at most as many directives as the regime has keys.
    `_fill_builder_items` has already put the list in that order and demoted what has no reader, so what reaches
    here is what the writer has to change: a value out of band, a key set twice, an outcome claim, more
    instructions than the regime has knobs.

    The note and conditional overflow is NOT one of those. Every note is an item the checker itself made a note
    of, because the key it named has no reader, its cost is unknown, or its forecast is over the cap and it is
    the customer's `cell_cap` question; none of the three is something the writer got wrong, and there is no
    criterion in the message by which it could pick which measurement to delete. So the channel carrying two is
    reported as a routing decision in `_fill_builder_items` and the rest go to the session report with their
    measurements (docs/builder_directives.md 6.3), rather than costing a round to have the writer truncate its
    own findings at random."""
    mws = plan.mesh_warnings or []
    if not mws:
        return
    frame = _builder_frame_for(plan.model_dump(), ctx, rep)
    channel = _channel_of(ctx, rep, frame)
    regime = channel["regime"]
    keys_max = len(catalog.DIRECTIVE_KEYS.get(regime) or {})
    counts: dict[str, int] = {"directive": 0, "conditional": 0, "note": 0}
    seen: dict[str, str] = {}
    order: list[tuple] = []
    for i, w in enumerate(mws):
        tag = f"mesh_warnings[{i}] (/mesh_warnings/{i})"
        cls = w.item_class or "note"
        counts[cls] = counts.get(cls, 0) + 1
        word = catalog.outcome_claim(w.why or "")
        if word:
            errors.append(f"{tag}: why says {word!r} (/mesh_warnings/{i}/why), which predicts the finished mesh; the builder can only "
                          "disagree with a prediction. Write the measurement that makes the item worth doing instead: what is there, "
                          "how big it is in builder cells, and what the renderer does with it")
        if w.severity in ("blocking", "info"):
            errors.append(f"{tag}: severity {w.severity!r} is not an attention level on this channel; a builder item is high (a guard or "
                          "an unmet floor), medium (a margin, or an action on a named measured failure) or low (a note)")
        elif w.severity != catalog.attention_of(cls, w.tier):
            errors.append(f"{tag}: severity {w.severity!r} disagrees with a {cls}{' at ' + w.tier if w.tier else ''}, which is "
                          f"{catalog.attention_of(cls, w.tier)!r}: severity here is how much attention the item needs, not how bad "
                          "the mesh will be")
        key, value = w.target.key, w.target.value
        if cls in ("directive", "conditional"):
            problem = catalog.directive_problem(key, value, regime)
            if problem:
                errors.append(f"{tag}: target (/mesh_warnings/{i}/target) {problem}. The keys with a reader on {regime} at platform "
                              f"{_platform_sha()[:8]} are {', '.join(sorted(catalog.DIRECTIVE_KEYS.get(regime) or {}))}")
            elif key in seen:
                errors.append(f"{tag}: {key} is already set by {seen[key]}; the builder cannot carry out two values of one key, so keep "
                              "the one the measurement argues for and make the other a note")
            else:
                seen[key] = f"mesh_warnings[{i}]"
            if w.cost_cells is None and cls == "directive":
                errors.append(f"{tag}: cost_cells (/mesh_warnings/{i}/cost_cells) is empty; an item the builder is asked to act on says "
                              "what it costs in cells against the cap, or it is a note")
            if not (w.location.patch_ids or w.location.point or w.location.region_id) and cls == "directive":
                errors.append(f"{tag}: location (/mesh_warnings/{i}/location) names no patch, point or region; WHERE is one of the four "
                              "questions an item answers")
        if cls == "conditional":
            problem = catalog.trigger_problem(w.trigger)
            if problem:
                errors.append(f"{tag}: trigger (/mesh_warnings/{i}/trigger) {problem}")
        if (w.provenance or {}).get("dropped"):
            errors.append(f"{tag}: {(w.provenance or {})['dropped']}; an item that costs more cells than it is worth does not "
                          "belong on a list the builder reads in order. Drop it, or make it a note with the measurement and no key")
        if cls == "note" and key:
            errors.append(f"{tag}: a note names no key, and this one names {key!r}; either it is a directive with a cost and a forecast, "
                          "or the key comes off and the location and the size stay")
        order.append((_CLASS_ORDER.get(cls, 2), _TIER_ORDER.get(w.tier, 3), i))
    if counts["directive"] > keys_max:
        errors.append(f"mesh_warnings (/mesh_warnings): {counts['directive']} directives on {regime}, which reads {keys_max} keys; there are "
                      f"{keys_max} knobs, so there are at most {keys_max} instructions. Keep the ones the measurement argues for and make "
                      "the rest notes")
    if order != sorted(order):
        first = next(i for i, (a, b) in enumerate(zip(order, sorted(order))) if a != b)
        errors.append(f"mesh_warnings (/mesh_warnings): the list is not in reading order at mesh_warnings[{order[first][2]}]; every directive "
                      "comes first by tier (T0 the guards, T1 the floors, T2 the margins), then the conditionals, then the notes")


def _rule_location(m: dict[str, Any], facts: Any) -> dict[str, Any]:
    """WHERE a catalog rule fired, in the shape MeshWarning.location takes: the openings its measurement names,
    and the point it measured (or the one opening's centroid). The same derivation `_mesh_warning` uses when the
    checker builds the item itself, so an item the plan wrote lands in the same place as one it did not."""
    known = {o.id: o for o in facts.openings}
    ids = sorted(i for i in _ids_in(m) if i in known)
    point = m.get("centroid") or m.get("seed_point") or (list(known[ids[0]].centroid) if len(ids) == 1 else None)
    closest = m.get("closest")
    return {"patch_ids": ids, "point": [float(c) for c in point] if point else None,
            "region_id": str(closest[0]) if isinstance(closest, (list, tuple)) and closest else None}


def _catalog_rules_by_kind(plan_obj: dict[str, Any], expected: list[Risk] | None) -> dict[str, list[dict[str, Any]]]:
    """Every catalog rule that fired on this part, by kind, as the catalog states it NOW.

    `synthesise_warnings` filters its pool to the builder audience, because it is choosing which rules become a
    builder item at all. Filling an item the plan already wrote is a different question - which rule measured the
    thing this item is about - and the audience does not answer it: `thin_feature` is `info` on a wall shell and
    the analyst still writes it into the builder's list as a note, which is what docs/builder_directives.md 8.3
    asks for. The rule measured that cluster either way, and the sentence the builder reads is the rule's.

    `expected` wins over the plan's own copy of a kind, and takes the whole kind with it. A plan copies the
    `list_risks` result of the run that wrote it, and a rule that has since been restated or consolidated leaves
    that copy stale in exactly the way that matters here: `mini_housing_001` carries four per-mouth
    `tilted_circular_mouth` risks in the old wording, where the catalog now states one over all four mouths. Per
    `_risk_key` the four are four different risks and none of them is the one, so keeping both would fill three
    items from a text the catalog no longer writes. The plan's copy is kept only for a kind the catalog does not
    state at all any more, where it is the only record of what was measured."""
    risks = [r for r in plan_obj.get("risks") or [] if isinstance(r, dict)]
    by_kind: dict[str, list[dict[str, Any]]] = {}
    for e in expected or []:
        by_kind.setdefault(e.kind, []).append(e.model_dump())
    for r in risks:
        kind = r.get("kind")
        if r.get("detected_by", "catalog") == "catalog" and isinstance(kind, str) and kind not in by_kind:
            by_kind.setdefault(kind, []).append(r)
    return by_kind


#: The lengths a builder item's `target` asks for, beside the magnitudes in its `size` (R39 holds an agent item's
#: `size` to the ledger already, so these are the numbers an item states about the part).
FOLD_TARGET_NUMBERS = ("extension_length", "gmsh_size_value", "cells_across", "max_cells")
#: An opening id, a region id, a thin cluster id or a derivation id written into a sentence: a name carrying a
#: digit, which `_numbers_in` would otherwise read as a magnitude the item states.
_ID_IN_PROSE = re.compile(r"\b[orktd]\d+\b", re.I)
#: How many of an item's own numbers a rule has to own before the measurement alone folds it. Two, measured: one
#: is a coincidence the corpus makes often (an opening's bore belongs to the tilted mouth, the seed and the
#: budget forecast at once), and the run pays for it in wrong folds; at two the wrong folds stop and the fold
#: still catches what the name route does not (docs/plan_v3_rules.md section 23.1).
FOLD_NUMBERS_MIN = 2


def _item_numbers(w: dict[str, Any]) -> list[float]:
    """Every magnitude a written item states about this part: its `size`, its builder cells, the lengths its
    target asks for, and the numbers written into its own `why`."""
    out: list[float] = []
    for node in ((w.get("size") or {}), (w.get("builder_cells") or {})):
        if isinstance(node, dict):
            out += [float(v) for v in node.values() if isinstance(v, (int, float)) and not isinstance(v, bool) and v]
    t = w.get("target") if isinstance(w.get("target"), dict) else {}
    out += [float(t[k]) for k in FOLD_TARGET_NUMBERS
            if isinstance(t.get(k), (int, float)) and not isinstance(t.get(k), bool) and t.get(k)]
    sphere = t.get("sphere")
    if isinstance(sphere, dict) and isinstance(sphere.get("radius"), (int, float)):
        out.append(float(sphere["radius"]))
    # an id is a name and not a magnitude: `o3` would otherwise contribute a 3 to every sentence that says where
    out += _numbers_in(_ID_IN_PROSE.sub(" ", str(w.get("why") or "")))
    return out


def _rule_numbers(m: dict[str, Any]) -> list[float]:
    """The numbers a rule measured about its own feature: the scalars of its measurement. A list-valued entry
    (`bores`, `ring_ids`) is the part's inventory rather than this feature, so it never owns a number."""
    return [float(v) for v in (m or {}).values()
            if isinstance(v, (int, float)) and not isinstance(v, bool) and v]


def _rule_scale(m: dict[str, Any]) -> float:
    """How big the rule's own feature is, which is how near a point has to be to be at it."""
    for key in ("bore", "hydraulic_diameter", "min_dimension", "surface_cell", "thickness_min"):
        v = m.get(key)
        if isinstance(v, (int, float)) and not isinstance(v, bool) and v > 0:
            return float(v)
    return 0.0


def _same_place(w: dict[str, Any], m: dict[str, Any], facts: Any) -> str:
    """Whether the item names the place the rule fired at, in the rule's own frame (`_rule_location`).

    A rule that names no place at all (`near_touching` measures a gap and no id) is about the part, so every
    item is at its place and the magnitude is what has to identify it."""
    rule = _rule_location(m, facts)
    rids = set(rule.get("patch_ids") or [])
    region, point = rule.get("region_id"), rule.get("point")
    if not (rids or region or point):
        return "part"
    loc = w.get("location") if isinstance(w.get("location"), dict) else {}
    ids = {i for i in (loc.get("patch_ids") or []) if isinstance(i, str)}
    if ids:
        return "ids" if rids and ids <= rids else ""
    if isinstance(loc.get("region_id"), str):
        return "region" if loc["region_id"] == region else ""
    target = w.get("target") if isinstance(w.get("target"), dict) else {}
    sphere = target.get("sphere") if isinstance(target.get("sphere"), dict) else {}
    mine = [p for p in (loc.get("point"), sphere.get("anchor"))
            if isinstance(p, (list, tuple)) and len(p) == 3]
    if point and mine:
        tol = max(_rule_scale(m), 1e-9)
        for p in mine:
            if math.dist([float(c) for c in p], [float(c) for c in point]) <= tol:
                return "point"
    return ""


def _fold_of(w: dict[str, Any], rules: list[dict[str, Any]], taken: set[str],
             facts: Any) -> tuple[dict[str, Any], str] | None:
    """The catalog rule an agent-written item is re-authoring, or None when it is the analyst's own.

    Two routes, and a fold needs a single winner on the better of the two.

    THE NAME. The item's kind says the catalog's own kind, or the mechanism that kind carries
    (`catalog.restates`). The vocabulary is the catalog's tables and `schema.MECHANISMS`, the list the prompt's
    own section 3 is generated from, so this is the model repeating a word it was handed.

    THE MEASUREMENT. The item names the place the rule fired at, and a number it states is a number that rule
    measured. Neither half alone is sound: one opening carries a short stub, a tilted mouth and a skew repair at
    once, so the place cannot say which; and a bore is a number three rules on the part hold, so the magnitude
    cannot say where.

    A rule another item has already taken is out, because one rule is one item: two items folding into one would
    put the same instruction on the list twice."""
    best: list[tuple[int, int, int, dict[str, Any], str]] = []
    mine = _item_numbers(w)
    for r in rules:
        if str(r.get("id") or "") in taken:
            continue
        m = r.get("measurement") or {}
        where = _same_place(w, m, facts)
        if not where:
            continue
        said = catalog.restates(str(w.get("kind") or ""), str(r.get("kind") or ""))
        theirs = _rule_numbers(m)
        hits = sum(1 for n in mine if any(_close(n, x) for x in theirs))
        if where == "part" and not said:
            # a rule that fired on the part as a whole (`near_touching` measures a gap and names no id) has no
            # place to agree on, so a coincidence of numbers is all the measurement route would have, and every
            # number of a part-wide rule is a number of the part. Only the catalog's own word identifies it
            continue
        if not (said or hits >= FOLD_NUMBERS_MIN):
            continue
        best.append((0 if said else 1, -hits, len(_ids_in(m)) or 99, r, said or where))
    if not best:
        return None
    best.sort(key=lambda c: c[:3])
    if len(best) > 1 and best[0][:2] == best[1][:2]:
        # two rules explain it equally well; naming the wrong one would put the wrong measurement in front of
        # the builder, so the item stays the analyst's and the contract stays on it
        return None
    return best[0][3], best[0][4]


def _fold_agent_items(mws: list[Any], by_kind: dict[str, list[dict[str, Any]]], reserved: set[str], facts: Any,
                      notes: list[str]) -> dict[int, dict[str, Any]]:
    """R42: an item the analyst authored under a name of its own, for a thing the catalog already detects at the
    same place, is that catalog item and is filled from it rather than rejected.

    This project's rule is that what the code already knows, the checker fills and the writer is never charged
    for: a patch's measured numbers (R22), a catalog risk's nine fields (R34), the reading of a refuting test the
    run made (R2's fill), a catalog item's target and sentence (R40's fill, section 21.1). An item re-authoring a
    catalog rule is the same case one level further out: the kind is new, the measurement behind it is not, and
    the location, the size and the target it is being asked for are the ones the catalog is already holding.

    The item's kind becomes the rule's, so the rest of `_fill_builder_items` treats it exactly as a catalog item
    the plan wrote under its own name, and the repair is logged rather than costing a round. An item no rule
    explains stays the analyst's and is held to the full contract, because there the fields really are its own."""
    rules = [r for group in by_kind.values() for r in group]
    if not rules:
        return {}
    taken = set(reserved)
    out: dict[int, dict[str, Any]] = {}
    logged: list[str] = []
    for i, w in enumerate(mws):
        if not isinstance(w, dict) or w.get("detected_by", "catalog") != "agent":
            continue
        found = _fold_of(w, rules, taken, facts)
        if found is None:
            continue
        rule, route = found
        taken.add(str(rule.get("id") or ""))
        out[i] = rule
        mine = str(w.get("kind") or "")
        mws[i] = {**w, "kind": str(rule.get("kind") or ""), "detected_by": "catalog"}
        logged.append(f"{w.get('id') or mine} ({mine} -> {rule.get('kind')} {rule.get('id')}, by the {route})")
    if logged:
        notes.append("R42 repair: " + ", ".join(logged) + ". The catalog already measured that, so its location, its "
                     "size and what the builder does about it are the catalog's and are filled from the rule, the way "
                     "a catalog risk's own fields are (R34). Name the catalog's kind when it has one; a kind of your "
                     "own is for something it does not measure, and then every field is yours")
    return out


def _fill_builder_items(plan_obj: dict[str, Any], ctx: ToolContext, notes: list[str],
                        expected: list[Risk] | None = None) -> None:
    """R40: the four questions filled on a builder list the plan wrote itself, and R41's order applied to it.

    The item classes and the tiers are the checker's, not the model's, for the same reason a patch's measured
    numbers are: whether the builder can carry a key out is read from `catalog.DIRECTIVE_KEYS` at this platform
    sha, and what it costs is the emulator's arithmetic. An item naming a key with no reader keeps its
    measurement and loses its instruction, and the demotion is logged by name, because the analyst measured
    something real about a feature the platform gives it no control over. An item whose VALUE does not fit a key
    that does have a reader is left as it is for `_check_mesh_warnings` to reject: that one is a mistake to
    correct, not a limit to live with.

    On a CATALOG kind two of the four answers are the catalog's and not the writer's, exactly as a catalog risk's
    kind, severity and measurement are (R34): WHAT TO DO is `catalog.remedy_target` read through
    `catalog.directive_of`, which needs the rule's own measurement to find the key - the tilted mouth's
    `surface_level 1` is only reachable while the emulator reports `deficit == 0`, and that number lives on the
    risk, not on the sentence the model paraphrased - and WHY is the rule's own `consequence`, the measurement
    the threshold fired on. A plan that wrote the old wish-list target (`level_delta`, a sphere, an extension) or
    an older prediction ("layers collide at the rim") is repaired to the catalog's text and the repair is logged;
    it is not rejected, because neither field is the writer's to get right. R40 keeps its rejection for an agent
    kind, where the sentence really is the model's own and only the model can rewrite it."""
    mws = plan_obj.get("mesh_warnings")
    if not isinstance(mws, list) or not mws:
        return
    T = current_thresholds()
    rep = catalog.representation(ctx.facts, ctx.purpose, ctx.brief, declared=ctx.declared, fluid_side=ctx.fluid_side)
    frame = _builder_frame_for(plan_obj, ctx, rep)
    channel = _channel_of(ctx, rep, frame)
    by_kind = _catalog_rules_by_kind(plan_obj, expected)
    mws = list(mws)
    # the rules the plan's own catalog-kind items will take, held back from the fold so an item written under the
    # catalog's own name always keeps the rule it named
    reserved: set[str] = set()
    for kind, group in by_kind.items():
        n = sum(1 for w in mws if isinstance(w, dict) and w.get("detected_by", "catalog") != "agent"
                and str(w.get("kind") or "") == kind)
        reserved |= {str(r.get("id") or "") for r in group[:n]}
    bound = _fold_agent_items(mws, by_kind, reserved, ctx.facts, notes)
    taken = {str(r.get("id") or "") for r in bound.values()}
    first_of: dict[str, dict[str, Any]] = {}
    demoted: list[str] = []
    restated: list[str] = []
    folded: list[str] = []
    placed: list[str] = []
    out: list[Any] = []
    for idx, w in enumerate(mws):
        if not isinstance(w, dict):
            out.append(w)
            continue
        kind = str(w.get("kind") or "")
        risk = bound.get(idx)
        if risk is None and w.get("detected_by", "catalog") != "agent":
            group = by_kind.get(kind) or []
            pool = [r for r in group if str(r.get("id") or "") not in taken]
            if pool:
                risk = pool[0]
                taken.add(str(risk.get("id") or ""))
            elif group and kind in first_of:
                # the plan wrote one item per place and the rule fired once over all of them: one key set once is
                # one instruction, so the places fold into the item that carries it rather than repeating it
                # (docs/builder_directives.md 8.2, and R6 asks for every id by name on that one item)
                rule_ids = {i for r in group for i in _ids_in(r.get("measurement") or {})}
                mine = [i for i in ((w.get("location") or {}).get("patch_ids") or []) if isinstance(i, str)]
                if mine and set(mine) <= rule_ids:
                    keep = first_of[kind]
                    loc = dict(keep.get("location") or {})
                    loc["patch_ids"] = sorted({*(loc.get("patch_ids") or []), *mine})
                    keep["location"] = loc
                    folded.append(f"{w.get('id') or kind} ({', '.join(mine)} into {keep.get('id')})")
                    continue
        if risk is not None:
            m = dict(risk.get("measurement") or {})
            target = {**catalog.remedy_target(kind, m, frame, T), **(risk.get("target") or {})}
            why, said = str(risk.get("consequence") or "") or str(w.get("why") or ""), str(w.get("why") or "")
            if why != said:
                restated.append(f"{w.get('id') or kind}"
                                + (f" ({catalog.outcome_claim(said)!r})" if catalog.outcome_claim(said) else ""))
            w = {**w, "why": why}
            if idx in bound:
                # a folded item's magnitudes are the rule's too: the numbers it wrote were about its own name for
                # the feature and nothing checked them against the rule that measured it (R39 reads an agent
                # item's `size` and stops at a catalog one), so the rule's own size and builder cells go on it
                size, cells = _rule_size(kind, m, frame)
                w = {**w, "size": size, "builder_cells": cells}
            loc = dict(w.get("location") or {})
            if not (loc.get("patch_ids") or loc.get("point") or loc.get("region_id")):
                # WHERE on a catalog kind is measured too, so an item that named nowhere is placed from the rule
                # rather than rejected for a field the rule already holds. Only when it named nowhere at all: R6
                # asks the analyst to name every tilted mouth by id, and filling over an answer would not test it
                w = {**w, "location": {**loc, **_rule_location(m, ctx.facts)}}
                placed.append(f"{w.get('id') or kind} ({', '.join(w['location'].get('patch_ids') or []) or 'a point'})")
        else:
            m, target = {"trigger": w.get("trigger")}, dict(w.get("target") or {})
        # the rule's own trigger wins: on a catalog kind WHICH CLASS the item is, is the catalog's, the way its
        # target and its sentence are, and the model's word for it went with the name
        verdict = _classify(kind, target, {**m, "trigger": m.get("trigger") or w.get("trigger")}, ctx, channel, frame)
        prov = dict(w.get("provenance") or {})
        prov.update({"regime": channel["regime"], "cell_cap": channel.get("cell_cap"),
                     "forecast_without": channel.get("forecast")})
        for field in ("demoted", "dropped"):
            if verdict[field]:
                prov[field] = verdict[field]
        if verdict["demoted"]:
            demoted.append(f"{w.get('id') or kind} ({verdict['demoted']})")
        item = {**w, "target": target, "item_class": verdict["item_class"], "tier": verdict["tier"],
                # a note has no trigger: the class is the checker's and the phrase goes with the key it set
                "trigger": verdict["trigger"] or (w.get("trigger") if verdict["item_class"] == "conditional" else None),
                "severity": catalog.attention_of(verdict["item_class"], verdict["tier"]),
                "cost_cells": w.get("cost_cells") if verdict["cost"] is None else verdict["cost"],
                "forecast_cells": verdict["forecast"], "provenance": prov}
        if risk is not None:
            first_of.setdefault(kind, item)
        out.append(item)
    ranked = rank_mesh_warnings(out, channel["regime"], renumber=False, drop_refused=False)
    kept = {str(w.get("id")) for w in ranked if isinstance(w, dict)}
    # nothing the model wrote is deleted here (P4.4): the surplus rides at the end of the plan's list, where the
    # report and the ledger still read it, and the channel's own cap is what the builder sees
    surplus = [w for w in out if not (isinstance(w, dict) and str(w.get("id")) in kept)]
    # a stable sort on class and tier alone: `ranked` is already in full reading order, so this only slots each
    # surplus item at the end of its own bucket instead of after the notes, where it would read out of order
    plan_obj["mesh_warnings"] = sorted(ranked + surplus, key=lambda w: (
        _CLASS_ORDER.get((w.get("item_class") or "note") if isinstance(w, dict) else "note", 2),
        _TIER_ORDER.get(w.get("tier") if isinstance(w, dict) else None, 3)))
    spare = [w for w in surplus if (w.get("item_class") or "note") in ("note", "conditional")]
    if spare:
        notes.append(f"R41: the builder's list on {channel['regime']} carries {MAX_NOTES} notes and {MAX_CONDITIONALS} "
                     "conditionals, and you wrote more true things than that: "
                     + ", ".join(f"{w.get('id') or w.get('kind')} ({w.get('kind')})" for w in spare)
                     + " stay on the plan and in the session report (hexera.report()['warnings']) with their locations "
                     "and their measurements, and the block the request carries stops at the cap. Nothing is lost and "
                     "this costs no round: a note is over the cap because nothing reads its key, not because you were "
                     "wrong to measure it")
    if demoted:
        notes.append("R40: " + ", ".join(demoted) + " name no key the renderer reads on "
                     f"{channel['regime']} at platform {_platform_sha()[:8]}; they keep their location and their "
                     "measurement as notes, and the key is dropped rather than sent as an instruction nobody can carry out")
    if placed:
        notes.append("R40 repair: " + ", ".join(placed) + " named no patch, point or region, and their rule measured one; "
                     "WHERE is filled from the rule, the way the measurement and the sentence are")
    if folded:
        notes.append("R41 repair: " + ", ".join(folded) + ". One rule fired over all of those places and the key it sets is "
                     "global, so the builder reads one instruction naming every id, not one copy of it per id")
    if restated:
        notes.append("R40 repair: " + ", ".join(restated) + " are catalog kinds, so the instruction and the sentence are the "
                     "rule's own, the way its kind and its severity are: the target is what `catalog.directive_of` reaches on "
                     f"{channel['regime']} and the why is the measurement the threshold fired on. Your wording is not what the "
                     "builder reads, so this costs no round")


def _platform_sha() -> str:
    from geometry_agent.agent.tools import PLATFORM_SHA
    return PLATFORM_SHA


def agent_warning_kinds(plan: Any) -> dict[str, int]:
    """Every mesh warning kind the analyst wrote itself, with how often, from a plan or a plan dict. The learning
    ledger counts these over a run: a kind the model keeps writing is a candidate for calibration (P4.3d, R25)."""
    obj = plan if isinstance(plan, dict) else (plan.model_dump() if hasattr(plan, "model_dump") else {})
    out: dict[str, int] = {}
    for w in obj.get("mesh_warnings") or []:
        if isinstance(w, dict) and _agent_mesh_warning(w) and w.get("kind"):
            out[str(w["kind"])] = out.get(str(w["kind"]), 0) + 1
    return out


def _fill_refined_estimate(plan_obj: dict[str, Any], ctx: ToolContext, mp: dict[str, Any]) -> None:
    """`mesh_plan.cell_estimate_refined`: the tier estimate plus what the plan's own refinement regions add,
    computed from the plan the way the estimate tool computes it.

    NOT WRITTEN ON THE CHAIN (work/z-chain NEEDS 2). The chain costs the plan on the builder emulator at the third
    intake; this estimate has run at a median 1.86x and a max 576x the delivered cells, and on the chain it would
    have raised R36's budget question on 209 of 263 scored corpus parts, 155 of which came in under their cap.
    None here is what R36 reads as "nothing to check"."""
    if getattr(ctx, "chain_attached", False):
        mp["cell_estimate_refined"] = None
        return
    try:
        from geometry_agent.agent.tools import refined_cell_estimate
        mp["cell_estimate_refined"] = refined_cell_estimate(ctx, mp.get("fidelity"), mp.get("refinement_regions") or [],
                                                            plan_obj.get("patches") or [])["refined_cells"]
    except (TypeError, ValueError, KeyError, AttributeError, IndexError):
        # a malformed region list is reported by schema validation next; the refined count is then moot.
        # IndexError is the one the learning-half run found (bluff_body_001, wing_008, wing_011 wrote a box
        # corner as arithmetic, and what survives the salvage is a two-component list). `tools.box_volume`
        # answers None for a box that is not a box, so nothing raises there any more; the catch stays because
        # the checker must report a plan whatever the estimate does with it
        mp["cell_estimate_refined"] = None


def _normalise(plan_obj: dict[str, Any], ctx: ToolContext, notes: list[str] | None = None) -> dict[str, Any]:
    """Mechanical omissions repaired here because their meaning is not in doubt, so they do not cost a round:
    a layer target on `walls` implies the synthetic walls patch; a patch's measured numbers, the facts hash,
    the tier's base size and cell estimate come from the facts (packet v2); a flow axis within a few degrees
    of a measured direction is that direction; a unit the file declares (or the brief pins) is the unit; one
    body under internal flow is the fluid; a pending catalog risk with no question receives the catalog's own
    question, one per kind, attached to an existing question when that question already names the opening;
    the refined cell estimate is computed from the plan. Everything the model must decide (its own risks'
    questions, roles, decisions) is still its job.

    Schema 3 (docs/plan_v3_rules.md): a catalog risk's mechanism and effect come from the kind tables; a
    question's effect from its risk; a catalog decision the brief already settles (R9) is set to continue with
    the phrase as its derivation, on schema 3 plans; the two outputs, `simulation_warnings` and `mesh_warnings`,
    are synthesised from the catalog risks when the plan did not write them (any schema version), so a schema 2
    plan and the reference policy get both lists for free. `notes` receives one line per R9 repair.

    P4.3 (docs/plan_v3_rules.md, "P4.3 repairs"), logged the same way: a lone id written where a list is asked
    for is that list (R14); a single external body's not_a_fluid_body or wall_shell role is obstacle and an agent
    risk that only says so is dropped (R13); a direction_sign pointing from the outlets to the inlets is flipped
    (R15).

    P4.3b (docs/plan_v3_rules.md, "P4.3b repairs"), logged the same way: a catalog risk that asks no decision
    carries continue and the catalog's own reason (R18); the builder summary gets the unit opening the rule asks
    for (R20); a measured opening of the one external body left out of the patches is a wall (R21); a measured
    patch number the model retyped is replaced by the measurement (R22, in `_fill_patch_numbers`); a question's
    relates_to written as a list of ids is the first of them (R23, in `_repair_id_lists`).

    P4.3d (docs/plan_v3_rules.md, "P4.3d repairs"), logged the same way: a mesh warning of the model's own kind is
    detected_by agent and keeps its fields (R25); a question R9 has already settled through its risk is dropped
    (R27); a layer target on a port names the wall patch (R28); required_extents keyed above and below is the four
    standard keys (R29); a refinement region coarser than the cell already there is clamped one level finer (R30);
    a measured opening the catalog cannot call a port is a wall (R31); a refuting test naming `tool.op` names the
    tool (R33).

    P4.3e (docs/plan_v3_rules.md section 14), logged the same way and run before any rule or repair reads a kind:
    every field the catalog owns on a catalog risk is filled from the catalog run under the plan's own roles,
    matched by id, whether the plan wrote it or not; a catalog risk that asks no user decision and is missing is
    added; a risk that names its own question is written into that question's also_settles (R34)."""
    if not isinstance(plan_obj, dict):
        return plan_obj
    plan_obj = dict(plan_obj)
    log = notes if notes is not None else []
    _repair_id_lists(plan_obj, log)
    _repair_refuting_tools(plan_obj, log)
    if plan_version(plan_obj) >= V3:
        # after R33, so the fill matches the tool names R2 reads (P4.3e): the reading of a refuting test this run
        # made belongs to the ledger, not to the model's memory of it
        _fill_identity_tests(plan_obj, ctx, log)
    patches = [dict(p) if isinstance(p, dict) else p for p in (plan_obj.get("patches") or [])]
    ids = {p.get("id") for p in patches if isinstance(p, dict)}
    mp = dict(plan_obj["mesh_plan"]) if isinstance(plan_obj.get("mesh_plan"), dict) else None
    targets = [lt.get("patch_id") for lt in (mp or {}).get("layer_targets", []) if isinstance(lt, dict)]
    if "walls" in targets and "walls" not in ids and mp is not None:
        patches.append({"id": "walls", "name": "walls", "role": "wall", "confidence": 1.0,
                        "evidence": ["every surface that is not a declared port (added by the checker: a layer target named it)"]})
    _repair_external_openings(ctx, patches, log)
    _repair_measured_openings(plan_obj, ctx, patches, log)
    _fill_patch_numbers(patches, ctx.facts, log)
    plan_obj["patches"] = patches
    if not plan_obj.get("facts_sha256"):
        plan_obj["facts_sha256"] = ctx.facts.sha256
    flow = plan_obj.get("flow")
    if isinstance(flow, dict) and isinstance(flow.get("axis"), (list, tuple)) and len(flow["axis"]) == 3:
        snapped = _snap_flow_axis(flow["axis"], ctx.facts)
        if snapped is not None:
            axis, flipped = snapped
            flow = dict(flow)
            flow["axis"] = axis
            if flipped and flow.get("direction_sign") in (1, -1):
                flow["direction_sign"] = -flow["direction_sign"]
            plan_obj["flow"] = flow
    _repair_direction_sign(plan_obj, ctx, log)
    _repair_identity_confidence(plan_obj, ctx, log)
    if not plan_obj.get("unit"):
        unit = _default_unit(ctx)
        if unit:
            plan_obj["unit"] = unit
    if mp is not None:
        est = next((e for e in ctx.facts.cell_estimates if e.tier == mp.get("fidelity")), None)
        if est is not None:
            if mp.get("base_size") is None:
                mp["base_size"] = est.base_size
            if mp.get("cell_estimate") is None:
                mp["cell_estimate"] = est.cells
        if not mp.get("regions"):
            defaults = _default_region_roles(ctx)
            if defaults:
                mp["regions"] = defaults
        if mp.get("seed_point") is None and ctx.purpose in ("internal_cfd", "conjugate_heat_transfer"):
            seed = _default_seed_point(plan_obj, ctx)
            if seed is not None:
                mp["seed_point"] = seed
        plan_obj["mesh_plan"] = mp
        # P4.3d: the mesh plan's three computable corrections, after the tier's own numbers are in place
        _repair_layer_targets(mp, patches, log)
        _repair_required_extents(plan_obj, ctx, mp, log)
        _repair_refinement_sizes(plan_obj, ctx, mp, log)
        # R36: the refined estimate is computed here, where R30 has just finished with the regions and where the
        # risk it raises is still ahead of the question pass. It used to be computed after the questions were
        # built, which is why nothing could ask about it
        _fill_refined_estimate(plan_obj, ctx, mp)

    risks = [dict(r) for r in plan_obj.get("risks") or [] if isinstance(r, dict)]
    version = plan_version(plan_obj)
    # P4.3e: the catalog's own fields on every catalog risk, before any rule or repair reads a kind (R34)
    expected = _expected_risks(plan_obj, ctx)
    _fill_catalog_risks(plan_obj, ctx, risks, log, expected)
    _fill_catalog_risk_fields(risks)
    settled_questions: list[dict[str, Any]] = []
    if version >= V3:
        r9, settled_questions = _repair_false_alarms(plan_obj, ctx, risks)
        if notes is not None:
            notes.extend(r9)
    # P4.3b: both read what the catalog and the rule themselves wrote, so both apply to either schema version
    _settle_non_decision_risks(risks, log)
    _repair_builder_unit_line(plan_obj, ctx, log)
    plan_obj["risks"] = risks
    questions = [dict(q) for q in plan_obj.get("questions") or [] if isinstance(q, dict)]
    if mp is not None:
        _repair_external_solid(plan_obj, ctx, mp, patches, risks, questions, log)
    # one question per decision: a second question on the same risk or patch is the same question asked twice
    seen: set = set()
    deduped = []
    for q in questions:
        key = q.get("relates_to")
        if key in seen and key not in ("identity", "purpose", "unit", "fidelity"):
            continue
        seen.add(key)
        deduped.append(q)
    questions = deduped
    questions = _merge_role_questions(questions, risks)
    _link_named_questions(questions, risks, log)
    asked = {q.get("relates_to") for q in questions}
    for q in questions:
        asked |= set(q.get("also_settles") or [])
    pending = [r for r in risks
               if r.get("detected_by", "catalog") == "catalog" and r.get("requires_user_decision")
               and r.get("user_decision", "pending") == "pending" and r.get("id") not in asked]
    # attach to a question that already names the opening; otherwise one injected question per kind
    left = []
    for r in pending:
        oid = (r.get("measurement") or {}).get("opening_id")
        host = None
        if oid:
            host = next((q for q in questions if oid in OPENING_ID.findall(q.get("text") or "")
                         and q.get("relates_to") != "unit"), None)
        if host is not None:
            host["also_settles"] = list(host.get("also_settles") or []) + [r.get("id")]
        else:
            left.append(r)
    by_kind: dict[str, list[dict]] = {}
    for r in left:
        by_kind.setdefault(r.get("kind", ""), []).append(r)
    n = len(questions)
    for kind, group in by_kind.items():
        n += 1
        first = group[0]
        ids_named = [x for x in ((r.get("measurement") or {}).get("opening_id") for r in group) if x]
        text = _catalog_question_text(first)
        if len(group) > 1 and ids_named:
            text += f" (openings {', '.join(ids_named)})"
        options = DEFAULT_OPTIONS.get(kind, ["continue", "fix", "abort"])
        # the checker's fallback default is the conservative first option; the unit question defaults to the best guess
        default = options[0]
        if kind == "unit_unknown":
            guess = (first.get("measurement") or {}).get("best_guess")
            default = guess if guess in options else options[0]
        if first.get("severity") == "blocking":
            default = None
        questions.append({"id": f"q{n}", "text": text, "options": options, "relates_to": first.get("id"), "default": default,
                          "also_settles": [r.get("id") for r in group[1:]]})
    _fill_question_effects(questions, risks)
    plan_obj["questions"] = questions
    if mp is not None:
        if version >= V3:
            _note_operating_point(mp, ctx)
    # P4.3d: a written mesh warning of the model's own kind is stamped detected_by agent before anything reads it
    _repair_mesh_warnings(plan_obj, log)
    # schema 3, the two outputs: synthesised from the catalog when the plan did not write them (any version)
    wrote_sims = plan_obj.get("simulation_warnings") is not None
    wrote_mws = plan_obj.get("mesh_warnings") is not None
    if not wrote_sims or not wrote_mws:
        sims, mws = synthesise_warnings(plan_obj, ctx, None if wrote_mws else expected,
                                        settled_questions=settled_questions)
        if not wrote_sims:
            plan_obj["simulation_warnings"] = sims
        if not wrote_mws:
            plan_obj["mesh_warnings"] = mws
    if wrote_mws:
        # R40: the plan wrote its own builder list, so the four questions are filled and ranked on it here. The
        # expected risks come too: a catalog kind's instruction is read off the rule's own measurement, which is
        # the only place the numbers `catalog.directive_of` needs (the mouth's `deficit`) are recorded
        _fill_builder_items(plan_obj, ctx, log, expected)
    if wrote_sims and settled_questions:
        # the plan wrote its own user list, so nothing synthesised is kept to host the questions R27 moved: they
        # are written onto that list here instead (P4.4). Every parsed submission of the two live v3 runs wrote it.
        _host_settled_questions(plan_obj, ctx, settled_questions, log)
    _fill_visual_impression(plan_obj, ctx)
    return plan_obj


def _fill_visual_impression(plan_obj: dict[str, Any], ctx: ToolContext) -> None:
    """The look, written onto the plan from the run so it travels with it (dev plan P9, section 19 of
    docs/plan_v3_rules.md).

    It is filled here and nowhere else, and anything the plan wrote under the key is replaced, the way a patch's
    measured numbers are: the impression is not the analyst's to compose, and `SkipJsonSchema` keeps it out of the
    submit tool's schema so it is never offered. A run that did not look, or whose look failed, leaves it None,
    which is what tells a reader downstream that there was nothing to see rather than nothing to say."""
    from geometry_agent.agent import tools

    impression = getattr(ctx, "vision_impression", None)
    if not impression:
        plan_obj.pop("visual_impression", None)
        return
    # what answered, recorded beside the words by the look that fetched them: a run whose opening look failed and
    # whose follow-up succeeded is leaning on the follow-up's description, and naming the opening look's provider
    # (there is none) would have said the words came from nowhere
    plan_obj["visual_impression"] = {"impression": dict(impression),
                                     "model": str(getattr(ctx, "vision_model", "") or ""),
                                     "provider": str(getattr(ctx, "vision_provider", "") or ""),
                                     "caveat": tools.VISION_CAVEAT,
                                     "drawn": dict(getattr(ctx, "vision_drawn", None) or {})}


def check(plan_obj: dict[str, Any], ctx: ToolContext) -> tuple[GeometryPlan | None, list[str]]:
    plan, errors, _hints = check_with_hints(plan_obj, ctx)
    return plan, errors


def _check_patches(plan: GeometryPlan, ctx: ToolContext, errors: list[str]) -> dict[str, str]:
    facts, ledger = ctx.facts, ctx.ledger.numbers
    known = {o.id: o for o in facts.openings}
    rep = catalog.representation(facts, ctx.purpose, ctx.brief, declared=ctx.declared, fluid_side=ctx.fluid_side)
    ring_ports = {o.id for o in catalog.port_openings(facts, rep, ctx.declared) if o.kind == "ring"}
    inner_regions = {r.id for r in facts.regions if r.nested_in}
    walls_area = facts.total_surface_area - sum(o.area for o in facts.openings if o.kind != "ring")
    seen_ids: set[str] = set()
    for p in plan.patches:
        if p.id in seen_ids:
            errors.append(f"patch {p.id}: duplicate id")
        seen_ids.add(p.id)
        if p.id in known:
            o = known[p.id]
            # R22 (P4.3b): area, centroid, normal and hydraulic_diameter are the measurement, filled by _normalise
            # and, when the model retyped one, replaced there and logged. Nothing about them is rejected here:
            # what a patch is judged on is its id, its role and the class of the opening it names.
            if p.role in ("inlet", "outlet"):
                if o.classification == "ring" and o.id not in ring_ports:
                    errors.append(f"patch {p.id} is a ring (a face with a hole through it) on a fluid body; a ring is a port only on a "
                                  "wall shell (carved cavity) or an annular passage, give it role wall")
                elif (o.kind == "cap" and o.region_id in inner_regions and rep == "wall_shell"
                      and not p.confirmed_by_user):
                    # THE ESCAPE ITS THREE NEIGHBOURS ALREADY HAVE. Without it this rule and R9 hand the model
                    # instructions with no common answer: R9 says of a declared port "a declared port is not a role
                    # question: give the patch the declared role with confirmed_by_user", and this said the role it
                    # was just told to give is an error. Both doors shut, so the whole plan died on grounding - twice
                    # in twenty-four runs, on a role the customer had confirmed on the platform's own panel.
                    #
                    # The geometry reading is still ours and it is still stated: a centre body's end cap is solid
                    # material and flow cannot enter through it, so this refuses on every run where nobody said
                    # otherwise. What it no longer does is overrule the person. "Whatever the human says is final;
                    # if he says something wrong we can correct him" - and `confirmed_by_user` is only ever set
                    # from an answer somebody actually gave (`confirm.py`), never from a default, so this cannot be
                    # opened by an assumption of ours wearing the customer's clothes.
                    errors.append(f"patch {p.id} is the end face of an inner body (a centre body) inside the wall shell; it is an "
                                  "obstacle face, not a port, and the port is the ring's bore around it; it is a port only if the "
                                  "user says it is (then set confirmed_by_user)")
                elif o.classification == "hole" and not p.confirmed_by_user:
                    errors.append(f"patch {p.id} is a hole (a pinhole, slit or seam); it is a wall defect unless the user says it is a port (then set confirmed_by_user)")
                elif o.classification == "planar_face" and not p.confirmed_by_user and not ctx.declared:
                    errors.append(f"patch {p.id} is a planar face (a flat side of the body); it is a wall unless the brief or a declared port names it as a port (then set confirmed_by_user)")
        elif p.id in SYNTHETIC_PATCHES or p.role in NAMED_SYNTHETIC_ROLES:
            # a synthetic patch may carry the user's own name for it ("aircraft", "casing"): the handover keeps it;
            # its area may be the wall area (the surface minus the opening faces, what get_facts_summary reports)
            for name, val in (("area", p.area), ("hydraulic_diameter", p.hydraulic_diameter)):
                if val is not None and not _measured(val, ledger) and not (name == "area" and _close(float(val), walls_area)):
                    errors.append(f"synthetic patch {p.id}.{name}={val} is not a measured number (use 0 or a tool result)" + _untraced(val, ctx))
        else:
            errors.append(f"patch {p.id}: unknown id; a port patch must use a measured opening id {sorted(known)}; "
                          f"a wall, farfield, symmetry or interface patch may use {sorted(SYNTHETIC_PATCHES)} or the user's own name")
    role_of = {p.id: p.role for p in plan.patches}
    posed = set(plan.flow.inlet_ids) | set(plan.flow.outlet_ids)
    port_ids = {o.id for o in catalog.port_openings(facts, rep, ctx.declared)}
    for oid in known:
        if oid in role_of:
            continue
        # R31 (P4.3d) gives every opening the catalog cannot call a port the wall patch in _normalise, so what is
        # left here is a port candidate: its role is a decision, and the message names the ones open to it
        if oid in posed:
            named = "inlet" if oid in plan.flow.inlet_ids else "outlet"
            errors.append(f"opening {oid} has no patch while flow.{named}_ids names it; add the patch with role {named}, its "
                          "confidence and the evidence, or take it out of the flow")
        elif oid in port_ids:
            errors.append(f"opening {oid} has no patch; it is a port candidate ({known[oid].classification}, hydraulic diameter "
                          f"{known[oid].hydraulic_diameter:.4g}), so its role is yours to decide: inlet, outlet, closed_end when the "
                          "brief calls it capped, opening_unknown when only the user can say, or wall")
        else:
            errors.append(f"opening {oid} has no patch; every measured opening needs a role (use closed_end or wall if not a port)")
    return role_of


def _check_flow(plan: GeometryPlan, ctx: ToolContext, role_of: dict[str, str], errors: list[str]) -> None:
    facts, ledger = ctx.facts, ctx.ledger.numbers
    known = {o.id: o for o in facts.openings}
    for lst, role in ((plan.flow.inlet_ids, "inlet"), (plan.flow.outlet_ids, "outlet")):
        for pid in lst:
            if role_of.get(pid) != role:
                errors.append(f"flow.{role}_ids contains {pid} whose patch role is {role_of.get(pid)!r}")
    flow = plan.flow
    if flow.axis is not None:
        for c in flow.axis:
            if not (_measured(c, ledger) or abs(abs(c) - 1.0) < 1e-9):
                errors.append(f"flow.axis component {c} is neither a measured principal-axis component nor axis-aligned")
    if flow.axis is None and flow.direction_sign != 0:
        errors.append("flow.axis is null: direction_sign must be 0 (nothing flows along no axis)")
    wall_file = any(r.kind == "solid_wall_representation" for r in plan.risks)
    if wall_file and (flow.inlet_ids or flow.outlet_ids):
        errors.append("a wall file has no inlet or outlet: leave inlet_ids and outlet_ids empty, axis null, direction_sign 0")
    internal = plan.purpose in ("internal_cfd", "conjugate_heat_transfer")
    if internal and not flow.inlet_ids and not flow.outlet_ids and flow.direction_sign != 0:
        errors.append("no ports assigned: direction_sign must be 0 and flow.confidence 0")
    ins = [known[i].centroid for i in flow.inlet_ids if i in known]
    outs = [known[i].centroid for i in flow.outlet_ids if i in known]
    if flow.axis is not None and ins and outs and flow.direction_sign != 0:
        # R15 (_repair_direction_sign) flips a backwards sign in _normalise when both sides have centroids, so this
        # fires only when the repair could not read the plan; the message stays for the amend pointer
        d = [sum(o[k] for o in outs) / len(outs) - sum(i[k] for i in ins) / len(ins) for k in range(3)]
        along = flow.direction_sign * sum(d[k] * flow.axis[k] for k in range(3))
        scale = max(known[i].hydraulic_diameter for i in flow.inlet_ids + flow.outlet_ids if i in known)
        if along < -DIRECTION_SIGN_TOL_OVER_D * scale:
            errors.append("flow.direction_sign points from the outlets toward the inlets; axis * direction_sign must point from "
                          "the inlets to the outlets (flip direction_sign or the axis)")


def _check_risks(plan: GeometryPlan, ctx: ToolContext, role_of: dict[str, str], errors: list[str],
                 hints: dict[str, Any]) -> list[Risk]:
    facts, ledger = ctx.facts, ctx.ledger.numbers
    known = {o.id: o for o in facts.openings}
    roles = {oid: role_of[oid] for oid in known if oid in role_of}
    expected = catalog.detect_risks(facts, ctx.purpose, plan.mesh_plan.fidelity, ctx.cell_cap, ctx.declared, roles, brief=ctx.brief,
                                    fluid_side=ctx.fluid_side)
    # R36: the plan's own refinement budget, appended so the comparison here is the list `_normalise` filled from
    expected = _with_refined_cell_cap(expected, None, plan, ctx)
    # R34: the same binding `_fill_catalog_risks` made, so what is missing here is what the plan never named and
    # what is unbound is an id (or a kind and subject) the catalog did not produce
    mine = [r.model_dump() for r in plan.risks]
    _pairs, unbound, taken = _bind_catalog_risks(mine, expected)
    missing = []
    v3 = plan.schema_version >= V3
    for r in expected:
        if r.id in taken or r.kind in catalog.NEW_BUILDER_KINDS:
            # the builder kinds added with schema 3 ride in mesh_warnings (synthesised when absent); the plan's
            # risks list is never asked for them, so a schema 2 transcript is judged exactly as before
            continue
        # a risk nobody has to decide is added by `_fill_catalog_risks`; what is left is a decision the plan owes
        oid = _risk_key(r)[1]
        errors.append(f"missing catalog risk {r.kind}" + (f" for {oid}" if oid else "")
                      + " for the roles this plan declares; add " + SHORT_RISK_FORM.format(id=r.id, decision="pending")
                      + " at /risks/- (or user_decision 'continue' or 'fix' with your reason in derivation); the checker fills "
                      "kind, severity, measurement, consequence and recommendation from the catalog")
        missing.append({"id": r.id, "kind": r.kind, **({"opening_id": oid} if oid else {}), "user_decision": "pending"})
    for r in unbound:
        # an entry written in the short form is its id and nothing else, so an id the catalog did not produce names
        # nothing at all. A full entry carries its own content and is left as it was before R34 (stale, reported in
        # the hint): a stored transcript that kept a risk an earlier list_risks raised is not newly rejected here
        if str(r.get("kind") or "").strip():
            continue
        ids = ", ".join(e.id for e in expected[:20]) + (", ..." if len(expected) > 20 else "")
        errors.append(f"risk {r.get('id')}: written as a catalog risk (id and decision), but the catalog produced no risk with "
                      f"that id under the roles this plan declares; the catalog ids now are {ids or 'none'}. A risk of your own "
                      "is detected_by 'agent' with an id from k101 up and writes its own kind, consequence and recommendation")
    if missing:
        hints["missing_catalog_risks"] = missing[:8]
        # R34: an id is a reference into one catalog run, and the catalog numbers k1 upward in detection order, so
        # a role changed after list_risks renumbers the rest. A plan short of a risk may be short of it or reading
        # an older numbering, and the note says so where the missing message cannot tell the two apart
        hints["note"] = ("a plan names catalog risks by the ids list_risks returned for the roles it declares; if a role "
                         "changed since that call, call list_risks again, because the ids renumber")
        if unbound:
            hints["stale_catalog_risks"] = [str(r.get("id")) for r in unbound]

    proceed = bool(PROCEED.search(ctx.brief or ""))
    catalog_decisions = [r for r in plan.risks if r.detected_by == "catalog" and r.requires_user_decision]
    questions_by_risk: dict[str, list] = {}
    for q in plan.questions:
        for rid in [q.relates_to, *q.also_settles]:
            questions_by_risk.setdefault(rid, []).append(q)
    by_question = {q.id: q for q in plan.questions}
    for r in plan.risks:  # R34: the link written the other way round
        if r.question_id in by_question and by_question[r.question_id] not in questions_by_risk.get(r.id, []):
            questions_by_risk.setdefault(r.id, []).append(by_question[r.question_id])
    stub_of = {s.opening_id: s for s in facts.stubs}
    op_missing = [r for r in plan.risks if r.detected_by == "agent" and r.kind == "operating_point_missing"]
    if len(op_missing) > 1 and not v3:
        errors.append("missing operating conditions are one risk per plan (kind operating_point_missing), not one per item")
    for r in plan.risks:
        if r.detected_by == "catalog":
            # R18 (P4.3b): only a catalog risk that asks a decision has one to override. A risk the catalog raised
            # for the record (requires_user_decision false) carries the catalog's own empty derivation into the
            # plan, and _normalise fills its decision and reason; rejecting it asked the model to invent a reason
            # for a decision nobody made (it fired on five of the six v3 smoke plans).
            if r.requires_user_decision and r.user_decision != "pending" and len(r.derivation.strip()) < 10:
                # R18b: THE REASON THE PLAN ITSELF CARRIES IS FILLED IN, and only a decision the checker cannot
                # account for is rejected. This rule is right - standing a catalog decision down with no reason is
                # the silent override it closes - and it was a third of the rejections that cost two plans in the
                # live batch of 2026-09-26 (cht_block_serpentine twice, tee_wall_flanged_filleted's second pass on
                # its own). Where the plan extends the very port a short run was raised on, or the brief says to
                # proceed and the decision is the one the `proceed` clause below DEMANDS in the same round, the
                # sentence is a fact about this plan that `_decision_reason` reads off it, not the analyst's
                # judgement, and asking for it back costs a round and buys nothing.
                got = _decision_reason(r, plan, proceed)
                if got:
                    r.derivation = got
                    hints.setdefault("warnings", []).append(
                        f"R18b repair: risk {r.id} ({r.kind}) decided {r.user_decision!r} with no derivation; the reason is in the "
                        f"plan and the checker wrote it: {got}")
                else:
                    # the pointer is in the message, not only in `tools.error_pointer`: a rejection the model has to
                    # reverse-engineer a path from is a rejection it spends a round on. The amend is one edit.
                    where = f"/risks/{[x.id for x in plan.risks].index(r.id)}/derivation"
                    errors.append(f"risk {r.id} ({r.kind}): overriding a catalog decision (user_decision {r.user_decision!r}) needs the "
                                  "reason in `derivation`: one sentence saying what settles it (the brief's phrase, the measurement, or "
                                  f"the catalog rule you are standing down). One edit fixes it: set {where} to that sentence")
            continue
        # R34: the catalog fields are optional at the type level now, because a catalog risk is written as its id
        # alone; a risk of the analyst's own still writes every one of them and the rule says so here
        written = [k for k in ("kind", "consequence", "recommendation") if str(getattr(r, k) or "").strip()]
        if len(written) < 3:
            errors.append(f"risk {r.id} (detected_by agent): a risk of your own writes "
                          + ", ".join(k for k in ("kind", "consequence", "recommendation") if k not in written)
                          + " itself (only a catalog risk is filled in from the catalog, by its id)")
        for mk, mv in r.measurement.items():
            if isinstance(mv, (int, float)) and not isinstance(mv, bool) and not _measured(float(mv), ledger):
                errors.append(f"agent risk {r.kind}.measurement.{mk}={mv} is not a measured number or a number from the brief; "
                              "computed quantities go in `derived` with a `derivation`" + _untraced(mv, ctx))
        if not _has_number(r.measurement):
            errors.append(f"agent risk {r.kind}: every agent risk cites at least one measured number in `measurement`"
                          + ("; a missing brief item is a line in mesh_plan.assumptions, not a risk" if v3 else
                             "; a missing brief item is one risk of kind operating_point_missing (severity info) carrying the bores "
                             "the sizing depends on"))
        # a derived value that cites a derivation id is held to the ledger by _check_derived; the formula is the tool's
        items = _derived_items(r)
        cited = bool(items) and all(ids for _, _, ids in items)
        if r.derived and len(r.derivation.strip()) < 10 and not cited:
            errors.append(f"agent risk {r.kind}: `derived` values need a `derivation` stating the formula and assumptions")
        elif r.derived:
            stated = _numbers_in(r.derivation)
            for dk, dv, ids in items:
                if not ids and not _stated(dv, stated):
                    errors.append(f"agent risk {r.kind}: derived {dk}={dv} does not appear in `derivation`; write the formula with its "
                                  "inputs and its result so the user can check it")
            if not cited and not any(_measured(n, ledger) for n in stated):
                errors.append(f"agent risk {r.kind}: `derivation` must state its inputs (at least one measured number or a number from the brief)")
        if r.kind == "operating_point_missing":
            # schema 3 rejects the kind itself (R4, _check_agent_risks_v3); schema 2 keeps the v2 rule
            if r.severity != "info" and not v3:
                errors.append("operating_point_missing is severity info: it changes no mesh number the plan cannot default")
        elif SOLVER_SETUP_KINDS.search(r.kind) and r.requires_user_decision:
            errors.append(f"agent risk {r.kind}: solver setup (velocity, Reynolds number, fluid, boundary conditions, loads, what to "
                          "measure) is not a geometry question; "
                          + ("drop the risk, write the assumption you make instead in mesh_plan.assumptions and size the layer "
                             "target from it in its reason" if v3 else
                             "fold it into one risk of kind operating_point_missing (severity info, your default filled in) and "
                             "record the assumption in mesh_plan.assumptions"))
        oid = r.measurement.get("opening_id")
        stub_ok = current_thresholds().STUB_OK_OVER_D
        if r.requires_user_decision and STUB_KINDS.search(r.kind) and oid in stub_of \
                and stub_of[oid].length_over_diameter >= stub_ok:
            errors.append(f"agent risk {r.kind}: the stub at {oid} is {stub_of[oid].length_over_diameter:.1f} D, at or above "
                          f"{stub_ok:.0f} D; the catalog's stub rule is the project's rule, so this is not a decision")
        if CAPPED_KINDS.search(r.kind) and BRIEF_CAPPED.search(ctx.brief or ""):
            errors.append(f"agent risk {r.kind}: a capped or blanked end of a fluid body is a planar cap identical to a port; the "
                          "brief's word settles it: give it closed_end with the brief as evidence, no conflict and no risk")
        if r.severity == "blocking":
            if r.user_decision != "pending":
                errors.append(f"agent risk {r.kind}: a blocking risk cannot carry your decision ({r.user_decision}); either the mesh "
                              "cannot be built until the user answers, or it is not blocking (medium when your default resolves it)")
            if any(q.default for q in questions_by_risk.get(r.id, [])):
                errors.append(f"agent risk {r.kind}: a blocking risk cannot carry a default answer; lower the severity or drop the default")
        if r.requires_user_decision:
            mine = _ids_in(r.measurement)
            for c in catalog_decisions:
                shared = mine & _ids_in(c.measurement)
                if shared:
                    errors.append(f"agent risk {r.kind} restates catalog risk {c.id} ({c.kind}) on {sorted(shared)}; two questions about one "
                                  f"feature is a defect: put your reasoning and options into the question for {c.id} and drop this risk "
                                  "(or make it requires_user_decision false)")
                    break
    if proceed:
        for r in plan.risks:
            # R36's risk is the checker's: it is raised from the plan the model has already submitted, so there
            # was no turn in which the model could have taken its default. Its question carries the default
            if r.derivation.startswith(R36_DERIVATION):
                continue
            if r.requires_user_decision and r.user_decision == "pending" and r.severity != "blocking":
                errors.append(f"the brief says to proceed: risk {r.id} ({r.kind}, {r.severity}) must carry your default decision "
                              "(continue or fix) with the reason in `derivation`, and its question keeps that default so the user can overturn it")
        for c in plan.brief_conflicts:
            if PROCEED.search(c):
                errors.append("the instruction to proceed is not a brief conflict; remove it from brief_conflicts")
        if "proceed" not in plan.summary_for_user.lower():
            errors.append("the brief says to proceed: summary_for_user must open with 'Proceeding with:' and list the defaults chosen")
    _check_refined_budget(plan, ctx, questions_by_risk, errors)
    return expected


def _check_refined_budget(plan: GeometryPlan, ctx: ToolContext, questions_by_risk: dict[str, list],
                          errors: list[str]) -> None:
    """R36's other half: a plan whose refined estimate is over the cap either carries the `cell_cap` risk with a
    question, or is rejected. `_normalise` raises the risk pending when the plan carried none, and the question
    pass asks it, so what reaches here is a plan that wrote the risk itself and then decided it away with nobody
    asked. Over the cap is the user's money, and taking that decision for them silently is the fault."""
    cap, refined = ctx.cell_cap, plan.mesh_plan.cell_estimate_refined
    if not cap or not isinstance(refined, (int, float)) or refined <= cap:
        return
    cc = [r for r in plan.risks if r.kind == "cell_cap"]
    # the test is the question, not the decision: a plan may take the default (a brief that says to proceed asks
    # for exactly that), but the user is still the one paying for the cells and must be able to overturn it
    silent = [r for r in cc if not questions_by_risk.get(r.id)]
    if cc and not silent:
        return
    ratio = float(refined) / cap
    where = f"risk {silent[0].id} (cell_cap)" if silent else "risks (/risks)"
    errors.append(f"{where}: mesh_plan.cell_estimate_refined is {int(refined):,} cells against the cap of {int(cap):,} "
                  f"({ratio:.3g}x), and no question asks about it. A plan over the cap carries the cell_cap risk with "
                  "its question, so the user can answer it, or it coarsens the refinement regions until the refined "
                  "estimate fits (estimate_cells with your refinement_regions returns the same number)")


def _extent_rows(extents: dict[str, float], facts, unit: str | None) -> list[dict[str, Any]]:
    """Every required extent against the body's own longest extent: `{key, value, body_extent, ratio, in_band,
    as_unit}`. The plan's sizes and the measured bbox are numbers in one and the same unit (the plan's `unit`
    says what the file's numbers mean; it never rescales them), so the ratio is unit free and a value written in
    another unit shows up as a ratio out by that unit's factor. `as_unit` is the unit the WHOLE SET reads as, on
    the test below, which is what makes the fault one amend rather than a guess; None when nothing explains it."""
    from geometry_agent.agent import tools

    L = max(facts.bbox.extent) if facts.bbox.extent else 0.0
    lo, hi = EXTENT_OVER_L
    rows: list[dict[str, Any]] = []
    if L <= 0:
        return rows
    T = current_thresholds()
    standard = {"upstream": T.EXTERNAL_UPSTREAM_OVER_L, "downstream": T.EXTERNAL_DOWNSTREAM_OVER_L,
                "lateral": T.EXTERNAL_LATERAL_OVER_L, "vertical": T.EXTERNAL_LATERAL_OVER_L}
    here = tools.UNIT_TO_M.get(unit or "") or 0.0
    ratios = {k: float(v) / L for k, v in extents.items()
              if isinstance(v, (int, float)) and not isinstance(v, bool) and v > 0}
    # A unit slip is a slip of the whole set by one exact factor, so the unit is read off the whole set and only
    # when the whole set is out of band on the SAME side: a plan with one extent under the body and another over
    # it is a box that is wrong, not a unit that is. Among the units whose factor brings every value into band the
    # one named is the one nearest the standard multiples (geometric mean of fixed over standard), and only when
    # that mean is within a factor of two of them. Anything looser names a unit for arithmetic's sake: on
    # wing_011's far field (0.886 L upstream, 1.418 L downstream) three units put the numbers somewhere in the
    # band and none of them is what the model meant
    candidate = None
    if here > 0 and ratios and (all(r < lo for r in ratios.values()) or all(r > hi for r in ratios.values())):
        best = None
        for u, f in tools.UNIT_TO_M.items():
            if u == unit:
                continue
            fixed = {k: r * f / here for k, r in ratios.items()}
            if not all(lo <= r <= hi for r in fixed.values()):
                continue
            off = math.exp(sum(math.log(r / standard.get(k, T.EXTERNAL_LATERAL_OVER_L))
                               for k, r in fixed.items()) / len(fixed))
            if abs(math.log(off)) <= math.log(2.0) and (best is None or abs(math.log(off)) < best[0]):
                best = (abs(math.log(off)), u)
        candidate = best[1] if best else None
    for k in sorted(ratios):
        ratio = ratios[k]
        in_band = lo <= ratio <= hi
        rows.append({"key": k, "value": float(extents[k]), "body_extent": L, "ratio": ratio,
                     "in_band": in_band, "as_unit": None if in_band else candidate})
    return rows


def _extent_message(row: dict[str, Any], unit: str | None) -> str:
    """R35's one line: the value, the body extent and the ratio, then the unit it would have been in band in."""
    from geometry_agent.agent import tools

    lo, hi = EXTENT_OVER_L
    u = f" {unit}" if unit else ""
    tail = ""
    if row["as_unit"]:
        f = tools.UNIT_TO_M[row["as_unit"]] / tools.UNIT_TO_M[unit]
        tail = (f"; read as {row['as_unit']!r} it is {row['value'] * f:.6g}{u} = {row['ratio'] * f:.3g} L, the standard "
                f"multiple, so the value is a length in {row['as_unit']!r} and the plan's unit is {unit!r}")
    return (f"required_extents[{row['key']}]={row['value']:.6g}{u} is {row['ratio']:.4g} x the body's own extent "
            f"{row['body_extent']:.6g}{u}; a far-field extent is {lo:g} to {hi:g} L{tail}")


def _check_mesh_plan(plan: GeometryPlan, ctx: ToolContext, role_of: dict[str, str], errors: list[str]) -> None:
    facts, ledger = ctx.facts, ctx.ledger.numbers
    mp = plan.mesh_plan
    est = next((e for e in facts.cell_estimates if e.tier == mp.fidelity), None)
    hs = None
    if est is None:
        errors.append(f"mesh_plan.fidelity {mp.fidelity!r} has no estimate")
    else:
        hs = est.surface_cell or catalog._surface_cell(facts, mp.fidelity)
        if mp.base_size is not None and not _close(mp.base_size, est.base_size):
            errors.append(f"mesh_plan.base_size={mp.base_size} but the {mp.fidelity} estimate's base size is {est.base_size}")
        if mp.cell_estimate is not None and abs(mp.cell_estimate - est.cells) > 0.02 * max(est.cells, 1):
            errors.append(f"mesh_plan.cell_estimate={mp.cell_estimate} but the {mp.fidelity} estimate is {est.cells}")
    for rr in mp.refinement_regions:
        tag = f"refinement {rr.where!r}"
        if not _derivable(rr.target_size, ledger):
            errors.append(f"{tag}: target_size {rr.target_size} is not derivable from a measurement by a power of two or a standard factor"
                          + _untraced(rr.target_size, ctx))
        if est is not None and rr.target_size >= est.base_size * (1 - REL_TOL):
            errors.append(f"{tag}: target_size {rr.target_size} is not finer than the base cell {est.base_size:.4g}; it refines nothing "
                          f"(the tier already puts {hs:.4g} on every surface; size a region from the local feature: one level finer "
                          f"than the base cell is {est.base_size / 2:.4g}, and a wake box is written at that or finer)")
        elif est is not None and rr.kind in ("surface", "feature_edges") and rr.target_size >= hs * (1 - REL_TOL):
            errors.append(f"{tag}: a {rr.kind} region at {rr.target_size} is not finer than the surface cell {hs:.4g} the tier already "
                          "puts there; it refines nothing")
        if NEAR_WALL_REGION.search(rr.where) or NEAR_WALL_REGION.search(rr.reason):
            # R24: name what to do instead, not only the rule
            errors.append(f"{tag}: layers resolve the near-wall region; refinement regions are for geometry (a junction, a gap, a wake, "
                          "a small bore). Drop this region and put the near-wall resolution in the layer target (n_layers, "
                          "first_cell_height and its reason), or reword it around the feature it actually refines")
        if rr.kind == "sphere":
            if rr.anchor is None or rr.radius is None:
                errors.append(f"{tag}: a sphere region needs anchor and radius (or use kind box, surface or feature_edges)")
        elif rr.kind == "box":
            if rr.box_min is None or rr.box_max is None:
                errors.append(f"{tag}: a box region needs box_min and box_max")
            else:
                for corner in (rr.box_min, rr.box_max):
                    if not _anchored(corner, facts, ledger, plan):
                        errors.append(f"{tag}: box corner {list(corner)} is not a measured point nor within half a bore of one"
                                      + (" nor inside the declared external domain" if plan.purpose == "external_cfd" else "")
                                      + "; a box is placed by its corners the way a sphere is by its anchor: each corner within half a "
                                      f"bore of one of {_anchor_candidates(facts)}, of a probe_section centroid, or of the axis between "
                                      "two openings of one body (a box that spans the run is a sphere at the junction, or a surface region)")
                for k in range(3):
                    if rr.box_max[k] < rr.box_min[k]:
                        errors.append(f"{tag}: box_max must be above box_min on every axis")
        elif rr.kind == "surface":
            if not rr.patch_ids:
                errors.append(f"{tag}: a surface region names the patches it refines in patch_ids")
            for pid in rr.patch_ids:
                if pid not in role_of:
                    errors.append(f"{tag}: patch_ids names {pid!r}, which is not in `patches`")
        elif rr.kind == "feature_edges" and not mp.preserve_features:
            errors.append(f"{tag}: a feature_edges region needs the edges named in preserve_features")
        if rr.radius is not None and not _derivable(rr.radius, ledger):
            errors.append(f"{tag}: radius {rr.radius} is not derivable from a measurement" + _untraced(rr.radius, ctx))
        if rr.anchor is not None and not _anchored(rr.anchor, facts, ledger, plan):
            errors.append(f"{tag}: anchor {list(rr.anchor)} is not a measured point nor within half a "
                          f"bore of one; use one of {_anchor_candidates(facts)} (or a probe_section centroid"
                          + (", or any point inside the declared external domain)" if plan.purpose == "external_cfd" else ")"))
    for lt in mp.layer_targets:
        if lt.patch_id not in role_of:
            errors.append(f"layer target for unknown patch {lt.patch_id!r}: add it to `patches` first (a synthetic "
                          f"patch such as walls has area 0), or target one of {sorted(role_of)}")
        if lt.n_layers == 0:
            if lt.first_cell_height != 0:
                errors.append(f"layer target {lt.patch_id}: n_layers 0 means no layers; first_cell_height must then be 0")
            continue
        if role_of.get(lt.patch_id) in NO_LAYER_ROLES:
            errors.append(f"layer target {lt.patch_id}: patch role is {role_of[lt.patch_id]!r}; layers grow from walls only, so name the "
                          "wall patch (walls, body, or the user's wall name) and put the bore you sized from in reason")
        if not _plausible_first_cell(lt.first_cell_height, ledger):
            errors.append(f"layer target {lt.patch_id}: first_cell_height {lt.first_cell_height} is outside 1e-5 to 0.02 of every measured length"
                          + _untraced(lt.first_cell_height, ctx))
        if not lt.reason.strip():
            errors.append(f"layer target {lt.patch_id}: reason is required (how the first cell was sized)")
        if not (1 <= lt.n_layers <= 60):
            errors.append(f"layer target {lt.patch_id}: n_layers {lt.n_layers} out of range (0 = no layers on this patch)")
    if plan.purpose == "external_cfd":
        bad = [k for k in mp.required_extents if k not in EXTENT_KEYS]
        if bad:
            errors.append(f"required_extents has keys {bad}; external flow uses exactly {list(EXTENT_KEYS)} (absolute lengths, standard multiples of the body length)")
        absent = [k for k in REQUIRED_EXTENT_KEYS if k not in mp.required_extents]
        if absent:
            errors.append(f"required_extents is missing {absent} for an external case")
        # R35: the magnitude, checked after R29 has read the keys and after the unit is settled. A far field the
        # handover turns into a domain_margin of 0.0 is not a far field, and until now nothing looked
        for row in _extent_rows(mp.required_extents, facts, _plan_unit(plan, ctx)):
            if not row["in_band"]:
                errors.append(_extent_message(row, _plan_unit(plan, ctx)))
    elif mp.required_extents:
        errors.append("required_extents is only for external flow; internal cases leave it empty and put every stub extension in "
                      "port_extensions [{patch_id, length, reason}]")
    for k, v in mp.required_extents.items():
        if not _derivable(v, ledger):
            errors.append(f"required_extents[{k}]={v} is not derivable from a measurement" + _untraced(v, ctx))
    for pe in mp.port_extensions:
        if role_of.get(pe.patch_id) not in ("inlet", "outlet"):
            errors.append(f"port_extensions names {pe.patch_id!r}, whose role is {role_of.get(pe.patch_id)!r}; only an inlet or outlet is extended")
        if not _derivable(pe.length, ledger):
            errors.append(f"port_extensions {pe.patch_id}: length {pe.length} is not derivable from a measurement (5 x the port's hydraulic diameter is)"
                          + _untraced(pe.length, ctx))
    _check_region_roles(plan, ctx, errors)
    if mp.seed_point is not None and not _anchored(mp.seed_point, facts, ledger, plan):
        errors.append(f"mesh_plan.seed_point {list(mp.seed_point)} is not within half a bore of a port centroid or a measured axis; "
                      "put it just inside the inlet along its inward normal")


def _check_region_roles(plan: GeometryPlan, ctx: ToolContext, errors: list[str]) -> None:
    facts = ctx.facts
    mp = plan.mesh_plan
    region_ids = [r.id for r in facts.regions]
    listed = [r.id for r in mp.regions]
    if len(listed) != len(set(listed)):
        errors.append("mesh_plan.regions lists a region twice")
    for r in mp.regions:
        if r.id not in region_ids:
            errors.append(f"mesh_plan.regions names {r.id!r}, which is not a measured region {region_ids[:12]}")
    if len(region_ids) <= REGION_ROLES_MAX:
        absent = [rid for rid in region_ids if rid not in listed]
        if absent:
            errors.append(f"mesh_plan.regions needs a role for every body: missing {absent} (fluid, solid, void, obstacle, rotating_zone, "
                          "or not_a_fluid_body when the file is the wall and the fluid must be extracted first)")
    roles = {r.role for r in mp.regions}
    if plan.purpose == "internal_cfd" and mp.regions and not ({"fluid", "wall_shell", "not_a_fluid_body"} & roles):
        errors.append("internal flow needs a region with role fluid, or wall_shell when the file is the wall the cavity is carved from, "
                      "or not_a_fluid_body when nothing can be carved")
    if "wall_shell" in roles and not any(r.kind in ("wall_shell_to_carve", "solid_wall_representation") for r in plan.risks):
        errors.append("a wall_shell region needs the catalog's wall_shell_to_carve (or solid_wall_representation) risk: the file must measure as a wall with open ring ports")
    if plan.purpose == "conjugate_heat_transfer" and mp.regions and not ({"fluid", "solid"} <= roles):
        errors.append("conjugate heat transfer needs at least one fluid region and one solid region in mesh_plan.regions")
    rotor_names = [x.name for x in facts.names if x.implied_role == "rotating_zone"]
    if "rotating_zone" in roles and not rotor_names and not any(r.kind == "rotor_topology" for r in plan.risks):
        errors.append("a rotating_zone region needs a rotor: a rotor_topology risk or a rotating-zone name in the file")
    if "not_a_fluid_body" in roles and not any(r.kind == "solid_wall_representation" for r in plan.risks) \
            and not any(r.detected_by == "agent" and r.requires_user_decision and re.search(r"fluid|wall", r.kind) for r in plan.risks):
        errors.append("not_a_fluid_body needs the solid_wall_representation risk or an agent risk (with a question) saying the file is the wall"
                      + ("; under an external purpose a body the far-field flow goes around is role obstacle, never not_a_fluid_body"
                         if plan.purpose in EXTERNAL_PURPOSES else
                         "; a body the flow goes around inside a fluid domain is role obstacle"))


def _check_questions(plan: GeometryPlan, ctx: ToolContext, role_of: dict[str, str], errors: list[str]) -> None:
    facts = ctx.facts
    risk_by_id = {r.id: r for r in plan.risks}
    patch_by_id = {p.id: p for p in plan.patches}
    for q in plan.questions:
        if q.relates_to not in risk_by_id and q.relates_to not in role_of and q.relates_to not in {"unit", "purpose", "fidelity", "identity"}:
            # A QUESTION ABOUT THE FLOW DIRECTION HAS A HOME AND THE MESSAGE NAMES IT. On tee_wall_flanged_filleted
            # (live, 2026-09-26) the analyst wrote relates_to 'flow direction' twice, wanting to put the direction to
            # the user, and was twice told only what the field is not. There is no 'direction' target and adding one
            # would mean a new answer kind at every boundary downstream; the role risk on the mouths IS that question,
            # which is why R11 (`_direction_is_asked`) reads it as the direction being asked.
            hint = ""
            if DIRECTION_WORDS.search(q.relates_to or ""):
                role_ids = [r.id for r in plan.risks if r.kind in ROLE_DECISION_KINDS]
                hint = (". A question about which way the flow runs relates_to the role risk on those mouths"
                        + (f" ({', '.join(role_ids)})" if role_ids else
                           " (add it from list_risks: role_assumed or undeclared_opening)")
                        + ", or the patch id of the mouth in doubt; there is no 'direction' target")
            errors.append(f"question {q.id} relates_to {q.relates_to!r}, which is not a risk id, patch id, or one of "
                          f"unit/purpose/fidelity/identity{hint}")
        for rid in q.also_settles:
            if rid not in risk_by_id:
                errors.append(f"question {q.id}: also_settles names {rid!r}, which is not a risk id")
        blocking = any(risk_by_id[rid].severity == "blocking" for rid in [q.relates_to, *q.also_settles] if rid in risk_by_id)
        if not q.options:
            errors.append(f"question {q.id}: options are required")
        for opt in q.options:
            if BAD_OPTION.search(opt):
                errors.append(f"question {q.id}: option {opt!r} is not an answer the plan can record; every option is a role for a named "
                              "opening, one of continue / fix / change purpose / abort in those words, a unit, or a purpose")
        if JARGON.search(q.text) or any(JARGON.search(o) for o in q.options):
            errors.append(f"question {q.id}: written for an engineer who has not seen the tool: no checker, detector, catalog or class "
                          "names, no 'Ask:'; say straight run, not stub; locate openings ('o2, the +x end')")
        unit_question = q.relates_to == "unit" or (q.relates_to in risk_by_id and risk_by_id[q.relates_to].kind in UNIT_QUESTION_KINDS)
        if plan.schema_version >= V3 and unit_question and LENGTH_WITH_UNIT.search(q.text):
            # prompt v2 said it inline; schema 3 enforces it: a question that asks what the unit is cannot quote a length in one
            errors.append(f"question {q.id}: a unit question quotes a length with a unit ({LENGTH_WITH_UNIT.search(q.text).group(0)!r}); "
                          "quote file numbers as 'in file units' and let the options carry the units")
        if q.default is None:
            if not blocking:
                errors.append(f"question {q.id}: every non-blocking question carries a `default`, the option you would choose")
        else:
            d = q.default.strip().lower()
            if not any(d == o.strip().lower() or d in o.lower() or o.lower() in d for o in q.options):
                errors.append(f"question {q.id}: default {q.default!r} is not one of its options")
        target = q.relates_to
        asked_patch = None
        if target in patch_by_id and target in {o.id for o in facts.openings}:
            asked_patch = patch_by_id[target]
        elif target in risk_by_id and risk_by_id[target].kind in ("undeclared_opening", "role_assumed"):
            oid = risk_by_id[target].measurement.get("opening_id")
            asked_patch = patch_by_id.get(oid) if oid else None
            if risk_by_id[target].kind == "role_assumed" and plan.flow.confidence > ASKED_CONFIDENCE_MAX:
                errors.append(f"flow.confidence {plan.flow.confidence} while question {q.id} asks the flow direction; a direction you ask "
                              f"about is never above {ASKED_CONFIDENCE_MAX}")
        if asked_patch is not None and asked_patch.confidence > ASKED_CONFIDENCE_MAX:
            errors.append(f"patch {asked_patch.id}: confidence {asked_patch.confidence} while question {q.id} asks its role; a role you ask "
                          f"the user to confirm is never above {ASKED_CONFIDENCE_MAX}")
    # two questions asking one decision about one opening: a role asked twice, a kind asked twice
    feature_of: dict[tuple[str, str], str] = {}
    for q in plan.questions:
        r = risk_by_id.get(q.relates_to)
        if r is not None:
            decision = "role" if r.kind in ROLE_DECISION_KINDS else r.kind
            ids = _role_ids(r) if decision == "role" else _ids_in(r.measurement)
        elif q.relates_to in patch_by_id:
            decision, ids = "role", {q.relates_to}
        else:
            continue
        for oid in sorted(ids):
            key = (decision, oid)
            if key in feature_of and feature_of[key] != q.id:
                errors.append(f"questions {feature_of[key]} and {q.id} both ask the {decision} decision for {oid}; keep one and list "
                              "the other risk in its also_settles")
                break
            feature_of.setdefault(key, q.id)
    asked = {q.id for q in plan.questions}
    for r in plan.risks:
        # R34: a risk may name its own question (`question_id`) as well as a question naming the risk
        if r.requires_user_decision and r.user_decision == "pending" \
                and not any(r.id == q.relates_to or r.id in q.also_settles for q in plan.questions) \
                and r.question_id not in asked:
            errors.append(f"risk {r.id} ({r.kind}) requires a user decision but no question relates to it")


def _check_unit(plan: GeometryPlan, ctx: ToolContext, errors: list[str]) -> None:
    facts = ctx.facts
    u = plan.unit
    declared = facts.units.declared
    if (u.declared or None) != (declared or None):
        errors.append(f"unit.declared must be {declared!r} (what the file says), got {u.declared!r}")
    plausible = facts.units.plausible_for_purpose.get(ctx.purpose, [])
    if u.assumed not in UNIT_WORDS:
        errors.append(f"unit.assumed {u.assumed!r} is not one of {sorted(UNIT_WORDS)}")
    elif declared and u.assumed != declared and u.basis != "user":
        errors.append(f"unit.assumed {u.assumed!r} contradicts the declared unit {declared!r}; only the user can override it (basis user)")
    elif not declared and plausible and u.assumed not in plausible:
        errors.append(f"unit.assumed {u.assumed!r} is not plausible for {ctx.purpose} at this size; plausible: {plausible}")
    if u.basis == "file" and not declared:
        errors.append("unit.basis 'file' but the file declares no unit; use brief, user or guess")
    brief_has_unit = re.search(r"\b(mm|millimet\w*|cm|centimet\w*|m|met(?:re|er)s?|in|inch(?:es)?|ft|feet|foot)\b", ctx.brief or "", re.I)
    if u.basis in ("brief", "user") and not brief_has_unit and not ctx.declared:
        errors.append(f"unit.basis {u.basis!r} but the brief names no unit; use guess and ask")
    if u.basis == "guess":
        unit_risk = next((r.id for r in plan.risks if r.kind == "unit_unknown"), None)
        if not any(q.relates_to in ("unit", unit_risk) for q in plan.questions):
            errors.append("unit.basis 'guess' needs a question (relates_to unit or the unit_unknown risk) with the guess as its default")
    # R20 (P4.3b): _normalise prepends the exact opening the rule asks for when the prose has none, so what is
    # left to reject is prose that opens with a unit contradicting the plan's own.
    sb = plan.summary_for_builder
    head = BUILDER_UNIT_OPENING.match(sb) if sb.strip() else None
    if head is not None and _unit_word(head.group(1)) != u.assumed:
        want = f"Unit: {u.assumed}, declared by the file" if facts.units.declared else f"Unit: assumed {u.assumed}, unconfirmed"
        errors.append(f"summary_for_builder opens with 'Unit: {head.group(1)}' but every size in the plan is in {u.assumed} "
                      f"(unit.assumed); write the opening as {want!r}, or change unit.assumed")


def _around(text: str, hit: re.Match, pad: int = 30) -> str:
    """The clause a picture word sits in, so a message about a 600-character summary points at the words that
    tripped it rather than at the first sixty characters of the field."""
    a, b = max(0, hit.start() - pad), min(len(text), hit.end() + pad)
    return ("..." if a else "") + text[a:b].strip() + ("..." if b < len(text) else "")


def _evidence_entries(plan: GeometryPlan) -> list[tuple[str, str]]:
    """Every evidence list in the plan, as (pointer, string). Identity, each patch's role, and the flow: the three
    places the plan states why it believes what it believes about what the geometry IS."""
    out = [(f"object.evidence[{i}] (/object/evidence/{i})", ev) for i, ev in enumerate(plan.object.evidence)]
    out += [(f"patch {p.id}.evidence[{j}] (/patches/{i}/evidence/{j})", ev)
            for i, p in enumerate(plan.patches) for j, ev in enumerate(p.evidence)]
    out += [(f"flow.evidence[{i}] (/flow/evidence/{i})", ev) for i, ev in enumerate(plan.flow.evidence)]
    return out


def _reason_entries(plan: GeometryPlan) -> list[tuple[str, str]]:
    """Every sentence that justifies something the builder or the user acts on. A question's wording is not here
    on purpose: the look is allowed to improve how a question reads (the tool description says so), a question is
    a thing asked of a person rather than a claim made to the builder, and "visual impression: is o2 a closed
    end?" is not a question anyone would answer."""
    mp = plan.mesh_plan
    out = [(f"refinement {r.where[:40]!r} reason (/mesh_plan/refinement_regions/{i}/reason)", r.reason)
           for i, r in enumerate(mp.refinement_regions)]
    out += [(f"layer target {lt.patch_id} reason (/mesh_plan/layer_targets/{i}/reason)", lt.reason)
            for i, lt in enumerate(mp.layer_targets)]
    out += [(f"port extension {e.patch_id} reason (/mesh_plan/port_extensions/{i}/reason)", e.reason)
            for i, e in enumerate(mp.port_extensions)]
    out += [(f"mesh_plan.assumptions[{i}] (/mesh_plan/assumptions/{i})", a) for i, a in enumerate(mp.assumptions)]
    out += [(f"region {r.id} reason (/mesh_plan/regions/{i}/reason)", r.reason) for i, r in enumerate(mp.regions)]
    for i, r in enumerate(plan.risks):
        if r.detected_by != "agent":
            continue
        for field in ("consequence", "recommendation", "derivation", "refuted_by"):
            out.append((f"agent risk {r.kind}.{field} (/risks/{i}/{field})", str(getattr(r, field) or "")))
    for i, w in enumerate(plan.mesh_warnings or []):
        out.append((f"mesh_warnings[{i}].why (/mesh_warnings/{i}/why)", w.why or ""))
    out.append(("summary_for_builder (/summary_for_builder)", plan.summary_for_builder))
    return out


def _check_vision_citations(plan: GeometryPlan, errors: list[str]) -> None:
    """Anywhere the plan leans on a picture it says so in the same words, so a reader can tell an impression from
    a measurement at a glance.

    Two forms, because the fields read differently. An entry of an evidence list must OPEN with
    'visual impression: ' (the rule the P4.1 checker already applied to `object.evidence`, and an evidence list is
    a list of citations, so the citation belongs at the front). A sentence that justifies something the builder or
    the user acts on need only carry the words 'visual impression' somewhere in it.

    With the look taken on every run this is the rule that keeps the discipline honest: the impression is always
    present, so the only thing separating what was seen from what was measured is that a claim from the picture is
    labelled wherever it lands."""
    for tag, ev in _evidence_entries(plan):
        if VISION_CITE.search(ev) and not ev.strip().lower().startswith(VISION_PREFIX):
            errors.append(f"{tag} cites a picture ({ev[:60]!r}); write it as '{VISION_PREFIX} ...' so the reader can tell it "
                          "from a measurement")
    for tag, text in _reason_entries(plan):
        hit = VISION_CITE.search(text)
        if hit is not None and VISION_MARK not in text.lower():
            errors.append(f"{tag} cites a picture ({_around(text, hit)!r}) without saying so; a look settles nothing on its own, so "
                          f"name it in the sentence ('{VISION_MARK}: ...') or write the measurement that carries the claim")


# ---------------------------------------------------------------------------------------------------------------
# Derived numbers (checker v3 R3b in its P4.1 form) and the counterfactual (R11, light form). A derived value that
# cites a derivation id must be the number the tool recorded under it; one that cites none is recomputed for the
# formulas the checker knows (dead leg from the stubs, taper half angle, mouth tilt, first cell from the plan's own
# inputs) and rejected when over DERIVED_MATCH_BAND off. A first cell is held to the smallest port bore and to the
# number its own reason states. A dead leg whose closed end is upstream of the junction is rejected by name.
# ---------------------------------------------------------------------------------------------------------------
#: A first cell lies within this band of the smallest port bore (a 0.35 micron first cell in an mm plan passed before).
#: The dev plan wrote 2e-2 for the top; 5e-2 because the tool's own y+ 100 first cell on a 20 mm bore at 2 m/s is
#: 4.7 percent of that bore (the recorded plans hold two such), and a unit slip is a thousand times off, not 2.5.
FIRST_CELL_OVER_BORE = (1e-4, 5e-2)
KNOWN_DEAD_LEG = re.compile(r"dead_?leg", re.I)
KNOWN_HALF_ANGLE = re.compile(r"half_?angle|cone_?angle|taper_?angle", re.I)
KNOWN_AREA_RATIO = re.compile(r"area_?ratio", re.I)
KNOWN_TILT = re.compile(r"tilt", re.I)
KNOWN_FIRST_CELL = re.compile(r"first_?cell|first_?layer|\by1\b|wall_?distance", re.I)
_LENGTH_UNIT = r"(mm|cm|um|µm|μm|microns?|micrometres?|micrometers?|m|in|inch(?:es)?|ft)"
_NUM = r"(-?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?)"
#: The number a layer target's reason states as the first cell, with its unit ("first cell 0.05 mm", "0.05 mm first
#: layer"). Between the words and the number only a short filler that names no other length and crosses no clause
#: boundary: "first cell sized from the 25 mm nozzle bore", "(2 m/s, 41.16 mm bore); first cell = y+ nu / u_tau" and
#: "L = 1.044 m; placeholder first cell" state no first cell (six recorded plans were rejected on such a bore).
_FIRST_CELL_WORDS = r"(?:first[ _-]?cell(?:[ _-]?height)?|first[ _-]?layer(?:[ _-]?(?:height|thickness))?|cell[ _-]?height|layer[ _-]?height|\by1\b|\bdy\b|Δy)"
_OTHER_LENGTH = r"\b(?:bore|diameter|D|Dh|D_h|L|extent|run|branch|port|inlet|outlet|nozzle|Re|Re_L|chord|length|radius|gap|span|width)\b"
_FILLER_AFTER = r"(?:(?!" + _OTHER_LENGTH + r")[^0-9;.]){0,40}?"
_FILLER_BEFORE = r"[\s()]*(?:(?:as|for|the|a|an|is|of)\s+){0,3}"
FIRST_CELL_IN_REASON = (
    re.compile(_FIRST_CELL_WORDS + _FILLER_AFTER + _NUM + r"\s*" + _LENGTH_UNIT + r"(?![\w/])", re.I),
    re.compile(_NUM + r"\s*" + _LENGTH_UNIT + r"(?![\w/])" + _FILLER_BEFORE + _FIRST_CELL_WORDS, re.I),
)
#: Where a stated input hides: a dict key, or a label in the derivation or reason text ("U = 2 m/s", "y+ 30", "nu 1e-6").
INPUT_KEYS = {"velocity": ("velocity", "u", "speed", "inlet_velocity", "u_inlet", "v"),
              "nu": ("nu", "kinematic_viscosity", "viscosity"),
              "yplus": ("yplus", "y_plus", "y+", "yplus_target", "y_plus_target", "target_yplus"),
              "bore": ("bore", "hydraulic_diameter", "bore_diameter", "d", "diameter", "d_h", "dh")}
INPUT_TEXT = {"velocity": re.compile(r"(?:\bU\b|\bvelocity\b|\bspeed\b)\s*(?:=|~|:|of|at)?\s*" + _NUM + r"\s*m\s*/\s*s", re.I),
              "nu": re.compile(r"(?:\bnu\b|ν|kinematic viscosity)\s*(?:=|~|:|of)?\s*" + _NUM, re.I),
              #: "y+ 50-100" states a range: both ends are read, and any y+ between them is the model's choice
              "yplus": re.compile(r"y\s*\+\s*(?:=|~|:|of|target)?\s*(?:~|about)?\s*" + _NUM + r"(?:\s*(?:-|to)\s*" + _NUM + r")?", re.I),
              #: "D = 0.392 m" in an mm plan is 392 mm: the unit after the bore is read and converted ("in" is a
              #: preposition too often to be a unit here; "inch" is)
              "bore": re.compile(r"(?:\bbore\b|\bD_?h?\b|hydraulic diameter|\bdiameter\b)\s*(?:=|~|:|of)?\s*" + _NUM
                                 + r"(?:\s*(mm|cm|um|µm|μm|microns?|m|ft|inch(?:es)?)(?![\w/^]))?", re.I)}


def _within(a: float, b: float, band: float = DERIVED_MATCH_BAND, abs_tol: float = 1e-9) -> bool:
    if abs(a - b) <= abs_tol:
        return True
    return b != 0 and abs(a / b - 1.0) <= band


def _derivation_numbers(rec: dict) -> dict[str, float]:
    """Every numeric value a derivation recorded, flattened (a seed point becomes seed_point[0..2])."""
    out: dict[str, float] = {}

    def walk(key: str, v: Any) -> None:
        if isinstance(v, bool):
            return
        if isinstance(v, (int, float)) and math.isfinite(float(v)):
            out[key] = float(v)
        elif isinstance(v, (list, tuple)):
            for i, x in enumerate(v):
                walk(f"{key}[{i}]", x)
        elif isinstance(v, dict):
            for k, x in v.items():
                walk(f"{key}.{k}", x)
    for k, v in (rec.get("values") or {}).items():
        walk(k, v)
    return out


def _cited_close(a: float, b: float) -> bool:
    """A cited value against the recorded one: relative within REL_TOL, never _close's absolute band, which would
    let a first cell of 3e-7 match a recorded nu of 1e-6."""
    if a == b:
        return True
    if b == 0:
        return abs(a) < 1e-12
    return abs(a / b - 1.0) < REL_TOL


def _round_sig(x: float, n: int) -> float:
    return float(f"{x:.{n}g}")


def _cited_equal(written: float, recorded: float) -> bool:
    """R16: a cited value is the recorded one when it is within REL_TOL of it, or equals it rounded to three or
    four significant figures (CITED_SIG_FIGS): 1.113 and 1.11 for a recorded 1.1127 are the recorded value, 1.13
    (a percent and a half off) is not."""
    if _cited_close(written, recorded):
        return True
    return any(abs(written - _round_sig(recorded, n)) <= 1e-9 * max(1.0, abs(written)) for n in CITED_SIG_FIGS)


def _si_in_plan_unit(rec: dict, unit: str | None) -> dict[str, float]:
    """The metre-valued scalars a derivation recorded (first_cell_height_m, bore_m: every `*_m` key), converted
    into the plan's unit: a plan in mm citing a first_cell computed in metres writes 1.2386 for a recorded
    first_cell_height_m of 0.0012386, the same length. Empty when the plan's unit is unknown."""
    from geometry_agent.agent.tools import UNIT_TO_M
    if unit not in UNIT_TO_M:
        return {}
    return {k: v / UNIT_TO_M[unit] for k, v in _derivation_numbers(rec).items() if k.endswith("_m")}


def _cites_ok(value: float, ids: list[str], ctx: ToolContext, key: str | None = None, unit: str | None = None) -> tuple[bool, str]:
    """Whether `value` is a number recorded under one of the cited derivation ids, else why not. A value is the
    recorded number when it is within REL_TOL of it or equals it rounded to three or four significant figures
    (_cited_equal), and, with the plan's `unit` given, when it equals a metre-valued scalar of the derivation
    (`*_m`) converted into that unit (R16: the P4.1 run's rejected first cells were the tool's metres value
    written in the plan's millimetres, the same length). The message lists the recorded scalars first, the one
    named like `key` ahead of them, the metre values converted into the plan's unit, and never uses the bare
    word derivation, which tools.error_pointer reads as the risk's `derivation` field."""
    unknown = [i for i in ids if i not in ctx.ledger.derivations]
    if unknown:
        return False, (f"{', '.join(unknown)} is not an id derived_geometry or compare_roles returned in this run (they return d1, d2, ...; "
                       f"this run has {sorted(ctx.ledger.derivations, key=lambda s: int(s[1:])) or 'none'})")
    for i in ids:
        rec = ctx.ledger.derivations[i]
        if any(_cited_equal(value, v) for v in _derivation_numbers(rec).values()):
            return True, ""
        if any(_cited_equal(value, v) for v in _si_in_plan_unit(rec, unit).values()):
            return True, ""

    def ordered(rec: dict) -> list[tuple[str, float]]:
        nums = _derivation_numbers(rec)
        return sorted(nums.items(), key=lambda kv: ("[" in kv[0], kv[0] != key))[:8]

    def converted(rec: dict) -> str:
        si = _si_in_plan_unit(rec, unit)
        if not si:
            return ""
        return " (" + ", ".join(f"{k[:-2]} {v:.6g} {unit} in the plan's unit" for k, v in sorted(si.items(), key=lambda kv: kv[0] != "first_cell_height_m")[:2]) + ")"

    shown = "; ".join(f"{i} ({ctx.ledger.derivations[i]['op']}) recorded "
                      + ", ".join(f"{k}={v:.6g}" for k, v in ordered(ctx.ledger.derivations[i])) + converted(ctx.ledger.derivations[i])
                      for i in ids)
    return False, (f"{shown}; the written value {value:.6g} is none of these (to four significant figures); write the recorded value "
                   "(in the plan's unit) or cite the id that produced this one")


#: What a stated input can plausibly be, in SI: outside these the number next to the label is something else (the
#: "2" in "Re = U D / nu = 2 x 0.036 / 1e-6" is the velocity, not nu) and the recompute is skipped, never wrong.
INPUT_BOUNDS = {"velocity": (1e-3, 500.0), "nu": (1e-8, 1e-3), "yplus": (0.1, 5000.0), "bore": (0.0, math.inf)}


def _find_input(name: str, dicts: list[dict], texts: list[str]) -> float | None:
    """A stated input by its usual keys, then by its label in the text; the first plausible one wins."""
    keys = INPUT_KEYS[name]
    lo, hi = INPUT_BOUNDS[name]
    for d in dicts:
        for k, v in (d or {}).items():
            if isinstance(k, str) and k.lower() in keys and isinstance(v, (int, float)) and not isinstance(v, bool) and lo < v <= hi:
                return float(v)
    for t in texts:
        for m in INPUT_TEXT[name].finditer(t or ""):
            try:
                v = float(m.group(1))
            except ValueError:
                continue
            if lo < v <= hi:
                return v
    return None


def _yplus_values(dicts: list[dict], texts: list[str]) -> list[float]:
    """Every y+ the plan states: a dict key, then each mention in the text with both ends of a range ("y+ 50-100"),
    because the model picks its y+ inside the range it quotes."""
    out: list[float] = []
    lo, hi = INPUT_BOUNDS["yplus"]
    v = _find_input("yplus", dicts, [])
    if v is not None:
        out.append(v)
    for t in texts:
        for m in INPUT_TEXT["yplus"].finditer(t or ""):
            for g in (m.group(1), m.group(2)):
                try:
                    x = float(g) if g else None
                except ValueError:
                    x = None
                if x and lo < x <= hi and x not in out:
                    out.append(x)
    return out


def _find_bore(dicts: list[dict], texts: list[str], unit: str) -> float | None:
    """The bore the plan sized from, in the plan's unit: a dict key (measured, so already in file units), else the
    first number after bore, D, Dh or diameter in the text, converted when it carries its own unit ("D = 0.392 m"
    in an mm plan is 392 mm; read as 0.392 mm it rejected a correct first cell)."""
    from geometry_agent.agent.tools import UNIT_TO_M, _unit_name
    v = _find_input("bore", dicts, [])
    if v is not None:
        return v
    for t in texts:
        m = INPUT_TEXT["bore"].search(t or "")
        if not m:
            continue
        try:
            v = float(m.group(1))
        except ValueError:
            continue
        if v <= 0:
            continue
        u = _unit_name(m.group(2)) if m.group(2) else None
        return v * UNIT_TO_M[u] / UNIT_TO_M[unit] if u else v
    return None


def _first_cell_band(bores: list[float], velocity: float, nu: float, ypluses: list[float], unit: str) -> tuple[float, float]:
    """The first cells the stated inputs admit: over the bores given, every stated y+ and both skin-friction laws
    (tools.CF_LAWS). A hand-computed value inside this envelope, within DERIVED_MATCH_BAND, is the model's own
    arithmetic done right whichever textbook it used; a unit slip is a thousand times outside it."""
    from geometry_agent.agent.tools import CF_LAWS, first_cell_of
    hs = [first_cell_of(b, velocity, nu, y, unit, law)["first_cell_height"] for b in bores for y in ypluses for law in CF_LAWS]
    return min(hs), max(hs)


def _in_band(h: float, band: tuple[float, float]) -> bool:
    lo, hi = band
    return lo * (1.0 - DERIVED_MATCH_BAND) <= h <= hi * (1.0 + DERIVED_MATCH_BAND)


def _band_words(band: tuple[float, float], unit: str) -> str:
    lo, hi = band
    return f"{lo:.4g} {unit}" if _within(lo, hi, band=1e-6) else f"{lo:.4g} to {hi:.4g} {unit}"


def _yplus_words(ypluses: list[float]) -> str:
    return f"{ypluses[0]:g}" if len(ypluses) == 1 else f"{min(ypluses):g} to {max(ypluses):g}"


def _taper_half_angles(ctx: ToolContext, pair: tuple[str, str], t: dict) -> list[float]:
    """The half angles a taper between two ports can be read as: from the two ports' own stub ends (the tool's
    number) and from any two stub ends on the run between the mouths. A flange ring's stub ends where the cone
    does while the outlet's own march to that flange is 0 long, so the ports' stub-end distance is the whole run
    and the model reading the cone off the ring's stub end is right."""
    facts = ctx.facts
    oa, ob = facts.opening(pair[0]), facts.opening(pair[1])
    pa, pb = [float(c) for c in oa.centroid], [float(c) for c in ob.centroid]
    chord = [pb[k] - pa[k] for k in range(3)]
    n = math.sqrt(sum(c * c for c in chord))
    angles = {float(t["half_angle_deg"])}
    if n <= 0:
        return sorted(angles)
    u = [c / n for c in chord]
    stations: set[float] = set()
    for s in facts.stubs:
        o = facts.opening(s.opening_id)
        if s.end_point and o is not None and o.region_id == oa.region_id:
            x = sum((float(s.end_point[k]) - pa[k]) * u[k] for k in range(3))
            if 0.0 <= x <= n:
                stations.add(round(x, 9))
    ordered = sorted(stations)
    half_diff = abs(float(t["bore_a"]) - float(t["bore_b"])) / 2.0
    for i, x1 in enumerate(ordered):
        for x2 in ordered[i + 1:]:
            if x2 > x1:
                angles.add(math.degrees(math.atan(half_diff / (x2 - x1))))
    return sorted(angles)


def _first_cell_in_reason(reason: str) -> tuple[float, str] | None:
    from geometry_agent.agent.tools import _unit_name
    for pat in FIRST_CELL_IN_REASON:
        m = pat.search(reason or "")
        if m:
            try:
                v = float(m.group(1))
            except ValueError:
                continue
            u = _unit_name(m.group(2))
            if u and v > 0:
                return v, u
    return None


def _plan_unit(plan: GeometryPlan, ctx: ToolContext) -> str:
    from geometry_agent.agent.tools import _file_unit, _unit_name
    return _unit_name(plan.unit.assumed) or _file_unit(ctx)[0]


def _recompute_dead_leg(plan: GeometryPlan, ctx: ToolContext, r: Risk) -> dict | None:
    """The dead leg a risk describes, from the stubs: the closed end is measurement.opening_id, the junction the
    opening measurement names (junction_id) or the port whose stub end lies nearest the closed end's mouth (the
    last junction before it), the supply the risk's inlet_id or the plan's first inlet."""
    from geometry_agent.agent.tools import dead_leg_of
    facts = ctx.facts
    m = r.measurement or {}
    closed = m.get("opening_id") or m.get("closed_end_id") or m.get("closed_end_opening")
    oc = facts.opening(str(closed)) if closed else None
    if oc is None:
        return None
    junction = m.get("junction_id") or m.get("junction_opening_id") or m.get("junction_opening")
    if not junction:
        ends = [(math.dist(s.end_point, oc.centroid), s.opening_id) for s in facts.stubs if s.end_point and s.opening_id != oc.id]
        if not ends:
            return None
        junction = min(ends)[1]
    inlet = m.get("inlet_id") or (plan.flow.inlet_ids[0] if plan.flow.inlet_ids else None)
    try:
        return dead_leg_of(ctx, str(junction), oc.id, str(inlet) if inlet else None)
    except ValueError:
        return None


def _taper_pair(ctx: ToolContext, r: Risk) -> tuple[str, str] | None:
    m = r.measurement or {}
    a, b = m.get("wide_id") or m.get("a"), m.get("narrow_id") or m.get("b")
    if a and b and ctx.facts.opening(str(a)) and ctx.facts.opening(str(b)):
        return str(a), str(b)
    ids = sorted(i for i in _ids_in(m) if ctx.facts.opening(i) is not None)
    return (ids[0], ids[1]) if len(ids) == 2 else None


def _check_derived(plan: GeometryPlan, ctx: ToolContext, errors: list[str]) -> None:
    from geometry_agent.agent.tools import mouth_tilt, taper_of
    for r in plan.risks:
        items = _derived_items(r)
        if not items:
            continue
        tag = f"agent risk {r.kind}" if r.detected_by == "agent" else f"risk {r.id} ({r.kind})"
        dead_leg: dict | None = None
        dead_leg_done = False
        for key, value, ids in items:
            if ids:
                ok, why = _cites_ok(value, ids, ctx, key, unit=_plan_unit(plan, ctx))
                if not ok:
                    errors.append(f"{tag}: derived {key}={value:.6g} cites {', '.join(ids)} but {why}")
                continue
            if KNOWN_DEAD_LEG.search(r.kind) or KNOWN_DEAD_LEG.search(key):
                if not dead_leg_done:
                    dead_leg, dead_leg_done = _recompute_dead_leg(plan, ctx, r), True
                    if dead_leg is not None and dead_leg["upstream"]:
                        errors.append(f"{tag}: {dead_leg['closed_end_opening']} lies upstream of the junction at {dead_leg['junction_opening']}'s "
                                      f"stub end ({dead_leg['behind_junction']:.4g} behind it against the supply from {dead_leg['inlet']}); "
                                      "the fluid there is the supply run, not a dead leg: drop this risk or name the closed end beyond the junction")
                if dead_leg is None or dead_leg["upstream"]:
                    continue
                L, over = dead_leg["dead_leg_length"], dead_leg["dead_leg_over_d"]
                # the closed end's own march to where its section changes is the same dead leg read from its mouth,
                # a junction's half-width shorter than the run from the neighbouring branch's stub end
                sc = ctx.facts.stub(dead_leg["closed_end_opening"])
                own = [sc.length, sc.length_over_diameter] if (sc is not None and sc.terminated_by in ("junction", "area_change")) else []
                if not any(_within(value, x) for x in (L, over, *own) if x is not None):
                    errors.append(f"{tag}: derived {key}={value:.6g} but the dead leg from {dead_leg['junction_opening']}'s stub end to "
                                  f"{dead_leg['closed_end_opening']} recomputes to {L:.4g} ({over:.4g} D of {dead_leg['closed_end_opening']}); "
                                  "over 5 percent off, take it from derived_geometry dead_leg and cite its id")
            elif KNOWN_HALF_ANGLE.search(key) or KNOWN_AREA_RATIO.search(key):
                pair = _taper_pair(ctx, r)
                if pair is None:
                    continue
                try:
                    t = taper_of(ctx, *pair)
                except ValueError:
                    continue
                if KNOWN_HALF_ANGLE.search(key):
                    if not any(_within(value, x, abs_tol=0.05) for x in _taper_half_angles(ctx, pair, t)):
                        errors.append(f"{tag}: derived {key}={value:.6g} but the taper between {pair[0]} and {pair[1]} recomputes to a half angle of "
                                      f"{t['half_angle_deg']:.4g} deg from the bores {t['bore_a']:.4g} and {t['bore_b']:.4g} over the stub-end distance "
                                      f"{t['taper_length']:.4g}; over 5 percent off, take it from derived_geometry taper")
                else:
                    ratios = (t["area_ratio_wide_over_narrow"], 1.0 / t["area_ratio_wide_over_narrow"])
                    if not any(_within(value, x) for x in ratios):
                        errors.append(f"{tag}: derived {key}={value:.6g} but the area ratio between {pair[0]} and {pair[1]} recomputes to "
                                      f"{ratios[0]:.4g} (or {ratios[1]:.4g} the other way); over 5 percent off, take it from derived_geometry taper")
            elif KNOWN_TILT.search(key):
                o = ctx.facts.opening(str((r.measurement or {}).get("opening_id") or ""))
                if o is None:
                    continue
                tilt = mouth_tilt(o)[0]
                if not _within(value, tilt, abs_tol=0.05):
                    errors.append(f"{tag}: derived {key}={value:.6g} but the mouth of {o.id} recomputes to {tilt:.4g} deg off its nearest grid axis; "
                                  "over 5 percent off, take it from derived_geometry port_tilt")
            elif KNOWN_FIRST_CELL.search(key):
                dicts = [r.measurement or {}, {k: v for k, v in (r.derived or {}).items() if k != key}]
                texts = [r.derivation or ""]
                unit = _plan_unit(plan, ctx)
                velocity, nu = _find_input("velocity", dicts, texts), _find_input("nu", dicts, texts)
                ypluses, bore = _yplus_values(dicts, texts), _find_bore(dicts, texts, unit)
                if velocity is None or nu is None or not ypluses or bore is None:
                    continue
                band = _first_cell_band([bore], velocity, nu, ypluses, unit)
                if not _in_band(value, band):
                    errors.append(f"{tag}: derived {key}={value:.6g} but its own inputs (bore {bore:.4g} {unit}, U {velocity:.4g} m/s, nu {nu:.4g} m^2/s, "
                                  f"y+ {_yplus_words(ypluses)}) recompute to {_band_words(band, unit)} by the log-law estimate (Cf from the flat-plate "
                                  "power law or Blasius); over 5 percent off, take it from derived_geometry first_cell")


def _check_first_cells(plan: GeometryPlan, ctx: ToolContext, errors: list[str]) -> None:
    """Every layer target's first cell: equal to the derivation it cites, within FIRST_CELL_OVER_BORE of the
    smallest port bore, equal to the number its own reason states (parsed with its unit), and, when the reason
    states U, nu and y+ without citing a derivation, equal to the log-law estimate from those inputs."""
    from geometry_agent.agent.tools import UNIT_TO_M, port_bore
    facts = ctx.facts
    rep = catalog.representation(facts, ctx.purpose, ctx.brief, declared=ctx.declared, fluid_side=ctx.fluid_side)
    bores = sorted((port_bore(o, rep), o.id) for o in catalog.port_openings(facts, rep, ctx.declared) if port_bore(o, rep) > 0)
    smallest = bores[0] if bores else None
    unit = _plan_unit(plan, ctx)
    lo, hi = FIRST_CELL_OVER_BORE
    for lt in plan.mesh_plan.layer_targets:
        if lt.n_layers == 0 or lt.first_cell_height <= 0:
            continue
        tag = f"layer target {lt.patch_id}"
        h = float(lt.first_cell_height)
        ids = list(dict.fromkeys(DERIVATION_ID.findall(lt.reason or "")))
        if ids:
            ok, why = _cites_ok(h, ids, ctx, "first_cell_height", unit=unit)
            if not ok:
                errors.append(f"{tag}: first_cell_height {h:.6g} cites {', '.join(ids)} but {why}")
        if smallest is not None:
            bore, oid = smallest
            if not (lo * bore <= h <= hi * bore):
                # the P4.1 run's band rejections were the tool's metres value written into a millimetre plan: ten
                # times or more outside a band 500 wide is that slip, and the message says so
                slip = (h < lo * bore * 0.1) or (h > hi * bore * 10.0)
                errors.append(f"{tag}: first_cell_height {h:.6g} is outside {lo:g} to {hi:g} of the smallest port bore {bore:.4g} ({oid}): "
                              f"{h / bore:.3g} of it; size it from that bore (derived_geometry first_cell)"
                              + (f"; ten times or more outside the band is a unit slip: the plan is in {unit}, the tool's "
                                 f"first_cell_height is in the unit its formula names and first_cell_height_m in metres; write the "
                                 f"first cell in {unit}" if slip else ""))
        stated = _first_cell_in_reason(lt.reason)
        if stated is not None:
            v, u = stated
            h_u = h * UNIT_TO_M[unit] / UNIT_TO_M[u]
            if not _within(h_u, v):
                errors.append(f"{tag}: first_cell_height {h:.6g} {unit} is {h_u:.4g} {u}, but its reason says {v:g} {u}; the number written in the "
                              "reason must be the first cell height (in the plan's unit or with its own)")
        if not ids:
            texts = [lt.reason or ""]
            velocity, nu = _find_input("velocity", [], texts), _find_input("nu", [], texts)
            ypluses, stated = _yplus_values([], texts), _find_bore([], texts, unit)
            # no bore stated: the model may have sized from any port, so the smallest to the largest bore is admitted
            bore_set = [stated] if stated else ([bores[0][0], bores[-1][0]] if bores else [])
            if bore_set and velocity is not None and nu is not None and ypluses:
                band = _first_cell_band(bore_set, velocity, nu, ypluses, unit)
                if not _in_band(h, band):
                    which = f"bore {stated:.4g} {unit}" if stated else f"the port bores {bores[0][0]:.4g} to {bores[-1][0]:.4g} {unit}"
                    errors.append(f"{tag}: first_cell_height {h:.6g} but the reason's own inputs ({which}, U {velocity:.4g} m/s, nu {nu:.4g} m^2/s, "
                                  f"y+ {_yplus_words(ypluses)}) recompute to {_band_words(band, unit)} by the log-law estimate (Cf from the flat-plate "
                                  "power law or Blasius); over 5 percent off, take it from derived_geometry first_cell and cite its id")


def _check_counterfactual(plan: GeometryPlan, ctx: ToolContext, expected: list[Risk], errors: list[str], hints: dict[str, Any]) -> None:
    """R11: the counterfactual is required when the direction is in doubt (role_assumed fires, a question asks a
    role, or a port role is under COUNTERFACTUAL_BELOW with no declared ports); it must then cite a ledger number
    (a number compare_roles or derived_geometry recorded, or its derivation id); and, with a brief that names no
    direction, an internal assignment carrying strictly more high risks than its swap under the catalog is priced
    with the diff - a warning when the direction is already a question the customer will answer, a rejection when
    nothing asks. Schema 2 (the light form): when role_assumed fires and the plan carries none, the result carries
    an info note in hints['warnings'], not a rejection.

    P4.4 (docs/plan_v3_rules.md 15.3, 15.4) moved the ledger-number clause under the requirement and made it a
    fill. It used to tax any counterfactual the plan carried: over `learning_v3_r3` that was 27 rejections on 22
    cases, and `_direction_in_doubt` was empty on every one of them, so the rule was charging a round for prose it
    had not asked for and no other rule leans on. Five of those cases were external bodies, where there is nothing
    to swap and the call the message named refuses an empty assignment, so the rejection could not be acted on at
    all. When the counterfactual IS required and cites no number the checker now prices the swap itself
    (`tools.role_swap_diff`, the comparison `compare_roles` runs, recorded in the ledger under a derivation id)
    and appends that sentence, the way `_fill_identity_tests` fills a refuting test. Schema 2 keeps the rejection:
    nothing fills a schema 2 plan.

    THE "STRICTLY WORSE" CLAUSE HAD BOTH DOORS SHUT (2026-09-26). It said: the brief names no direction, so swap
    the roles or cite the brief phrase that decides the direction. With a silent brief there IS no phrase, so the
    only satisfying move was the swap - and on the four cht and manifold parts driven live the roles it wanted
    swapped were the ones the platform's own proposal had settled, so a plan that swapped them was refused one
    boundary later by `contract.given` ("the plan calls o4 'wall' and the customer confirmed 'outlet'") and a plan
    that kept them was refused here. Two of the seven `grounding_rejected` runs on the batch were this rule.

    The clause exists because a reversed inlet is a silently wrong mesh, and the word that carries the weight is
    SILENTLY. When the direction is already a question on the confirmation screen (`_direction_is_asked`: a question
    settling a role decision on one of the mouths the swap would turn, or naming one of them, which `_normalise`
    guarantees for every pending role risk) the outcome is not silent: the customer sees which way round it runs,
    and the price of the other way is
    in `flow.counterfactual`, which this rule has just made sure of. So the finding becomes a warning and the plan
    keeps its assignment. Where nothing asks, it is still a rejection - now naming the third door as well as the
    two, so the model can put the direction to the user instead of renaming a mouth the survey settled."""
    from geometry_agent.agent import tools
    cf = plan.flow.counterfactual
    if cf is not None and not cf.swap.strip():
        errors.append("flow.counterfactual.swap must name the roles the other way round (which opening becomes the inlet)")
    fires = any(r.kind == "role_assumed" for r in plan.risks) or any(r.kind == "role_assumed" for r in expected)
    reasons = _direction_in_doubt(plan, ctx, fires)

    def uncited() -> bool:
        text = cf.what_breaks or ""
        ids = [i for i in DERIVATION_ID.findall(text) if i in ctx.ledger.derivations]
        return not ids and not [n for n in _numbers_in(text) if n != 0 and _measured(n, ctx.ledger.numbers)]

    if plan.schema_version < V3:
        if fires and cf is None:
            hints.setdefault("warnings", []).append(
                "info: role_assumed fires and flow.counterfactual is absent; call compare_roles with the roles swapped and write "
                "flow.counterfactual {swap, what_breaks} citing its numbers (not required under plan schema 2; required from schema 3)")
        if cf is not None and reasons and uncited():
            errors.append("flow.counterfactual.what_breaks cites no ledger number: quote a number from compare_roles or derived_geometry "
                          "(a severity sum, a dead leg, a seed point coordinate) or its derivation id")
        return
    if not reasons:
        return
    if cf is None:
        errors.append("flow.counterfactual is required: " + "; ".join(reasons) + ". Call compare_roles with the roles swapped and "
                      "write flow.counterfactual {swap, what_breaks} citing its numbers")
    diff = tools.role_swap_diff(ctx, {p.id: p.role for p in plan.patches}, plan.mesh_plan.fidelity)
    if cf is not None and uncited():
        if diff is None:
            errors.append("flow.counterfactual on a case with no inlet and no outlet has nothing to swap, so there is no comparison to "
                          "quote: leave flow.counterfactual out (compare_roles refuses an empty assignment)")
        else:
            cf.what_breaks = (cf.what_breaks or "").rstrip().rstrip(".") + ". " + diff["cites"]
            hints.setdefault("warnings", []).append(
                f"R11 repair: flow.counterfactual.what_breaks cited no ledger number, so the checker ran the comparison itself and "
                f"appended it ({diff['derivation_id']}): {diff['cites']}")
    if (diff is not None and ctx.purpose in INTERNAL and diff["high_risks_a"] > diff["high_risks_b"]
            and not DIRECTION_IN_BRIEF.search(ctx.brief or "") and not ctx.declared):
        priced = (f"the chosen assignment (inlets {diff['inlets']}, outlets {diff['outlets']}) carries "
                  f"{diff['high_risks_a']} high risk(s) {diff['high_kinds_a']} while the swap carries {diff['high_risks_b']} "
                  f"{diff['high_kinds_b']}")
        swapped = {str(i) for i in [*diff["inlets"], *diff["outlets"]]}
        asked = _direction_is_asked(plan, ctx, swapped)
        if asked is not None:
            hints.setdefault("warnings", []).append(
                f"R11: {priced}, and the brief names no direction; {asked}, so the direction is the customer's to settle and "
                f"the plan keeps its assignment. The price of the swap rides in flow.counterfactual ({diff['derivation_id']})")
        else:
            # THE THIRD DOOR IS NAMED BY ITS POINTER. `tee_wall_flanged_filleted` reached the warning branch on its
            # third submission and lost it on the fourth: told "flow.confidence 0.9 while question q1 asks the flow
            # direction", the analyst deleted the question instead of lowering the confidence, and nothing asked any
            # more. A message that says which risk to open is a message that road can be walked back from.
            role_risks = [r for r in plan.risks if r.kind in ROLE_DECISION_KINDS]
            at = ([f"/risks/{i}" for i, r in enumerate(plan.risks) if r.kind in ROLE_DECISION_KINDS]
                  or ["/risks"])
            which = (f"{role_risks[0].id} ({role_risks[0].kind}) at {at[0]}" if role_risks else
                     f"the role risk that covers {diff['inlets']} (/risks)")
            errors.append("flow.counterfactual: " + priced + "; the brief names no direction, so do ONE of three things: swap the "
                          "roles in patches and flow; cite the brief phrase that decides the direction in flow.evidence; or put "
                          "the direction to the user, by setting requires_user_decision true and user_decision pending on "
                          f"{which}, which the checker then turns into a question (and hold the asked role's confidence at or "
                          f"under {ASKED_CONFIDENCE_MAX:g} rather than dropping the question). Do not swap a role the survey "
                          "settled: raise it as the user's decision instead")


# ---------------------------------------------------------------------------------------------------------------
# Schema 3 (dev plan P4.2, docs/plan_v3_rules.md): the two outputs synthesised from the catalog, the false-alarm
# repair (R9), and the rules R2 to R12 that apply to schema 3 plans only. A schema 2 plan gets the two lists for
# free and is otherwise judged as before, so the stored transcripts change only through the lists.
# ---------------------------------------------------------------------------------------------------------------
V3 = 3
ANALYSIS_MAX_CHARS = 1500
#: summary_for_builder on schema 3 is at most this much prose (dev plan P4.2: the strategy header, generated by
#: hexera.strategy_header, plus at most 600 characters of prose; hexera.builder_block keeps the same 600).
BUILDER_PROSE_MAX_CHARS = 600
#: object.confidence over this needs a tests_run entry with a ledger number; over the second, the chosen type's
#: refuting test present and supporting (R2).
IDENTITY_TESTED_ABOVE = 0.8
IDENTITY_REFUTED_ABOVE = 0.9
#: An identity whose whole named support is the look cannot exceed this (dev plan P9: "vision-only evidence caps
#: object confidence at 0.6"; R38). The plan promised the cap and nothing implemented it. It matters more now the
#: look is taken on every run: a description the analyst always has is a description it will always lean on, and
#: what an impression may carry has to be bounded in code, not asked for in a prompt.
#:
#: The NUMBER and its reason live together in `vision/trust.py`, which is also what `trust.for_model` hands every
#: model downstream, so the checker here and what a consumer reads cannot disagree about the cap or about why it
#: is 0.6 rather than any other figure.
VISION_ONLY_CONFIDENCE_MAX = _vision_trust.IDENTITY_CONFIDENCE_MAX
#: A port role under this, with no declared ports, puts the direction in doubt: the counterfactual is required (R11).
COUNTERFACTUAL_BELOW = 0.9
HIGH_SEVERITIES = {"blocking", "high"}
INTERNAL = {"internal_cfd", "conjugate_heat_transfer"}
#: The effect of a question by what it relates to when no risk kind decides it (R8).
TARGET_EFFECT = {"unit": "changes_bc", "purpose": "changes_mesh", "fidelity": "changes_mesh", "identity": "changes_mesh"}
#: R9 (P4.4, docs/plan_v3_rules.md): a brief phrase settles a question only when it ANSWERS THAT QUESTION. A
#: phrase that names the question's subject settles nothing. "Fixed pressure outlet" is the boundary condition
#: that makes an undeveloped exit plane ill-posed, so it is the reason the warning matters, and it deleted the
#: short-stub question on 261 of the 322 export briefs until it was cut here. What settles a short-run question
#: is a brief that declines a geometry change. Each entry below names what it settles, in the message R9 quotes;
#: eval/live/false_alarm_patterns.json states the same test for the scorer, in its own code.
R9_SETTLES = {"short_stub": re.compile(r"geometry is final|as built|as-built|no geometry changes|"
                                       r"do not (?:modify|change|alter|extend)[^.]{0,30}geometr|"
                                       r"mesh (?:it )?as (?:supplied|provided|it is)", re.I),
              "symmetry_opportunity": re.compile(r"full 3d|no symmetry", re.I)}
R9_UNIT_IN_BRIEF = re.compile(r"\d+(?:\.\d+)?\s*(mm|millimet(?:re|er)s?|cm|m\b|met(?:re|er)s?|in\b|inch(?:es)?|ft|feet|foot)", re.I)
#: The engine and the fidelity tier are two questions and two answers. Naming the engine settles which mesher
#: runs; it says nothing about which tier, so a question about dropping the tier to fit the cap is not answered
#: by "Engine: snappyHexMesh" (which every export brief writes). The fidelity reading is tried first.
R9_ENGINE_QUESTION = re.compile(r"\b(engine|snappyhexmesh|snappy|gmsh|cfmesh)\b", re.I)
R9_ENGINE_IN_BRIEF = re.compile(r"engine\s*:\s*[a-z]+|\bengine is\b|snappyhexmesh|\bgmsh\b|\bcfmesh\b", re.I)
R9_FIDELITY_QUESTION = re.compile(r"\b(fidelity|tier|draft)\b", re.I)
R9_FIDELITY_IN_BRIEF = re.compile(r"\b(draft|standard|max)\b[^.\n]{0,20}\b(tier|fidelity)\b|\bfidelity\s*:?\s*(draft|standard|max)\b", re.I)
R9_SYMMETRY_QUESTION = re.compile(r"symmetr|half[- ]model|half the domain", re.I)
#: The role decision R9 can settle from a declaration. declared_port_unmatched is NOT one of them: that risk
#: fires because no measured opening matches the declaration, so a declared port at the opening cannot exist and
#: the question is a conflict between the brief and the file, never a re-ask.
R9_ROLE_KINDS = {"undeclared_opening", "role_assumed", "tiny_port"}
STUB_QUESTION_KINDS = {"short_stub", "short_inlet_run", "inlet_run_developing"}
UNIT_QUESTION_KINDS = {"unit_unknown", "unit_implausible"}
#: A brief that names the direction: the diff of R11 is not applied against it.
DIRECTION_IN_BRIEF = re.compile(r"\binlets?\b|\boutlets?\b|\bflow (?:from|into|enters|goes|is along|along)\b|\bupstream\b|\bdownstream\b|"
                                r"\bfeeds?\b|\bfed\b|\bsuppl(?:y|ied|ies)\b|\bdischarges?\b|\bexits?\b", re.I)
#: A brief that states an operating point: no assumption note is added for it.
OPERATING_POINT_IN_BRIEF = re.compile(r"m\s*/\s*s|reynolds|\bre\s*[=~:]|velocity|flow ?rate|kg\s*/\s*s|l\s*/\s*min|\bmach\b|\brpm\b|m3\s*/\s*h", re.I)
OPERATING_POINT_NOTE = ("operating point not given in the brief (velocity, fluid): the first cell is a placeholder sized as its "
                        "layer target's reason states; schema 3 carries this as an assumption, not as a risk")
#: A refinement region on a wall shell's metal names the thin skin (R7).
ON_THE_METAL = re.compile(r"\bthin\b|\bmetal\b|wall[- ]thickness|\bthickness\b|\bskin\b", re.I)
#: The second look (R10): the items the checker recomputes, by purpose, matched to the model's lines by these words.
SECOND_LOOK_ITEMS: dict[str, list[tuple[str, str]]] = {
    "internal": [("mouths", r"mouth|tilt|grid[- ]?align"), ("outlet_runs", r"outlet run|outlet stub|straight run|short stub|\b5 ?d\b|stub"),
                 ("seed", r"\bseed\b|locationinmesh"), ("smallest_port", r"smallest port|cells across|builder cell|port floor|resolution"),
                 ("metal", r"\bmetal\b|thickness|on the wall"), ("flow_axis", r"flow axis|principal axis|unit vector"),
                 ("first_cell", r"first cell|first layer|y\+|layer height")],
    "external": [("extents", r"extent|far[- ]?field|domain box|upstream|downstream"), ("ground", r"\bground\b|\bfloor\b|\broad\b"),
                 ("wake", r"\bwake\b"), ("knife_edges", r"knife|trailing edge|sharp edge")],
    "cht": [("interfaces", r"interface|shared|conformal|glued"), ("fluid_ports", r"fluid region|sealed|natural convection|\bports?\b")],
    "structural": [("no_flow", r"flow field|\binlet\b|\boutlet\b|flow axis"), ("no_layers", r"\blayer")],
}


def plan_version(plan_obj: Any) -> int:
    """The plan's schema version: schema_version when written, else the current version (the tool schema's default)."""
    v = plan_obj.get("schema_version") if isinstance(plan_obj, dict) else getattr(plan_obj, "schema_version", None)
    try:
        return int(v) if v is not None else PLAN_SCHEMA_VERSION
    except (TypeError, ValueError):
        return PLAN_SCHEMA_VERSION


def _tool_names() -> set[str]:
    """Every tool and derived op a refuting test or a refuted_by sentence may name."""
    from geometry_agent.agent import tools
    return set(tools.HANDLERS) | set(tools.DERIVED_OPS) | {tools.COMPARE_ROLES, tools.DERIVED}


def _tools_called(ctx: ToolContext, names: set[str] | None = None) -> list[str]:
    """The tools this run has actually called, derived ops included (R24: a message that asks for 'a tool of this
    run' names them). The whole vocabulary when the run has called nothing yet."""
    names = names if names is not None else _tool_names()
    called = {c for c in ctx.ledger.calls if c in names}
    called |= {str(d.get("op")) for d in ctx.ledger.derivations.values() if str(d.get("op")) in names}
    return sorted(called) or sorted(names)


def _numbers_of(obj: Any) -> list[float]:
    """Every number in a measurement (nested), booleans excluded."""
    if isinstance(obj, bool):
        return []
    if isinstance(obj, (int, float)):
        return [float(obj)] if math.isfinite(float(obj)) else []
    if isinstance(obj, dict):
        return [x for v in obj.values() for x in _numbers_of(v)]
    if isinstance(obj, (list, tuple)):
        return [x for v in obj for x in _numbers_of(v)]
    return []


def _plan_roles(plan_obj: dict[str, Any], facts) -> dict[str, str]:
    known = {o.id for o in facts.openings}
    return {p["id"]: p["role"] for p in plan_obj.get("patches") or []
            if isinstance(p, dict) and p.get("id") in known and isinstance(p.get("role"), str)}


#: R36's risks carry this in their `derivation`: the checker raised them from the plan's own refined estimate, so
#: `list_risks` could not have shown them (the plan did not exist when it ran) and the fill adds them rather than
#: leaving the plan to owe a risk it was never told about.
R36_DERIVATION = "checker R36:"


def _refined_cell_cap_risk(ctx: ToolContext, fidelity: str | None, refined: Any, regions: int,
                           expected: list[Risk]) -> Risk | None:
    """R36: the plan's own refinement set has a price, and nothing compared it to the customer's cap.

    The catalog's `cell_cap` rule reads the tier estimate (the chosen tier's `facts.cell_estimates` row), which
    knows nothing about the regions the plan then asks for; `budget_forecast` reads the emulator at the builder's
    DEFAULT strategy, which knows nothing about them either. So a plan could ask for a refinement set whose own
    refined estimate was 249 times the cap and no rule anywhere had a number to say it with. Over the 159
    learning-half plans of the v3 run the refined estimate was over the cap on 100 of them and 86 of those carried
    no `cell_cap` risk at all; the worst was 497,663,572 cells against a cap of 2,000,000.

    The risk is APPENDED to the catalog's own list, never inserted, so no catalog id renumbers and an id the model
    read from `list_risks` still means what it meant. It is raised only when the catalog raised no `cell_cap` of
    its own: when the catalog did, the plan owes that one already and `_check_risks` says so."""
    cap = ctx.cell_cap
    if not cap or not isinstance(refined, (int, float)) or isinstance(refined, bool) or refined <= cap:
        return None
    if any(e.kind == "cell_cap" for e in expected):
        return None
    est = next((e for e in ctx.facts.cell_estimates if e.tier == fidelity), None)
    base = int(est.cells) if est is not None else None
    used = {e.id for e in expected}
    n = 1
    while f"k{n}" in used:
        n += 1
    ratio = round(float(refined) / cap, 2)
    return Risk(
        id=f"k{n}", kind="cell_cap", severity="high", detected_by="catalog",
        measurement={"refined_estimate": int(refined), "cap": int(cap), "ratio": ratio, "fidelity": fidelity,
                     "tier_estimate": base, "cells_added_by_regions": (int(refined) - base) if base is not None else None,
                     "refinement_regions": int(regions), "frame": "agent surface cell"},
        # section 22's rule on the sentence section 22 was opened on: what was measured, what each answer gives
        # the reader, and not one control the reader does not have. Every number here is this risk's own
        # measurement; the finer mesh is named by where it was asked for, because `refinement_regions` is a list
        # in the plan and not something the customer can edit (docs/plan_v3_rules.md section 24.7)
        consequence=(f"Resolving this part the way the plan asks takes about {int(refined):,} cells and the budget you set "
                     f"is {int(cap):,}: "
                     + (f"{float(refined) / cap:,.0f}" if refined >= 10 * cap else f"{ratio:.2f}")
                     + " times it."
                     + (f" The part on its own needs {base:,}; "
                        + (f"the one place the mesh is asked to be finer adds the other {int(refined) - base:,}."
                           if int(regions) == 1 else
                           f"the {int(regions)} places the mesh is asked to be finer add the other "
                           f"{int(refined) - base:,}.")
                        if base is not None and int(regions) else "")
                     + " Both cannot hold, and a job that ships over the budget it was given has come back at two to five "
                     "times it, which is time and money nobody agreed to."),
        recommendation=(f"Meshing coarser holds your {int(cap):,}-cell budget, and what it costs is resolution in the "
                        "places the plan asked for it, at the junctions, the bends and the area changes. Raising the "
                        f"budget to {int(refined):,} cells keeps that resolution and costs the run time those cells take. "
                        "Stopping now costs neither."),
        requires_user_decision=True, user_decision="pending",
        derivation=(f"{R36_DERIVATION} mesh_plan.cell_estimate_refined {int(refined):,} > cell_cap {int(cap):,}"
                    + (f"; the tier estimate alone is {base:,}" if base is not None else "")))


def _with_refined_cell_cap(expected: list[Risk], plan_obj: dict[str, Any] | None, plan: GeometryPlan | None,
                           ctx: ToolContext) -> list[Risk]:
    """`expected` plus R36's risk when the plan's refined estimate is over the cap. Both callers go through here
    so `_normalise`'s fill and `_check_risks`'s comparison are always looking at the same list."""
    mp = (plan_obj.get("mesh_plan") if isinstance(plan_obj, dict) else None) or {}
    if plan is not None:
        fidelity, refined, regions = plan.mesh_plan.fidelity, plan.mesh_plan.cell_estimate_refined, len(plan.mesh_plan.refinement_regions)
    else:
        fidelity, refined = mp.get("fidelity"), mp.get("cell_estimate_refined")
        regions = len(mp.get("refinement_regions") or [])
    extra = _refined_cell_cap_risk(ctx, fidelity, refined, regions, expected)
    return [*expected, extra] if extra is not None else expected


def _expected_risks(plan_obj: dict[str, Any], ctx: ToolContext) -> list[Risk]:
    """The catalog under the plan's own roles (what _check_risks compares against), for the synthesis."""
    fidelity = (plan_obj.get("mesh_plan") or {}).get("fidelity") if isinstance(plan_obj.get("mesh_plan"), dict) else None
    try:
        found = catalog.detect_risks(ctx.facts, ctx.purpose, fidelity or ctx.fidelity, ctx.cell_cap, ctx.declared,
                                     _plan_roles(plan_obj, ctx.facts), brief=ctx.brief, fluid_side=ctx.fluid_side)
    except (StopIteration, ValueError, KeyError, TypeError, AttributeError):
        # an invalid tier or a malformed plan is reported by schema validation; the lists are then moot
        return []
    return _with_refined_cell_cap(found, plan_obj, None, ctx)


def _effect_of(risk: dict[str, Any] | None, target: str | None) -> str | None:
    """What answering a question does, from its risk (the model's effect, else the catalog kind's), else from
    what it relates to (the unit, the purpose, a patch's role); None when nothing decides it (R8 then rejects)."""
    if risk is not None:
        if risk.get("effect") in EFFECTS:
            return risk["effect"]
        if risk.get("detected_by", "catalog") == "catalog":
            return catalog.KIND_EFFECT.get(str(risk.get("kind")), "advisory")
        return None
    if target in TARGET_EFFECT:
        return TARGET_EFFECT[target]
    if isinstance(target, str) and OPENING_ID.fullmatch(target):
        return "changes_bc"
    return None


def _fill_catalog_risk_fields(risks: list[dict[str, Any]]) -> None:
    """A catalog risk's mechanism and effect come from the kind tables (catalog fills them; a plan that copied
    an older list_risks result, or a schema 2 transcript, gets them here)."""
    for r in risks:
        if r.get("detected_by", "catalog") != "catalog":
            continue
        kind = str(r.get("kind") or "")
        if r.get("mechanism") is None and kind in catalog.KIND_MECHANISM:
            r["mechanism"] = catalog.KIND_MECHANISM[kind]
        if r.get("effect") is None:
            r["effect"] = catalog.KIND_EFFECT.get(kind, "advisory")


def _fill_question_effects(questions: list[dict[str, Any]], risks: list[dict[str, Any]]) -> None:
    by_id = {r.get("id"): r for r in risks}
    for q in questions:
        if q.get("effect") in EFFECTS:
            continue
        target = q.get("relates_to")
        eff = _effect_of(by_id.get(target), target)
        for rid in (q.get("also_settles") or []) if eff is None else []:
            eff = _effect_of(by_id.get(rid), rid)
            if eff is not None:
                break
        if eff is not None:
            q["effect"] = eff


def _note_operating_point(mp: dict[str, Any], ctx: ToolContext) -> None:
    """Schema 3: a missing operating point is an assumption line, never a risk. Added when the plan grows layers,
    the brief states no velocity or Reynolds number, and no assumption speaks of it yet."""
    layers = [lt for lt in mp.get("layer_targets") or [] if isinstance(lt, dict) and (lt.get("n_layers") or 0) > 0]
    if not layers or OPERATING_POINT_IN_BRIEF.search(ctx.brief or ""):
        return
    assumptions = [str(a) for a in (mp.get("assumptions") or [])]
    if any(OPERATING_POINT_IN_BRIEF.search(a) or re.search(r"\bnu\b|y\+|operating|placeholder|\bfluid\b|\bair\b|\bwater\b|\bU\b", a, re.I)
           for a in assumptions):
        return
    mp["assumptions"] = assumptions + [OPERATING_POINT_NOTE]


def _brief_unit(brief: str, facts, purpose: str) -> str | None:
    """The one unit every dimension in the brief is written in, when it is plausible for the purpose."""
    units = set()
    for m in R9_UNIT_IN_BRIEF.finditer(brief or ""):
        word = m.group(1).lower()
        unit = catalog._UNIT_WORDS.get(word) or catalog._UNIT_WORDS.get(word.rstrip("s")) or (
            "mm" if word.startswith("millimet") else "m" if word.startswith("met") else "in" if word.startswith("inch") else
            "ft" if word in ("feet", "foot") else None)
        if unit:
            units.add(unit)
    if len(units) != 1:
        return None
    unit = next(iter(units))
    plausible = facts.units.plausible_for_purpose.get(purpose, [])
    return unit if (not plausible or unit in plausible) else None


def _unit_settled_by_brief(ctx: ToolContext) -> tuple[str | None, str]:
    """The unit the brief settles for R9, with the reason: a brief dimension equal to a measured length pins it
    exactly (catalog.unit_from_brief), else the one unit every brief dimension is written in when it is plausible
    for the purpose at the file's size. (None, "") when the brief writes no dimension with a unit, mixes units, or
    names a unit implausible for the file: then the brief and the file disagree and a unit question is not a
    false alarm."""
    brief = ctx.brief or ""
    if not R9_UNIT_IN_BRIEF.search(brief):
        return None, ""
    settled, why = catalog.unit_from_brief(ctx.facts, brief, ctx.purpose)
    if settled:
        return settled, why
    u = _brief_unit(brief, ctx.facts, ctx.purpose)
    return (u, f"the brief writes its dimensions in {u}") if u else (None, "")


def _risk_ids(m: dict[str, Any]) -> set[str]:
    """The openings whose role a role-decision risk is about (dict form of _role_ids)."""
    out = set()
    if m.get("opening_id"):
        out.add(str(m["opening_id"]))
    for k in ("inlet_ids", "outlet_ids"):
        out |= {x for x in (m.get(k) or []) if isinstance(x, str)}
    return out


def _repair_false_alarms(plan_obj: dict[str, Any], ctx: ToolContext,
                         risks: list[dict[str, Any]]) -> tuple[list[str], list[dict[str, Any]]]:
    """R9 on schema 3: a pending catalog decision the brief already ANSWERS is set to continue with the phrase as
    its derivation, so no question is injected for it. Three readings, each named for the question it answers
    (P4.4): a short run under a brief that declines a geometry change ("geometry is final", "as built"); the unit
    under a brief dimension whose unit settles the file unit (_unit_settled_by_brief; the unit call then follows
    the brief when it is a guess); a role on a declared port. A phrase that only names the subject of a question
    settles nothing and is not here: "fixed pressure outlet" was cut at P4.4, and so was the cell-budget reading
    the scorer carried, because stating the cap does not choose between dropping the tier and raising it.

    Returns one note per repair. The decision is never lost: it stays on the risk as `user_decision` continue with
    the phrase in `derivation`, the question that would have asked it moves to `settled_questions` (below), and
    `synthesise_warnings` carries both into the user's simulation warning as `answer` and `settled_by`."""
    notes: list[str] = []
    brief = ctx.brief or ""
    facts = ctx.facts
    rep = catalog.representation(facts, ctx.purpose, ctx.brief, declared=ctx.declared, fluid_side=ctx.fluid_side)
    pairs = catalog.declared_pairs(facts, catalog.port_openings(facts, rep, ctx.declared), ctx.declared, rep) if ctx.declared else {}
    settled_unit, settled_why = _unit_settled_by_brief(ctx)
    for r in risks:
        if r.get("detected_by", "catalog") != "catalog" or not r.get("requires_user_decision") \
                or r.get("user_decision", "pending") != "pending":
            continue
        kind = str(r.get("kind") or "")
        m = r.get("measurement") or {}
        phrase = what = None
        if kind in STUB_QUESTION_KINDS:
            hit = R9_SETTLES["short_stub"].search(brief)
            phrase, what = (hit.group(0), "whether the geometry may change") if hit else (None, None)
        elif kind == "unit_unknown":
            hit = R9_UNIT_IN_BRIEF.search(brief)
            phrase, what = (hit.group(0), f"the unit ({settled_unit})") if hit and settled_unit else (None, None)
        elif kind in R9_ROLE_KINDS and pairs:
            ids = _risk_ids(m)
            if ids and all(i in pairs for i in ids):
                phrase = ", ".join(f"declared port {pairs[i].get('name')!r} ({pairs[i].get('role')}) at {i}" for i in sorted(ids))
                what = "the role"
        if not phrase:
            continue
        r["user_decision"] = "continue"
        r["derivation"] = f"brief: {phrase!r} settles {what}; no question (checker R9)"
        subject = m.get("opening_id") or ", ".join(sorted(_risk_ids(m))) or "the plan"
        notes.append(f"R9: {kind} on {subject} settled by the brief ({phrase!r}), which answers {what}; set to continue, "
                     "no question (the decision rides in the simulation warning's answer and settled_by)")
    unit = plan_obj.get("unit")
    if settled_unit and not facts.units.declared and (not isinstance(unit, dict) or unit.get("basis") == "guess"):
        # a brief dimension that equals a measured length settles the unit exactly (the catalog's reading); one
        # that matches nothing measured settles it by the unit it is written in, when that unit is plausible for
        # the file (an implausible brief unit is a conflict the unit question is for, not a false alarm)
        plan_obj["unit"] = {"declared": None, "assumed": settled_unit, "basis": "brief"}
        notes.append(f"R9: {settled_why}; unit basis brief, no unit question")
    dropped_notes, settled_questions = _drop_settled_questions(plan_obj, ctx, risks, pairs)
    notes.extend(dropped_notes)
    notes.extend(_state_settled_assumptions(plan_obj, risks))
    return notes, settled_questions


def _drop_settled_questions(plan_obj: dict[str, Any], ctx: ToolContext, risks: list[dict[str, Any]],
                            pairs: dict[str, dict]) -> tuple[list[str], list[dict[str, Any]]]:
    """R27, as P4.4 rewrites it: a question the brief has ANSWERED is not asked again, and is not deleted either.
    It comes out of `questions` and is handed to `synthesise_warnings`, which writes it into the user's simulation
    warning with its options, the decision as `answer` and the brief phrase as `settled_by`
    (`provenance.asked` False). Returns `(notes, moved questions)`.

    Why the simulation warning and not `mesh_plan.assumptions` or a new list of the plan's own: the simulation
    warning IS the user's output (dev plan P4.2, "simulation warnings to the user, one question each, with a
    default"), it already carries `question`, `options`, `default`, `answer` and `settled_by` for exactly this
    case, `hexera.report()` and `handover()` already carry it under `warnings.user`, and `confirm.apply_answers`
    already routes an answer keyed by a warning id. `mesh_plan.assumptions` is the builder's half of the plan and
    is a list of strings, so the options and the default would be lost; a new plan field would grow the submit
    tool's own schema, which is the last place a field nobody writes belongs.

    The risk behind the question already carries `user_decision` continue and the phrase in `derivation` (the
    repair above), and the user summary gains one sentence naming the phrase
    (`_state_settled_assumptions`), so the same decision reaches the user three ways and can be overruled.

    A question that names a risk still pending stays in `questions` for the rule to report: there the decision,
    not only the question, is at stake."""
    questions = plan_obj.get("questions")
    if not isinstance(questions, list) or not questions:
        return [], []
    risk_by_id = {str(r.get("id")): r for r in risks}

    def pending(rid: Any) -> bool:
        r = risk_by_id.get(str(rid))
        return bool(r) and bool(r.get("requires_user_decision")) and r.get("user_decision", "pending") == "pending"

    notes: list[str] = []
    kept: list[Any] = []
    settled: list[dict[str, Any]] = []
    for q in questions:
        if not isinstance(q, dict):
            kept.append(q)
            continue
        rid = q.get("relates_to")
        r = risk_by_id.get(str(rid))
        kind = r.get("kind") if r else None
        named = [rid, *(q.get("also_settles") or [])]
        role_ids: set[str] = set()
        if r is not None and kind in R9_ROLE_KINDS:
            role_ids = _risk_ids(r.get("measurement") or {})
        elif r is None and OPENING_ID.fullmatch(str(rid or "")):
            role_ids = {str(rid)}
        view = {"id": q.get("id"), "text": q.get("text"), "relates_to": rid, "kind": kind,
                "agent": r is None or r.get("detected_by", "catalog") == "agent",
                "kinds": {kind} | {risk_by_id[str(x)].get("kind") for x in (q.get("also_settles") or []) if str(x) in risk_by_id},
                "role_ids": role_ids}
        why = _r9_verdict(view, ctx, pairs)
        if not why or any(pending(x) for x in named):
            kept.append(q)
            continue
        settled.append(q)
        notes.append(f"R27 repair: question {q.get('id')} is not asked: {why.split(';')[0]}; it is kept on its simulation warning with "
                     "its options, the decision as the answer and the brief phrase as settled_by, so the user can overrule it")
    if settled:
        plan_obj["questions"] = kept
    return notes, settled


#: The brief phrase a risk's derivation records when R9 settled it (`_repair_false_alarms` writes it, R18's
#: "catalog: ..." is the other form); `_state_settled_assumptions` and the warnings quote it back.
SETTLED_BY_BRIEF = re.compile(r"^brief:\s*(.+?)\s*settles\s+([^;]+)", re.I)
#: At most this many stated assumptions are appended to summary_for_user, and at most this much text: the
#: sentence exists so the user can overrule a decision the brief made for them, not to restate the plan.
SETTLED_SENTENCES_MAX = 3
SETTLED_SENTENCE_MAX_CHARS = 420


def _state_settled_assumptions(plan_obj: dict[str, Any], risks: list[dict[str, Any]]) -> list[str]:
    """P4.4: every decision the brief made for the user reaches the user. One sentence per risk R9 settled is
    appended to `summary_for_user`, naming the brief phrase and what was done, so a person reading the summary can
    say otherwise. The plan already carries the same fact three ways (the risk's derivation, the settled question,
    the simulation warning's answer and settled_by); this is the one a person actually reads."""
    parts: list[str] = []
    seen: set[str] = set()
    for r in risks:
        m = SETTLED_BY_BRIEF.match(str(r.get("derivation") or ""))
        if m is None or r.get("user_decision", "pending") == "pending":
            continue
        phrase, what = m.group(1).strip().strip("'\""), m.group(2).strip()
        kind = str(r.get("kind") or "")
        oid = (r.get("measurement") or {}).get("opening_id")
        subject = f"{kind} at {oid}" if oid else kind
        key = f"{phrase}|{what}"
        if key in seen:
            parts[-1] = parts[-1].rstrip(".") + f", and {subject}."
            continue
        seen.add(key)
        parts.append(f"your brief says {phrase!r}, which settles {what}, so I took {r.get('user_decision')} on {subject}.")
        if len(parts) >= SETTLED_SENTENCES_MAX:
            break
    if not parts:
        return []
    line = "Taken from your brief (say so if you want it otherwise): " + " ".join(parts)
    if len(line) > SETTLED_SENTENCE_MAX_CHARS:
        line = line[:SETTLED_SENTENCE_MAX_CHARS - 3].rstrip() + "..."
    summary = str(plan_obj.get("summary_for_user") or "").rstrip()
    if line in summary:
        return []
    plan_obj["summary_for_user"] = (summary + " " + line).strip()
    return [f"R27 repair: summary_for_user carries {len(parts)} stated assumption(s) the brief settled, "
            "so a decision taken from the brief is one the user can still overrule"]


def _builder_frame_for(plan_obj: dict[str, Any], ctx: ToolContext, rep: str) -> dict[str, Any]:
    """tools.builder_frame with the plan's inlet, for internal purposes; empty otherwise."""
    if ctx.purpose not in INTERNAL or rep == "external":
        return {}
    from geometry_agent.agent import tools
    roles = _plan_roles(plan_obj, ctx.facts)
    inlet_id = next((i for i, role in roles.items() if role == "inlet"), None)
    try:
        return tools.builder_frame(ctx.facts, rep, None, inlet_id)
    except (ValueError, ZeroDivisionError, KeyError, AttributeError):
        return {}


#: The measurement key that sizes each builder kind (MeshWarning.size and builder_cells).
_FEATURE_KEY = {"tilted_circular_mouth": "bore", "port_resolution": "min_dimension", "gap_resolution": "min_gap_between_regions",
                "near_touching": "min_gap", "thin_feature": "thickness_min", "seed_point": "bore", "budget_forecast": "bore",
                "gmsh_size": "min_dimension"}


def _rule_size(kind: str, m: dict[str, Any], frame: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any] | None]:
    """A rule's own magnitudes in the builder's frame: what `MeshWarning.size` and `builder_cells` carry for it.
    One derivation, used by the synthesis and by the fill of an item the plan wrote (R42)."""
    def num(*keys):
        for k in keys:
            v = m.get(k)
            if isinstance(v, (int, float)) and not isinstance(v, bool) and v > 0:
                return float(v)
        return None
    size = {"bore": num("bore", "hydraulic_diameter"), "min_dim": num("min_dimension"), "thickness": num("thickness_min"),
            "gap": num("min_gap", "min_gap_between_regions"), "tilt_deg": num("tilt_deg"), "angle_deg": None, "length": None}
    feature = num(_FEATURE_KEY.get(kind, "bore"), "hydraulic_diameter", "bore")
    wall_cell = float((frame or {}).get("wall_cell") or 0.0)
    cells = {"wall_cell": wall_cell, "cells_across": (feature / wall_cell) if feature else None} if wall_cell > 0 else None
    return size, cells


#: The caps on the list the builder reads (docs/builder_directives.md 6.5). The directive cap is the number of
#: keys the renderer consumes for the regime, so the list is short by construction and never by truncation.
MAX_CONDITIONALS = 2
MAX_NOTES = 2


def _channel_of(ctx: ToolContext, rep: str, frame: dict[str, Any]) -> dict[str, Any]:
    """What the builder channel is for this case: the engine, the regime whose keys have a reader, the customer's
    cap, the strategy the cap forces (`catalog.budget_fit`, the T0 guard), and two forecasts. `default_forecast`
    is what the renderer does when the plan says nothing, which is what the guard's own saving is measured
    against; `forecast` is the guard applied, which is the baseline every other item is priced against."""
    engine = catalog.engine_from_brief(ctx.brief, ctx.purpose)
    inlet_id = frame.get("inlet_id")
    base = catalog.budget_fit(ctx.facts, rep, engine, inlet_id, ctx.cell_cap)
    out = {"engine": engine, "regime": catalog.regime_of(engine, rep), "cell_cap": ctx.cell_cap,
           "inlet_id": inlet_id, "rep": rep, "base_strategy": base, "forecast": None, "default_forecast": None}
    out["default_forecast"] = _estimate(ctx, out, None)
    out["forecast"] = _estimate(ctx, out, base) if base else out["default_forecast"]
    return out


def _estimate(ctx: ToolContext, channel: dict[str, Any], strategy: dict[str, Any] | None) -> int | None:
    from geometry_agent.agent import tools
    try:
        return int(tools.estimate_builder_cells(ctx.facts, strategy or None, channel["rep"], channel["engine"],
                                                channel.get("inlet_id"))["cells_high"])
    except (ValueError, ZeroDivisionError, KeyError, AttributeError, TypeError, StopIteration):
        return None


def _forecast_with(ctx: ToolContext, channel: dict[str, Any], key: str, value: Any) -> int | None:
    """The emulator's count for the baseline strategy with one key moved. `quality` and `reference_length_m`
    change no cell, so they cost nothing and the baseline stands; a key already in the baseline is the guard
    itself, and its forecast is the baseline. None when the emulator cannot run here."""
    if key in ("quality", "reference_length_m"):
        return channel.get("forecast")
    base = dict(channel.get("base_strategy") or {})
    if base.get(key) == value:
        return channel.get("forecast")
    base[key] = {"mode": "factor", "value": value} if key == "size" else value
    return _estimate(ctx, channel, base)


def _floor_shortfall(kind: str, m: dict[str, Any]) -> float:
    """How far a measured feature sits under the floor its kind names, as a fraction of that floor; 0 when the
    kind names no floor. T1 is read in this order, furthest under first, because that is how much of the geometry
    the builder's own cell is missing; the notes are ordered by it too."""
    have = m.get("cells_across") or m.get("cells_across_gap") or m.get("elements_across_default")
    floor = catalog.threshold_of(kind) or {}
    want = m.get("cells_min") or m.get("cutoff") or floor.get("value")
    try:
        return max(0.0, 1.0 - float(have) / float(want)) if have and want else 0.0
    except (TypeError, ValueError, ZeroDivisionError):
        return 0.0


def _classify(kind: str, target: dict[str, Any], m: dict[str, Any], ctx: ToolContext, channel: dict[str, Any],
              frame: dict[str, Any]) -> dict[str, Any]:
    """Which of the three classes an item is, and everything that follows from it: the tier, the trigger, the
    cost against the default strategy, the forecast with it applied, and why it was demoted when it was.

    The four admissions of docs/builder_directives.md 6.3, in order. The key must be one the renderer reads for
    this engine and regime and the value one it does not clamp away (1 and 2); the forecast with it applied must
    sit under the builder's own margin (3), and an item that fails that is the customer's `cell_cap` question and
    not a builder instruction, so it keeps its measurement and loses its key; a cost nobody knows is the same
    demotion, because WHAT IT COSTS is one of the four questions an item answers. A margin (T2) also pays
    `catalog.price_admits`: an item that costs more cells than it is worth does not belong on a list read in
    order, and `dropped` says so."""
    T = current_thresholds()
    regime, cap = channel["regime"], channel.get("cell_cap")
    base = channel.get("forecast")
    out: dict[str, Any] = {"item_class": "note", "tier": None, "trigger": None, "cost": None, "forecast": None,
                           "demoted": "", "dropped": "", "value_problem": ""}
    if kind in catalog.CONDITIONAL_KINDS or m.get("trigger"):
        out["item_class"], out["trigger"] = "conditional", str(m.get("trigger") or "")
    d = catalog.directive_of(kind, m, frame, regime, T)
    key, value = target.get("key"), target.get("value")
    if not key and d:
        key, value = d["key"], d["value"]
        target["key"], target["value"] = key, value
    if d and key == d["key"]:
        out["tier"] = d["tier"]
    elif kind in catalog.DIRECTIVE_TIER_BY_KIND:
        # a list the model wrote carries no measurement for `directive_of` to read; the kind still knows its tier
        out["tier"] = catalog.DIRECTIVE_TIER_BY_KIND[kind]

    def demote(reason: str) -> dict[str, Any]:
        target.pop("key", None)
        target.pop("value", None)
        return {**out, "item_class": "note", "tier": None, "trigger": None, "demoted": reason}

    if not key:
        if out["item_class"] == "conditional":
            # a conditional is one key set when the critique says one phrase; with no key there is nothing for
            # the builder to do when it does, so the measurement stays and the item is a note. The trigger goes
            # with it: a phrase keyed to no key is keyed to nothing, and asking the writer to correct it buys a
            # round for a field nobody would read
            return demote("names a trigger and no key, so there is nothing to set when the critique says it")
        return out
    if not catalog.directive_key_readable(key, regime):
        return demote(f"the target {catalog.directive_problem(key, value, regime)}")
    problem = catalog.directive_problem(key, value, regime)
    if problem:
        # the key has a reader and the value does not fit it: a mistake the writer fixes, not a demotion
        out["item_class"] = "directive" if out["item_class"] != "conditional" else "conditional"
        return {**out, "value_problem": problem, "tier": out["tier"] or "T2"}
    with_it = _forecast_with(ctx, channel, key, value)
    out["forecast"] = with_it
    # the guard is already in the baseline, so what it costs is measured against the renderer's own default
    against = channel.get("default_forecast") if (channel.get("base_strategy") or {}).get(key) == value else base
    if with_it is None or against is None:
        return demote(f"the emulator prices no strategy here, so what {key} costs is unknown")
    out["cost"] = int(with_it) - int(against)
    if cap and with_it > (1.0 - catalog.budget_margin()) * cap:
        return demote(f"{key} {value} forecasts {int(with_it):,} cells, over the {cap:,} cap by the builder's "
                      f"{catalog.budget_margin():.0%} margin; that is the customer's cell_cap question, not an instruction")
    if out["item_class"] == "conditional":
        return out
    out["item_class"] = "directive"
    out["tier"] = out["tier"] or "T2"
    if catalog.price_admits(out["cost"], base, cap, out["tier"]) is False:
        out["dropped"] = (f"{key} {value} costs {out['cost']:,} cells of the "
                          f"{int((1.0 - catalog.budget_margin()) * (cap or 0) - base):,} left under the cap, over the "
                          f"{catalog.price_fraction():.0%} a margin may spend")
    return out


def _mesh_warning(r: dict[str, Any], ctx: ToolContext, rep: str, frame: dict[str, Any], tier: Any, n: int,
                  patches: list, channel: dict[str, Any] | None = None) -> dict[str, Any]:
    """One MeshWarning from a builder-audience catalog risk, in the builder's frame."""
    from geometry_agent.agent import tools
    T = current_thresholds()
    facts = ctx.facts
    known = {o.id: o for o in facts.openings}
    kind, m = str(r.get("kind") or ""), r.get("measurement") or {}
    ids = sorted(i for i in _ids_in(m) if i in known)
    point = m.get("centroid") or m.get("seed_point") or (list(known[ids[0]].centroid) if len(ids) == 1 else None)
    closest = m.get("closest")
    region_id = str(closest[0]) if isinstance(closest, (list, tuple)) and closest else None

    size, builder_cells = _rule_size(kind, m, frame)
    wall_cell = float(frame.get("wall_cell") or 0.0)
    target = {**catalog.remedy_target(kind, m, frame, T), **(r.get("target") or {})}
    channel = channel or _channel_of(ctx, rep, frame)
    verdict = _classify(kind, target, m, ctx, channel, frame)
    cost = verdict["cost"]
    if cost is None and verdict["item_class"] == "note":
        # a note prices nothing it can set; what it can still price is the sphere its location implies, which is
        # what the reference policy's own refinement estimate costs
        sphere = target.get("sphere")
        if isinstance(sphere, dict) and sphere.get("anchor") and sphere.get("radius") and tier and wall_cell > 0:
            t_size = wall_cell / (2 ** max(int(target.get("level_delta") or 0), 0))
            try:
                est = tools.refined_cell_estimate(ctx, tier, [{"where": kind, "kind": "sphere", "target_size": t_size,
                                                                "anchor": sphere["anchor"], "radius": sphere["radius"], "reason": kind}], patches)
                cost = int(est["regions"][0]["cells"]) if est.get("regions") else None
            except (TypeError, ValueError, KeyError, ZeroDivisionError):
                cost = None
    prov: dict[str, Any] = {"rule_class": catalog.rule_class_of(kind), "threshold_key": catalog.KIND_THRESHOLD.get(kind),
                            "threshold": catalog.threshold_of(kind, T), "risk_id": r.get("id"), "severity": r.get("severity"),
                            "detected_by": r.get("detected_by", "catalog"), "derivation": r.get("derivation") or "",
                            "representation": rep, "regime": channel["regime"], "cell_cap": channel.get("cell_cap"),
                            "forecast_without": channel.get("forecast"), "platform_sha": tools.PLATFORM_SHA,
                            "shortfall": round(_floor_shortfall(kind, m), 4)}
    for field in ("demoted", "dropped"):
        if verdict[field]:
            prov[field] = verdict[field]
    if kind == "tilted_circular_mouth":
        prov["sweep"] = dict(catalog.TILTED_MOUTH_SWEEP)
    return {"id": f"mw{n}", "kind": kind, "detected_by": "catalog",
            "severity": catalog.attention_of(verdict["item_class"], verdict["tier"]),
            "item_class": verdict["item_class"], "tier": verdict["tier"], "trigger": verdict["trigger"] or None,
            "location": {"patch_ids": ids, "point": [float(c) for c in point] if point else None, "region_id": region_id},
            "size": size, "builder_cells": builder_cells, "target": target, "cost_cells": cost,
            "forecast_cells": verdict["forecast"],
            "why": r.get("consequence") or "", "provenance": prov, "if_it_fails": None}


def synthesise_warnings(plan_obj: dict[str, Any], ctx: ToolContext, expected: list[Risk] | None = None,
                        settled_questions: list[dict[str, Any]] | None = None,
                        ) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """The two outputs from the plan's catalog risks: `simulation_warnings` for the user (one per question, with
    the question's text, options, default and effect, plus one advisory entry per user-audience risk that asks
    nothing) and `mesh_warnings` for the builder (one per builder-audience catalog risk, in the builder's frame:
    location, size, builder cells, the kind's remedy as the target, the cost when a region is implied). The
    expected catalog risks, when given, contribute the builder kinds the plan's list predates (the schema 3 kinds
    ride here, never in the risks list).

    `settled_questions` are the questions R27 took out of the plan because the brief answered them (P4.4). They
    host their warning like any other question, so its `question`, `options` and `default` survive; what marks
    them is `answer` (the decision the brief implies), `settled_by` (the phrase) and `provenance.asked` False."""
    facts = ctx.facts
    T = current_thresholds()
    rep = catalog.representation(facts, ctx.purpose, ctx.brief, declared=ctx.declared, fluid_side=ctx.fluid_side)
    risks = [r for r in plan_obj.get("risks") or [] if isinstance(r, dict)]
    questions = [q for q in plan_obj.get("questions") or [] if isinstance(q, dict)]
    # P4.4: a question the brief answered was taken out of `questions` by R27 and handed here. It still hosts its
    # warning, so the user sees the question, its options and the answer the brief gave, and can say otherwise;
    # `provenance.asked` marks which of the two it came from.
    settled = [q for q in settled_questions or [] if isinstance(q, dict)]
    host: dict[str, dict] = {}
    covered: set[str] = set()
    for q in questions + settled:
        rid = q.get("relates_to")
        if isinstance(rid, str):
            host.setdefault(rid, q)
        covered |= {x for x in (q.get("also_settles") or []) if isinstance(x, str)}
    asked_ids = {str(q.get("id")) for q in questions}
    sims: list[dict[str, Any]] = []
    for r in risks:
        kind, rid = str(r.get("kind") or ""), r.get("id")
        q = host.get(rid)
        audience = catalog.audience_of(kind, rep)
        if q is None and (rid in covered or not (audience == "user" or r.get("requires_user_decision"))):
            continue
        eff = q.get("effect") if (q and q.get("effect") in EFFECTS) else _effect_of(r, rid)
        decision = r.get("user_decision", "pending")
        derivation = str(r.get("derivation") or "")
        answer = decision if decision != "pending" else None
        settled_by = None
        if answer is not None:
            # "brief: ..." is the R9 repair's phrase and "catalog: ..." is R18's: either names who settled it
            settled_by = (derivation.split(";")[0].strip() if derivation.lower().startswith(("brief:", "catalog:")) else "analyst")
        catalog_risk = r.get("detected_by", "catalog") == "catalog"
        sims.append({
            "id": f"sw{len(sims) + 1}", "kind": kind, "measurement": r.get("measurement") or {},
            "threshold": catalog.threshold_of(kind, T) if catalog_risk else None,
            "question": q.get("text") if q else None, "options": list(q.get("options") or []) if q else [],
            "default": q.get("default") if q else None, "effect": eff,
            "also_settles": [x for x in (q.get("also_settles") or []) if x != rid] if q else [],
            "provenance": {"rule_class": catalog.rule_class_of(kind) if catalog_risk else "agent",
                           "threshold_key": catalog.KIND_THRESHOLD.get(kind) if catalog_risk else None, "risk_id": rid,
                           "question_id": q.get("id") if q else None, "severity": r.get("severity"), "audience": audience,
                           "detected_by": r.get("detected_by", "catalog"), "mechanism": r.get("mechanism"),
                           "asked": bool(q) and str(q.get("id")) in asked_ids},
            "answer": answer, "settled_by": settled_by})
    frame = _builder_frame_for(plan_obj, ctx, rep)
    mp = plan_obj.get("mesh_plan") if isinstance(plan_obj.get("mesh_plan"), dict) else {}
    tier = mp.get("fidelity")
    patches = plan_obj.get("patches") or []
    pool = [r for r in risks if r.get("detected_by", "catalog") == "catalog" and catalog.audience_of(str(r.get("kind")), rep) == "builder"]
    have = {_risk_key(r) for r in risks if r.get("detected_by", "catalog") == "catalog" and isinstance(r.get("kind"), str)}
    for e in expected or []:
        if e.kind in catalog.NEW_BUILDER_KINDS and _risk_key(e) not in have and catalog.audience_of(e.kind, rep) == "builder":
            pool.append(e.model_dump())
    channel = _channel_of(ctx, rep, frame)
    mws = [_mesh_warning(r, ctx, rep, frame, tier, i + 1, patches, channel) for i, r in enumerate(pool)]
    return sims, rank_mesh_warnings(mws, channel["regime"])


#: How the three classes are read: every directive by tier, then the conditionals, then the notes.
_CLASS_ORDER = {"directive": 0, "conditional": 1, "note": 2}
_TIER_ORDER = {"T0": 0, "T1": 1, "T2": 2, None: 3}


def rank_mesh_warnings(mws: list[dict[str, Any]], regime: str, renumber: bool = True,
                       drop_refused: bool = True) -> list[dict[str, Any]]:
    """The order the builder reads the list in, and the cap on its length (docs/builder_directives.md 6.4, 6.5).

    T0 first, the guards that cost nothing and lose the run when wrong; then T1, the floors, furthest under first,
    because that is how much of the geometry is missing; then T2, the margins, cheapest first, because the price
    rule has already refused the ones that are not worth their cells. The conditionals follow, then at most two
    notes. An item `_classify` dropped on price is gone, and one directive per key: two items asking the same key
    for different values are two instructions the builder cannot both carry out, so the higher tier keeps the key
    and the other becomes a note.

    The length is bounded by the number of keys the renderer reads for this regime, which is seven on internal
    snappy, six on external and two on gmsh. That is the point of the design: there are seven knobs, so there are
    at most seven instructions, and the list is short by construction and never by truncation."""
    keys_max = len(catalog.DIRECTIVE_KEYS.get(regime) or {})
    # `drop_refused` False is the plan's own list: nothing the model wrote is deleted here, it is ordered and the
    # price is R41's to report (P4.4: never removed silently again)
    kept = [w for w in mws if drop_refused is False or not (w.get("provenance") or {}).get("dropped")]

    def sort_key(w: dict[str, Any]) -> tuple:
        cls = _CLASS_ORDER.get(w.get("item_class") or "note", 2)
        tier = _TIER_ORDER.get(w.get("tier"), 3)
        shortfall = float((w.get("provenance") or {}).get("shortfall") or 0.0)
        cost = w.get("cost_cells")
        cost = float(cost) if isinstance(cost, (int, float)) else float("inf")
        return (cls, tier, -shortfall, cost, str(w.get("id")))

    kept.sort(key=sort_key)
    out: list[dict[str, Any]] = []
    seen_keys: set[str] = set()
    directives = conditionals = notes = 0
    for w in kept:
        cls = w.get("item_class") or "note"
        key = ((w.get("target") or {}).get("key")) if isinstance(w.get("target"), dict) else None
        if cls == "directive" and key in seen_keys:
            w = {**w, "item_class": "note", "tier": None, "severity": catalog.attention_of("note"),
                 "target": {k: v for k, v in (w.get("target") or {}).items() if k not in ("key", "value")},
                 "provenance": {**(w.get("provenance") or {}),
                                "demoted": f"{key} is already set by a higher-tier item; one directive per key"}}
            cls = "note"
        if cls == "directive":
            if directives >= keys_max:
                continue
            directives += 1
            if key:
                seen_keys.add(key)
        elif cls == "conditional":
            if conditionals >= MAX_CONDITIONALS:
                continue
            conditionals += 1
        else:
            if notes >= MAX_NOTES:
                continue
            notes += 1
        out.append(w)
    if renumber:
        out = [{**w, "id": f"mw{i + 1}"} for i, w in enumerate(out)]
    return out


#: The fields a settled question gives the warning that hosts it.
HOSTED_QUESTION_FIELDS = ("question", "options", "default", "effect", "also_settles", "answer", "settled_by")


def _host_settled_questions(plan_obj: dict[str, Any], ctx: ToolContext, settled: list[dict[str, Any]],
                            notes: list[str]) -> None:
    """P4.4: a question R27 took out of `questions` rides on the plan's simulation warnings whoever wrote them.

    `synthesise_warnings` hosts it when the checker builds that list, which is what the stand-in and a schema 2
    plan get. A plan that wrote its own list keeps it, and there the move would otherwise be the deletion this
    pass exists to stop: every parsed submission of `learning_v3_r3` (102 of 102) and `learning_v3_r2` (107 of
    107) wrote both lists itself, so no live plan has ever taken the synthesised path. The question is written
    here onto the warning that carries its risk, keeping that warning's own id, and a risk with no warning of
    its own gains the synthesised one under an id the list does not use."""
    sims = plan_obj.get("simulation_warnings")
    if not settled or not isinstance(sims, list):
        return
    moved = {str(q.get("id")) for q in settled}
    built, _mws = synthesise_warnings(plan_obj, ctx, None, settled_questions=settled)
    own: dict[str, dict[str, Any]] = {}
    used: set[str] = set()
    for w in sims:
        if not isinstance(w, dict):
            continue
        used.add(str(w.get("id")))
        prov = w.get("provenance")
        rid = prov.get("risk_id") if isinstance(prov, dict) else None
        if isinstance(rid, str):
            own.setdefault(rid, w)
    hosted: list[str] = []
    for w in built:
        prov = w.get("provenance") or {}
        if prov.get("asked") is not False or str(prov.get("question_id")) not in moved:
            continue
        rid = prov.get("risk_id")
        target = own.get(rid) if isinstance(rid, str) else None
        if target is None:
            n = len(sims) + 1
            while f"sw{n}" in used:
                n += 1
            w["id"] = f"sw{n}"
            used.add(w["id"])
            sims.append(w)
        else:
            target.update({k: w[k] for k in HOSTED_QUESTION_FIELDS})
            p = target.get("provenance")
            target["provenance"] = {**(p if isinstance(p, dict) else {}), "question_id": prov.get("question_id"), "asked": False}
        hosted.append(f"{prov.get('question_id')} ({w.get('kind') or rid})")
    if hosted:
        notes.append(f"R27 repair: the question(s) the brief answered ({', '.join(hosted)}) are carried by the plan's own simulation "
                     "warnings with their options, the decision as the answer and the brief phrase as settled_by")


def warnings_for(plan: GeometryPlan, ctx: ToolContext) -> tuple[list, list]:
    """The two lists as models for a plan that did not carry them (hexera.report on a plan built outside the
    checker): the plan's own lists when present, else the synthesis with the catalog under the plan's roles."""
    from geometry_agent.agent.schema import MeshWarning, SimulationWarning
    if plan.simulation_warnings is not None and plan.mesh_warnings is not None:
        return list(plan.simulation_warnings), list(plan.mesh_warnings)
    obj = plan.model_dump()
    sims, mws = synthesise_warnings(obj, ctx, _expected_risks(obj, ctx))
    return ([SimulationWarning.model_validate(s) for s in sims] if plan.simulation_warnings is None else list(plan.simulation_warnings),
            [MeshWarning.model_validate(w) for w in mws] if plan.mesh_warnings is None else list(plan.mesh_warnings))


def _same_type(a: str, b: str) -> bool:
    x, y = re.sub(r"[^a-z0-9 ]", " ", a.lower()).split(), re.sub(r"[^a-z0-9 ]", " ", b.lower()).split()
    if not x or not y:
        return False
    xs, ys = " ".join(x), " ".join(y)
    return xs == ys or xs in ys or ys in xs


def _hypothesis_for(type_name: str, hyps: list):
    return next((h for h in hyps if _same_type(h.type, type_name)), None)


def _call_words(rt) -> str:
    """A refuting test as the call to make: `probe_section(opening_id=o3)` (R24: the message names the arguments)."""
    args = ", ".join(f"{k}={v}" for k, v in (rt.args or {}).items() if not isinstance(v, (dict, list)))
    return f"{rt.tool}({args})"


def _refuting_calls(hyps: list) -> str:
    """The calls the plan's own hypotheses name, for a message that has to say what would settle the identity."""
    return ", ".join(_call_words(h.refuting_test) for h in hyps if h.refuting_test is not None and h.refuting_test.tool.strip())


def _reading_of(ctx: ToolContext, tool: str, value: float) -> bool:
    """Whether a call of `tool` in this run returned this number (R2, P4.3e).

    A `tests_run` entry cites the reading of the tool it names, and the ledger is one way of knowing a number was
    measured: it holds the numbers inside a result, but never the length of a list, and "how many ports are
    there" is the reading 115 of the learning-half run's 453 refuting tests name. The call log holds it, and
    holds it per tool, so this is the stricter test of the two where the ledger has the number and the only test
    that has it at all where the ledger does not."""
    from geometry_agent.agent import tools

    return any(_close(value, v) or value == v for v in tools.readings_of(ctx, tool))


def _looked(ctx: ToolContext) -> bool:
    """Whether this run has an impression to lean on at all. With no look the cap has nothing to say, and the
    existing R2 gates are the whole of the identity rule."""
    return getattr(ctx, "vision_impression", None) is not None


def _check_identity(plan: GeometryPlan, ctx: ToolContext, errors: list[str]) -> None:
    """R2: two or three identity hypotheses, each with a refuting test naming a tool; object.confidence over 0.8
    needs object.identity.tests_run citing a ledger number, over 0.9 the chosen type's refuting test run and
    supporting; the verdict (object.identity) agrees with object.type and object.confidence.

    R38 (dev plan P9): a `tests_run` entry naming `look_at_views` is never one of the cited tests, and an identity
    whose whole named support is the impression is capped at VISION_ONLY_CONFIDENCE_MAX."""
    obj = plan.object
    ident = obj.identity
    ledger = ctx.ledger.numbers
    names = _tool_names()
    hyps = plan.identity_hypotheses
    if not 2 <= len(hyps) <= 3:
        errors.append(f"identity_hypotheses (/identity_hypotheses): schema 3 needs two or three first-turn hypotheses, each "
                      f"{{type, prior, refuting_test {{tool, args, would_refute_if}}}}; got {len(hyps)}"
                      + ("; if the list was cut off with the end of the submission, add it with one "
                         "amend_geometry_plan edit at /identity_hypotheses and never a whole resubmission" if not hyps else ""))
    for i, h in enumerate(hyps):
        rt = h.refuting_test
        if rt is None or not rt.tool.strip() or not rt.would_refute_if.strip():
            errors.append(f"identity_hypotheses[{i}] (/identity_hypotheses/{i}/refuting_test): hypothesis {h.type!r} needs a refuting "
                          "test naming the tool, its args and the reading that would refute it")
        elif rt.tool not in names:
            errors.append(f"identity_hypotheses[{i}] (/identity_hypotheses/{i}/refuting_test/tool): {rt.tool!r} is not a tool of this "
                          f"run; name one of {sorted(names)}")
    tests = list(ident.tests_run) if ident is not None else []
    # R38: the look measures nothing. `_measured` reads one ledger for the whole run, so an entry naming
    # look_at_views and carrying a number probe_section produced would otherwise pass the 0.8 gate on a test that
    # never ran; the entry is struck out here rather than left to be spotted in a message.
    cited = [t for t in tests if t.tool != LOOK_TOOL and t.result_number is not None
             and (_measured(float(t.result_number), ledger) or _reading_of(ctx, t.tool, float(t.result_number)))]
    if any(t.tool == LOOK_TOOL and t.result_number is not None for t in tests):
        errors.append(f"object.identity.tests_run names {LOOK_TOOL} with a result_number: the look returns words and records no number "
                      "(every digit in its reply is scrubbed), so no number in the plan is its reading; drop the entry, or write the "
                      "tool that measured that number (/object/identity/tests_run)")
    # R38's CAP IS ENFORCED BY WRITING IT, NOT BY REFUSING HERE. `_repair_identity_confidence` clamps the number
    # to VISION_ONLY_CONFIDENCE_MAX before this runs and puts the reason and the lift in the notes, so by the time
    # the plan reaches these lines `obj.confidence` can no longer be over the cap on a vision-only identity: the
    # rejection that used to stand here could not fire, and a check that cannot fire reads as protection there is
    # none of. The two predicates cannot disagree either - the repair returns early only when `_identity_support`
    # finds a strand that is not the picture, and a plan with one is not vision-only - so nothing is left to catch.
    #
    # `cited` above is still computed here and still used by R2 and R24 below, and the look_at_views entry is still
    # struck out with its own message, which is the half of R38 that is about what a citation may be.
    if obj.confidence > IDENTITY_TESTED_ABOVE and not cited:
        # R24 (P4.3d): name the call that would settle it, from the hypotheses' own refuting tests
        offer = _refuting_calls(hyps) or ", ".join(_tools_called(ctx, names)[:4])
        errors.append(f"object.confidence {obj.confidence:g} is over {IDENTITY_TESTED_ABOVE:g}: object.identity.tests_run needs an entry "
                      "{tool, result_number, verdict} whose result_number is a ledger number (a measurement or a derived_geometry "
                      f"result); run one of your own refuting tests ({offer}) and record its number, or lower the confidence "
                      "(/object/identity)")
    if obj.confidence > IDENTITY_REFUTED_ABOVE and hyps:
        chosen = _hypothesis_for(obj.type, hyps)
        if chosen is None:
            errors.append(f"object.confidence {obj.confidence:g} is over {IDENTITY_REFUTED_ABOVE:g} but no identity_hypotheses entry names "
                          f"the chosen type {obj.type!r}; list it with its refuting test or lower the confidence (/identity_hypotheses)")
        elif chosen.refuting_test is not None and chosen.refuting_test.tool.strip():
            rt = chosen.refuting_test
            if not any(t.tool == rt.tool and t.verdict == "supports" for t in cited):
                errors.append(f"object.confidence {obj.confidence:g} is over {IDENTITY_REFUTED_ABOVE:g}: the refuting test of "
                              f"{chosen.type!r} ({_call_words(rt)}) must appear in object.identity.tests_run with its ledger number and "
                              f"verdict supports; it would refute {chosen.type!r} if {rt.would_refute_if.strip() or 'its reading says so'}, "
                              f"so call it and write {{tool: {rt.tool}, result_number: the number it returns, verdict: supports}}, or lower "
                              "the confidence (/object/identity)")
    if ident is not None:
        if ident.type.strip() and not _same_type(ident.type, obj.type):
            errors.append(f"object.identity.type {ident.type!r} is not object.type {obj.type!r}: one verdict (/object/identity/type)")
        if ident.confidence is not None and abs(ident.confidence - obj.confidence) > 1e-6:
            errors.append(f"object.identity.confidence {ident.confidence:g} must equal object.confidence {obj.confidence:g} "
                          "(/object/identity/confidence)")


def _carrying_catalog_risk(mechanism: str, plan: GeometryPlan, expected: list[Risk]) -> Risk | None:
    """The catalog risk that already carries a mechanism, if any: dismissing the mechanism because the catalog has
    it is right, and adding a risk of one's own for it is what R4 rejects. Only a catalog risk counts; the
    analyst's own risk on the mechanism is not a reason to dismiss the mechanism."""
    for r in list(plan.risks) + list(expected):
        if r.detected_by != "catalog" or mechanism == "other":
            continue
        if (r.mechanism or catalog.KIND_MECHANISM.get(r.kind)) == mechanism:
            return r
    return None


def _dismissal_fact(mechanism: str, plan: GeometryPlan, ctx: ToolContext,
                    expected: list[Risk]) -> tuple[dict[str, Any], str] | None:
    """R26: the named fact that carries a dismissal, for a mechanism the checker can settle itself from the facts,
    as `({key: value}, the sentence naming it)`; None when only a measurement can settle it, and
    `({}, the contradiction)` when the facts contradict the dismissal.

    "The part is nowhere near the ground" is a geometric fact, not a measurement, and so are "no bend in the run",
    "no junction", "one body", "the catalog already carries this mechanism" and "the purpose is not external". Each
    is read off the facts packet or the catalog's own output, which is why the checker can stand behind it.

    Three of them are topological claims and only those can be contradicted: dean_secondary_flow ("no bend") by a
    stub that ends by drift, jet_impingement and dead_leg_stagnation ("no junction") by a stub that ends at one.
    Every mechanism of the enum but `other` has a fact here; `other` needs the number."""
    facts = ctx.facts
    T = current_thresholds()
    rep = catalog.representation(facts, ctx.purpose, ctx.brief, declared=ctx.declared, fluid_side=ctx.fluid_side)
    ports = catalog.port_openings(facts, rep, ctx.declared)
    bends = [s.opening_id for s in facts.stubs if s.terminated_by == "drift"]
    junctions = [s.opening_id for s in facts.stubs if s.terminated_by == "junction"]
    closed = [p.id for p in plan.patches if p.role == "closed_end"]
    if mechanism == "dean_secondary_flow":
        if bends:
            return {}, (f"stub{'s' if len(bends) > 1 else ''} {', '.join(bends)} end by drift, which is a bend in the run; measure "
                        "the bend radius over the bore (derived_geometry) and cite it, or name the bend in why_not")
        return ({"stubs_ending_in_a_bend": 0, "ports": len(ports)},
                f"no stub of the {len(ports)} port runs ends by drift, so the facts carry no bend")
    if mechanism == "jet_impingement":
        if junctions:
            return {}, (f"stub{'s' if len(junctions) > 1 else ''} {', '.join(junctions)} end at a junction, where a branch can impinge; "
                        "measure the run from the branch to the facing wall (derived_geometry run_between) and cite it")
        return ({"stubs_ending_at_a_junction": 0, "ports": len(ports)},
                f"no stub ends at a junction and the file has {len(ports)} port openings, so nothing branches to impinge")
    if mechanism == "dead_leg_stagnation":
        if junctions and closed:
            return {}, (f"stub{'s' if len(junctions) > 1 else ''} {', '.join(junctions)} end at a junction and {', '.join(closed)} "
                        "close an end: that is the shape of a dead leg; cite derived_geometry dead_leg")
        return ({"stubs_ending_at_a_junction": len(junctions), "closed_end_patches": len(closed)},
                f"{'no stub ends at a junction' if not junctions else 'no patch closes an end'}, so the facts carry no dead leg")
    if mechanism == "ground_effect":
        floor = [o.id for o in facts.openings if o.on_bbox_face and o.bbox_side == "z_min"]
        return ({"planar_face_on_bbox_floor": bool(floor), "bbox_z_min": float(facts.bbox.min[2])},
                (f"{', '.join(floor)} lies on the bounding box floor (z_min)" if floor else
                 "no planar face lies on the bounding box floor (z_min), so the part is nowhere near the ground"))
    if mechanism == "wake":
        return ({"purpose": ctx.purpose, "body_length": float(max(facts.bbox.extent))},
                f"the purpose is {ctx.purpose} and the body length is {max(facts.bbox.extent):.6g}")
    if mechanism == "tip_gap":
        gap = facts.features.min_gap_between_regions
        return ({"regions": len(facts.regions), "min_gap_between_regions": gap},
                ("the file has one body, so there is no second region to leave a tip gap" if len(facts.regions) == 1 else
                 f"the closest two regions are {gap:.6g} apart" if gap else "no gap between regions was measured"))
    if mechanism == "thermal_interface_unshared":
        coincident = [i for i in facts.interfaces if getattr(i, "kind", "shared") == "coincident"]
        return ({"purpose": ctx.purpose, "coincident_interfaces": len(coincident)},
                f"the purpose is {ctx.purpose} and {len(coincident)} interface(s) are coincident and unshared")
    if mechanism == "swirl_no_symmetry":
        planes = None if facts.axes.symmetry_planes is None else list(facts.axes.symmetry_planes)
        return ({"rotational_order": facts.axes.rotational_order, "symmetry_planes": planes},
                f"the measured rotational order is {facts.axes.rotational_order} and the symmetry planes are "
                f"{planes if planes is not None else 'not measured (the symmetry stage did not run)'}")
    if mechanism == "layer_collision":
        return ({"near_touching_pairs": facts.features.near_touching_pairs, "min_gap": facts.features.min_gap},
                f"{facts.features.near_touching_pairs} near-touching pair(s) were measured")
    carrier = _carrying_catalog_risk(mechanism, plan, expected)
    if carrier is not None:
        return ({"catalog_risk": carrier.id, "catalog_kind": carrier.kind},
                f"catalog risk {carrier.id} ({carrier.kind}) already carries {mechanism}; a risk of your own for it would restate it (R4)")
    if mechanism in ("separation", "recirculation_at_outlet", "cell_starvation", "tilted_mouth_skew"):
        kinds = sorted(k for k, m in catalog.KIND_MECHANISM.items() if m == mechanism)
        return ({"catalog_risk": None, "catalog_kinds_measured": kinds},
                f"the catalog measured no {' or '.join(kinds)} on this file under the plan's roles, and {mechanism} is its rule "
                f"(threshold {catalog.KIND_THRESHOLD.get(kinds[0], 'none')}: {getattr(T, catalog.KIND_THRESHOLD.get(kinds[0], ''), 'n/a')})")
    return None


#: The kinds whose decision a port extension in the plan accounts for: both are "this run is too short", and a
#: plan that extends the mouth has fixed it before the mesher sees it. Read from the catalog's own mechanism map so
#: a kind added to the same mechanism is covered without being typed out again.
_EXTENSION_SETTLES = frozenset({"short_stub", "short_inlet_run"})


def _decision_reason(r: Risk, plan: GeometryPlan, proceed: bool) -> str:
    """The sentence a catalog decision's `derivation` should carry when THIS PLAN already contains the reason, or ""
    when only the analyst can say (R18b, and see the rule's own comment).

    Two readings, both facts about the plan or the brief rather than judgements:

    - a short run decided on a mouth the plan extends in `mesh_plan.port_extensions`: the extension IS the reason,
      it is in the plan, and `_second_look_table` already excuses the same mouth on the same grounds ("o2 is
      extended in mesh_plan.port_extensions"), so the checker was rejecting a plan for not restating what it reads
      two rules later;
    - a non-blocking risk decided under a brief that says to proceed: the `proceed` clause of `_check_risks`
      DEMANDS this decision in the same round it is rejected for having no reason behind it, and the reason is the
      clause's own.

    Anything else is the analyst's and is still rejected, which is what keeps this from becoming a rubber stamp."""
    if r.kind in _EXTENSION_SETTLES:
        oid = (r.measurement or {}).get("opening_id")
        ext = next((e for e in plan.mesh_plan.port_extensions if e.patch_id == oid), None)
        # AN EXTENSION NOTHING APPLIES IS NOT A FIX, AND ITS LENGTH WAS NEVER READ.
        #
        # This wrote "so the short run is fixed rather than accepted" into the plan's own record from the
        # mere EXISTENCE of an entry for the mouth. Measured on manifold_short, internal_cfd: catalog risk
        # k2 short_stub, severity high, o3 at 1.5 D against a required 5.0 D; a plan carrying
        # port_extensions [{patch_id: o3, length: 0.0}] was ACCEPTED with errors == [], and its derivation
        # read "the run at o3 is extended by 0 ... so the short run is fixed". A zero-length extension
        # standing down a high-severity decision, in the plan's own words.
        #
        # Two things have to be true for that sentence, and neither was checked:
        #   1. the extension has to REACH the run the catalog asked for. `required_over_diameter` is on the
        #      risk's own measurement, so there is nothing to look up.
        #   2. something has to APPLY it. `hexera.HANDOVER_READERS['advisory.port_extensions']` is
        #      ('none', 'tessellate_internal writes the faces as they are', '8.8') - nothing does. The key
        #      is advisory until step 8.8 lands.
        #
        # While (2) holds the sentence cannot be true at ANY length, so the extension settles nothing and
        # the decision keeps its question for the customer, which is the outcome the platform now has a
        # surface for. When 8.8 lands and the reader is no longer 'none', (1) is the gate that remains.
        if ext is not None and _extension_is_applied() and _extension_reaches(r, ext):
            return (f"the run at {oid} is extended by {ext.length:.6g} in mesh_plan.port_extensions before meshing, so the short "
                    "run is fixed rather than accepted (written by the checker from the plan's own extension)")
    if proceed and r.severity != "blocking" and r.user_decision in ("continue", "fix"):
        # continue and fix only: those are the two the `proceed` clause demands, so those are the two whose reason is
        # the clause's. An `abort` or a `change_purpose` under the same brief is a judgement of the analyst's and
        # the checker has no sentence for it.
        return ("the brief instructs proceeding without questions, so the catalog's decision is taken as the default and its "
                "question keeps that default for the user to overturn (written by the checker from the brief's instruction)")
    return ""



def _extension_is_applied() -> bool:
    """Does anything in the pipeline actually act on `mesh_plan.port_extensions`?

    Read off the same table the prompt hands the model, so this cannot drift from what the model is told:
    `HANDOVER_READERS['advisory.port_extensions']` names its reader, and today that reader is `none`. A key
    nothing reads cannot fix anything, whatever the plan writes beside it.
    """
    from geometry_agent.agent import hexera
    row = getattr(hexera, "HANDOVER_READERS", {}).get("advisory.port_extensions")
    reader = (row[0] if isinstance(row, (list, tuple)) and row else row) or "none"
    return str(reader).strip().lower() not in ("", "none")


def _extension_reaches(r, ext) -> bool:
    """Is the extension long enough to reach the run the catalog asked for?

    `required_over_diameter` and `length_over_diameter` are on the risk's own measurement, so this compares
    what the plan added against what the catalog said was missing. An unmeasurable comparison is False: a
    reason we cannot check is not a reason, and this sentence is the record of why a high-severity decision
    was stood down.
    """
    m = getattr(r, "measurement", None) or {}
    need, have = m.get("required_over_diameter"), m.get("length_over_diameter")
    # `hydraulic_diameter` FIRST, because that is the key the risk actually carries. `catalog` writes a
    # short_stub measurement as {opening_id, length_over_diameter, hydraulic_diameter, length, terminated_by,
    # required_over_diameter, area, ...} and none of the other three names appears in it, so reading only
    # those made this return False on every real short_stub: the gate was unmeasurable by construction, and
    # its own docstring says an unmeasurable comparison is False. It does not bite today, because
    # `_extension_is_applied` is False and short-circuits before it, but this is the gate the comment above
    # says "remains" when step 8.8 lands a reader - at which point a wrong False would refuse every extension
    # that does reach, quietly, for the same reason.
    bore = (m.get("hydraulic_diameter") or m.get("diameter") or m.get("bore") or m.get("bore_m"))
    for v in (need, have, bore, getattr(ext, "length", None)):
        if isinstance(v, bool) or not isinstance(v, (int, float)) or v != v:
            return False
    if bore <= 0:
        return False
    return (have + (ext.length / bore)) >= need

def _reaches_a_key(mechanism: str) -> bool:
    """Whether acting on this mechanism reaches a platform key, read off the same table the prompt hands the model
    (`prompt.MECHANISM_LINES`, second column), so the checker and the prompt cannot disagree about it.

    WHY A CONTRADICTION MAY COST A ROUND ONLY WHEN IT CAN CHANGE THE MESH. On the live batch of 2026-09-26 a
    whole plan was lost to `agent_risks_considered[0]: the facts contradict dismissing jet_impingement: stubs o1,
    o2, o3 end at a junction ...; measure the run from the branch to the facing wall (derived_geometry
    run_between) and cite it`. Two things are wrong with spending a plan on it. The call the message names cannot
    express the measurement it asks for: `tools._point_arg` takes an opening id or `oN.stub_end` and nothing in
    the facts names "the facing wall", so no `run_between` argument exists that would satisfy the rule, and the
    same impossible measurement is what `MECHANISM_LINES["jet_impingement"]` asks the model for. And
    jet_impingement's reach is `note`: no key moves either way, so the dismissal and the risk produce the SAME
    mesh, and the round buys prose.

    Where the reach is a key (tilted_mouth_skew -> surface_level, cell_starvation -> cells_across,
    swirl_no_symmetry -> no half model, recirculation_at_outlet -> a user question,
    thermal_interface_unshared -> glue in CAD) a wrong dismissal does change what the builder is handed, and the
    rejection is worth its round. That is the line, and it is drawn by the reach rather than by the mechanism's
    name."""
    from geometry_agent.agent.prompt import MECHANISM_LINES

    reach = (MECHANISM_LINES.get(mechanism) or ("", ""))[1].strip().lower()
    return bool(reach) and reach != "note"


#: The `derived_geometry` op that settles each contradictable dismissal, or None where no op measures it. Only
#: three mechanisms can be contradicted (`_dismissal_fact`: a bend, a junction, a junction with a closed end), and
#: this says which of the three the analyst can answer in one call. `dead_leg` takes the junction opening and the
#: closed end and returns the signed length, so that contradiction is a one-round fix and keeps its rejection. No
#: op returns a bend radius or a distance to a facing wall, so those two cannot be answered as asked, and
#: `_contradiction_costs_a_round` repairs them instead. `test_the_contradiction_table_names_ops_that_exist` holds it to
#: `tools.DERIVED_OPS`, so an op added or renamed cannot leave a mechanism claiming a call that is not there.
CONTRADICTION_OP: dict[str, str | None] = {"dead_leg_stagnation": "dead_leg", "jet_impingement": None,
                                           "dean_secondary_flow": None}


def _contradiction_costs_a_round(mechanism: str) -> bool:
    """Whether a dismissal the facts contradict is a rejection: when acting on the mechanism reaches a builder key,
    or when a `derived_geometry` op measures the thing the message asks for. Otherwise the entry is repaired with
    the contradiction and the plan stands, because three rejections cost the whole plan and a note that moves no
    key cannot be worth one of them."""
    return _reaches_a_key(mechanism) or CONTRADICTION_OP.get(mechanism) is not None


def _check_considered(plan: GeometryPlan, ctx: ToolContext, expected: list[Risk], errors: list[str],
                      hints: dict[str, Any]) -> None:
    """R5 with the P4.3d reading (R26): a mechanism is dismissed either by a ledger number or by a named fact the
    checker can verify itself from the facts, and where it can, the entry is repaired with the fact it used instead
    of being rejected. "The part is nowhere near the ground" is a geometric fact and there is no single number
    behind it; the run dismissed ground_effect, dean_secondary_flow, jet_impingement and dead_leg_stagnation that
    way 84 times over 122 cases. Only a dismissal the facts contradict is rejected, and then the message names the
    topology it has to answer."""
    ledger = ctx.ledger.numbers
    for i, c in enumerate(plan.agent_risks_considered):
        tag = f"agent_risks_considered[{i}] (/agent_risks_considered/{i})"
        if c.mechanism not in MECHANISMS:
            errors.append(f"{tag}: mechanism {c.mechanism!r} is not one of {', '.join(MECHANISMS)}")
        if not c.why_not.strip():
            errors.append(f"{tag}: why_not is required")
        nums = _numbers_of(c.measurement)
        if nums and any(_measured(v, ledger) for v in nums):
            continue
        got = _dismissal_fact(c.mechanism, plan, ctx, expected) if c.mechanism in MECHANISMS else None
        if got is None:
            errors.append(f"{tag}: measurement must carry the ledger number that dismissed {c.mechanism} (a measurement or a "
                          "derived_geometry result). Every mechanism of the enum but `other` the checker settles from the facts "
                          "itself (a bend, a junction, a closed end, the bbox floor, the region count, the purpose, the "
                          "rotational order, or the catalog risk that carries it); `other` is yours to measure")
            continue
        fact, why = got
        if not fact:
            if _contradiction_costs_a_round(c.mechanism):
                errors.append(f"{tag}: the facts contradict dismissing {c.mechanism}: {why}")
                continue
            # R26b: the contradiction stands, the dismissal does not, and neither costs the plan (see the note
            # above `_reaches_a_key`). The entry keeps the mechanism it considered and says the checker's own
            # sentence about it, so `agent_risks_considered` cannot read as "dismissed" where it was not.
            c.why_not = f"NOT DISMISSED, the facts contradict it: {why}. The analyst wrote: {(c.why_not or '').strip()}"[:1000]
            hints.setdefault("warnings", []).append(
                f"R26b: {tag} dismissed {c.mechanism} and the facts contradict it ({why}); {c.mechanism} reaches no builder key "
                f"(prompt.MECHANISM_LINES) and no derived_geometry op measures what the message asks for "
                f"(grounding.CONTRADICTION_OP), so the entry now records the contradiction instead of the dismissal and the "
                "plan stands")
            continue
        c.measurement.update({k: v for k, v in fact.items() if k not in c.measurement})
        hints.setdefault("warnings", []).append(
            f"R26 repair: {tag} dismissed {c.mechanism} with no ledger number; the checker verified it from the facts ({why}) and "
            f"put {json.dumps(fact, default=str)} in the entry's measurement")
    if not any(r.detected_by == "agent" for r in plan.risks) and len(plan.agent_risks_considered) < 2:
        errors.append("agent_risks_considered (/agent_risks_considered): a plan with no agent risk lists at least two mechanisms "
                      "considered and dismissed, each {mechanism, measurement with a ledger number or a fact the checker can "
                      "verify, why_not}")


def _check_agent_risks_v3(plan: GeometryPlan, ctx: ToolContext, expected: list[Risk], errors: list[str]) -> None:
    """R3: every agent risk carries a mechanism, an effect, a target when the effect changes the mesh, derived
    values by derivation id, and a refuted_by naming a tool and a number. R4: an agent risk with the same
    mechanism on the same subject as a catalog risk is rejected naming the catalog id (other never counts);
    operating_point_missing is rejected pointing at mesh_plan.assumptions. R5 (`_check_considered`): the
    considered-and-dismissed list carries a ledger number or a fact the checker verifies."""
    names = _tool_names()
    called = _tools_called(ctx, names)
    have = {_risk_key(r) for r in plan.risks if r.detected_by == "catalog"}
    catalog_risks = [r for r in plan.risks if r.detected_by == "catalog"] + [r for r in expected if _risk_key(r) not in have]
    index_of = {r.id: i for i, r in enumerate(plan.risks)}
    agents = [r for r in plan.risks if r.detected_by == "agent"]
    for r in agents:
        tag = f"agent risk {r.kind}"
        if r.kind == "operating_point_missing":
            errors.append(f"risk {r.id} (operating_point_missing): not a risk under plan schema 3; write the missing operating point as "
                          "a line in mesh_plan.assumptions and size the layer target from the placeholder its reason states "
                          "(/mesh_plan/assumptions), then drop this risk")
            continue
        if r.mechanism is None:
            errors.append(f"{tag}: mechanism is required, one of {', '.join(MECHANISMS)} (other needs a refuting test like every mechanism)")
        if r.effect is None:
            errors.append(f"{tag}: effect is required (changes_mesh, changes_bc or advisory): what acting on this risk does")
        elif r.effect == "changes_mesh" and not r.target:
            errors.append(f"{tag}: effect changes_mesh needs a target in the builder's frame (level_delta, sphere, box, "
                          "extension_length, seed_point, layers, gmsh_size_value)")
        rb = (r.refuted_by or "").strip()
        # R24: the message names the tools this run actually called, so "a tool of this run" is not a guess
        if not rb:
            errors.append(f"{tag}: refuted_by is required: one sentence naming one of the tools this run called "
                          f"({', '.join(called)}) and the number from it that would refute this risk")
        elif not any(n in rb.lower() for n in names) or not NUMBER.search(rb):
            missing = [w for w, ok in (("no tool of this run", any(n in rb.lower() for n in names)),
                                       ("no number", bool(NUMBER.search(rb)))) if not ok]
            errors.append(f"{tag}: refuted_by names {' and '.join(missing)}; write one of {', '.join(called)} and the reading that would "
                          f"refute this risk, as 'section_profile(o3): area ratio 1.0 past the junction'; got {rb[:100]!r}")
        for key, value, ids in _derived_items(r):
            if not ids:
                errors.append(f"{tag}: derived {key}={value:.6g} cites no derivation id; take it from derived_geometry and cite its id "
                              "(schema 3: every derived value by its id)")
        if r.mechanism and r.mechanism != "other":
            mine = _ids_in(r.measurement)
            for c in catalog_risks:
                cm = c.mechanism or catalog.KIND_MECHANISM.get(c.kind)
                if cm != r.mechanism or cm == "other":
                    continue
                theirs = _ids_in(c.measurement)
                shared = mine & theirs
                if shared or (not mine and not theirs):
                    # R24: name the pointer the amend goes to, so "put it into k2" is an edit and not a search
                    at = index_of.get(c.id)
                    where = (f"/risks/{at}/derived, /risks/{at}/derivation or the question that relates_to {c.id}" if at is not None else
                             f"{c.id} (add it from missing_catalog_risks first: it is not in the plan yet)")
                    errors.append(f"{tag}: mechanism {r.mechanism} on {sorted(shared) or 'the body'} is catalog risk {c.id} ({c.kind}); "
                                  f"remove this risk (/risks/{index_of.get(r.id)}) and put the extra reasoning into {where}")
                    break


def _regions_on_the_metal(plan: GeometryPlan) -> list:
    return [rr for rr in plan.mesh_plan.refinement_regions if ON_THE_METAL.search(rr.where or "") or ON_THE_METAL.search(rr.reason or "")]


#: The magnitudes an agent-written mesh warning states about THIS part, which therefore have to be numbers this
#: run measured. The builder knobs beside them (level_delta, cells_across, max_cells, the layer count and its
#: ratio) are settings, not measurements, and are left alone; so are the coordinates, which R1 already holds to a
#: patch or a region the facts know.
WARNING_MEASURED_KEYS = ("bore", "min_dim", "thickness", "gap", "tilt_deg", "angle_deg")
#: `size.length` is the exception, and the stored transcripts are why: on a wake warning the model writes the box
#: it wants, which is a multiple of a measured length (wing_007's 2287.8 is five chords, bend_elbow_019's 1067.56
#: is five bores). Those are the only four hits the rule had on the 159 recordings of learning_v4_b, and all four
#: are that. So a length is held the way a refinement region's numbers are, derivable from a measurement, and the
#: five keys above, where a measurement is what the field means, are held to the ledger itself.
WARNING_DERIVED_KEYS = ("length",)


def _check_warning_numbers(w, i: int, ctx: ToolContext, errors: list[str]) -> None:
    """Every magnitude an agent's mesh warning states is a number this run measured (R39).

    A mesh warning is the one structured field that reaches the builder carrying a size, and until now nothing
    traced those numbers: a warning carrying `size {bore: 42.5}` off the picture was accepted with no complaint at
    all, which is the hole the always-on look makes worth closing. The message names the picture through
    `_untraced` the way every other untraced number does."""
    ledger = ctx.ledger.numbers
    radius = w.target.sphere.radius if w.target.sphere is not None else None
    # a feature's size is the measurement that carries the warning, so it is held to the ledger itself; a length
    # and every target is a number the plan works out from one, so each is held the way a refinement region's is.
    # The difference matters: `_derivable` accepts any ledger number times a power of two, and 42.5 is a triangle
    # count times one sixty-fourth on the pipe fixture, so a bore from the picture walked through the looser test
    fields = [(f"size.{k}", getattr(w.size, k, None), _measured) for k in WARNING_MEASURED_KEYS]
    fields += [(f"size.{k}", getattr(w.size, k, None), _derivable) for k in WARNING_DERIVED_KEYS]
    fields += [("target.sphere.radius", radius, _derivable),
               ("target.extension_length", w.target.extension_length, _derivable),
               ("target.gmsh_size_value", w.target.gmsh_size_value, _derivable)]
    for key, v, traced in fields:
        if v is None or traced(float(v), ledger):
            continue
        pointer = "/mesh_warnings/{}/{}".format(i, key.replace(".", "/"))
        errors.append(f"mesh_warnings[{i}] ({pointer}): {key}={v} is not a number measured on this part; write the tool result "
                      "that carries it, or a derived_geometry value by its id" + _untraced(float(v), ctx))


def _size_restates_value(w: Any) -> str:
    """The `size` field that is a copy of `target.value` on a key that takes a count, "" when there is none.

    Asking for `size` beside a row of platform keys bought a new way to fill it: `n_layers 5` with
    `size {length: 5}`, `max_cells 2000000` with `size {length: 2000000}`. Five layers is not a length and two
    million cells is not a length, so that item tells the builder where to look and nothing about how big the
    thing there is, while looking like it does. A missing size is a hole the checker already names; this one is a
    fact that lies, which is worse, so it is refused by name.

    Only on `catalog.COUNT_KEYS`. On `reference_length_m` the value IS the body's own length and a `size.length`
    equal to it is two readings agreeing, not one of them copied."""
    if not catalog.counted_key(w.target.key):
        return ""
    value = w.target.value
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        return ""
    for name, got in w.size.model_dump().items():
        if isinstance(got, (int, float)) and not isinstance(got, bool) and float(got) == float(value):
            return name
    return ""


def _target_clause(w: Any, regime: str) -> str:
    """What to say when an agent warning reaches the check with an empty `target`, and there are two cases.

    THE CHECKER EMPTIED IT. `_classify.demote` pops `key` and `value` off a target whose key no reader consumes,
    so an item whose whole target was that key arrives here with nothing in it. 101 of the 134 target complaints
    in the 176-draw run arrived beside the R40 note naming the key that had just been thrown away, as note eleven
    of a warnings list, beside an error saying the field was missing. "Your target is missing" is then a fact that
    lies, and the amend it asks for is the one the model already made: on `ahmed_variant_002` draw 1 the model
    wrote `level_delta`, was told the target was missing, wrote `gmsh_size_value`, got the same sentence back,
    wrote `{}` and the run ended. So the demotion is what the error says, in the error, with the key named.

    THE MODEL WROTE NONE. Then the clause names the legal set for THIS regime and the note form separately. It
    used to offer `level_delta, sphere, box, extension_length, seed_point, layers, gmsh_size_value, cells_across`
    in the same clause as the platform keys, joined by "or": those are `MeshTarget`'s sibling FIELDS, and 93 of
    the 197 keys the model wrote over the run were one of them, 45 of those `level_delta` alone. A refusal that
    does not say what would be accepted buys nothing, so this one names the keys and where they came from."""
    from geometry_agent.agent import prompt as _prompt
    keys = ", ".join(sorted(catalog.DIRECTIVE_KEYS.get(regime) or {}))
    demoted = str((w.provenance or {}).get("demoted") or "")
    if demoted:
        # the reason already names the readable keys whenever the demotion was about readability, so naming them
        # twice in one sentence is the table the rejection is already too long to carry twice
        named = "one of those keys" if keys and keys in demoted else f"a key a reader consumes on {regime} ({keys})"
        return (f"target: you DID write one and the checker dropped it: {demoted}. That is why the field is empty here "
                f"and it is not something you left out. Either name {named}, with a value in the range the request's "
                f"{_prompt.BUILDER_KEYS_HEADING} row states, or keep the measurement as a note, whose extent goes in "
                f"target's own fields (level_delta, sphere, box, extension_length, seed_point, layers, "
                f"gmsh_size_value, cells_across, max_cells): those are fields of `target` and never values of `key`")
    return (f"target: an instruction, {{key, value}} with one of the keys a reader consumes on {regime} "
            f"({keys}), listed with its range under {_prompt.BUILDER_KEYS_HEADING} in the request; or, when no key "
            f"there reaches the feature, a note, whose extent goes in target's own fields (level_delta, sphere, box, "
            f"extension_length, seed_point, layers, gmsh_size_value, cells_across, max_cells). Those are fields of "
            f"`target` and never values of `key`")


def _check_mesh_warnings(plan: GeometryPlan, ctx: ToolContext, expected: list[Risk], errors: list[str]) -> None:
    """A model-written mesh_warnings list is checked: known patch ids only, and a catalog warning's kind is one the
    catalog calibrates (R1). R25 (P4.3d): an agent warning may name any snake_case kind, and in exchange it carries
    what the builder acts on - a location the facts know, a size, a target in the builder's frame, a why - and no
    claim to a calibrated threshold (`_repair_mesh_warnings` strips that one). R6: a tilted circular mouth on a
    carve (the catalog's tilted_circular_mouth) without a mesh warning of that kind naming it. R7: no refinement
    region on a wall shell's metal, and no sphere coarser than the builder's wall cell."""
    facts = ctx.facts
    T = current_thresholds()
    rep = catalog.representation(facts, ctx.purpose, ctx.brief, declared=ctx.declared, fluid_side=ctx.fluid_side)
    # the row of keys this case reads, exactly as `_channel_of` reads it, without paying for the emulator: the
    # message that refuses a target has to name the same set the request named or one of the two is lying
    regime = catalog.regime_of(catalog.engine_from_brief(ctx.brief, ctx.purpose), rep)
    known = {o.id for o in facts.openings}
    # a place the facts know: a measured region, or a thin cluster (the builder is told where the thin metal is)
    region_ids = {r.id for r in facts.regions} | {c.id for c in facts.features.thin_clusters}
    patch_ids = {p.id for p in plan.patches}
    mws = plan.mesh_warnings or []
    for i, w in enumerate(mws):
        tag = f"mesh_warnings[{i}] (/mesh_warnings/{i})"
        for pid in w.location.patch_ids:
            if pid not in known and pid not in patch_ids:
                errors.append(f"{tag}: location.patch_ids names {pid!r}, which is neither a measured opening {sorted(known)} nor a patch of this plan")
        if w.location.region_id is not None and w.location.region_id not in region_ids:
            errors.append(f"{tag}: location.region_id {w.location.region_id!r} is neither a measured region nor a thin cluster "
                          f"{sorted(region_ids)}")
        if w.detected_by != "agent":
            # a kind the catalog RAISED on this part is a catalog kind whatever its audience: the fill reads the
            # rule for its target and its sentence either way (`_catalog_rules_by_kind`), and R42 folds an item
            # into a user-audience rule like short_stub, which the builder reads as a note
            if w.kind not in catalog.MESH_WARNING_KINDS and w.kind not in {r.kind for r in expected}:
                errors.append(f"{tag}: kind {w.kind!r} is not a calibrated builder kind {sorted(catalog.MESH_WARNING_KINDS)} and the "
                              "catalog raised no risk of that kind on this part; a kind of your own is detected_by 'agent' and "
                              "carries location, size, target and why")
            continue
        missing = []
        if not catalog.agent_warning_kind_ok(w.kind):
            errors.append(f"{tag}: kind {w.kind!r} is not a name a builder can read; write your own kind in snake_case "
                          "(wake_refinement, cell_starvation), the feature, not the remedy")
        if not (w.location.patch_ids or w.location.point or w.location.region_id
                or w.target.sphere is not None or w.target.box is not None or w.target.seed_point is not None):
            missing.append("location: location.patch_ids, a measured opening id from the packet's openings_detail, or "
                           "location.point, a centroid or a probe_section point (a sphere or box target counts as one)")
        if not any(v is not None for v in w.size.model_dump().values()):
            missing.append("size: bore, min_dim, thickness, gap, tilt_deg, angle_deg or length, the measurement that carries "
                           "it, off the opening or the cluster you name (get_opening, derived_geometry, section_profile)")
        if not any(v is not None for v in w.target.model_dump().values()):
            missing.append(_target_clause(w, regime))
        if not (w.why or "").strip():
            missing.append("why: one sentence stating that measurement in the builder's frame, never how the mesh turns out")
        restated = _size_restates_value(w)
        if restated:
            errors.append(f"{tag}: size.{restated} is {getattr(w.size, restated)}, which is the value you are setting "
                          f"{w.target.key} to, and {w.target.key} takes a count. HOW BIG is the feature's own "
                          "measurement at the place you named, in the file's unit: the bore, the min_dim, the "
                          "thickness, the gap, the tilt_deg, the angle_deg or the length you measured on it. An "
                          "item whose size restates its instruction has answered one question twice and the "
                          "builder has no measurement to size a cell against")
        if missing:
            errors.append(f"{tag}: kind {w.kind!r} is your own and names nothing the catalog measured on this part, which is "
                          "accepted, and then every field is yours to supply; the builder needs " + "; ".join(missing))
        _check_warning_numbers(w, i, ctx, errors)
    _check_builder_items(plan, ctx, rep, errors)
    for r in expected:
        if r.kind != "tilted_circular_mouth":
            continue
        # one item carries every tilted mouth, because `surface_level` is global; each id still has to be named
        named = {i for w in mws if w.kind == "tilted_circular_mouth" for i in w.location.patch_ids}
        missing_ids = [i for i in (r.measurement.get("opening_ids") or [r.measurement.get("opening_id")]) if i and i not in named]
        for oid in missing_ids:
            errors.append(f"mesh_warnings (/mesh_warnings): the circular mouth {oid} is tilted "
                          f"{float((r.measurement.get('tilt_deg_by_id') or {}).get(oid) or r.measurement.get('tilt_deg') or 0):.3g} "
                          f"degrees off the {r.measurement.get('grid_axis')} axis, over TILTED_MOUTH_DEG {T.TILTED_MOUTH_DEG:g}; a carve needs a "
                          f"mesh warning of kind tilted_circular_mouth naming {oid} in location.patch_ids, and on internal snappy its "
                          "instruction is target {key: surface_level, value: 1}, which is what puts the port cap at the wall level "
                          "(snappy_runner.py:636); level_delta and a sphere have no reader")
    if ctx.purpose not in INTERNAL:
        return
    if rep == "wall_shell":
        for rr in _regions_on_the_metal(plan):
            errors.append(f"refinement {rr.where!r}: on a wall shell the thin metal is not meshed (the cavity is carved inside it); "
                          "no refinement region on the wall's thickness; drop it or anchor it in the fluid (a junction, a gap between passages)")
    frame = _builder_frame_for(plan.model_dump(), ctx, rep)
    wall_cell = float(frame.get("wall_cell") or 0.0)
    if wall_cell > 0:
        for rr in plan.mesh_plan.refinement_regions:
            if rr.kind == "sphere" and rr.target_size > wall_cell * (1.0 + REL_TOL):
                errors.append(f"refinement {rr.where!r}: sphere target_size {rr.target_size:.4g} is coarser than the builder's wall cell "
                              f"{wall_cell:.4g} (inlet bore {float(frame.get('bore') or 0):.4g} over cells_across {frame.get('cells_across')}); "
                              "it refines nothing the builder does not already do; size it under the wall cell or drop it")


def _check_effects(plan: GeometryPlan, errors: list[str]) -> None:
    """R8: a question or a simulation warning whose default exists but whose effect is missing is rejected; a
    question exists only when its effect is not advisory."""
    for q in plan.questions:
        if q.default is not None and q.effect is None:
            errors.append(f"question {q.id}: effect is required when a default exists (changes_mesh, changes_bc or advisory): "
                          "what taking the default does")
        elif q.effect == "advisory":
            errors.append(f"question {q.id}: effect advisory; a question exists only when its answer changes the mesh or a boundary "
                          "condition; drop it and keep the note in mesh_plan.notes")
    for i, w in enumerate(plan.simulation_warnings or []):
        tag = f"simulation_warnings[{i}] (/simulation_warnings/{i}/effect)"
        if w.default is not None and w.effect is None:
            errors.append(f"{tag}: default {w.default!r} exists but effect is missing (changes_mesh, changes_bc or advisory)")
        elif w.question and w.effect == "advisory":
            errors.append(f"{tag}: a question with effect advisory; a warning asks only when the answer changes the mesh or a boundary condition")


def _r9_declared_pairs(ctx: ToolContext) -> dict[str, dict]:
    if not ctx.declared:
        return {}
    rep = catalog.representation(ctx.facts, ctx.purpose, ctx.brief, declared=ctx.declared, fluid_side=ctx.fluid_side)
    return catalog.declared_pairs(ctx.facts, catalog.port_openings(ctx.facts, rep, ctx.declared), ctx.declared, rep)


def _r9_verdict(view: dict[str, Any], ctx: ToolContext, pairs: dict[str, dict]) -> str | None:
    """R9 on one question: why the brief already ANSWERS it, or None. `view` is the question as either a model or
    a dict has it: {id, text, relates_to, kind, kinds, agent, role_ids}. One reading, used by the R27 repair that
    moves the question to `settled_questions` and by the rule that reports what the repair could not reach.

    Every branch answers the question it fires on, and says which phrase did it (P4.4). A phrase that names the
    question's subject without answering it is not a branch here: the outlet's boundary condition does not decide
    whether the outlet run may be extended, and the engine does not decide the fidelity tier."""
    brief = ctx.brief or ""
    kinds, kind = view["kinds"], view["kind"]
    if kinds & STUB_QUESTION_KINDS:
        hit = R9_SETTLES["short_stub"].search(brief)
        if hit:
            return (f"the brief declines a geometry change ({hit.group(0)!r}), which answers whether to extend the short run; it is not "
                    "a question here: the risk stands at user_decision continue with the phrase in derivation")
    if kinds & UNIT_QUESTION_KINDS or view["relates_to"] == "unit":
        hit = R9_UNIT_IN_BRIEF.search(brief)
        settled, _why = _unit_settled_by_brief(ctx)
        if hit and settled:
            return (f"the brief writes its dimensions with a unit ({hit.group(0)!r}), which settles the file unit ({settled}); drop the "
                    "question and set unit.basis brief")
    role_ids = view["role_ids"]
    if role_ids and pairs and all(i in pairs for i in role_ids):
        named = ", ".join(f"{pairs[i].get('name')!r} ({pairs[i].get('role')}) at {i}" for i in sorted(role_ids))
        return (f"the role of {sorted(role_ids)} is declared ({named}); a declared port is not a role question: give the patch the "
                "declared role with confirmed_by_user and drop the question")
    # the text pattern reads the model's own questions; a catalog question carries its kind (the rotor_topology
    # question says "8-fold rotational symmetry" and is not a half-model question: 16 export rotor cases failed on it)
    if kind == "symmetry_opportunity" or (view["agent"] and R9_SYMMETRY_QUESTION.search(view["text"] or "")):
        hit = R9_SETTLES["symmetry_opportunity"].search(brief)
        if hit:
            return f"the brief says {hit.group(0)!r}, which answers whether to mesh half the domain; it is not a question here: drop it"
    # the tier is read before the engine: a question about dropping the tier to fit the cap is a tier question,
    # and naming the engine does not answer it (P4.4; every export brief writes "Engine: snappyHexMesh")
    text = view["text"] or ""
    if view["relates_to"] == "fidelity" or (view["agent"] and R9_FIDELITY_QUESTION.search(text)):
        hit = R9_FIDELITY_IN_BRIEF.search(brief)
        if hit:
            return f"the brief names the fidelity tier ({hit.group(0)!r}), which answers it; it is not a question: drop it"
    elif view["agent"] and R9_ENGINE_QUESTION.search(text):
        hit = R9_ENGINE_IN_BRIEF.search(brief)
        if hit:
            return f"the brief names the engine ({hit.group(0)!r}), which answers it; it is not a question: drop it"
    return None


def _check_false_alarms(plan: GeometryPlan, ctx: ToolContext, errors: list[str]) -> None:
    """R9, what the R27 repair could not reach: a question the brief ANSWERS while a risk it names still asks a
    pending decision (the repair moves the rest to `settled_questions` in `_normalise`, and only the question,
    never the decision). The patterns are `_r9_verdict`, re-derived at P4.4 so each one answers the question it
    fires on: a short-run question under a brief that declines a geometry change ("geometry is final", "as
    built"); a unit question under a brief dimension whose unit settles the file unit; a role question on a
    declared port; a symmetry question under "full 3D" or "no symmetry"; a fidelity question under the brief's own
    tier; an engine question under the brief's own engine."""
    risk_by_id = {r.id: r for r in plan.risks}
    pairs = _r9_declared_pairs(ctx)
    for q in plan.questions:
        r = risk_by_id.get(q.relates_to)
        kind = r.kind if r is not None else None
        role_ids: set[str] = set()
        if r is not None and r.kind in R9_ROLE_KINDS:
            role_ids = _role_ids(r)
        elif r is None and OPENING_ID.fullmatch(q.relates_to or ""):
            role_ids = {q.relates_to}
        view = {"id": q.id, "text": q.text, "relates_to": q.relates_to, "kind": kind, "agent": r is None or r.detected_by == "agent",
                "kinds": {kind} | {risk_by_id[x].kind for x in q.also_settles if x in risk_by_id}, "role_ids": role_ids}
        why = _r9_verdict(view, ctx, pairs)
        if why:
            errors.append(f"question {q.id}: {why}")


def _direction_in_doubt(plan: GeometryPlan, ctx: ToolContext, role_assumed: bool) -> list[str]:
    """Why the flow direction is an assumption (R11): role_assumed fires, a question asks a role, or a port role
    is under COUNTERFACTUAL_BELOW with no declared ports."""
    reasons = []
    if role_assumed:
        reasons.append("role_assumed fires")
    risk_by_id = {r.id: r for r in plan.risks}
    known = {o.id for o in ctx.facts.openings}
    asked = [q.id for q in plan.questions
             if (q.relates_to in risk_by_id and risk_by_id[q.relates_to].kind in ROLE_DECISION_KINDS) or q.relates_to in known]
    if asked:
        reasons.append(f"question {asked[0]} asks a role")
    if not ctx.declared:
        low = [p.id for p in plan.patches if p.role in ("inlet", "outlet") and p.confidence < COUNTERFACTUAL_BELOW]
        if low:
            reasons.append(f"port role confidence under {COUNTERFACTUAL_BELOW:g} on {low} with no declared ports")
    return reasons


def _direction_is_asked(plan: GeometryPlan, ctx: ToolContext, ports: set[str]) -> str | None:
    """The question that puts the flow direction to the customer, as the sentence R11 quotes; None when nothing on
    the confirmation screen asks it. `ports` are the openings the swap would change roles on.

    A question counts when it settles a role decision (`ROLE_DECISION_KINDS`) on one of those openings, or when it
    names one of them directly - which is the same test `_direction_in_doubt` uses to decide the counterfactual is
    required in the first place, narrowed to the mouths in question. IT IS NARROWED ON PURPOSE: a question about a
    drain's role is not a question about which way the run flows, and answering "something asks a role somewhere"
    would let the plan keep an assignment nobody is going to look at.

    The reading is of the NORMALISED plan, so the questions `_normalise` injects for every pending catalog role
    risk are in it: a role risk the catalog raised and nobody answered is always asked, and this function is how
    the rule knows that."""
    risk_by_id = {r.id: r for r in plan.risks}
    for q in plan.questions:
        for rid in [q.relates_to, *q.also_settles]:
            r = risk_by_id.get(rid)
            if r is None or r.kind not in ROLE_DECISION_KINDS:
                continue
            named = _ids_in(r.measurement)
            if not named or (named & ports):
                return f"question {q.id} puts {r.kind} risk {r.id} to the user"
        if q.relates_to in ports:
            return f"question {q.id} asks what opening {q.relates_to} is"
    return None


# The catalog's high risks under a plan's roles and under the swap is `tools.role_swap_diff` (P4.4), which
# replaced a private `_role_diff` here: one comparison, run by the checker for R11 and by the `compare_roles`
# tool for the model, recorded in the ledger under a derivation id, so the number the checker prices the swap
# with is a number a plan may cite. R11 passes it the plan's own fidelity, as every other catalog run the
# checker makes does, and keeps the purpose gate on the "strictly worse" clause where `_role_diff` had it.


def _second_look_table(plan: GeometryPlan, ctx: ToolContext, expected: list[Risk]) -> list[dict[str, Any]]:
    """The second look recomputed by the checker (R10): one row per item it can compute for the purpose, with
    ok, the number, a note, the clause that made it ok (`why`, what the R19 repair reports back when the model
    wrote a cautious no) and what to write when it is not ok (`fix`, R24)."""
    from geometry_agent.agent import tools
    facts = ctx.facts
    T = current_thresholds()
    mp = plan.mesh_plan
    rep = catalog.representation(facts, ctx.purpose, ctx.brief, declared=ctx.declared, fluid_side=ctx.fluid_side)
    known = {o.id: o for o in facts.openings}
    role_of = {p.id: p.role for p in plan.patches}
    ledger = ctx.ledger.numbers
    rows: list[dict[str, Any]] = []

    def row(item: str, ok: bool, number: float | None, note: str, why: str = "", fix: str = "") -> None:
        rows.append({"item": item, "ok": bool(ok), "number": number, "note": note, "why": why or note, "fix": fix})

    text_blob = " ".join([*mp.assumptions, *mp.notes, plan.analysis, plan.summary_for_builder]).lower()
    if ctx.purpose in INTERNAL:
        ports = [o for o in catalog.port_openings(facts, rep, ctx.declared) if role_of.get(o.id) in ("inlet", "outlet", "opening_unknown")]
        mws = plan.mesh_warnings or []
        warned = {pid for w in mws if w.kind == "tilted_circular_mouth" for pid in w.location.patch_ids}
        tilted = [o for o in ports if rep == "wall_shell" and tools.mouth_shape(o, rep) == "circle" and tools.mouth_tilt(o)[0] >= T.TILTED_MOUTH_DEG]
        max_tilt = max((tools.mouth_tilt(o)[0] for o in ports), default=0.0)
        missing = [o.id for o in tilted if o.id not in warned]
        row("mouths", not missing, round(max_tilt, 4),
            "every mouth grid-aligned or carrying a tilted-mouth warning" if not missing else f"tilted mouths without a warning: {missing}",
            why=(f"the tilted-mouth rule is a carve rule and this file measures as {rep}, so a tilt of {max_tilt:.3g} deg costs nothing"
                 if rep != "wall_shell" else
                 f"a tilted_circular_mouth mesh warning names {sorted(o.id for o in tilted)}" if tilted else
                 f"every mouth is within {T.TILTED_MOUTH_DEG:g} deg of its grid axis"),
            fix=f"give each of {missing} a mesh warning of kind tilted_circular_mouth naming it in location.patch_ids")
        decided = {r.measurement.get("opening_id") for r in plan.risks if r.kind == "short_stub" and r.user_decision != "pending"}
        extended = {e.patch_id for e in mp.port_extensions}
        short = []
        min_run = None
        excused: list[str] = []
        for oid in plan.flow.outlet_ids:
            s = facts.stub(oid)
            if s is None:
                continue
            min_run = s.length_over_diameter if min_run is None else min(min_run, s.length_over_diameter)
            if s.length_over_diameter >= T.STUB_OK_OVER_D:
                continue
            if oid in decided:
                excused.append(f"a short_stub decision was taken at {oid}")
            elif oid in extended:
                excused.append(f"{oid} is extended in mesh_plan.port_extensions")
            else:
                short.append(oid)
        row("outlet_runs", not short, round(min_run, 3) if min_run is not None else None,
            f"every outlet run at least {T.STUB_OK_OVER_D:g} D or a decided short_stub" if not short else f"undecided short outlet runs: {short}",
            why="; ".join(excused) or f"every outlet run is at least {T.STUB_OK_OVER_D:g} D",
            fix=f"take the short_stub decision on {short} (user_decision continue or fix, the reason in derivation) or extend them in "
                "mesh_plan.port_extensions")
        inlet = next((known[i] for i in plan.flow.inlet_ids if i in known), None)
        if mp.seed_point is not None and inlet is not None:
            # THE ROW READS THE RULE THAT OWNS THE SEED, not a stricter test of its own. `_check_mesh_plan` accepts a
            # seed within half a bore of ANY measured point or measured axis (`_anchored`), which is what a seed
            # "just inside the run" is; this row measured the distance to the INLET alone and called 8.7 bores down
            # a serpentine channel not ok, so the checker rejected a plan whose seed the checker itself accepts.
            # A check must be able to fail differently from the thing it checks; two spellings of one test cannot.
            #
            # AND RAY PARITY IS NOT A REASON WHEN IT DID NOT RUN. `inside is None` never moved `ok`, yet the note
            # said "ray parity not run (no mesh on disk)" inside a rejection's reason, which reads as the thing the
            # line failed on - a measurement that does not exist at plan time and no amend can produce. It is now
            # reported only when it was tested, because a fact that lies is worse than a missing one.
            bore = tools.port_bore(inlet, rep) or inlet.hydraulic_diameter or 0.0
            dist = math.dist(mp.seed_point, inlet.centroid)
            over = dist / bore if bore > 0 else None
            parity = catalog._seed_parity(facts, tuple(mp.seed_point), rep) if rep == "wall_shell" else None
            inside = parity.get("inside") if parity and parity.get("tested") else None
            anchored = _anchored(mp.seed_point, facts, ledger, plan)
            ok = anchored and inside is not False
            parity_note = (", inside the cavity by ray parity" if inside else
                           ", NOT inside the cavity by ray parity" if inside is False else "")
            where = ("on a measured point or axis" if anchored else
                     f"not within {ANCHOR_SNAP_OVER_D:g} bores of any measured point or axis")
            note = (f"seed {dist:.4g} from inlet {inlet.id} ({over:.3g} bores), {where}{parity_note}" if over is not None
                    else f"seed {where}{parity_note} (the inlet has no bore)")
            row("seed", ok, round(over, 4) if over is not None else None, note,
                why=note,
                fix=f"move mesh_plan.seed_point within {ANCHOR_SNAP_OVER_D:g} bores of a measured point or axis - just inside "
                    f"{inlet.id} along its inward normal from centroid {[round(c, 4) for c in inlet.centroid]} is one - "
                    "or leave it out and let the checker place it")
        frame = _builder_frame_for(plan.model_dump(), ctx, rep)
        smallest = frame.get("smallest_port") if frame else None
        if smallest and smallest.get("cells_across_builder") is not None:
            cells = float(smallest["cells_across_builder"])
            row("smallest_port", cells >= T.PORT_CELLS_MIN, round(cells, 3),
                f"smallest port {smallest['id']} gets {cells:.1f} builder cells at cells_across {frame.get('cells_across')} (floor {T.PORT_CELLS_MIN:g})",
                why=f"the smallest port {smallest['id']} gets {cells:.1f} builder cells, at or above the floor of {T.PORT_CELLS_MIN:g}",
                fix=f"raise cells_across (a port_resolution target) until {smallest['id']} gets {T.PORT_CELLS_MIN:g} builder cells, or "
                    "add a surface region on its bore")
        on_metal = _regions_on_the_metal(plan) if rep == "wall_shell" else []
        row("metal", not on_metal, float(len(on_metal)),
            "no refinement region on the metal" if not on_metal else f"regions on the wall's metal: {[r.where for r in on_metal]}",
            why="no refinement region names the wall's metal (thin, thickness, skin)" if rep == "wall_shell" else
                "the file is not a wall shell, so it has no metal to refine",
            fix=f"drop the regions {[r.where for r in on_metal]} or reword them: the cavity is the mesh, its skin is not")
        axis = plan.flow.axis
        if axis is not None:
            n = math.sqrt(sum(c * c for c in axis)) or 1.0
            unit_vec = sum(1 for c in axis if abs(abs(c) - 1.0) < 1e-6) == 1 and sum(1 for c in axis if abs(c) < 1e-6) == 2
            principal = any(abs(sum(a * b for a, b in zip(axis, p)) / (n * (math.sqrt(sum(c * c for c in p)) or 1.0)))
                            >= math.cos(math.radians(FLOW_AXIS_SNAP_DEG)) for p in facts.axes.principal)
            row("flow_axis", unit_vec or principal, None, "the flow axis is a principal axis or a unit vector" if (unit_vec or principal)
                else f"flow axis {list(axis)} is neither a principal axis nor a unit vector",
                why="the flow axis is a coordinate unit vector" if unit_vec else
                    f"the flow axis is a measured principal axis within {FLOW_AXIS_SNAP_DEG:g} degrees",
                fix=f"write flow.axis as a coordinate unit vector or as one of the measured principal axes "
                    f"{[[round(c, 4) for c in p] for p in facts.axes.principal][:3]}")
        bores = sorted(tools.port_bore(o, rep) for o in catalog.port_openings(facts, rep, ctx.declared) if tools.port_bore(o, rep) > 0)
        layers = [lt for lt in mp.layer_targets if lt.n_layers > 0 and lt.first_cell_height > 0]
        if layers and bores:
            lo, hi = FIRST_CELL_OVER_BORE
            bad = []
            ratio = None
            unit = _plan_unit(plan, ctx)
            for lt in layers:
                ratio = lt.first_cell_height / bores[0]
                stated = _first_cell_in_reason(lt.reason)
                in_band = lo * bores[0] <= lt.first_cell_height <= hi * bores[0]
                equal = True
                if stated is not None:
                    v, u = stated
                    equal = _within(lt.first_cell_height * tools.UNIT_TO_M[unit] / tools.UNIT_TO_M[u], v)
                if not (in_band and equal):
                    bad.append(lt.patch_id)
            row("first_cell", not bad, round(ratio, 6) if ratio is not None else None,
                f"first cell within {lo:g} to {hi:g} of the smallest bore {bores[0]:.4g} and equal to its reason" if not bad
                else f"first cell out of band or unequal to its reason on {bad}",
                why=f"the first cell is inside {lo:g} to {hi:g} of the smallest bore {bores[0]:.4g} and equals the number its reason states",
                fix=f"on {bad}, write the first_cell_height derived_geometry recorded (in the plan's unit) and state that number in the "
                    "layer target's reason")
    elif ctx.purpose == "external_cfd":
        absent = [k for k in EXTENT_KEYS if k not in mp.required_extents]
        # R35: presence was the whole of this row, and 31 of 31 external plans of the learning-half v3 run passed
        # it, 16 of them with the far field written in metres in a millimetre plan. The magnitude is the row now
        unit = _plan_unit(plan, ctx)
        ext_rows = _extent_rows(mp.required_extents, facts, unit)
        out = [r for r in ext_rows if not r["in_band"]]
        lo, hi = EXTENT_OVER_L
        worst = min((r["ratio"] for r in ext_rows), default=None)
        row("extents", not absent and not out, worst if worst is not None else float(len(mp.required_extents)),
            f"the four extents present, each {lo:g} to {hi:g} x the body extent" if not (absent or out) else
            (f"missing extents {absent}" if absent else
             "; ".join(_extent_message(r, unit) for r in out[:2])),
            why=f"mesh_plan.required_extents carries all four of {list(EXTENT_KEYS)}, each between {lo:g} and {hi:g} "
                "times the body's own longest extent",
            fix=(f"add {absent} to mesh_plan.required_extents (absolute lengths in the plan's unit)" if absent else
                 f"rewrite {[r['key'] for r in out]} as absolute lengths in {unit}: the standard multiples are "
                 f"{T.EXTERNAL_UPSTREAM_OVER_L:g} L upstream, {T.EXTERNAL_DOWNSTREAM_OVER_L:g} L downstream and "
                 f"{T.EXTERNAL_LATERAL_OVER_L:g} L lateral, where L is the body's own extent"))
        planar_floor = any(o.on_bbox_face and o.bbox_side == "z_min" for o in facts.openings)
        stated = bool(re.search(r"\bground\b|\bfloor\b|\broad\b", text_blob))
        row("ground", (not planar_floor) or stated, None,
            "no planar face on the bbox minimum z" if not planar_floor else ("ground contact stated" if stated else "the bbox minimum z face is planar and no ground contact is stated"),
            why="no planar face lies on the bbox minimum z, so there is no ground contact to state" if not planar_floor else
                "the ground plane is stated in the plan's prose",
            fix="say the body sits on the ground in mesh_plan.assumptions, mesh_plan.notes, analysis or summary_for_builder (the checker "
                "reads those four for the words ground, floor or road; a second_look note is not one of them)")
        base = mp.base_size or 0.0
        wake = [rr for rr in mp.refinement_regions if rr.kind == "box" and re.search(r"\bwake\b", (rr.where or "") + " " + (rr.reason or ""), re.I)]
        coarse = [rr.where for rr in wake if base > 0 and rr.target_size >= base]
        row("wake", not coarse, min((rr.target_size for rr in wake), default=None),
            "wake box finer than the base size, or absent" if not coarse else f"wake box not finer than the base size {base:.4g}: {coarse}",
            why="the plan writes no wake box" if not wake else f"every wake box is finer than the base size {base:.4g}",
            fix=f"size {coarse} at {base / 2:.4g} or finer (one level under the base size {base:.4g}), or drop the box")
        knives = facts.features.knife_edge_count
        preserved = any(re.search(r"knife|trailing|sharp", f, re.I) for f in mp.preserve_features) or \
            any(rr.kind == "feature_edges" for rr in mp.refinement_regions)
        row("knife_edges", knives == 0 or preserved, float(knives),
            "no knife edge" if knives == 0 else ("knife edges preserved" if preserved else f"{knives} knife edges and nothing preserves them"),
            why="the file has no knife edge" if knives == 0 else "the plan preserves the knife edges",
            fix="name the knife or trailing edges in mesh_plan.preserve_features, or add a feature_edges refinement region")
    elif ctx.purpose == "conjugate_heat_transfer":
        coincident = [i for i in facts.interfaces if getattr(i, "kind", "shared") == "coincident"]
        glued = [i for i in facts.interfaces if getattr(i, "kind", "shared") == "shared"]
        ok = not coincident or bool(glued)
        row("interfaces", ok, float(len(glued)), "every interface shared" if ok else f"{len(coincident)} coincident, unshared interface(s)",
            why="no coincident unshared interface was measured" if not coincident else f"{len(glued)} interface(s) are shared",
            fix="carry the unshared_interface (or no_shared_interface) risk with its decision: the faces are glued in CAD, not in the mesh")
        fluid = [r.id for r in mp.regions if r.role == "fluid"]
        by_region = {o.id: o.region_id for o in facts.openings}
        sealed = bool(re.search(r"sealed|natural convection", text_blob))
        without = [rid for rid in fluid if not any(by_region.get(pid) == rid and role_of.get(pid) in ("inlet", "outlet") for pid in role_of)]
        row("fluid_ports", (not without) or sealed, float(len(fluid)),
            "every fluid region has ports" if not without else ("fluid region declared sealed" if sealed else f"fluid region(s) {without} have no port and are not declared sealed"),
            why="every fluid region has an inlet or an outlet" if not without else "a fluid region without a port is declared sealed",
            fix=f"give {without} an inlet or outlet patch, or say sealed (or natural convection) in mesh_plan.assumptions, notes, "
                "analysis or summary_for_builder")
    elif ctx.purpose == "structural":
        no_flow = plan.flow.axis is None and not plan.flow.inlet_ids and not plan.flow.outlet_ids and plan.flow.direction_sign == 0
        row("no_flow", no_flow, None, "no flow fields" if no_flow else "flow fields on a structural case",
            why="the plan writes no flow fields",
            fix="a structural case has no flow: axis null, inlet_ids and outlet_ids empty, direction_sign 0")
        layered = [lt.patch_id for lt in mp.layer_targets if lt.n_layers > 0]
        row("no_layers", not layered, float(len(layered)), "no layers" if not layered else f"layers on {layered}",
            why="the plan grows no prism layers",
            fix=f"set n_layers 0 (and first_cell_height 0) on {layered}: a structural mesh grows no boundary layer")
    return rows


def _second_look_kind(purpose: str) -> str:
    return "internal" if purpose == "internal_cfd" else "cht" if purpose == "conjugate_heat_transfer" else "external" if purpose == "external_cfd" else "structural"


def _check_second_look(plan: GeometryPlan, ctx: ToolContext, expected: list[Risk], errors: list[str], hints: dict[str, Any]) -> None:
    """R10: the second look recomputed line by line for the items the checker can compute. Only one direction is
    a rejection: the line claims ok=True where the checker finds False, which is a claim the plan cannot support.

    R19 (P4.3b): the other direction is a cautious no where the checker knows an exception the model did not, and
    a cautious no must never cost a round. The line is replaced with the checker's own verdict, number and note,
    and the clause that made it ok is logged in hints["warnings"] ("ok: a short_stub decision was taken at o2"),
    so the exception is learned rather than guessed. The checker's whole table rides in hints["second_look"]."""
    if not plan.second_look:
        return
    table = {r["item"]: r for r in _second_look_table(plan, ctx, expected)}
    hints["second_look"] = list(table.values())
    patterns = [(name, re.compile(words, re.I)) for name, words in SECOND_LOOK_ITEMS[_second_look_kind(ctx.purpose)]]
    for i, line in enumerate(plan.second_look):
        name = next((n for n, pat in patterns if pat.search(line.item or "")), None)
        if name is None or name not in table:
            continue
        mine = table[name]
        if bool(line.ok) == mine["ok"]:
            continue
        number = f" (number {mine['number']:.4g})" if isinstance(mine["number"], (int, float)) else ""
        if mine["ok"]:
            line.ok = True
            line.number = mine["number"] if isinstance(mine["number"], (int, float)) else line.number
            line.note = mine["note"]
            hints.setdefault("warnings", []).append(
                f"R19 repair: second_look[{i}] {line.item!r} said ok=False where the checker finds ok=True{number}; ok: "
                f"{mine['why']}. The line now carries the checker's verdict, number and note (a cautious no is never a rejection)")
            continue
        errors.append(f"second_look[{i}] (/second_look/{i}): the line {line.item!r} says ok=True, the checker finds ok=False: "
                      f"{mine['note']}{number}; " + (f"{mine['fix']}, or " if mine["fix"] else "")
                      + "amend this line to ok=False with the checker's number and note")


def _missing_v3_tail(normalised: Any) -> list[str]:
    """R32 (P4.3d): the schema 3 fields a plan that will not parse is also missing, as one line each.

    A plan cut off mid-JSON keeps its required fields (the loop salvages the largest valid prefix) and loses the
    optional tail the schema 3 rules demand next, so the model fixed the four fields pydantic named and was
    rejected a second time for `identity_hypotheses` and `agent_risks_considered`. Both rounds are the one cut, so
    the whole list travels with the first rejection - in `hints`, not in `errors`, because a rejection whose every
    error is a missing required field is how the loop knows the submission was truncated rather than judged
    (`tools.missing_fields_only`), and this list must not spoil that reading."""
    if not isinstance(normalised, dict) or plan_version(normalised) < V3:
        return []
    return [f"/{f}: {what}" for f, what in V3_TAIL_FIELDS if not normalised.get(f)]


def check_with_hints(plan_obj: dict[str, Any], ctx: ToolContext,
                     salvaged: bool = False) -> tuple[GeometryPlan | None, list[str], dict[str, Any]]:
    """Like check(), plus machine-usable hints for the resubmission: the catalog risks the plan is missing for
    the roles it actually declares, verbatim, so a model that changed roles after list_risks does not need
    another round to fetch them.

    A plan that does not parse carries `hints["missing_v3_tail"]`: the schema 3 fields the rules ask for next,
    which pydantic cannot report because they are optional at the type level (R32). The errors stay pure missing
    field lines so the loop's own reading of a truncated submission is untouched. `salvaged` says the arguments
    were cut off mid-JSON and the loop recovered the prefix (loop.salvage_json); it changes no verdict and marks
    the rejection `hints["truncated"]`, so the learning ledger can count the round against the output limit rather
    than the model's judgement. The loop may pass it, or set `ctx.last_plan_salvaged` instead."""
    errors: list[str] = []
    hints: dict[str, Any] = {}
    notes: list[str] = []
    salvaged = bool(salvaged or getattr(ctx, "last_plan_salvaged", False))
    normalised = _normalise(plan_obj, ctx, notes)
    if notes:
        hints.setdefault("warnings", []).extend(notes)

    def short(errs: list[str]) -> tuple[None, list[str], dict[str, Any]]:
        tail = _missing_v3_tail(normalised)
        if tail:
            hints["missing_v3_tail"] = tail
            if salvaged:
                hints["truncated"] = True
        return None, errs, hints

    if isinstance(normalised, dict) and not normalised.get("unit"):
        return short(["schema: ('unit',): Field required: state the file unit as {declared: what the file says or null, assumed: the "
                      "unit every size below is in, basis: file | brief | user | guess}"])
    try:
        plan = GeometryPlan.model_validate(normalised)
    except ValidationError as exc:
        return short([f"schema: {e['loc']}: {e['msg']}" for e in exc.errors()][:20])

    facts = ctx.facts
    if plan.facts_sha256 != facts.sha256:
        errors.append(f"facts_sha256 must be {facts.sha256}")
    if plan.purpose != ctx.purpose:
        errors.append(f"purpose must be {ctx.purpose!r} (the user's), got {plan.purpose!r}")

    role_of = _check_patches(plan, ctx, errors)
    _check_flow(plan, ctx, role_of, errors)
    expected = _check_risks(plan, ctx, role_of, errors, hints)
    _check_mesh_plan(plan, ctx, role_of, errors)
    _check_questions(plan, ctx, role_of, errors)
    _check_unit(plan, ctx, errors)
    _check_vision_citations(plan, errors)
    _check_derived(plan, ctx, errors)
    _check_first_cells(plan, ctx, errors)
    _check_counterfactual(plan, ctx, expected, errors, hints)
    if plan.schema_version >= V3:
        _check_identity(plan, ctx, errors)
        _check_agent_risks_v3(plan, ctx, expected, errors)
        _check_considered(plan, ctx, expected, errors, hints)
        _check_mesh_warnings(plan, ctx, expected, errors)
        _check_effects(plan, errors)
        _check_false_alarms(plan, ctx, errors)
        _check_second_look(plan, ctx, expected, errors, hints)
        if len(plan.analysis) > ANALYSIS_MAX_CHARS:
            errors.append(f"analysis must be at most {ANALYSIS_MAX_CHARS} characters (got {len(plan.analysis)}); reasoning goes in the "
                          "plan's structured fields (evidence, derivation, reason, second_look), not in prose")
        prose = _builder_prose(plan.summary_for_builder)
        if len(prose) > BUILDER_PROSE_MAX_CHARS:
            errors.append(f"summary_for_builder must be at most {BUILDER_PROSE_MAX_CHARS} characters of prose after the unit (got "
                          f"{len(prose)}): every port by id, then what the mesh_plan fields do not say; "
                          "the strategy header is generated by the handover")

    if not plan.summary_for_builder.strip() or not plan.summary_for_user.strip():
        errors.append("both summaries must be non-empty")
    else:
        sb = plan.summary_for_builder
        unnamed = [p.id for p in plan.patches if p.role in ("inlet", "outlet") and p.id not in sb and (p.name or "\x00") not in sb]
        if unnamed:
            errors.append(f"summary_for_builder must name every port patch by id or name; missing {unnamed}")
    if len(plan.analysis.strip()) < 40:
        errors.append("analysis must record the reasoning (identity, required topology, what the geometry provides, brief vs measurement, what will break)")
    if math.isnan(plan.object.confidence):
        errors.append("object.confidence is NaN")
    return (plan if not errors else None), errors, hints
