"""What the look may be trusted to say, field by field, carried in the block instead of kept in a doc.

A consumer downstream must not have to remember which fields earned their place. It reads the tier off the
block. That is the whole point of this module: the finding below is a measurement, and a measurement belongs
in a value a reader can act on, not only in a paragraph someone has to have read.

THE LEDGER. Measured on all 322 corpus parts with the file name hidden, reader gpt-5.6-luna, and held out on
a second brief-derived ground truth (`eval/vision/holdout.py`). Written up in `docs/vision.md`. Nothing in
this module re-derives any of it; every `why` below quotes it.

THE THREE TIERS, and the difference between them is what a consumer may DO with the field.

  relied_on  the field earned its place. Act on it.
  candidate  the field points at something worth measuring. It is never the answer on its own: the
             measurement sizes it, the plan decides whether it is worth the cells, and until then nothing
             downstream may turn on it.
  recorded   the field is kept so a person can read what the model said, and for nothing else. It never
             drives a decision and it is never put in front of another model.

`defects` is the clearest recorded field and the reason the tier exists. Over the corpus it raised three to
five false alarms on clean files and caught neither of the two files that have a real defect, so it has
never once been right. It reaches a human and nothing else, and `for_model` below is what makes that true in
code rather than in a warning nobody reads.

THE IDENTITY CAP lives here too, with its reason attached, because 0.6 written in one file with no number
beside it is a magic number. `agent/grounding.py` reads `IDENTITY_CONFIDENCE_MAX` from here, so the checker
and the block cannot disagree about it.
"""
from __future__ import annotations

from typing import Any

TRUST_SCHEMA = "geometry_agent.look_trust.v1"

RELIED_ON = "relied_on"
CANDIDATE = "candidate"
RECORDED = "recorded"
TIERS = (RELIED_ON, CANDIDATE, RECORDED)

TIER_MEANING = {
    RELIED_ON: "measured to be right often enough to act on",
    CANDIDATE: "a place to measure, never an answer: the measurement confirms it or it does not count",
    RECORDED: "kept so a person can read what was said; it drives no decision and reaches no model",
}

LEDGER = ("322 corpus parts, file name hidden, reader gpt-5.6-luna, held out on a second brief-derived "
          "ground truth (eval/vision/holdout.py); written up in docs/vision.md")

#: R38. An identity whose only named support is the picture may not carry more confidence than this.
IDENTITY_CONFIDENCE_MAX = 0.6
IDENTITY_CONFIDENCE_MAX_WHY = (
    "the name of the part is right on 215 of 322 at best, and the verdict changes on 9 to 11 of 40 "
    "identical repeat calls, so a name from the picture alone is about two thirds of an answer and is not "
    "reproducible; 0.6 is the ceiling that says so")
IDENTITY_CONFIDENCE_MAX_ENFORCED_BY = (
    "geometry_agent.agent.grounding.VISION_ONLY_CONFIDENCE_MAX, which rejects a plan whose object identity "
    "names no support but the picture and carries more")

#: What the look claims that held out WORST, named so a reader of the block can see them rather than
#: discovering them in a plan. They arrive inside `internal_features` and `notes`, which is why both are
#: tiered away from relied_on whatever they say.
CONTESTED_CLAIMS = (
    "a dead leg: 0 of 13 held out",
    "a closed header: 0 of 18 held out",
    "a capped end of any kind: the measurement reads one off the openings and the look named none on the 31 "
    "held-out parts that have one, so prose implying a passage runs straight through settles nothing",
    "a diffuser cone: 0 to 1 of 13, it sees a sudden widening and never names the feature",
)

#: The static half of the table: tier, the measured reason, and where the measurement already has the same
#: thing when it does. `scored` is False for a field the ledger never scored, and such a field is a
#: candidate rather than a relied-on one precisely because nothing measured it.
FIELDS: dict[str, dict[str, Any]] = {
    "looks_like": {
        "tier": CANDIDATE, "scored": True,
        "why": "right on 215 of 322 at best, and the verdict changes on 9 to 11 of 40 identical repeat calls",
        "read_as": "a name to confirm with the customer, never a name to state",
    },
    "confidence": {
        "tier": RELIED_ON, "scored": True,
        "why": "high against not-high separates at p <= 1.3e-03 on all four arms",
        "read_as": "a trigger, not a score: act on high, and do not read the low end as a number",
    },
    "orientation": {
        "tier": RECORDED, "scored": True,
        "why": "the measurement has this exactly, and the picture is the weaker of the two",
        "measurement_has_it": "axes.principal, axes.blunt_end_sign, openings[].normal",
    },
    "openings_seen": {
        "tier": RELIED_ON, "scored": True,
        "why": "which labelled mouths it can see is 91 to 94 percent recall, Jaccard 1.00 on a repeat call",
        "read_as": "the SET of ids it names is the finding; each field inside an entry is tiered on its own",
    },
    "openings_seen[].id": {
        "tier": RELIED_ON, "scored": True,
        "why": "91 to 94 percent recall on the labelled mouths, Jaccard 1.00 on a repeat call",
        "read_as": "an id of 'unlabelled' is the look reporting a mouth the measurement did not find, which "
                   "is the one thing here no measurement can supply",
    },
    "openings_seen[].looks_like": {
        "tier": RECORDED, "scored": True,
        "why": "opening class is a thing the measurement has exactly",
        "measurement_has_it": "openings[].kind, openings[].classification, openings[].shape",
    },
    "openings_seen[].mouth": {
        "tier": CANDIDATE, "scored": False,
        "why": "never scored on its own, and no measurement reports whether a mouth stands proud, sits "
               "flush in the wall or sits down in a pocket",
        "read_as": "worth measuring where a port extension is being considered, never worth asserting",
    },
    "openings_seen[].likely_role": {
        "tier": RECORDED, "scored": True,
        "why": "it abstains on six of every seven declared mouths, and the abstention is the product; where "
               "it does guess it is right 48 percent of the time, which is a coin flip",
        "read_as": "never a role. A role comes from the customer or from nowhere",
    },
    "internal_features": {
        # tier is decided by the value: see `_internal_features`
        "tier": CANDIDATE, "scored": True,
        "why": "Jaccard 0.31 to 0.46 from one call: the finding repeats, the wording does not",
        "read_as": "a place to measure. An EMPTY list is the stronger statement and is relied on: 0 false "
                   "obstructions on 103 plain-passage cases",
    },
    "sharp_edges": {
        "tier": CANDIDATE, "scored": False,
        "why": "never scored on its own",
        "measurement_has_it": "thickness.sharp_edge_count and thickness.knife_edge_count, which are counts "
                              "and say nothing about where",
    },
    "attachments": {
        "tier": RELIED_ON, "scored": True,
        "why": "25 of 25 recall at 93 to 100 percent precision, stable in every arm, and no measurement "
               "reports one at all",
    },
    "thin_parts": {
        "tier": CANDIDATE, "scored": False,
        "why": "never scored on its own",
        "measurement_has_it": "thickness.thin_clusters, which have a thickness and a centroid",
    },
    "defects": {
        "tier": RECORDED, "scored": True,
        "why": "three to five false alarms on clean files and zero catches on the two files that have a "
               "real defect: it has never once been right",
        "read_as": "for a person to read. It must not reach a planner, an intake model or a customer",
    },
    #: THE FOUR FIELDS THE PROMPT ASKS FOR AND THIS TABLE DID NOT NAME. Before this they fell through
    #: `tier_of`'s default and came back `recorded`, so `tiered()` never split them, `for_model` never carried
    #: them, and the two the corpus measures highest were buried by an omission rather than by a decision.
    "marks_seen": {
        "tier": RELIED_ON, "scored": True,
        "why": "on the one thing the renderer can check, whether the letter stands on material or in open "
               "space, it agrees 1,524 / 1,476 / 1,517 / 1,481 times a draw and disagrees 5 / 10 / 8 / 24 "
               "(four draws, 322 parts, combo_sa, deterministic arithmetic off cached replies). Read against "
               "its control, the next part's answers at this part's letters, which agree 1,237 / 1,194 / "
               "1,232 / 1,195 and disagree 296 / 298 / 299 / 316: about 285 a draw over chance, and every "
               "agreement is something the renderer classified before it drew the letter",
        "read_as": "a PLACE the renderer nominated and the look answered. The letter is the subject and the "
                   "renderer holds its coordinate, so this is the one look field that can be addressed",
        "measured_only": "material or space. No measurement in this pipeline has a word for WHAT the solid "
                         "is, and on 63 of 322 parts the representation makes even that unreadable",
    },
    "stops_seen": {
        "tier": RELIED_ON, "scored": True,
        "why": "agrees 33 / 36 / 32 / 34 a draw against 0 / 1 / 1 / 3 disagreements, on the 32 parts that get "
               "a panel; and driver 5 of the round-five coverage table, every stop the terminus found, was "
               "0 of 322 in the delivered document on both arms",
        "read_as": "one answer per panel, in panel order, and the panel order IS the measurement's own list "
                   "of stopped openings, so each answer carries an opening id and therefore a centroid",
        "measured_only": "that the panel was drawn at all. `find_stops` returns nothing on a fluid domain by "
                         "design, so a missing panel there is the measurement's gap and not the look's",
    },
    "could_not_check": {
        "tier": RECORDED, "scored": True,
        "why": "empty on 322 of 322 parts of the shipped arm: the door variants that asked for it did not "
               "ship, so there is nothing in it to deliver",
        "read_as": "nothing, today. It is kept in the record because a variant still asks for it",
    },
    "cannot_tell": {
        "tier": RECORDED, "scored": True,
        "why": "empty on 322 of 322 parts of the shipped arm, and the screened form of it fired on 87 of 92 "
               "and flagged no gap",
        "read_as": "nothing, today",
    },
    #: THE TRAVERSAL (work/vf-walk). Its prompt arms were killed and are named by `GEOMETRY_AGENT_VISION_PROMPT`
    #: only, so the shipped variant never asks for it and the normaliser writes an empty list on every shipped
    #: look. Entered here rather than left to `tier_of`'s default, which would give the same tier by omission,
    #: which is the fault the four entries above were written to end. What ships from that branch is the
    #: checker, `reconcile.walk`, and it grades a walk reply off the mesh; it never reads this tier.
    "walk": {
        "tier": RECORDED, "scored": True,
        "why": "empty on every look the shipped prompt produces: both walk arms were killed (`walk` false "
               "denials 8, 9, 8, 7 of 65 against a control of 10, 7, 8, 9, p = 0.771; `walk_alone` lost true "
               "denials, p = 0.143), so nothing that ships asks for it",
        "read_as": "nothing, today. Kept in the record because a variant still asks for it",
    },
    "symmetry": {
        "tier": RECORDED, "scored": True,
        "why": "the measurement has this exactly",
        "measurement_has_it": "symmetry.scores, symmetry.planes, symmetry.rotational_axis, "
                              "symmetry.rotational_order",
    },
    "notes": {
        "tier": RECORDED, "scored": True,
        "why": "free prose, and the claims that land here are the ones that held out worst",
        "contested": list(CONTESTED_CLAIMS),
    },
}

#: The impression's own field names, in the order `vision.prompt.normalise_impression` writes them, READ FROM
#: THE PROMPT rather than copied.
#:
#: IT WAS COPIED AND IT WENT STALE, which is the ninth instance of the fault this project keeps meeting: a
#: second spelling of one list drifts and nobody finds out from the code. The prompt grew to fifteen fields and
#: this tuple still named eleven, so `tiered()` walked a list that did not contain `marks_seen` or
#: `stops_seen`, the two fields the corpus scores highest, and they reached no tier and therefore no consumer.
#: A hand-written list cannot be wrong about this if it is not hand-written.
from geometry_agent.vision.prompt import IMPRESSION_FIELDS, not_asked  # noqa: E402


def not_asked_fields() -> tuple[str, ...]:
    """The record's fields the SHIPPED prompt never asks for, read from the prompt and not listed here.

    FIVE OF THE SIXTEEN. `orientation` and `symmetry` were taken out of the prompt on a measurement
    (`vision.prompt.SYSTEM`'s own note); `could_not_check`, `cannot_tell` and `walk` belong to arms that did not
    ship. The normaliser writes every field on every look, so each of the five is in the record at its empty
    value, and an empty value is not an answer: `_internal_features` is the proof that this project reads an
    empty list as a finding where the field was asked for, and reading one the same way where it was not would
    be the look saying it looked. `tiered()` therefore leaves them out, `fields_for()` marks them `asked: False`,
    and `trust_for()` names them, so a consumer sees the silence as silence.

    Not a new TIER, deliberately: `contract.ratchet.TIER_ORDER.index` would raise on a fourth one, and the
    question this answers is not how much the field is trusted, it is whether anybody asked."""
    return not_asked()

#: What the table says about a field the shipped prompt does not ask for. It is not "the look found nothing".
NOT_ASKED_READ_AS = ("nothing: the shipped prompt does not ask for this field, so the value in the record is the "
                     "empty one the parser writes and not an answer the look gave")

#: What an empty `internal_features` means, which is the one asymmetry in the table: the absence of a
#: finding is measured and the finding itself is not.
PLAIN_INSIDE_WHY = ("0 false obstructions on 103 plain-passage cases: where it says nothing is across the "
                    "passage, nothing is")


def _internal_features(impression: dict) -> dict[str, Any]:
    """`internal_features` tiered by what it says, because empty and non-empty are different findings."""
    entry = dict(FIELDS["internal_features"])
    if not (impression.get("internal_features") or []):
        entry["tier"] = RELIED_ON
        entry["why"] = PLAIN_INSIDE_WHY
        entry["read_as"] = "an empty list is the finding: the passage is plain"
        return entry
    entry["contested"] = list(CONTESTED_CLAIMS)
    return entry


def tier_of(field: str, impression: dict | None = None) -> str:
    """The tier of one field, with the value taken into account where the value decides it."""
    if field == "internal_features":
        return str(_internal_features(impression or {})["tier"])
    entry = FIELDS.get(field)
    return str(entry["tier"]) if entry else RECORDED


def fields_for(impression: dict | None) -> dict[str, dict[str, Any]]:
    """The whole table, with every value-dependent tier resolved against this impression."""
    imp = impression if isinstance(impression, dict) else {}
    unasked = set(not_asked_fields())
    out: dict[str, dict[str, Any]] = {}
    for name, entry in FIELDS.items():
        row = _internal_features(imp) if name == "internal_features" else dict(entry)
        if name in unasked:
            row["asked"] = False
            row["read_as"] = NOT_ASKED_READ_AS
        out[name] = row
    return out


def trust_for(impression: dict | None) -> dict[str, Any]:
    """The trust block that rides with an impression.

    A reader of the JSON can tell a relied-on field from a recorded one without opening docs/vision.md:
    `fields[name].tier` says which, `tiers[tier]` says what the word means, and the three lists say it
    again in the form a consumer actually branches on.
    """
    fields = fields_for(impression)
    by_tier = {tier: sorted(n for n, e in fields.items() if e["tier"] == tier) for tier in TIERS}
    return {
        "schema": TRUST_SCHEMA,
        "ledger": LEDGER,
        "tiers": dict(TIER_MEANING),
        "fields": fields,
        "not_asked": sorted(not_asked_fields()),
        "may_decide": by_tier[RELIED_ON],
        "confirm_first": by_tier[CANDIDATE],
        "never_decides": by_tier[RECORDED],
        "identity_confidence_max": IDENTITY_CONFIDENCE_MAX,
        "identity_confidence_max_why": IDENTITY_CONFIDENCE_MAX_WHY,
        "identity_confidence_max_enforced_by": IDENTITY_CONFIDENCE_MAX_ENFORCED_BY,
    }


def tiered(impression: dict | None) -> dict[str, dict[str, Any]]:
    """The impression's own values split into the three tiers, for a reader that wants the values rather
    than the table. Opening entries are split field by field, because one entry carries all three tiers."""
    imp = impression if isinstance(impression, dict) else {}
    unasked = set(not_asked_fields())
    out: dict[str, dict[str, Any]] = {t: {} for t in TIERS}
    for name in IMPRESSION_FIELDS:
        if name == "openings_seen":
            continue
        if name not in imp:
            continue
        # a field the prompt never asked for carries the parser's empty value and not the look's answer, so it
        # is not put in a tier: a reader of a tier is reading what the look said (`not_asked_fields`)
        if name in unasked:
            continue
        out[tier_of(name, imp)][name] = imp[name]
    openings = [o for o in (imp.get("openings_seen") or []) if isinstance(o, dict)]
    if openings:
        out[RELIED_ON]["openings_seen"] = [str(o.get("id") or "unlabelled") for o in openings]
        mouths = {str(o.get("id") or "unlabelled"): str(o.get("mouth") or "unsure")
                  for o in openings if str(o.get("mouth") or "unsure") != "unsure"}
        if mouths:
            out[CANDIDATE]["opening_mouths"] = mouths
        out[RECORDED]["opening_classes"] = {str(o.get("id") or "unlabelled"): str(o.get("looks_like") or "unsure")
                                            for o in openings}
        out[RECORDED]["opening_roles"] = {str(o.get("id") or "unlabelled"): str(o.get("likely_role") or "unsure")
                                          for o in openings}
    return out


#: One short line per recorded field, so a consumer holding `for_model` can see WHY a field it might have
#: expected is not there. Short on purpose: it rides in a prompt.
WITHHELD_FROM_MODELS = {
    "defects": "3 to 5 false alarms on clean files, 0 catches on the two with a real defect",
    "likely_role": "a coin flip where it guesses; the measurement and the customer own a role",
    "opening_class": "the measurement has it exactly",
    "orientation": "the measurement has it exactly",
    "symmetry": "the measurement has it exactly",
    "notes": "free prose, and the claims that land there held out worst",
}

MODEL_CAVEAT = ("words from rendered views, not a measurement: every digit was removed before you saw it. "
                "relied_on was measured to be right often enough to act on; candidates are places to "
                "measure and are never facts on their own.")


#: How to read `at_places`, carried WITH the rows rather than left to a note on the other side of the boundary.
#: The boundary is an allowlist of keys (`meshpipeline.engines.snappy.planner.GEOMETRY_AGENT_BLOCK_KEYS`) and
#: its note names `relied_on`, `candidates` and `withheld` and nothing else, so a key whose meaning lives only
#: in that note would arrive unexplained. This sentence is the key's own explanation and travels with it.
AT_PLACES_CAVEAT = (
    "one finding per place, and the PLACE is measured while the words are not. The letter and the panel were "
    "chosen and drawn by the measurement before the model saw the picture, so where_m is a measured "
    "coordinate in metres and the_look_says is what the model wrote about that exact spot. where_from and "
    "where_missing are keys of at_places_where; a null where_m is never a guess. declined is the look saying "
    "it could not read that place, which is an answer and not a gap.")


#: Said beside the fields a prediction was taken out of. The same sentence the survey block carries for the same
#: rule (`agent.hexera.SEEN_REFUSED_WHY["predicts"]`), which reads this key rather than writing a second copy.
PREDICTS_REFUSED_WHY = ("the look's own words said how the finished mesh would come out, which the Surveyor "
                        "never does, so those words are dropped and the findings they were attached to are "
                        "named here; nothing else in this block was lost for them")


def _drop_predictions(relied: dict[str, Any], candidates: dict[str, Any],
                      rows: list[dict[str, Any]]) -> list[str]:
    """Take every predicting phrase out of the three, in place, and name the FIELDS that lost one.

    THESE THREE AND NOTHING ELSE, because they are the only parts of the dict `for_model` builds that hold the
    MODEL'S own words. Every other key it writes is a sentence this package wrote (`read_as`, `withheld`,
    `at_places_read_as`, `at_places_where`, `identity_confidence_max_why`) or a measured field, and running a
    rule about a model's words over our own prose would let the check meant to catch a model silently edit a
    constant of ours.

    The field a reader knows and not the path inside it: `attachments[2]` is `attachments` short by one. Placed
    rows are counted rather than named, because their names are the letters the renderer drew and a reader
    counting findings wants to know how many are missing.
    """
    # INSIDE THE FUNCTION, AND IT HAS TO BE. `contract/marks.py` reads `trust.IDENTITY_CONFIDENCE_MAX` at module
    # scope, so contract already imports THIS module; the same import at the top of this file fails on both
    # orders, `AttributeError: partially initialized module 'geometry_agent.vision.trust' has no attribute
    # 'IDENTITY_CONFIDENCE_MAX'` importing trust first and `ImportError: cannot import name 'ContractError'`
    # importing contract first. Tried, not assumed. This is a leaf call a handful of times a file, so the
    # deferred import costs nothing and moving it up costs the package its import.
    from geometry_agent.contract.survey import drop_outcome_claims, predicts_outcome
    fields: list[str] = []
    for group in (relied, candidates):
        cleaned, dropped = drop_outcome_claims(group)
        if dropped:
            group.clear()
            group.update(cleaned)
            fields.extend(p.split("[")[0].split(".")[0] for p in dropped)
    kept = [r for r in rows if not predicts_outcome(r.get("the_look_says"))]
    if len(kept) != len(rows):
        fields.append(f"at_places x{len(rows) - len(kept)}")
        rows[:] = kept
    return sorted(set(fields))


def for_model(impression: dict | None, *, model: str = "", provider: str = "",
              at_places: list[dict[str, Any]] | None = None) -> dict[str, Any] | None:
    """What may be put in front of another model: the relied-on fields, the candidates marked as such, and
    not one recorded field.

    None when there is nothing to say. `defects`, `likely_role`, `orientation`, `symmetry`, the per-opening
    class and `notes` are not in the dict this builds, so no downstream prompt can carry them by accident:
    that is the recorded tier expressed in code rather than in a comment.

    `at_places` is `vision.place.places(...)`: the two relied-on fields that carry a subject, joined to the
    coordinate the measurement issued for that subject. It is OPTIONAL and defaults to nothing, because the
    only caller that can supply it is one holding the render manifest, and the intake path
    (`meshpipeline.agents.intake.geometry_brief.look_at_it`) calls this function with an impression alone.
    A caller that passes nothing gets those two fields AS WORDS, which is the whole point of them being
    optional: an upgrade of the channel for the caller that can address a place, and not a condition on the
    finding being delivered at all.

    AND IT IS WHERE A PREDICTION IS TAKEN OUT, because this function is the definition of what may be put in
    front of a model and a forecast of how the mesh turns out is the one thing the Surveyor never says
    (`contract.survey.drop_outcome_claims`). It was done one layer up, in `hexera._planner_look`, which covered
    the typed block and left every other caller of this function open: `chain.job` puts `relied_on` straight
    into the GEOMETRY AGENT's own prompt, `chain.handover` hands the record's own view to a reader holding no
    typed block, and the platform's intake path calls this with an impression alone. Three channels to a model
    and one of them the agent that decides what to do. One drop here closes all of them and the caller that
    used to do it keeps nothing of its own to do.

    WHAT A PHRASE COSTS IS THE PHRASE. A placed row is one finding with one coordinate, so a row whose words
    predict goes whole; `relied_on` and `candidates` lose the element or the key, so the other attachments on a
    part are still delivered. A list the drop empties goes with its last element, because an empty list here
    MEANS the look found none (`inside_is_plain`), and a look that said something is not a look that found
    nothing. What went is named in `seen_refused`, because a list silently shortened reads as a complete one.

    NOT A SCRUB OF THE STORED RECORD. What the look actually said stays in the document for a person to read;
    this is the channel to a model, and `vision.prompt` scrubs the digits on the way in as this takes the words
    out on the way back.
    """
    imp = impression if isinstance(impression, dict) else None
    if not imp:
        return None
    split = tiered(imp)
    relied: dict[str, Any] = {}
    # `marks_seen` and `stops_seen` are in this list because they are RELIED_ON in the table above and the
    # list is what actually decides what leaves. Before, the two were named only in a pop below, whose
    # comment said they were dropped here deliberately because they travel as `at_places` - and they were
    # absent from this allowlist, so the pop removed nothing and the fields never arrived to be dropped.
    # MEASURED on an impression carrying both: `for_model(imp, model="m")` returned relied_on
    # ["attachments", "confidence", "openings_seen"] and neither field in any form. `at_places` is
    # optional and three of the four callers pass nothing - `chain.job`, which puts `relied_on` straight
    # into the GEOMETRY AGENT's own prompt, `chain.handover`, and the platform's intake path - so on
    # those three the two look fields the corpus scores highest reached nobody at all.
    for name in ("attachments", "confidence", "openings_seen", "internal_features",
                 "marks_seen", "stops_seen"):
        value = split[RELIED_ON].get(name)
        if value not in (None, "", []):
            relied[name] = value
    if not (imp.get("internal_features") or []):
        # the empty list is the finding, and a key that says so survives a consumer that drops empty lists
        relied["inside_is_plain"] = True
    candidates = {k: v for k, v in split[CANDIDATE].items() if v not in (None, "", [], {})}
    # A PLACED ROW REPLACES THE RAW PHRASES, AND ONLY WHERE THERE IS ONE.
    #
    # Where `at_places` carries a field's findings, each phrase arrives joined to the coordinate it is about,
    # and carrying the raw list as well would put the same finding in front of the model twice, once
    # addressable and once not. So the raw list goes - but keyed on what the rows ACTUALLY contain, not on the
    # caller having remembered to pass something. `kind` is the row's own record of which field it came from
    # (`vision.place.marked_places` and `.passage_ends` write it), which makes this a check of the
    # replacement rather than an assumption about it.
    #
    # The partial case is the reason it is written this way: `marked_places` skips an answer whose letter the
    # renderer has no record of drawing, so rows can cover the stops and none of the marks. Keyed on `kind`,
    # the placed half goes and the unplaced half is still delivered as words.
    rows = [r for r in (at_places or []) if isinstance(r, dict)]
    placed = {str(r.get("kind") or "") for r in rows}
    for name, as_a_row in (("marks_seen", "marked_place"), ("stops_seen", "passage_end")):
        if as_a_row in placed:
            relied.pop(name, None)
            candidates.pop(name, None)
    refused = _drop_predictions(relied, candidates, rows)
    if not relied and not candidates and not rows:
        return None
    out = {
        "is_measurement": False,
        "read_as": MODEL_CAVEAT,
        "relied_on": relied,
        "candidates": candidates,
        "withheld": dict(WITHHELD_FROM_MODELS),
        "identity_confidence_max": IDENTITY_CONFIDENCE_MAX,
        "identity_confidence_max_why": IDENTITY_CONFIDENCE_MAX_WHY,
        "model": str(model or ""),
        "provider": str(provider or ""),
    }
    if rows:
        from geometry_agent.vision.place import legend
        out["at_places"] = rows
        out["at_places_read_as"] = AT_PLACES_CAVEAT
        # the sentences behind `where_from` and `where_missing`, once for the whole list rather than on every
        # row, and only the ones these rows use
        out["at_places_where"] = legend(rows)
    if refused:
        # the caveat and the legend above explain a list that is not here when the drop took the last row, which
        # is why they are written from `rows` after it rather than before
        out["seen_refused"] = {"fields": refused, "why": PREDICTS_REFUSED_WHY}
    return out


#: The keys of one `openings_seen` entry a model may be shown. `id` is the finding (the SET of ids is relied on)
#: and `mouth` is a candidate. `looks_like` and `likely_role` are recorded, and `why` is tiered by nothing, which
#: `tier_of` reads as recorded: an unscored sentence is exactly the kind of prose the ledger keeps from a model.
OPENING_KEYS_FOR_MODELS: tuple[str, ...] = tuple(
    name.split("[].", 1)[1] for name, entry in FIELDS.items()
    if name.startswith("openings_seen[].") and entry["tier"] != RECORDED)


def model_safe(impression: dict | None) -> dict[str, Any]:
    """The impression with every field the ledger tiers `recorded` taken OUT, in the impression's own shape.

    `for_model` is the answer for a reader that takes the tiered dict. This is the answer for a reader that
    renders an impression as it stands, which is what the geometry agent's own model is shown today: the opening
    message prints `vision.prompt.impression_block(impression)` and the `look_at_views` tool returns the
    impression itself, so `defects`, `notes`, `orientation`, `symmetry` and every opening's guessed class and role
    reach that model, and whatever it writes from them reaches the builder in `builder_block`. Passing this
    instead closes that channel with no change to the prompt's layout.

    A recorded field is ABSENT here, never emptied. An empty `defects` list would read as "the look found no
    defect", which is a statement the look did not make; a renderer must print nothing for an absent field.

    THE TIER IS ALL THIS DECIDES. A prediction of how the mesh turns out is not a tier, it is a phrase, and it is
    taken out of this channel by `agent.tools.shown_to_model`, which is this function's one caller and the one
    place that can say what went in a form the agent's own reader prints. `for_model` does its own drop because
    the dict IT builds has a key for the record; this one hands back the impression's own shape, which has none.
    """
    imp = impression if isinstance(impression, dict) else {}
    out: dict[str, Any] = {}
    for name, value in imp.items():
        if name == "openings_seen":
            rows = [{k: o[k] for k in OPENING_KEYS_FOR_MODELS if k in o} for o in (value or [])
                    if isinstance(o, dict)]
            out[name] = rows
            continue
        if tier_of(name, imp) != RECORDED:
            out[name] = value
    return out


__all__ = ["AT_PLACES_CAVEAT", "CANDIDATE", "CONTESTED_CLAIMS", "FIELDS", "IDENTITY_CONFIDENCE_MAX",
           "IDENTITY_CONFIDENCE_MAX_ENFORCED_BY", "IDENTITY_CONFIDENCE_MAX_WHY", "IMPRESSION_FIELDS",
           "LEDGER", "MODEL_CAVEAT", "NOT_ASKED_READ_AS", "OPENING_KEYS_FOR_MODELS", "PLAIN_INSIDE_WHY",
           "RECORDED", "RELIED_ON",
           "TIERS", "TIER_MEANING", "TRUST_SCHEMA", "WITHHELD_FROM_MODELS", "fields_for", "for_model",
           "model_safe", "not_asked_fields", "tier_of", "tiered", "trust_for"]
