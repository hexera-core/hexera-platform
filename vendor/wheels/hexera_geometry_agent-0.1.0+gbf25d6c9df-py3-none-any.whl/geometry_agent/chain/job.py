"""THE CHAIN, WIRED: one job from the customer's brief to the builder's handoff.

The design of record is Rehaan's and this module is it, in order, as code:

    1. INTAKE     the customer states purpose, budget, boundary conditions.    `state_brief`
    2. MEASURE    deterministic geometry, against that brief.                   `measure`, `survey_document`
    3. LOOK       after the measurement, always: it decides what gets drawn.    `look`
    4. INTAKE     armed with the survey. Its abstentions are the questions.     `survey`, `second_intake`
    5. GEOMETRY   decides flow patches and where the cells go. Never what the   `plan`
                  geometry IS.
    6. INTAKE     a third time ONLY for a question that did not exist at 4.     `third_intake`
    7. BUILDER    receives both write-ups, the Surveyor's information riding    `deliver`
                  inside the geometry agent's typed block, after the cut.

`run_job` runs all seven. Each stage is also a function of its own, because on the platform the stages happen at
different times: the survey at upload, the questions when the customer is there, the plan after, the handoff when
the builder is dispatched. Every stage takes its predecessor's HANDOFF, validated by that handoff's contract, and
writes one event to the job ledger (`chain/store.py`). Nothing here re-derives a measured number, and nothing
here calls a model except the two places the design has one: the look (step 3) and the geometry agent (step 5),
both injected, so a test and the corpus simulation run the whole chain with no key.

WHAT EACH HANDOFF IS VALIDATED BY

    brief       contract.brief.BriefHandoff              purpose, budget kind, port rows carry no measurement
    survey      contract.survey.SurveyHandoff            no recorded look field, no builder key, no prediction,
                + bound_to_brief                          measured against THIS brief
    questions   ask.intake.ask_intake                    settle cuts, consequence ranking, one budget
    answers     contract.intake.IntakeHandoff, binds_to  bound to the survey; a default is not a confirmation
    plan        agent.loop.ChainGiven + check_plan       the loop refuses a context that reads the part
                                                          differently, and sends back a contradicting plan
    trade       contract.intake.LateIntakeHandoff,       only a question the second intake did not have
                binds_late
    handoff     contract.deliver.check_builder_handoff   one representation, the resolved cap, confirmed and
                                                          assumed never merged, the envelope from the emulator

A DEFAULT IS NOT A CONFIRMATION, end to end. A skipped question becomes a `Defaulted` in the ledger, an
`unanswered` id in the contract handoff, an entry under `assumed` in intake's write-up and a row under
`unsettled` in the survey block. At no point does it become an `Answered`, a `confirmed` mark or a label, and
`tests/test_chain_job.py` follows one skipped question through every one of those.
"""
from __future__ import annotations

import hashlib
import json
import re
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Protocol

from geometry_agent.agent import catalog, hexera
from geometry_agent.agent.loop import ChainGiven, LoopConfig, run_loop
from geometry_agent.agent.schema import AnalysisResult, GeometryPlan
from geometry_agent.agent.tools import ToolContext
from geometry_agent.ask import intake as aintake
from geometry_agent.ask import trade as atrade
from geometry_agent.ask.schema import OUR_CHOICE, TIERS
from geometry_agent.ask.schema import Question as AskQuestion
from geometry_agent.ask.schema import Uncertainty as AskUncertainty
from geometry_agent.chain import handover as chandover
from geometry_agent.chain.bridge import KIND_TEACHES
from geometry_agent.chain.resolution import Answered, Defaulted, Stated, Unasked, now
from geometry_agent.chain.schema import (
    Brief,
    Intake,
    JobRecord,
    Look,
    MeasuredOpening,
    Plan,
    Question,
    SeenOpening,
    Survey,
    Uncertainty,
    canonical_kind,
    plan_drift,
    question_id,
    topic_of,
)
from geometry_agent.chain.store import JobLedger
from geometry_agent.contract import deliver
from geometry_agent.contract import marks as mk
from geometry_agent.contract.asking import _opening_evidence
from geometry_agent.contract.brief import BriefHandoff, brief_from
from geometry_agent.contract.build import survey_from
from geometry_agent.contract.given import (
    CHECKER_WRITTEN,
    FLOW_DIRECTION_RE,
    PER_SUBJECT_FIELDS,
    Given,
    cell_counts,
    check_plan,
    unconfirmed_roles,
)
from geometry_agent.contract.intake import Answer, IntakeHandoff, LateIntakeHandoff, label_from
from geometry_agent.contract.marks import ContractError
from geometry_agent.contract.survey import SurveyHandoff, bound_to_brief
from geometry_agent.contract.survey import Uncertainty as ContractUncertainty
from geometry_agent.facts.schema import GeometryFacts
from geometry_agent.vision import trust

RUN_SCHEMA = "geometry_agent.chain.run.v1"

#: THE question budget, read from the one place it is set (synthesis C18).
QUESTION_BUDGET = aintake.MAX_ASKED

#: Each question kind's contract field: the `OWNERS` row an answer to it settles.
ABOUT_OF: dict[str, str] = {
    "port_role": "opening.role", "unit": "unit", "fluid_side": "representation", "budget_envelope": "cell_budget",
    "flow_direction": "flow_direction", "unlabelled_mouth": "unlabelled_mouth",
    "look_dispute": "contradiction_resolution", "dispatch_refusal": "dispatch", "identity": "identity.name",
    "opening_unseen": "opening_ids",
}

#: A person's role words onto the plan's Role vocabulary. `closed for this run` is the customer's phrase for a
#: mouth the mesher caps; the plan schema calls that `closed_end`.
ROLE_WORD: dict[str, str] = {"inlet": "inlet", "outlet": "outlet", "wall": "wall", "closed for this run": "closed_end",
                             "closed_end": "closed_end", "symmetry": "symmetry"}

#: Keys of an ask uncertainty's `measurement` that are the LOOK's words, not measurements. The ledger's `known`
#: is "measured values only", so these stay out of it; the look's own record is the `look` stage.
LOOK_KEYS = frozenset({"for_a_person_only", "seen_by_the_look", "ask", "because", "signal", "proposed", "seen",
                       "claim", "others_on_the_record"})


# ---------------------------------------------------------------------------------------------------------------
# who answers
# ---------------------------------------------------------------------------------------------------------------

@dataclass(frozen=True)
class Put:
    """A question as a person sees it. Nothing else crosses to the customer side."""
    id: str
    kind: str
    stage: str
    text: str
    options: tuple[str, ...]
    default: str
    places: tuple[str, ...] = ()


@dataclass(frozen=True)
class Reply:
    """One person's answer. `per_place` answers a question that names several mouths, one role each; `value` is
    the chosen option for any other question. `verbatim` is what they actually wrote, kept for the vocabulary
    rule. `by` is who: `customer` or `operator`, or a simulated stand-in that says it is one."""
    value: str = ""
    per_place: Mapping[str, str] = field(default_factory=dict)
    #: What they wrote, for a single-valued answer. A per-place answer's verbatim is the word given for each
    #: mouth, which is what the vocabulary rule reads.
    verbatim: str = ""
    by: str = "customer"


class Customer(Protocol):
    def reply(self, question: Put) -> Reply | None:
        """The answer, or None when the customer skipped the question and the default stands."""


class Silent:
    """A customer who answers nothing. Every default stands and not one of them is a confirmation."""

    def reply(self, question: Put) -> Reply | None:
        return None


@dataclass
class Scripted:
    """Answers keyed by question id, then by kind. For tests and for an operator replaying a conversation."""
    replies: dict[str, Reply] = field(default_factory=dict)

    def reply(self, question: Put) -> Reply | None:
        return self.replies.get(question.id) or self.replies.get(question.kind)


# ---------------------------------------------------------------------------------------------------------------
# the run
# ---------------------------------------------------------------------------------------------------------------

@dataclass
class JobRun:
    """Everything one job produced, stage by stage, and every ledger row it wrote, in order."""
    key: str
    provenance: str
    brief: BriefHandoff
    exit: str = "running"
    reason: str = ""
    facts: GeometryFacts | None = None
    document: dict[str, Any] | None = None
    look_block: dict[str, Any] | None = None
    #: STEP 4's own output: `reconcile.joint.Joint`, or None when there was no reply to reconcile against the
    #: measurement. `run.reconciliation` and `run.alerts` are read off it and are what intake is armed with.
    joint: Any = None
    representation_without_brief: str = ""
    asked: aintake.Asked | None = None
    records: list[Uncertainty] = field(default_factory=list)
    survey: SurveyHandoff | None = None
    intake: IntakeHandoff | None = None
    resolutions: list[Any] = field(default_factory=list)
    given: Given | None = None
    result: AnalysisResult | None = None
    envelope: atrade.Envelope | None = None
    trade: atrade.Trade | None = None
    trade_skipped_because: str = ""
    late: LateIntakeHandoff | None = None
    late_resolutions: list[Any] = field(default_factory=list)
    handoff: dict[str, Any] | None = None
    events: list[dict[str, Any]] = field(default_factory=list)
    notes: dict[str, Any] = field(default_factory=dict)

    @property
    def plan(self) -> GeometryPlan | None:
        return self.result.plan if self.result is not None else None


def _sha(payload: Any) -> str:
    return hashlib.sha256(json.dumps(payload, sort_keys=True, default=str).encode("utf-8")).hexdigest()


# ---------------------------------------------------------------------------------------------------------------
# 1. the brief
# ---------------------------------------------------------------------------------------------------------------

def state_brief(purpose: str, text: str = "", *, declared: list[dict[str, Any]] | None = None,
                engine: str | None = None, fidelity: str = "standard", cell_cap: int | None = None,
                cell_cap_by: str = "") -> BriefHandoff:
    """Step 1. Validated by `contract.brief`, hashed, and nothing measured yet."""
    return brief_from(purpose, text, declared=declared, engine=engine, fidelity=fidelity, cell_cap=cell_cap,
                      cell_cap_by=cell_cap_by)


def brief_record(brief: BriefHandoff) -> Brief:
    return Brief(sha256=brief.sha256, purpose=brief.purpose, engine=brief.engine or "", fidelity=brief.fidelity,
                 text=brief.text, cell_cap=brief.budget,
                 cell_cap_quote=brief.cell_cap.source if brief.cell_cap is not None else "",
                 declared=tuple(dict(r) for r in brief.declared))


# ---------------------------------------------------------------------------------------------------------------
# 2. measure, against the brief
# ---------------------------------------------------------------------------------------------------------------

def measure(brief: BriefHandoff, path: str | Path | None = None, *, facts: GeometryFacts | None = None,
            cache_dir: str | Path | None = None, measured_purpose: str | None = None,
            timeout_s: float | None = None) -> tuple[GeometryFacts | None, str]:
    """Step 2's instrument. Returns `(facts, refusal)`; exactly one is set.

    ADMISSION FIRST: a file over the size ceiling or a measurement past its deadline is refused here, by
    `agent.run.measured_facts`, before any stage downstream sees it. Broken CAD never reaches the Surveyor.

    The facts are measured under the BRIEF's purpose. Handed facts measured under another purpose (the upload
    hook measures before anybody has said what the job is for), this refuses them by name, because the cache
    that produced them is keyed by purpose and a stage downstream cannot tell.
    """
    if facts is not None:
        if measured_purpose is not None and measured_purpose != brief.purpose:
            raise ContractError("measure", f"these facts were measured for {measured_purpose!r} and the brief says "
                                           f"{brief.purpose!r}: measure again for the purpose the customer stated")
        return facts, ""
    if path is None:
        raise ContractError("measure", "neither a file nor its facts")
    from geometry_agent.agent import run as arun
    p = Path(path)
    ceiling = arun.file_ceiling_bytes()
    try:
        size = p.stat().st_size
    except OSError as exc:
        return None, f"the file could not be read: {exc}"
    if ceiling and size > ceiling:
        return None, arun.REFUSED_TOO_LARGE.format(mb=size / 1024 / 1024, cap=ceiling / 1024 / 1024,
                                                   var=arun.MAX_FILE_MB_ENV)
    got, refusal = arun.measured_facts(p, brief.purpose, cache_dir,  # type: ignore[arg-type]
                                       arun.measure_timeout_s() if timeout_s is None else timeout_s)
    if refusal is not None:
        return None, refusal.reason
    return got, ""


def survey_document(facts: GeometryFacts, brief: BriefHandoff, look: dict[str, Any] | None = None, *,
                    cell_cap: int | None = None, unit: str | None = None,
                    flow_direction: str | None = None, inlet_ids: list[str] | None = None,
                    fluid_side: str | None = None) -> dict[str, Any]:
    """The measurement document, AGAINST THE BRIEF, stamped with the brief's sha.

    This is where "intake before measure" stops being an accident of when the upload hook fired. The
    representation is the catalog's reading of the openings with the brief's text and the customer's port rows
    (`catalog.representation(facts, purpose, brief, declared=declared)`), so the survey is measured against the
    brief, and the stamp says which one. `cell_cap` is the resolved budget when a later stage has one, and
    `fluid_side` the customer's answer to which side of the surface is the fluid when intake asked it.
    """
    return hexera.report_measured(facts, unit, brief.text or None, purpose=brief.purpose, engine=brief.engine,
                                  declared=list(brief.declared) or None,
                                  cell_cap=cell_cap if cell_cap is not None else brief.budget, look=look,
                                  stamp={"brief_sha256": brief.sha256}, flow_direction=flow_direction,
                                  inlet_ids=inlet_ids, fluid_side=fluid_side)


def fluid_side_answered(resolutions: list[Any] | None) -> str | None:
    """The side of the surface a PERSON said is the fluid (`catalog.FLUID_SIDES`), or None. A default that stood
    is not in it: the representation then stays today's, marked assumed, and the flow path stays refused."""
    for r in resolutions or []:
        if isinstance(r, Answered) and str(r.field).startswith("fluid_side:") and r.value in catalog.FLUID_SIDES:
            return str(r.value)
    return None


def _side_key(u: AskUncertainty | None, said: str) -> str:
    """A fluid-side option read back to its `catalog.FLUID_SIDES` key."""
    from geometry_agent.ask import say as asay
    bores = int(((u.measurement or {}) if u is not None else {}).get("bores") or 1)
    if said in catalog.FLUID_SIDES:
        return said
    return asay.fluid_side_of(said, bores) or said


def _contract_value(q: AskQuestion, u: AskUncertainty | None, value: str) -> str:
    """What an answer SETS in the contract, where that is not the words chosen: a fluid side sets the
    representation its reading gives (`contract.marks.OWNERS['representation']`)."""
    if q.kind != "fluid_side" or u is None:
        return value
    readings = (u.measurement or {}).get("readings") or {}
    return str(readings.get(_side_key(u, value), value))


#: The brief's own sentence about which way the flow goes, and only that sentence. Every external brief in the
#: corpus writes it this way ("Flow is along +X"), and matching the phrase rather than any `[+-][xyz]` in the
#: text is the whole point: a brief is full of axis letters - extents, normals, patch positions - and only this
#: line is the customer saying which way the fluid runs.
BRIEF_FLOW_RE = re.compile(r"flow\s+(?:is\s+)?(?:runs\s+)?along\s*([+-])\s*([xyz])\b", re.I)


def flow_axis_of(given: Given | None, resolutions: list[Any] | None = None,
                 brief: BriefHandoff | None = None) -> str | None:
    """The customer's flow direction as `+x` and the rest, or None.

    Three sources, in order of authority: an answer or a confirmed mark; a `Stated` resolution, which is the
    brief's sentence once a flow QUESTION was raised and the brief settled it; and the brief's own text.

    WHY THE THIRD ONE EXISTS. The second only fires when a flow question was raised at all, and on a part whose
    measurement is confident about the axis no such question exists - on `naca0012` the brief says "Flow is
    along +X", no uncertainty is raised, and this function returned None. So the customer stated the direction
    and nothing read it, which is the same defect one step upstream: the plan then posed the direction off the
    blunt end and could contradict the brief with nobody noticing. The third source closes that.

    A DEFAULT THAT STOOD IS STILL NOT A DIRECTION ANYBODY GAVE, and stays None: this reads the customer's own
    words and the measurement's reading is not among the three.
    """
    values: list[Any] = []
    if given is not None:
        values.append(given.value("flow_direction"))
    for r in resolutions or []:
        field = str(getattr(r, "field", "") or "")
        if field.startswith("flow_direction"):
            # read each type by its own field: a Stated has no `value`, and reaching for one raises by design
            if isinstance(r, Answered):
                values.append(r.value)
            elif isinstance(r, Stated):
                values.append(r.brief_value)
    for value in values:
        hit = FLOW_DIRECTION_RE.search(str(value or ""))
        if hit:
            return f"{hit.group(1)}{hit.group(2).lower()}"
    if brief is not None:
        return flow_axis_in_brief(str(getattr(brief, "text", "") or ""))
    return None


def flow_axis_in_brief(text: str) -> str | None:
    """The direction the brief's own sentence names, as `+x`, or None. `BRIEF_FLOW_RE` and nothing else.

    Its own function because two callers read it: `flow_axis_of` above, and step 4, which runs before `given`
    exists and can therefore hear the customer only through the brief.
    """
    hit = BRIEF_FLOW_RE.search(str(text or ""))
    return f"{hit.group(1)}{hit.group(2).lower()}" if hit else None


def representation_without_brief(facts: GeometryFacts, purpose: str) -> str:
    """What the upload hook's order would have measured: the file alone, no brief, no port rows."""
    return str(catalog.representation(facts, purpose, None, declared=None))  # type: ignore[arg-type]


def survey_for(stored: dict[str, Any], brief: BriefHandoff, *, look: dict[str, Any] | None = None) -> dict[str, Any]:
    """Re-survey a measurement stored at upload against the brief, without measuring the file again.

    The upload hook measures before intake. Its FACTS stand (they depend on the file and the purpose); its
    representation, triage and forecast do not, because they read the brief. So the stored document's facts are
    re-read into a fresh document against this brief. Refused when the stored document has no facts or was
    measured for another purpose.
    """
    raw = stored.get("facts")
    if not isinstance(raw, dict):
        raise ContractError("survey", "the stored measurement carries no facts to re-survey from")
    if str(stored.get("purpose") or brief.purpose) != brief.purpose:
        raise ContractError("survey", f"the stored measurement was taken for {stored.get('purpose')!r} and the brief "
                                      f"says {brief.purpose!r}: measure again")
    facts = GeometryFacts.model_validate(raw)
    return survey_document(facts, brief, look if look is not None else stored.get("look"))


# ---------------------------------------------------------------------------------------------------------------
# 3. the look, after the measurement
# ---------------------------------------------------------------------------------------------------------------

LookFn = Callable[[GeometryFacts, str], dict[str, Any]]


def look(facts: GeometryFacts, brief: BriefHandoff, representation: str, *, path: str | Path | None = None,
         block: dict[str, Any] | None = None, look_fn: LookFn | None = None, client: Any = None) -> dict[str, Any]:
    """Step 3. After the measurement, always, because the measurement decides what gets drawn: the labels are the
    measured opening ids and the stops view needs the representation, which is the SURVEY's, passed in.

    `block` is a look already taken (a stored or cached one). `look_fn(facts, representation)` is any other
    source. Otherwise `vision.look.look_at_geometry`, which never raises and returns `not_attempted` when no
    vision model is configured, because then nothing looked. The look never produces a number: every digit is
    scrubbed before it is stored.

    WITH NO FILE AND NO STORED LOOK, NOBODY TOOK ONE EITHER, which is why this says so
    (`contract.survey.LOOK_NOT_ATTEMPTED`) rather than `failed`. A failed look is one that was taken and brought
    no reading back, and a builder's rule is that neither of them is a clear passage but they are not the same
    fact: this step had nothing to render.
    """
    if block is not None:
        return block
    if look_fn is not None:
        return look_fn(facts, representation)
    if path is None:
        return hexera.look_block(None, status=hexera.LOOK_NOT_ATTEMPTED,
                                 reason="no file to render and no stored look")
    from geometry_agent.vision.look import look_at_geometry
    return look_at_geometry(path, facts, client=client, purpose=brief.purpose, brief=brief.text or None,
                            declared=list(brief.declared) or None, representation=representation)


# ---------------------------------------------------------------------------------------------------------------
# 4a. RECONCILE, after the look and before the questions
# ---------------------------------------------------------------------------------------------------------------

def reconcile(facts: GeometryFacts, representation: str, look_block: dict[str, Any] | None, *,
              path: str | Path | None = None, case: str = "", mesh: Any = None,
              stated_axis: str | None = None) -> Any:
    """STEP 4. The measurement checking the look and the look checking the measurement, on this job's own file.

    NEVER RAISES, for the same reason `look` never raises. Step 4 is pure addition: the chain delivered without it
    for four rounds, so a fault in it must cost the job its reconciliation and nothing else. A fault is logged
    through `observe.warning` under `reconcile.failed` and the job carries on with no reconciliation.

    Returns `reconcile.joint.Joint`, or None when there is no pair: a look that failed has one source and
    nothing to reconcile, and the caller then goes on exactly as it did before this function existed.

    WHY IT SITS HERE AND NOT LATER. A contradiction between the two sources needs no answer key, which makes it
    the only quality signal in this product that works on a customer file nobody has ever seen. It is worth
    having only if somebody is asked about it, so it has to be computed BEFORE the second intake:
    `ask.uncertainty.dispute_uncertainty` turns the highest-ranked dispute into a question with a cautious
    default, and `ask.uncertainty.MIXED_SIGNALS` turns a monitor firing into one where the hand verdicts do not
    already say which side is right. Both of those have been built and reachable for four rounds and neither had
    an input. This is the input.

    WHAT IT IS NOT. It is not a re-decision of what the geometry is, it names no builder setting, and it
    forecasts nothing about the mesh. Its output reaches the builder as a fact about the JOB (a count, a tier, a
    signal id: `joint.RECORD_DEFAULT` is `counts`, which carries no quoted sentence), never as a new claim about
    the part.

    NOTHING HERE READS THE BRIEF, and `stated_axis` is not an exception to that. What the caller reads out of
    the brief is ONE SIGNED AXIS LETTER (`flow_axis_in_brief`, the sentence "Flow is along +X" and nothing else),
    and the letter is a direction a person gave, which is the one thing about this part that no measurement owns.
    It reaches `profile.trust` and cannot become a claim, a station or a place. No text, no declared ports, no
    budget and no purpose go past this line. `tests/test_chain_reconcile.py` pins that by signature and by call.

    `mesh` IS ALMOST ALWAYS NONE AND THAT COSTS A TESSELLATION. Nothing on this path holds the triangles: the
    facts were measured in a child process and the look came back as pictures. Step 4's own work is 0.088 s
    median over 12 real corpus parts; loading the triangles a third time makes it 0.21 s median, with 11 of the
    12 under 0.67 s and one helical mixer at 17.9 s. The argument is here so that the caller who fixes that (a
    NEEDS FROM OTHERS on `agent/run.py`) needs no change in this file. See
    `joint.STEP4_SECONDS_WITH_THE_MESH_IN_HAND`.
    """
    from geometry_agent.reconcile import joint as rjoint
    try:
        return rjoint.for_job(facts, representation, look_block, case=case, path=path, mesh=mesh,
                              stated_axis=stated_axis)
    except Exception as exc:  # noqa: BLE001 - see the docstring: step 4 may cost itself and never the job
        from geometry_agent import observe
        observe.warning("reconcile.failed", why=f"{type(exc).__name__}: {str(exc)[:200]}", case=case)
        return None


def look_record(block: dict[str, Any] | None) -> Look:
    """The look as the ledger keeps it: WHICH STATE IT WAS IN, the words, and the trust tier of every field AT
    THE TIME.

    The status travels because without it two of the three states are one row here: a look that failed and a
    look nobody took both leave a record with no words, no tiers and no model, and the ledger is what a
    recalibration and a postmortem read.
    """
    block = block or {}
    imp = block.get("impression") if str(block.get("status") or "") == "ok" else None
    imp = imp if isinstance(imp, dict) else {}
    seen = tuple(SeenOpening(id=str(o.get("id") or "unlabelled"), role_said=str(o.get("likely_role") or ""),
                             looks_like=str(o.get("looks_like") or ""), mouth=str(o.get("mouth") or ""),
                             why=str(o.get("why") or ""))
                 for o in (imp.get("openings_seen") or []) if isinstance(o, dict))
    internal = tuple(str(x) for x in (imp.get("internal_features") or []))
    return Look(status=str(block.get("status") or ""),
                model=str(block.get("model") or ""), provider=str(block.get("provider") or ""),
                confidence=str(imp.get("confidence") or ""), looks_like=str(imp.get("looks_like") or ""),
                openings_seen=seen, attachments=tuple(str(x) for x in (imp.get("attachments") or [])),
                internal_features=internal, inside_is_plain=(not internal) if imp else None,
                tiers={name: str(e.get("tier")) for name, e in trust.fields_for(imp).items()} if imp else {},
                identity_confidence_max=trust.IDENTITY_CONFIDENCE_MAX if imp else None)


# ---------------------------------------------------------------------------------------------------------------
# 4. the survey's uncertainties, as the questions intake puts
# ---------------------------------------------------------------------------------------------------------------

def _rows(document: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {str(r.get("id")): r for r in (document.get("openings") or []) if isinstance(r, dict)}


def _subject(u: AskUncertainty) -> str:
    return ",".join(u.places) if u.places else "part"


def _question_of(asked: aintake.Asked) -> dict[str, AskQuestion]:
    out: dict[str, AskQuestion] = {}
    for q in [*asked.questions, *asked.held]:
        for uid in q.covers:
            out.setdefault(uid, q)
    return out


def merged_records(asked: aintake.Asked, raised_at: str = "second") -> list[Uncertainty]:
    """The ONE uncertainty record (appendix B), one per thing the Surveyor could not settle, per place.

    Built from the ask engine's own objects and nothing else: `kind` through `canonical_kind`, `tier` and
    `computed` from `ask.consequence` (never set by hand), `ask`/`options`/`default` from `ask.say`, `known`
    from the measurement with the look's words kept out. One record per mouth, not per question, because the
    learning joins on `role:o3`, while the question that asked about it may name four mouths.
    """
    q_of = _question_of(asked)
    out: list[Uncertainty] = []
    for u in asked.uncertainties:
        q = q_of.get(u.id)
        kind = canonical_kind(u.kind)
        places = tuple(u.places)
        for place in (places or ("",)):
            subject = place or _subject(u)
            known = {k: v for k, v in (u.measurement or {}).items() if k not in LOOK_KEYS}
            if place:
                known["place"] = place
            tier = (q.tier if q is not None else "none") or "none"
            consequence = (q.consequence or {}) if q is not None else {}
            # a grouped role question carries one consequence PER MOUTH; the record is per mouth, so it reads its own
            consequence = (consequence.get("per_place") or {}).get(place) or consequence
            out.append(Uncertainty(
                id=f"{kind}:{subject}", kind=kind, subject=subject, known=known,
                unsettled_because=u.abstention, ask=q.text if q is not None else "",
                default=q.default if q is not None else u.fallback,
                default_from=(f"{q.default_is}: {q.because}" if q is not None else u.source),
                teaches=KIND_TEACHES.get(kind, ""), effect=(q.effect if q is not None else "advisory"),
                rank=float(TIERS.index(tier)) if tier in TIERS else float(len(TIERS)),
                places=places, why=f"{u.unknown}. Read from {u.source}.",
                options=tuple(q.options) if q is not None else tuple(u.branches),
                options_from=("the measured mouths and the customer's own role words" if kind == "role"
                              else "the measurement and the stated budget" if kind == "budget"
                              else "the question's own branches"),
                tier=tier, computed=consequence.get("computed") if consequence else None, raised_at=raised_at,
                asked=bool(q is not None and q.asked), settled_by=(q.settled_by if q is not None else "no_home")))
    return out


def _evidence(q: AskQuestion, document: dict[str, Any]) -> list[mk.Mark]:
    rows = _rows(document)
    out: list[mk.Mark] = []
    for place in q.places:
        row = rows.get(place)
        if row is not None:
            out.extend(m for m in _opening_evidence(row) if m.value is not None)
    fc = document.get("forecast") or {}
    if q.kind == "budget_envelope" and isinstance(fc.get("cells_high"), (int, float)):
        out.append(mk.measured("forecast.cells_high", int(fc["cells_high"]),
                               "forecast.cells_high (tools.estimate_builder_cells)"))
    return out


def contract_uncertainties(asked: aintake.Asked, document: dict[str, Any]) -> list[ContractUncertainty]:
    """The survey handoff's uncertainty list, one per QUESTION the Surveyor's abstentions became.

    A question somebody else already answered (the customer's port list, the brief, the file) is not an
    uncertainty any more and is not here; the ledger still has it, as `Stated`. A question WE decided not to put
    (below the budget, no consequence) is still an uncertainty and is here, because the builder must be told it is
    unsettled. The two kinds that are never asked are here as `advisory`.
    """
    out: list[ContractUncertainty] = []
    covered: set[str] = set()
    by_id = {u.id: u for u in asked.uncertainties}
    for q in [*asked.questions, *asked.held]:
        covered.update(q.covers)
        if not q.asked and q.settled_by not in OUR_CHOICE:
            continue
        first = by_id.get(q.covers[0]) if q.covers else None
        effect = "advisory" if q.settled_by == "no_consequence" else (q.effect or "changes_mesh")
        out.append(ContractUncertainty(
            id=q.id, about=ABOUT_OF.get(q.kind, q.kind), subjects=list(q.places),
            why=((first.abstention + ". ") if first is not None and first.abstention else "") + q.because,
            options=list(q.options), options_from=("the measured mouths" if q.kind == "port_role"
                                                   else "the question's own branches"),
            default=q.default, effect=effect, evidence=_evidence(q, document)))
    for u in asked.uncertainties:
        if u.id in covered:
            continue
        out.append(ContractUncertainty(
            id=u.id, about=ABOUT_OF.get(u.kind, u.kind), subjects=list(u.places), why=u.abstention or u.unknown,
            options=list(u.branches), options_from="the question's own branches", default=u.fallback or None,
            effect="advisory"))
    return out


def survey(document: dict[str, Any], brief: BriefHandoff, *, alerts: Any = None, reconciliation: Any = None,
           asked_before: dict[str, int] | None = None) -> tuple[SurveyHandoff, aintake.Asked, list[Uncertainty]]:
    """Step 4's input: the Surveyor's handoff, the questions its abstentions became, and the ledger's records.

    ONE finder: `ask.intake.ask_intake`, with the customer's port rows and the brief, so the first cut (somebody
    already answered it) runs before anything is asked. The survey handoff is built from ITS list and refuses to
    exist unless it was measured against this brief.
    """
    asked = aintake.ask_intake(document, declared=list(brief.declared) or None, brief=brief.text or None,
                               alerts=alerts, reconciliation=reconciliation, max_asked=QUESTION_BUDGET,
                               asked_before=asked_before)
    # the budget's sentence travels with it: read out of the brief's own words when that is where it came from,
    # and "supplied by the caller" only when intake handed a number over some other way
    from_text = brief.cell_cap is None or brief.cell_cap.source.startswith("brief:")
    handoff = survey_from(document, brief=brief.text or None, budget=None if from_text else brief.budget,
                          declared=list(brief.declared) or None,
                          uncertainties=contract_uncertainties(asked, document), brief_sha256=brief.sha256)
    bound_to_brief(handoff, brief.sha256)
    return handoff, asked, merged_records(asked)


def survey_record(document: dict[str, Any], brief: BriefHandoff, without_brief: str) -> Survey:
    unit = document.get("unit") or {}
    fc = document.get("forecast") or {}
    bbox = document.get("bbox") or {}
    bodies = document.get("bodies") or {}
    openings = tuple(MeasuredOpening(
        id=str(r.get("id")), kind=str(r.get("kind") or ""), shape=str(r.get("shape") or ""),
        classification=str(r.get("classification") or ""), area=r.get("area_file"),
        hydraulic_diameter=r.get("hydraulic_diameter_file"), bore_diameter=r.get("bore_diameter_file"),
        tilt_deg=r.get("tilt_deg"), on_bbox_face=r.get("on_bbox_face"),
        centroid=tuple(r.get("centroid_file") or ()) or None, region_id=str(r.get("region_id") or ""))
        for r in (document.get("openings") or []) if isinstance(r, dict))
    return Survey(facts_sha256=str(document.get("source_sha256") or ""),
                  representation=str(document.get("representation") or ""), purpose=str(document.get("purpose")),
                  engine=str(document.get("engine") or ""), unit=str(unit.get("assumed") or ""),
                  unit_basis=str(unit.get("basis") or ""),
                  planner_block_status=str((document.get("planner_block") or {}).get("status") or ""),
                  openings=openings, bbox_extent=tuple(bbox.get("extent_file") or ()) or None,
                  bodies=bodies.get("count"), watertight=bodies.get("watertight"),
                  forecast_cells=fc.get("cells_high"), forecast_basis=tuple(str(b) for b in fc.get("basis") or ()),
                  stated_cell_cap=brief.budget, measurement_schema=str(document.get("schema") or ""),
                  brief_sha256=brief.sha256, representation_without_brief=without_brief)


# ---------------------------------------------------------------------------------------------------------------
# 4. the second intake: put the questions, bring the answers back typed
# ---------------------------------------------------------------------------------------------------------------

def _put(q: AskQuestion, stage: str) -> Put:
    return Put(id=q.id, kind=q.kind, stage=stage, text=q.text, options=tuple(q.options), default=q.default,
               places=tuple(q.places))


def _field(kind: str, subject: str) -> str:
    return f"{canonical_kind(kind)}:{subject}"


def role_defaults(q: AskQuestion, asked: aintake.Asked) -> dict[str, str]:
    """What the role question's default does, per mouth: the builder's own fallback, stated out loud."""
    by_id = {u.id: u for u in asked.uncertainties}
    out: dict[str, str] = {}
    for uid in q.covers:
        u = by_id.get(uid)
        if u is not None and u.places:
            out[u.places[0]] = ROLE_WORD.get(u.fallback, u.fallback)
    return out


def second_intake(survey_handoff: SurveyHandoff, asked: aintake.Asked, customer: Customer, *,
                  document: dict[str, Any] | None = None, declared: list[dict[str, Any]] | None = None,
                  at: str = "") -> tuple[IntakeHandoff, list[Any], dict[str, str], dict[str, str]]:
    """Step 4: put the questions, and bring every answer back as the type it is.

    Returns the contract handoff, the ledger's resolutions, the stated roles (the customer's port list bound to
    measured mouths) and the assumed roles (defaults that stood). Per question:

      answered       `Answered` per place in the ledger; a `confirmed` Answer in the handoff
      skipped        `Defaulted` per place; the id is `unanswered` in the handoff, except on a field whose
                     ownership row admits an assumption (the unit), where it rides as `default_taken`
      held, by us    `Unasked`, with why (below the budget, no consequence, or no home at all)
      settled by the customer's own words or the file
                     `Stated`, with the quote. Nobody was asked, so nobody confirmed
    """
    at = at or now()
    answers: list[Answer] = []
    unanswered: list[str] = []
    resolutions: list[Any] = []
    stated: dict[str, str] = {}
    assumed: dict[str, str] = {}
    by_id = {u.id: u for u in asked.uncertainties}
    for q in asked.questions:
        reply = customer.reply(_put(q, "second"))
        about = ABOUT_OF.get(q.kind, q.kind)
        if q.kind == "port_role":
            defaults = role_defaults(q, asked)
            if reply is None:
                unanswered.append(q.id)
                for oid, role in defaults.items():
                    resolutions.append(Defaulted(field=_field(q.kind, oid), assumed=role, question_id=q.id,
                                                 default_from=q.default, at=at))
                    assumed[oid] = role
                continue
            given_any = False
            for oid in q.places:
                said = reply.per_place.get(oid)
                if said is None:
                    role = defaults.get(oid, "")
                    if role:
                        resolutions.append(Defaulted(field=_field(q.kind, oid), assumed=role, question_id=q.id,
                                                     default_from=q.default, at=at))
                        assumed[oid] = role
                    continue
                if said not in q.options and said not in ROLE_WORD:
                    raise ContractError("intake", f"{said!r} is not one of the question's options {q.options}",
                                        field=f"{q.id}:{oid}")
                role = ROLE_WORD.get(said, said)
                # THE WORD THEY GAVE FOR THIS MOUTH is the verbatim, not the reply's note about itself: the
                # vocabulary rule learns synonyms from `verbatim`, and a note carried there on 255 simulated parts
                # came back proposed as a new role word
                resolutions.append(Answered(field=_field(q.kind, oid), value=role, question_id=q.id,
                                            answered_by=reply.by, verbatim=said, at=at))
                answers.append(Answer(question_id=q.id, about=about, subject=oid, value=role, answered_by=reply.by,
                                      at=at))
                given_any = True
            if not given_any:
                unanswered.append(q.id)
            continue
        first = by_id.get(q.covers[0]) if q.covers else None
        subject = _subject(first) if first is not None else "part"
        if reply is None or not reply.value:
            # the default's VALUE (the uncertainty's own fallback: `m`, `along +x`), not the question's sentence
            # about it ("read the file as m"), which is what a field is set to and what the ledger keeps
            value = (first.fallback if first is not None and first.fallback else q.default)
            resolutions.append(Defaulted(field=_field(q.kind, subject), assumed=value, question_id=q.id,
                                         default_from=f"{q.default_is}: {q.default}", at=at))
            if mk.ASSUMED in mk.OWNERS.get(about, ()):
                answers.append(Answer(question_id=q.id, about=about, value=_contract_value(q, first, value),
                                      answered_by="default_taken", at=at))
            else:
                unanswered.append(q.id)
            continue
        if reply.value not in q.options and not (q.kind == "fluid_side" and reply.value in catalog.FLUID_SIDES):
            raise ContractError("intake", f"{reply.value!r} is not one of the question's options {q.options}",
                                field=q.id)
        # a fluid side is kept in the ledger as the side the customer chose (`through`, `is_fluid`), which is the
        # label, and set in the contract as the representation that side gives
        chosen = _side_key(first, reply.value) if q.kind == "fluid_side" else reply.value
        resolutions.append(Answered(field=_field(q.kind, subject), value=chosen, question_id=q.id,
                                    answered_by=reply.by, verbatim=reply.verbatim or reply.value, at=at))
        answers.append(Answer(question_id=q.id, about=about, value=_contract_value(q, first, reply.value),
                              answered_by=reply.by, at=at))
    for q in asked.held:
        for uid in q.covers:
            u = by_id.get(uid)
            if u is None:
                continue
            subject = _subject(u)
            if q.settled_by in OUR_CHOICE:
                resolutions.append(Unasked(field=_field(q.kind, subject), assumed=q.default or u.fallback,
                                           why_not_asked=q.settled_by, default_from=q.default_is, at=at))
                if q.kind == "port_role" and u.places:
                    assumed[u.places[0]] = ROLE_WORD.get(u.fallback, u.fallback)
                continue
            value = _stated_value(q, u)
            resolutions.append(Stated(field=_field(q.kind, subject), brief_value=value,
                                      quote=q.settled_quote or q.settled_by, at=at))
            if q.kind == "port_role" and u.places and value in ROLE_WORD:
                stated[u.places[0]] = ROLE_WORD[value]
    covered = {uid for q in [*asked.questions, *asked.held] for uid in q.covers}
    for u in asked.uncertainties:
        if u.id not in covered:
            resolutions.append(Unasked(field=_field(u.kind, _subject(u)), assumed=u.fallback or "nothing",
                                       why_not_asked="no_home", default_from=u.source, at=at))
    for oid, role in stated_off_builder_ports(document, declared, stated).items():
        # the customer's port list names a mouth the builder's port rule does not cut: their statement stands
        # and is labelled theirs, and `stated_off_builder_ports` is what the report counts
        stated[oid] = role
        resolutions.append(Stated(field=f"role:{oid}", brief_value=role, at=at,
                                  quote=f"your port list names this mouth as {role}; the builder's port rule does "
                                        "not cut it as a port"))
    handoff = IntakeHandoff(survey_source_sha256=survey_handoff.source_sha256,
                            survey_facts_sha256=survey_handoff.facts_sha256,
                            asked=[q.id for q in asked.questions], answers=answers, unanswered=unanswered)
    return handoff, resolutions, stated, assumed


def labels_from(given: Given, asked: aintake.Asked | None = None) -> list[dict[str, Any]]:
    """THE FREE GROUND TRUTH, as rows: one per answer a PERSON gave, from `contract.intake.label_from`.

    WHY THIS FUNCTION EXISTS. `docs/contract.md` has said since the package was written that
    `contract/ratchet.py` is what reads these rows. Nothing built them: `label_from` had no caller and
    `contract/ratchet` was imported by its own test and nothing else, so the one mechanism in this project that
    scores the LOOK against a customer on a real part, with no answer key and no annotator, had no input at all.
    The chain already holds both halves at the end of step 4, and this is the two lines that join them.

    A DEFAULT IS NOT A CONFIRMATION, so a row whose `answered_by` is `default_taken` is not a label and is not
    here. It is the rule the whole ratchet rests on: a ledger of our own guesses fed back would demote a look
    field for disagreeing with us. `ask.record.is_label` states the same rule over the ask engine's own rows,
    where the default is spelled `defaulted` rather than `default_taken`; the word here is the contract's,
    because the object here is a `contract.intake.Answer`.

    Nothing is applied. `ratchet.proposed` proposes and `ratchet.apply` needs a path, and neither is called here:
    the live recalibration is `chain/recalibrate.py`, which reads job records and tests its counts against a
    measured null. This is the row, and the row is what was missing.
    """
    out: list[dict[str, Any]] = []
    by_id = {q.id: q for q in [*asked.questions, *asked.held]} if asked is not None else {}
    for handoff in (given.intake, given.late):
        if handoff is None:
            continue
        for a in handoff.answers:
            if a.answered_by == "default_taken":
                continue
            row = label_from(a, given.survey)
            q = by_id.get(a.question_id)
            if q is not None:
                #: `label_from`'s `question` is the CONTRACT question and the ask engine's is a different object,
                #: so the two text columns are filled from the one the chain actually put
                row["asked"], row["why_asked"] = q.text, q.because
            out.append(row)
    return out


def brief_stated_facts(asked: aintake.Asked) -> dict[str, Any]:
    """The PART-LEVEL fields the customer's brief settled, `{contract field: value}`, for `Given.of`.

    A question the brief answered is held with `settled_by == 'brief'`, and until this function existed that was
    the end of it: `second_intake` wrote a `Stated` resolution, which is a ledger row, and no mark, so the
    answer reached nothing that reads a fact. On the unit that was the whole point of asking. The role questions
    are not here because `second_intake` already binds those per mouth into `stated_roles`.

    A field whose `OWNERS` row does not admit `stated` is left out here rather than refused, because those are
    the kinds whose answer is not a claim about the part at all (`dispatch`, `unlabelled_mouth`); `Given.of`
    refuses one that gets through, so a new kind cannot arrive silently.
    """
    out: dict[str, Any] = {}
    for q in asked.held:
        if q.settled_by != "brief" or q.kind == "port_role":
            continue
        about = ABOUT_OF.get(q.kind)
        value = q.settled_value or None
        if not about or not value or about in PER_SUBJECT_FIELDS:
            continue
        if mk.STATED in mk.OWNERS.get(about, ()):
            out[about] = value
    return out


def stated_off_builder_ports(document: dict[str, Any] | None, declared: list[dict[str, Any]] | None,
                             already: dict[str, str]) -> dict[str, str]:
    """Port rows that sit at a measured mouth OUTSIDE the builder-port set, `{opening_id: role}`.

    The second intake asks and settles only the mouths the builder will cut (`ask.uncertainty.builder_ports`).
    On 16 of the 261 corpus parts with port rows the customer's declared inlet sits exactly on a face the catalog
    classifies `planar_face` and not `port_candidate` (`diffuser_plenum_004_fluid`'s o1, 0 mm from the row), so
    no question and no settle ever saw it, and the plan's inlet there reached the builder labelled as the agent's
    own decision. It is the customer's statement, and this is what labels it so. Whether the builder's port rule
    should cut that face is the catalog's question, not this module's.
    """
    if not document or not declared:
        return {}
    from geometry_agent.ask import settle
    rows = [r for r in (document.get("openings") or []) if isinstance(r, dict) and r.get("planar")]
    # one binding over every planar mouth, one to one, and only the mouths the second intake did not settle
    bound = settle.bind_declared(rows, declared, (document.get("bbox") or {}).get("diagonal_mm"))
    out: dict[str, str] = {}
    for oid, row in bound.items():
        role = ROLE_WORD.get(str(row.get("role") or row.get("type") or ""))
        if role and oid not in already:
            out[oid] = role
    return out


def _stated_value(q: AskQuestion, u: AskUncertainty) -> str:
    """What the customer's own words selected, for a question somebody other than a person asked settled.

    `Question.settled_value` is the option the cut itself picked, so this reads the answer rather than working it
    out a second time from the saved quote. It used to re-run `settle.brief_settles` over the quote, which meant
    two derivations of one answer, a `"wall"` fallback on the role branch that could differ from what the blanket
    actually selected, and a string split for the declaration branch. The quote is the EVIDENCE and the value is
    the ANSWER, and those are not the same field.
    """
    if q.settled_value:
        return str(q.settled_value)
    quote = str(q.settled_quote or "")
    if q.settled_by == "declaration" and "names this mouth as" in quote:
        return quote.rsplit(" ", 1)[-1]
    if q.settled_by == "brief":
        from geometry_agent.ask import settle
        options = list(u.branches) if q.kind == "port_role" else list(q.options)
        got = settle.brief_settles(q.kind, options, quote)
        return got[0] if got else quote
    return q.default


def intake_record(asked: aintake.Asked, resolutions: list[Any], key: str, *, only: str = "second",
                  write_up: str = "", at: str = "") -> Intake:
    qs = asked.questions if only == "second" else []
    return Intake(asked=tuple(Question(id=question_id(key, q.id), uncertainty_id=q.id, topic=canonical_kind(q.kind),
                                       ask=q.text, options=tuple(q.options), default=q.default,
                                       default_from=q.default_is, effect=q.effect, asked_at=at or now())
                              for q in qs),
                  resolutions=tuple(resolutions), write_up=write_up)


# ---------------------------------------------------------------------------------------------------------------
# 5. the geometry agent: decides what to DO, from the facts and the confirmations
# ---------------------------------------------------------------------------------------------------------------

def agent_declared(brief: BriefHandoff, given: Given, document: dict[str, Any]) -> list[dict[str, Any]]:
    """The port rows the geometry agent works from: the customer's own, plus one per CONFIRMED role.

    A confirmation reaches the agent through the channel it already reads (the declared rows the checker, the
    catalog and the reference policy bind), placed at the measured mouth IN THE FILE'S OWN UNITS, because that
    channel compares `near` with `opening.centroid` (`tools.py:406`, `catalog.py:1816`). The first version wrote
    millimetres, which on a unitless STL are null, so a confirmed role never reached the agent and the chain's
    check refused every plan the agent could make without it. A default is NOT added as a row: it is not the
    customer's, and the agent decides the flow patches nobody spoke about.
    """
    rows = [dict(r) for r in brief.declared]
    table = _rows(document)
    for oid, row in table.items():
        mark = given.role_of(oid)
        if mark is None or str(mark.value) not in ("inlet", "outlet"):
            continue
        near = row.get("centroid_file")
        if not near:
            continue
        out = {"name": f"{mark.value}_{oid}", "role": str(mark.value), "near": list(near)}
        bore = row.get("bore_diameter_file") or row.get("hydraulic_diameter_file")
        if bore:
            out["bore_diameter"] = bore
        rows.append(out)
    return rows


def given_text(given: Given, look_block: dict[str, Any] | None, flow_direction: str | None = None) -> str:
    """The block the geometry agent reads after its measurements. Words and ids; the only number is the cap the
    request already carries, so nothing here is a measurement the checker would have to trace.

    `flow_direction` is `flow_axis_of`'s answer: the direction a PERSON gave, `+x` and the rest, or None. It is
    passed in rather than read off `given` because the brief's own sentence arrives as a `Stated` resolution and
    not as a mark, and both readings settle the same question.
    """
    rep = given.fact("representation")
    unit = given.fact("unit")
    lines = ["GIVEN BY THE CHAIN. The Surveyor measured the first part and it is not yours to re-decide; the "
             "customer answered the second.",
             f"representation: {given.representation} ({rep.kind if rep else '?'}"
             f"{', measured against the brief' if rep is None or rep.kind == mk.MEASURED else ''})",
             f"unit: {unit.value} ({unit.kind})" if unit is not None
             else "unit: nobody has stated one; it is an open question"]
    confirmed, stated_roles, assumed = [], [], []
    ids = sorted({*given.stated_roles, *given.assumed_roles,
                  *[a.subject for a in (given.intake.answers if given.intake else []) if a.about == "opening.role"]})
    for oid in ids:
        src = given.role_source(oid)
        if src is None:
            continue
        kind, role = src
        (confirmed if kind == mk.CONFIRMED else stated_roles if kind == mk.STATED else assumed).append(
            f"{oid} = {role}")
    # THE DIRECTION THE FLOW COMES AT THE BODY. A person answered it or wrote it in their brief, and until this
    # line existed the answer was written to `report_measured` and the coverage block and read by nobody: the
    # builder's `flow_axis` came off `plan.flow.axis`, which is the model's own choice
    if flow_direction:
        lines.append(f"flow direction: along {flow_direction}, given by the customer. Pose flow.axis and "
                     f"flow.direction_sign so that axis times sign is along {flow_direction}; it is not yours "
                     f"to choose and the checker sends back a plan that poses it the other way")
    lines.append("confirmed by the customer: " + ("; ".join(confirmed) or "nothing"))
    if stated_roles:
        lines.append("stated in the customer's own port list: " + "; ".join(stated_roles))
    if assumed:
        lines.append("defaults that stood, nobody confirmed them (you decide these flow patches; the builder is told "
                     "they are assumptions): " + "; ".join(assumed))
    unsettled = [u for u in given.survey.uncertainties if u.id in set(given.unsettled())]
    if unsettled:
        lines.append("still unsettled: " + "; ".join(f"{u.about} {','.join(u.subjects)}".strip() for u in unsettled))
    budget = given.fact("cell_budget")
    lines.append(f"cell budget: {budget.kind} by the customer" if budget is not None
                 else "cell budget: none stated")
    if look_block and look_block.get("status") == "ok":
        seen = trust.for_model(look_block.get("impression"), model=str(look_block.get("model") or ""))
        if seen:
            # THE TIER IS THE ANSWER; A HAND-WRITTEN LIST BESIDE IT IS A SECOND OPINION. `for_model`
            # nests each field under the tier it EARNED over 322 corpus parts, and `relied_on` means
            # exactly "measured to be right often enough to act on". Keeping three names out of that
            # tier threw away everything else it had earned - including what the look thinks the part
            # IS - so the agent planned with two keys while the BUILDER was handed the same look's
            # identity, confidence and sharp edges. The planner saw less than the thing it plans for.
            #
            # It cost a real job its plan: the agent named the object at 0.85 "with no support but
            # the picture" and was refused three times, on a part whose identity the look had and it
            # was never given. Candidates ride too, under their own name: they are places to measure,
            # never facts, and `agent/grounding.py` caps an identity resting on the look alone at
            # `trust.IDENTITY_CONFIDENCE_MAX` whatever this block says.
            relied = seen.get("relied_on") or {}
            if relied:
                lines.append("the look, fields measured to be right often enough to act on: "
                             + json.dumps(relied, default=str)[:1400])
            # SPELLED AS `for_model` SPELLS IT. This read "candidate" and the writer
            # (`vision/trust.for_model`) emits "candidates", so the block above was the only one that
            # ever arrived and the whole CANDIDATE tier was dropped on every job the platform runs.
            # Measured over the 322 cached corpus looks, what was being thrown away: looks_like on
            # 322 of 322, sharp_edges 319, opening_mouths 310, thin_parts 229, internal_features 171.
            # The comment above describes the defect this line was written to fix, which is what made
            # it hard to see: the intent was right, the key was misspelled, and the fix never landed.
            # It is still costing plans - "the plan names the object at confidence 0.85 with no support
            # but the picture" was one of the five grounding rejections in the 36-run batch of
            # 2026-09-27, on a part whose identity the look had and the planner was never handed.
            candidate = seen.get("candidates") or {}
            if candidate:
                lines.append("the look, CANDIDATES - places to measure, never facts on their own: "
                             + json.dumps(candidate, default=str)[:700])
    lines.append("RULE: decide what to do and where the cells go. Do not contradict a confirmation or the "
                 "customer's port list, and do not state the representation or the unit differently.")
    return "\n".join(lines)


def plan_check(given: Given, flow_direction: str | None = None) -> Callable[[dict], list[str]]:
    """`check_plan` as the loop calls it: what the PLAN says, and nothing the plan did not choose.

    The representation check here is the plan-caused one only (a `wall_shell` region role over a survey that
    measured something else). `hexera.representation_of` also rewrites `unknown` to `fluid_domain` and calls the
    catalog without the customer's port rows, and that is hexera's normalisation, not the plan's: on
    `volute_scroll_012` it refused a plan that had done nothing wrong. On this path the builder is handed the
    survey's representation explicitly, so that rewrite never reaches it, and `builder_representation_differs`
    counts how often it would have on the path that ships today. The checker-written cell counts are skipped for
    the same reason: the plan did not choose them.
    """
    def check(plan_dict: dict) -> list[str]:
        return check_plan(plan_dict, given, skip_keys=CHECKER_WRITTEN, flow_direction=flow_direction)
    return check


def builder_representation_differs(the_plan: GeometryPlan, facts: GeometryFacts, brief: BriefHandoff,
                                   given: Given) -> str | None:
    """What `hexera.representation_of` would hand the builder for this plan, when it is not the survey's. The
    chain never passes it on; this is the count of how often the path that ships today would have."""
    rep = hexera.representation_of(the_plan, facts, brief.text or None)
    return None if rep == given.representation else rep


def plan(facts: GeometryFacts, brief: BriefHandoff, given: Given, document: dict[str, Any], client: Any, *,
         look_block: dict[str, Any] | None = None, config: LoopConfig | None = None,
         fluid_side: str | None = None, flow_direction: str | None = None) -> AnalysisResult:
    """Step 5. The geometry agent plans from the survey's facts plus the confirmations, and the loop enforces both
    halves of the rule: it refuses to start on a context that reads the part differently from the survey, and
    it sends back any plan that contradicts the survey or a confirmation. `fluid_side` is the customer's answer
    to which side of the surface is the fluid, which the context reads the part through. `flow_direction` is
    their answer to which way the flow comes at the body: the text states it and the check pins it, because the
    builder's `flow_axis` is the plan's own `flow.axis` and nothing else was reading the answer."""
    ctx = ToolContext(facts=facts, purpose=brief.purpose, fidelity=brief.fidelity,  # type: ignore[arg-type]
                      cell_cap=given.budget, declared=agent_declared(brief, given, document) or None,
                      brief=brief.text, fluid_side=fluid_side)
    chain_given = ChainGiven(representation=given.representation,
                             text=given_text(given, look_block, flow_direction),
                             check=plan_check(given, flow_direction))
    return run_loop(client, ctx, config, given=chain_given)


def plan_record(result: AnalysisResult, given: Given, facts: GeometryFacts, brief: BriefHandoff, survey_rec: Survey,
                write_up: str, engine: str) -> Plan:
    p = result.plan
    if p is None:
        return Plan(accepted=False, policy=result.exit, write_up=result.reason[:400])
    restated = {"representation": hexera.representation_of(p, facts, brief.text or None), "unit": p.unit.assumed}
    used = tuple(sorted(pt.id for pt in p.patches if given.role_of(pt.id) is not None
                        and str(given.role_of(pt.id).value) == str(pt.role)))
    counts = cell_counts(p.model_dump(mode="json"))
    return Plan(accepted=True, schema_version=getattr(p, "schema_version", None), fidelity=p.mesh_plan.fidelity,
                engine=engine, cell_estimate=counts.get("cell_estimate"),
                refinement_regions=len(p.mesh_plan.refinement_regions), used_confirmations=used,
                restates=plan_drift(survey_rec, restated), risks=len(p.risks), questions_asked=len(p.questions),
                write_up=write_up, policy=result.exit)


# ---------------------------------------------------------------------------------------------------------------
# 6. the third intake, only for a question that did not exist at the second
# ---------------------------------------------------------------------------------------------------------------

def third_intake(survey_handoff: SurveyHandoff, the_plan: GeometryPlan, facts: GeometryFacts, brief: BriefHandoff,
                 given: Given, customer: Customer, *, engine: str,
                 at: str = "") -> tuple[atrade.Envelope, atrade.Trade | None, LateIntakeHandoff | None, list[Any], str]:
    """Step 6. The budget trade, the canonical plan-dependent question, asked ONCE with a default.

    Returns `(envelope, trade, late handoff, resolutions, skipped_because)`. The envelope is computed on every
    job, because the builder receives it either way. The trade is asked only when the planned envelope exceeds
    the stated budget AND the second intake had no budget question at all, asked or held: that is the rule,
    enforced again by `contract.intake.binds_late` so it holds for any caller.
    """
    at = at or now()
    unit = str(given.value("unit") or the_plan.unit.assumed)
    env = atrade.planned_envelope(the_plan, facts, representation=given.representation, engine=engine,
                                  cap=given.budget, unit=unit, brief=brief.text or None)
    earlier = {canonical_kind_safe(u.about) for u in survey_handoff.uncertainties}
    if "budget" in earlier:
        return env, None, None, [], "the second intake already had the budget question; it is asked once"
    trade = atrade.trade_question(env)
    if trade is None:
        why = ("no budget was stated, so there is nothing to trade against" if given.budget is None
               else "the planned envelope fits the stated budget")
        return env, None, None, [], why
    raised = ContractUncertainty(
        id=trade.id, about="cell_budget", why=trade.because, options=list(trade.options),
        options_from="the stated budget and the builder emulator's envelope for this plan", default=trade.default,
        effect="changes_mesh",
        evidence=[mk.measured("forecast.cells_high", env.cells_high,
                              "tools.estimate_builder_cells on the plan's strategy (ask.trade.planned_envelope)")])
    reply = customer.reply(Put(id=trade.id, kind=trade.kind, stage="third", text=trade.text,
                               options=tuple(trade.options), default=trade.default))
    answers: list[Answer] = []
    resolutions: list[Any] = []
    unanswered: list[str] = []
    if reply is None or not reply.value:
        resolutions.append(Defaulted(field="budget:cap", assumed=trade.default, question_id=trade.id,
                                     default_from="the customer's own stated budget", at=at))
        unanswered.append(trade.id)
    else:
        if reply.value not in trade.options:
            raise ContractError("late_intake", f"{reply.value!r} is not one of {trade.options}", field=trade.id)
        resolutions.append(Answered(field="budget:cap", value=reply.value, question_id=trade.id,
                                    answered_by=reply.by, verbatim=reply.verbatim or reply.value, at=at))
        answers.append(Answer(question_id=trade.id, about="cell_budget", value=trade.value_of(reply.value),
                              answered_by=reply.by, at=at))
    late = LateIntakeHandoff(survey_source_sha256=survey_handoff.source_sha256,
                             survey_facts_sha256=survey_handoff.facts_sha256,
                             depends_on=f"plan {_sha(the_plan.model_dump(mode='json'))[:16]}", raised=[raised],
                             asked=[trade.id], answers=answers, unanswered=unanswered)
    return env, trade, late, resolutions, ""


def canonical_kind_safe(about: str) -> str:
    try:
        return canonical_kind(about)
    except ValueError:
        return about


def trade_record(trade: atrade.Trade | None, resolutions: list[Any], key: str, at: str = "") -> Intake | None:
    if trade is None:
        return None
    return Intake(asked=(Question(id=question_id(key, trade.id), uncertainty_id=trade.id, topic="budget",
                                 ask=trade.text, options=tuple(trade.options), default=trade.default,
                                 default_from=trade.default_is, effect="changes_mesh", asked_at=at or now()),),
                  resolutions=tuple(resolutions))


def trade_uncertainty(trade: atrade.Trade) -> Uncertainty:
    env = trade.envelope
    return Uncertainty(
        id="budget:planned", kind="budget", subject="planned", known={k: env.get(k) for k in
                                                                        ("cells_high", "cells_low", "cap",
                                                                         "held_cells_high", "held_cells_across",
                                                                         "proper_cells_across")},
        unsettled_because="resolving the places the plan names costs more cells than the budget you stated",
        ask=trade.text, default=trade.default, default_from=f"{trade.default_is}: {trade.because}",
        teaches=KIND_TEACHES["budget"], effect="changes_mesh", rank=float(TIERS.index("resolution")),
        why=f"the planned envelope from {env.get('source')} exceeds the stated budget", options=tuple(trade.options),
        options_from="the stated budget and the builder emulator's envelope for this plan", tier="resolution",
        computed=True, raised_at="third", asked=True, settled_by="")


# ---------------------------------------------------------------------------------------------------------------
# 7. the builder
# ---------------------------------------------------------------------------------------------------------------

def geometry_write_up(run: JobRun, *, engine: str) -> dict[str, Any]:
    """The geometry agent's write-up: `hexera.builder_plan_block`, handed the SURVEY's representation and the
    RESOLVED budget, so `hexera.representation_of` is never consulted on this path."""
    given, facts, the_plan = run.given, run.facts, run.plan
    assert given is not None and facts is not None and the_plan is not None
    return hexera.builder_plan_block(the_plan, facts, engine=engine, cell_cap=given.budget,
                                     representation=given.representation,
                                     unit=str(given.value("unit") or the_plan.unit.assumed),
                                     brief=run.brief.text or None, request_txt=run.brief.text or None)


def named_inlets(given: Given, facts: GeometryFacts) -> list[str]:
    """The mouths a person called the inlet: confirmed, or stated in their own port list. A default that stood
    and the agent's own decision are not in it, so the block's inlet is never a guess wearing a person's word."""
    out: list[str] = []
    for o in facts.openings:
        src = given.role_source(o.id)
        if src is not None and src[0] in (mk.CONFIRMED, mk.STATED) and src[1] == "inlet":
            out.append(o.id)
    return out


#: The line the builder reads in front of the cut when step 5 made no plan, and how long it may be. It is short
#: on purpose: the prose in front of the cut is the customer's own request, and a job with no plan has less to
#: say there, not more. The reason in full rides in the typed block, where the cut cannot reach it.
NO_PLAN_LINE = ("GEOMETRY AGENT: no plan was made for this part ({exit}). Nothing below is a plan of ours and no "
                "patch was chosen by one. The measured block still stands; see its `survey.unsettled` for why.")
NO_PLAN_PREFIX_BUDGET = 300


def no_plan_write_up(run: JobRun) -> dict[str, Any]:
    """What goes in front of the cut when there is no plan: one line naming the exit, and no instruction.

    THE EXIT WORD AND NOT THE REASON, because `AnalysisResult.reason` carries the checker's own errors and runs
    to hundreds of characters; in front of the cut those characters come out of the customer's request. The
    reason travels whole in the typed block (`contract.deliver.with_no_plan`).
    """
    return {"text": NO_PLAN_LINE.format(exit=run.result.exit if run.result is not None else "no agent ran"),
            "budget": NO_PLAN_PREFIX_BUDGET}


def deliver_to_builder(run: JobRun, record: JobRecord, write_up: dict[str, Any], *,
                       no_plan: str = "") -> dict[str, Any]:
    """Step 7. The geometry agent's instruction in front of the cut, and after it, in the typed block: the
    measurement and the look, the Surveyor's marks, intake's write-up and the plan's envelope.

    `no_plan` IS THE REASON THERE IS NO PLAN, and passing it is how step 7 runs for a job step 5 could not
    plan. The block then carries one `unsettled` row saying so (`deliver.with_no_plan`) and the whole contract
    is run again over it, because a row added after `builder_handoff` validated the block is the one thing in
    the block nothing checked. Without it the builder was handed a measurement identical to a job the geometry
    agent never ran on, which is the silence `with_no_plan` documents.
    """
    given, facts = run.given, run.facts
    assert given is not None and facts is not None and run.document is not None
    # THE INLET THE CUSTOMER NAMED is the one the block sizes from: the survey measured before anybody said which
    # mouth is which, and its widest-mouth fallback named the customer's outlet as the inlet on 3 of 8 parts
    #
    # THE SAME RESOLVER AS STEP 5, with the third intake's rows added because they exist by now. The plan was
    # CHECKED against the value at step 5, so if the two ever differ the builder would be handed a direction no
    # plan was ever held to. The third intake is the budget trade and carries no direction today, so this cannot
    # happen; it is recorded rather than asserted because a silent drift here is the defect this item was about
    flow = flow_axis_of(given, [*run.resolutions, *run.late_resolutions], brief=run.brief)
    if flow != run.notes.get("flow_direction"):
        run.notes["flow_direction_moved_after_the_plan"] = {"checked": run.notes.get("flow_direction"),
                                                           "delivered": flow}
    final = survey_document(facts, run.brief, run.look_block, cell_cap=given.budget, flow_direction=flow,
                            inlet_ids=named_inlets(given, facts), fluid_side=fluid_side_answered(run.resolutions))
    intake_block = chandover.intake_block(record)
    patches = deliver.flow_patches([p.model_dump(mode="json") for p in run.plan.patches], given) \
        if run.plan is not None else None
    # THE CUSTOMER'S ANSWERS RIDE IN `survey.confirmed` (work/z-deliver NEEDS 7): the second intake's and the third's,
    # bound to the survey they answer. Without them the survey the builder read listed every answered role as
    # unsettled
    answers = [*(run.intake.answers if run.intake is not None else []), *(run.late.answers if run.late else [])]
    answered = SimpleNamespace(survey_source_sha256=given.survey.source_sha256, answers=answers) \
        if run.intake is not None else None
    # STEP 4 REACHES THE BUILDER AS A FACT ABOUT THE JOB, and `counts` is what makes that true rather than the
    # comment saying so. `joint.RECORD_DEFAULT` carries the numbers, the question, the confirmed fields, the
    # tiers and the firings as signal IDS: no suppressed sentence is quoted back, so nothing here is a new claim
    # about the part. `joint.planner_block` then puts the contradiction count INSIDE `look`, because the
    # platform's `GEOMETRY_AGENT_BLOCK_KEYS` is an allowlist and a new top-level key is dropped in silence.
    # AND THE MEASURED HALF, which is not a fact about the job but a measurement about the part, and is the
    # other consumer this layer had and never fed. `hexera._planner_places` reads `measured_places` and ranks
    # the rows with every other place; `hexera.py` says they are the only throat and section-change places
    # there are. Nothing wrote the key, so the planner has never seen one.
    if run.joint is not None:
        from geometry_agent.reconcile import joint as rjoint
        rjoint.into_document(final, run.joint)
        block = rjoint.planner_block(final, intake=answered)
    else:
        block = hexera.planner_block(final, intake=answered)
    handoff = deliver.builder_handoff(block, given, geometry_write_up=write_up,
                                      intake_block=intake_block,
                                      plan_envelope=run.envelope.as_dict() if run.envelope is not None else None,
                                      patches=patches)
    if not no_plan:
        return handoff
    out = {**handoff, "typed": deliver.with_no_plan(handoff["typed"], no_plan)}
    deliver.check_builder_handoff(out, given)
    return out


# ---------------------------------------------------------------------------------------------------------------
# the whole job
# ---------------------------------------------------------------------------------------------------------------

def _record(run: JobRun, part_key: str, job_id: str, case: str, **stages: Any) -> JobRecord:
    return JobRecord(key=run.key, part_key=part_key, job_id=job_id, provenance=run.provenance, case=case,
                     **stages)


def run_job(purpose: str, brief_text: str = "", *, path: str | Path | None = None,
            facts: GeometryFacts | None = None, declared: list[dict[str, Any]] | None = None,
            engine: str | None = None, fidelity: str = "standard", cell_cap: int | None = None,
            customer: Customer | None = None, client: Any = None, look_block: dict[str, Any] | None = None,
            look_fn: LookFn | None = None, ledger: JobLedger | None = None, job_id: str = "",
            provenance: str = "live", case: str = "",
            asked_before: dict[str, int] | None = None, config: LoopConfig | None = None,
            cache_dir: str | Path | None = None) -> JobRun:
    """The seven steps, in Rehaan's order. Returns the run with every handoff and every ledger row it wrote.

    `client` is the geometry agent's model (`agent.reference.ReferencePolicy` for a deterministic run, or
    `client_from_env()`); `customer` answers the questions (`Silent` when omitted, which confirms nothing). The
    ledger is optional; without one, the events are still built and returned, and nothing is written anywhere.

    `alerts` AND `reconciliation` USED TO BE PARAMETERS HERE AND ARE GONE. They were pure pass-through: this
    function accepted them, handed them to `survey`, and `survey` handed them to `ask_intake`, where
    `dispute_uncertainty` sat behind `if reconciliation is None: return []`. Nothing in this repository, in the
    platform or in any eval ever passed either one, on any line, so the guard was never passed and step 4's whole
    output had no route in. Step 4 now runs here (`reconcile`, between the look and the questions) and builds
    both. Keeping the parameters as a caller override would have left a seam with no caller, which is the same
    defect in a smaller costume; a caller that needs one can add it back with its call site.
    """
    customer = customer or Silent()
    brief = state_brief(purpose, brief_text, declared=declared, engine=engine, fidelity=fidelity,
                        cell_cap=cell_cap)
    job_id = job_id or brief.sha256[:12]
    run = JobRun(key="", provenance=provenance, brief=brief)
    own_ledger = ledger or JobLedger(Path("unused"))
    part_key = ""

    # 2. MEASURE, against the brief. Admission refuses before anything is measured.
    got, refusal = measure(brief, path, facts=facts, cache_dir=cache_dir)
    if got is None:
        run.key = own_ledger.open_job(_sha(str(path)), job_id, provenance=provenance, case=case)
        run.events.append(own_ledger.put(run.key, "brief", brief_record(brief)))
        run.exit, run.reason = "refused", refusal
        return _flush(run, ledger)
    run.facts = got
    part_key = got.sha256
    run.key = own_ledger.open_job(part_key, job_id, provenance=provenance, case=case)
    run.events.append(own_ledger.put(run.key, "brief", brief_record(brief)))

    run.representation_without_brief = representation_without_brief(got, brief.purpose)
    measured = survey_document(got, brief)
    representation = str(measured["representation"])

    # 3. LOOK, after the measurement, with the survey's representation.
    run.look_block = look(got, brief, representation, path=path, block=look_block, look_fn=look_fn)
    run.document = survey_document(got, brief, run.look_block)
    survey_rec = survey_record(run.document, brief, run.representation_without_brief)
    run.events.append(own_ledger.put(run.key, "survey", survey_rec))
    run.events.append(own_ledger.put(run.key, "look", look_record(run.look_block)))

    # 4. RECONCILE, then INTAKE armed with the survey AND with what step 4 found.
    # THE DIRECTION THE CUSTOMER GAVE, as far as this point in the chain can know it. `given` and the
    # resolutions do not exist until the second intake, which is the next step, so the brief's own sentence is
    # the whole of the customer's voice here and `flow_axis_of` is the one reader of it.
    run.joint = reconcile(got, representation, run.look_block, path=path, case=case or part_key,
                          stated_axis=flow_axis_of(None, brief=brief))
    reconciliation = run.joint.reconciliation if run.joint is not None else None
    alerts = run.joint.alerts if run.joint is not None else None
    run.survey, run.asked, run.records = survey(run.document, brief, alerts=alerts, reconciliation=reconciliation,
                                                asked_before=asked_before)
    run.events.append(own_ledger.put(run.key, "uncertainty", run.records))
    run.intake, run.resolutions, stated, assumed = second_intake(run.survey, run.asked, customer,
                                                                 document=run.document,
                                                                 declared=list(brief.declared) or None)
    run.notes["stated_off_builder_ports"] = sorted(
        r.field.split(":", 1)[1] for r in run.resolutions
        if isinstance(r, Stated) and "does not cut it as a port" in r.quote)
    # THE BRIEF'S OWN ANSWERS, carried as marks. A question the brief settled was held with the quote and nothing
    # read it: on the unit that meant the file's guess stood while the customer's sentence sat in the ledger
    run.given = Given.of(run.survey, run.intake, stated_roles=stated, assumed_roles=assumed,
                         stated_facts=brief_stated_facts(run.asked))
    # THE LABEL ROWS, which are what `contract/ratchet.py` reads and what nothing was building
    run.notes["labels"] = labels_from(run.given, run.asked)
    intake_rec = intake_record(run.asked, run.resolutions, run.key)
    record = _record(run, part_key, job_id, case, brief=brief_record(brief), survey=survey_rec,
                     look=look_record(run.look_block), uncertainties=tuple(run.records), intake=intake_rec)
    intake_rec = Intake(asked=intake_rec.asked, resolutions=intake_rec.resolutions,
                        write_up=chandover.write_up(record))
    run.events.append(own_ledger.put(run.key, "intake", intake_rec))

    # 5. GEOMETRY.
    eng = str(run.document.get("engine") or "snappy")
    if client is None:
        run.exit, run.reason = "no_agent", "no geometry agent client was given; the chain stops at the plan"
        return _flush(run, ledger)
    # WHICH SIDE IS THE FLUID, when intake asked it and a person answered: the agent reads the part that way and
    # the builder's block is measured that way. A default that stood leaves both on today's reading, refused
    run.notes["fluid_side"] = fluid_side_answered(run.resolutions)
    # WHICH WAY THE FLOW COMES, from the same resolutions the builder handoff reads it from at step 7. One value,
    # resolved here, so the text the agent reads, the rule that sends a plan back and the block the builder gets
    # cannot disagree about what the customer said
    run.notes["flow_direction"] = flow_axis_of(run.given, run.resolutions, brief=run.brief)
    run.result = plan(got, brief, run.given, run.document, client, look_block=run.look_block, config=config,
                      fluid_side=run.notes["fluid_side"], flow_direction=run.notes["flow_direction"])
    run.notes["plan_violations_sent_back"] = sum(1 for t in run.result.trace if t.get("rejection_kind") == "given")
    if run.plan is None:
        plan_rec = plan_record(run.result, run.given, got, brief, survey_rec, "", eng)
        run.events.append(own_ledger.put(run.key, "plan", plan_rec))
        run.exit, run.reason = run.result.exit, run.result.reason
        # 7. BUILDER, WITHOUT A PLAN AND SAYING SO. The job still goes to the builder: the measurement, the look
        # and the customer's answers are worth having and the platform hands them over whatever step 5 did. What
        # it never said is that a plan was ATTEMPTED and could not be made, so the block the builder read was the
        # block of a job the geometry agent had never run on. `no_plan=` puts the reason in it.
        record = _record(run, part_key, job_id, case, brief=brief_record(brief), survey=survey_rec,
                         look=look_record(run.look_block), uncertainties=tuple(run.records), intake=intake_rec,
                         plan=plan_rec)
        run.handoff = deliver_to_builder(run, record, no_plan_write_up(run), no_plan=run.reason)
        run.events.append(own_ledger.put(run.key, "handover", run.handoff))
        return _flush(run, ledger)
    plan_dict = run.plan.model_dump(mode="json")
    run.notes["builder_representation_differs"] = builder_representation_differs(run.plan, got, brief, run.given)
    run.notes["unconfirmed_roles"] = unconfirmed_roles(plan_dict, run.given)
    run.notes["plan_cell_counts"] = cell_counts(plan_dict)
    # THE AGENT'S OWN QUESTIONS ARE NOT PUT TO THE CUSTOMER on this path. The third intake is for a question that
    # did not exist at the second, and the canonical one, the budget, is the trade above, costed on the builder
    # emulator; the plan's `cell_cap` question is raised by the checker (R36) from `cell_estimate_refined`, the
    # number the trade exists to replace. The rest (`short_stub` above all) are decisions about what to DO, which
    # is the agent's job. Recorded here by the risk each one relates to, so a corpus run counts them.
    risk_kind = {r.id: r.kind for r in run.plan.risks}
    run.notes["plan_questions_not_put"] = [risk_kind.get(q.relates_to, str(q.relates_to))
                                           for q in run.plan.questions]

    # 6. INTAKE a third time, only for a question that did not exist at the second.
    run.envelope, run.trade, run.late, run.late_resolutions, run.trade_skipped_because = third_intake(
        run.survey, run.plan, got, brief, run.given, customer, engine=eng)
    if run.late is not None:
        run.given = Given.of(run.survey, run.intake, late=run.late, stated_roles=stated, assumed_roles=assumed)

    # the plan's row is written once its write-up exists, and the write-up is sized against the RESOLVED budget,
    # which the third intake can move; then the third intake's question joins the uncertainty stage (re-written,
    # last event wins), then the trade itself, so the rows read in the order the job happened
    write_up = geometry_write_up(run, engine=eng)
    plan_rec = plan_record(run.result, run.given, got, brief, survey_rec, str(write_up.get("text") or ""), eng)
    run.events.append(own_ledger.put(run.key, "plan", plan_rec))
    trade_rec = trade_record(run.trade, run.late_resolutions, run.key)
    if trade_rec is not None:
        run.records.append(trade_uncertainty(run.trade))
        run.events.append(own_ledger.put(run.key, "uncertainty", run.records))
        run.events.append(own_ledger.put(run.key, "trade", trade_rec))

    # 7. BUILDER.
    record = _record(run, part_key, job_id, case, brief=brief_record(brief), survey=survey_rec,
                     look=look_record(run.look_block), uncertainties=tuple(run.records), intake=intake_rec,
                     plan=plan_rec, trade=trade_rec)
    run.handoff = deliver_to_builder(run, record, write_up)
    run.events.append(own_ledger.put(run.key, "handover", run.handoff))
    run.exit, run.reason = "delivered", "every handoff passed its contract"
    return _flush(run, ledger)


def resolutions_from_rows(questions: list[Any], rows: list[dict[str, Any]], *, asked: list[str] | None = None,
                          customer: str = "customer") -> list[Any]:
    """The ledger's resolutions from a platform's answer rows (the platform fixer's NEEDS 13).

    The platform keeps every answer as a row in `geometry_surveys.answers`: `question_id`, `about`, `subject`,
    `value`, `answered_by`, `skipped`, `at`. This reads them the way the chain's own second intake records its
    answers, so a job the platform ran lands in the job ledger as the same three things and never as a fourth:

      Answered   a row the CUSTOMER gave and did not skip
      Defaulted  a question that was asked (`asked`) with no customer answer: our default stood
      Unasked    a question the survey raised and nobody put

    A DEFAULT IS NOT A CONFIRMATION. A row written by anyone other than `customer`, or a skipped row, is never an
    `Answered`, whatever value it carries. `questions` are the survey's questions (anything with `id`, `about`,
    `subject` and `default`)."""
    asked_ids = set(asked or [])
    by_q: dict[str, dict[str, Any]] = {}
    for row in rows or []:
        if isinstance(row, dict) and row.get("answered_by") == customer and not row.get("skipped"):
            by_q[str(row.get("question_id") or "")] = row
    out: list[Any] = []
    for q in questions:
        qid = str(getattr(q, "id", "") or "")
        about = str(getattr(q, "about", "") or "")
        default = str(getattr(q, "default", "") or "")
        row = by_q.get(qid)
        if row is not None:
            subject = str(row.get("subject") or getattr(q, "subject", "") or "")
            out.append(Answered(field=f"{about}:{subject}" if subject else about, value=str(row.get("value")),
                                question_id=qid, answered_by=customer, verbatim=str(row.get("note") or ""),
                                at=str(row.get("at") or now())))
        elif qid in asked_ids:
            out.append(Defaulted(field=about, assumed=default, question_id=qid, default_from="the survey's own default",
                                 at=now()))
        else:
            out.append(Unasked(field=about, assumed=default, why_not_asked="policy",
                               default_from="the survey's own default", at=now()))
    return out


def _flush(run: JobRun, ledger: JobLedger | None) -> JobRun:
    if ledger is not None:
        ledger.flush()
    return run


__all__ = ["ABOUT_OF", "QUESTION_BUDGET", "ROLE_WORD", "RUN_SCHEMA", "Customer", "JobRun", "Put", "Reply", "Scripted",
           "Silent", "agent_declared", "brief_record", "builder_representation_differs", "contract_uncertainties", "deliver_to_builder",
           "fluid_side_answered", "geometry_write_up", "given_text", "labels_from",
           "intake_record", "look", "look_record", "resolutions_from_rows", "measure", "merged_records", "named_inlets",
           "plan", "plan_check",
           "plan_record", "representation_without_brief", "run_job", "second_intake", "state_brief", "survey",
           "survey_document", "survey_for", "survey_record", "third_intake", "topic_of", "trade_record",
           "trade_uncertainty"]
