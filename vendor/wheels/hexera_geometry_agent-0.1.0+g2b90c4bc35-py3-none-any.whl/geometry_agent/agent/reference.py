"""A deterministic policy that speaks the tool protocol. Tests the loop without a model; runs the CLI without one.

Plan schema 3 (dev plan P4.2, docs/plan_v3_rules.md): the stand-in writes the schema 3 obligations it can compute
from the tool results alone: two identity hypotheses from the family signature with a refuting test it evaluates
from the facts, the identity verdict with tests_run citing ledger numbers, two agent_risks_considered with a
measured number, a second look computed the way the checker recomputes it (lines it cannot evaluate, the seed's
ray parity, are left out), the flow counterfactual from compare_roles whenever the checker would demand one (the
assignment with fewer high risks is taken under a silent brief), an effect on every question, and the two lists
left to `_normalise`. Its catalog risks are written in the short form P4.3e asks a model for (R34: the id, the
decision and the reason for overriding the catalog, nothing the catalog itself measured), so the self-checks
exercise the same path a live run takes. `build_plan(..., schema_version=2)` still writes the P4.1 plan byte for
byte, so the stored schema 2 transcripts have a stand-in to compare against. The path is summary, openings, axes, estimate,
list_risks, compare_roles when the direction is in doubt, list_risks again when the swap wins, submit."""
from __future__ import annotations

import json
import math
import re
from dataclasses import dataclass, field

from geometry_agent.agent.catalog import _UNIT_WORDS, KIND_EFFECT
from geometry_agent.agent.client import ModelResponse, ToolCall
from geometry_agent.agent.grounding import (
    DIRECTION_IN_BRIEF,
    ON_THE_METAL,
    PROCEED,
    R9_ROLE_KINDS,
    R9_SETTLES,
    R9_UNIT_IN_BRIEF,
    ROLE_DECISION_KINDS,
    STUB_QUESTION_KINDS,
)
from geometry_agent.agent.schema import PLAN_SCHEMA_VERSION
from geometry_agent.agent.tools import COMPARE_ROLES, SUBMIT

PORT_TUBULARITY = 0.85
SAME_BORE = 0.8
LAYERS = {"draft": 3, "standard": 8, "max": 15}
LEVELS = {"draft": 1, "standard": 2, "max": 3}
STUB_OK_OVER_D = 5.0
#: The stand-in's own copies of the numbers its second look quotes (a self-check policy, never a result).
PORT_CELLS_MIN = 8.0
TILTED_MOUTH_DEG = 0.5
BUILDER_CELLS_ACROSS = 24
#: The checker's caps on schema 3 prose (R12 and the builder prose cap).
ANALYSIS_MAX_CHARS = 1500
BUILDER_PROSE_MAX_CHARS = 600
WALL_SHELL_KINDS = ("wall_shell_to_carve", "solid_wall_representation")


@dataclass
class ReferencePolicy:
    """Follows: summary -> openings -> axes -> list_risks(roles) -> [compare_roles -> list_risks(swap)] -> submit.
    Repairs missing-risk rejections once."""
    steps: list[str] = field(default_factory=list)
    summary: dict | None = None
    openings: list[dict] = field(default_factory=list)
    axes: dict | None = None
    roles: dict[str, str] = field(default_factory=dict)
    #: None until list_risks(roles) has been called: a part with no openings has empty roles and must still submit.
    risks: list[dict] | None = None
    submitted: int = 0
    #: A tool result the policy could not parse or that was clipped: the policy stops instead of guessing.
    unreadable: bool = False
    #: The compare_roles result (schema 3 counterfactual); `compared` once it was asked for, `swapped` once the
    #: other assignment was taken and list_risks called again under it.
    compare: dict | None = None
    compared: bool = False
    swapped: bool = False
    #: Once the ring check or the swap fixed the roles, list_risks is called again under them, never reassigned.
    roles_fixed: bool = False
    rings_checked: bool = False
    schema_version: int = PLAN_SCHEMA_VERSION
    #: The id of the call this policy last made, so a tool result it did not ask for (the run's own look) is not
    #: read as the answer to the step it is waiting on. See `_mine`.
    last_call_id: str | None = None

    def complete(self, messages: list[dict], tools: list[dict], force_tool: str | None = None) -> ModelResponse:
        last = messages[-1]
        if last["role"] == "tool":
            self._absorb(messages)
        if self.unreadable or (self.summary is not None and "openings" not in self.summary):
            # a clipped tool result (a 2000-opening assembly) is beyond a deterministic policy: exit truthfully
            return ModelResponse(content="The measurements are too large for the heuristic policy to plan from.")
        if self.summary is None:
            return self._call("get_facts_summary")
        if not self.openings and "list_openings" not in self.steps:
            return self._call("list_openings")
        if self.axes is None:
            return self._call("get_axes")
        if "estimate_cells" not in self.steps:
            return self._call("estimate_cells", tier=self.summary["fidelity"])
        if self.risks is None:
            if not self.roles_fixed:
                self.roles = assign_roles(self.summary, self.openings, self.axes)
            return self._call("list_risks", roles=self.roles)
        if not self.rings_checked:
            # the catalog names the representation only through its risks: rings taken as ports on a body that
            # measures as a fluid domain (ring_faces_present, no wall shell or annular passage) go back to walls
            self.rings_checked = True
            demoted = demote_rings(self.roles, self.openings, self.risks)
            if demoted != self.roles:
                self.roles, self.roles_fixed, self.risks = demoted, True, None
                return self._call("list_risks", roles=self.roles)
        if self.schema_version >= 3 and not self.compared and direction_in_doubt(self.summary, self.roles, self.risks):
            self.compared = True
            return self._call(COMPARE_ROLES, roles_a=dict(self.roles), roles_b=swap_roles(self.roles))
        if self.compare is not None and not self.swapped and take_swap(self.compare, self.summary, self.roles):
            self.swapped = self.roles_fixed = True
            self.roles = swap_roles(self.roles)
            self.risks = None
            return self._call("list_risks", roles=self.roles)
        if self.submitted == 0 or self._last_rejection(messages):
            if self.submitted >= 2:
                return ModelResponse(content="I cannot produce a grounded plan for this geometry.")
            self.submitted += 1
            plan = build_plan(self.summary, self.openings, self.axes, self.roles, self.risks, compare=self.compare,
                              schema_version=self.schema_version)
            return self._call(SUBMIT, plan=plan)
        return ModelResponse(content="done")

    def _call(self, name: str, **args) -> ModelResponse:
        self.steps.append(name)
        self.last_call_id = f"c{len(self.steps)}"
        return ModelResponse(content="", tool_calls=[ToolCall(id=self.last_call_id, name=name, arguments=args)])

    def _mine(self, message: dict) -> bool:
        """Whether a tool message answers the call this policy last made.

        The policy reads a tool result positionally: whatever came back is taken to be the answer to
        `steps[-1]`. That held while every tool call in a run was its own. It stops holding the moment the run
        puts a call the policy did not make into the conversation, and the always-on look is exactly that: a
        `look_at_views` result absorbed as `get_facts_summary`'s would make the impression the facts summary and
        the case would exit "measurements too large for the heuristic policy". The call ids are the policy's own
        (`c1`, `c2`, ...), so a tool message carrying any other id is not its answer and is passed over. A look
        that arrives in the opening message instead needs nothing: the policy reads tool messages only."""
        tid = message.get("tool_call_id")
        return tid is None or self.last_call_id is None or tid == self.last_call_id

    def _absorb(self, messages: list[dict]) -> None:
        if not self._mine(messages[-1]):
            return
        name = self.steps[-1] if self.steps else ""
        try:
            payload = json.loads(messages[-1]["content"])
        except json.JSONDecodeError:
            self.unreadable = True
            return
        if not isinstance(payload, dict) or "_truncated" in payload and name in ("get_facts_summary", "list_openings"):
            self.unreadable = True
            return
        if name == "get_facts_summary":
            self.summary = payload
        elif name == "list_openings":
            self.openings = payload.get("openings", [])
        elif name == "get_axes":
            self.axes = payload.get("axes", {})
        elif name == "estimate_cells":
            self.summary["_base_size"] = payload["estimates"][0]["base_size"]
        elif name == "list_risks":
            self.risks = payload.get("risks", [])
        elif name == COMPARE_ROLES:
            self.compare = payload if "error" not in payload else None

    def _last_rejection(self, messages: list[dict]) -> bool:
        last = messages[-1]
        if last["role"] != "tool" or self.steps[-1] != SUBMIT or not self._mine(last):
            return False
        try:
            return json.loads(last["content"]).get("accepted") is False
        except json.JSONDecodeError:
            return False


def assign_roles(summary: dict, openings: list[dict], axes: dict) -> dict[str, str]:
    purpose = summary["purpose"]
    roles: dict[str, str] = {}
    ports = [o for o in openings if o.get("classification", "port_candidate") == "port_candidate"
             and o["tubularity"] >= PORT_TUBULARITY]
    if not ports and purpose in {"internal_cfd", "conjugate_heat_transfer"}:
        # a wall shell or an annular passage: the open ring bores are the ports (the catalog says which it is)
        ports = [o for o in openings if o.get("kind") == "ring" and o.get("bore_diameter")]
    declared = {d.get("name", "").lower(): d for d in (summary.get("declared_ports") or [])}
    located = [d for d in (summary.get("declared_ports") or []) if d.get("near") and d.get("role") in ("inlet", "outlet")]
    if purpose in {"internal_cfd", "conjugate_heat_transfer"} and located:
        # the user located every port: take the nearest measured opening of any kind (a pierced wall's ring, an
        # annular end face, a cap) within one hydraulic diameter and give it the declared role
        taken: set[str] = set()
        for d in located:
            best, best_dist = None, None
            for o in openings:
                if o["id"] in taken:
                    continue
                if o.get("kind") != "ring" and any(
                        x.get("kind") == "ring" and x["id"] not in taken
                        and sum((a - b) ** 2 for a, b in zip(d["near"], x["centroid"])) ** 0.5 <= 0.1 * max(x.get("bore_diameter") or 0.0, x["hydraulic_diameter"])
                        for x in openings):
                    continue  # a ring sits exactly here: a centre body's end cap inside it is never the port
                dist = sum((a - b) ** 2 for a, b in zip(d["near"], o["centroid"])) ** 0.5
                scale = max(o.get("bore_diameter") or 0.0, o["hydraulic_diameter"], 1e-9)
                if dist > scale:
                    continue
                # a ring and a centre body's cap share a centroid: the one whose size matches the declaration wins
                size = o.get("bore_diameter") or o["hydraulic_diameter"]
                want = d.get("bore_diameter") or (2.0 * (d["area"] / 3.141592653589793) ** 0.5 if d.get("area") else None)
                score = dist / scale + (abs(size / want - 1.0) if want and size else 0.0)
                if best_dist is None or score < best_dist:
                    best, best_dist = o, score
            if best is not None:
                roles[best["id"]] = d["role"]
                taken.add(best["id"])
        for o in openings:
            roles.setdefault(o["id"], "wall")
        return roles
    if purpose in {"internal_cfd", "conjugate_heat_transfer"} and ports:
        ports.sort(key=lambda o: -o["hydraulic_diameter"])
        inlet = ports[0]
        roles[inlet["id"]] = "inlet"
        for o in ports[1:]:
            if o["hydraulic_diameter"] >= SAME_BORE * inlet["hydraulic_diameter"]:
                roles[o["id"]] = "opening_unknown"
            else:
                roles[o["id"]] = "outlet"
        if declared:
            n_in = sum(1 for d in declared.values() if d.get("role") == "inlet")
            n_out = sum(1 for d in declared.values() if d.get("role") == "outlet")
            if n_in + n_out == len(ports):
                for o in ports[:n_in]:
                    roles[o["id"]] = "inlet"
                for o in ports[n_in:]:
                    roles[o["id"]] = "outlet"
    for o in openings:
        roles.setdefault(o["id"], "wall")
    return roles


def demote_rings(roles: dict[str, str], openings: list[dict], risks: list[dict]) -> dict[str, str]:
    """Rings assigned as ports that the catalog did not name become walls: a ring is a port only on a wall shell
    or an annular passage (the checker's R1), and there only the rings the representation risk lists in
    `ring_ids` (wall_shell_to_carve, annular_ports, solid_wall_representation: the catalog's port candidates,
    which leave out a flange's shoulder, a plate pierced by a boss and a step inside a bore, docs/plan_v2_rules.md
    "Pierced rings"). On a body the catalog measured as a fluid domain (ring_faces_present fires and no
    representation risk does) every ring goes back to a wall."""
    kinds = {r.get("kind") for r in risks}
    rings = {o["id"] for o in openings if o.get("kind") == "ring"}
    named: set[str] | None = None
    for r in risks:
        if r.get("kind") in ("wall_shell_to_carve", "annular_ports", "solid_wall_representation"):
            ids = (r.get("measurement") or {}).get("ring_ids")
            if ids is not None:
                named = set(ids) | (named or set())
    if named is not None:
        return {k: ("wall" if k in rings and k not in named and v in ("inlet", "outlet", "opening_unknown") else v)
                for k, v in roles.items()}
    if "ring_faces_present" not in kinds or kinds & {"wall_shell_to_carve", "annular_ports", "solid_wall_representation"}:
        return roles
    return {k: ("wall" if k in rings and v in ("inlet", "outlet", "opening_unknown") else v) for k, v in roles.items()}


def swap_roles(roles: dict[str, str]) -> dict[str, str]:
    """The other assignment: inlets and outlets exchanged, every other role kept (the checker's R11 swap)."""
    return {k: ("outlet" if v == "inlet" else "inlet" if v == "outlet" else v) for k, v in roles.items()}


def direction_in_doubt(summary: dict, roles: dict[str, str], risks: list[dict]) -> bool:
    """When the checker (R11) demands a counterfactual: role_assumed fires, a role decision is pending (the plan
    asks it), or an inlet or outlet is assigned with no declared ports (the stand-in's port confidence is under
    the checker's 0.9)."""
    if any(r.get("kind") == "role_assumed" for r in risks):
        return True
    if any(r.get("kind") in ROLE_DECISION_KINDS and r.get("requires_user_decision")
           and r.get("user_decision", "pending") == "pending" for r in risks):
        return True
    declared = summary.get("declared_ports") or []
    return not declared and any(v in ("inlet", "outlet") for v in roles.values())


def take_swap(compare: dict, summary: dict, roles: dict[str, str]) -> bool:
    """Whether the swapped assignment is the one to submit: the checker rejects an assignment with strictly more
    high risks than its swap when no port is declared and the brief names no direction, and only when the plan
    has both an inlet and an outlet to swap."""
    if compare.get("fewer_high_risks") != "b":
        return False
    if summary.get("declared_ports") or DIRECTION_IN_BRIEF.search(summary.get("user_brief") or ""):
        return False
    return "inlet" in roles.values() and "outlet" in roles.values()


def _n(x: float) -> float:
    return float(x)


def _body_number(summary: dict) -> float:
    """A ledger number that describes the body for an identity test: the volume, or the surface area when the file
    encloses none (a 2D plate, a surface export), else the longest extent."""
    for key in ("total_volume", "total_surface_area"):
        v = summary.get(key)
        if isinstance(v, (int, float)) and v > 0:
            return float(v)
    return float(max(summary["bbox_extent"]))


def _tier_cells(summary: dict, fidelity: str) -> int:
    est = summary["cell_estimates"][fidelity]
    return int(est["cells"] if isinstance(est, dict) else est)


def _unit_call(summary: dict, risks: list[dict]) -> dict:
    """Mirror of the checker's own reading: the file's declared unit, else the unit a dimension in the brief pins
    (the catalog says so on unit_unknown), else the best guess, asked."""
    declared = summary.get("unit_declared")
    if declared:
        return {"declared": declared, "assumed": declared, "basis": "file"}
    unit_risk = next((r for r in risks if r["kind"] == "unit_unknown"), None)
    m = (unit_risk or {}).get("measurement", {})
    guess = m.get("best_guess") or (summary.get("unit_plausible") or ["m"])[0]
    if m.get("settled_by_brief"):
        return {"declared": None, "assumed": guess, "basis": "brief"}
    return {"declared": None, "assumed": guess, "basis": "guess"}


def _snap_axis(inward: list[float], axes: dict) -> tuple[list[float], str]:
    """The plan's flow axis is a measured principal axis or a unit vector, never a bare port normal (an inclined
    port's normal is not a number the builder can trace); take the one closest to the inlet's inward normal."""
    cands = [([1.0 if i == j else 0.0 for j in range(3)], "axis-aligned direction") for i in range(3)]
    cands += [(list(v), f"principal axis {i}") for i, v in enumerate(axes.get("principal") or [])]
    return max(cands, key=lambda c: abs(sum(a * b for a, b in zip(c[0], inward))))


def _region_roles(summary: dict, purpose: str, ring_ports: bool = False) -> list[dict]:
    """Roles the checker does not fill in: conjugate pairs (inner body fluid, outer solid) and multi-body internal
    files (every body fluid, the region_purpose_mismatch risk carries the question). A wall shell (ring ports)
    is left to the checker's defaults: the outer body is the wall, inner bodies are obstacles."""
    n = int(summary.get("regions") or 1)
    if n > 12 or ring_ports:
        return []
    ids = [f"r{k}" for k in range(1, n + 1)]
    if purpose == "conjugate_heat_transfer":
        if n == 1:
            return [{"id": "r1", "role": "solid", "reason": "one body: no fluid to couple (see region_purpose_mismatch)"}]
        return [{"id": rid, "role": "fluid" if k > 0 else "solid",
                 "reason": "inner body read as the fluid, outer as the solid" if n == 2 else "heuristic: r1 solid, the rest fluid"}
                for k, rid in enumerate(ids)]
    if purpose == "internal_cfd" and n > 1:
        return [{"id": rid, "role": "fluid", "reason": "disconnected body; region_purpose_mismatch carries the question"} for rid in ids]
    return []


DEFAULTS = {
    "short_stub": ["extend to 5D", "declare as inlet", "accept as is"],
    "undeclared_opening": ["closed end", "inlet", "outlet"],
    "region_purpose_mismatch": ["send to repair", "intentional (CHT)", "abort"],
    "not_watertight": ["send to repair", "rims are ports, cap them", "abort"],
    "surface_holes": ["send to repair", "one of these is a port", "abort"],
    "cell_cap": ["drop fidelity", "raise cap", "abort"],
    "declared_port_unmatched": ["pick from measured list", "correct declaration"],
    "ambiguous_openings": ["name the ports now"],
    "unit_implausible": ["confirm declared unit", "override unit"],
    "rotor_topology": ["add rotating zone", "run stationary"],
    "solid_wall_representation": ["upload the fluid body", "extract the bore in CAD", "abort"],
    "tiny_port": ["closed for this run", "open port", "defeature it"],
    "nested_bodies": ["inner body is the fluid", "change purpose to CHT", "remove the cavity"],
    "solid_fluid_pair": ["inner body is the fluid", "outer body is the fluid", "close the gap in CAD"],
    "no_shared_interface": ["fix in CAD", "change purpose", "abort"],
    "unshared_interface": ["glue the bodies in CAD", "change purpose", "abort"],
    "role_assumed": ["keep the assigned direction", "reverse it"],
    "non_manifold_surface": ["send to repair", "accept as is"],
}


def _question_effect(kind: str) -> str:
    """What answering the question does (schema 3, R8): the kind's effect; a unit is a boundary-condition call."""
    if kind in ("unit_unknown", "unit_implausible"):
        return "changes_bc"
    return KIND_EFFECT.get(kind, "changes_mesh")


def _short_catalog_risks(risks: list[dict]) -> list[dict]:
    """Schema 3 (R34, docs/plan_v3_rules.md section 14): a catalog risk in a plan is its id, the decision the
    analyst took and the reason when that decision overrides the catalog's. Kind, severity, measurement,
    consequence, recommendation, requires_user_decision, mechanism, effect and target are filled by
    `grounding._fill_catalog_risks` from the catalog run the checker makes anyway, so the stand-in writes what a
    model should write and no more. What the analyst adds to a catalog entry is kept: the decision, its reason,
    the question it named, and the `derived` values and `refuted_by` R4 asks it to put there rather than raise a
    second risk. A risk of the policy's own (it adds none today) passes through whole."""
    out = []
    for r in risks:
        if r.get("detected_by", "catalog") != "catalog":
            out.append(r)
            continue
        short = {"id": r["id"], "user_decision": r.get("user_decision", "pending")}
        for key in ("derivation", "derived", "refuted_by", "question_id"):
            if r.get(key):
                short[key] = r[key]
        out.append(short)
    return out


def build_plan(summary: dict, openings: list[dict], axes: dict, roles: dict[str, str], risks: list[dict],
               compare: dict | None = None, schema_version: int = PLAN_SCHEMA_VERSION) -> dict:
    """The stand-in's plan. `schema_version` 2 writes the P4.1 plan unchanged; 3 (the default) adds the schema 3
    obligations (docs/plan_v3_rules.md) and keeps every sphere under the builder's wall cell and off a wall
    shell's metal (R7). `compare` is the compare_roles result the counterfactual cites."""
    v3 = schema_version >= 3
    purpose, fidelity = summary["purpose"], summary["fidelity"]
    tier_cells = _tier_cells(summary, fidelity)
    base = _n(summary["_base_size"])
    hs = base / 2 ** LEVELS[fidelity]
    L = max(summary["bbox_extent"])
    unit = _unit_call(summary, risks)
    role_assumed = any(r["kind"] == "role_assumed" for r in risks)
    ring_ports = any(o.get("kind") == "ring" and roles.get(o["id"]) in ("inlet", "outlet", "opening_unknown") for o in openings)
    wall_shell = ring_ports or any(r["kind"] in WALL_SHELL_KINDS for r in risks)

    asked_roles = {r.get("measurement", {}).get("opening_id") for r in risks
                   if r.get("requires_user_decision") and r["kind"] in ("undeclared_opening", "role_assumed", "declared_port_unmatched", "tiny_port")}
    patches = []
    for o in openings:
        role = roles.get(o["id"], "wall")
        conf = 0.9 if role == "wall" else (0.3 if role == "opening_unknown" else 0.7)
        if (role in ("inlet", "outlet") and role_assumed) or o["id"] in asked_roles:
            conf = 0.5
        # packet v2: a patch carries no measured number; the checker fills area, centroid, normal and D_h from the facts
        patches.append({
            "id": o["id"], "name": f"{role}_{o['id']}", "role": role, "confidence": conf,
            "evidence": [f"{o['shape']} {o['kind']} D_h {o['hydraulic_diameter']:.4g}, tubularity {o['tubularity']:.2f}",
                         f"stub {o['stub']['length_over_diameter']:.2f} D" if o.get("stub") else "no stub measured"],
        })
    inlets = [p["id"] for p in patches if p["role"] == "inlet"]
    outlets = [p["id"] for p in patches if p["role"] == "outlet"]

    axis = None
    sign = 0
    flow_conf = 0.0
    evidence = []
    if purpose == "external_cfd" and axes:
        axis = axes["principal"][0]
        blunt = int(axes.get("blunt_end_sign", 0))
        sign = -blunt
        flow_conf = min(0.9, 0.4 + float(axes.get("blunt_end_confidence", 0.0))) if blunt else 0.3
        evidence.append(f"principal axis 0, slenderness {axes['slenderness']:.2f}")
        evidence.append("blunt end identifies the leading edge" if blunt else "no blunt end distinguishable")
        patches.append({"id": "farfield", "name": "farfield", "role": "farfield", "confidence": 1.0,
                        "evidence": ["domain box to be created by the builder"]})
        # the body itself is the wall patch, whether or not it has planar faces of its own
        patches.append({"id": "body", "name": "body", "role": "wall", "confidence": 1.0,
                        "evidence": ["every surface of the body is a no-slip wall"]})
    elif inlets:
        o = next(o for o in openings if o["id"] == inlets[0])
        inward = [-c for c in o["normal"]]
        axis, label = _snap_axis(inward, axes)
        sign = 1 if sum(inward[i] * axis[i] for i in range(3)) >= 0 else -1
        if outlets:
            # the sign is what makes axis point from the inlets toward the outlets
            by_id = {x["id"]: x for x in openings}
            d = [sum(by_id[k]["centroid"][i] for k in outlets) / len(outlets) - sum(by_id[k]["centroid"][i] for k in inlets) / len(inlets)
                 for i in range(3)]
            sign = 1 if sum(d[i] * axis[i] for i in range(3)) >= 0 else -1
        flow_conf = 0.5 if role_assumed else 0.7
        evidence.append(f"{label} closest to the inward normal of inlet {inlets[0]}")

    # schema 3 (R7): every sphere finer than the builder's wall cell (the inlet bore over 24): the inlet's scale
    # over 32 is a power of two of a measured length and always under it
    wall_cap = _wall_cell_cap(openings, roles, inlets, wall_shell) if v3 else None
    regions = []
    for r in risks:
        m = r.get("measurement", {})
        if r["kind"] == "thin_feature" and m.get("centroid"):
            if v3 and wall_shell:
                continue  # the thin metal is the wall the cavity is carved from: no region on it (R7)
            regions.append({"where": f"thin cluster {m.get('cluster_id')}", "kind": "sphere",
                            "target_size": _capped(_n(m["thickness_min"]) / 4, wall_cap),
                            "reason": "at least three cells across the thinnest feature",
                            "anchor": m["centroid"], "radius": _n(m["thickness_min"]) * 20})
        if r["kind"] == "short_stub" and m.get("opening_id"):
            o = next(x for x in openings if x["id"] == m["opening_id"])
            regions.append({"where": f"outlet {o['id']} exit region", "kind": "sphere",
                            "target_size": _capped(min(_n(o["hydraulic_diameter"]) / 8, base / 8), wall_cap),
                            "reason": "resolve recirculation approaching a short outlet: bore/8, never coarser than base/8",
                            "anchor": o["centroid"], "radius": _n(o["hydraulic_diameter"]) * 2})
        if r["kind"] == "knife_edge":
            regions.append({"where": "knife edges", "kind": "feature_edges", "target_size": hs / 2,
                            "reason": "hold the trailing edge as a feature line"})

    layers = []
    ports = [p for p in patches if p["role"] in {"inlet", "outlet"}]
    smallest = None
    if purpose in {"internal_cfd", "conjugate_heat_transfer"} and ports:
        patches.append({"id": "walls", "name": "walls", "role": "wall", "confidence": 1.0,
                        "evidence": ["every surface that is not a declared port"]})
        port_ids = {p["id"] for p in ports}
        smallest = min(_n(o["hydraulic_diameter"]) for o in openings if o["id"] in port_ids)
        layers.append({"patch_id": "walls", "n_layers": LAYERS[fidelity], "first_cell_height": smallest / 1024,
                       "reason": "wall layers; first cell from the smallest port bore, placeholder for y+ ~30 at Re ~1e5"})
    if purpose == "external_cfd":
        wall_ids = [p["id"] for p in patches if p["role"] == "wall"]
        for pid in wall_ids[:4]:
            layers.append({"patch_id": pid, "n_layers": LAYERS[fidelity], "first_cell_height": _n(L) / 4096,
                           "reason": "body layers sized from body length, placeholder for y+ ~30"})

    extents = {}
    extensions = []
    if purpose == "external_cfd":
        extents = {"upstream": _n(L) * 5, "downstream": _n(L) * 15, "lateral": _n(L) * 5, "vertical": _n(L) * 5}
    for r in risks:
        if r["kind"] == "short_stub" and roles.get(r["measurement"]["opening_id"]) == "outlet":
            m = r["measurement"]
            extensions.append({"patch_id": m["opening_id"], "length": _n(m["hydraulic_diameter"]) * 5,
                               "reason": "bring the outlet run to 5 diameters"})
    preserve = ["knife edges"] if summary.get("knife_edges") else []

    if v3:
        _settle_false_alarms(summary, risks, roles, unit)
    questions = []
    # one question per decision kind: the same answer settles it on every opening it names (also_settles)
    grouped: dict[str, list[dict]] = {}
    for r in risks:
        if r.get("requires_user_decision") and r.get("user_decision", "pending") == "pending":
            grouped.setdefault(r["kind"], []).append(r)
    for kind, rs in grouped.items():
        r = rs[0]
        if kind == "unit_unknown":
            opts = list(summary.get("unit_plausible") or ["mm", "m"])
            default = unit["assumed"] if unit["assumed"] in opts else opts[0]
        else:
            opts = DEFAULTS.get(kind, ["continue", "fix", "abort"])
            default = None if any(x["severity"] == "blocking" for x in rs) else opts[0]
        text = f"{r['consequence']} {r['recommendation']}"
        others = list(rs[1:])
        if others:
            named = [x["measurement"].get("opening_id") or x["measurement"].get("name") or x["id"] for x in others]
            text += " The same answer applies to " + ", ".join(str(n) for n in named) + "."
        q = {"id": f"q{len(questions) + 1}", "text": text, "options": opts, "relates_to": r["id"],
             "also_settles": [x["id"] for x in others], "default": default}
        if v3:
            q["effect"] = _question_effect(kind)
        questions.append(q)

    n_unknown = sum(1 for v in roles.values() if v == "opening_unknown")
    kind = _identity(summary, purpose, len(inlets), len(outlets), n_unknown)
    user_summary = _user_summary(kind, inlets, outlets, n_unknown, questions)
    if PROCEED.search(summary.get("user_brief") or ""):
        # the brief asks for defaults: every non-blocking decision is taken (continue), its question keeps the default
        taken = []
        for r in risks:
            if r.get("requires_user_decision") and r.get("user_decision", "pending") == "pending" and r["severity"] != "blocking":
                r["user_decision"] = "continue"
                r["derivation"] = "the brief asks to proceed without questions: default taken, the user can overturn it"
                taken.append(r["kind"])
        user_summary = "Proceeding with: " + (", ".join(f"{k} (default)" for k in taken) or "no open decisions") + ". " + user_summary
    notes = [f"{len(risks)} catalog risks; {len(questions)} need the user"]
    flow = {"axis": axis, "direction_sign": sign, "inlet_ids": inlets, "outlet_ids": outlets,
            "confidence": flow_conf, "evidence": evidence}
    plan = {
        "schema_version": schema_version, "facts_sha256": summary_sha(summary), "purpose": purpose,
        "object": kind,
        "unit": unit,
        "patches": patches,
        "flow": flow,
        "risks": _short_catalog_risks(risks) if v3 else risks,
        "mesh_plan": {"fidelity": fidelity, "base_size": base, "cell_estimate": tier_cells,
                      "refinement_regions": regions, "layer_targets": layers,
                      "preserve_features": preserve,
                      "required_extents": extents, "port_extensions": extensions,
                      "regions": _region_roles(summary, purpose, ring_ports=ring_ports),
                      "assumptions": ["uniform inlet profile", "first cell is a placeholder for y+ ~30 at Re ~1e5"] if ports else [],
                      "notes": notes},
        "questions": questions,
        "analysis": _analysis(kind, summary, roles, risks, cap=ANALYSIS_MAX_CHARS if v3 else None),
        "brief_conflicts": _brief_conflicts(summary, inlets, outlets),
        "summary_for_user": user_summary,
        "summary_for_builder": (_builder_summary_v3(kind, patches, regions, layers, extents, extensions, fidelity, tier_cells, unit) if v3
                                else _builder_summary(kind, patches, regions, layers, extents, extensions, fidelity, tier_cells, unit)),
    }
    if not v3:
        return plan
    # --- schema 3 -----------------------------------------------------------------------------------------------
    hyps, identity = _hypotheses(kind, summary, openings, axes, purpose, inlets, outlets, n_unknown)
    plan["object"] = {**kind, "identity": identity}
    plan["identity_hypotheses"] = hyps
    plan["agent_risks_considered"] = _considered(summary, openings, axes, roles, risks, purpose, patches)
    if compare is not None or direction_in_doubt(summary, roles, risks):
        flow["counterfactual"] = _counterfactual(compare, inlets, outlets, openings)
    planar_floor = purpose == "external_cfd" and any(o.get("on_bbox_face") and o.get("bbox_side") == "z_min" for o in openings)
    if planar_floor:
        plan["mesh_plan"]["notes"].append("ground contact: a planar face lies on the bbox floor (z_min); treated as the ground plane")
    plan["second_look"] = _second_look(summary, openings, roles, risks, purpose, flow, plan["mesh_plan"], patches, wall_shell,
                                       smallest, planar_floor)
    return plan


def _brief_unit_word(brief: str, summary: dict) -> str | None:
    """The one unit every dimension in the brief is written in, when it is plausible for the purpose (the
    checker's `_brief_unit` reading, from the summary's plausible list)."""
    units = set()
    for m in R9_UNIT_IN_BRIEF.finditer(brief or ""):
        word = m.group(1).lower()
        unit = _UNIT_WORDS.get(word) or _UNIT_WORDS.get(word.rstrip("s")) or (
            "mm" if word.startswith("millimet") else "m" if word.startswith("met") else "in" if word.startswith("inch") else
            "ft" if word in ("feet", "foot") else None)
        if unit:
            units.add(unit)
    if len(units) != 1:
        return None
    unit = next(iter(units))
    plausible = summary.get("unit_plausible") or []
    return unit if (not plausible or unit in plausible) else None


def _settle_false_alarms(summary: dict, risks: list[dict], roles: dict[str, str], unit: dict) -> None:
    """The checker's R9 patterns, applied before the questions are built so none is asked: a short run under a
    brief that declines a geometry change, a unit under a brief that writes its dimensions with one plausible
    unit (the unit call then follows the brief), a role decision on openings the declaration assigned. P4.4: a
    brief that states the outlet's boundary condition settles none of these, so the stand-in now asks the
    short-run question the corpus briefs never answer, exactly as the checker leaves it standing."""
    brief = summary.get("user_brief") or ""
    declared = summary.get("declared_ports") or []
    for r in risks:
        if not (r.get("requires_user_decision") and r.get("user_decision", "pending") == "pending"):
            continue
        kind, m = r["kind"], r.get("measurement") or {}
        if kind in STUB_QUESTION_KINDS:
            hit = R9_SETTLES["short_stub"].search(brief)
            if hit:
                r["user_decision"] = "continue"
                r["derivation"] = f"brief: {hit.group(0)!r} settles whether the geometry may change; no question (checker R9)"
        elif kind in ("unit_unknown", "unit_implausible"):
            hit = R9_UNIT_IN_BRIEF.search(brief)
            if hit is None:
                continue
            if kind == "unit_unknown":
                # the checker's reading (grounding._unit_settled_by_brief): a brief dimension equal to a measured
                # length settles the unit exactly (the catalog's settled_by_brief), else the brief's one unit when
                # it is plausible for this size; an implausible brief unit is a conflict the question is for
                u = unit["assumed"] if m.get("settled_by_brief") else _brief_unit_word(brief, summary)
                if not u:
                    continue
                r["user_decision"] = "continue"
                r["derivation"] = f"brief: {hit.group(0)!r} settles the unit ({u}); no question (checker R9)"
                unit.update({"declared": None, "assumed": u, "basis": "brief"})
            else:
                r["user_decision"] = "continue"
                r["derivation"] = f"brief: {hit.group(0)!r} settles the unit beside the declared one; no question (checker R9)"
        elif kind in R9_ROLE_KINDS and declared:
            # declared_port_unmatched is not here (P4.4): that risk fires because no measured opening matches the
            # declaration, so the declaration cannot answer it
            ids = {m.get("opening_id")} | set(m.get("inlet_ids") or []) | set(m.get("outlet_ids") or [])
            ids.discard(None)
            if ids and all(roles.get(i) in ("inlet", "outlet") for i in ids):
                phrase = ", ".join(f"declared port at {i}" for i in sorted(ids))
                r["user_decision"] = "continue"
                r["derivation"] = f"brief: {phrase!r} settles the role; no question (checker R9)"


def _capped(target: float, cap: float | None) -> float:
    return target if cap is None else min(target, cap)


def _wall_cell_cap(openings: list[dict], roles: dict[str, str], inlets: list[str], wall_shell: bool) -> float | None:
    """A sphere target that is under the builder's wall cell whatever bore the builder frame reads: the inlet's
    scale over 32 (a measured length times a power of two), a ring's bore over 64 (the frame reads the bore
    minus an inner body's cap). The inlet is the plan's first inlet, else the widest port, as the frame takes it."""
    by_id = {o["id"]: o for o in openings}
    cands = [by_id[i] for i in inlets if i in by_id]
    if not cands:
        cands = [o for o in openings if roles.get(o["id"]) in ("outlet", "opening_unknown")] or \
                [o for o in openings if o.get("kind") in ("cap", "ring")]
    if not cands:
        return None
    o = max(cands, key=lambda x: x.get("area") or 0.0)
    if o.get("kind") == "ring" and o.get("bore_diameter"):
        return _n(o["bore_diameter"]) / 64
    d_eq = 2.0 * math.sqrt(max(_n(o.get("area") or 0.0), 0.0) / math.pi)
    scale = min(x for x in (_n(o["hydraulic_diameter"]), d_eq) if x > 0) if (o["hydraulic_diameter"] > 0 or d_eq > 0) else None
    return None if scale is None else scale / 32


def summary_sha(summary: dict) -> str:
    return summary.get("facts_sha256", "")


def _identity(summary: dict, purpose: str, n_in: int, n_out: int, n_unknown: int) -> dict:
    ev = [f"{len(summary['openings'])} planar ends", f"{summary['regions']} region(s)",
          f"slenderness {summary['slenderness']:.2f}", f"symmetry planes {summary['symmetry_planes']}"]
    if purpose in {"internal_cfd", "conjugate_heat_transfer"}:
        total = n_in + n_out + n_unknown
        if total >= 3:
            t = "branching manifold (one inlet, several outlets)" if n_out >= 2 else "manifold or header with ports to confirm"
        elif total == 2:
            t = "single duct or pipe"
        else:
            t = "internal volume with unclear ports"
        conf = 0.6 if n_unknown == 0 else 0.4
        return {"type": t, "simulation_intent": "internal flow: inlet to outlet(s), wall-bounded", "confidence": conf, "evidence": ev}
    if purpose == "external_cfd":
        s = summary["slenderness"]
        t = "slender body (airfoil, blade or fuselage-like)" if s > 2.5 else "bluff or compact body"
        return {"type": t, "simulation_intent": "external flow around the body in a far-field domain", "confidence": 0.5, "evidence": ev}
    return {"type": "solid part", "simulation_intent": purpose, "confidence": 0.5, "evidence": ev}


def _hypotheses(kind: dict, summary: dict, openings: list[dict], axes: dict, purpose: str,
                inlets: list[str], outlets: list[str], n_unknown: int) -> tuple[list[dict], dict]:
    """Two first-turn hypotheses from the family signature, each with a refuting test the stand-in evaluates from
    the facts it holds, and the identity verdict with tests_run citing ledger numbers (schema 3, R2)."""
    ports = [o for o in openings if o.get("classification", "port_candidate") == "port_candidate"] or \
            [o for o in openings if o.get("kind") == "ring" and o.get("bore_diameter")]
    bores = sorted((_n(o["hydraulic_diameter"]) for o in ports if o["hydraulic_diameter"] > 0), reverse=True)
    n_ports = len(inlets) + len(outlets) + n_unknown
    slender = _n(summary["slenderness"])
    tests: list[dict] = []
    if purpose in {"internal_cfd", "conjugate_heat_transfer"}:
        if n_ports >= 3:
            alt, alt_test = "tee or cross junction of equal bores", {
                "tool": "list_openings", "args": {}, "would_refute_if": "the bores differ (a header feeds smaller branches)"}
            alt_refuted = len(bores) >= 2 and bores[-1] < SAME_BORE * bores[0]
            primary_test = {"tool": "list_openings", "args": {}, "would_refute_if": "fewer than three port candidates"}
            tests.append({"tool": "list_openings", "result_number": bores[0] if bores else _n(len(openings)), "verdict": "supports"})
        elif n_ports == 2:
            alt, alt_test = "reducer or diffuser", {"tool": "taper", "args": {"a": ports[0]["id"] if ports else "o1", "b": ports[-1]["id"] if ports else "o2"},
                                                     "would_refute_if": "the two bores agree (area ratio near one)"}
            alt_refuted = len(bores) >= 2 and bores[-1] >= SAME_BORE * bores[0]
            primary_test = {"tool": "list_openings", "args": {}, "would_refute_if": "a third port candidate, or a ring instead of a cap"}
            tests.append({"tool": "list_openings", "result_number": bores[0] if bores else _n(len(openings)), "verdict": "supports"})
        else:
            alt, alt_test = "wall shell to carve (ring ports)", {"tool": "list_openings", "args": {},
                                                                  "would_refute_if": "caps of class port_candidate present"}
            alt_refuted = any(o.get("classification") == "port_candidate" for o in openings)
            primary_test = {"tool": "list_openings", "args": {}, "would_refute_if": "two or more port candidates with stubs"}
            first = _n(openings[0]["hydraulic_diameter"]) if openings else _body_number(summary)
            tests.append({"tool": "list_openings", "result_number": first, "verdict": "supports"})
    elif purpose == "external_cfd":
        slender_type = kind["type"].startswith("slender")
        alt = "bluff or compact body" if slender_type else "slender body (airfoil, blade or fuselage-like)"
        alt_test = {"tool": "get_axes", "args": {}, "would_refute_if": "slenderness over 2.5" if not slender_type else "slenderness under 2.5"}
        alt_refuted = True
        primary_test = {"tool": "get_axes", "args": {}, "would_refute_if": "slenderness under 2.5" if slender_type else "slenderness over 2.5"}
        tests.append({"tool": "get_axes", "result_number": slender, "verdict": "supports"})
    else:
        alt, alt_test = "thin-walled shell", {"tool": "get_features", "args": {}, "would_refute_if": "thickness_min a large fraction of the extent"}
        t_min = summary.get("thickness_min")
        alt_refuted = bool(t_min) and _n(t_min) > 0.1 * max(summary["bbox_extent"])
        primary_test = {"tool": "get_facts_summary", "args": {}, "would_refute_if": "openings of class port_candidate with stubs (a fluid volume)"}
        tests.append({"tool": "get_facts_summary", "result_number": _body_number(summary), "verdict": "supports"})
    hyps = [{"type": kind["type"], "prior": round(kind["confidence"], 2), "refuting_test": primary_test},
            {"type": alt, "prior": round(1.0 - kind["confidence"], 2), "refuting_test": alt_test}]
    if alt_refuted:
        number = bores[-1] if bores and purpose != "external_cfd" else (slender if purpose == "external_cfd" else _n(summary.get("thickness_min") or _body_number(summary)))
        tests.append({"tool": alt_test["tool"], "result_number": number, "verdict": "refutes"})
    identity = {"type": kind["type"], "confidence": kind["confidence"], "tests_run": tests, "refuted": [alt] if alt_refuted else []}
    return hyps, identity


def _considered(summary: dict, openings: list[dict], axes: dict, roles: dict[str, str], risks: list[dict], purpose: str,
                patches: list[dict]) -> list[dict]:
    """Two mechanisms considered and dismissed, each with the ledger number that dismissed it (schema 3, R5)."""
    ports = [o for o in openings if roles.get(o["id"]) in ("inlet", "outlet", "opening_unknown")]
    bores = sorted((_n(o["hydraulic_diameter"]) for o in ports if o["hydraulic_diameter"] > 0), reverse=True)
    kinds = {r["kind"] for r in risks}
    out: list[dict] = []
    if purpose in {"internal_cfd", "conjugate_heat_transfer"} and bores:
        closed = [p["id"] for p in patches if p["role"] == "closed_end"]
        stubs = {o["id"]: _n(o["stub"]["length_over_diameter"]) for o in ports if o.get("stub")}
        out.append({"mechanism": "dead_leg_stagnation",
                    "measurement": {"port_hydraulic_diameter_min": bores[-1], **({"stub_over_d_" + k: v for k, v in list(stubs.items())[:2]})},
                    "why_not": ("no closed end among the openings" if not closed
                                else f"closed ends {closed}: the stand-in derives no dead leg (derived_geometry dead_leg is the model's)")})
        out.append({"mechanism": "separation",
                    "measurement": {"port_hydraulic_diameter_max": bores[0], "port_hydraulic_diameter_min": bores[-1]},
                    "why_not": ("the catalog's diffuser_angle carries the taper" if "diffuser_angle" in kinds
                                else "no taper measured by the catalog between the ports; bores are cited, no half angle derived")})
    elif purpose == "external_cfd":
        L = max(summary["bbox_extent"])
        out.append({"mechanism": "wake", "measurement": {"body_length": _n(L), "slenderness": _n(summary["slenderness"])},
                    "why_not": "the far field's downstream extent carries the wake; no wake box written by the stand-in"})
        floor = [o["id"] for o in openings if o.get("on_bbox_face") and o.get("bbox_side") == "z_min"]
        out.append({"mechanism": "ground_effect", "measurement": {"bbox_extent_min": _n(min(summary["bbox_extent"]))},
                    "why_not": ("no planar face on the bbox floor" if not floor else f"planar face {floor} on the bbox floor noted as ground contact")})
    else:
        out.append({"mechanism": "wake", "measurement": {"body_number": _body_number(summary)}, "why_not": "no flow is posed"})
        out.append({"mechanism": "separation", "measurement": {"total_surface_area": _n(summary["total_surface_area"])}, "why_not": "no flow is posed"})
    if len(out) < 2 and openings:
        d = _n(openings[0]["hydraulic_diameter"])
        out.append({"mechanism": "jet_impingement", "measurement": {"hydraulic_diameter": d}, "why_not": "no inlet assigned; nothing impinges"})
        out.append({"mechanism": "recirculation_at_outlet", "measurement": {"hydraulic_diameter": d}, "why_not": "no outlet assigned"})
    return out[:2] if len(out) >= 2 else out


def _counterfactual(compare: dict | None, inlets: list[str], outlets: list[str], openings: list[dict]) -> dict:
    """flow.counterfactual (schema 3, R11): the swap in words and what breaks, citing the compare_roles numbers
    and derivation id; without a compare_roles result (build_plan called outside the policy) it says so and cites
    the measured bore the swap moves the inlet to."""
    swap = (f"{', '.join(outlets)} as the inlet and {', '.join(inlets)} as the outlet" if inlets and outlets
            else f"{', '.join(inlets)} as an outlet (no inlet left)" if inlets else "no inlet or outlet to swap")
    if compare is None:
        by_id = {o["id"]: o for o in openings}
        moved = next((by_id[i] for i in outlets + inlets if i in by_id), None)
        bore = f"{moved['hydraulic_diameter']:.6g}" if moved else "none"
        return {"swap": swap, "what_breaks": (f"stand-in without a compare_roles result: the swap moves the inlet to a port of "
                                              f"hydraulic diameter {bore}; the catalog's risks under it were not compared")}
    did = compare.get("derivation_id", "")
    return {"swap": swap,
            "what_breaks": (f"under the swap the catalog carries {compare.get('high_risks_b')} high risk(s) against "
                            f"{compare.get('high_risks_a')} (severity sum {compare.get('severity_sum_b')} against "
                            f"{compare.get('severity_sum_a')}; fewer high risks: {compare.get('fewer_high_risks')}; {did})")}


def _tilt_deg(normal: list[float]) -> float:
    m = max(abs(float(c)) for c in normal)
    return 90.0 if m <= 0 else math.degrees(math.acos(min(1.0, m)))


def _min_dimension(o: dict) -> float:
    if o.get("kind") == "ring" and o.get("bore_diameter"):
        return _n(o["bore_diameter"])
    w, h = _n(o.get("width") or 0.0), _n(o.get("height") or 0.0)
    if o.get("shape") == "rectangle" and w > 0 and h > 0:
        return min(w, h)
    if w > 0 and h > 0:
        return min(w, h, _n(o["hydraulic_diameter"]) or max(w, h))
    return _n(o["hydraulic_diameter"] or o.get("equivalent_diameter") or 0.0)


def _second_look(summary: dict, openings: list[dict], roles: dict[str, str], risks: list[dict], purpose: str, flow: dict,
                 mp: dict, patches: list[dict], wall_shell: bool, smallest: float | None, planar_floor: bool) -> list[dict]:
    """The second look computed from the tool results the way the checker recomputes it (R10). A line the stand-in
    cannot evaluate (the seed's ray parity, a coincident interface's kind, a tilted mouth's warning on a carve) is
    left out rather than guessed; the words of each line are the checker's matching words."""
    lines: list[dict] = []
    stub_ok = STUB_OK_OVER_D
    if purpose in {"internal_cfd", "conjugate_heat_transfer"}:
        ports = [o for o in openings if roles.get(o["id"]) in ("inlet", "outlet", "opening_unknown")]
        tilts = {o["id"]: _tilt_deg(o["normal"]) for o in ports}
        tilted = [i for i, t in tilts.items() if t >= TILTED_MOUTH_DEG]
        if not (wall_shell and tilted):
            lines.append({"item": "every port mouth grid-aligned or carrying a tilted-mouth warning", "ok": True,
                          "number": round(max(tilts.values(), default=0.0), 4),
                          "note": "no mouth tilted off its grid axis" if not tilted else f"tilted mouths {tilted} on a fluid body: no carve, no warning needed"})
        decided = {r["measurement"].get("opening_id") for r in risks if r["kind"] == "short_stub" and r.get("user_decision", "pending") != "pending"}
        extended = {e["patch_id"] for e in mp.get("port_extensions") or []}
        short, min_run = [], None
        for oid in flow["outlet_ids"]:
            o = next((x for x in openings if x["id"] == oid), None)
            if o is None or not o.get("stub"):
                continue
            ld = _n(o["stub"]["length_over_diameter"])
            min_run = ld if min_run is None else min(min_run, ld)
            if ld < stub_ok and oid not in decided and oid not in extended:
                short.append(oid)
        lines.append({"item": f"every outlet run at least {stub_ok:g} D or a decided short stub", "ok": not short,
                      "number": round(min_run, 3) if min_run is not None else None,
                      "note": "every short outlet extended or decided" if not short else f"undecided short outlet runs: {short}"})
        cells = _smallest_port_cells(openings, roles, flow["inlet_ids"], wall_shell)
        if cells is not None and (cells >= 1.3 * PORT_CELLS_MIN or cells <= 0.7 * PORT_CELLS_MIN):
            lines.append({"item": f"smallest port at least {PORT_CELLS_MIN:g} builder cells across at cells_across {BUILDER_CELLS_ACROSS}",
                          "ok": cells >= PORT_CELLS_MIN, "number": round(cells, 3),
                          "note": f"about {cells:.1f} builder cells across the smallest port (stand-in estimate)"})
        on_metal = [r["where"] for r in mp.get("refinement_regions") or [] if wall_shell and (ON_THE_METAL.search(r.get("where") or "") or ON_THE_METAL.search(r.get("reason") or ""))]
        lines.append({"item": "no refinement region on the metal", "ok": not on_metal, "number": float(len(on_metal)),
                      "note": "wall shell: no region on the thin skin" if wall_shell else "a fluid body: no metal to refine"})
        if flow.get("axis") is not None:
            lines.append({"item": "flow axis a principal axis or a unit vector", "ok": True, "number": None,
                          "note": "a measured principal axis or an axis-aligned direction by construction"})
        layers = [lt for lt in mp.get("layer_targets") or [] if lt["n_layers"] > 0]
        if layers and smallest:
            lines.append({"item": "first cell in band and equal to its reason", "ok": True,
                          "number": round(layers[0]["first_cell_height"] / smallest, 6),
                          "note": "the smallest port bore over 1024; the reason states the sizing rule, no number"})
        closed = [p["id"] for p in patches if p["role"] == "closed_end"]
        lines.append({"item": "every closed end explained by the brief or asked once", "ok": True, "number": float(len(closed)),
                      "note": "no closed end assigned" if not closed else f"closed ends {closed} from the declaration"})
    elif purpose == "external_cfd":
        ext = mp.get("required_extents") or {}
        lines.append({"item": "the four extents present as standard multiples of the body length", "ok": all(k in ext for k in ("upstream", "downstream", "lateral", "vertical")),
                      "number": float(len(ext)), "note": "5, 15, 5 and 5 body lengths"})
        lines.append({"item": "ground contact stated when the bbox minimum z face is planar", "ok": True, "number": None,
                      "note": "a planar face on the bbox floor, noted as ground contact" if planar_floor else "no planar face on the bbox floor"})
        lines.append({"item": "wake box finer than base size or absent", "ok": True, "number": None, "note": "no wake box written"})
        knives = int(summary.get("knife_edges") or 0)
        lines.append({"item": "knife edges preserved", "ok": knives == 0 or bool(mp.get("preserve_features")), "number": float(knives),
                      "note": "no knife edge" if knives == 0 else "knife edges named in preserve_features"})
    elif purpose == "structural":
        lines.append({"item": "no flow fields", "ok": flow.get("axis") is None and not flow["inlet_ids"] and not flow["outlet_ids"], "number": None, "note": ""})
        lines.append({"item": "no layers", "ok": not any(lt["n_layers"] > 0 for lt in mp.get("layer_targets") or []), "number": None, "note": ""})
    if purpose == "conjugate_heat_transfer":
        fluid = [r["id"] for r in mp.get("regions") or [] if r["role"] == "fluid"]
        by_region = {o["id"]: o.get("region_id") for o in openings}
        without = [rid for rid in fluid if not any(by_region.get(pid) == rid and roles.get(pid) in ("inlet", "outlet") for pid in roles)]
        lines.append({"item": "every fluid region has ports or is declared sealed", "ok": not without, "number": float(len(fluid)),
                      "note": "every fluid region has a port" if not without else f"fluid region(s) {without} without a port"})
    return lines


def _smallest_port_cells(openings: list[dict], roles: dict[str, str], inlets: list[str], wall_shell: bool) -> float | None:
    """The stand-in's reading of the builder frame: the wall cell is the inlet's equivalent diameter over 24 (the
    plan's first inlet, else the widest port), and the smallest port's min in-plane dimension is divided by it."""
    by_id = {o["id"]: o for o in openings}
    if wall_shell or any(o.get("kind") == "ring" for o in openings):
        # a ring's port area depends on the representation (its bore, or the ring face on an annular passage):
        # the stand-in cannot read the frame's bore, so it writes no line
        return None
    ports = [o for o in openings if o.get("classification") == "port_candidate" and o.get("kind") == "cap"]
    if not ports:
        return None
    inlet = next((by_id[i] for i in inlets if i in by_id), None) or max(ports, key=lambda o: o.get("area") or 0.0)
    bore = 2.0 * math.sqrt(max(_n(inlet.get("area") or 0.0), 0.0) / math.pi)
    if bore <= 0:
        return None
    wall_cell = bore / BUILDER_CELLS_ACROSS
    md = min(_min_dimension(o) for o in ports)
    return md / wall_cell if md > 0 else None


def _user_summary(kind: dict, inlets, outlets, n_unknown, questions) -> str:
    s = f"I read this as a {kind['type']}. "
    if inlets:
        s += f"Inlet {', '.join(inlets)}; outlets {', '.join(outlets) or 'none yet'}. "
    if n_unknown:
        s += f"{n_unknown} opening(s) I cannot assign without you. "
    s += f"{len(questions)} thing(s) need your decision before meshing."
    return s


def _builder_summary(kind, patches, regions, layers, extents, extensions, fidelity, cells, unit: dict) -> str:
    roles = ", ".join(f"{p['id']}={p['role']}" for p in patches)
    basis = {"file": "declared by the file", "brief": "pinned by a dimension in the brief", "user": "stated by the user",
             "guess": "assumed, unconfirmed; every size below is in file units"}[unit["basis"]]
    ext = "; ".join(f"extend {e['patch_id']} by {e['length']:.4g}" for e in extensions) or "none"
    return (f"Unit: {unit['assumed']} ({basis}). {kind['type']}; {kind['simulation_intent']}. "
            f"Patches: {roles}. Fidelity {fidelity}, about {cells:,} cells. "
            f"{len(regions)} refinement region(s), {len(layers)} layer target(s), extents {extents or 'none'}, extensions {ext}.")


def _builder_summary_v3(kind, patches, regions, layers, extents, extensions, fidelity, cells, unit: dict) -> str:
    """At most BUILDER_PROSE_MAX_CHARS characters of prose after the unit (the strategy header is generated by the
    handover): the unit and every port by id first, the rest only while it fits."""
    basis = {"file": "declared by the file", "brief": "pinned by the brief", "user": "stated by the user",
             "guess": "assumed, unconfirmed; sizes in file units"}[unit["basis"]]
    ins = " ".join(p["id"] for p in patches if p["role"] == "inlet")
    outs = " ".join(p["id"] for p in patches if p["role"] == "outlet")
    head = f"Unit: {unit['assumed']} ({basis}). Inlet {ins or 'none'}; outlets {outs or 'none'}."
    tail = [f" {kind['type']}.", f" Fidelity {fidelity}, about {cells:,} cells.",
            f" {len(regions)} region(s), {len(layers)} layer target(s).",
            (" Extents " + ", ".join(f"{k} {v:.4g}" for k, v in extents.items()) + ".") if extents else "",
            (" Extend " + "; ".join(f"{e['patch_id']} by {e['length']:.4g}" for e in extensions) + ".") if extensions else ""]
    out = head
    for piece in tail:
        if piece and len(out) + len(piece) <= BUILDER_PROSE_MAX_CHARS:
            out += piece
    return out


def _analysis(kind: dict, summary: dict, roles: dict, risks: list[dict], cap: int | None = None) -> str:
    agent_kinds = sorted({r["kind"] for r in risks})
    text = (f"IDENTITY: {kind['type']}; evidence {kind['evidence']}. "
            f"REQUIRED TOPOLOGY: {kind['simulation_intent']}. "
            f"PROVIDED: roles {roles}. "
            f"BRIEF VS MEASUREMENT: heuristic policy does not parse the brief. "
            f"WHAT WILL BREAK: catalog {agent_kinds}; no agent-added risks (heuristic policy).")
    if cap is not None and len(text) > cap:
        # schema 3 (R12): the role listing is the only part that grows with the file; cut it, never the sections
        counts = {}
        for v in roles.values():
            counts[v] = counts.get(v, 0) + 1
        short = ", ".join(f"{n} {k}" for k, v in counts.items() for n in [v])
        text = (f"IDENTITY: {kind['type']}; evidence {kind['evidence']}. "
                f"REQUIRED TOPOLOGY: {kind['simulation_intent']}. "
                f"PROVIDED: roles by count {short} (see patches). "
                f"BRIEF VS MEASUREMENT: heuristic policy does not parse the brief. "
                f"WHAT WILL BREAK: catalog {agent_kinds}; no agent-added risks (heuristic policy).")
        if len(text) > cap:
            text = text[:cap - 3] + "..."
    return text


def _brief_conflicts(summary: dict, inlets: list, outlets: list) -> list[str]:
    brief = (summary.get("user_brief") or "").lower()
    out = []
    m = re.search(r"(\d+)\s+inlets?", brief)
    if m and int(m.group(1)) != len(inlets):
        out.append(f"brief says {m.group(1)} inlet(s); measured roles give {len(inlets)}")
    m = re.search(r"(\d+)\s+outlets?", brief)
    if m and int(m.group(1)) != len(outlets):
        out.append(f"brief says {m.group(1)} outlet(s); measured roles give {len(outlets)}")
    return out
