"""The quality signal that survives a stranger's file: the measurement against the look, with no answer key.

WHY THIS FILE EXISTS. Every number this project has published scores the look against a brief we wrote
ourselves. On a customer's housing there is no brief, no family, no `internals.TRUTHS` row, and every one of
those numbers goes silent. Two things do not need an answer key:

    A CONTRADICTION. The measurement and the look both speak about the same place and disagree. One of them is
                     wrong and the document is unreliable there, and knowing which one is wrong is not needed
                     to know that.
    AN IMPOSSIBILITY. The look says something that cannot be true of THIS FILE whatever the part is: a mouth at
                      an id no label was drawn for, an interior in a file with no interior, a letter that was
                      never drawn.

Both are computable from the file and the reply alone. That is the whole of what this module does.

THREE MORE CLASSES ARE HERE AND THEY ARE NOT THE SAME THING, so they are labelled and never summed with the
first two in one headline:

    SELF-CONTRADICTION. The reply disagrees with itself between fields. No measurement is involved at all, so
                        it is the cheapest signal here and the only one that would work with no geometry.
    INSTABILITY.        Two looks at the same part disagree. It costs a second reader call, which is the most
                        expensive thing in this pipeline, and it is priced as such in `COST`.
    OMISSION.           The look left something the measurement asked about unanswered. Not a contradiction:
                        silence is a gap and not a wrong answer, and it is reported apart because an operator
                        acts on it differently.

WHAT A FIRING MEANS AND WHAT IT DOES NOT. It means one of the two sources is wrong at the flagged place. It
does NOT mean the look is wrong, and on this corpus it almost never is. Every firing of every contradiction
signal here was read by hand against the corpus briefs in `eval/vision/monitor_verdicts.json`, and across the
union of four draws the reply is at fault in ONE place: seven `defects` entries naming a gap in a file the
loader finds watertight. The rest are the measurement blind (nine static mixers), a real feature the brief
calls a plain passage (thirteen venturi throats, two wye crotches), or one of the project's own text detectors
reading a correct reply as a denial. A monitor that printed "the look is wrong" on a firing would be lying to
the operator most of the time. Every alert carries `says` and `measured` so the operator reads both sides, and
the action says what to do with the document rather than who to blame.

WHAT THIS MODULE MAY NOT SEE, pinned by `tests/test_reconcile_monitor.py` and not merely promised here: a
brief, a family, a case name, a corpus truth row, a declared role, an expected representation. `Measured.case`
is a label for printing and a test pins that scrambling it changes no alert. The measured `representation`
IS read, and that is the one thing worth stating plainly: `catalog.representation` is brief-informed in the
benchmark's own cache, and `bench` carries `representation_blind` beside it for exactly this reason. The
runner scores both and prints the difference rather than assuming it away.

WHAT IT SILENTLY DROPS, asked before any number is believed. A signal that raises is caught in `run_signals`
and reported as a `signal_failed` health alert, never dropped. A reply with no impression produces one
`reply_unusable` alert and no others, so an unusable reply cannot look clean. A signal whose measurement
cannot speak returns nothing, which is indistinguishable in the count from a signal that looked and found
nothing: `coverage()` reports, per signal, how many parts it was ABLE to speak about, so a signal that is
silent because it is blind cannot pass as a signal that is silent because the part is fine.
"""
from __future__ import annotations

import re
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from typing import Any

from geometry_agent.reconcile.inventory import Look, Measured
from geometry_agent.reconcile.profile import mark_is_solid, obstruction_marks, restriction_verdict

# ---------------------------------------------------------------------------------------------------------------
# the vocabulary of a signal
# ---------------------------------------------------------------------------------------------------------------

#: What kind of thing fired. Never summed across classes in one headline: they mean different things to an
#: operator and two of them do not involve the measurement at all.
CONTRADICTION = "contradiction"
IMPOSSIBILITY = "impossibility"
SELF = "self_contradiction"
INSTABILITY = "instability"
OMISSION = "omission"
HEALTH = "health"

#: What the signal needs, which is the whole of the "can we afford to run it on every job" question.
#:
#:   free        the reply text and nothing else. Zero marginal cost on any job.
#:   measured    the facts and the render record the pipeline already produced to draw the pictures. Zero
#:               marginal cost: these objects exist before the reader is called.
#:   profile     the 41-station cross-section array. `render.choose_stations` already computes it to decide
#:               where to cut and then discards it, so this is zero marginal cost IF it is kept, and one extra
#:               pass over the mesh if the monitor runs standalone. `eval/vision/monitor.py cost` times both.
#:   second_look one more reader call on the same part. At the cold astra rate this DOUBLES the per-job reader
#:               bill. It is the only expensive class here and nothing else depends on it.
FREE = "free"
MEASURED = "measured"
PROFILE = "profile"
SECOND_LOOK = "second_look"

#: What an operator does with a firing. The monitor never edits the document itself: it says what to do and
#: the reconciler decides.
#:
#:   withhold  drop the look's statement at this place from the document. The measurement stands alone.
#:   flag      keep the statement and mark it contested, so the builder does not read it as settled.
#:   review    put the job in front of a person. Reserved for firings that mean the file itself is odd.
#:   escalate  worth a better reader on this one part.
WITHHOLD, FLAG, REVIEW, ESCALATE = "withhold", "flag", "review", "escalate"


@dataclass
class Alert:
    """One firing: what fired, where, and both sides of the disagreement in the words each side used."""
    signal: str
    kind: str
    action: str
    subject: str = ""
    says: str = ""
    measured: str = ""
    why: str = ""

    def line(self) -> str:
        where = f" at {self.subject}" if self.subject else ""
        return f"[{self.kind}] {self.signal}{where}: look says {self.says!r}; measurement says {self.measured!r}"


SIGNALS: list[dict[str, Any]] = []


def signal(kind: str, cost: str, action: str, fires_on: str, means: str, blind_to: str, reads: str = ""):
    """Register one signal with everything the operator table needs printed beside its number.

    `reads` is the ONE impression field the signal reads the look's side of, where it reads a named field at all.
    It exists for `run_signals` to honour `Look.not_asked` the way `inventory.run_claims` honours it: a prompt that
    never asked a field got no answer to it, and scoring its empty value is reading silence as a finding. Most
    signals read the measurement, or the whole reply, and name nothing here.
    """
    def wrap(fn: Callable[..., list[Alert]]):
        SIGNALS.append({"id": fn.__name__, "kind": kind, "cost": cost, "action": action,
                        "fires_on": fires_on, "means": means, "blind_to": blind_to, "reads": reads,
                        "pair": fn.__code__.co_argcount == 3, "fn": fn})
        return fn
    return wrap


# ---------------------------------------------------------------------------------------------------------------
# reading a mark answer, which is the one piece of vocabulary this file owns
# ---------------------------------------------------------------------------------------------------------------
#
# THE MISTAKE THIS SECTION EXISTS TO AVOID, found by reading the replies rather than the counts. A letter on a
# fluid domain's `void` region is standing on a SOLID thing: a tube in a bundle, a blade in a row. The reader,
# correctly, describes it as an absence of fluid:
#
#     "A: a circular tube exclusion, not fluid"
#     "A: inner-body space excluded from the fluid volume"
#
# A keyword reader that scores `space` from "space" and `fluid` from "fluid" calls both of those OPEN and
# contradicts a reply that was exactly right, on the two families this project most wants to catch. It is the
# same shape as the seven blind spots already on the record: the detector could not read a negation, and the
# negation was the answer. So the segmentation is `meaning.segments`, injected rather than rewritten, plus one
# vocabulary this file adds because no other file needed it: the language of a region EXCLUDED from a volume.
#
# `eval/vision/monitor.py hand-check` scores this reader against answers labelled by hand, and the labels are
# committed before the reader is, so the reader cannot have been fitted to them.

#: Material: the letter is on a solid thing.
SAYS_MATERIAL = re.compile(
    r"\bsolid\b|\bmaterial\b|\bwall\b|\bmetal\b|\bplug\b|\bcore\b|\bweb\b|\brib\b|\bvane\b|\bbaffle\b"
    r"|\bblade\b|\bstrut\b|\bboss\b|\bcent(?:re|er)[- ]?body\b|\bfilled\b|\bblocked\b|\bobstruct"
    r"|\bhub\b|\btube (?:body|wall|bundle)\b|\binsert\b|\bbody\b", re.I)
#: Space: the letter is in the void the flow occupies.
SAYS_SPACE = re.compile(
    r"\bopen\b|\bbore\b|\bvoid\b|\bempty\b|\bcavit|\bpassage\b|\bchannel\b|\bgap\b|\bhole\b|\bhollow\b"
    r"|\bspace\b|\bclear\b|\bduct\b|\bfluid\b|\bflow\b|\bwindow\b|\bplenum\b|\bchamber\b"
    r"|\bopening\b|\bapertures?\b|\bmouths?\b|\bthroats?\b|\bports?\b", re.I)
#: `annular` is deliberately in NEITHER vocabulary. It is a shape and both a wall and a passage can have it:
#: "an annular wall separating fluid regions" is material, "open annular passage" is space, and the noun after
#: it decides. Reading it as space was both of this reader's two disagreements with the hand labels, which
#: went 98 of 100 to 100 of 100 on that one change and on nothing else.
#: A region CUT OUT of the material the rest of the picture is made of. On a fluid domain this is the language
#: for a solid: the tube is not modelled, it is the hole the fluid closes around. It beats both vocabularies
#: above because it is a statement about what the region is NOT.
SAYS_EXCLUDED = re.compile(
    r"\bexclu(?:ded|sion|sions)\b|\bcut out of\b|\bcarved (?:out )?(?:of|from)\b"
    r"|\bremoved from\b|\bsubtracted\b|\bnon[- ]?fluid\b"
    r"|\boccupied by\b|\bdisplaces?\b|\bdisplacing\b", re.I)
#: The same claim written as a PLACE rather than as a noun: "a central void outside the fluid volume" is the
#: inner body and not a piece of empty passage. This one is read on the whole segment and not on its head,
#: because it is the tail of the sentence that carries it, and it is kept apart from `SAYS_EXCLUDED` for the
#: opposite case: "an annular fluid passage between vane-shaped exclusions" is a letter IN the passage, and
#: reading an exclusion off its tail would invert it.
OUTSIDE_THE_FLUID = re.compile(r"\b(?:outside|beyond|external to|not part of|excluded from|removed from|"
                               r"absent from|not)\s+(?:the\s+)?(?:\w+\s+){0,2}?(?:fluid|flow|wetted)\b", re.I)
#: The look declining at this letter. Never a contradiction.
SAYS_UNSURE = re.compile(r"\bunsure\b|\bcannot tell\b|\bcan'?t tell\b|\bunclear\b|\bnot (?:sure|clear)\b"
                         r"|\bindeterminate\b|\bambiguous\b", re.I)

#: Where an answer stops describing the letter and starts describing what is NEXT TO the letter. "an annular
#: fluid passage between vane-shaped exclusions" is a letter in the passage, and reading the exclusions as its
#: subject inverts it. `meaning._SEGMENT` already breaks on `around`, `surrounding` and `with`; these are the
#: locatives it does not carry, found by reading the answers this reader got wrong.
LOCATIVE_TAIL = re.compile(r"\b(?:between|beside|next to|adjacent to|either side of|outside|inside of|"
                           r"bounded by|separat(?:es|ing)|divid(?:es|ing)|surround(?:s|ing)|enclos(?:es|ing)|"
                           r"either end of|across from|opposite|behind|in front of|"
                           r"under|underneath|beneath|over|above|below|atop|alongside|interrupting|inside|"
                           r"in|at|on|of|from|within|into|near|by|through|against|"
                           r"across|along|onto|towards?)\s", re.I)

MATERIAL, SPACE, UNSURE = "material", "space", "unsure"


def _last(pattern: re.Pattern[str], text: str) -> int:
    """Where the last match of this vocabulary ends, or -1."""
    hits = list(pattern.finditer(text))
    return hits[-1].end() if hits else -1


def _class_of(head: str, flip: bool) -> str | None:
    """Material or space for one noun phrase, or None when it names neither.

    THE HEAD NOUN DECIDES AND IT IS LAST, which is the opposite of what this reader was first written to do
    and the difference costs a whole family. English puts the head of a compound at the end: "a curved passage
    wall" is a WALL and "curved passage-wall material" is MATERIAL, and reading the first noun called both of
    those an open passage and contradicted a reply that was right. The preposition is what flips it back:
    "solid material in the curved duct wall" is material in a wall, so the caller cuts the phrase at the first
    preposition before this is asked and what is left is the subject with its modifiers in front of it.

    `flip` inverts the reading and is passed only for a VERBAL negation: "not fluid" takes the fluid away and
    leaves material behind, while "an unobstructed fluid passage" takes nothing away and is still a fluid
    passage. That distinction is `meaning.VERBAL_NEGATION`, read off the segment rather than re-derived, and
    getting it wrong called 24 correct answers contradictions on the first run of this file."""
    mat, spc = _last(SAYS_MATERIAL, head), _last(SAYS_SPACE, head)
    if mat < 0 and spc < 0:
        return None
    said = MATERIAL if mat > spc else SPACE
    if flip:
        said = SPACE if said == MATERIAL else MATERIAL
    return said


def read_mark_answer(body: str, segments: Callable[[str], list[dict]] | None = None) -> str:
    """What one lettered answer says is at that letter: `material`, `space` or `unsure`.

    `segments` is `meaning.segments`, injected. Without it the reader falls back to the whole string, which is
    negation-blind; `tests` pins that passing it changes the answer on the phrases it was built for.

    The first segment that names either vocabulary decides, and later segments are context. An exclusion
    phrase in that segment wins outright, because "not fluid" and "excluded from the fluid volume" both carry
    the fluid vocabulary and mean its opposite."""
    text = str(body or "")
    if not text.strip():
        return UNSURE
    if SAYS_UNSURE.search(text):
        return UNSURE
    # read on the WHOLE answer and before the segmenter, because it is a qualifier and qualifiers arrive
    # last: "central open bore, outside the annular fluid volume" is cut at the comma, and the segment that
    # decides is the one before the qualifier that reverses it
    if OUTSIDE_THE_FLUID.search(text):
        return MATERIAL
    segs = (segments(text) if segments
            else [{"text": text, "negated": False, "contrast": False, "verbal": False}])
    for seg in segs:
        if seg.get("contrast"):
            continue
        piece = seg["text"]
        head = LOCATIVE_TAIL.split(piece, maxsplit=1)[0]
        if SAYS_EXCLUDED.search(head):
            return MATERIAL
        flip = bool(seg.get("verbal"))
        # the head names neither class, because its subject is a word this file has no vocabulary for ("the
        # edge of a thin curved wall"): the rest of the segment is read rather than abstaining
        said = _class_of(head, flip) or _class_of(piece, flip)
        if said:
            return said
    return UNSURE


def _letter_of(answer: str) -> str:
    m = re.match(r"^\s*\(?([A-Za-z])\)?\s*[:.)\-]\s+", answer or "")
    return m.group(1).upper() if m else ""


def _body_of(answer: str) -> str:
    return re.sub(r"^\s*\(?[A-Za-z]\)?\s*[:.)\-]\s+", "", answer or "")


def _openings_seen(look: Look) -> list[dict]:
    v = look.get("openings_seen")
    return [o for o in v if isinstance(o, dict)] if isinstance(v, list) else []


def _oid(o: dict) -> str:
    oid = str(o.get("id") or "").strip()
    return "" if oid.lower() in ("", "unlabelled", "unlabeled", "none", "unsure", "n/a") else oid


def asserts_material_inside(look: Look) -> str:
    """The reply's own words, if any, positively putting solid material inside the part.

    THE GUARD THAT FOUR SIGNALS NEEDED AND NONE OF THEM HAD. `stance` decides one verdict for a whole reply,
    and on a hollow part whose reply contains a sentence like "the central circular faces are solid core ends,
    not open bores" it reads the reply as being about a solid external body and cancels every object the reply
    named. The reply has then NAMED A CORE and been recorded as denying, and a monitor built on that verdict
    flags the one reply that got it right. Five of this file's first five obstruction alarms were that, and
    every one of them named the thing in `internal_features` in the sentence above the one that fooled the
    detector.

    So before any signal calls a reply a denial, this asks the reply directly: does it, in an ASSERTED and
    un-negated segment of `internal_features` or `notes`, put material inside. It is not a second stance
    detector and it decides nothing on its own: it only ever suppresses.
    """
    for name in ("internal_features", "notes"):
        for entry in look.list_of(name):
            segs = (look.segments(entry) if look.segments
                    else [{"text": entry, "negated": False, "contrast": False, "verbal": False}])
            for seg in segs:
                if seg.get("negated") or seg.get("contrast"):
                    continue
                if read_mark_answer(seg["text"], look.segments) == MATERIAL:
                    return str(entry)[:80]
    return ""


#: A denial that claims to cover the whole part. "no internal features anywhere", "featureless throughout".
#: Without the scope word a denial and a naming are not a contradiction: a reply may truthfully say the run is
#: clear and a vane sits in the branch, and 85 of 322 replies do something of that shape. With the scope word
#: there is no place left for the named thing to be.
WHOLE_PART_SCOPE = re.compile(r"\banywhere\b|\bthroughout\b|\bentire(?:ly)?\b|\bwhole\b|\bat all\b"
                              r"|\bany (?:internal|interior)\b|\bcompletely\b|\ball (?:cuts|sections|views)\b"
                              r"|\bevery (?:cut|section)\b|\bno internal (?:features?|structures?)\b", re.I)
#: A caution to the builder, which carries the words of a denial and is the opposite of one. "Do not assume the
#: cavity is unobstructed throughout" is the reply telling the builder to go and look, and both of this
#: signal's first two firings were that sentence on a closed-header manifold. It is a reply doing the right
#: thing and a monitor charging it for the vocabulary.
A_CAUTION = re.compile(r"\bdo not assume\b|\bdon'?t assume\b|\bshould not be assumed\b|\bcannot be assumed\b"
                       r"|\bmust not be assumed\b|\bnot safe to assume\b|\bbefore meshing\b|\bcheck\b", re.I)


# ---------------------------------------------------------------------------------------------------------------
# HEALTH: is there a reply to read at all
# ---------------------------------------------------------------------------------------------------------------

@signal(HEALTH, FREE, REVIEW,
        fires_on="a reply with no impression: a refusal, a parse failure, a transport error",
        means="there is nothing to reconcile and the document must go out measurement-only",
        blind_to="a reply that parsed but is nonsense. Nothing here reads for sense.")
def reply_unusable(m: Measured, look: Look) -> list[Alert]:
    if look.impression:
        return []
    return [Alert("reply_unusable", HEALTH, REVIEW, measured="no impression in the record",
                  why="the reader returned nothing this pipeline can read")]


@signal(HEALTH, FREE, WITHHOLD,
        fires_on="a digit surviving into the reply, which the prompt forbids and the scrubber removes",
        means="the scrub failed, so a number the model invented could reach the builder as if measured",
        blind_to="a number written in words. `two vanes` is not caught and is not scrubbed either.")
def numbers_survived_the_scrub(m: Measured, look: Look) -> list[Alert]:
    out: list[Alert] = []
    for f, v in (look.impression or {}).items():
        text = " ".join(str(x) for x in v) if isinstance(v, list) else str(v or "")
        # an opening id is a digit by design and is the one exception the scrubber itself makes
        stripped = re.sub(r"\bo\d+\b", " ", text, flags=re.I)
        if re.search(r"\d", stripped):
            out.append(Alert("numbers_survived_the_scrub", HEALTH, WITHHOLD, subject=str(f),
                             says=re.sub(r"\s+", " ", stripped)[:80],
                             measured="the prompt forbids every digit and the scrubber removes them"))
    return out


# ---------------------------------------------------------------------------------------------------------------
# IMPOSSIBILITY: the look says something that cannot be true of this file
# ---------------------------------------------------------------------------------------------------------------

@signal(IMPOSSIBILITY, MEASURED, WITHHOLD,
        fires_on="an opening id in `openings_seen` that no label was drawn for",
        means="the look answered about a mouth that was not in front of it, so the id is invented",
        blind_to="a mouth described in prose with no id. Nothing here can match a phrase to an opening.")
def phantom_mouth(m: Measured, look: Look) -> list[Alert]:
    # An absent label record is not an empty one. This signal's whole test is "no label was drawn for this id",
    # and with nobody's record of what was drawn it cannot be asked. It fired on 1,552, 1,555, 1,554 and 1,553
    # correctly answered mouths over the four cached draws when the absent record read as empty, all WITHHOLD.
    # `mouths_left_unanswered` below was already guarded; this one and `inventory.opening_id_exists` were not.
    if not m.knows_labels:
        return []
    drawn, measured = set(m.labelled or ()), {o.id for o in m.facts.openings}
    out: list[Alert] = []
    for seen in _openings_seen(look):
        oid = _oid(seen)
        if not oid or oid in drawn:
            continue
        where = ("measured but never drawn" if oid in measured
                 else f"no such opening; the measurement found {len(measured)}")
        out.append(Alert("phantom_mouth", IMPOSSIBILITY, WITHHOLD, subject=oid,
                         says=str(seen.get("looks_like") or "")[:60], measured=where))
    return out


@signal(IMPOSSIBILITY, MEASURED, WITHHOLD,
        fires_on="a lettered answer whose letter was never drawn on any cut",
        means="the look answered a mark that is not in the picture",
        blind_to="a letter drawn but illegible. The renderer records what it drew, never what was readable.")
def phantom_letter(m: Measured, look: Look) -> list[Alert]:
    drawn = {str(p.get("id")) for p in m.mark_places}
    if not drawn:
        return []
    out: list[Alert] = []
    for answer in look.list_of("marks_seen"):
        letter = _letter_of(answer)
        if letter and letter not in drawn:
            out.append(Alert("phantom_letter", IMPOSSIBILITY, WITHHOLD, subject=letter,
                             says=_body_of(answer)[:60],
                             measured=f"letters drawn: {', '.join(sorted(drawn))}"))
    return out


@signal(IMPOSSIBILITY, MEASURED, WITHHOLD,
        fires_on="an answer to a stop panel when no stops view was drawn",
        means="the look answered a panel that does not exist",
        blind_to="nothing. The renderer knows exactly how many panels it drew.")
def stop_answers_without_a_stops_view(m: Measured, look: Look) -> list[Alert]:
    answers = look.list_of("stops_seen")
    if not answers or m.stopped:
        return []
    return [Alert("stop_answers_without_a_stops_view", IMPOSSIBILITY, WITHHOLD,
                  says=f"{len(answers)} panels answered", measured="no stops view was drawn")]


@signal(IMPOSSIBILITY, MEASURED, WITHHOLD,
        fires_on="a passage, cavity or bore ASSERTED inside a file the measurement reads as a body in a stream",
        means="an external-flow file has no inside, so a passage inside it cannot be there",
        blind_to="a wrong representation. This fires on the measurement's word for the file, and the runner "
                 "scores the brief-informed and the blind representation apart because they differ on 25.")
def inside_a_body_with_no_interior(m: Measured, look: Look) -> list[Alert]:
    """THE VERSION THAT DOES NOT WORK IS WORTH MORE THAN THE ONE THAT DOES, so it is written down here.

    The obvious rule is "`internal_features` is not empty on an external file, or the stance verdict is
    `names`". It fires on 7, 4, 4 and 6 parts and every one of them lands on an external-flow family, so a
    table scored by the corpus class prints it as 100 per cent right on all four draws. It is 0 per cent
    right. The entries it fires on are `Solid hub without a visible bore` and `Solid blade sections without
    internal cavities`: the reply is using the field to say there is NO interior, and the naming it is charged
    with is `vane`, which on a rotor is the outside of the part. Both halves are the reply being correct.

    So the rule is a POSITIVE assertion of a void, and with that it fires on 0 parts on all four draws. That
    zero is the finding: the reader does not invent interiors, and the first version measured its own
    negation blindness and a class column agreed with it."""
    if m.has_passage or m.representation == "unknown":
        return []
    out: list[Alert] = []
    for entry in look.list_of("internal_features"):
        segs = (look.segments(entry) if look.segments
                else [{"text": entry, "negated": False, "contrast": False, "verbal": False}])
        if any(not s.get("negated") and not s.get("contrast")
               and read_mark_answer(s["text"], look.segments) == SPACE for s in segs):
            out.append(Alert("inside_a_body_with_no_interior", IMPOSSIBILITY, WITHHOLD,
                             subject="internal_features", says=str(entry)[:80],
                             measured=f"{m.representation}: no interior in this file"))
    return out


@signal(CONTRADICTION, MEASURED, FLAG,
        fires_on="a reply calling the part a solid body with no interior on a file that has a passage",
        means="the reply has told the builder there is nothing to mesh inside a file whose whole point is the "
              "inside, and every object the reply named is cancelled by that sentence downstream",
        blind_to="a reply that says it in words `stance.says_it_is_solid` does not carry. That detector is "
                 "hand-checked against 151 replies and is borrowed rather than rewritten here.")
def called_solid_but_the_file_has_a_passage(m: Measured, look: Look) -> list[Alert]:
    if not look.says_solid or not m.has_passage:
        return []
    return [Alert("called_solid_but_the_file_has_a_passage", CONTRADICTION, FLAG,
                  says="a solid body with no internal passage",
                  measured=f"{m.representation}: the file is a passage",
                  why="this also cancels the reply's own naming downstream, see `asserts_material_inside`")]


# ---------------------------------------------------------------------------------------------------------------
# CONTRADICTION: both sides speak about the same place and disagree
# ---------------------------------------------------------------------------------------------------------------

@signal(CONTRADICTION, MEASURED, FLAG,
        fires_on="the look calling the passage plain while a lettered mark stands on solid material inside it",
        means="the renderer drew a letter on a solid region of a cut and the look said the passage is clear",
        blind_to="anything touching the wall. A mixer element welded to the bore is not an enclosed region in "
                 "that plane and nominates no mark, so this channel never sees it.")
def denied_over_an_obstruction_mark(m: Measured, look: Look) -> list[Alert]:
    if not m.has_passage or not m.mark_places:
        return []
    if look.stance.get("verdict") != "denies":
        return []
    # the reply named the thing itself, whatever the one-verdict detector decided about the reply as a whole.
    # Without this guard the signal fires on 5 parts and the reply is right on all five: see
    # `asserts_material_inside` for what cancels the naming and why it is not fixed in `stance`.
    named = asserts_material_inside(look)
    if named:
        return []
    bodies = obstruction_marks(m.mark_places, m.representation)
    if not bodies:
        return []
    where = ", ".join(str(b.get("id")) for b in bodies)
    clause = look.stance.get("denied", [("", "")])[0][1]
    return [Alert("denied_over_an_obstruction_mark", CONTRADICTION, FLAG, subject=where,
                  says=str(clause)[:80],
                  measured=f"{len(bodies)} of {len(m.mark_places)} marks stand on solid material in the passage")]


@signal(CONTRADICTION, PROFILE, FLAG,
        fires_on="the look calling the passage plain where the cross-section narrows and recovers",
        means="a section change the mesher must resolve sits where the look told the builder to stop looking",
        blind_to="a branch, and a bore that leaves the cut plane. Both are `unreadable` and fire nothing. And "
                 "it cannot tell a venturi throat from an orifice plate: on this corpus 13 of its 14 firings "
                 "are the venturi family and the brief calls 10 of those a plain passage.")
def denied_over_a_restriction(m: Measured, look: Look) -> list[Alert]:
    if look.stance.get("verdict") != "denies":
        return []
    verdict, detail = restriction_verdict(m.profile)
    if verdict != "restricted":
        return []
    clause = look.stance.get("denied", [("", "")])[0][1]
    return [Alert("denied_over_a_restriction", CONTRADICTION, FLAG,
                  subject=f"t={detail['at']:.2f}", says=str(clause)[:80],
                  measured=f"the flow area falls to {detail['open_fraction']:.0%} of its peak and recovers",
                  why="blocked" if detail.get("blocked") else "narrowed")]


@signal(CONTRADICTION, PROFILE, FLAG,
        fires_on="the look putting something in the passage where BOTH measurement channels find it clear",
        means="the look named a thing neither the cross-section nor the marks can find",
        blind_to="anything both channels are blind to at once, which is most of the annular, blade-row and "
                 "static-mixer families. Requiring both channels to speak is what keeps this signal off them: "
                 "it fires on 12 parts where the looser one-channel version fires on 33.")
def asserted_over_a_clear_bore(m: Measured, look: Look) -> list[Alert]:
    if look.stance.get("verdict") != "names":
        return []
    if not m.has_passage or not m.mark_places:
        return []
    verdict, _ = restriction_verdict(m.profile)
    if verdict != "clear":
        return []
    if obstruction_marks(m.mark_places, m.representation):
        return []
    named = ", ".join(k for k, _ in look.stance.get("named", [])[:3])
    return [Alert("asserted_over_a_clear_bore", CONTRADICTION, FLAG, subject=named,
                  says=str(look.stance.get("named", [("", "")])[0][1])[:80],
                  measured="the cross-section never narrows and no mark stands on material in the passage")]


#: How many letters must be readable before a majority of them means anything. Three, which is the smallest
#: number that can have a majority at all without a tie, and the corpus draws six to eight on a part that has
#: any. Nothing in the result below moves between three and five.
MIN_LETTERS_FOR_REPRESENTATION = 3


def _letter_tally(m: Measured, look: Look) -> tuple[int, int, list[tuple[str, str, str]]]:
    """Per letter: does the reply's reading agree with what the renderer drew the letter on.

    Returns (agree, disagree, the disagreeing letters as (letter, what was said, what was drawn))."""
    kinds = {str(p.get("id")): str(p.get("kind")) for p in m.mark_places}
    agree = 0
    against: list[tuple[str, str, str]] = []
    for answer in look.list_of("marks_seen"):
        letter = _letter_of(answer)
        kind = kinds.get(letter)
        if kind is None:
            continue
        is_solid = mark_is_solid(kind, m.representation)
        if is_solid is None:
            continue
        said = read_mark_answer(_body_of(answer), look.segments)
        if said == UNSURE:
            continue
        if (said == MATERIAL) == is_solid:
            agree += 1
        else:
            against.append((letter, _body_of(answer)[:70],
                            f"a {kind} region on a {m.representation}: "
                            f"{'solid material' if is_solid else 'open space'}"))
    return agree, len(against), against


@signal(CONTRADICTION, MEASURED, REVIEW,
        fires_on="MOST of the lettered answers disagreeing with what the renderer drew the letters on",
        means="THE REPRESENTATION IS WRONG. A `void` region is solid on a fluid domain and open on a wall "
              "shell, so one wrong word about the file inverts every letter at once, and a reader that is "
              "right about the pictures will then disagree with all of them. This is the signal that matters "
              "most in production and it is the one nobody could have found on the corpus alone: the "
              "benchmark's cached representation is brief-informed, and a customer's is the blind call.",
        blind_to="a representation that is wrong in a way the letters do not invert, and a part with fewer "
                 "than three readable letters. It also cannot say WHICH representation is right, only that "
                 "the one assumed disagrees with the reader.")
def the_letters_say_the_representation_is_wrong(m: Measured, look: Look) -> list[Alert]:
    if not m.mark_places:
        return []
    agree, against, detail = _letter_tally(m, look)
    if agree + against < MIN_LETTERS_FOR_REPRESENTATION or against <= agree:
        return []
    return [Alert("the_letters_say_the_representation_is_wrong", CONTRADICTION, REVIEW,
                  subject=", ".join(d[0] for d in detail),
                  says=detail[0][1],
                  measured=f"{against} of {agree + against} readable letters disagree with "
                           f"{m.representation}",
                  why="one wrong word about the file inverts every letter at once")]


@signal(CONTRADICTION, MEASURED, WITHHOLD,
        fires_on="a MINORITY of the lettered answers calling material space, or space material",
        means="the look read the picture wrong at a place the measurement chose and knows the truth of",
        blind_to="what the solid IS. And it cannot speak where the representation is neither a wall shell nor "
                 "a fluid domain, which is 63 of the 322 parts. A MAJORITY inversion is not this signal: it "
                 "is the representation being wrong and it is reported once, as one alert, rather than as one "
                 "alert per letter.")
def mark_read_against_the_picture(m: Measured, look: Look) -> list[Alert]:
    if not m.mark_places:
        return []
    agree, against, detail = _letter_tally(m, look)
    if against > agree and agree + against >= MIN_LETTERS_FOR_REPRESENTATION:
        return []
    return [Alert("mark_read_against_the_picture", CONTRADICTION, WITHHOLD, subject=letter,
                  says=said, measured=drawn) for letter, said, drawn in detail]


@signal(CONTRADICTION, MEASURED, FLAG,
        fires_on="the look saying a passage carries on in a panel the stops detector drew because it ends",
        means="the terminus the measurement found is being denied, and a closed end the builder does not know "
              "about is a leak",
        blind_to="every fluid domain. `find_stops` is gated off them, so no panel is drawn and this signal is "
                 "silent on 302 of 322 parts by construction, not by finding nothing.")
def stop_panel_denied(m: Measured, look: Look) -> list[Alert]:
    answers = look.list_of("stops_seen")
    if not m.stopped or not answers:
        return []
    out: list[Alert] = []
    for i, oid in enumerate(m.stopped):
        if i >= len(answers):
            break
        body = answers[i]
        if SAYS_UNSURE.search(body):
            continue
        stops = bool(_SAYS_STOPS.search(body))
        goes = bool(_SAYS_CONTINUES.search(body))
        if goes and not stops:
            out.append(Alert("stop_panel_denied", CONTRADICTION, FLAG, subject=oid, says=body[:70],
                             measured="the detector found this passage ends at a wall"))
    return out


_SAYS_STOPS = re.compile(r"\bruns into\b|\bgoes no further\b|\bdead[- ]?ends?\b|\bblind\b|\bclosed\b|\bcapped\b"
                         r"|\bblocked\b|\bstops?\b|\bterminat|\bends? (?:at|in|against)\b|\bsealed\b", re.I)
_SAYS_CONTINUES = re.compile(r"\bcontinues\b|\bcarries on\b|\bgoes (?:on|through)\b|\bpasses through\b"
                             r"|\bopens? (?:out|into|through)\b|\bnot (?:closed|blocked|capped)\b"
                             r"|\bthrough[- ]?(?:flow|passage)\b", re.I)


@signal(CONTRADICTION, MEASURED, WITHHOLD,
        fires_on="a defect named on a file the loader finds watertight, manifold, consistent and clean",
        means="the look invented a file problem, and a file problem is the one thing the loader checks "
              "exhaustively before anything else runs",
        blind_to="a defect the loader silently repaired. `clean_surface` merges duplicate faces without "
                 "reporting it, so a file that arrived broken can read clean here.")
def defect_on_a_file_the_loader_calls_clean(m: Measured, look: Look) -> list[Alert]:
    said = look.list_of("defects")
    if not said:
        return []
    f, facts = m.facts.features, m.facts
    problems = []
    if not facts.watertight:
        problems.append("not watertight")
    if getattr(f, "non_manifold_edge_count", 0):
        problems.append(f"{f.non_manifold_edge_count} non-manifold edges")
    if not getattr(f, "winding_consistent", True):
        problems.append("inconsistent winding")
    if getattr(facts, "debris_components", 0):
        problems.append(f"{facts.debris_components} debris components")
    if problems:
        return []
    return [Alert("defect_on_a_file_the_loader_calls_clean", CONTRADICTION, WITHHOLD,
                  says="; ".join(said)[:80],
                  measured="watertight, manifold, consistent winding, no debris")]


@signal(CONTRADICTION, MEASURED, WITHHOLD, reads="orientation",
        fires_on="the look naming a long axis that is not the longest bounding-box extent",
        means="the look's frame is wrong, so every direction word in the reply is suspect",
        blind_to="a part whose two longest extents are within five per cent, where there is no longest axis "
                 "to be wrong about. Those are skipped rather than counted as agreement.")
def long_axis_named_wrong(m: Measured, look: Look) -> list[Alert]:
    """TWO NARROWINGS, BOTH FOUND BY READING THE FIRINGS, and the looser version is written down because it
    fires four times as often and is measuring the wrong thing.

    The loose version also accepted "runs along X" and asked only that the named axis not be the longest. It
    fires on 19, 20, 18 and 18 parts, and 21 of 21 in the union say X. That is not the reader defaulting to X:
    it is `The hub axis runs along X` on a rotor whose bounding box is a disc, and `The chamber's long
    direction runs along X` on a plenum with a nozzle hanging off the bottom. THE AXIS OF A PART AND THE
    LONGEST EDGE OF ITS BOUNDING BOX ARE NOT THE SAME QUANTITY, and a rotor is the case where they are
    furthest apart. So only the literal words "long axis" or "longest axis" count, and the difference has to
    be worth naming: a housing whose two longest extents are 250 and 309 is not a reply getting the axis
    wrong, it is two people drawing the line in different places."""
    said = _LONG_AXIS_ONLY(look.text_of("orientation"))
    if said is None:
        return []
    extent = list(m.facts.bbox.extent)
    got = int(m.facts.bbox.longest_axis)
    if said == got:
        return []
    if extent[said] <= 0 or extent[got] / extent[said] < AXIS_MARGIN:
        return []
    return [Alert("long_axis_named_wrong", CONTRADICTION, WITHHOLD, subject="orientation",
                  says=f"the long axis is {'XYZ'[said]}",
                  measured=f"the longest extent is {'XYZ'[got]}, "
                           f"{extent[got] / extent[said]:.2f} times the named one")]


_LONG_AXIS = re.compile(r"long(?:est)?\s+axis[^.;]{0,40}?([+-]?\s*[XYZ])\b", re.I)
#: How much longer the longest extent must be than the axis the reply named, before the two are disagreeing
#: rather than drawing a line in different places. 1.5 and not a fitted number: below it sit a housing at 1.24
#: and a plenum at 1.11, both of them lumpy parts with a branch hanging off one side.
AXIS_MARGIN = 1.5


def _LONG_AXIS_ONLY(text: str) -> int | None:  # noqa: N802 - named for the constant it reads
    hit = _LONG_AXIS.search(text or "")
    return "xyz".index(hit.group(1).strip().lstrip("+-").lower()) if hit else None


def _axis_said(text: str) -> int | None:
    """The loose reading, kept for `eval/vision/monitor.py` to print beside the tight one. Not used by any
    signal: it accepts "the hub axis runs along X", which is a true statement about a rotor and not a claim
    about its bounding box."""
    fallback = re.compile(r"\b(?:runs|lies|extends|oriented|aligned)\s+(?:along|with|parallel to)\s+"
                          r"(?:the\s+)?([+-]?\s*[XYZ])\b", re.I)
    for pat in (_LONG_AXIS, fallback):
        hit = pat.search(text or "")
        if hit:
            return "xyz".index(hit.group(1).strip().lstrip("+-").lower())
    return None


# ---------------------------------------------------------------------------------------------------------------
# SELF-CONTRADICTION: the reply against itself, with no measurement at all
# ---------------------------------------------------------------------------------------------------------------

@signal(SELF, FREE, FLAG,
        fires_on="a denial scoped to the whole part beside a named thing inside it",
        means="there is no place left for the named thing to be, so one of the two statements is false",
        blind_to="the ordinary case, deliberately. A reply may truthfully say one run is clear and name a vane "
                 "in a branch: 85 of 322 replies name and deny something, and without the scope word that is "
                 "not a contradiction. The scope word is what makes it one.")
def denies_everywhere_but_names_something(m: Measured, look: Look) -> list[Alert]:
    st = look.stance
    if not st.get("mixed"):
        return []
    whole = [c for _, c in st.get("denied", [])
             if WHOLE_PART_SCOPE.search(str(c)) and not A_CAUTION.search(str(c))]
    if not whole:
        return []
    named = ", ".join(k for k, _ in st.get("named", [])[:3])
    return [Alert("denies_everywhere_but_names_something", SELF, FLAG, subject=named,
                  says=str(whole[0])[:80],
                  measured="the same reply names " + named,
                  why="no measurement is involved: the reply contradicts itself")]


@signal(SELF, FREE, FLAG,
        fires_on="the same opening id answered twice with different answers",
        means="the reply holds two readings of one mouth and the document can only carry one",
        blind_to="two ids that are the same mouth. The look cannot know that and neither can this.")
def a_mouth_answered_twice_differently(m: Measured, look: Look) -> list[Alert]:
    by_id: dict[str, list[dict]] = {}
    for seen in _openings_seen(look):
        oid = _oid(seen)
        if oid:
            by_id.setdefault(oid, []).append(seen)
    out: list[Alert] = []
    for oid, rows in by_id.items():
        if len(rows) < 2:
            continue
        keys = ("looks_like", "mouth", "likely_role")
        spellings = {tuple(str(r.get(k) or "").strip().lower() for k in keys) for r in rows}
        if len(spellings) > 1:
            out.append(Alert("a_mouth_answered_twice_differently", SELF, FLAG, subject=oid,
                             says=" | ".join("/".join(s) for s in sorted(spellings))[:80],
                             measured="one mouth, two answers",
                             why="no measurement is involved"))
    return out


@signal(SELF, FREE, FLAG,
        fires_on="a mouth called a cap and given an inlet or outlet role in the same entry",
        means="a cap is closed and a port is open, so the entry cannot be read as it stands",
        blind_to="a cap with a hole in it, which the look has no word for and which would make both true.")
def a_cap_given_a_flow_role(m: Measured, look: Look) -> list[Alert]:
    out: list[Alert] = []
    for seen in _openings_seen(look):
        shape = str(seen.get("looks_like") or "").strip().lower()
        role = str(seen.get("likely_role") or "").strip().lower()
        if shape in ("cap", "blank", "blanked") and role in ("inlet", "outlet"):
            out.append(Alert("a_cap_given_a_flow_role", SELF, FLAG, subject=_oid(seen) or "?",
                             says=f"{shape} / {role}", measured="a closed face cannot carry flow",
                             why="no measurement is involved"))
    return out


@signal(SELF, FREE, FLAG,
        fires_on="a reply that calls the part a solid body with no interior and then gives a mouth a flow role",
        means="the reply has said there is nothing for a port to serve",
        blind_to="a reply that says it twice in words too different for `stance.says_it_is_solid`, which is "
                 "the hand-checked detector this borrows rather than writing a second one.")
def solid_throughout_but_a_port_named(m: Measured, look: Look) -> list[Alert]:
    if not look.says_solid:
        return []
    roles = [(_oid(o), str(o.get("likely_role") or "").strip().lower()) for o in _openings_seen(look)]
    hit = [oid for oid, role in roles if role in ("inlet", "outlet")]
    if not hit:
        return []
    return [Alert("solid_throughout_but_a_port_named", SELF, FLAG, subject=", ".join(hit),
                  says="a solid body with no internal passage, and an inlet or outlet",
                  measured="the reply's own two statements", why="no measurement is involved")]


# ---------------------------------------------------------------------------------------------------------------
# OMISSION: the look left the measurement's question unanswered
# ---------------------------------------------------------------------------------------------------------------

@signal(OMISSION, MEASURED, FLAG,
        fires_on="a label the renderer drew that the reply never answers",
        means="the document has no reading for that mouth, which is a gap and not a wrong answer",
        blind_to="whether the label was legible. An occluded label is a render fault and reads the same here.")
def mouths_left_unanswered(m: Measured, look: Look) -> list[Alert]:
    """ACCOUNTED FOR IS NOT THE SAME AS ANSWERED and the difference is most of this signal. On an annular part
    the two rings at one end are four measured openings and one visible mouth, and the reply answers o3 and o4
    and then writes "Only o3 and o4 are visible in the supplied views" in `notes`. That reply has accounted for
    o1 and o2: it has told the builder exactly what it could not see, which is the behaviour this project has
    spent four rounds trying to buy. Charging it for a gap it declared would be scoring care as a defect.

    So an id named ANYWHERE in the reply counts as accounted for. The loose version, which asks only that the
    id appear in `openings_seen`, fires on 25, 25, 26 and 27 parts."""
    if not m.labelled:
        return []
    answered = {_oid(o) for o in _openings_seen(look)}
    elsewhere = " ".join(str(v) for v in (look.impression or {}).values())
    missing = [x for x in m.labelled
               if x not in answered and not re.search(rf"\b{re.escape(x)}\b", elsewhere, re.I)]
    if not missing:
        return []
    return [Alert("mouths_left_unanswered", OMISSION, FLAG, subject=", ".join(missing),
                  says=f"{len(answered & set(m.labelled))} of {len(m.labelled)} labels answered",
                  measured=f"{len(m.labelled)} labels were drawn")]


@signal(OMISSION, MEASURED, FLAG,
        fires_on="a stop panel the renderer drew that the reply never answers",
        means="the terminus view is this project's one measured win and an unanswered panel wastes it",
        blind_to="the same thing `stop_panel_denied` is blind to: there is no panel on a fluid domain.")
def stop_panels_left_unanswered(m: Measured, look: Look) -> list[Alert]:
    if not m.stopped:
        return []
    answers = look.list_of("stops_seen")
    if len(answers) >= len(m.stopped):
        return []
    return [Alert("stop_panels_left_unanswered", OMISSION, FLAG,
                  says=f"{len(answers)} answers", measured=f"{len(m.stopped)} panels drawn")]


@signal(OMISSION, PROFILE, FLAG,
        fires_on="a cross-section whose two ends differ by more than the taper ratio, with no change of "
                 "section named anywhere in the reply",
        means="the diffuser cone row. The measurement has the taper to three decimals and the look finds 2 or "
              "3 of 13, so this is the measurement telling the document what the look missed",
        blind_to="a passage that narrows and widens back to the same size, which reads as no taper at all. "
                 "And it cannot tell a cone from a step.")
def taper_left_unnamed(m: Measured, look: Look) -> list[Alert]:
    """THE AXIS GATE BELONGS HERE TOO and `FlowProfile.taper` does not carry it. `restriction_verdict` refuses
    to read a profile whose passage does not run along the fitted axis; `taper` reads the first and last live
    station of the same profile and does not ask. On a bend the fitted axis is the chord across it, so the end
    stations are oblique slices of the bore and their areas differ for a geometric reason: this signal fired on
    `bend_elbow_021_fluid` at 9.78 to one on a pipe of constant section. Ungated it fires on 37, 40, 42 and 45
    parts and the elbows are most of the top of that list."""
    if not m.profile.readable:
        return []
    tp = m.profile.taper()
    if not tp:
        return []
    text = " ".join(look.list_of("internal_features") + look.list_of("notes")
                    + [str(look.get("looks_like") or "")] + look.list_of("marks_seen"))
    if _SAYS_TAPER.search(text):
        return []
    return [Alert("taper_left_unnamed", OMISSION, FLAG,
                  says="no change of section named anywhere in the reply",
                  measured=f"the two ends differ by {tp['ratio']:.2f} to one, "
                           f"{'opening out' if tp['opens_towards_end'] else 'closing down'} along the axis")]


_SAYS_TAPER = re.compile(r"\btapers?\b|\btapering\b|\bcones?\b|\bconical\b|\bdiffuser\b|\bexpans|\bwidens?\b"
                         r"|\bwidening\b|\bnarrows?\b|\bnarrowing\b|\bcontract|\bventuri\b|\bthroat\b"
                         r"|\bnozzle\b|\breduc|\bflares?\b|\bflaring\b|\bbell[- ]?mouth\b"
                         r"|\bchange (?:of|in) (?:section|area|diameter)\b"
                         r"|cross[- ]?section(?:al)? (?:change|area)", re.I)


# ---------------------------------------------------------------------------------------------------------------
# INSTABILITY: two looks at the same part, which costs a second reader call
# ---------------------------------------------------------------------------------------------------------------

@signal(INSTABILITY, SECOND_LOOK, ESCALATE,
        fires_on="two looks at the same part reaching different verdicts about the inside",
        means="the reader is not reading the part, it is guessing, and neither answer can be trusted here",
        blind_to="two looks that are both wrong the same way. Agreement is not correctness and this signal "
                 "never claims it is.")
def two_looks_disagree_about_the_inside(m: Measured, first: Look, second: Look) -> list[Alert]:
    a, b = first.stance.get("verdict"), second.stance.get("verdict")
    if a == b:
        return []
    return [Alert("two_looks_disagree_about_the_inside", INSTABILITY, ESCALATE, subject="internal_features",
                  says=f"first look {a}", measured=f"second look {b}",
                  why="no measurement is involved: the two readings disagree")]


@signal(INSTABILITY, SECOND_LOOK, ESCALATE,
        fires_on="two looks answering the same letter, one material and one space",
        means="the reader cannot see what is at that place, whatever it says about it",
        blind_to="a letter only one of the two answered. That is an omission, not a disagreement.")
def two_looks_disagree_about_a_letter(m: Measured, first: Look, second: Look) -> list[Alert]:
    def by_letter(look: Look) -> dict[str, str]:
        out: dict[str, str] = {}
        for answer in look.list_of("marks_seen"):
            letter = _letter_of(answer)
            if letter:
                out[letter] = read_mark_answer(_body_of(answer), look.segments)
        return out
    left, right = by_letter(first), by_letter(second)
    out: list[Alert] = []
    for letter in sorted(set(left) & set(right)):
        if left[letter] == UNSURE or right[letter] == UNSURE:
            continue
        if left[letter] != right[letter]:
            out.append(Alert("two_looks_disagree_about_a_letter", INSTABILITY, ESCALATE, subject=letter,
                             says=f"first look {left[letter]}", measured=f"second look {right[letter]}",
                             why="no measurement is involved"))
    return out


# ---------------------------------------------------------------------------------------------------------------
# running the monitor
# ---------------------------------------------------------------------------------------------------------------

@dataclass
class Report:
    """What fired on one job, and what an operator should do about it."""
    case: str
    alerts: list[Alert] = field(default_factory=list)
    #: signals that could not run, by id and reason. Never silently dropped.
    failed: dict[str, str] = field(default_factory=dict)

    @property
    def clean(self) -> bool:
        return not self.alerts

    def of_kind(self, kind: str) -> list[Alert]:
        return [a for a in self.alerts if a.kind == kind]

    def signals(self) -> set[str]:
        return {a.signal for a in self.alerts}

    def worst(self) -> str:
        """The strongest action any alert asks for, in the order they are defined."""
        for action in (REVIEW, WITHHOLD, ESCALATE, FLAG):
            if any(a.action == action for a in self.alerts):
                return action
        return "pass"


def run_signals(m: Measured, look: Look, second: Look | None = None,
                only: Sequence[str] | None = None, costs: Sequence[str] | None = None) -> Report:
    """Every registered signal over one part and one reply.

    `costs` restricts to signals affordable in this setting, which is how the same code runs as the every-job
    monitor and as the full bench: `run_signals(m, look, costs=("free", "measured"))` is the set with no
    marginal cost at all.

    A SIGNAL WHOSE FIELD THE PROMPT NEVER ASKED DOES NOT RUN, which is `inventory.run_claims`' rule applied to the
    other reader of the same `Look`. `run_claims` gates on `look.not_asked` and this did not, so the same object
    was read two ways: on the cached corpus, replied to under a variant that asked `orientation`,
    `long_axis_named_wrong` went on firing at WITHHOLD while the contradiction count beside it had stopped
    counting the field. The live path never showed it, because a reply to the shipped prompt carries no
    orientation at all and the signal needs a stated axis to fire, which is measured rather than assumed."""
    report = Report(case=m.case)
    if not look.impression:
        return Report(case=m.case, alerts=reply_unusable(m, look))
    unasked = set(look.not_asked or ())
    for s in SIGNALS:
        if only and s["id"] not in only:
            continue
        if costs and s["cost"] not in costs:
            continue
        if unasked and s["reads"] and s["reads"] in unasked:
            continue
        if s["pair"] and second is None:
            continue
        try:
            report.alerts += (s["fn"](m, look, second) if s["pair"] else s["fn"](m, look))
        except Exception as exc:
            report.failed[s["id"]] = f"{type(exc).__name__}: {exc}"
            report.alerts.append(Alert("signal_failed", HEALTH, REVIEW, subject=s["id"],
                                       measured=f"{type(exc).__name__}: {exc}"))
    return report


def signal_table() -> list[dict[str, str]]:
    """The monitor itself: every signal, what it fires on, what it means, what it cannot see, what it costs."""
    return [{"signal": s["id"], "kind": s["kind"], "cost": s["cost"], "action": s["action"],
             "fires_on": s["fires_on"], "means": s["means"], "blind_to": s["blind_to"]} for s in SIGNALS]


def can_speak(m: Measured, look: Look, signal_id: str) -> bool:
    """Whether a signal was ABLE to say anything about this part, apart from whether it did.

    A signal silent because it is blind and a signal silent because the part is fine are the same zero in a
    count and opposite evidence, and telling them apart is the difference between a 4 per cent alarm and a 4
    per cent alarm on a tenth of the corpus. Every entry here is the signal's own gate, restated once."""
    gates: dict[str, Callable[[], bool]] = {
        "reply_unusable": lambda: True,
        "numbers_survived_the_scrub": lambda: bool(look.impression),
        "phantom_mouth": lambda: bool(_openings_seen(look)),
        "phantom_letter": lambda: bool(m.mark_places) and bool(look.list_of("marks_seen")),
        "stop_answers_without_a_stops_view": lambda: bool(look.list_of("stops_seen")),
        "inside_a_body_with_no_interior": lambda: not m.has_passage and m.representation != "unknown",
        "called_solid_but_the_file_has_a_passage": lambda: m.has_passage,
        "denied_over_an_obstruction_mark": lambda: (m.has_passage and bool(m.mark_places)
                                                    and look.stance.get("verdict") == "denies"),
        "denied_over_a_restriction": lambda: (restriction_verdict(m.profile)[0] != "unreadable"
                                              and look.stance.get("verdict") == "denies"),
        "asserted_over_a_clear_bore": lambda: (m.has_passage and bool(m.mark_places)
                                               and restriction_verdict(m.profile)[0] != "unreadable"
                                               and look.stance.get("verdict") == "names"),
        "mark_read_against_the_picture": lambda: bool(m.mark_places) and bool(look.list_of("marks_seen"))
                                                 and mark_is_solid("void", m.representation) is not None,
        "the_letters_say_the_representation_is_wrong":
            lambda: sum(_letter_tally(m, look)[:2]) >= MIN_LETTERS_FOR_REPRESENTATION,
        "stop_panel_denied": lambda: bool(m.stopped) and bool(look.list_of("stops_seen")),
        "defect_on_a_file_the_loader_calls_clean": lambda: bool(look.list_of("defects")),
        "long_axis_named_wrong": lambda: _LONG_AXIS_ONLY(look.text_of("orientation")) is not None,
        "denies_everywhere_but_names_something": lambda: bool(look.stance.get("mixed")),
        "a_mouth_answered_twice_differently": lambda: len(_openings_seen(look)) > 1,
        "a_cap_given_a_flow_role": lambda: bool(_openings_seen(look)),
        "solid_throughout_but_a_port_named": lambda: bool(look.says_solid),
        "mouths_left_unanswered": lambda: bool(m.labelled),
        "stop_panels_left_unanswered": lambda: bool(m.stopped),
        "taper_left_unnamed": lambda: m.profile.readable,
        "two_looks_disagree_about_the_inside": lambda: True,
        "two_looks_disagree_about_a_letter": lambda: bool(look.list_of("marks_seen")),
    }
    gate = gates.get(signal_id)
    if gate is None:
        raise KeyError(f"no eligibility gate is written down for {signal_id!r}")
    return bool(gate())
