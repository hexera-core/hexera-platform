"""Read-only tools over GeometryFacts. Every number they return is recorded, and the plan may only use recorded numbers."""
from __future__ import annotations

import inspect
import json
import math
import re
from dataclasses import dataclass, field
from typing import Any

from geometry_agent import observe
from geometry_agent.agent import catalog
from geometry_agent.facts.schema import Fidelity, GeometryFacts, Purpose

SUBMIT = "submit_geometry_plan"
#: Edits the last submitted plan at JSON-pointer paths and re-runs the checker, so a rejection costs one small
#: turn instead of a full resubmission. The loop executes it (like SUBMIT); it is not in HANDLERS.
AMEND = "amend_geometry_plan"
PLAN_TOOLS = frozenset({SUBMIT, AMEND})


#: How deep `call_numbers` walks a result, and how many numbers it keeps from one call. A tool result is a tree
#: and the log is read, not searched: the numbers a refuting test names sit at the top of it.
CALL_NUMBER_DEPTH = 3
CALL_NUMBER_LIMIT = 64
#: A logged call says who ran it. Absent means the model asked for it; `facts_packet` means the packet ran it to
#: build the opening message, so its reading was in front of the model before the first turn.
VIA = "via"
PACKET_VIA = "facts_packet"


def call_numbers(result: Any, limit: int = CALL_NUMBER_LIMIT) -> dict[str, float]:
    """Every number a tool result carries, by the name it carries it under (`features.min_wall_thickness`,
    `half_angle_deg`), for the log of what a call returned.

    A list contributes its length as `<name>.count` and its entries are not walked: "how many ports are there"
    is what a refuting test reads off `list_openings`, and a 2,000-opening assembly would otherwise fill the log
    with numbers no sentence names."""
    out: dict[str, float] = {}

    def walk(node: Any, prefix: str, depth: int) -> None:
        if not isinstance(node, dict):
            return
        for k, v in node.items():
            if len(out) >= limit:
                return
            name = f"{prefix}{k}"
            if isinstance(v, bool) or v is None:
                continue
            if isinstance(v, (int, float)):
                if math.isfinite(float(v)):
                    out[name] = float(v)
            elif isinstance(v, (list, tuple)):
                out[f"{name}.count"] = float(len(v))
            elif isinstance(v, dict) and depth < CALL_NUMBER_DEPTH:
                walk(v, f"{name}.", depth + 1)
    walk(result, "", 0)
    return out


@dataclass
class Ledger:
    numbers: set[float] = field(default_factory=set)
    ids: set[str] = field(default_factory=set)
    calls: list[str] = field(default_factory=list)
    #: Every derived_geometry and compare_roles result by derivation id (d1, d2, ...): op, formula, inputs and the
    #: values at full precision, so the checker can hold a plan to the number the tool actually produced.
    derivations: dict[str, dict] = field(default_factory=dict)
    #: The same calls as `calls`, with what each was asked and what it returned: {tool, args, numbers, op,
    #: derivation_id, error}. `calls` is the names alone and stays what it was; this is the log a rule reads when
    #: it has to say whether a named test was run and what reading it gave (P4.3e, `ledger_calls`).
    call_log: list[dict] = field(default_factory=list)

    def log_call(self, tool: str, args: Any, result: Any) -> dict:
        """Record one call in `call_log` and return the entry. A derived call logs its op and derivation id, and
        its numbers are the derivation's own values (the ledger holds those at full precision); every other call
        logs the numbers of its result. A result carrying `error` measured nothing, and its entry says so."""
        entry: dict[str, Any] = {"tool": tool, "args": args if isinstance(args, dict) else {}}
        res = result if isinstance(result, dict) else {}
        if res.get("error"):
            entry["numbers"] = {}
            entry["error"] = str(res["error"])[:200]
        elif tool in (DERIVED, COMPARE_ROLES):
            entry["op"] = str(res.get("op") or (args or {}).get("op") or tool)
            entry["derivation_id"] = res.get("derivation_id")
            entry["numbers"] = call_numbers(res.get("values") if "values" in res else res)
        else:
            entry["numbers"] = call_numbers(res)
        self.call_log.append(entry)
        return entry

    def record(self, obj: Any) -> None:
        if isinstance(obj, bool):
            return
        if isinstance(obj, (int, float)):
            self.numbers.add(float(obj))
        elif isinstance(obj, str):
            if obj and (obj[0] in "okrtd") and obj[1:].isdigit():
                self.ids.add(obj)
        elif isinstance(obj, dict):
            for v in obj.values():
                self.record(v)
        elif isinstance(obj, (list, tuple)):
            for v in obj:
                self.record(v)

    def derive(self, op: str, formula: str, inputs: dict, values: dict) -> str:
        """Record one derivation and return its id. The values enter the ledger's numbers at full precision (the
        tool result the model sees is rounded like every other), so a plan may cite either form."""
        did = f"d{len(self.derivations) + 1}"
        self.derivations[did] = {"op": op, "formula": formula, "inputs": inputs, "values": values}
        self.ids.add(did)
        self.record(values)
        return did


@dataclass
class ToolContext:
    #: THE FACTS THIS RUN PRICES ON, and they are priced for THIS run's purpose.
    #:
    #: The measurement happens once, at upload, and the survey re-measures nothing by design, so the two
    #: purpose-dependent things in it (`cell_estimates` and the mixed-scale warnings) were whatever the upload
    #: asked for. `SURVEYED_PURPOSES` includes `external_cfd`, and the external branch of `estimate_cells` is a
    #: different domain with a far-field cell four levels coarser, so an external job was priced on internal
    #: counts. `__post_init__` recomputes both from the document's own numbers, which re-reads nothing, and where
    #: the document's estimate cannot be reproduced it is left alone with a warning that says so
    #: (`facts.measure.priced_for`).
    facts: GeometryFacts
    purpose: Purpose
    fidelity: Fidelity
    cell_cap: int | None
    declared: list[dict] | None
    brief: str
    ledger: Ledger = field(default_factory=Ledger)
    render_dir: str | None = None
    _mesh: Any = None
    #: A VisionClient when the run looks at the part; None keeps look_at_views out of the tool list and leaves
    #: the opening message byte for byte what it is without vision.
    vision: Any | None = None
    vision_calls: int = 0
    #: The scrubbed description this run is leaning on, and every number any look's raw reply carried, so the
    #: checker can say "came from the visual impression" when one of them turns up in a plan.
    #:
    #: It is the opening look's description, and where that failed it is the first follow-up's, because what the
    #: cap (R38) and the builder's block must both key off is whether the analyst HAS a description, not which
    #: call fetched it. It was the opening look's alone until 2026-09-14, and a run whose opening look failed and
    #: whose follow-up succeeded then read as a run that never looked: the plan could rest its identity on a
    #: picture at any confidence and the builder was never told what the run saw.
    vision_impression: dict | None = None
    #: What answered, for the plan's `visual_impression` and the stamp. Public because two other modules want
    #: them and neither should be reaching into `_vision_result`.
    vision_model: str = ""
    vision_provider: str = ""
    #: The renderer's own record of WHERE the pictures pointed, for the look that became the run's standing
    #: description: `{"marks": [{"id": "A", "cut": 1, "kind": ..., "point": [...]}], "stops": [...]}`. It is a
    #: measurement and not a word the model wrote. It travels because `marks_seen` and `stops_seen` are the two
    #: look fields that carry a subject, and a subject is worth nothing downstream without the table that says
    #: where the subject is. `vision.place` makes the join and refuses where it cannot.
    vision_drawn: dict | None = None
    vision_numbers: set[float] = field(default_factory=set)
    #: What the opening look returned (the tool result shape), so a bare repeat of look_at_views is answered from
    #: it for nothing, and `vision_error` is why it did not happen when it did not.
    _vision_result: dict | None = None
    vision_error: str | None = None
    #: Every look this run has taken, keyed by (question, focus_opening_id). The opening look is the ("", "") key;
    #: a follow-up with a question of its own is a different key and is really asked, up to MAX_LOOKS.
    _vision_answers: dict[tuple[str, str], dict] = field(default_factory=dict)
    #: The keys of looks the run gave up waiting on. Their threads are abandoned, not killed, so one may still
    #: answer after the opening message has gone out; the words it brings are cached for a later repeat but they
    #: are never made the run's standing description, which the analyst never saw.
    _vision_abandoned: set[tuple[str, str]] = field(default_factory=set)
    #: Case memory (dev plan P7). `memory` is a provider with one method, `block_for(ctx) -> dict | None`
    #: (geometry_agent.learn.memory.CaseMemory); None keeps memory off and no block is built. `memory_block` is
    #: what was shown, for the trace and the ledger, and `memory_numbers` is every number it showed.
    #:
    #: `memory_numbers` is a SEPARATE set and is never merged into `ledger.numbers`: a number from another part
    #: is not a measurement of this one, so it stays untraceable and the checker refuses it, naming memory as
    #: where it came from (`numbers_from_memory`, MEMORY_UNTRACED_REASON).
    memory: Any | None = None
    memory_block: dict | None = None
    #: True when this run is step 5 of the wired chain (`loop.run_loop(..., given=ChainGiven)`). The chain costs the
    #: plan on the builder emulator at the third intake (`ask.trade`), so the refinement-ball estimate
    #: (`refined_cell_estimate`, median 1.86x the delivered cells, max 576x) is neither shown to the model nor
    #: written into the plan, where R36 would raise a budget question from it (work/z-chain NEEDS 2 and 3).
    chain_attached: bool = False

    memory_numbers: set[float] = field(default_factory=set)
    #: The plan object as the model last submitted it (kept after a rejection); amend_geometry_plan edits this.
    last_plan: dict | None = None
    #: Whether that plan is what a cut-off submission left (loop.salvage_json closed it off). The checker reads it
    #: so the amend that finishes the plan is judged as the same truncation, not as a second fault of the model's
    #: (grounding.check_with_hints `salvaged`, R32).
    last_plan_salvaged: bool = False
    #: The result each detail tool returned while `facts_packet` built the opening message, by tool name. A probe
    #: whose answer is in there is answered from it (`packet_answer`) instead of measured again: the model already
    #: has the numbers, so the call costs no measurement time. The loop prunes it to what the message carried.
    packet_answers: dict[str, dict] = field(default_factory=dict)
    #: The names of the calls answered that way, in order, for the trace.
    echoed_calls: list[str] = field(default_factory=list)
    #: A PERSON'S answer to which side of the surface is the fluid (`catalog.FLUID_SIDES`), when the survey could
    #: not settle it and intake asked. Every `catalog.representation` call on this context passes it, so the
    #: geometry agent reads the part the way the customer said and never re-decides it. None on every run that did
    #: not ask. The side is read on every run now, so this is the case where the reading settles nothing.
    fluid_side: str | None = None

    #: A number the user wrote may be quoted back in another unit (25 mm as 0.025 m, 4 in as 0.1016 m or 101.6 mm).
    BRIEF_UNIT_FACTORS = (1.0, 1e-3, 1e3, 1e-2, 1e2, 0.0254, 1 / 0.0254, 0.3048, 1 / 0.3048, 25.4, 1 / 25.4, 304.8, 1 / 304.8)

    def __post_init__(self):
        # THE PRICE IS FOR THIS JOB'S PURPOSE, first, because everything below and every tool above reads
        # `self.facts`. `measure` computed the estimate for whatever purpose the upload named and never again
        from geometry_agent.facts import measure as facts_measure
        self.facts = facts_measure.priced_for(self.facts, self.purpose)
        # every reader here (the checker, the catalog, the reference policy, the port binding) compares a row's
        # `near` with a centroid in the file's own numbers; a row intake wrote in millimetres is converted once,
        # here, when the file's unit is known (catalog.in_file_units, work/z-chain NEEDS 4)
        if self.declared:
            self.declared = catalog.in_file_units(self.declared, self.facts)
        for src in (self.brief or "", json.dumps(self.declared or [])):
            for tok in re.findall(r"-?\d+(?:\.\d+)?(?:[eE]-?\d+)?", src):
                try:
                    v = float(tok)
                except ValueError:
                    continue
                for f in self.BRIEF_UNIT_FACTORS:
                    self.ledger.numbers.add(round(v * f, 9))

    def mesh(self):
        if self._mesh is None:
            from pathlib import Path

            from geometry_agent.facts.load import load_mesh
            self._mesh = load_mesh(Path(self.facts.source_path))
        return self._mesh


def _round(obj: Any, nd: int = 6) -> Any:
    if isinstance(obj, bool):
        return obj
    if isinstance(obj, float):
        return round(obj, nd)
    if isinstance(obj, dict):
        return {k: _round(v, nd) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_round(v, nd) for v in obj]
    return obj


#: A derived number keeps at least this many significant figures (and the six decimals every tool result keeps):
#: a first cell of 2.3456e-5 m rounded to six decimals is 0.000023, two percent off the number the ledger holds
#: under its derivation id, and the model can only cite what it sees. A magnitude under this is written as 0.
DERIVED_SIG_FIGS = 7
DERIVED_ZERO = 1e-12


def _round_derived(obj: Any) -> Any:
    """Six decimals, but never fewer than DERIVED_SIG_FIGS significant figures, so a small derived number stays
    within grounding.REL_TOL of the full-precision value recorded under its derivation id."""
    if isinstance(obj, bool):
        return obj
    if isinstance(obj, float):
        if obj == 0.0 or not math.isfinite(obj):
            return obj
        if abs(obj) < DERIVED_ZERO:
            return 0.0
        return round(obj, max(6, DERIVED_SIG_FIGS - 1 - math.floor(math.log10(abs(obj)))))
    if isinstance(obj, dict):
        return {k: _round_derived(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_round_derived(v) for v in obj]
    return obj


def get_facts_summary(ctx: ToolContext) -> dict:
    f = ctx.facts
    return {
        "facts_sha256": f.sha256,
        "format": f.source_format, "faces": f.faces, "watertight": f.watertight,
        "regions": len(f.regions), "total_volume": f.total_volume, "total_surface_area": f.total_surface_area,
        "walls_area": f.total_surface_area - sum(o.area for o in f.openings if o.kind != "ring"),
        "bbox_extent": f.bbox.extent, "bbox_diagonal": f.bbox.diagonal, "longest_axis": f.bbox.longest_axis,
        "bodies": f.bodies,
        "interfaces": [{"regions": [i.region_a, i.region_b], "area": i.area, "faces": i.faces} for i in f.interfaces],
        "openings": [
            {"id": o.id, "kind": o.kind, "class": o.classification, "shape": o.shape, "hydraulic_diameter": o.hydraulic_diameter,
             "area": o.area, "normal": o.normal, "on_bbox_face": o.on_bbox_face, "bbox_side": getattr(o, "bbox_side", None),
             "region": o.region_id, "bore_diameter": o.bore_diameter,
             "stub_over_diameter": (f.stub(o.id).length_over_diameter if f.stub(o.id) else None),
             "stub_ends_at": (f.stub(o.id).end_point if f.stub(o.id) else None),
             "stub_terminated_by": (f.stub(o.id).terminated_by if f.stub(o.id) else None)}
            for o in f.openings
        ],
        "thickness_min": f.features.thickness_min, "thin_clusters": len(f.features.thin_clusters),
        "knife_edges": f.features.knife_edge_count, "min_gap": f.features.min_gap,
        "principal_axis_0": f.axes.principal[0], "slenderness": f.axes.slenderness,
        "symmetry_planes": f.axes.symmetry_planes,
        "rotational_symmetry": ({"order": f.axes.rotational_order, "about_principal_axis": f.axes.rotational_axis,
                                 "score": f.axes.rotational_score} if f.axes.rotational_order else None),
        "blunt_end_sign": f.axes.blunt_end_sign, "blunt_end_confidence": f.axes.blunt_end_confidence,
        "unit_declared": f.units.declared, "unit_plausible": f.units.plausible_for_purpose.get(ctx.purpose, []),
        "names": [{"name": n.name, "implied_role": n.implied_role} for n in f.names[:20]],
        "cell_estimates": {e.tier: {"cells": e.cells, "base_size": e.base_size, "surface_cell": _surface_cell_of(e)}
                           for e in f.cell_estimates},
        "cell_cap": ctx.cell_cap, "purpose": ctx.purpose, "fidelity": ctx.fidelity,
        "user_brief": ctx.brief, "declared_ports": ctx.declared or [],
        "debris_components": getattr(f, "debris_components", 0),
        "non_manifold_edges": getattr(f.features, "non_manifold_edge_count", 0),
        "warnings": f.warnings,
    }


SURFACE_LEVELS = {"draft": 1, "standard": 2, "max": 3}


def _surface_cell_of(e) -> float:
    """The cell the tier puts on every surface: from the estimate when it carries it, else the tier rule."""
    hs = getattr(e, "surface_cell", 0.0) or 0.0
    return hs if hs > 0 else e.base_size / (2 ** SURFACE_LEVELS[e.tier])


#: Every float in the opening message is written to this many significant figures (packet v2, dev plan P4.1). A
#: four-figure copy sits within 5e-4 of the measurement, under grounding.REL_TOL, so the plan may cite it.
PACKET_SIG_FIGS = 4
#: A principal-axis or mirror-normal component under this is numerical noise and is written as 0.
AXIS_COMPONENT_SNAP = 1e-3
#: Summary keys the packet does not carry: the openings list (openings_detail holds every field of it), the brief
#: and the declared ports (both already in the user message, loop.opening_messages), and walls_area (derivable).
PACKET_CUTS = ("openings", "user_brief", "declared_ports", "walls_area")
#: The tiers the plan did not choose keep only these fields (their assumption lists say the same thing three times).
TIER_KEEP = ("tier", "cells", "base_size", "surface_cell")
AXIS_NAMES = ("x", "y", "z")
INTERNAL_PURPOSES = ("internal_cfd", "conjugate_heat_transfer")
REPRESENTATION_WORDS = {
    "wall_shell": "the file is the solid wall; the cavity is carved inside it and the ring bores are the ports",
    "fluid_domain": "the file is the fluid; its end caps are the ports",
    "annular_fluid": "an annular passage around a hub; the end rings are the ports",
    "external": "an external body in a far field; no ports",
    "unknown": "no port candidate measured",
}


def _sig(obj: Any, digits: int = PACKET_SIG_FIGS) -> Any:
    """Every float to `digits` significant figures, recursively; ints, bools and strings untouched."""
    if isinstance(obj, bool):
        return obj
    if isinstance(obj, float):
        if obj == 0.0 or not math.isfinite(obj):
            return obj
        return float(f"{obj:.{digits}g}")
    if isinstance(obj, dict):
        return {k: _sig(v, digits) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_sig(v, digits) for v in obj]
    return obj


def _snap_vector(v) -> list[float]:
    return [0.0 if abs(float(c)) < AXIS_COMPONENT_SNAP else float(c) for c in v]


def _g(x: Any) -> str:
    return f"{float(x):.{PACKET_SIG_FIGS}g}"


def mouth_tilt(o) -> tuple[float, str]:
    """Degrees between a mouth normal and the nearest coordinate axis, and that axis's name: the background hex
    grid is axis aligned, so a tilted circular mouth is cut stair-stepped."""
    n = [float(c) for c in o.normal]
    norm = math.sqrt(sum(c * c for c in n))
    if norm <= 0:
        return 90.0, "x"
    k = max(range(3), key=lambda i: abs(n[i]))
    return float(math.degrees(math.acos(min(1.0, abs(n[k]) / norm)))), AXIS_NAMES[k]


def mouth_shape(o, rep: str) -> str:
    """circle | rectangle | annulus | other: the outline the builder's grid has to cut at the mouth."""
    if o.kind == "ring" and rep == "annular_fluid":
        return "annulus"
    return {"circle": "circle", "rectangle": "rectangle"}.get(o.shape, "other")


def port_bore(o, rep: str) -> float:
    """The length the builder divides by cells_across: a ring's bore on a wall shell, the gap of an annulus, a
    cap's hydraulic diameter (the feature bank's definition, learn/features.port_bore)."""
    if o.kind == "ring" and o.bore_diameter:
        if rep == "annular_fluid":
            return max(0.0, float(o.hydraulic_diameter) - float(o.bore_diameter))
        return float(o.bore_diameter)
    return float(o.hydraulic_diameter or 0.0)


def min_in_plane_dim(o, rep: str) -> float:
    """The smallest in-plane dimension of the mouth (learn/features.min_in_plane_dim): a ring's bore scaled by the
    face's aspect, the gap of an annulus, the short side of a rectangle, the hydraulic diameter otherwise."""
    if o.kind == "ring" and o.bore_diameter:
        if rep == "annular_fluid":
            return max(0.0, (float(o.hydraulic_diameter) - float(o.bore_diameter)) / 2.0)
        lo, hi = min(o.width, o.height), max(o.width, o.height)
        return float(o.bore_diameter) * (lo / hi if hi > 0 else 1.0)
    return float(min(o.width, o.height) if (o.width and o.height) else (o.hydraulic_diameter or 0.0))


def _packet_opening_extras(o, rep: str, wall_cell: float, tilt_deg: float) -> dict:
    """The six per-opening fields packet v2 adds: the mouth's tilt off the grid and the axis it is nearest, whether
    it is grid-aligned under the calibrated threshold, its outline, its smallest in-plane dimension and how many
    builder wall cells (the inlet bore over 24) span its bore (the feature bank's cells_across_24)."""
    tilt, axis = mouth_tilt(o)
    bore = port_bore(o, rep)
    return {"tilt_deg": tilt, "grid_axis": axis, "grid_aligned": tilt < tilt_deg, "mouth_shape": mouth_shape(o, rep),
            "min_in_plane_dim": min_in_plane_dim(o, rep),
            "builder_cells_across_at_24": (bore / wall_cell) if (wall_cell > 0 and bore > 0) else None}


def _declared_inlet(ctx: ToolContext, rep: str):
    """The opening the user's declared inlet names (area within the catalog's band, `near` within its reach), so
    the builder frame is sized from the inlet the renderer will be given; None when none is declared or matched."""
    from geometry_agent.agent.thresholds import current as current_thresholds

    T = current_thresholds()
    facts = ctx.facts
    ports = _builder_ports(facts, rep)
    for d in ctx.declared or []:
        if not isinstance(d, dict) or d.get("role") != "inlet":
            continue
        best = None
        for o in ports:
            score = 0.0
            if d.get("area"):
                a = float(catalog.port_area(facts, o, rep))
                want = float(d["area"])
                if a <= 0 or want <= 0 or abs(a / want - 1.0) > T.AREA_MATCH_BAND:
                    continue
                score += abs(a / want - 1.0)
            if d.get("near"):
                scale = max(float(o.hydraulic_diameter or 0.0), float(o.bore_diameter or 0.0), 1e-12)
                dist = math.dist([float(c) for c in d["near"]], o.centroid)
                if dist > T.NEAR_MATCH_OVER_D * scale:
                    continue
                score += dist / scale
            if best is None or score < best[0]:
                best = (score, o)
        if best is not None:
            return best[1]
    return None


def _band_coverage(facts: GeometryFacts, rep: str, purpose: str, bores: list[float]) -> tuple[float | None, str]:
    """The fraction of the fluid volume inside the builder's near band (NEAR_BAND_OF_EXTENT of the extent, one
    level finer than the wall). No stage measures it, so it is an estimate and the method is named beside it
    (learn/features.band_coverage): the slab bound on a fluid body, the tube formula on a wall shell's port bores
    (its cavity is not measured), the band around the body over the far-field box for an external case."""
    t = NEAR_BAND_OF_EXTENT * max(facts.bbox.extent)
    if purpose == "external_cfd" or rep == "external":
        est = next((e for e in facts.cell_estimates if e.tier == "standard"), None)
        if est is not None and est.domain_volume > 0:
            return min(1.0, facts.total_surface_area * t / est.domain_volume), "surface area x band over the far-field volume"
        return None, "none"
    if rep == "wall_shell":
        fr = [1.0 - max(0.0, 1.0 - 2.0 * t / b) ** 2 for b in bores if b > 0]
        return (sum(fr) / len(fr) if fr else None), "tube formula on the port bores; the cavity itself is not measured"
    vol = facts.total_volume
    if vol and vol > 0:
        return min(1.0, facts.total_surface_area * t / vol), "surface area x band over the fluid volume"
    return None, "none"


def _junction_cluster(facts: GeometryFacts, ports: list, bores: dict[str, float]) -> tuple[list[str], list[float] | None]:
    """The largest set of stub end points lying within one bore of each other, and their mean: the junction the
    ports run into, read from the stubs alone."""
    ends = [(o.id, facts.stub(o.id).end_point) for o in ports if facts.stub(o.id) is not None and facts.stub(o.id).end_point]
    best: list[str] = []
    for a, pa in ends:
        members = [a] + [b for b, pb in ends if b != a and math.dist(pa, pb) <= max(bores.get(a, 0.0), bores.get(b, 0.0))]
        if len(members) > len(best):
            best = members
    if len(best) < 2:
        return [], None
    pts = [pe for oid, pe in ends if oid in best]
    return best, [sum(p[k] for p in pts) / len(pts) for k in range(3)]


def _packet_frame(ctx: ToolContext, rep: str, tilt_deg: float) -> tuple[dict, list[str]]:
    """The case in the builder's frame (numbers the SALIENT lines quote, so every one of them is in the ledger),
    and the SALIENT lines themselves: six to ten short lines computed by code, what a reader must know first."""
    f = ctx.facts
    internal = ctx.purpose in INTERNAL_PURPOSES
    external = ctx.purpose == "external_cfd"
    L = float(max(f.bbox.extent))
    band = NEAR_BAND_OF_EXTENT * L
    ports = catalog.port_openings(f, rep, ctx.declared) if not external else []
    bores = {o.id: port_bore(o, rep) for o in ports}
    inlet = _declared_inlet(ctx, rep) if internal else None
    frame = builder_frame(f, rep, None, inlet.id if inlet is not None else None) if internal else None
    wall_cell = float(frame["wall_cell"]) if frame else 0.0
    est = estimate_builder_cells(f, None, rep, "snappy", inlet.id if inlet is not None else None) if (internal or external) else None
    if external and est is not None:
        wall_cell = float(est["builder"].get("wall_cell") or 0.0)
    cap = int(ctx.cell_cap) if ctx.cell_cap else None
    cov, cov_method = _band_coverage(f, rep, ctx.purpose, list(bores.values()))
    thick = f.features.thickness_min
    junction_ids, junction_pt = _junction_cluster(f, ports, bores)
    tilted = [(o.id, mouth_tilt(o)[0]) for o in ports if mouth_shape(o, rep) == "circle" and mouth_tilt(o)[0] >= tilt_deg]
    tilted_other = [o.id for o in ports if mouth_shape(o, rep) != "circle" and mouth_tilt(o)[0] >= tilt_deg]
    smallest = min(ports, key=lambda o: bores[o.id]) if ports else None
    numbers: dict[str, Any] = {
        "representation": rep, "engine": "snappy", "inlet_id": (frame or {}).get("inlet_id"),
        "inlet_bore": (frame or {}).get("bore"), "cells_across": BUILDER_CELLS_ACROSS_DEFAULT, "wall_cell": wall_cell or None,
        "smallest_port_id": smallest.id if smallest else None,
        "smallest_bore": bores[smallest.id] if smallest else None,
        "smallest_bore_over_extent": (bores[smallest.id] / L) if (smallest and L > 0) else None,
        "near_band": band, "band_coverage_fraction": cov,
        "thin_over_wall_cell": (thick / wall_cell) if (thick and wall_cell > 0) else None,
        "tilted_circular_ids": [oid for oid, _ in tilted], "junction_ids": junction_ids, "junction_point": junction_pt,
        "cells_low": est["cells_low"] if est else None, "cells_high": est["cells_high"] if est else None,
        "cell_cap": cap, "high_over_cap": (est["cells_high"] / cap) if (est and cap) else None,
    }
    lines: list[str] = []
    unit = f.units.declared or "not declared"
    words = "a solid part; no flow is posed" if ctx.purpose == "structural" else REPRESENTATION_WORDS.get(rep, rep)
    lines.append(f"representation {rep}: {words}; {f.bodies} bod{'y' if f.bodies == 1 else 'ies'}, {f.faces:,} faces, unit {unit}")
    if external:
        faces = [o for o in f.openings if o.classification == "planar_face"]
        lines.append("no ports (external body)" + (": planar faces " + ", ".join(f"{o.id} ({o.bbox_side or 'off the box'})" for o in faces[:8])
                                                   if faces else "; no planar face"))
        ax = f.axes
        lines.append(f"extent L {_g(L)}, slenderness {_g(ax.slenderness)}, blunt end sign {ax.blunt_end_sign} (confidence "
                     f"{ax.blunt_end_confidence:.2f}), symmetry planes "
                     f"{list(ax.symmetry_planes) if ax.symmetry_planes is not None else 'not measured'}")
    elif ports:
        decl = " (declared inlet)" if inlet is not None else ""
        lines.append(f"{len(ports)} port openings: " + ", ".join(
            f"{o.id} {o.kind} bore {_g(bores[o.id])}" + (decl if inlet is not None and o.id == inlet.id else "") for o in ports[:12])
            + (f" (+{len(ports) - 12} more)" if len(ports) > 12 else ""))
    else:
        others = [o for o in f.openings if o.classification in ("planar_face", "ring", "hole")]
        lines.append("no port opening measured" + (f"; {len(others)} planar faces, rings or holes: " + ", ".join(o.id for o in others[:8])
                                                   if others else ""))
    if ports:
        if tilted:
            lines.append(f"mouths tilted over {tilt_deg:g} deg off the grid (the port cap is cut stair-stepped): "
                         + ", ".join(f"{oid} {_g(t)} deg" for oid, t in tilted[:8])
                         + (f"; non-circular mouths tilted too: {tilted_other[:6]}" if tilted_other else ""))
        else:
            lines.append(f"every circular mouth grid-aligned (under {tilt_deg:g} deg)"
                         + (f"; non-circular mouths tilted: {tilted_other[:6]}" if tilted_other else ""))
        d = bores[smallest.id]
        inside = "holds it entirely" if d < 2.0 * band else "does not hold it entirely"
        lines.append(f"smallest bore {smallest.id} {_g(d)} = {_g(d / L)} of the extent {_g(L)}; the builder's near band "
                     f"({NEAR_BAND_OF_EXTENT:g} of the extent, {_g(band)}) {inside}")
        if junction_ids:
            lines.append(f"junction: the stubs of {', '.join(junction_ids)} end within one bore of each other near "
                         f"[{', '.join(_g(c) for c in junction_pt)}]")
        else:
            ends = ", ".join(f"{o.id} {f.stub(o.id).terminated_by}" for o in ports[:8] if f.stub(o.id) is not None)
            lines.append("no junction from the stubs: no two stub ends lie within one bore of each other" + (f" (stubs end by {ends})" if ends else ""))
        legs = [(o.id, f.stub(o.id).length_over_diameter) for o in ports if f.stub(o.id) is not None and f.stub(o.id).terminated_by == "junction"]
        if legs:
            lines.append("dead-leg candidates (mouth to junction, if that mouth is closed): "
                         + ", ".join(f"{oid} {_g(ld)} D" for oid, ld in legs[:8]))
        else:
            lines.append("no stub runs into a junction, so no dead-leg candidate")
    n_cl = len(f.features.thin_clusters)
    if thick:
        cells = f" = {_g(thick / wall_cell)} wall cells (wall cell {_g(wall_cell)})" if wall_cell > 0 else ""
        if rep == "wall_shell":
            lines.append(f"{n_cl} thin cluster(s) are the shell's metal, not fluid: thinnest {_g(thick)}{cells}")
        elif n_cl == 0:
            lines.append(f"no thin cluster; thinnest wall-to-wall distance {_g(thick)}{cells}")
        elif external or ctx.purpose == "structural":
            lines.append(f"thin features of the body: {n_cl} cluster(s), thinnest {_g(thick)}{cells}")
        else:
            lines.append(f"thin fluid passages: {n_cl} cluster(s), thinnest {_g(thick)}{cells}")
    else:
        lines.append("no thin cluster or wall thickness measured")
    if cov is not None and (internal or external):
        volume = "the far-field volume" if external else "the fluid volume"
        lines.append(f"near band ({_g(band)} from the wall, one level finer): about {cov * 100:.0f}% of {volume}; "
                     f"estimated by {cov_method}")
    if est is not None:
        if frame and frame.get("inlet_id"):
            where = f"cells_across {BUILDER_CELLS_ACROSS_DEFAULT} on {frame['inlet_id']} bore {_g(frame['bore'])}"
        elif external:
            where = f"external, surface level {est['builder'].get('surface_level')}"
        else:
            where = "no port to size the bore from"
        low, high = int(est["cells_low"]), int(est["cells_high"])
        count = f"{low:,} to {high:,} cells" if high > low else f"about {high:,} cells"
        if high <= 0:
            lines.append(f"builder estimate (snappy, {where}): none; {est['basis'][0]}")
        elif cap:
            ratio = high / cap
            verdict = "over it: fewer cells across the inlet or a higher cap" if ratio > 1.0 else "under it"
            lines.append(f"builder estimate (snappy, {where}): {count} = {_g(ratio)}x the cap {cap:,}, {verdict}")
        else:
            lines.append(f"builder estimate (snappy, {where}): {count}; no cell cap given")
    else:
        lines.append(f"no builder cell estimate ({ctx.purpose}: not a snappy case); extent {[_g(v) for v in f.bbox.extent]}, "
                     f"diagonal {_g(f.bbox.diagonal)}, {len(f.openings)} openings measured")
    if ctx.purpose == "structural" or (f.bodies > 1 and not ports):
        lines.append("bodies: " + "; ".join(
            f"{r.id} {'nested in ' + r.nested_in if r.nested_in else 'outer'}, {r.faces:,} faces, watertight {r.watertight}"
            + (f", volume {_g(r.volume)}" if r.volume else "") for r in f.regions[:6])
            + (f" (+{len(f.regions) - 6} more)" if len(f.regions) > 6 else ""))
    lines.append(f"surface: watertight {f.watertight}, non-manifold edges {f.features.non_manifold_edge_count}, knife edges "
                 f"{f.features.knife_edge_count}, debris components {f.debris_components}, symmetry planes {list(f.axes.symmetry_planes) if f.axes.symmetry_planes is not None else 'not measured'}")
    return numbers, lines


def facts_packet(ctx: ToolContext) -> dict:
    """The summary plus every detail tool's result, for the opening message: one object, one ledger record.

    Packet v2 (dev plan P4.1, docs/plan_v2_rules.md): the summary's openings list, the brief, the declared ports
    and walls_area are cut, so are the assumption lists of the tiers not chosen and a rotational symmetry of
    order under 2; principal-axis components under 1e-3 are 0; every float is written to four significant
    figures (grounding.REL_TOL covers the copy). Each opening gains tilt_deg, grid_axis, grid_aligned,
    mouth_shape, min_in_plane_dim and builder_cells_across_at_24; the case gains `builder_frame` (the numbers
    in the builder's frame) and `salient` (six to ten lines computed by code).

    Every detail tool it runs is kept on the context under its own name (`ctx.packet_answers`), so a probe for
    something the packet already carries is answered from that copy instead of measured again (`packet_answer`),
    and each of those runs is a call in the ledger's log marked `via` facts_packet (P4.3e): the tool ran, and its
    reading was in front of the model before its first turn, so a rule that asks whether a test was run must see
    it. `keep_packet_calls` drops the ones the opening message did not carry."""
    import copy

    from geometry_agent.agent.thresholds import current as current_thresholds

    f = ctx.facts
    tilt_deg = float(current_thresholds().TILTED_MOUTH_DEG)
    rep = catalog.representation(f, ctx.purpose, ctx.brief, declared=ctx.declared, fluid_side=ctx.fluid_side)

    def keep(name: str, result: dict) -> dict:
        # a deep copy: the packet mutates what it is given (the summary's cuts, the snapped axes)
        ctx.packet_answers[name] = copy.deepcopy(result)
        ctx.ledger.log_call(name, {}, result)[VIA] = PACKET_VIA
        return result

    packet = keep("get_facts_summary", get_facts_summary(ctx))
    for key in PACKET_CUTS:
        packet.pop(key, None)
    order = int(f.axes.rotational_order or 0)
    if order < 2:
        packet.pop("rotational_symmetry", None)
    packet["principal_axis_0"] = _snap_vector(f.axes.principal[0])
    numbers, lines = _packet_frame(ctx, rep, tilt_deg)
    wall_cell = float(numbers.get("wall_cell") or 0.0) if ctx.purpose in INTERNAL_PURPOSES else 0.0
    listed = keep("list_openings", list_openings(ctx))
    packet["openings_detail"] = [{**row, **_packet_opening_extras(f.opening(row["id"]), rep, wall_cell, tilt_deg)}
                                 for row in listed["openings"]]
    if listed["groups"]:
        packet["opening_groups"] = listed["groups"]
    packet["regions_detail"] = keep("list_regions", list_regions(ctx))["regions"]
    packet["features"] = keep("get_features", get_features(ctx))["features"]
    axes = keep("get_axes", get_axes(ctx))["axes"]
    axes["principal"] = [_snap_vector(v) for v in axes["principal"]]
    axes["symmetry_normals"] = [_snap_vector(v) for v in axes.get("symmetry_normals") or []]
    if order < 2:
        for key in ("rotational_axis", "rotational_order", "rotational_score"):
            axes.pop(key, None)
    packet["axes"] = axes
    packet["names_detail"] = keep("get_names", get_names(ctx))["names"]
    packet["units"] = keep("get_unit_evidence", get_unit_evidence(ctx))["units"]
    packet["cell_estimates_detail"] = [e if e["tier"] == ctx.fidelity else {k: e[k] for k in TIER_KEEP}
                                       for e in keep("estimate_cells", estimate_cells(ctx))["estimates"]]
    packet["builder_frame"] = numbers
    packet["salient"] = lines
    return _sig(packet)


def _opening_row(ctx: ToolContext, o) -> dict:
    """One opening, every field the plan can cite, nothing the plan cannot use. Compact enough that 250 of
    them fit a tool result, so a microchannel plate does not lose ports to clipping."""
    s = ctx.facts.stub(o.id)
    row = {"id": o.id, "kind": o.kind, "classification": o.classification, "shape": o.shape, "region_id": o.region_id,
           "area": o.area, "hydraulic_diameter": o.hydraulic_diameter, "equivalent_diameter": o.equivalent_diameter,
           "width": o.width, "height": o.height, "centroid": o.centroid, "normal": o.normal, "tubularity": o.tubularity,
           "on_bbox_face": o.on_bbox_face, "bbox_side": getattr(o, "bbox_side", None), "bore_diameter": o.bore_diameter}
    row["stub"] = ({"length_over_diameter": s.length_over_diameter, "terminated_by": s.terminated_by, "end_point": s.end_point,
                    "inward_direction": s.inward_direction, "entry_area_ratio": s.entry_area_ratio} if s else None)
    return row


def opening_groups(ctx: ToolContext) -> list[dict]:
    """Openings that are geometrically the same (kind, class, region, bore within 2%, parallel normals), so a
    plate with 100 identical ports reads as one line, not 100."""
    groups: dict[tuple, list] = {}
    for o in ctx.facts.openings:
        n = tuple(round(v, 1) for v in o.normal)
        key = (o.kind, o.classification, o.region_id, o.shape, round(o.hydraulic_diameter, 2 if o.hydraulic_diameter > 1 else 4), n)
        groups.setdefault(key, []).append(o)
    out = []
    for key, members in groups.items():
        if len(members) < 3:
            continue
        stubs_ = [ctx.facts.stub(o.id) for o in members]
        stubs_ = [s.length_over_diameter for s in stubs_ if s]
        out.append({"count": len(members), "kind": key[0], "classification": key[1], "region_id": key[2], "shape": key[3],
                    "hydraulic_diameter": key[4], "normal": list(key[5]), "ids": [o.id for o in members],
                    "stub_over_d_range": [round(min(stubs_), 2), round(max(stubs_), 2)] if stubs_ else None})
    return out


def list_openings(ctx: ToolContext) -> dict:
    return {"openings": [_opening_row(ctx, o) for o in ctx.facts.openings], "groups": opening_groups(ctx)}


def get_opening(ctx: ToolContext, opening_id: str) -> dict:
    o = ctx.facts.opening(opening_id)
    if o is None:
        return {"error": f"no opening {opening_id!r}; known: {[x.id for x in ctx.facts.openings]}"}
    s = ctx.facts.stub(opening_id)
    return {"opening": o.model_dump(), "stub": s.model_dump() if s else None}


def list_regions(ctx: ToolContext) -> dict:
    return {"regions": [r.model_dump() for r in ctx.facts.regions]}


def get_features(ctx: ToolContext) -> dict:
    feats = ctx.facts.features.model_dump()
    # THE CHORD COVERAGE, SAID IN ONE WORD EACH (work/z-facts NEEDS 15). The two coverage records are how the
    # measurement proves what its minima covered, for a person auditing it; the model needs only whether each
    # minimum is exhaustive or an upper bound. Whole, they took the tee_wye_004 packet to 9,087 characters
    # against the dev plan's 9,000
    for key, short in (("thickness_coverage", "thickness_min_exhaustive"), ("gap_coverage", "min_gap_exhaustive")):
        cov = feats.pop(key, None)
        if isinstance(cov, dict):
            feats[short] = bool(cov.get("minimum_exhaustive"))
    return {"features": feats}


def get_axes(ctx: ToolContext) -> dict:
    return {"axes": ctx.facts.axes.model_dump()}


def get_names(ctx: ToolContext) -> dict:
    return {"names": [n.model_dump() for n in ctx.facts.names]}


def get_unit_evidence(ctx: ToolContext) -> dict:
    return {"units": ctx.facts.units.model_dump()}


def estimate_cells(ctx: ToolContext, tier: str | None = None, refinement_regions: list[dict] | None = None) -> dict:
    """Per-tier estimates, each with its surface cell. With `refinement_regions` (the plan's own list) the
    chosen tier's estimate is extended by what those regions add, so the budget conversation happens before
    the builder discovers it; the checker computes the same number into mesh_plan.cell_estimate_refined."""
    ests = [e for e in ctx.facts.cell_estimates if tier is None or e.tier == tier]
    out = {"estimates": [{**e.model_dump(), "surface_cell": _surface_cell_of(e)} for e in ests], "cell_cap": ctx.cell_cap,
           "note": "cells-across arithmetic divides by surface_cell (the cell the tier already puts on every surface), never by base_size"}
    if refinement_regions is not None and tier is not None:
        if getattr(ctx, "chain_attached", False):
            out["refined"] = None
            out["refined_not_given"] = ("the chain costs this plan on the builder emulator after you submit it and "
                                        "asks the customer once if it does not fit; the refinement-ball estimate is "
                                        "not given here because it has run at a median 1.86x the cells delivered")
        else:
            out["refined"] = refined_cell_estimate(ctx, tier, refinement_regions, patches=None)
    return out


FILL = 0.7


def box_volume(lo: Any, hi: Any) -> float | None:
    """The volume of the box two corners span, or None when either corner is not three numbers.

    A corner is not always three numbers. `bluff_body_001`, `wing_008` and `wing_011` of the learning-half run
    wrote a box corner as arithmetic (`"box_max": [94.44 + 5 * 188.94, ...]`), which is not JSON, and what
    reaches the estimate after the salvage is a two-component list. Indexing it raised `IndexError` out of
    `estimate_cells`, which `run_tool` catches nothing but `TypeError` from, and out of `_normalise`, which the
    checker has to return a verdict from. A box that is not a box adds no cells: that is the answer here, and the
    shape itself is reported where shapes are, by schema validation at `/mesh_plan/refinement_regions/i/box_max`
    (`facts.schema.Vec3`)."""
    corners = []
    for corner in (lo, hi):
        if not isinstance(corner, (list, tuple)) or len(corner) != 3:
            return None
        try:
            corners.append([float(v) for v in corner])
        except (TypeError, ValueError):
            return None
    a, b = corners
    return abs((b[0] - a[0]) * (b[1] - a[1]) * (b[2] - a[2]))


def refined_cell_estimate(ctx: ToolContext, tier: str | None, refinement_regions: list, patches: list | None) -> dict:
    """The tier estimate plus the cells each refinement region adds beyond the base cell already counted in its
    volume: a sphere or box of target size t holds FILL * V / t**3 cells, of which FILL * V / base**3 are already
    in the tier estimate; a surface region adds a band of three cells over the patch area at its target; a
    feature_edges region adds a band along the sharp edges. Deterministic, so the checker fills it in."""
    import math

    est = next((e for e in ctx.facts.cell_estimates if e.tier == tier), None)
    if est is None:
        return {"tier": tier, "cells": 0, "refined_cells": 0, "regions": []}
    base = est.base_size
    f = ctx.facts
    walls_area = f.total_surface_area - sum(o.area for o in f.openings if o.kind != "ring")
    area_of = {(p.get("id") if isinstance(p, dict) else p.id): (p.get("area") if isinstance(p, dict) else p.area)
               for p in (patches or [])}
    rows = []
    extra = 0
    for r in refinement_regions:
        d = r if isinstance(r, dict) else r.model_dump()
        t = float(d.get("target_size") or 0)
        if t <= 0:
            continue
        kind = d.get("kind") or "sphere"
        cells = 0
        if kind == "sphere" and d.get("radius"):
            v = 4 / 3 * math.pi * float(d["radius"]) ** 3
            cells = int(max(0.0, FILL * v * (1 / t**3 - 1 / base**3)))
        elif kind == "box" and d.get("box_min") and d.get("box_max"):
            v = box_volume(d["box_min"], d["box_max"])
            if v is None:
                # not a box: the corner the plan wrote is not three numbers, which schema validation reports at
                # its own path. It adds no cells, and the estimate returns a number rather than raising
                continue
            cells = int(max(0.0, FILL * v * (1 / t**3 - 1 / base**3)))
        elif kind == "surface":
            area = 0.0
            for pid in d.get("patch_ids") or []:
                a = area_of.get(pid) or 0.0
                area += a if a > 0 else (walls_area if pid in ("walls", "body", "wall") or str(pid).startswith("wall") else 0.0)
            cells = int(area * 3 / t**2)
        elif kind == "feature_edges":
            cells = int(f.features.sharp_edge_length * 3 * 3 / t**2) if f.features.sharp_edge_length else 0
        rows.append({"where": d.get("where"), "kind": kind, "target_size": t, "cells": cells})
        extra += cells
    return {"tier": tier, "cells": est.cells, "refined_cells": est.cells + extra, "regions": rows}


def list_risks(ctx: ToolContext, roles: dict[str, str] | None = None) -> dict:
    risks = catalog.detect_risks(ctx.facts, ctx.purpose, ctx.fidelity, ctx.cell_cap, ctx.declared, roles, brief=ctx.brief,
                                 fluid_side=ctx.fluid_side)
    return {"roles_applied": roles is not None, "risks": [r.model_dump() for r in risks]}


def probe_section(ctx: ToolContext, opening_id: str, distance_over_d: float) -> dict:
    """Cross-section `distance_over_d` diameters inward from an opening: loop count, area, centroid, area ratio."""
    import numpy as np

    from geometry_agent.facts.regions import region_meshes
    from geometry_agent.facts.stubs import _inward, _section

    o = ctx.facts.opening(opening_id)
    if o is None:
        return {"error": f"no opening {opening_id!r}"}
    if not (0 <= float(distance_over_d) <= 50):
        return {"error": "distance_over_d must be between 0 and 50"}
    mesh = ctx.mesh()
    parts = region_meshes(mesh)
    idx = int(o.region_id[1:]) - 1
    part = parts[idx] if 0 <= idx < len(parts) else mesh
    d = o.hydraulic_diameter
    direction = _inward(part, o)
    origin = np.asarray(o.centroid) + float(distance_over_d) * d * direction
    loops, area, cen, total = _section(part, origin, direction, 1.5 * d)
    return {"opening_id": opening_id, "distance_over_d": float(distance_over_d), "loops_near": loops,
            "loops_total": total, "area": area, "area_over_opening_area": (area / o.area if o.area else None),
            "centroid": (tuple(float(v) for v in cen) if cen is not None else None),
            "inward_direction": tuple(float(v) for v in direction)}


def section_profile(ctx: ToolContext, opening_id: str, max_over_d: float = 15.0, step_over_d: float = 0.5) -> dict:
    """Cross-section area against distance inward from an opening, one call: the shape of a diffuser, nozzle,
    venturi or expansion read as a curve, instead of one probe_section per station."""
    import numpy as np

    from geometry_agent.facts.regions import region_meshes
    from geometry_agent.facts.stubs import _inward, _section

    o = ctx.facts.opening(opening_id)
    if o is None:
        return {"error": f"no opening {opening_id!r}"}
    max_over_d = float(min(max(max_over_d, 0.5), 50.0))
    step_over_d = float(min(max(step_over_d, 0.1), 5.0))
    mesh = ctx.mesh()
    parts = region_meshes(mesh)
    idx = int(o.region_id[1:]) - 1
    part = parts[idx] if 0 <= idx < len(parts) else mesh
    d = o.hydraulic_diameter
    direction = _inward(part, o)
    stations = []
    k = step_over_d
    while k <= max_over_d + 1e-9:
        loops, area, cen, total = _section(part, np.asarray(o.centroid) + k * d * direction, direction, 1.5 * d)
        stations.append({"distance_over_d": round(k, 3), "loops": loops,
                         "area_over_opening_area": round(area / o.area, 4) if o.area and loops else 0.0,
                         "centroid": (tuple(round(float(v), 6) for v in cen) if cen is not None else None)})
        if loops == 0 and total == 0:
            break
        k += step_over_d
    ratios = [s["area_over_opening_area"] for s in stations if s["loops"] == 1]
    out = {"opening_id": opening_id, "inward_direction": tuple(float(v) for v in direction), "stations": stations,
           "area_ratio_min": min(ratios) if ratios else None, "area_ratio_max": max(ratios) if ratios else None,
           "single_loop_stations": len(ratios), "note": "area ratios are relative to the opening; loops > 1 means a junction"}
    out.update(_taper(stations, d))
    return out


TAPER_BAND = 0.10


def _taper(stations: list[dict], d: float) -> dict:
    """Where the section area starts and stops changing along the profile, and what that means: the taper's
    length, half angle (from the equivalent diameters at both ends) and area ratio, the throat station and the
    velocity ratio there. Read from single-loop stations only."""
    import math

    single = [(s["distance_over_d"], s["area_over_opening_area"]) for s in stations if s["loops"] == 1 and s["area_over_opening_area"] > 0]
    if len(single) < 2:
        return {"taper": None, "min_area_station": None, "velocity_ratio_at_throat": None}
    k_min, a_min = min(single, key=lambda t: t[1])
    start = next((k for k, a in single if abs(a - 1.0) > TAPER_BAND), None)
    taper = None
    if start is not None:
        after = [(k, a) for k, a in single if k >= start]
        end_k, end_a = after[-1]
        for i in range(1, len(after)):
            if abs(after[i][1] - after[i - 1][1]) <= 0.02 * max(after[i - 1][1], 1e-9):
                end_k, end_a = after[i - 1]
                break
        prev = max((k for k, _ in single if k < start), default=0.0)
        L = (end_k - prev) * d
        d_start, d_end = d, d * math.sqrt(end_a)
        half = math.degrees(math.atan(abs(d_end - d_start) / 2 / L)) if L > 0 else None
        taper = {"start_over_d": prev, "end_over_d": end_k, "length": round(L, 6), "area_ratio": round(end_a, 4),
                 "half_angle_deg": round(half, 2) if half is not None else None,
                 "kind": "diffuser" if end_a > 1 else "contraction"}
    return {"taper": taper, "min_area_station": k_min,
            "velocity_ratio_at_throat": round(1.0 / a_min, 3) if a_min > 0 else None}


def distance_between(ctx: ToolContext, opening_a: str, opening_b: str) -> dict:
    import numpy as np

    a, b = ctx.facts.opening(opening_a), ctx.facts.opening(opening_b)
    if a is None or b is None:
        return {"error": "unknown opening id"}
    d = float(np.linalg.norm(np.asarray(a.centroid) - np.asarray(b.centroid)))
    dot = float(np.dot(a.normal, b.normal))
    return {"a": opening_a, "b": opening_b, "distance": d,
            "distance_over_a_diameter": d / a.hydraulic_diameter if a.hydraulic_diameter else None,
            "normals_dot": dot, "facing": "opposed" if dot < -0.9 else ("parallel" if dot > 0.9 else "angled"),
            "same_region": a.region_id == b.region_id}


def render_view(ctx: ToolContext, direction: str, focus_opening_id: str | None = None) -> dict:
    try:
        from geometry_agent.render import render_direction
    except ImportError:
        return {"error": "rendering unavailable (install the 'render' extra)"}
    if not ctx.render_dir:
        return {"error": "no render directory configured for this run"}
    focus = ctx.facts.opening(focus_opening_id).centroid if focus_opening_id and ctx.facts.opening(focus_opening_id) else None
    path = render_direction(ctx.facts.source_path, direction, ctx.render_dir, focus=focus)
    return {"image_path": str(path), "direction": direction, "focus": focus,
            "note": "axis arrows: red +X, green +Y, blue +Z; openings labelled by id"}


LOOK = "look_at_views"
VISION_CAVEAT = ("a visual impression of the rendered views; nothing here is a measurement, and the measured "
                 "classes and numbers stand")
#: Real calls to the vision model in one run: the look the run opens with, and at most one follow-up the analyst
#: asks for itself. A repeat with nothing new to ask is answered from what the opening look already said.
MAX_LOOKS = 2
#: What a look past the cap is told. It is not an error: the description it wants is already in front of it.
LOOKS_SPENT = ("this run has already looked at the part {n} times, which is the limit; the description you have is "
               "what the views show")


def look_at_views(ctx: ToolContext, question: str | None = None, focus_opening_id: str | None = None) -> dict:
    """What the geometry agent's model is SHOWN of a look: `_look_at_views`' result with the impression passed
    through `vision.trust.model_safe`, so a field the ledger tiers `recorded` (defects, notes, orientation,
    symmetry, each opening's guessed class and role) is absent, never emptied. The run keeps the whole record
    (`ctx._vision_answers`, `ctx.vision_impression`), which is what the stored document and the trace read; what
    the model writes from the look reaches the builder in `builder_block`, so the model is the channel that has
    to be closed (work/z-deliver NEEDS 5). `loop.attach_look` calls this, so the opening message is closed too."""
    return shown_to_model(_look_at_views(ctx, question, focus_opening_id))


def shown_to_model(result: dict) -> dict:
    """A look result as a model may read it: the impression reduced to `trust.model_safe`, with no prediction of
    how the mesh turns out left in it, and everything else as is.

    THE SECOND DOOR INTO THIS MODEL, and it was open while the first was being shut. `vision.trust.for_model`
    takes a predicting phrase out of the TIERED dict, which is what `chain.job.given_text` puts in the geometry
    agent's prompt; this path hands the agent the impression in its own shape instead, so the same words reached
    the same model by the tool and by the opening message. The Surveyor never says how the mesh will turn out,
    and what this model writes from the look reaches the builder in `builder_block`.

    THE NOTE RIDES ON THE RESULT AND NOT INSIDE THE IMPRESSION, because the impression is a fixed record with a
    fixed renderer (`vision.prompt.impression_block` prints the fields it knows and ignores the rest), so a key
    added inside it would be a list silently shortened. `seen_refused` is the name the survey block and the
    composed look already use for this, with the same two halves.
    """
    if not isinstance(result, dict) or not isinstance(result.get("impression"), dict):
        return result
    from geometry_agent.contract.survey import drop_outcome_claims
    from geometry_agent.vision import trust
    safe, dropped = drop_outcome_claims(trust.model_safe(result["impression"]))
    out = {**result, "impression": safe}
    if dropped:
        out["seen_refused"] = {"fields": sorted({p.split("[")[0].split(".")[0] for p in dropped}),
                               "why": trust.PREDICTS_REFUSED_WHY}
    return out


def _look_at_views(ctx: ToolContext, question: str | None = None, focus_opening_id: str | None = None) -> dict:
    """A vision model's words-only impression of the cached renders of the part.

    The run opens with one of these (`loop.attach_look`), so by the time the analyst can call anything the
    description is already in the opening message beside the measurements. What the tool is for afterwards is the
    question a standing description cannot answer: a named opening, a specific doubt. A call that asks nothing new
    is answered from the opening look and costs nothing; a call with a question or a focus of its own is really
    asked, up to MAX_LOOKS in the run. `run_tool` records nothing from this tool in the ledger, so no number that
    only the picture produced can be cited by the plan."""
    from pathlib import Path

    from geometry_agent.vision import prompt as vprompt
    from geometry_agent.vision.render import DEFAULT_VIEWS, MAX_LABELS, cache_dir_for, read_manifest, render_views
    from geometry_agent.vision.terminus import mouths_from_openings, solid_from_representation

    if ctx.vision is None:
        return {"error": "no vision model is attached to this run; decide from the measurements"}
    if focus_opening_id and ctx.facts.opening(focus_opening_id) is None:
        return {"error": f"no opening {focus_opening_id!r}; known: {[o.id for o in ctx.facts.openings]}"}
    # keyed by what is being asked, so the opening look (nothing asked) answers every bare repeat for nothing and
    # a question of the analyst's own is a different question and is really asked
    key = ((question or "").strip(), (focus_opening_id or "").strip())
    if key in ctx._vision_answers:
        return {**ctx._vision_answers[key], "repeated": True}
    if ctx.vision_calls >= MAX_LOOKS:
        # the description the run is standing on, which is the opening look's unless that one failed: handing
        # back the opening look's error to an analyst that has a perfectly good description would tell it the
        # run cannot see when it can
        spent = dict(_standing_look(ctx))
        spent["note"] = LOOKS_SPENT.format(n=ctx.vision_calls)
        return {**spent, "repeated": True}

    views = list(DEFAULT_VIEWS)
    measured = [(o.id, tuple(o.centroid)) for o in ctx.facts.openings]
    # what kind of model this is, measured once here and used twice: the stops detector needs it to read a
    # mouth the right way round, and the message needs it so an external body does not come back with invented
    # ports. It used to be computed only for the message, further down
    rep = catalog.representation(ctx.facts, ctx.purpose, ctx.brief, declared=ctx.declared, fluid_side=ctx.fluid_side)
    # THE MEASUREMENT FEEDS THE VISION, which is the whole of the stops view: the detector turns on which
    # openings the measurement calls a way in or out and on whether the mesh is the material, and neither is
    # a thing a pile of triangles knows. `render_views` raises rather than drawing a blank panel when they are
    # missing, so this call passed nothing and worked only while the view was off by default. It is the
    # default since 2026-09-16 and it is passed here now
    mouths = mouths_from_openings(ctx.facts.openings)
    # THE PROMPT IS CHOSEN NOW, as the picture is: `render_views` reads the render switches at call time, and the
    # module-level `vprompt.SYSTEM` was fixed at import, so a process that set a switch after that would draw one
    # picture and describe another. `look.run_prompt` applies the bench's six guards and names the mismatch
    from geometry_agent.vision.look import run_prompt
    base, mismatch = run_prompt()
    if base is None:
        return _look_failed(ctx, key, mismatch, views)
    try:
        paths = render_views(ctx.facts.source_path, out_dir=ctx.render_dir, views=views, labels=measured,
                             mouths=mouths, solid=solid_from_representation(rep))
    # any failure, not only an expected one: a file this machine cannot render (the 402-body STEP exhausts its
    # memory before one triangle is drawn) is a look that did not happen, never a case with no result
    except Exception as exc:  # noqa: BLE001
        return _look_failed(ctx, key, f"rendering failed: {type(exc).__name__}: {str(exc)[:200]}", views)
    manifest = read_manifest(cache_dir_for(ctx.facts.source_path)) or {}
    labelled = manifest.get("labelled") or [oid for oid, _ in measured[:MAX_LABELS]]
    # the same per-part rule the bench runs under: a field whose picture this part does not have is not
    # described, and the empty picture goes with the words. `paths_for_part` is given the ORIGINAL view list,
    # because `render_views` returns one file per view in the order it was asked for, and `views` is rebound
    # only afterwards so that everything below names the views actually sent. All three are identities at the
    # shipped default, so nothing on this path changes until `GEOMETRY_AGENT_VISION_GHOST_FIELDS=off` is set
    # on purpose
    system = vprompt.system_for_part(manifest, base)
    paths = vprompt.paths_for_part(paths, views, manifest, base)
    views = vprompt.views_for_part(views, manifest, base)
    # the letters the strip drew, when it drew any, named in the message the way the opening ids are.
    # `marks_for_prompt` is what decides whether the message may name them, and it reads the system prompt in
    # hand rather than the environment, so a picture with violet letters on it and a prompt that has never
    # heard of one cannot be sent from here. The bench refuses that pair outright (`prompt.marks_mismatch`);
    # there is nothing here to refuse to, so the pairing is made by construction instead. The bench passed this
    # through from the day the marks existed and this call did not, which did not matter while nothing drew a
    # letter and mattered on every real run the moment they became the default. It is handed THIS PART'S
    # prompt and not the run's, for the same reason
    marks = vprompt.marks_for_prompt(manifest.get("marked"), system)
    # what kind of model this is, which the run measured and the picture cannot settle: a solid whose outside is
    # meshed, the fluid volume itself, or hardware with a cavity. Told to the model because without it every part
    # reads as internal flow and an external body comes back with invented ports (vision/prompt.MODEL_KIND)
    user = vprompt.user_prompt(views, labelled, question=question, focus_opening_id=focus_opening_id,
                               marks=marks,
                               file_name=Path(ctx.facts.source_path).name,
                               representation=rep)
    ctx.vision_calls += 1
    try:
        reply = ctx.vision.describe(paths, user, system=system)
    # the vision adapters read a provider's JSON the way the text client used to, and an AttributeError from a
    # reply of the wrong shape would leave the case with no result at all rather than a look that did not work
    except Exception as exc:  # noqa: BLE001
        return _look_failed(ctx, key, f"the vision model failed: {type(exc).__name__}: {str(exc)[:300]}", views)
    # WHAT `look.py` REFUSES, refused here too (work/z-vision NEEDS 2): a reply cut off at the ceiling or withheld
    # by the provider, a reply that is not the JSON object the prompt asks for, and one that left out a field it
    # asked. Each used to become the run's standing impression, and an absent `internal_features` reads as a
    # plain passage. The client already raises on a cut-off reply; `refusal` holds a client written elsewhere to it
    from geometry_agent.vision import client as vision_client
    problem = vision_client.refusal(reply) or vprompt.reply_problem(getattr(reply, "text", "") or "", system)
    if problem:
        return _look_failed(ctx, key, f"the look was refused: {problem}", views)
    impression, numbers = vprompt.impression_from_reply(reply.text)
    # every look's numbers, not only the first: a follow-up carries digits the checker has to be able to name too
    ctx.vision_numbers |= set(numbers)
    result = {"impression": impression, "views": views, "model": reply.model, "provider": reply.provider,
              "caveat": VISION_CAVEAT, "system": system}
    if manifest.get("warning"):
        result["render_warning"] = manifest["warning"]
    ctx._vision_answers[key] = result
    if ctx._vision_result is None:
        ctx._vision_result = result
    if ctx.vision_impression is None and key not in ctx._vision_abandoned:
        # the run's standing description, which is the opening look's on every ordinary run. The one run where
        # this is not the same thing is the one whose opening look failed: the analyst asked again, got words,
        # and has them in front of it. The cap must see that (a plan may not rest an identity on a picture) and
        # the builder must be told what the run saw. Only an abandoned look's late answer is refused, because
        # that is the one description nobody in the run has read.
        ctx.vision_impression = impression
        ctx.vision_model, ctx.vision_provider = str(reply.model or ""), str(reply.provider or "")
        # the manifest of the SAME render this look read, taken here rather than re-read later: a second read
        # could pick up a cache another call rewrote, and then a finding would be placed at a letter from a
        # different picture
        ctx.vision_drawn = {"marks": list(manifest.get("mark_places") or []),
                            "stops": list(manifest.get("stop_places") or manifest.get("stopped") or [])}
    return result


def _look_failed(ctx: ToolContext, key: tuple[str, str], reason: str, views: list[str]) -> dict:
    """A look that did not work, cached like one that did: a model cannot burn its rounds retrying it, and the
    run says what went wrong rather than saying nothing."""
    result: dict = {"error": reason, "views": list(views), "caveat": VISION_CAVEAT}
    ctx._vision_answers[key] = result
    if ctx._vision_result is None:
        ctx._vision_result = result
        ctx.vision_error = reason
    return result


def opening_look(ctx: ToolContext) -> dict:
    """What the look the run opened with returned, or an empty mapping when the run has not looked. The trace
    reads this rather than the context's own field, so where the result is kept stays this module's business.

    This is the OPENING look specifically, error and all, because round 0 of the trace is a record of what
    happened at round 0. What the run ended up standing on is `_standing_look`."""
    return dict(ctx._vision_result or {})


def _standing_look(ctx: ToolContext) -> dict:
    """The result carrying the description the run is leaning on: the opening look's, or the first follow-up's
    when the opening look failed. Falls back to the opening look's result (the error) when there is none."""
    if ctx.vision_impression is not None:
        for result in ctx._vision_answers.values():
            if result.get("impression") is ctx.vision_impression:
                return result
    return dict(ctx._vision_result or {})


def look_abandoned(ctx: ToolContext, reason: str) -> dict:
    """The opening look, given up on: the loop calls this when the look outlived the share of the case budget it
    was allowed, or raised where nothing else catches.

    The thread it was made on is abandoned, not killed, because a blocking socket read cannot be interrupted from
    outside. Should it answer later it finds `_vision_result` already set and leaves it alone, so the plan's
    `visual_impression` can never carry a description the opening message did not; what it may still do is answer
    a later bare `look_at_views` with the words it finally got, which is better than nothing and is the same
    images either way."""
    from geometry_agent.vision.render import DEFAULT_VIEWS
    ctx._vision_abandoned.add(("", ""))
    return _look_failed(ctx, ("", ""), reason, list(DEFAULT_VIEWS))


# ---------------------------------------------------------------------------------------------------------------
# Case memory (dev plan P7). The block is built by geometry_agent.learn.memory and attached to the opening message
# by the loop; nothing here reaches into the learning loop. What lives here is the run's side of the contract: the
# numbers a block showed, held apart from the measurement ledger, and the sentence the checker uses to name one.
# ---------------------------------------------------------------------------------------------------------------
MEMORY_MODES = ("off", "on", "shuffled")
#: What the checker says about a plan number that is only a remembered case's. The wording matches the vision
#: reason it sits beside (grounding._untraced): both name where a number came from that was never measured here.
MEMORY_UNTRACED_REASON = (" (this number came from a remembered case, not from this part; only numbers measured on "
                          "this geometry may enter the plan)")


def numbers_from_memory(ctx: ToolContext) -> set[float]:
    """Every number the run's memory block showed. Empty when memory is off, so a checker that consults it costs
    nothing on a run without memory. These are deliberately not in `ctx.ledger.numbers`: they are measurements of
    other parts, and a plan that cites one is citing another geometry's millimetre."""
    return {float(v) for v in (getattr(ctx, "memory_numbers", None) or ())}


def memory_mode(ctx: ToolContext) -> str:
    """off, on or shuffled, for the result stamp and the ledger."""
    provider = getattr(ctx, "memory", None)
    mode = getattr(provider, "mode", None) if provider is not None else None
    return str(mode) if mode in MEMORY_MODES else "off"


# ---------------------------------------------------------------------------------------------------------------
# derived_geometry and compare_roles (dev plan P4.1): the arithmetic the model would otherwise do by hand, done by
# code. Every result is recorded in the ledger under a derivation id (d1, d2, ...) with its formula, so the plan
# cites the id and the checker (grounding._check_derived) holds it to the number the tool produced, and recomputes
# the formulas it knows when no id is cited.
# ---------------------------------------------------------------------------------------------------------------
DERIVED = "derived_geometry"
COMPARE_ROLES = "compare_roles"
DERIVED_OPS = ("port_tilt", "run_between", "dead_leg", "angle_between", "taper", "first_cell", "reynolds",
               "cells_across", "unit_convert", "eval")
UNIT_TO_M = {"m": 1.0, "mm": 1e-3, "cm": 1e-2, "um": 1e-6, "in": 0.0254, "ft": 0.3048}
UNIT_ALIASES = {"meter": "m", "metre": "m", "meters": "m", "metres": "m", "millimeter": "mm", "millimetre": "mm",
                "millimeters": "mm", "millimetres": "mm", "centimeter": "cm", "centimetre": "cm", "centimeters": "cm",
                "centimetres": "cm", "micron": "um", "microns": "um", "micrometre": "um", "micrometer": "um", "µm": "um",
                "μm": "um", "inch": "in", "inches": "in", "\"": "in", "foot": "ft", "feet": "ft", "'": "ft"}
#: Skin-friction laws a first-cell estimate may use, Cf = coeff x Re^exponent: the flat-plate turbulent power law
#: (the tool's, what every y+ calculator uses) and Blasius for pipe flow (Cf = f/4 with f = 0.316 Re^-0.25). They
#: differ by about 15 percent in the first cell, so the checker admits either when it recomputes a stated one.
CF_LAWS = {"flat_plate": (0.026, -1.0 / 7.0), "blasius": (0.079, -0.25)}
CF_COEFF, CF_EXPONENT = CF_LAWS["flat_plate"]
#: A stub end within this many bores of the junction point belongs to that junction.
JUNCTION_REACH_OVER_D = 1.5
#: A closed end behind the junction by more than this fraction of its bore, on the supply's own axis, is upstream.
UPSTREAM_OVER_D = 0.5
SEVERITY_WEIGHT = {"blocking": 8, "high": 4, "medium": 2, "low": 1, "info": 0}
_EVAL_MAX_CHARS = 400
_EVAL_MAX_EXPONENT = 64.0


def _unit_name(u: Any) -> str | None:
    s = str(u or "").strip().lower()
    s = UNIT_ALIASES.get(s, s)
    return s if s in UNIT_TO_M else None


def _file_unit(ctx: ToolContext) -> tuple[str, str]:
    """(unit, how): the file's declared unit, else the first unit plausible for the purpose, else metres, with
    the words the formula string states it in."""
    declared = _unit_name(ctx.facts.units.declared)
    if declared:
        return declared, "the unit the file declares"
    for u in ctx.facts.units.plausible_for_purpose.get(ctx.purpose, []):
        if _unit_name(u):
            return _unit_name(u), "assumed: the first unit plausible for the purpose (the file declares none)"
    return "m", "assumed: metres (the file declares no unit and none is plausible)"


def _in_ledger(ctx: ToolContext, x: Any) -> bool:
    """A number the model may feed into a derivation: measured, derived, or from the brief (grounding's rule)."""
    from geometry_agent.agent.grounding import _measured

    return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(float(x)) and _measured(float(x), ctx.ledger.numbers)


def _num_arg(ctx: ToolContext, args: dict, key: str, ledger: bool = False, positive: bool = True) -> float:
    v = args.get(key)
    if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(float(v)):
        raise ValueError(f"{key} must be a number, got {v!r}")
    if positive and float(v) <= 0:
        raise ValueError(f"{key} must be positive, got {v!r}")
    if ledger and not _in_ledger(ctx, v):
        raise ValueError(f"{key}={v!r} is not a measured number, a derived number or a number from the brief; take it from a tool result")
    return float(v)


def _opening_arg(ctx: ToolContext, args: dict, key: str):
    oid = args.get(key)
    o = ctx.facts.opening(str(oid)) if oid is not None else None
    if o is None:
        raise ValueError(f"{key}={oid!r} is not an opening; known: {[x.id for x in ctx.facts.openings]}")
    return o


def _point_arg(ctx: ToolContext, args: dict, key: str) -> tuple[Any, list[float], str, bool]:
    """(opening, point, label, is_stub_end) for 'o3' (the mouth centroid) or 'o3.stub_end' (its stub's end point)."""
    raw = str(args.get(key) or "")
    oid, _, tail = raw.partition(".")
    o = ctx.facts.opening(oid) if oid else None
    if o is None:
        raise ValueError(f"{key}={raw!r} is not an opening id or 'oN.stub_end'; known: {[x.id for x in ctx.facts.openings]}")
    if tail in ("stub_end", "end", "stub_ends_at"):
        s = ctx.facts.stub(o.id)
        if s is None or not s.end_point:
            raise ValueError(f"{o.id} has no measured stub end point")
        return o, [float(c) for c in s.end_point], f"{o.id} stub end", True
    if tail:
        raise ValueError(f"{key}={raw!r} is not an opening id or 'oN.stub_end' (the only suffix is .stub_end)")
    return o, [float(c) for c in o.centroid], f"{o.id} mouth", False


def _fmt_vec(v) -> str:
    return "[" + ", ".join(f"{float(c):.4g}" for c in v) + "]"


def _op_port_tilt(ctx: ToolContext, args: dict) -> tuple[dict, str, dict]:
    from geometry_agent.agent.thresholds import current as current_thresholds

    o = _opening_arg(ctx, args, "opening_id")
    rep = catalog.representation(ctx.facts, ctx.purpose, ctx.brief, declared=ctx.declared, fluid_side=ctx.fluid_side)
    tilt_deg = float(current_thresholds().TILTED_MOUTH_DEG)
    tilt, axis = mouth_tilt(o)
    values = {"tilt_deg": tilt, "grid_axis": axis, "grid_aligned": tilt < tilt_deg, "mouth_shape": mouth_shape(o, rep),
              "min_in_plane_dim": min_in_plane_dim(o, rep), "bore": port_bore(o, rep)}
    formula = (f"tilt_deg = degrees(acos(|n_{axis}| / |n|)) = {tilt:.4g} with n = {_fmt_vec(o.normal)} the mouth normal of {o.id} "
               f"and {axis} its nearest grid axis; grid_aligned = tilt_deg < {tilt_deg:g} (TILTED_MOUTH_DEG); mouth_shape from the "
               f"outline ({o.shape}); min_in_plane_dim = {values['min_in_plane_dim']:.5g} the smallest in-plane dimension of the mouth")
    return values, formula, {"opening_id": o.id, "normal": [float(c) for c in o.normal], "TILTED_MOUTH_DEG": tilt_deg}


def _op_run_between(ctx: ToolContext, args: dict) -> tuple[dict, str, dict]:
    facts = ctx.facts
    rep = catalog.representation(facts, ctx.purpose, ctx.brief, declared=ctx.declared, fluid_side=ctx.fluid_side)
    oa, pa, la, ea = _point_arg(ctx, args, "a")
    ob, pb, lb, eb = _point_arg(ctx, args, "b")
    straight = math.dist(pa, pb)
    sa, sb = facts.stub(oa.id), facts.stub(ob.id)
    da, db = port_bore(oa, rep) or float(oa.hydraulic_diameter), port_bore(ob, rep) or float(ob.hydraulic_diameter)
    reach = JUNCTION_REACH_OVER_D * max(da, db)
    along = None
    how = "the straight line between the two points"
    if not ea and not eb and sa and sb and sa.end_point and sb.end_point and math.dist(sa.end_point, sb.end_point) <= reach:
        gap = math.dist(sa.end_point, sb.end_point)
        along = float(sa.length) + gap + float(sb.length)
        how = (f"along the run: {oa.id}'s stub {sa.length:.5g} + the gap between the two stub ends {gap:.4g} + {ob.id}'s stub "
               f"{sb.length:.5g} (both stubs end within {JUNCTION_REACH_OVER_D:g} bores of each other)")
    elif not ea and eb and sa and sa.end_point and math.dist(sa.end_point, pb) <= reach:
        gap = math.dist(sa.end_point, pb)
        along = float(sa.length) + gap
        how = f"along the run: {oa.id}'s stub {sa.length:.5g} + the gap from its end to {lb} {gap:.4g}"
    elif ea and not eb and sb and sb.end_point and math.dist(sb.end_point, pa) <= reach:
        gap = math.dist(sb.end_point, pa)
        along = float(sb.length) + gap
        how = f"along the run: {ob.id}'s stub {sb.length:.5g} + the gap from its end to {la} {gap:.4g}"
    distance = along if along is not None else straight
    values = {"distance": distance, "distance_straight": straight, "distance_along_run": along,
              "over_d_a": (distance / da) if da > 0 else None, "over_d_b": (distance / db) if db > 0 else None,
              "bore_a": da, "bore_b": db}
    formula = (f"distance {la} to {lb} = {distance:.5g}, {how}; straight-line distance {straight:.5g}; "
               f"over D: {distance:.5g} / {da:.5g} ({oa.id}) = {_g(values['over_d_a']) if da > 0 else None}, "
               f"{distance:.5g} / {db:.5g} ({ob.id}) = {_g(values['over_d_b']) if db > 0 else None}")
    return values, formula, {"a": la, "b": lb, "point_a": pa, "point_b": pb}


def dead_leg_of(ctx: ToolContext, junction_opening: str, closed_end_opening: str, inlet: str | None = None) -> dict:
    """The signed distance along the run from the junction (the junction opening's stub end) to a closed end.
    Negative when the closed end lies upstream of the junction: behind it against the supply direction (the
    chord from the inlet's mouth to the junction; the junction opening is the supply when no inlet is named) by
    more than UPSTREAM_OVER_D of its bore and on the supply's own axis, which is the supply run, not a dead leg.
    The checker calls this with the plan's own inlet, so the tool and the checker agree by construction."""
    facts = ctx.facts
    rep = catalog.representation(facts, ctx.purpose, ctx.brief, declared=ctx.declared, fluid_side=ctx.fluid_side)
    oj = facts.opening(str(junction_opening))
    oc = facts.opening(str(closed_end_opening))
    if oj is None or oc is None:
        raise ValueError(f"junction_opening {junction_opening!r} or closed_end_opening {closed_end_opening!r} is not an opening; "
                         f"known: {[x.id for x in facts.openings]}")
    sj = facts.stub(oj.id)
    if sj is None or not sj.end_point:
        raise ValueError(f"{oj.id} has no measured stub end point, so it names no junction")
    J = [float(c) for c in sj.end_point]
    oi = facts.opening(str(inlet)) if inlet else oj
    if oi is None:
        raise ValueError(f"inlet {inlet!r} is not an opening")
    chord = [J[k] - float(oi.centroid[k]) for k in range(3)]
    n = math.sqrt(sum(c * c for c in chord))
    if n <= 0 and sj.inward_direction:
        chord, n = [float(c) for c in sj.inward_direction], 1.0
    u = [c / n for c in chord] if n > 0 else [0.0, 0.0, 0.0]
    dc = port_bore(oc, rep) or float(oc.hydraulic_diameter)
    dj = port_bore(oj, rep) or float(oj.hydraulic_diameter)
    C = [float(c) for c in oc.centroid]
    rel = [C[k] - J[k] for k in range(3)]
    s = sum(rel[k] * u[k] for k in range(3))
    lateral = math.sqrt(max(0.0, sum(r * r for r in rel) - s * s))
    upstream = oc.id == oi.id or (s < -UPSTREAM_OVER_D * dc and lateral < max(dc, dj))
    sc = facts.stub(oc.id)
    straight = math.dist(J, C)
    if sc is not None and sc.end_point and math.dist(sc.end_point, J) <= JUNCTION_REACH_OVER_D * max(dc, dj):
        # the closed leg's own march plus what is left to the junction along that leg's axis (a junction spans about
        # a bore, and the junction point sits on the run's wall, so the lateral part of the gap is not run length)
        axis = list(sc.inward_direction) if sc.inward_direction else [-float(c) for c in oc.normal]
        an = math.sqrt(sum(c * c for c in axis)) or 1.0
        gap = abs(sum((J[k] - float(sc.end_point[k])) * axis[k] for k in range(3))) / an
        along = float(sc.length) + gap
        how = f"{oc.id}'s stub {sc.length:.5g} (ends by {sc.terminated_by}) + the rest of the way to the junction along its axis {gap:.4g}"
    else:
        along = straight
        how = f"the straight line from the junction to {oc.id}'s mouth (its stub does not end at this junction)"
    signed = -along if upstream else along
    return {"junction_opening": oj.id, "closed_end_opening": oc.id, "inlet": oi.id, "junction_point": J, "supply_direction": u,
            "dead_leg_length": signed, "dead_leg_over_d": (signed / dc) if dc > 0 else None, "distance_along_run": along,
            "distance_straight": straight, "behind_junction": -s, "lateral_offset": lateral, "bore_closed_end": dc,
            "upstream": upstream, "is_dead_leg": not upstream, "how": how}


def _op_dead_leg(ctx: ToolContext, args: dict) -> tuple[dict, str, dict]:
    r = dead_leg_of(ctx, args.get("junction_opening"), args.get("closed_end_opening"), args.get("inlet"))
    how = r.pop("how")
    L, over = r["dead_leg_length"], r["dead_leg_over_d"]
    if r["upstream"]:
        verdict = (f"NOT a dead leg: {r['closed_end_opening']} lies upstream of the junction ({r['behind_junction']:.4g} behind it against "
                   f"the supply direction from {r['inlet']}, lateral offset {r['lateral_offset']:.4g}); the fluid there is the supply, "
                   "so the distance is negative")
    else:
        verdict = f"a dead leg: {r['closed_end_opening']} lies beyond the junction, stagnant fluid from the junction to its closed mouth"
    formula = (f"dead_leg_length = {'-' if r['upstream'] else ''}({how}) = {L:.5g}; dead_leg_over_d = {L:.5g} / {r['bore_closed_end']:.5g} "
               f"= {over:.5g}; junction = {r['junction_opening']}'s stub end {_fmt_vec(r['junction_point'])}; supply direction = the chord "
               f"from {r['inlet']}'s mouth to the junction {_fmt_vec(r['supply_direction'])}; {verdict}")
    inputs = {"junction_opening": r["junction_opening"], "closed_end_opening": r["closed_end_opening"], "inlet": r["inlet"]}
    return r, formula, inputs


def _op_angle_between(ctx: ToolContext, args: dict) -> tuple[dict, str, dict]:
    facts = ctx.facts
    oa, ob = _opening_arg(ctx, args, "a"), _opening_arg(ctx, args, "b")

    def angle(u, v) -> float:
        nu = math.sqrt(sum(c * c for c in u)) or 1.0
        nv = math.sqrt(sum(c * c for c in v)) or 1.0
        return math.degrees(math.acos(max(-1.0, min(1.0, sum(x * y for x, y in zip(u, v)) / (nu * nv)))))

    def inward(o):
        s = facts.stub(o.id)
        return list(s.inward_direction) if (s is not None and s.inward_direction) else [-float(c) for c in o.normal]

    a_n, a_in = angle(oa.normal, ob.normal), angle(inward(oa), inward(ob))
    values = {"angle_deg": a_n, "angle_between_inward_deg": a_in,
              "facing": "opposed" if a_n > 170 else ("parallel" if a_n < 10 else "angled")}
    formula = (f"angle_deg = degrees(acos(n_a . n_b)) = {a_n:.4g} with n_a = {_fmt_vec(oa.normal)} ({oa.id}) and n_b = {_fmt_vec(ob.normal)} "
               f"({ob.id}); angle_between_inward_deg = {a_in:.4g} between the two inward flow directions (the stubs' inward directions, "
               "else the negated normals): the turn the fluid makes from one to the other")
    return values, formula, {"a": oa.id, "b": ob.id, "normal_a": [float(c) for c in oa.normal], "normal_b": [float(c) for c in ob.normal]}


def taper_of(ctx: ToolContext, a: str, b: str) -> dict:
    """Half angle and area ratio of the taper between two ports, from their bores and the distance between their
    stub ends (the catalog's diffuser_angle formula): the cone that the two marches stop at either end of."""
    facts = ctx.facts
    rep = catalog.representation(facts, ctx.purpose, ctx.brief, declared=ctx.declared, fluid_side=ctx.fluid_side)
    oa, ob = facts.opening(str(a)), facts.opening(str(b))
    if oa is None or ob is None:
        raise ValueError(f"a={a!r} or b={b!r} is not an opening; known: {[x.id for x in facts.openings]}")
    sa, sb = facts.stub(oa.id), facts.stub(ob.id)
    if sa is None or sb is None or not sa.end_point or not sb.end_point:
        raise ValueError(f"both {oa.id} and {ob.id} need a measured stub end point")
    L = math.dist(sa.end_point, sb.end_point)
    if L <= 0:
        raise ValueError(f"the stubs of {oa.id} and {ob.id} end at the same point: no taper between them")
    da, db = port_bore(oa, rep) or float(oa.hydraulic_diameter), port_bore(ob, rep) or float(ob.hydraulic_diameter)
    if da <= 0 or db <= 0:
        raise ValueError("both openings need a bore")
    half = math.degrees(math.atan(abs(da - db) / 2.0 / L))
    wide, narrow = (oa, ob) if da >= db else (ob, oa)
    return {"a": oa.id, "b": ob.id, "bore_a": da, "bore_b": db, "taper_length": L, "half_angle_deg": half,
            "area_ratio_b_over_a": (db / da) ** 2, "area_ratio_wide_over_narrow": (max(da, db) / min(da, db)) ** 2,
            "wide_id": wide.id, "narrow_id": narrow.id,
            "kind_a_to_b": "diffuser" if db > da * 1.001 else ("contraction" if db < da * 0.999 else "constant section"),
            "end_a": [float(c) for c in sa.end_point], "end_b": [float(c) for c in sb.end_point]}


def _op_taper(ctx: ToolContext, args: dict) -> tuple[dict, str, dict]:
    r = taper_of(ctx, args.get("a"), args.get("b"))
    formula = (f"half_angle_deg = degrees(atan(|D_a - D_b| / 2 / L)) = degrees(atan(|{r['bore_a']:.5g} - {r['bore_b']:.5g}| / 2 / "
               f"{r['taper_length']:.5g})) = {r['half_angle_deg']:.4g}, L = the distance between the stub ends of {r['a']} "
               f"{_fmt_vec(r['end_a'])} and {r['b']} {_fmt_vec(r['end_b'])}; area_ratio_b_over_a = (D_b / D_a)^2 = "
               f"{r['area_ratio_b_over_a']:.5g}; from {r['a']} to {r['b']} the section is a {r['kind_a_to_b']} "
               f"(wide end {r['wide_id']}, narrow end {r['narrow_id']}); the stubs stop where the section starts changing, "
               "so L is the taper as measured, a lower bound on the drawn cone")
    return r, formula, {"a": r["a"], "b": r["b"]}


def first_cell_of(bore: float, velocity: float, nu: float, yplus: float, unit: str, law: str = "flat_plate") -> dict:
    """The first-cell height for a y+ target, in the bore's unit: Re = U D / nu, Cf from `law` (CF_LAWS; the
    tool uses the flat-plate power law 0.026 Re^(-1/7)), u_tau = U sqrt(Cf / 2), y1 = y+ nu / u_tau. Pure
    arithmetic shared by the tool and the checker's recomputation."""
    coeff, exponent = CF_LAWS[law]
    f = UNIT_TO_M[unit]
    d_m = bore * f
    re = velocity * d_m / nu
    cf = coeff * re ** exponent
    u_tau = velocity * math.sqrt(cf / 2.0)
    y1_m = yplus * nu / u_tau
    return {"first_cell_height": y1_m / f, "first_cell_height_m": y1_m, "reynolds": re, "cf": cf, "u_tau": u_tau,
            "bore": bore, "bore_m": d_m, "velocity": velocity, "nu": nu, "yplus": yplus, "unit": unit}


def _op_first_cell(ctx: ToolContext, args: dict) -> tuple[dict, str, dict]:
    bore = _num_arg(ctx, args, "bore", ledger=True)
    velocity, nu, yplus = _num_arg(ctx, args, "velocity"), _num_arg(ctx, args, "nu"), _num_arg(ctx, args, "yplus")
    if args.get("unit") is not None and _unit_name(args["unit"]) is None:
        raise ValueError(f"unit {args['unit']!r} is not one of {sorted(UNIT_TO_M)}")
    unit, how = (_unit_name(args["unit"]), "given") if args.get("unit") is not None else _file_unit(ctx)
    r = first_cell_of(bore, velocity, nu, yplus, unit)
    formula = (f"Re = U D / nu = {velocity:.5g} x {r['bore_m']:.5g} m / {nu:.4g} = {r['reynolds']:.5g}; Cf = 0.026 Re^(-1/7) = {r['cf']:.5g} "
               f"(flat-plate turbulent power law, the wall-function estimate: a turbulent boundary layer, the bore as the length scale, "
               f"y+ 30 to 300 for a standard wall function, about 1 for a resolved layer); u_tau = U sqrt(Cf/2) = {r['u_tau']:.5g} m/s; "
               f"first_cell_height = y+ nu / u_tau = {yplus:g} x {nu:.4g} / {r['u_tau']:.5g} = {r['first_cell_height_m']:.5g} m = "
               f"{r['first_cell_height']:.5g} {unit} (file unit {unit}, {how}); a cell-centred code puts the first centre at half this height")
    return r, formula, {"bore": bore, "velocity": velocity, "nu": nu, "yplus": yplus, "unit": unit}


def _op_reynolds(ctx: ToolContext, args: dict) -> tuple[dict, str, dict]:
    bore = _num_arg(ctx, args, "bore", ledger=True)
    velocity, nu = _num_arg(ctx, args, "velocity"), _num_arg(ctx, args, "nu")
    if args.get("unit") is not None and _unit_name(args["unit"]) is None:
        raise ValueError(f"unit {args['unit']!r} is not one of {sorted(UNIT_TO_M)}")
    unit, how = (_unit_name(args["unit"]), "given") if args.get("unit") is not None else _file_unit(ctx)
    d_m = bore * UNIT_TO_M[unit]
    re = velocity * d_m / nu
    values = {"reynolds": re, "bore_m": d_m, "regime": "laminar" if re < 2300 else ("transitional" if re < 4000 else "turbulent")}
    formula = (f"Re = U D / nu = {velocity:.5g} m/s x {d_m:.5g} m / {nu:.4g} m^2/s = {re:.5g} (bore {bore:.5g} {unit}, file unit {unit}, {how}; "
               "pipe-flow regime bands 2300 and 4000)")
    return values, formula, {"bore": bore, "velocity": velocity, "nu": nu, "unit": unit}


def _feature_size(ctx: ToolContext, feature: Any, rep: str) -> tuple[float, str]:
    """(size, label) of the feature a cell has to span: a port's bore, a thin cluster's minimum thickness, the
    thinnest wall-to-wall distance ('thin'), or the smallest gap ('gap', 'gap_between_regions')."""
    f = ctx.facts
    name = str(feature or "")
    o = f.opening(name)
    if o is not None:
        return port_bore(o, rep) or float(o.hydraulic_diameter), f"bore of {o.id}"
    for c in f.features.thin_clusters:
        if c.id == name:
            return float(c.thickness_min), f"minimum thickness of thin cluster {c.id}"
    if name in ("thin", "thickness", "thickness_min"):
        if not f.features.thickness_min:
            raise ValueError("no wall thickness measured")
        return float(f.features.thickness_min), "thinnest wall-to-wall distance (features.thickness_min)"
    if name in ("gap", "min_gap"):
        if not f.features.min_gap:
            raise ValueError("no gap measured")
        return float(f.features.min_gap), "smallest gap between near-touching surfaces (features.min_gap)"
    if name in ("gap_between_regions", "min_gap_between_regions"):
        if not f.features.min_gap_between_regions:
            raise ValueError("no gap between bodies measured")
        return float(f.features.min_gap_between_regions), "smallest gap between two bodies (features.min_gap_between_regions)"
    raise ValueError(f"feature {feature!r} is not an opening id, a thin cluster id, 'thin', 'gap' or 'gap_between_regions'; "
                     f"openings {[x.id for x in f.openings]}, clusters {[c.id for c in f.features.thin_clusters]}")


def _op_cells_across(ctx: ToolContext, args: dict) -> tuple[dict, str, dict]:
    f = ctx.facts
    rep = catalog.representation(f, ctx.purpose, ctx.brief, declared=ctx.declared, fluid_side=ctx.fluid_side)
    frame = str(args.get("frame") or "builder").lower()
    if frame not in ("agent", "builder"):
        raise ValueError(f"frame must be agent or builder, got {frame!r}")
    size, label = _feature_size(ctx, args.get("feature"), rep)
    if size <= 0:
        raise ValueError(f"{label} is not a positive length")
    if frame == "agent":
        est = next((e for e in f.cell_estimates if e.tier == ctx.fidelity), None)
        if est is None:
            raise ValueError(f"no cell estimate for tier {ctx.fidelity!r}")
        cell = _surface_cell_of(est)
        how = f"the {ctx.fidelity} tier's surface cell {cell:.5g} (base_size {est.base_size:.5g} / 2^{SURFACE_LEVELS[ctx.fidelity]})"
        extra: dict[str, Any] = {"tier": ctx.fidelity, "surface_cell": cell}
    else:
        n = args.get("cells_across_diameter", BUILDER_CELLS_ACROSS_DEFAULT)
        if isinstance(n, bool) or not isinstance(n, (int, float)) or n <= 0:
            raise ValueError(f"cells_across_diameter must be a positive number, got {n!r}")
        inlet_id = args.get("inlet")
        if inlet_id is not None and f.opening(str(inlet_id)) is None:
            raise ValueError(f"inlet {inlet_id!r} is not an opening")
        if inlet_id is None:
            declared = _declared_inlet(ctx, rep) if ctx.purpose in INTERNAL_PURPOSES else None
            inlet_id = declared.id if declared is not None else None
        bf = builder_frame(f, rep, {"cells_across_diameter": int(n)}, inlet_id)
        cell = float(bf["wall_cell"])
        if cell <= 0:
            raise ValueError("no port to size the builder's wall cell from")
        how = (f"the builder's wall cell {cell:.5g} = inlet bore {bf['bore']:.5g} ({bf['inlet_id']}) / cells_across_diameter {bf['cells_across']}"
               " (drivers.py:584 with :634)")
        extra = {"inlet_id": bf["inlet_id"], "inlet_bore": bf["bore"], "cells_across_diameter": bf["cells_across"], "wall_cell": cell}
    values = {"cells_across": size / cell, "feature_size": size, "cell": cell, "frame": frame, **extra}
    formula = f"cells_across = {label} {size:.5g} / {how} = {size / cell:.5g}"
    return values, formula, {"feature": args.get("feature"), "frame": frame, **({"cells_across_diameter": extra.get("cells_across_diameter")} if frame == "builder" else {})}


def _op_unit_convert(ctx: ToolContext, args: dict) -> tuple[dict, str, dict]:
    value = _num_arg(ctx, args, "value", ledger=True, positive=False)
    src = _unit_name(args.get("from", args.get("from_unit")))
    dst = _unit_name(args.get("to", args.get("to_unit")))
    if src is None or dst is None:
        raise ValueError(f"from and to must be units among {sorted(UNIT_TO_M)}, got {args.get('from', args.get('from_unit'))!r} and "
                         f"{args.get('to', args.get('to_unit'))!r}")
    factor = UNIT_TO_M[src] / UNIT_TO_M[dst]
    out = value * factor
    values = {"value": out, "from": src, "to": dst, "factor": factor}
    formula = f"{value:.6g} {src} x {factor:.6g} {dst}/{src} = {out:.6g} {dst}"
    return values, formula, {"value": value, "from": src, "to": dst}


_EVAL_FUNCS = {"sqrt": math.sqrt, "log": math.log, "log10": math.log10, "exp": math.exp, "sin": math.sin, "cos": math.cos,
               "tan": math.tan, "asin": math.asin, "acos": math.acos, "atan": math.atan, "atan2": math.atan2, "degrees": math.degrees,
               "radians": math.radians, "abs": abs, "min": min, "max": max, "hypot": math.hypot}
_EVAL_CONSTS = {"pi": math.pi, "e": math.e}


def safe_eval(expr: str, env: dict[str, float]) -> float:
    """Arithmetic over the names in `env` and the math functions above, walked from the AST: no attribute,
    subscript, comparison, comprehension, lambda, string or import can appear, so a formula can never reach
    anything but numbers. The exponent of a power is bounded so an expression cannot take the process down."""
    import ast
    if not isinstance(expr, str) or not expr.strip():
        raise ValueError("expr must be a non-empty string")
    if len(expr) > _EVAL_MAX_CHARS:
        raise ValueError(f"expr is over {_EVAL_MAX_CHARS} characters")
    try:
        tree = ast.parse(expr.strip(), mode="eval")
    except SyntaxError as exc:
        raise ValueError(f"expr is not an arithmetic expression: {exc.msg}") from None
    ops = {ast.Add: lambda a, b: a + b, ast.Sub: lambda a, b: a - b, ast.Mult: lambda a, b: a * b, ast.Div: lambda a, b: a / b,
           ast.Pow: lambda a, b: a ** b, ast.Mod: lambda a, b: a % b, ast.FloorDiv: lambda a, b: a // b}

    def ev(node) -> float:
        if isinstance(node, ast.Constant):
            if isinstance(node.value, bool) or not isinstance(node.value, (int, float)):
                raise ValueError(f"only numeric constants are allowed, not {node.value!r}")
            return float(node.value)
        if isinstance(node, ast.Name):
            if node.id in env:
                return float(env[node.id])
            if node.id in _EVAL_CONSTS:
                return _EVAL_CONSTS[node.id]
            raise ValueError(f"unknown name {node.id!r}: give it in names as a ledger number or a derivation id")
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.USub, ast.UAdd)):
            v = ev(node.operand)
            return -v if isinstance(node.op, ast.USub) else v
        if isinstance(node, ast.BinOp) and type(node.op) in ops:
            a, b = ev(node.left), ev(node.right)
            if isinstance(node.op, ast.Pow) and abs(b) > _EVAL_MAX_EXPONENT:
                raise ValueError(f"an exponent over {_EVAL_MAX_EXPONENT:g} is refused")
            if isinstance(node.op, (ast.Div, ast.Mod, ast.FloorDiv)) and b == 0:
                raise ValueError("division by zero")
            return float(ops[type(node.op)](a, b))
        if isinstance(node, ast.Call):
            if not isinstance(node.func, ast.Name):
                raise ValueError(f"calling a {type(node.func).__name__} is not allowed; only these functions are allowed: {sorted(_EVAL_FUNCS)}")
            if node.func.id not in _EVAL_FUNCS or node.keywords:
                raise ValueError(f"only these functions are allowed: {sorted(_EVAL_FUNCS)}")
            return float(_EVAL_FUNCS[node.func.id](*[ev(a) for a in node.args]))
        raise ValueError(f"{type(node).__name__} is not allowed: arithmetic (+ - * / ** %), the names given and math functions only")

    out = ev(tree.body)
    if not math.isfinite(out):
        raise ValueError("the expression is not finite")
    return out


def _resolve_name(ctx: ToolContext, name: str, ref: Any) -> tuple[float, str]:
    """A name's value: a number that is in the ledger, or 'dN' (a derivation with one numeric value) or 'dN.key'."""
    if isinstance(ref, str):
        did, _, key = ref.partition(".")
        rec = ctx.ledger.derivations.get(did)
        if rec is None:
            raise ValueError(f"{name}={ref!r} names no derivation of this run ({sorted(ctx.ledger.derivations) or 'none yet'})")
        nums = {k: v for k, v in rec["values"].items() if isinstance(v, (int, float)) and not isinstance(v, bool)}
        if key:
            if key not in nums:
                raise ValueError(f"{name}={ref!r}: {did} has no numeric value {key!r}; it has {sorted(nums)}")
            return float(nums[key]), f"{ref} ({rec['op']})"
        if len(nums) != 1:
            raise ValueError(f"{name}={ref!r}: {did} holds {len(nums)} numeric values {sorted(nums)}; name one as {did}.<key>")
        k, v = next(iter(nums.items()))
        return float(v), f"{did}.{k} ({rec['op']})"
    if isinstance(ref, bool) or not isinstance(ref, (int, float)) or not math.isfinite(float(ref)):
        raise ValueError(f"{name}={ref!r} must be a number or a derivation id")
    if not _in_ledger(ctx, ref):
        raise ValueError(f"{name}={ref!r} is not a measured number, a derived number or a number from the brief")
    return float(ref), "ledger"


def _op_eval(ctx: ToolContext, args: dict) -> tuple[dict, str, dict]:
    names = args.get("names")
    if not isinstance(names, dict) or not names:
        raise ValueError("names must be a non-empty object {name: ledger number or derivation id}; an expression needs at least one ledger value")
    env: dict[str, float] = {}
    where: dict[str, str] = {}
    for k, ref in names.items():
        if not isinstance(k, str) or not k.isidentifier() or k in _EVAL_FUNCS or k in _EVAL_CONSTS:
            raise ValueError(f"name {k!r} must be an identifier that is not a function or constant name")
        env[k], where[k] = _resolve_name(ctx, k, ref)
    expr = args.get("expr")
    value = safe_eval(expr, env)
    bound = ", ".join(f"{k} = {v:.6g}" + (f" from {where[k]}" if where[k] != "ledger" else "") for k, v in env.items())
    return {"value": value}, f"{expr.strip()} = {value:.6g} with {bound}", {"expr": expr.strip(), "names": dict(names)}


_DERIVED_OPS = {"port_tilt": _op_port_tilt, "run_between": _op_run_between, "dead_leg": _op_dead_leg, "angle_between": _op_angle_between,
                "taper": _op_taper, "first_cell": _op_first_cell, "reynolds": _op_reynolds, "cells_across": _op_cells_across,
                "unit_convert": _op_unit_convert, "eval": _op_eval}


def derived_geometry(ctx: ToolContext, op: str, args: dict | None = None) -> dict:
    """One derivation over measured numbers, recorded in the ledger under a derivation id with its formula and
    returned as {derivation_id, op, values, formula, inputs}. Read-only. An op error returns {error} and records
    nothing."""
    fn = _DERIVED_OPS.get(str(op))
    if fn is None:
        return {"error": f"unknown op {op!r}; ops: {list(DERIVED_OPS)}"}
    if args is None:
        args = {}
    if not isinstance(args, dict):
        return {"error": f"args must be an object for {op}"}
    try:
        values, formula, inputs = fn(ctx, args)
    except (ValueError, TypeError, KeyError, ZeroDivisionError, OverflowError) as exc:
        return {"error": f"{op}: {exc}"}
    did = ctx.ledger.derive(str(op), formula, inputs, values)
    return {"derivation_id": did, "op": op, "values": values, "formula": formula, "inputs": inputs}


def _risk_diff_key(r) -> tuple:
    m = r.measurement or {}
    return (r.kind, m.get("opening_id"), m.get("cluster_id"))


def _roles_arg(name: str, roles: Any) -> dict[str, str]:
    if not isinstance(roles, dict) or not roles:
        raise ValueError(f"{name} must be a non-empty object {{opening_id: role}}")
    out = {}
    for k, v in roles.items():
        if v not in ROLE_ENUM:
            raise ValueError(f"{name}[{k!r}]={v!r} is not a role; roles: {ROLE_ENUM}")
        out[str(k)] = str(v)
    return out


def _compare_roles_values(ctx: ToolContext, ra: dict[str, str], rb: dict[str, str],
                          fidelity: str | None = None) -> tuple[dict[str, Any], str]:
    """The catalog under two role assignments and the diff between them, with the formula that reproduces it.
    The one copy of the comparison: the `compare_roles` tool calls it for the model, `role_swap_diff` calls it
    for the checker. Both ids are known to be openings of this file before it runs. `fidelity` overrides the
    context's tier, which is what the checker needs: every catalog run it makes is under the tier the plan chose
    (`plan.mesh_plan.fidelity`), not the tier the user asked for, and the cell-cap risks differ between them."""
    facts = ctx.facts
    tier = fidelity or ctx.fidelity
    rep = catalog.representation(facts, ctx.purpose, ctx.brief, declared=ctx.declared, fluid_side=ctx.fluid_side)
    ports = catalog.port_openings(facts, rep, ctx.declared)

    def side(roles: dict[str, str]) -> dict:
        risks = catalog.detect_risks(facts, ctx.purpose, tier, ctx.cell_cap, ctx.declared, roles, brief=ctx.brief,
                                     fluid_side=ctx.fluid_side)
        inlet = next((o for o in ports if roles.get(o.id) == "inlet"), None)
        seed = catalog.seed_point_for(facts, inlet, rep) if inlet is not None else None
        diff = next((r for r in risks if r.kind == "diffuser_angle"), None)
        if diff is not None:
            m = diff.measurement
            wide, narrow, half = m.get("wide_id"), m.get("narrow_id"), m.get("half_angle_deg")
            if roles.get(wide) == "outlet":
                direction = f"diffuser: the section widens from {narrow} toward the outlet {wide}, half angle {half} deg"
            elif roles.get(narrow) == "outlet":
                direction = f"contraction: the section narrows from {wide} toward the outlet {narrow}, half angle {half} deg"
            else:
                direction = f"section change between {narrow} and {wide} (half angle {half} deg), neither the outlet"
        else:
            direction = "no taper measured between the ports"
        return {"roles": roles, "risks": risks, "by_key": {_risk_diff_key(r): r for r in risks},
                "severity_sum": sum(SEVERITY_WEIGHT.get(r.severity, 0) for r in risks),
                "high": sum(1 for r in risks if r.severity in ("high", "blocking")),
                "decisions": sum(1 for r in risks if r.requires_user_decision),
                "inlet_id": inlet.id if inlet is not None else None, "seed_point": [float(c) for c in seed] if seed else None,
                "diffuser_direction": direction}

    a, b = side(ra), side(rb)

    def only(x: dict, y: dict) -> list[dict]:
        return [{"kind": r.kind, "opening_id": (r.measurement or {}).get("opening_id"), "severity": r.severity,
                 "requires_user_decision": r.requires_user_decision}
                for k, r in x["by_key"].items() if k not in y["by_key"]]

    changed = [{"kind": k[0], "opening_id": k[1], "severity_a": a["by_key"][k].severity, "severity_b": b["by_key"][k].severity}
               for k in a["by_key"] if k in b["by_key"] and a["by_key"][k].severity != b["by_key"][k].severity]
    fewer = "a" if a["high"] < b["high"] else ("b" if b["high"] < a["high"] else "equal")
    high_kinds = {f"high_kinds_{s}": sorted({r.kind for r in x["risks"] if r.severity in ("high", "blocking")})
                  for s, x in (("a", a), ("b", b))}
    values = {"only_under_a": only(a, b), "only_under_b": only(b, a), "severity_changed": changed, **high_kinds,
              "severity_sum_a": a["severity_sum"], "severity_sum_b": b["severity_sum"], "high_risks_a": a["high"], "high_risks_b": b["high"],
              "decisions_a": a["decisions"], "decisions_b": b["decisions"], "inlet_a": a["inlet_id"], "inlet_b": b["inlet_id"],
              "seed_point_a": a["seed_point"], "seed_point_b": b["seed_point"],
              "diffuser_direction_a": a["diffuser_direction"], "diffuser_direction_b": b["diffuser_direction"], "fewer_high_risks": fewer}
    formula = (f"catalog.detect_risks under roles_a {ra} and roles_b {rb}: {len(a['risks'])} risks (severity sum {a['severity_sum']}, "
               f"{a['high']} high) against {len(b['risks'])} ({b['severity_sum']}, {b['high']} high); severity weights {SEVERITY_WEIGHT}; "
               f"only under a: {[(r['kind'], r['opening_id']) for r in values['only_under_a']]}; only under b: "
               f"{[(r['kind'], r['opening_id']) for r in values['only_under_b']]}; seed point a {values['seed_point_a']} (inside "
               f"{a['inlet_id']}), b {values['seed_point_b']} (inside {b['inlet_id']}); fewer high risks: {fewer}")
    return values, formula


def compare_roles(ctx: ToolContext, roles_a: dict, roles_b: dict) -> dict:
    """The catalog under two role assignments and the diff between them: the risks only under each, the
    severity sums, the seed point and the diffuser direction each implies, and which has fewer high risks.
    Recorded under a derivation id so a counterfactual can cite it."""
    try:
        ra, rb = _roles_arg("roles_a", roles_a), _roles_arg("roles_b", roles_b)
    except ValueError as exc:
        return {"error": str(exc)}
    unknown = sorted((set(ra) | set(rb)) - {o.id for o in ctx.facts.openings})
    if unknown:
        return {"error": f"unknown opening ids {unknown}; known: {[o.id for o in ctx.facts.openings]}"}
    values, formula = _compare_roles_values(ctx, ra, rb)
    did = ctx.ledger.derive(COMPARE_ROLES, formula, {"roles_a": ra, "roles_b": rb}, values)
    return {"derivation_id": did, **values, "roles_a": ra, "roles_b": rb, "formula": formula}


#: The two roles a swap exchanges; every other role stays where it is.
SWAPPED_ROLE = {"inlet": "outlet", "outlet": "inlet"}


def swap_roles(roles: dict[str, str]) -> dict[str, str]:
    """The assignment the other way round: inlets become outlets and outlets inlets, everything else untouched."""
    return {k: SWAPPED_ROLE.get(v, v) for k, v in roles.items()}


def role_swap_diff(ctx: ToolContext, roles: dict[str, str], fidelity: str | None = None) -> dict[str, Any] | None:
    """`compare_roles` run on a plan's own roles against their swap, recorded in the ledger the same way, so the
    number a counterfactual has to quote exists whether or not the model called the tool (P4.4).

    `None` means there is nothing to swap and so nothing to quote: no inlet or no outlet among the roles (an
    external body has neither, and the `compare_roles` tool refuses an empty assignment outright), an id the
    file does not have, or a catalog that will not run under one of the two assignments. `cites` is the one
    sentence a `what_breaks` can carry: the derivation id and the two high-risk counts, which is what R11 asks
    a counterfactual to quote. `fidelity` is the tier to run the catalog under: the checker passes the plan's
    own (`plan.mesh_plan.fidelity`), as every other catalog run it makes does."""
    known = {o.id for o in ctx.facts.openings}
    plan_roles = {k: v for k, v in (roles or {}).items() if k in known}
    inlets = sorted(k for k, v in plan_roles.items() if v == "inlet")
    outlets = sorted(k for k, v in plan_roles.items() if v == "outlet")
    if not inlets or not outlets:
        return None
    swapped = swap_roles(plan_roles)
    try:
        values, formula = _compare_roles_values(ctx, plan_roles, swapped, fidelity)
    except (StopIteration, ValueError, KeyError, TypeError, AttributeError):
        return None
    did = ctx.ledger.derive(COMPARE_ROLES, formula, {"roles_a": plan_roles, "roles_b": swapped}, values)
    kinds_plan = sorted({r["kind"] for r in values["only_under_a"] if r["severity"] in ("high", "blocking")})
    kinds_swap = sorted({r["kind"] for r in values["only_under_b"] if r["severity"] in ("high", "blocking")})
    cites = (f"compare_roles({did}): with inlets {inlets} and outlets {outlets} swapped, the catalog carries "
             f"{values['high_risks_b']} high risk(s) against {values['high_risks_a']} as planned (severity sums "
             f"{values['severity_sum_b']} and {values['severity_sum_a']})"
             + (f"; only under the swap: {kinds_swap}" if kinds_swap else "")
             + (f"; lost by the swap: {kinds_plan}" if kinds_plan else "")
             + (f"; the seed moves from {_sig(values['seed_point_a'])} to {_sig(values['seed_point_b'])}"
                if values["seed_point_a"] != values["seed_point_b"] else ""))
    return {"derivation_id": did, "swap": swapped, "inlets": inlets, "outlets": outlets, "cites": cites, **values}


HANDLERS = {
    "get_facts_summary": get_facts_summary,
    "list_openings": list_openings,
    "get_opening": get_opening,
    "list_regions": list_regions,
    "get_features": get_features,
    "get_axes": get_axes,
    "get_names": get_names,
    "get_unit_evidence": get_unit_evidence,
    "estimate_cells": estimate_cells,
    "list_risks": list_risks,
    "probe_section": probe_section,
    "section_profile": section_profile,
    "distance_between": distance_between,
    "render_view": render_view,
    DERIVED: derived_geometry,
    COMPARE_ROLES: compare_roles,
    LOOK: look_at_views,
}


#: The note an answered-from-the-packet result carries, so the model reads why nothing was measured and stops
#: paying a round for a number it was handed with the opening message.
PACKET_ANSWER_NOTE = ("the MEASUREMENTS of the opening message already carry this: the tool's own answer is repeated "
                      "here from that packet and nothing was measured again. Probe only for what the measurements "
                      "do not carry.")


def packet_answer(ctx: ToolContext, name: str, args: dict) -> dict | None:
    """The result `facts_packet` already computed for this call, or None when the packet does not answer it.

    Only the no-argument form of a tool the packet ran is answered: `estimate_cells` with a tier or a refinement
    list, `get_opening`, and every measuring tool (probe_section, section_profile, render_view, look_at_views)
    do work the packet never did. The loop prunes `packet_answers` to what the opening message actually carried,
    so a run whose file was too large for the inline packet still measures for real."""
    if args:
        return None
    return ctx.packet_answers.get(name)


#: What the model is told when a tool broke. It names the tool, the fault and what to do instead, because a
#: result the model cannot act on costs a round and then the run.
TOOL_FAILED = ("{name} could not be measured on this part: {why}. Nothing was measured, so cite no number from "
               "this call. The MEASUREMENTS in the opening message stand; plan from those, or probe something "
               "else. The same call is unlikely to answer differently.")


def run_tool(ctx: ToolContext, name: str, args: dict) -> dict:
    """Run one tool and return its result. NEVER RAISES, and that is the whole point of this function.

    A TOOL THAT BREAKS IS MODEL FEEDBACK, NOT THE JOB'S DEATH. Nothing between here and the platform catches a
    tool's exception on purpose: `run_loop` lets it out, `chain.job.plan` lets it out, and
    `application/geometry_step.plan_the_part` then logs one warning ("no plan for this submission, the job runs
    without it") and hands the builder a job with no plan in it. MEASURED on the 322-part export corpus with the
    customer's file absent from disk, which is the state `plan_the_part` documents and allows (`source_path=""`
    when the upload could not be fetched for the agent's own tools): `probe_section` and `section_profile` raised
    `UnsupportedGeometry` on 311 of 322 parts, one per part with an opening to probe. The eleven that survived
    have no openings. So one unfetched file cost the plan, silently, on all but a handful of parts.

    The argument check is a real bind against the handler's signature rather than a `TypeError` catch around the
    call: a `TypeError` raised INSIDE a handler is a fault in our code, and reporting it to the model as "bad
    arguments for section_profile" sent the model round to fix arguments that were already right.
    """
    fn = HANDLERS.get(name)
    if fn is None:
        return {"error": f"unknown tool {name!r}"}
    try:
        inspect.signature(fn).bind(ctx, **args)
    except TypeError as exc:
        return {"error": f"bad arguments for {name}: {exc}"}
    answered = packet_answer(ctx, name, args)
    if answered is not None:
        # the numbers go through the ledger exactly as a measured call's would: the model may cite what it is shown
        result = _round(answered)
        result["from_facts_packet"] = PACKET_ANSWER_NOTE
        ctx.ledger.record(result)
        ctx.ledger.calls.append(name)
        ctx.ledger.log_call(name, args, result)
        ctx.echoed_calls.append(name)
        return result
    try:
        result = fn(ctx, **args)
    except Exception as exc:  # noqa: BLE001 - a tool that broke is a result, never the end of the job
        # THE SAME SHAPE AS A TOOL THAT REFUSED ON PURPOSE (`{"error": ...}` from `get_opening` and the rest),
        # so it goes through the same tail: the call is in `ledger.calls` and in the call log with its error and
        # no numbers, because the call HAPPENED and measured nothing. Two conventions for one outcome is how a
        # rule that reads the log comes to disagree with the model about what ran.
        observe.warning("tool.failed", tool=name, error=type(exc).__name__)
        result = {"error": TOOL_FAILED.format(name=name, why=f"{type(exc).__name__}: {str(exc)[:200]}")}
    # a derived number keeps its significant figures (a first cell in metres has none left at six decimals)
    result = _round_derived(result) if name in (DERIVED, COMPARE_ROLES) else _round(result)
    if name != LOOK:
        # the visual impression is words; nothing in it may become a number the plan can cite
        ctx.ledger.record(result)
    ctx.ledger.calls.append(name)
    if name != LOOK:
        ctx.ledger.log_call(name, args, result)
    return result


# ---------------------------------------------------------------------------------------------------------------
# The call log, read back (P4.3e, docs/plan_v3_rules.md section 14). The ledger already knows which tools ran,
# with which arguments and what they returned; a rule that has to say whether a named test was run reads it here
# rather than reaching into the ledger's fields. `ledger_calls` is the whole log; `matching_calls` finds the calls
# a refuting test names; `number_for` picks the reading a sentence is about; `refuting_verdict` reads the
# hypothesis's own would_refute_if against that reading.
# ---------------------------------------------------------------------------------------------------------------
def ledger_calls(ctx: ToolContext) -> list[dict]:
    """Every call this run made, in order, as `{tool, args, numbers}` (plus `op` and `derivation_id` on a derived
    call, `error` on one that measured nothing, `via` facts_packet on one the packet ran for the opening
    message). The entries are copies: reading the log cannot change it."""
    return [dict(entry) for entry in ctx.ledger.call_log]


def keep_packet_calls(ctx: ToolContext, names: Any) -> None:
    """Drop the packet's logged calls the opening message did not carry. On the summary-only path the loop keeps
    only `get_facts_summary` in `packet_answers`, and the log has to say the same: the other seven tools ran, but
    the model never saw their readings, so no rule may treat them as a test it has had the answer to."""
    kept = set(names or ())
    ctx.ledger.call_log = [c for c in ctx.ledger.call_log
                           if c.get(VIA) != PACKET_VIA or c.get("tool") in kept]


def _arg_values(args: Any, depth: int = 0) -> set:
    """The values an argument object names, flattened: a refuting test writes `{a: o1, b: o2}` where the call was
    logged as `{op: taper, args: {a: o1, b: o2}}`, so the keys do not line up and the values do."""
    out: set = set()
    if isinstance(args, dict) and depth < 3:
        for v in args.values():
            out |= _arg_values(v, depth + 1)
    elif isinstance(args, (list, tuple)) and depth < 3:
        for v in args:
            out |= _arg_values(v, depth + 1)
    elif isinstance(args, str):
        out.add(args.strip())
    elif isinstance(args, (int, float)) and not isinstance(args, bool):
        out.add(float(args))
    return out


def matching_calls(ctx: ToolContext, tool: str, args: Any = None) -> list[dict]:
    """The calls of this run that answer `tool`: a tool name (`list_openings`) or a derived op (`taper`, which
    ran as `derived_geometry(op=taper)`). With `args`, a call must also name every value the arguments name, so
    `taper {a: o1, b: o2}` does not match the taper of two other ports; an empty `args` matches any call of the
    tool. A run that never called it returns []."""
    want = str(tool or "").strip()
    if not want:
        return []
    asked = _arg_values(args) - {""}
    out = []
    for entry in ctx.ledger.call_log:
        if entry.get("error"):
            continue
        if entry.get("tool") != want and str(entry.get("op") or "") != want:
            continue
        if asked and not asked <= _arg_values(entry.get("args")):
            continue
        out.append(dict(entry))
    return out


def readings_of(ctx: ToolContext, tool: str) -> set[float]:
    """Every number a call of `tool` returned in this run: what a plan citing that tool may have read off it.

    The ledger's `numbers` is the same set over every tool at once, minus the lengths of lists, which it does not
    hold: it records the numbers in a result, never how many entries a result had. "How many ports are there" is
    the reading 115 of the learning-half run's 453 refuting tests name, so a rule that asks whether a citation is
    a reading of the call it names asks here (R2's `tests_run`), and a rule that asks whether a number was
    measured at all still asks the ledger."""
    return {float(v) for call in matching_calls(ctx, tool) for v in (call.get("numbers") or {}).values()}


_WORD = re.compile(r"[a-z0-9]+")


def number_for(call: dict, text: str = "", ledger: Any = None) -> tuple[str, float] | None:
    """The reading of a call a sentence is about, as `(name, number)`: the number whose own name the sentence
    names (`half angle` picks `half_angle_deg`, `ports` picks `openings.count`), else the first number the call
    returned. None when the call returned no number.

    With `ledger` (a set of the run's numbers), a reading the ledger already holds wins a tie and is preferred to
    one it does not, so a rule that may only write a citable number gets one where the call returned one. A
    `.count` is the exception on purpose: the log computes it from a result the model was shown, and the ledger
    records the numbers in a result rather than the length of its lists, so a count is a reading of the call and
    not a measured quantity. Nothing here puts it in the ledger."""
    numbers = call.get("numbers") or {}
    if not numbers:
        return None
    held = ledger if isinstance(ledger, (set, frozenset)) else set()
    words = set(_WORD.findall(str(text).lower()))
    best, score = None, (-1, -1)
    for name, value in numbers.items():
        parts = set(_WORD.findall(name.lower()))
        rank = (len(parts & words), 1 if float(value) in held else 0)
        if rank > score:
            best, score = (name, float(value)), rank
    return best


#: Number words a refuting test writes out ("fewer than one large port"), so a sentence with no digit still reads.
_NUMBER_WORDS = {"zero": 0.0, "one": 1.0, "two": 2.0, "three": 3.0, "four": 4.0, "five": 5.0, "six": 6.0,
                 "seven": 7.0, "eight": 8.0, "nine": 9.0, "ten": 10.0, "twelve": 12.0}
_COMPARISONS: tuple[tuple[str, Any], ...] = (
    (r"(?:at least|no fewer than|no less than)\s+", lambda v, n: v >= n),
    (r"(?:at most|no more than|no greater than)\s+", lambda v, n: v <= n),
    (r"(?:under|below|less than|fewer than|smaller than|short of)\s+", lambda v, n: v < n),
    (r"(?:over|above|more than|greater than|exceed(?:s|ing)?|beyond|larger than)\s+", lambda v, n: v > n),
    (r"(?:not|never|other than|anything but|differs? from)\s+(?:exactly\s+)?", lambda v, n: abs(v - n) > 1e-9),
    (r"(?:exactly|equals?|is|are|of)\s+", lambda v, n: abs(v - n) <= 1e-9),
)
_NUM = r"(-?\d+(?:\.\d+)?|" + "|".join(_NUMBER_WORDS) + r")"


def _as_number(token: str) -> float | None:
    try:
        return float(token)
    except ValueError:
        return _NUMBER_WORDS.get(token.lower())


def refuting_verdict(would_refute_if: str, value: float) -> str | None:
    """The verdict a hypothesis's own `would_refute_if` gives a reading: "refutes" when the sentence's condition
    holds for `value`, "supports" when it demonstrably does not, None when the sentence states no condition a
    comparison can read ("if the branch is not a branch").

    The sentences the live run wrote are comparisons ("if the half angle is under 7 degrees", "if fewer than one
    large port", "if the count is not 3"), so the first comparison in the sentence is read and the rest of it is
    left alone. Nothing here guesses: an unreadable sentence returns None and the caller decides."""
    text = " ".join(str(would_refute_if or "").lower().split())
    if not text:
        return None
    hit = None
    for pattern, test in _COMPARISONS:
        m = re.search(pattern + _NUM + r"\b", text)
        if m is not None and (hit is None or m.start() < hit[0]):
            n = _as_number(m.group(1))
            if n is not None:
                hit = (m.start(), test, n)
    if hit is None:
        return None
    return "refutes" if hit[1](float(value), hit[2]) else "supports"


# ---------------------------------------------------------------------------------------------------------------
# amend_geometry_plan: JSON-pointer edits to the last submitted plan, and the pointer each checker message points
# at, so a rejection can say "amend these paths" and the model never retypes the plan. The loop runs the checker.
# ---------------------------------------------------------------------------------------------------------------
_MISSING = object()


def _pointer_tokens(path: str) -> list[str] | None:
    """RFC 6901 tokens of `path`; None when it is not a pointer. "" and "/" both name the plan root."""
    if path in ("", "/"):
        return []
    if not path.startswith("/"):
        return None
    return [t.replace("~1", "/").replace("~0", "~") for t in path[1:].split("/")]


def _child(node: Any, tok: str, name: str = "") -> Any:
    if isinstance(node, dict):
        return node.get(tok, _MISSING)
    if isinstance(node, list):
        i = _element_index(node, tok, name)
        if i is not None and i < len(node):
            return node[i]
    return _MISSING


#: The field that names an element of each plan list, for the listing a missing index gets (P4.3, R17).
_LIST_LABELS = {"risks": ("id", "kind"), "patches": ("id", "role"), "questions": ("id", "relates_to"),
                "refinement_regions": ("where", "kind"), "layer_targets": ("patch_id",), "port_extensions": ("patch_id",),
                "regions": ("id", "role"), "mesh_warnings": ("id", "kind"), "simulation_warnings": ("id", "kind"),
                "identity_hypotheses": ("type",), "second_look": ("item",), "agent_risks_considered": ("mechanism",)}


def _element_index(node: list, tok: str, name: str = "") -> int | None:
    """The element of a plan list a pointer token names: the POSITION when it is a digit that resolves, and
    otherwise the element whose own identifying field (`_LIST_LABELS`, the id or patch_id) is that token. `-` is
    not handled here; the caller appends. None when the token names no element.

    AN INSTRUCTION A MODEL RELIABLY MISREADS IS A DEFECT IN THE INSTRUCTION. The live batch of 2026-09-26 lost a
    whole plan to `edit /mesh_plan/port_extensions/9: no element 9 in a list of 8 ... 8 entries: 0 o7, 1 o9, 2 o10,
    3 o12, 4 o13, 5 o15, 6 o16, 7 o18` and the same for index 11: the analyst was addressing an extension by the
    MOUTH's number (o9 -> 9) rather than by list position, which is how a human reads that list too, and the
    message's own listing printed the mapping it was refusing to make. That is the third edit-addressing error
    recorded this month.

    THE POSITION READING ALWAYS WINS. A digit is tried as an index first and the id reading is reached only when
    that index does not exist, so no pointer that resolved before resolves differently now: a list of 21 patches
    o0..o20 edited at /patches/9 still means position 9. `o9` as a token is new ground and resolves by id, and an
    ambiguous list (two entries with the same id, or an id that is itself a bare number) resolves to neither."""
    if tok == "-":
        return None
    if tok.isdigit() and int(tok) < len(node):
        return int(tok)
    key = _LIST_LABELS.get(name, ("id",))[0]
    if tok.isdigit():
        # A digit is a position and nothing else while it can be one. An index equal to the length is the append
        # position (`/patches/1` on a one-patch list adds a patch), so the id reading starts only PAST it, and
        # then only for an opening-id spelling of the number - never a bare number, so "9" cannot pick up an entry
        # whose id happens to be the string "9".
        if int(tok) <= len(node):
            return None
        hits = [i for i, it in enumerate(node)
                if isinstance(it, dict) and isinstance(it.get(key), str) and re.fullmatch(rf"[a-z]+0*{tok}", it[key])]
    else:
        hits = [i for i, it in enumerate(node) if isinstance(it, dict) and str(it.get(key)) == tok]
    return hits[0] if len(hits) == 1 else None


def list_entries(node: Any, list_path: str) -> str:
    """The valid indices of a plan list with what each element is ("risks has 3 entries: 0 k1 (symmetry_opportunity),
    1 k2 (external_domain), 2 k101 (external_body_solid)"), so an amend that named a missing index can be
    written against the list as it is. The P4.1 run lost a case to an amend at /risks/3 of a three-risk list."""
    name = list_path.strip("/").split("/")[-1] or "the list"
    if not isinstance(node, list):
        return f"{name} is not a list"
    if not node:
        return f"{name} is empty (indices count from 0; - appends)"
    labels = _LIST_LABELS.get(name, ("id",))
    rows = []
    for i, it in enumerate(node[:24]):
        if isinstance(it, dict):
            head = str(it.get(labels[0]) if it.get(labels[0]) is not None else "?")
            tail = f" ({it.get(labels[1])})" if len(labels) > 1 and it.get(labels[1]) is not None else ""
            rows.append(f"{i} {head}{tail}")
        else:
            rows.append(f"{i} {str(it)[:24]!r}")
    more = f", ... ({len(node)} in all)" if len(node) > 24 else ""
    by_id = ""
    first = next((it.get(labels[0]) for it in node if isinstance(it, dict) and isinstance(it.get(labels[0]), str)), None)
    if first:
        by_id = f"; an entry may be named by its {labels[0]} instead of its position ({list_path.rstrip('/')}/{first})"
    return f"{name} has {len(node)} entr{'y' if len(node) == 1 else 'ies'}: " + ", ".join(rows) + more + by_id


def missing_index_note(plan_obj: dict, pointer: str) -> str:
    """For a pointer whose list index is not in the plan, the listing of that list; "" when every index resolves
    or the pointer names no list index."""
    tokens = _pointer_tokens(pointer)
    if not tokens:
        return ""
    node: Any = plan_obj
    for depth, tok in enumerate(tokens):
        name = tokens[depth - 1] if depth else ""
        if isinstance(node, list) and _element_index(node, tok, name) is None and tok != "-":
            return list_entries(node, "/" + "/".join(tokens[:depth]))
        node = _child(node, tok, name)
        if node is _MISSING:
            return ""
    return ""


def apply_plan_edits(plan_obj: dict, edits: Any, notes: list[str] | None = None) -> tuple[dict, list[str]]:
    """Apply `edits` to a copy of `plan_obj` and return (copy, errors). An edit is {path, value} (path an RFC 6901
    JSON pointer; a list element by position, by its own id, or "-" and a position equal to the length to append)
    or {path, op: "remove"}. Every edit whose path the plan does not have is an error naming that pointer, and
    then nothing is applied: the model amends again against the plan it last saw, not against a half-edited one.

    `notes` collects one line per pointer that resolved by id where the position did not exist (`_element_index`),
    so an edit the tool re-read is on the record and not a silent reinterpretation."""
    import copy
    out = copy.deepcopy(plan_obj)
    errors: list[str] = []
    if not isinstance(edits, list) or not edits:
        return plan_obj, ["edits must be a non-empty list of {path, value}"]
    for i, edit in enumerate(edits):
        if not isinstance(edit, dict) or not isinstance(edit.get("path"), str):
            errors.append(f"edit {i}: needs a string path (a JSON pointer such as /patches/0/area)")
            continue
        path, op = edit["path"], edit.get("op") or "set"
        if op not in ("set", "remove"):
            errors.append(f"edit {path}: op must be set or remove, got {op!r}")
            continue
        if op == "set" and "value" not in edit:
            errors.append(f"edit {path}: no value given")
            continue
        tokens = _pointer_tokens(path)
        if tokens is None:
            errors.append(f"edit {path!r}: not a JSON pointer (start with / and separate keys and indices with /)")
            continue
        if not tokens:
            if op == "remove" or not isinstance(edit["value"], dict):
                errors.append("edit at the plan root must set a whole plan object")
            else:
                out = copy.deepcopy(edit["value"])
            continue
        node = out
        for depth, tok in enumerate(tokens[:-1]):
            parent = node
            name = tokens[depth - 1] if depth else ""
            if isinstance(parent, list) and notes is not None and tok.isdigit():
                at = _element_index(parent, tok, name)
                if at is not None and at != int(tok):
                    labels = _LIST_LABELS.get(name, ("id",))
                    notes.append(f"edit {path}: read as the entry whose {labels[0]} is {parent[at].get(labels[0])!r} (position "
                                 f"{at} in a list of {len(parent)}), because there is no position {tok}")
            node = _child(node, tok, name)
            if node is _MISSING:
                # a missing list index names what the list holds (R17): the model amends against the list as it is
                where = f"/{'/'.join(tokens[:depth + 1])}"
                listing = f"; {list_entries(parent, '/' + '/'.join(tokens[:depth]))}" if isinstance(parent, list) and tok.isdigit() else ""
                errors.append(f"edit {path}: no such path ({where} is not in the plan{listing})")
                break
        if node is _MISSING:
            continue
        last = tokens[-1]
        if isinstance(node, dict):
            if op == "remove":
                if last not in node:
                    errors.append(f"edit {path}: no such path ({last!r} is not a field there; fields: {sorted(node)[:12]})")
                    continue
                del node[last]
            else:
                node[last] = copy.deepcopy(edit["value"])
        elif isinstance(node, list):
            name = tokens[-2] if len(tokens) > 1 else ""
            idx = len(node) if last == "-" else _element_index(node, last, name)
            if idx is None and last.isdigit() and int(last) == len(node):
                idx = len(node)  # an index equal to the length appends
            if idx is None or idx > len(node) or (op == "remove" and idx == len(node)):
                errors.append(f"edit {path}: no element {last} in a list of {len(node)} (indices count from 0; - appends; "
                              f"{list_entries(node, '/' + '/'.join(tokens[:-1]))})")
                continue
            if last != "-" and last.isdigit() and idx != int(last) and notes is not None:
                labels = _LIST_LABELS.get(name, ("id",))
                notes.append(f"edit {path}: read as the entry whose {labels[0]} is {node[idx].get(labels[0])!r} (position {idx} "
                             f"in a list of {len(node)}), because there is no position {last}")
            if op == "remove":
                del node[idx]
            elif idx == len(node):
                node.append(copy.deepcopy(edit["value"]))
            else:
                node[idx] = copy.deepcopy(edit["value"])
        else:
            errors.append(f"edit {path}: the value at /{'/'.join(tokens[:-1])} is a {type(node).__name__}, not an object or a list")
    if errors:
        return plan_obj, errors
    return out, []


def _index_of(items: Any, key: str, value: Any) -> int | None:
    for i, it in enumerate(items if isinstance(items, list) else []):
        if isinstance(it, dict) and it.get(key) == value:
            return i
    return None


#: The plan fields added with schema 3 whose checker messages carry their own JSON pointer (grounding R2, R5, R6,
#: R8, R10 and the written mesh_warnings list under R1), plus object.confidence, whose R2 messages point at the
#: identity block the entry belongs in.
SCHEMA3_FIELD_PREFIXES = ("second_look", "mesh_warnings", "agent_risks_considered", "simulation_warnings",
                          "identity_hypotheses", "object.identity", "object.confidence")


def _item_pointer(plan_obj: dict, list_path: str, key: str, value: Any) -> str:
    """/list_path/i for the element whose `key` is `value`, or the list itself when no element has it."""
    node: Any = plan_obj
    for tok in list_path.strip("/").split("/"):
        node = node.get(tok) if isinstance(node, dict) else None
    idx = _index_of(node, key, value)
    return list_path if idx is None else f"{list_path}/{idx}"


def _risk_pointer(plan_obj: dict, ident: str, tail: str = "") -> str:
    """A risk by id (k3) or by kind (short_stub); the risks list when neither matches."""
    risks = plan_obj.get("risks") if isinstance(plan_obj.get("risks"), list) else []
    idx = _index_of(risks, "id", ident)
    if idx is None:
        idx = _index_of(risks, "kind", ident)
    return "/risks" if idx is None else f"/risks/{idx}{tail}"


def error_pointer(message: str, plan_obj: dict) -> str:
    """The JSON pointer a checker message points at: the field or id it names, resolved against the submitted
    plan; the plan root ("") when it names nothing the plan holds. The messages are grounding.py's own."""
    import re
    m = re.match(r"^schema: \((.*)\):", message)
    if m:
        import ast
        try:
            loc = ast.literal_eval("(" + m.group(1).rstrip(",") + ",)")
        except (ValueError, SyntaxError):
            return ""
        return "/" + "/".join(str(x) for x in loc) if loc else ""
    m = re.match(r"^(?:synthetic )?patch ([A-Za-z0-9_\-]+)(?:\.([a-z_]+))?", message)
    if m:
        p = _item_pointer(plan_obj, "/patches", "id", m.group(1))
        return p + (f"/{m.group(2)}" if m.group(2) and p != "/patches" else "")
    if message.startswith("opening ") and "has no patch" in message:
        return "/patches"
    m = re.match(r"^flow\.([a-z_]+)", message)
    if m:
        return f"/flow/{m.group(1)}"
    if message.startswith(("a wall file has no inlet", "no ports assigned")):
        return "/flow"
    if message.startswith("missing catalog risk") or "operating_point_missing" in message.split(":")[0]:
        return "/risks"
    m = re.match(r"^(?:agent )?risk ([A-Za-z0-9_]+)\.measurement\.([A-Za-z0-9_]+)", message)
    if m:
        return _risk_pointer(plan_obj, m.group(1), f"/measurement/{m.group(2)}")
    m = re.match(r"^(?:the brief says to proceed: )?(?:agent )?risk ([A-Za-z0-9_]+)(?: \(([A-Za-z0-9_]+)[^)]*\))?(?=[:, ]|$)", message)
    if m:
        if "no question relates" in message:
            return "/questions"
        tail = "/derivation" if "derivation" in message else "/severity" if "severity must stay" in message else ""
        p = _risk_pointer(plan_obj, m.group(1), tail)
        return p if p != "/risks" or not m.group(2) else _risk_pointer(plan_obj, m.group(2), tail)
    m = re.match(r"^questions? ([A-Za-z0-9_]+)(?: and ([A-Za-z0-9_]+))?", message)
    if m:
        return _item_pointer(plan_obj, "/questions", "id", m.group(2) or m.group(1))
    m = re.match(r"^refinement '([^']*)'", message)
    if m:
        return _item_pointer(plan_obj, "/mesh_plan/refinement_regions", "where", m.group(1))
    m = re.match(r"^layer target (?:for unknown patch )?'?([A-Za-z0-9_\-]+)'?", message)
    if m:
        return _item_pointer(plan_obj, "/mesh_plan/layer_targets", "patch_id", m.group(1))
    m = re.match(r"^port_extensions (?:names ')?([A-Za-z0-9_\-]+)", message)
    if m:
        return _item_pointer(plan_obj, "/mesh_plan/port_extensions", "patch_id", m.group(1))
    if message.startswith("required_extents"):
        return "/mesh_plan/required_extents"
    m = re.match(r"^mesh_plan\.([a-z_]+)", message)
    if m:
        return f"/mesh_plan/{m.group(1)}"
    if message.startswith(("internal flow needs a region", "a wall_shell region", "conjugate heat transfer needs",
                           "a rotating_zone region", "not_a_fluid_body needs")):
        return "/mesh_plan/regions"
    m = re.match(r"^unit\.([a-z]+)", message)
    if m:
        return f"/unit/{m.group(1)}"
    m = re.match(r"^object\.evidence\[(\d+)\]", message)
    if m:
        return f"/object/evidence/{m.group(1)}"
    if message.startswith(SCHEMA3_FIELD_PREFIXES):
        # the schema 3 fields carry their JSON pointer in the text ("second_look[2] (/second_look/2): ...",
        # "mesh_warnings (/mesh_warnings): ...", "object.identity.type ... (/object/identity/type)"); a message
        # without one points at the field it opens with
        m = re.search(r"\((/[A-Za-z0-9_/\-]+)\)", message)
        if m:
            return m.group(1)
        return "/" + message.split(" ", 1)[0].split("[", 1)[0].rstrip(":").replace(".", "/")
    for start, pointer in (("object.confidence", "/object/confidence"), ("facts_sha256", "/facts_sha256"),
                           ("purpose must be", "/purpose"), ("analysis must", "/analysis"),
                           ("summary_for_builder", "/summary_for_builder"), ("both summaries", "/summary_for_user"),
                           ("the brief says to proceed: summary_for_user", "/summary_for_user"),
                           ("the instruction to proceed is not a brief conflict", "/brief_conflicts")):
        if message.startswith(start):
            return pointer
    return ""


def error_pointers(errors: list[str], plan_obj: dict) -> list[str]:
    """One pointer per distinct target of the checker messages, in the order the messages came."""
    out: list[str] = []
    for msg in errors:
        p = error_pointer(msg, plan_obj if isinstance(plan_obj, dict) else {})
        if p not in out:
            out.append(p)
    return out


def amend_instruction(pointers: list[str], applied: bool = True, plan_obj: dict | None = None) -> str:
    """The rejection's instruction: the paths to amend and how, in place of a full resubmission. With the plan
    the edits were applied against, a pointer whose list index the plan does not have (an amend at /risks/3 of
    a three-risk list) is followed by that list's valid indices and ids (R17)."""
    shown = ", ".join(p or "(the plan root)" for p in pointers) or "(the plan root)"
    text = (f"amend these paths: {shown}. Call {AMEND} with edits [{{path, value}}] at those JSON pointers (indices "
            "count from 0; a value that replaces a list element is the whole element). Do not resubmit the whole "
            "plan, do not restructure or re-analyse, and call no other tool unless an error requires a number you lack.")
    if not applied:
        text += " No edit was applied; the last submitted plan stands as it was."
    if isinstance(plan_obj, dict):
        notes = []
        for p in pointers:
            note = missing_index_note(plan_obj, p or "")
            if note and note not in notes:
                notes.append(note)
        if notes:
            text += " The plan as it stands: " + "; ".join(notes) + "."
    return text


# ---------------------------------------------------------------------------------------------------------------
# A plan whose tail the serialisation lost (P4.3d, docs/plan_v3_rules.md section 11). `loop.salvage_json` closes
# off a submission that ended mid-JSON, so what reaches the checker is a plan short of whatever came after the cut.
# Pydantic stops at the structure, so such a rejection is nothing but "Field required" lines: not one content rule
# has run, and not one of those lines is the model's judgement. These name the class, and say what belongs where.
# ---------------------------------------------------------------------------------------------------------------
#: How grounding renders a pydantic error: `schema: ('mesh_plan',): Field required`.
SCHEMA_ERROR = "schema: ("
MISSING_FIELD = "): Field required"
#: The companion line grounding's R32 puts beside those: the schema 3 fields the same cut lost silently. It is the
#: structure of the plan too, not a judgement of it, so it does not make the rejection the model's. The end-to-end
#: tests run a truncated plan through the real checker, so a reword breaks them rather than charging the model.
TAIL_FIELDS_NOTE = "these schema 3 fields are missing too"


def is_missing_field(message: str) -> bool:
    """True for a checker error that says a required plan field was not there at all."""
    return message.startswith(SCHEMA_ERROR) and MISSING_FIELD in message


def missing_fields_only(errors: list[str]) -> bool:
    """The rejection is about the plan's structure and nothing else: at least one missing required field, and no
    line but those and R32's list of the fields the same cut took. The signature of a submission whose tail was
    lost, with no judgement of the model's in it yet (pydantic stops before a content rule runs)."""
    return (bool(errors) and any(is_missing_field(e) for e in errors)
            and all(is_missing_field(e) or TAIL_FIELDS_NOTE in e for e in errors))


#: What each required field of the plan is for, in one clause. The shape comes from the plan schema itself
#: (`field_contract`), where it is already written down; this is the half the schema cannot say.
FIELD_PURPOSE = {
    "purpose": "the user's purpose, unchanged",
    "object": "what the object is, with the identity verdict",
    "unit": "the unit every size in the plan is in",
    "patches": "one per measured opening plus the walls patch",
    "flow": "axis times direction_sign points from the inlets to the outlets",
    "risks": "every list_risks entry unchanged, then your own from k101 up",
    "mesh_plan": "the mesh plan",
    "questions": "one per decision only the user can settle; [] when the brief settles them all",
    "analysis": "the reasoning, in prose",
    "summary_for_user": "concluded, assumed, needed",
    "summary_for_builder": "the unit line, then the prose for the builder",
}


def _shape_of(annotation: Any) -> str:
    """The shape a plan field asks for, read off the schema: a model's required keys, a list of them, or the type."""
    import typing

    from pydantic import BaseModel
    origin, args = typing.get_origin(annotation), typing.get_args(annotation)
    if origin is typing.Literal:
        return "one of " + ", ".join(str(a) for a in args)
    if origin is dict:
        return "an object"
    if args and origin in (list, tuple, set, frozenset):
        return "a list of " + (_shape_of(args[0]) or "values")
    if args:  # an optional or a union: the first member that is not None carries the shape
        return _shape_of(next((a for a in args if a is not type(None)), None))
    if isinstance(annotation, type) and issubclass(annotation, BaseModel):
        keys = ", ".join(n for n, f in annotation.model_fields.items() if f.is_required())
        return "{" + keys + "}" if keys else "an object"
    if annotation is str:
        return "text"
    return getattr(annotation, "__name__", "") if annotation is not None else ""


def _model_of(annotation: Any):
    """The model a field holds, through a list or an optional; None when it holds no model."""
    import typing

    from pydantic import BaseModel
    if isinstance(annotation, type) and issubclass(annotation, BaseModel):
        return annotation
    for arg in typing.get_args(annotation):
        model = _model_of(arg)
        if model is not None:
            return model
    return None


def _field_at(pointer: str):
    """The plan field a JSON pointer names, walking the nested models and skipping list indices; None when the
    plan schema has no such field (the cut can land anywhere, including a field of the model's own invention)."""
    from geometry_agent.agent.schema import GeometryPlan
    model, field_ = GeometryPlan, None
    for tok in (t for t in pointer.strip("/").split("/") if t and not t.isdigit()):
        fields = getattr(model, "model_fields", None) if model is not None else None
        if not fields or tok not in fields:
            return None
        field_ = fields[tok]
        model = _model_of(field_.annotation)
    return field_


def field_contract(pointer: str) -> str:
    """What belongs at a plan pointer: what the field is for (the top-level clause), then the keys the schema asks
    for. A scalar's type is not news next to a purpose, so it is dropped there and kept where there is none
    (/mesh_plan/required_extents). "" for a pointer the plan schema does not name."""
    field_ = _field_at(pointer)
    if field_ is None:
        return ""
    purpose = FIELD_PURPOSE.get(pointer.strip("/"), "")
    shape = _shape_of(field_.annotation)
    if purpose and not shape.startswith(("{", "a list of")):
        shape = ""
    return ": ".join(p for p in (purpose, shape) if p)


def missing_field_notes(errors: list[str], plan_obj: dict | None = None) -> list[str]:
    """The errors with, on every missing required field, the pointer an amend goes to and what belongs there.
    Any other message passes through untouched."""
    out: list[str] = []
    for e in errors:
        if is_missing_field(e) and e.rstrip().endswith("Field required"):
            pointer = error_pointer(e, plan_obj if isinstance(plan_obj, dict) else {})
            note = field_contract(pointer)
            out.append(f"{e} ({pointer}): {note}" if note else f"{e} ({pointer})")
        else:
            out.append(e)
    return out


#: The instruction a plan short of its tail gets back: the pointers, and one call for all of them. All 27 of those
#: rejections in the live learning-half run were finished by a single amend; what the rejection lacked was the
#: contract per field and the charge (docs/plan_v3_rules.md section 11).
SALVAGE_AMEND = ("Add all {n} in one {amend} call: edits [{{path, value}}], one entry per path above, each value the "
                 "whole object or text that belongs there. Nothing else in the plan has to change, and a second "
                 "call costs another round.")
SALVAGE_AMEND_ONE = ("Add it with one {amend} call: edits [{{path, value}}] at that path, the value the whole object "
                     "or text that belongs there. Nothing else in the plan has to change.")


def tail_pointers(tail: list[str] | None) -> list[str]:
    """The pointers of grounding's `missing_v3_tail` lines (`/second_look: one line per item ...` -> `/second_look`).

    The schema 3 tail is optional at the type level, so pydantic never names it and it reaches the loop only as a
    hint. It is still a field the plan must carry and the same cut took it, so the amend paths and the instruction
    have to name it too: otherwise the rejection asks for the four required fields, says nothing else has to
    change, and the next round is spent on the three it did not ask for (R32, docs/plan_v3_rules.md section 12)."""
    out: list[str] = []
    for line in tail or []:
        pointer = str(line).split(":")[0].strip()
        if pointer.startswith("/") and pointer not in out:
            out.append(pointer)
    return out


def salvage_instruction(pointers: list[str]) -> str:
    """The amend instruction for a submission the serialisation cut short: finish the plan in one call."""
    shown = ", ".join(p or "(the plan root)" for p in pointers) or "(the plan root)"
    amend = (SALVAGE_AMEND_ONE if len(pointers) <= 1 else SALVAGE_AMEND).format(n=len(pointers), amend=AMEND)
    return f"amend these paths: {shown}. " + amend


def _deref(schema: dict) -> dict:
    """Inline every $ref so providers that reject $defs still get the full structure."""
    defs = schema.get("$defs", {})

    def walk(node):
        if isinstance(node, dict):
            if "$ref" in node:
                target = defs[node["$ref"].split("/")[-1]]
                merged = {k: v for k, v in target.items() if k != "title"}
                merged.update({k: v for k, v in node.items() if k != "$ref"})
                return walk(merged)
            return {k: walk(v) for k, v in node.items() if k not in ("$defs", "title")}
        if isinstance(node, list):
            return [walk(v) for v in node]
        return node
    return walk(schema)


# ---------------------------------------------------------------------------------------------------------------
# The submit tool's parameter schema, in the short form (P4.3e, docs/plan_v3_rules.md section 14).
#
# The schema is resent whole on every round and it is what the model reads most literally: prompt v3 has said
# "the checker fills patch numbers, facts_sha256, base size, cell estimate" since it was written, and the live
# learning-half run wrote all of them anyway, 419 characters of measured patch numbers a plan, because the tool
# schema listed them as fields of the plan. A field the checker fills is not in the schema the model is given.
# What is left is pruned of the boilerplate pydantic writes and no model reads: `anyOf [X, null]` says only what
# `required` already says, `default: null` says nothing at all, and a Vec3's three identical `prefixItems` are
# `items` with a length.
# ---------------------------------------------------------------------------------------------------------------
#: Fields the checker fills or owns, by the path of the object that carries them. Every one is replaced or
#: computed in grounding._normalise (the patch numbers by _fill_patch_numbers, R22; cell_estimate_refined on
#: every plan, written or not) or by the confirm step, so a model writing one cannot change the plan.
CHECKER_FILLED: dict[tuple[str, ...], tuple[str, ...]] = {
    (): ("facts_sha256",),
    ("patches",): ("area", "centroid", "normal", "hydraulic_diameter"),
    ("mesh_plan",): ("base_size", "cell_estimate", "cell_estimate_refined"),
    #: detected_by reads off the kind (R25) and the live run wrote "catalog" on 324 of 361 warnings because the
    #: schema's default said so, which is 158 rejections in 116 of the 159 cases; if_it_fails is earned from
    #: recorded retries and is never the model's to write.
    ("mesh_warnings",): ("detected_by", "if_it_fails"),
    #: the confirm step writes these when the user answers.
    ("simulation_warnings",): ("answer", "settled_by"),
}
#: The one line the submit tool says instead of listing them.
CHECKER_FILLED_NOTE = ("The checker fills every measured number for you: a patch's area, centroid, normal and "
                       "hydraulic diameter, facts_sha256, the tier's base size and cell estimates, a mesh "
                       "warning's detected_by. They are not fields of this schema; writing them changes nothing.")


def _prune_boilerplate(node: Any) -> Any:
    """`anyOf [X, null]` is X (a field is optional because `required` does not name it), `default: null` is
    nothing, and three identical `prefixItems` are `items` with a length."""
    if isinstance(node, list):
        return [_prune_boilerplate(v) for v in node]
    if not isinstance(node, dict):
        return node
    options = node.get("anyOf")
    if isinstance(options, list) and len(options) == 2 and {"type": "null"} in options:
        other = next(o for o in options if o != {"type": "null"})
        if isinstance(other, dict):
            node = {**{k: v for k, v in node.items() if k != "anyOf"}, **other}
    out = {k: _prune_boilerplate(v) for k, v in node.items() if not (k == "default" and v is None)}
    items = out.get("prefixItems")
    if isinstance(items, list) and items and all(i == items[0] for i in items):
        out.pop("prefixItems")
        out["items"] = items[0]
    return out


def _drop_filled(schema: Any, path: tuple[str, ...] = ()) -> Any:
    """The schema without the fields the checker fills, at every level of the plan."""
    if not isinstance(schema, dict):
        return schema
    out = dict(schema)
    if isinstance(out.get("items"), dict):
        out["items"] = _drop_filled(out["items"], path)
    props = out.get("properties")
    if isinstance(props, dict):
        cut = set(CHECKER_FILLED.get(path, ()))
        out["properties"] = {k: _drop_filled(v, path + (k,)) for k, v in props.items() if k not in cut}
        if isinstance(out.get("required"), list):
            out["required"] = [r for r in out["required"] if r in out["properties"]]
    return out


def plan_parameters_schema(short: bool = True) -> dict:
    """The plan schema the submit tool advertises. `short` is the form the model is given: without the fields the
    checker fills and without the boilerplate. The full form is what `schema.GeometryPlan` still accepts, so a
    plan that writes a filled field parses exactly as before and the checker replaces it as it always did."""
    from geometry_agent.agent.schema import GeometryPlan
    full = _deref(GeometryPlan.model_json_schema())
    return _drop_filled(_prune_boilerplate(full)) if short else full


def _fn(name: str, description: str, properties: dict | None = None, required: list[str] | None = None) -> dict:
    return {"type": "function", "function": {
        "name": name, "description": description,
        "parameters": {"type": "object", "properties": properties or {}, "required": required or []},
    }}


ROLE_ENUM = ["inlet", "outlet", "wall", "farfield", "symmetry", "interface", "opening_unknown", "closed_end"]

SCHEMAS: list[dict] = [
    _fn("get_facts_summary", "Everything measured about the geometry, compactly. Call this first."),
    _fn("list_openings", "Every planar end or open rim that could be a port, with its measured stub length."),
    _fn("get_opening", "One opening in full.", {"opening_id": {"type": "string"}}, ["opening_id"]),
    _fn("list_regions", "Connected components of the surface and what each encloses."),
    _fn("get_features", "Edge lengths, sharp and knife edges, wall thickness statistics, thin clusters, gaps."),
    _fn("get_axes", "Principal axes, symmetry planes, and which end is blunt."),
    _fn("get_names", "Entity names left in the file by the CAD author, with the role each name implies."),
    _fn("get_unit_evidence", "Declared unit and which units make the size plausible for the purpose."),
    _fn("estimate_cells", "Cell count estimate per fidelity tier with its assumptions and the surface cell the tier already "
        "puts on every surface. Pass refinement_regions (your plan's list) with a tier to see what they add (refined_cells).",
        {"tier": {"type": "string", "enum": ["draft", "standard", "max"]},
         "refinement_regions": {"type": "array", "items": {"type": "object"}, "description": "the plan's refinement_regions"}}),
    _fn("list_risks",
        "The deterministic failure catalog. Without roles: every planar end is a possible port. With roles: the "
        "definitive list for those roles. Call with roles before submitting; the plan must contain every risk returned.",
        {"roles": {"type": "object", "additionalProperties": {"type": "string", "enum": ROLE_ENUM},
                   "description": "opening_id -> role"}}),
    _fn("probe_section", "Cross-section N diameters inward from an opening: how many loops, area relative to the opening, "
        "where its centroid is. Use it to see what lies downstream of a port before assigning its role.",
        {"opening_id": {"type": "string"}, "distance_over_d": {"type": "number"}}, ["opening_id", "distance_over_d"]),
    _fn("section_profile", "Cross-section area against distance inward from an opening, all stations in one call (up to 50 "
        "diameters, default 15 at 0.5 steps), plus the taper it implies (length, half angle, area ratio), the throat "
        "station and the velocity ratio there. The shape of a diffuser, nozzle, venturi, expansion or bend as a curve. "
        "Use this instead of repeated probe_section calls.",
        {"opening_id": {"type": "string"}, "max_over_d": {"type": "number"}, "step_over_d": {"type": "number"}}, ["opening_id"]),
    _fn("distance_between", "Distance and relative orientation of two openings, and whether they belong to the same body.",
        {"opening_a": {"type": "string"}, "opening_b": {"type": "string"}}, ["opening_a", "opening_b"]),
    _fn("render_view", "Render one view of the geometry with axis arrows. Only when facts and names leave identity ambiguous.",
        {"direction": {"type": "string", "enum": ["+x", "-x", "+y", "-y", "+z", "-z", "iso"]},
         "focus_opening_id": {"type": "string"}}, ["direction"]),
    _fn(DERIVED,
        "Arithmetic over measured numbers, done by code and recorded in the ledger under a derivation id (d1, d2, ...) with "
        "its formula, so the plan cites the id instead of a number you worked out. Never do this arithmetic by hand. ops and "
        "args: port_tilt {opening_id} (tilt off the grid, grid axis, grid_aligned, mouth shape, min in-plane dimension); "
        "run_between {a, b} (distance along the run between two openings, or 'o3.stub_end' for a stub's end point, in D of "
        "each); dead_leg {junction_opening, closed_end_opening, inlet?} (signed distance from the junction's stub end to the "
        "closed end along the run; negative when the closed end is upstream, and then it is not a dead leg); angle_between "
        "{a, b} (from the normals and the inward directions); taper {a, b} (half angle and area ratio from the two bores and "
        "the stub-end distance); first_cell {bore, velocity, nu, yplus, unit?} (height in file units, the log-law estimate "
        "written out with its assumptions); reynolds {bore, velocity, nu, unit?}; cells_across {feature, frame: agent|builder, "
        "cells_across_diameter?, inlet?} (feature an opening id, a thin cluster id, 'thin' or 'gap'; builder frame divides by "
        "the inlet bore over cells_across_diameter, default 24); unit_convert {value, from, to}; eval {expr, names} (any "
        "arithmetic with sqrt, log, exp, trig, min, max, pi over names bound to ledger numbers or derivation ids such as "
        "{D: 0.05, h: 'd2.first_cell_height'}; names must bind at least one measured number, so a 5 D extension is expr "
        "'5 * D' with {D: the bore}, never '5 * 93.1' with no names, and pi is already there). Returns {derivation_id, "
        "values, formula, inputs}; the bore, value and every name must be a number from a tool result or the brief.",
        {"op": {"type": "string", "enum": list(DERIVED_OPS)},
         "args": {"type": "object", "description": "the op's arguments, as listed"}}, ["op", "args"]),
    _fn(COMPARE_ROLES,
        "The catalog under two role assignments and the diff: the risks only under each, severity sums, the number of high "
        "risks, the seed point and the diffuser direction each implies, and which assignment has fewer high risks; recorded "
        "under a derivation id. Call it when inlet and outlet are interchangeable (role_assumed) or a role is asked about, "
        "and write flow.counterfactual {swap, what_breaks} citing its numbers or its derivation id.",
        {"roles_a": {"type": "object", "additionalProperties": {"type": "string", "enum": ROLE_ENUM},
                     "description": "opening_id -> role, the assignment the plan uses"},
         "roles_b": {"type": "object", "additionalProperties": {"type": "string", "enum": ROLE_ENUM},
                     "description": "opening_id -> role, the other assignment"}}, ["roles_a", "roles_b"]),
    _fn(AMEND,
        "Fix a rejected submission in place: apply edits to the plan you last submitted and run the same checker; "
        "returns the same accepted / rejected result as submit_geometry_plan. Each edit is {path, value} with path a "
        "JSON pointer into the plan (/patches/0/area, /risks/2/derivation, /questions/1, "
        "/mesh_plan/refinement_regions/0/radius; indices count from 0; /questions/- appends; {path, op: 'remove'} "
        "deletes). A list element may be named by its own id instead of its position, which is safer when the "
        "position is not in front of you: /risks/k2/derivation, /mesh_plan/port_extensions/o9/length, "
        "/patches/o3/role. A rejection lists the paths to amend. Use this after every rejection instead of resubmitting.",
        {"edits": {"type": "array", "description": "the edits, in order",
                   "items": {"type": "object", "required": ["path"],
                             "properties": {"path": {"type": "string", "description": "JSON pointer into the plan"},
                                            "value": {"description": "the new value at path (any JSON)"},
                                            "op": {"type": "string", "enum": ["set", "remove"]}}}},
         "note": {"type": "string", "description": "one line on what the edits fix"}},
        ["edits"]),
    _fn(SUBMIT,
        "Submit the plan. Rejected if any number is not traceable to a tool result, any opening id is unknown, or any "
        "risk from list_risks(roles) is missing. After a rejection, fix the listed paths with amend_geometry_plan. "
        + CHECKER_FILLED_NOTE,
        {"plan": plan_parameters_schema()},
        ["plan"]),
]

LOOK_SCHEMA = _fn(
    LOOK,
    "Look at the part again, with a question. The run already opened with a look: the description under WHAT THE PART "
    "LOOKS LIKE in your first message is a vision model reading nine rendered views of this file (six axis views, two "
    "isometrics and a cutaway; axis arrows red +X, green +Y, blue +Z; openings labelled by id). Call this only to "
    "settle something that description does not answer: name the opening in focus_opening_id, or put the doubt in "
    "question, and the answer comes back in the impression's notes. One such follow-up per run; a call with no "
    "question and no focus returns the description you already have and costs nothing. What a look may change: "
    "object.type, an evidence string (written as 'visual impression: ...'), a role's confidence, a question's "
    "wording. What it may not: any number, any measured class (port_candidate, planar_face, hole, ring, interface), "
    "the unit. Nothing it returns is a measurement, and an identity that rests on it alone is held at 0.6 confidence "
    "or below.",
    {"question": {"type": "string", "description": "what you want the look to settle, in words"},
     "focus_opening_id": {"type": "string", "description": "an opening id to describe in detail"}},
)


#: The two tools that write a plan, in SCHEMAS order (amend, then submit). Every other schema is a measurement.
PLAN_ONLY_SCHEMAS: list[dict] = SCHEMAS[-2:]


def schemas_for(ctx: ToolContext, plan_only: bool = False) -> list[dict]:
    """The model's tool list for this run: SCHEMAS, plus look_at_views only when a vision model is attached,
    so a run without one never spends a round on it.

    `plan_only` withdraws every measurement tool and leaves the two that write a plan. The loop sets it once a
    run has spent its probing budget without submitting: a live run showed the model taking the submit nudge as
    advice and probing through seventeen of them to the hard stop, so past the cutoff the probes are not there
    to call. A run that has never submitted keeps only submit (there is nothing to amend)."""
    if plan_only:
        return PLAN_ONLY_SCHEMAS if ctx.last_plan is not None else PLAN_ONLY_SCHEMAS[-1:]
    if ctx.vision is None:
        return SCHEMAS
    return SCHEMAS[:-1] + [LOOK_SCHEMA, SCHEMAS[-1]]


# ---------------------------------------------------------------------------------------------------------------
# The builder's frame. The snappy renderer sizes cells from the declared inlet's bore and cells_across_diameter,
# not from the agent's diagonal/80 tier, so every "cells across" number the builder will see has to be computed
# with the renderer's own rules. Those rules are reproduced here, each constant citing the platform line it was
# read from (hexera-platform-v2 at PLATFORM_SHA, src/meshpipeline; the audit is docs/handover_consumers.md).
# Nothing here imports the platform.
# ---------------------------------------------------------------------------------------------------------------
PLATFORM_SHA = "57684388c66c5968bed166f4c5121c1c9110dd48"

#: engines/snappy/drivers.py:578  cells_across = max(8, int(strategy.get("cells_across_diameter", 24)))
BUILDER_CELLS_ACROSS_DEFAULT = 24
BUILDER_CELLS_ACROSS_MIN = 8
#: drivers.py:576  strategy.get("surface_level", 2); :582 feature_level defaults to surface_level + 1
BUILDER_SURFACE_LEVEL_DEFAULT = 2
#: drivers.py:579 and snappy_runner.py:500  n_layers default 3
BUILDER_N_LAYERS_DEFAULT = 3
#: drivers.py:580 (internal 0.3) and snappy_runner.py:501 (external 0.35)
BUILDER_FIRST_LAYER_REL = {"internal": 0.3, "external": 0.35}
#: snappy_runner.py:459 and :614  max_cells default 8_000_000 (settings/policy.py:15 CELL_HARD_LIMIT default)
BUILDER_MAX_CELLS_DEFAULT = 8_000_000
#: snappy_runner.py:619  pad = max(2.0 * base_cell, 0.03 * maxext)
INTERNAL_PAD_CELLS, INTERNAL_PAD_OF_EXTENT = 2.0, 0.03
#: snappy_runner.py:624  div = [max(8, min(120, int(round(dext[i] / base_cell)))) for i in range(3)]
INTERNAL_DIV_MIN, INTERNAL_DIV_MAX = 8, 120
#: snappy_runner.py:637  near_dist = max(3.0 * base_cell, 0.08 * maxext)
NEAR_BAND_CELLS, NEAR_BAND_OF_EXTENT = 3.0, 0.08
#: snappy_runner.py:632 and :440  _HARD_MAX_LEVEL = 10
HARD_MAX_LEVEL = 10
#: snappy_runner.py:679 and :533  nCellsBetweenLevels 3
CELLS_BETWEEN_LEVELS = 3
#: snappy_runner.py:686 and :540  expansionRatio 1.2
LAYER_EXPANSION = 1.2
#: cad/analysis.py:160 and :166  base_cell = L / base_divisions, base_divisions 24; :160 body_cells 150,
#: :159 cells_per_feature 8, :161 max_level 8, :162 depth 12
EXTERNAL_BASE_DIVISIONS, EXTERNAL_BODY_CELLS, EXTERNAL_CELLS_PER_FEATURE = 24, 150, 8
EXTERNAL_MAX_LEVEL, EXTERNAL_DEPTH = 8, 12
#: cad/analysis.py:190-191  near = 6 surface cells, far = max(4 near, 0.04 L)
EXTERNAL_NEAR_CELLS, EXTERNAL_FAR_MULT, EXTERNAL_FAR_OF_L = 6.0, 4.0, 0.04
#: snappy_runner.py:308-309  domain_margin defaults up 2, down 4, side 2, vert 2 (body lengths)
EXTERNAL_MARGINS = {"up": 2.0, "down": 4.0, "side": 2.0, "vert": 2.0}
#: snappy_runner.py:355  _VERT_FLOOR = 2.0 when the axis roles are known
EXTERNAL_VERT_FLOOR = 2.0
#: snappy_runner.py:411-422  _BG_MAX_DIV 256, floor 12, _BG_CELL_BUDGET 600_000, trim factor 0.92
BG_MAX_DIV, BG_MIN_DIV, BG_CELL_BUDGET, BG_TRIM = 256, 12, 600_000, 0.92
#: engines/gmsh/driver.py:258  size default {"mode": "factor", "value": 0.04}; :263 MeshSizeMin h / 20;
#: :265 curvature_nodes 24
GMSH_SIZE_FACTOR, GMSH_SIZE_MIN_OVER, GMSH_CURVATURE_NODES = 0.04, 20.0, 24
#: tetrahedra per h cubed: about 6 (a tet of edge h has volume near h**3 / 6 in a graded Delaunay fill)
GMSH_TETS_PER_H3 = 6.0

_REP_KEY = {"carve": "wall_shell"}


def _rep_key(representation: str | None) -> str:
    """The catalog's representation name for a corpus or handover name (carve is the corpus word for wall_shell)."""
    return _REP_KEY.get(representation or "", representation or "unknown")


def builder_inlet(facts: GeometryFacts, representation: str | None, inlet_id: str | None = None):
    """The opening the renderer sizes from and the area it reads: with a binding the declared inlet's opening
    (a ring by what its inner wire encloses, drivers.py:422-438); without one the widest planar opening
    (cad_tessellate.py:614 and :631). Returns (opening, area) or (None, 0.0)."""
    rep = _rep_key(representation)
    ports = _builder_ports(facts, rep)
    if inlet_id:
        o = facts.opening(inlet_id)
        if o is not None:
            return o, float(catalog.port_area(facts, o, rep))
    if not ports:
        return None, 0.0
    o = max(ports, key=lambda p: catalog.port_area(facts, p, rep))
    return o, float(catalog.port_area(facts, o, rep))


def _builder_ports(facts: GeometryFacts, rep: str) -> list:
    """The openings the renderer would cut as ports: the catalog's port openings under the representation, and
    when it names none, every planar face (a cap or a ring), which is what tessellate_internal takes
    (cad_tessellate.py:588-591: planar face -> opening candidate)."""
    ports = catalog.port_openings(facts, rep)
    if ports:
        return ports
    return [o for o in facts.openings if o.kind in ("cap", "ring")]


def port_min_dimension(o) -> float:
    """The smallest in-plane dimension of a port mouth: the bore of a ring, the short side of a rectangle, the
    hydraulic diameter otherwise. The dimension the builder's wall cell has to fit across."""
    if o.kind == "ring" and o.bore_diameter:
        return float(o.bore_diameter)
    if o.shape == "rectangle" and o.width > 0 and o.height > 0:
        return float(min(o.width, o.height))
    if o.width > 0 and o.height > 0:
        return float(min(o.width, o.height, o.hydraulic_diameter or max(o.width, o.height)))
    return float(o.hydraulic_diameter or o.equivalent_diameter or 0.0)


def port_hydraulic_diameter(facts: GeometryFacts, o, rep: str) -> float:
    """4 A / P of the mouth flow crosses: a ring's bore under a wall shell (the annulus between the bore and an
    inner body's end cap when one sits in it), the ring face under an annular passage, the face's own hydraulic
    diameter otherwise. A passage's volume over its wetted area is this over 4, whatever its section."""
    if o.kind == "ring" and o.bore_diameter:
        area = float(catalog.port_area(facts, o, rep))
        if area <= 0:
            return 0.0
        if rep == "annular_fluid":
            outer = 2.0 * math.sqrt(max(float(o.area), 0.0) / math.pi)
            perimeter = math.pi * (outer + float(o.bore_diameter))
        else:
            perimeter = math.pi * float(o.bore_diameter) + sum(math.pi * float(c.equivalent_diameter)
                                                                for c in catalog.inner_caps(facts, o))
        return 4.0 * area / perimeter if perimeter > 0 else 0.0
    return float(o.hydraulic_diameter or o.equivalent_diameter or 0.0)


def port_tilt_deg(o) -> float:
    """How far the mouth's normal sits off the nearest grid axis, in degrees: the background hex grid is axis
    aligned, so a tilted circular mouth is cut by stair-stepped cells and its port cap sits one level coarser
    than the wall (snappy_runner.py:636)."""
    n = [abs(float(v)) for v in o.normal]
    m = max(n)
    if m <= 0:
        return 90.0
    return float(math.degrees(math.acos(min(1.0, m))))


def builder_frame(facts: GeometryFacts, representation: str | None, strategy: dict | None = None,
                  inlet_id: str | None = None) -> dict:
    """Every port in the builder's cells: the wall cell is the inlet bore over cells_across_diameter
    (drivers.py:584 with :634, so the level cancels), and each port's min in-plane dimension is divided by it."""
    strategy = strategy or {}
    rep = _rep_key(representation)
    inlet, area = builder_inlet(facts, rep, inlet_id)
    cells_across = max(BUILDER_CELLS_ACROSS_MIN, int(strategy.get("cells_across_diameter", BUILDER_CELLS_ACROSS_DEFAULT)))
    bore = 2.0 * math.sqrt(area / math.pi) if area > 0 else 0.0
    wall_cell = bore / cells_across if bore > 0 else 0.0
    ports = []
    for o in _builder_ports(facts, rep):
        md = port_min_dimension(o)
        tilt = port_tilt_deg(o)
        ports.append({"id": o.id, "kind": o.kind, "shape": o.shape, "min_dimension": md,
                      "cells_across_builder": (md / wall_cell) if wall_cell > 0 else None,
                      "tilt_deg": round(tilt, 3), "grid_aligned": tilt <= 0.5,
                      "bore_over_extent": (md / max(facts.bbox.extent)) if max(facts.bbox.extent) > 0 else None})
    smallest = min(ports, key=lambda p: p["min_dimension"]) if ports else None
    return {"inlet_id": inlet.id if inlet else None, "bore": bore, "cells_across": cells_across, "wall_cell": wall_cell,
            "ports": ports, "smallest_port": smallest}


def _fluid_geometry(facts: GeometryFacts, rep: str, ports: list, bore: float, inlet=None) -> tuple[float, float, list[str]]:
    """(fluid volume, wall area, notes) the carve will fill. A fluid body's volume is measured; a wall shell's
    cavity is not (the renderer discovers it by carving), so it is taken as the inner skin's area times a quarter
    of the inlet's hydraulic diameter: a passage's volume over its wetted area is D_h / 4 for any section (the
    bore of a round tube, the gap of an annulus)."""
    notes: list[str] = []
    port_area = sum(float(catalog.port_area(facts, o, rep)) for o in ports)
    if rep == "wall_shell":
        annuli = sum(max(0.0, o.area - (o.bore_area or 0.0)) for o in ports if o.kind == "ring")
        wall = 0.5 * max(0.0, facts.total_surface_area - annuli)
        dh = (port_hydraulic_diameter(facts, inlet, rep) if inlet is not None else 0.0) or bore
        volume = wall * dh / 4.0
        notes.append("wall area = (surface area minus ring faces) / 2, the shell's inner skin; cavity volume = wall area x "
                     f"inlet hydraulic diameter {dh:.4g} / 4 (a passage's V/A is D_h/4 for any section): agent-side "
                     "assumptions, the renderer carves the cavity it finds")
        return volume, wall, notes
    outer = [r for r in facts.regions if not r.nested_in]
    vols = [float(r.volume) for r in outer if r.watertight and r.volume]
    if vols:
        volume = sum(vols)
        notes.append("fluid volume = the outer watertight bodies' enclosed volume")
    else:
        ext = facts.bbox.extent
        volume = float(facts.total_volume) if facts.total_volume else 0.5 * float(ext[0] * ext[1] * ext[2])
        notes.append("fluid volume = total enclosed volume, or half the bounding box when the surface is open")
    inner = sum(float(r.volume) for r in facts.regions if r.nested_in and r.watertight and r.volume)
    if inner:
        volume = max(0.0, volume - inner)
        notes.append("inner bodies' volume subtracted (obstacles in the fluid)")
    wall = max(0.0, facts.total_surface_area - port_area)
    return volume, wall, notes


def _estimate_internal(facts: GeometryFacts, strategy: dict, representation: str | None, inlet_id: str | None) -> dict:
    rep = _rep_key(representation)
    ports = _builder_ports(facts, rep)
    inlet, bore_area = builder_inlet(facts, rep, inlet_id)
    basis: list[str] = []
    if inlet is None or bore_area <= 0:
        return {"engine": "snappy", "representation": representation, "cells_low": 0, "cells_high": 0, "breakdown": {},
                "builder": {}, "basis": ["no port opening to size the bore from (drivers.py:498-499 sizes from the "
                                         "declared inlet's opening area)"]}
    bore = 2.0 * math.sqrt(bore_area / math.pi)                                                  # drivers.py:499
    cells_across = max(BUILDER_CELLS_ACROSS_MIN,
                       int(strategy.get("cells_across_diameter", BUILDER_CELLS_ACROSS_DEFAULT)))  # drivers.py:578
    sl = strategy.get("surface_level", BUILDER_SURFACE_LEVEL_DEFAULT)
    surface_level = int(sl[-1] if isinstance(sl, (list, tuple)) else sl)                        # drivers.py:576-577
    feature_level = int(strategy.get("feature_level", surface_level + 1))                        # drivers.py:582
    n_layers = max(0, int(strategy.get("n_layers", BUILDER_N_LAYERS_DEFAULT)))                   # drivers.py:579
    base_cell = (bore / cells_across) * (2 ** surface_level)                                     # drivers.py:584
    ext = [float(v) for v in facts.bbox.extent]
    maxext = max(ext)                                                                            # snappy_runner.py:617-618
    pad = max(INTERNAL_PAD_CELLS * base_cell, INTERNAL_PAD_OF_EXTENT * maxext)                   # snappy_runner.py:619
    dext = [e + 2.0 * pad for e in ext]                                                          # snappy_runner.py:620-622
    div = [max(INTERNAL_DIV_MIN, min(INTERNAL_DIV_MAX, int(round(d / base_cell)))) for d in dext]  # snappy_runner.py:624
    base_actual = max(dext[i] / max(div[i], 1) for i in range(3))                                # snappy_runner.py:627
    deficit = max(0, int(math.floor(math.log2(max(base_actual / max(base_cell, 1e-30), 1.0)) + 1e-9)))  # :631
    smax = min(HARD_MAX_LEVEL, surface_level + deficit)                                          # snappy_runner.py:634
    flevel = min(HARD_MAX_LEVEL, max(smax, feature_level + deficit))                             # snappy_runner.py:635
    port_level = max(1, smax - 1)                                                                # snappy_runner.py:636
    near_dist = max(NEAR_BAND_CELLS * base_cell, NEAR_BAND_OF_EXTENT * maxext)                   # snappy_runner.py:637
    near_level = min(HARD_MAX_LEVEL, smax + 1)                                                   # snappy_runner.py:638

    def h(level: int) -> float:
        return base_actual / (2 ** level)

    volume, wall, notes = _fluid_geometry(facts, rep, ports, bore, inlet)
    basis += notes
    # the near band: every cell within near_dist of the wall is refined to near_level (refinementRegions, mode
    # distance, snappy_runner.py:681); a bore under twice near_dist sits in it entirely
    v_near = min(volume, wall * near_dist)
    cells_near = v_near / h(near_level) ** 3
    remaining = max(0.0, volume - v_near)
    basis.append(f"near band: volume within near_dist {near_dist:.4g} of the wall (min of wall area x near_dist and the "
                 f"fluid volume) at level {near_level} (snappy_runner.py:637-638, :681)")
    # transition shells beyond the band: nCellsBetweenLevels 3 cells at each level down to 1 (snappy_runner.py:679)
    cells_transition = 0.0
    for level in range(near_level - 1, 0, -1):
        if remaining <= 0:
            break
        v_k = min(remaining, wall * CELLS_BETWEEN_LEVELS * h(level))
        cells_transition += v_k / h(level) ** 3
        remaining -= v_k
    cells_base = remaining / base_actual ** 3
    basis.append("beyond the band: 3 cells per level down to the background (nCellsBetweenLevels 3, snappy_runner.py:679), "
                 "the rest at the background cell")
    # feature edges finer than the band: a 3 x 3 cell tube along the sharp edges at flevel (features level, :663)
    cells_feature = 0.0
    if flevel > near_level and facts.features.sharp_edge_length:
        hf = h(flevel)
        cells_feature = facts.features.sharp_edge_length * (CELLS_BETWEEN_LEVELS * hf) ** 2 / hf ** 3 * (1.0 - (hf / h(near_level)) ** 3)
        basis.append(f"feature edges at level {flevel}, one level finer than the band, along {facts.features.sharp_edge_length:.4g} "
                     "of sharp edges (snappy_runner.py:663, :635)")
    # layers: nSurfaceLayers on the wall entry only (snappy_runner.py:685), one cell per wall face per layer at the
    # wall cell, which is the band's cell
    cells_layers = n_layers * wall / h(near_level) ** 2
    basis.append(f"layers: {n_layers} x wall area / wall cell squared, wall cell = level {near_level} cell "
                 "(addLayersControls, snappy_runner.py:685-686)")
    basis.append(f"port faces at level {port_level}, one below the wall (snappy_runner.py:636, :666): no cells added, "
                 "the mouth's cap is coarser than its rim")
    low = int(cells_near + cells_base + cells_layers)
    high = int(low + cells_transition + cells_feature)
    frame = builder_frame(facts, rep, strategy, inlet.id)
    return {
        "engine": "snappy", "representation": representation, "cells_low": low, "cells_high": high,
        "breakdown": {"near_band": int(cells_near), "background": int(cells_base), "layers": int(cells_layers),
                      "transition": int(cells_transition), "feature_edges": int(cells_feature),
                      "fluid_volume": volume, "wall_area": wall, "near_band_volume": v_near},
        "builder": {"inlet_id": inlet.id, "bore": bore, "cells_across": cells_across, "wall_cell": bore / cells_across,
                    "surface_level": surface_level, "feature_level": feature_level, "n_layers": n_layers,
                    "base_cell": base_cell, "divisions": div, "base_actual": base_actual, "deficit": deficit,
                    "smax": smax, "flevel": flevel, "port_level": port_level, "near_dist": near_dist,
                    "near_level": near_level, "near_cell": h(near_level), "max_cells": int(strategy.get("max_cells", BUILDER_MAX_CELLS_DEFAULT)),
                    "ports": frame["ports"], "smallest_port": frame["smallest_port"]},
        "basis": ["bore = 2 sqrt(inlet opening area / pi) from the declared inlet (drivers.py:422-438, :498-499)",
                  f"base cell = bore / cells_across x 2**surface_level = {base_cell:.4g} (drivers.py:584)",
                  f"pad max(2 base, 0.03 extent), divisions {div} clamped 8..120, background cell {base_actual:.4g}, "
                  f"deficit {deficit} (snappy_runner.py:619-634)", *basis,
                  f"platform {PLATFORM_SHA[:8]}"],
    }


def _external_recommendation(facts: GeometryFacts, max_cells: int) -> dict:
    """cad/analysis.py:159-207 recommend_refinement over the agent's measurements. min_feature is the analysis'
    1 percent-of-area triangle length, which the agent does not measure the same way; the fifth percentile of
    the wall thickness (or the median edge) stands in, which only moves the feature level, capped at surf + 2."""
    diag, L = float(facts.bbox.diagonal), float(max(facts.bbox.extent))
    proxy = facts.features.thickness_p05 or facts.features.edge_length_median or diag * 1e-4
    minf = max(float(proxy), diag * 1e-4)                                                       # analysis.py:164
    area = float(facts.total_surface_area or diag * diag)                                        # analysis.py:165
    base_cell = L / EXTERNAL_BASE_DIVISIONS                                                      # analysis.py:166

    def level(target: float) -> int:
        return int(math.ceil(math.log2(max(base_cell / max(target, 1e-30), 1.0))))              # analysis.py:168-169

    afford = int(math.floor(0.5 * math.log2(max(max_cells * base_cell ** 2 / (EXTERNAL_DEPTH * max(area, 1e-9)), 1.0))))
    afford = max(1, min(afford, EXTERNAL_MAX_LEVEL))                                             # analysis.py:173-175
    surf = max(1, min(level(diag / EXTERNAL_BODY_CELLS), afford, EXTERNAL_MAX_LEVEL - 1))       # analysis.py:178
    feat_true = level(minf / EXTERNAL_CELLS_PER_FEATURE)                                         # analysis.py:183
    feat = max(surf, min(feat_true, surf + 2, EXTERNAL_MAX_LEVEL))                               # analysis.py:184
    surf_cell = base_cell / 2 ** surf                                                            # analysis.py:189
    near = EXTERNAL_NEAR_CELLS * surf_cell                                                       # analysis.py:190
    far = max(EXTERNAL_FAR_MULT * near, EXTERNAL_FAR_OF_L * L)                                   # analysis.py:191
    return {"base_cell": base_cell, "surface_level": surf, "feature_level": feat, "afford_level": afford,
            "distance_bands": [(near, surf), (far, max(1, surf - 1))], "surface_area": area, "min_feature": minf, "L": L}


def _external_domain(facts: GeometryFacts, margins: dict, flow_axis: str | None) -> tuple[list[float], list[float], float]:
    """snappy_runner.py:303-377 domain_from_strategy without a symmetry plane: a declared flow axis puts up and
    down along it with the body's extent on that axis as the ruler (:311-335); otherwise axis 0 carries up and
    down, 1 side, 2 vert, all in units of L (:337-340)."""
    bmin, bmax = [float(v) for v in facts.bbox.min], [float(v) for v in facts.bbox.max]
    ext = [float(v) for v in facts.bbox.extent]
    L = max(ext)
    up, dn = float(margins.get("up", EXTERNAL_MARGINS["up"])), float(margins.get("down", EXTERNAL_MARGINS["down"]))
    side, vert = float(margins.get("side", EXTERNAL_MARGINS["side"])), float(margins.get("vert", EXTERNAL_MARGINS["vert"]))
    dmin, dmax = list(bmin), list(bmax)
    if flow_axis:
        ax = flow_axis.strip().lower()
        sign, letter = (ax[0], ax[1]) if ax[0] in "+-" else ("+", ax[0])
        i_s = {"x": 0, "y": 1, "z": 2}[letter]
        rest = [j for j in range(3) if j != i_s]
        ref = ext[i_s] or L
        lo_m, hi_m = (up, dn) if sign == "+" else (dn, up)
        dmin[i_s], dmax[i_s] = bmin[i_s] - lo_m * ref, bmax[i_s] + hi_m * ref
        dmin[rest[0]], dmax[rest[0]] = bmin[rest[0]] - side * ref, bmax[rest[0]] + side * ref
        dmin[rest[1]], dmax[rest[1]] = bmin[rest[1]] - vert * ref, bmax[rest[1]] + vert * ref
        return dmin, dmax, ref
    dmin = [bmin[0] - up * L, bmin[1] - side * L, bmin[2] - vert * L]
    dmax = [bmax[0] + dn * L, bmax[1] + side * L, bmax[2] + vert * L]
    return dmin, dmax, L


def _estimate_external(facts: GeometryFacts, strategy: dict) -> dict:
    max_cells = int(strategy.get("max_cells", BUILDER_MAX_CELLS_DEFAULT))                        # snappy_runner.py:459
    rec = _external_recommendation(facts, max_cells)
    base = rec["base_cell"]
    margins = strategy.get("domain_margin") or {}
    dmin, dmax, ref = _external_domain(facts, margins, strategy.get("flow_axis"))
    ext = [dmax[i] - dmin[i] for i in range(3)]                                                  # snappy_runner.py:397
    div = [max(BG_MIN_DIV, min(BG_MAX_DIV, int(round(ext[i] / base)))) for i in range(3)]        # snappy_runner.py:413
    for _ in range(256):                                                                          # snappy_runner.py:416-422
        if div[0] * div[1] * div[2] <= BG_CELL_BUDGET:
            break
        k = max(range(3), key=lambda i: div[i])
        if div[k] <= BG_MIN_DIV:
            break
        div[k] = max(BG_MIN_DIV, int(div[k] * BG_TRIM))
    base_actual = max(ext[i] / max(div[i], 1) for i in range(3))                                 # snappy_runner.py:433
    deficit = max(0, int(math.floor(math.log2(max(base_actual / max(base, 1e-30), 1.0)) + 1e-9)))  # :439
    floor = min(HARD_MAX_LEVEL, rec["surface_level"] + deficit)                                  # snappy_runner.py:446
    ceil_ = min(HARD_MAX_LEVEL, max(floor, rec["afford_level"] + deficit))                       # snappy_runner.py:447
    so = strategy.get("surface_level")
    if isinstance(so, (int, float)) and not isinstance(so, bool):
        so = [int(so)]
    lvl = floor if not so else max(floor, min(int(so[-1]) + deficit, ceil_))                     # snappy_runner.py:449
    smax = lvl
    flevel = int(strategy.get("feature_level", rec["feature_level"]))                            # snappy_runner.py:451
    flevel = min(HARD_MAX_LEVEL, max(smax, min(flevel, rec["feature_level"]) + deficit))         # snappy_runner.py:452
    (b0d, b0l), (b1d, b1l) = rec["distance_bands"]                                               # snappy_runner.py:502
    near_level = min(int(b0l) + deficit, smax + 2)                                               # snappy_runner.py:503
    far_level = max(1, smax - 1)                                                                 # snappy_runner.py:535
    n_layers = max(0, int(strategy.get("n_layers", BUILDER_N_LAYERS_DEFAULT)))                   # snappy_runner.py:500

    def h(level: int) -> float:
        return base_actual / (2 ** level)

    area = float(facts.total_surface_area)
    v_body = float(facts.total_volume) if (facts.watertight and facts.total_volume) else 0.0
    v_domain = ext[0] * ext[1] * ext[2]
    # the surface: one cell thick at smax on the fluid side (the inside is carved away, locationInMesh :462)
    cells_surface = area / h(smax) ** 2
    v_surface = area * h(smax)
    # the near band at near_level out to b0d, the far band at far_level out to b1d (refinementRegions :535)
    v_near = max(0.0, area * (b0d - h(smax)))
    cells_near = v_near / h(near_level) ** 3
    v_far = max(0.0, area * (b1d - b0d))
    cells_far = v_far / h(far_level) ** 3
    # transitions: 3 cells per level between the surface and the near band, and below the far band
    cells_transition = 0.0
    for level in range(smax - 1, near_level, -1):
        cells_transition += CELLS_BETWEEN_LEVELS * area / h(level) ** 2
    for level in range(far_level - 1, 0, -1):
        cells_transition += CELLS_BETWEEN_LEVELS * area / h(level) ** 2
    v_refined = v_surface + v_near + v_far
    cells_background = max(0.0, v_domain - v_body - v_refined) / base_actual ** 3
    cells_background = min(cells_background, float(div[0] * div[1] * div[2]))
    cells_layers = n_layers * area / h(smax) ** 2                                                # snappy_runner.py:526-527
    cells_feature = 0.0
    if flevel > smax and facts.features.sharp_edge_length:
        hf = h(flevel)
        cells_feature = facts.features.sharp_edge_length * (CELLS_BETWEEN_LEVELS * hf) ** 2 / hf ** 3 * (1.0 - (hf / h(smax)) ** 3)
    low = int(cells_background + cells_surface + cells_near + cells_far + cells_layers)
    high = int(low + cells_transition + cells_feature)
    return {
        "engine": "snappy", "representation": "external", "cells_low": low, "cells_high": high,
        "breakdown": {"background": int(cells_background), "surface": int(cells_surface), "near_band": int(cells_near),
                      "far_band": int(cells_far), "layers": int(cells_layers), "transition": int(cells_transition),
                      "feature_edges": int(cells_feature), "body_volume": v_body, "domain_volume": v_domain, "wall_area": area},
        "builder": {"base_cell": base, "divisions": div, "base_actual": base_actual, "deficit": deficit,
                    "surface_level": smax, "feature_level": flevel, "afford_level": rec["afford_level"],
                    "recommended_surface_level": rec["surface_level"], "near_band": [b0d, near_level],
                    "far_band": [b1d, far_level], "wall_cell": h(smax), "n_layers": n_layers, "max_cells": max_cells,
                    "domain_min": dmin, "domain_max": dmax, "reference_length": ref,
                    "domain_margin": {k: float(margins.get(k, EXTERNAL_MARGINS[k])) for k in EXTERNAL_MARGINS}},
        "basis": [f"base cell = L / 24 = {base:.4g} (cad/analysis.py:166); afford level {rec['afford_level']} from max_cells "
                  f"{max_cells} and the wetted area (analysis.py:173-175); surface level {rec['surface_level']} (analysis.py:178)",
                  f"domain margins {margins or EXTERNAL_MARGINS} body lengths (snappy_runner.py:308-309, :337-340); "
                  f"divisions {div} within 12..256 and the 600k background budget, background cell {base_actual:.4g}, "
                  f"deficit {deficit} (snappy_runner.py:411-439)",
                  f"surface one cell thick at level {smax}; near band {b0d:.4g} at level {near_level}; far band {b1d:.4g} at "
                  f"level {far_level} (analysis.py:189-192, snappy_runner.py:503, :535); layers {n_layers} x area / wall cell "
                  "squared (snappy_runner.py:526-527)",
                  "transition 3 cells per level (nCellsBetweenLevels 3, snappy_runner.py:533) and feature edges only in cells_high",
                  f"platform {PLATFORM_SHA[:8]}"],
    }


def _estimate_gmsh(facts: GeometryFacts, strategy: dict, representation: str | None) -> dict:
    diag = float(facts.bbox.diagonal)
    size = strategy.get("size") or {"mode": "factor", "value": GMSH_SIZE_FACTOR}                 # gmsh/driver.py:258
    h = float(size.get("value", GMSH_SIZE_FACTOR)) * diag if size.get("mode", "factor") == "factor" else float(size["value"])  # :259-261
    h_min = h / GMSH_SIZE_MIN_OVER                                                                # gmsh/driver.py:263
    nodes = int(strategy.get("curvature_nodes", GMSH_CURVATURE_NODES))                            # gmsh/driver.py:265
    volume = float(facts.total_volume) if (facts.watertight and facts.total_volume) else 0.5 * float(
        facts.bbox.extent[0] * facts.bbox.extent[1] * facts.bbox.extent[2])
    area = float(facts.total_surface_area)
    rep = _rep_key(representation)
    ports = _builder_ports(facts, rep) if rep != "external" else []
    inlet, _inlet_area = builder_inlet(facts, rep) if ports else (None, 0.0)
    d_main = port_hydraulic_diameter(facts, inlet, rep) if inlet is not None else 0.0
    # Mesh.MeshSizeFromCurvature `nodes` (gmsh/driver.py:264-265): a curved wall of radius R is meshed with `nodes`
    # elements per full turn, so a passage of hydraulic diameter D has its walls at pi D / nodes wherever that is
    # under h (floored at MeshSizeMin), and its interior follows through Mesh.MeshSizeExtendFromBoundary (gmsh
    # default 1, the driver leaves it). The main passage is sized from the inlet; a smaller port's tube is sized
    # from its own bore in the high figure; the fillets the same option refines are not measured.
    h_main = max(h_min, min(h, math.pi * d_main / nodes)) if (d_main > 0 and nodes > 0) else h
    cells_interior = GMSH_TETS_PER_H3 * volume / h_main ** 3
    cells_surface = GMSH_TETS_PER_H3 * area / h_main ** 2
    cells_ports = 0.0
    d_min = 0.0
    h_port = h_main
    for o in ports:
        d = port_min_dimension(o)
        if d <= 0:
            continue
        d_min = d if d_min == 0.0 else min(d_min, d)
        h_c = max(h_min, math.pi * d / nodes) if nodes > 0 else h
        if h_c >= h_main:
            continue
        h_port = min(h_port, h_c)
        v_local = math.pi / 4.0 * d * d * d
        a_local = math.pi * d * d + math.pi / 4.0 * d * d
        cells_ports += GMSH_TETS_PER_H3 * (v_local * (1.0 / h_c ** 3 - 1.0 / h_main ** 3) + a_local * (1.0 / h_c ** 2 - 1.0 / h_main ** 2))
    low = int(cells_interior + cells_surface)
    return {
        "engine": "gmsh", "representation": representation, "cells_low": low, "cells_high": int(low + cells_ports),
        "breakdown": {"interior": int(cells_interior), "surface_band": int(cells_surface), "port_curvature": int(cells_ports),
                      "volume": volume, "surface_area": area},
        "builder": {"h": h, "h_min": h_min, "h_surface": h_main, "h_port": h_port, "curvature_nodes": nodes, "size": size,
                    "inlet_id": inlet.id if inlet is not None else None, "main_passage_dh": d_main,
                    "smallest_port": d_min, "elements_across_smallest_port": (d_min / h_port) if d_min > 0 else None},
        "basis": [f"h = size.value x diagonal = {h:.4g} under mode factor (gmsh/driver.py:258-262), MeshSizeMin h / 20 (:263)",
                  f"walls at min(h, pi D / curvature_nodes) = {h_main:.4g} for the main passage D_h {d_main:.4g} "
                  f"(Mesh.MeshSizeFromCurvature {nodes}, gmsh/driver.py:264-265); the interior follows "
                  "(Mesh.MeshSizeExtendFromBoundary, gmsh default 1, not set by the driver)",
                  f"tets about 6 V / h**3 = {int(cells_interior)} plus a one-element surface band 6 A / h**2 = {int(cells_surface)}; "
                  "cells_high adds each smaller port's mouth and one bore of tube at its own pi d / nodes",
                  f"platform {PLATFORM_SHA[:8]}"],
    }


def estimate_builder_cells(facts: GeometryFacts, strategy: dict | None, representation: str | None, engine: str,
                           inlet_id: str | None = None) -> dict:
    """The builder's own cell count for a strategy in the planner's keys, from the renderer's rules rather than
    the agent's tier. Internal snappy: cells_across_diameter, surface_level, feature_level, n_layers, max_cells;
    external snappy: domain_margin, surface_level, feature_level, n_layers, max_cells, flow_axis; gmsh: size
    {mode, value}, curvature_nodes. Returns cells_low and cells_high (the transition shells and feature edges
    are counted only in the high figure), the breakdown, the builder's own numbers and the basis, every formula
    with the platform line it came from."""
    strategy = dict(strategy or {})
    if engine == "gmsh":
        return _estimate_gmsh(facts, strategy, representation)
    if _rep_key(representation) == "external":
        return _estimate_external(facts, strategy)
    return _estimate_internal(facts, strategy, representation, inlet_id)
