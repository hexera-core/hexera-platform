"""HANDOFF 3: intake and the geometry agent, together, to the builder.

WHERE IT RIDES, and this is the whole reason the block exists. `engines/snappy/planner.py:186` cuts
`request_txt[:2000]` and serialises the measured-geometry dict AFTER the cut. Prose in front of the cut is
subject to it; a dict key is not. So the Surveyor's information rides in the TYPED BLOCK, inside
`metrics["geometry_agent"]`, and cannot be truncated away.

WHAT THE PAIR HANDS OVER:

  the geometry agent's write-up   what to do and where to spend the cells. `hexera.builder_plan_block` already
                                  renders it into the prose in front of the cut.
  intake's write-up               what the customer settled, which is the only source of a role or an intent.
  the Surveyor's information      measurements and places, riding WITH the geometry agent's write-up, in the
                                  typed block after the cut.

THE CONTRACT, AND WHO SATISFIES IT. `check_survey_block` takes whatever lands at `planner_block["survey"]` and
refuses anything that breaks the rules below. `agent/hexera.planner_survey` is the implementation that composes
the block on both live paths, because it has the document and the look; this file ships the validator, the
`Given`-only builder that states the contract in executable form, and `attach`, which completes the composed
block rather than writing a second one over it. That sentence is the fix: for four rounds this file read as
though either builder would do, and the second one silently won on the platform's own path.

  RULE 1, EVERY VALUE SAYS WHAT KIND IT IS. Each leaf of the block is a mark: `{"kind": ..., "value": ...}`.
    A consumer reading two lines of it already knows whether a claim was computed, seen or confirmed.
  RULE 2, NO DIGIT FROM THE LOOK. A `seen` mark carrying a number means the scrub failed upstream, and the
    scrub is the reason the look may be shown to a builder at all. Refused, not stripped.
  RULE 3, NO RECORDED-TIER FIELD. Read from `vision.trust`: defects, notes, orientation, symmetry, an opening's
    class or the role the look guessed. Those are kept for a person and reach no model.
  RULE 4, THE BLOCK IS SMALL. It rides in a prompt beside everything else the planner reads. `SURVEY_BLOCK_MAX`
    is the ceiling and a block over it is refused rather than silently cut, because a block that can be cut is
    a block that can lose the one thing it was carrying. Two limits keep it under that ceiling and neither is a
    character count: `SURVEY_BLOCK_ITEMS` caps how many ROWS the block carries and `SURVEY_ROW_IDS_MAX` caps how
    many ids one row NAMES. Both say what they left out, because a list silently shortened reads downstream as a
    complete one.
  RULE 5, A DEFAULT IS NOT A CONFIRMATION. `confirmed` holds marks of kind `confirmed` and nothing else, and a
    default rides under `defaults_taken` with kind `assumed`. The platform's planner prompt tells the model in
    words that `confirmed` means the customer said it, so a default under that key is the builder binding a
    boundary condition from our guess while believing a person chose it.
  RULE 6, NO BUILDER SETTING AND NO PREDICTION. The two rules the Surveyor is defined by
    (`contract.survey.refuse_builder_keys`, `refuse_outcome_claims`), read here as well as at handoff 1,
    because this block is composed from the document and the look rather than from that handoff. THE SECOND IS
    PAID FOR WHERE THE LOOK IS COMPOSED FOR A MODEL: `vision.trust.for_model` takes a predicting phrase out of
    the look's own words and names the finding, so one phrase costs that phrase instead of costing the builder
    every placed finding, every measured mark and every confirmed role. This still refuses a block
    built anywhere else, and `refusal_reason` is why an explanation of a refusal can be put inside the block
    that was composed instead: a reason that quotes what it refused is a reason this rule refuses again.
  RULE 7, WHICH OF THE THREE LOOK STATES. A look that FAILED, a look nobody has taken and a look that came back
    and found a clear passage are three different things (`contract.survey.LOOK_STATES`). `looked` is a boolean
    and says only whether findings are here, so `look_state` says which state produced that answer.

ONE WRITER A KEY. `agent/hexera.planner_survey` composes every key that comes off the DOCUMENT or the look;
`hexera.survey_with_answers` is the only writer of the keys that come off INTAKE, and `attach` calls it instead
of composing a second block over the top of the first. Two builders of one block, with the second winning on the
platform's own path, is how `at_places`, `defaults_taken`, `seen_refused`, `intake_refused`, `look_refused` and
`left_out_for_size` were composed for four rounds and never left the document.

WHAT IS FORBIDDEN HERE AND NOWHERE ELSE: a role that is not confirmed. The builder binds patches from what it
is handed, so a guessed role in this block is a guessed boundary condition on a real job.
"""
from __future__ import annotations

import copy
import json
from typing import Any

from geometry_agent.contract import given as given_mod
from geometry_agent.contract import marks as mk
from geometry_agent.contract.given import Given
from geometry_agent.contract.marks import ContractError
from geometry_agent.contract.survey import (
    LOOK_OK,
    LOOK_STATES,
    predicts_outcome,
    refuse_builder_keys,
    refuse_outcome_claims,
)

SURVEY_BLOCK_SCHEMA = "geometry_agent.contract.survey_block.v1"

#: The block rides in a prompt. Over this it is refused, never cut: a block that can be cut is a block that can
#: lose the one thing it was carrying, which is the failure this whole handoff exists to end.
SURVEY_BLOCK_MAX = 4000

#: What the block MUST carry. A missing one is a loud failure at the boundary.
SURVEY_BLOCK_REQUIRED: tuple[str, ...] = ("schema", "source_sha256", "representation", "unit", "kinds",
                                          "confirmed", "unsettled")

#: At most this many confirmed roles and seen findings in the block. Ordered so the cut takes the least
#: important, and the limit is on the LIST rather than on the characters, so nothing is ever half a sentence.
SURVEY_BLOCK_ITEMS = 12

#: HOW MANY IDS ONE ROW NAMES before it starts counting instead. `SURVEY_BLOCK_ITEMS` caps the number of ROWS and
#: nothing capped the length of a row's own list, which grows with the mouth count: an `unsettled` row's
#: `subjects`, one id per mouth the question named, and a `confirmed` answer's `applies_to`, one id per mouth that
#: answer placed. The first was capped at 20 by `hexera.SURVEY_SUBJECTS_MAX`; the second was not, and it is the
#: one that costs the most, because `_fit` can drop a `seen` finding to make room and can drop nothing from
#: `confirmed`, so an oversized `applies_to` takes the WHOLE survey down: `check_survey_block` refuses,
#: `application/geometry_survey.builder_block` catches the refusal and returns None, and the builder is handed a
#: survey composed with no intake at all. A confirmed role lost that way is a boundary condition the customer set
#: and the builder never saw.
#:
#: ONE NUMBER, because `application/geometry_survey.block_list_max()` reads `hexera.SURVEY_SUBJECTS_MAX` as the
#: platform's answer to "how many mouths does one row of this block name". Two numbers would make that function
#: right about one list and wrong about the other. `hexera.SURVEY_SUBJECTS_MAX` is this constant.
#:
#: APPLIED ALWAYS, not only when the block is too big, so one part's block does not change shape because another
#: mouth was measured. The most mouths on any part in the export corpus is 20 (`static_mixer_002/004/006`,
#: `rotor_like_002/008`), so no corpus part's block moves; `corpus_complex`'s `showerhead_61_hex` has 64 and the
#: largest real part measured on this machine has 2,015.
SURVEY_ROW_IDS_MAX = 20


def cap_row_ids(row: dict[str, Any], key: str = "applies_to", about: str = "this answer") -> dict[str, Any]:
    """`row` with at most `SURVEY_ROW_IDS_MAX` ids under `key`, and the remainder SAID rather than dropped.

    A silently shortened list reads downstream as a complete one, which is worse than a long one: a builder that
    binds four patches from a list of four ids does the right thing, and a builder that binds four from a
    shortened list of two hundred and forty does the wrong thing believing it was told everything. So the count
    goes into `why`, which is where `hexera._survey_unsettled` already put it and which
    `application/geometry_survey.block_list_max`'s docstring already names as the place it belongs.

    `why` AND NOT `value`, for two reasons that are both rules of this block. `mk.as_json(compact=True)` drops
    `why` because the ledger sentence behind a claim is long and repeats over every mouth; this sentence is
    neither, and it is not the ledger's, so it is put back on purpose after the compaction. And `_walk_marks`
    refuses a digit in a `seen` mark's `value` and skips `why`, so a count in `value` would make a mouth-standoff
    row fail the no-digit rule that exists to catch a failed scrub.

    The row is edited in place and returned, so a caller can use it either way.
    """
    ids = row.get(key)
    if not isinstance(ids, list):
        return row
    rest = len(ids) - SURVEY_ROW_IDS_MAX
    if rest <= 0:
        return row
    row[key] = ids[:SURVEY_ROW_IDS_MAX]
    said = (f"the first {SURVEY_ROW_IDS_MAX} are named here and they stand for {rest} more, and {about} is "
            f"about every one of them")
    row["why"] = f"{row['why']}; {said}" if row.get("why") else said
    return row


#: How long a refusal's explanation may be inside the block. It rides against `SURVEY_BLOCK_MAX`, so a reason is
#: a sentence and not a traceback.
REFUSAL_REASON_MAX = 300

#: What is said when the reason cannot be repeated at all. Constant, short, and pinned by a test to pass
#: `check_survey_block`'s own string rules, because it is the floor the guarantee below stands on.
REFUSAL_UNQUOTABLE = ("this block refused what was composed for it and the explanation could not be repeated "
                      "here without breaking the same rule; the refusal is in the stored document")


def safe_reason(text: Any) -> str:
    """`text` cut to `REFUSAL_REASON_MAX` and PROVED to pass the rules this block is checked against.

    A REFUSAL'S EXPLANATION MUST NEVER ITSELF BE REFUSABLE. `refuse_outcome_claims` reads every string in the
    block, an explanation is a string in the block, and the explanations this package writes quote the thing they
    refused: a look refused for predicting was refused a second time at `look_refused`, for the same phrase
    quoted back, and the builder lost the whole survey over it. The guarantee is not a list of words to avoid. It
    is that the sentence is run through the rule that will judge it before it is written, and replaced when it
    does not pass.

    THE STRING THAT IS RETURNED IS THE STRING THAT IS PROVED, which is why the cut comes first. It is not that
    the cut can make a phrase: every `OUTCOME_WORDS` entry is one run of characters, and a prefix of a string
    contains no run the whole string does not, so no truncation can introduce one. ("will meshing" was offered as
    a case where it does. It is not one: that string already contains `will mesh` uncut, which is the whole
    reason shortening it looks like it produced one.) The order is the discipline anyway: prove the sentence you
    are about to write, not a longer one you are not, because the next reason to shorten a reason may not be a
    plain cut off the end.
    """
    said = str(text or "")[:REFUSAL_REASON_MAX]
    # only the outcome rule can fire on a bare string: `refuse_builder_keys` reads dict KEYS, and the key this
    # sits under (`look_refused`, `survey_refused`) is not one. `_walk_marks` reads dicts with a kind and a value
    return REFUSAL_UNQUOTABLE if predicts_outcome(said) else said


def refusal_reason(exc: Exception, *, where: str = "survey_block") -> str:
    """Why a block was refused, said so that it can ride inside the block that was composed instead.

    The refusal's own message when it can be repeated, because naming the rule AND the value is what a person
    debugging needs and most rules (the ceiling, a missing key, a kind that is not a kind) quote nothing
    forbidden. When the message is the problem, the rule and the place are named and the value is not repeated:
    that keeps the one fact a reader downstream can act on, which is that the look said something this handoff
    does not carry and where it said it.
    """
    said = safe_reason(f"{type(exc).__name__}: {exc}")
    if said != REFUSAL_UNQUOTABLE:
        return said
    field = getattr(exc, "field", "") or "the block"
    return safe_reason(f"{type(exc).__name__} at {field}: refused by {where} for predicting how the finished "
                       f"mesh comes out, and the words are not repeated here")


def intake_half(intake: Any, late: Any = None,
                source_sha256: str = "") -> tuple[dict[str, Any], dict[str, Any], set[str], str]:
    """`(confirmed, defaults_taken, the question ids they settled, why an intake was refused or "")`.

    THE ONE IMPLEMENTATION OF THE SURVEY BLOCK'S INTAKE HALF. `survey_block` calls it, and so does
    `agent.hexera.planner_survey`, which composes the block that actually rides to the builder, through
    `hexera._survey_confirmed`. Two implementations of this half is what made the key names differ between the
    two builders of one block, and when the second builder wiped the first the names changed with it.

    ONE ENTRY PER ANSWER GIVEN, with the mouths it placed beside it. The first version wrote one mark per mouth,
    each repeating who answered and when, and on an eight-mouth manifold (`mini_housing_014`) the repetition
    alone took the block over its ceiling. Who and when stay in every mark's `source`, because a confirmation
    that loses them is an assumption; what is not repeated is the same sentence eight times.

    A DEFAULT IS NOT A CONFIRMATION, and until this split both went under `confirmed`. The platform's own planner
    prompt tells the model that `confirmed` means the customer said it, so a default that sat there reached the
    builder as a customer's decision and the builder bound a boundary condition from our guess. `Answer.as_mark`
    already knows the difference: `confirmed` when a person answered, `assumed` when the default stood. Two
    kinds, two keys, and `check_survey_block` refuses the block if they are ever merged.

    `late` is the THIRD intake, the budget trade and nothing else. Reading only the second left a budget the
    trade had settled out of the block the builder sizes from.
    """
    handoffs = [h for h in (intake, late) if h is not None]
    if not handoffs:
        return {}, {}, set(), ""
    if source_sha256:
        for h in handoffs:
            if str(getattr(h, "survey_source_sha256", "") or "") != str(source_sha256):
                return {}, {}, set(), "the answers were given about a different file"
    confirmed: dict[str, Any] = {}
    defaults: dict[str, Any] = {}
    settled: set[str] = set()
    for h in handoffs:
        for answer in getattr(h, "answers", []) or []:
            try:
                claim = answer.as_mark()
            except ContractError:
                # a default on a field that admits no assumption (a port role) is not an answer at all; it is
                # the question still open, and it stays in `unsettled` rather than being counted as settled
                continue
            # AND NEITHER IS A VALUE OF OURS THAT THEY WAVED THROUGH. `confirmed` means a person said it - the
            # platform's planner prompt states that reading to the model in words - and the application
            # proposing every unplaced mouth as an outlet, the customer saying "you decide everything", and the
            # proposal then riding under `confirmed` is the builder binding OUR guess as if they had chosen it.
            # It cannot go under `defaults_taken` either: `check_survey_block` admits only an `assumed` mark
            # there, and `OWNERS["opening.role"]` gives a role no such kind (`intake.Answer.as_mark`). So it
            # rides as the question still open, exactly as the branch above does, and our value still reaches
            # the builder where it is honest about whose it is: `flow_patches` names it beside the plan's role.
            #
            # IT IS `our_proposal_accepted` AND NOT `not their_own_value()`, which was this change's first
            # version and was wrong: a DEFAULT that stood is also not their own value, and skipping it here took
            # every default out of `defaults_taken` - the half that exists to tell the builder the question is
            # open. Caught by `test_a_default_rides_under_defaults_taken_in_both_builders_and_never_under_
            # confirmed`, which is the test that already knew the two are different facts.
            if answer.our_proposal_accepted():
                continue
            mark = mk.as_json(claim, compact=True)
            into = confirmed if claim.kind == mk.CONFIRMED else defaults
            settled.add(answer.question_id)
            if not answer.subject:
                into[answer.about] = mark
                continue
            key = f"{answer.about}={answer.value}"
            row = into.get(key)
            if row is None or row.get("source") != mark["source"]:
                key = key if row is None else f"{key}@{answer.question_id}"
                row = into.setdefault(key, {**mark, "applies_to": []})
            row["applies_to"].append(answer.subject)
    # THE ROW'S OWN LIST IS CAPPED HERE AND NOT BY THE CALLER, for the reason `hexera._survey_unsettled` gives
    # about `subjects`: a caller can only shorten the list it is handed, and the sentence saying how many were
    # left out belongs in the row that is kept. Capped on BOTH halves, because `defaults_taken` is the same
    # grouping over the same mouths and the block's ceiling does not care which key the characters sat under.
    return ({k: cap_row_ids(v) for k, v in list(confirmed.items())[:SURVEY_BLOCK_ITEMS]},
            {k: cap_row_ids(v, about="this default") for k, v in
             list(defaults.items())[:SURVEY_BLOCK_ITEMS]}, settled, "")


def survey_block(given: Given) -> dict[str, Any]:
    """The Surveyor's information, as it rides with the geometry agent's write-up in the typed block.

    Every value carries its kind. A builder reading `{"kind": "confirmed", "value": "inlet"}` knows a person
    said so; reading `{"kind": "seen", "tier": "relied_on", "value": ["a flange at one end"]}` it knows a model
    said so from pictures and what that is worth. There is no third state where it cannot tell.

    THE `Given`-ONLY BUILDER. `agent.hexera.planner_survey` composes the block that rides on both live paths,
    because it has the document and the look and this does not. This is the contract in executable form, and
    `attach`'s fallback for a planner block that carries no survey at all.
    """
    survey = given.survey
    confirmed, defaults, _settled, refused = intake_half(given.intake, given.late, survey.source_sha256)
    if refused:
        # unreachable through `Given.of`, which binds the intake to the survey before this can be called, and
        # raised rather than swallowed so that it stays unreachable: a block built from answers about another
        # file is the one failure this whole handoff is built to make impossible.
        raise ContractError("survey_block", refused, field="confirmed")
    # `_settled` is not read here: `given.unsettled()` already counts a question held below the intake budget,
    # which never became an answer and which a settled-id set therefore cannot see.
    seen: dict[str, Any] = {}
    for name in ("attachments", "inside_is_plain", "identity.name"):
        m = survey.mark(name)
        if m is not None and m.kind == mk.SEEN:
            seen[name] = mk.as_json(m, compact=True)
    # one entry per WORD, with the ids on it, not one entry per opening: same reason as `unsettled` below
    standoffs: dict[str, dict[str, Any]] = {}
    for op in survey.openings:
        standoff = op.mark("opening.mouth_standoff")
        if standoff is not None and standoff.kind == mk.SEEN:
            # THE WORD IS THE SEEN VALUE AND THE IDS ARE NOT. An opening id carries a digit, and the ids came
            # off the LABELS the renderer drew from the measurement, not out of the model. Putting them in
            # `value` made this block fail its own no-digit rule, which was the rule working: they travel
            # beside the claim as measured provenance instead.
            row = standoffs.setdefault(str(standoff.value),
                                       {"kind": standoff.kind, "value": str(standoff.value),
                                        "field": standoff.field, "source": "look.openings_seen[].mouth",
                                        "tier": standoff.tier, "applies_to": []})
            row["applies_to"].append(op.id)
    for word, row in list(standoffs.items())[:SURVEY_BLOCK_ITEMS]:
        # the same cap, for the same reason: there are at most four standoff words and one id per mouth under
        # each of them, so the rows are few and a row is as long as the part has mouths
        seen[f"opening.mouth_standoff.{word}"] = cap_row_ids(row, about="this reading")
    measured: dict[str, Any] = {}
    # NOT `thickness.min_m` (the platform fixer's NEEDS 9): the typed block's survey (`hexera.SURVEY_MEASURED`)
    # leaves it out, and two surveys of one part must not disagree about what was measured. The thin places ride
    # in `places`, located, which is what a builder acts on
    for name in ("bbox_diagonal_m", "inlet_bore_m", "forecast.cells_high", "cell_budget"):
        m = given.fact(name)
        if m is not None:
            measured[name] = mk.as_json(m, compact=True)
    # GROUPED BY REASON, not one row per opening. Four mouths nobody has assigned a role to is ONE thing the
    # builder needs to know, said once with the four ids on it; four copies of the same sentence is the block
    # spending its ceiling on repetition and then losing a finding to the cap.
    # EVERYTHING nobody confirmed, asked and skipped AND never asked. `unanswered()` is only the first, and a
    # question held below the budget reached the builder as nothing at all through it (`Given.unsettled`).
    open_ids = set(given.unsettled()) if given.intake is not None else set(given.unanswered())
    grouped: dict[tuple[str, str], list[str]] = {}
    for u in survey.uncertainties:
        if u.id not in open_ids:
            continue
        grouped.setdefault((u.about, u.why), []).extend(u.subjects or [u.subject or u.id])
    unsettled = [{"about": about, "subjects": subjects, "why": why}
                 for (about, why), subjects in list(grouped.items())[:SURVEY_BLOCK_ITEMS]]
    block = {
        "schema": SURVEY_BLOCK_SCHEMA,
        "source_sha256": survey.source_sha256,
        "facts_sha256": survey.facts_sha256,
        "representation": mk.as_json(given.must("representation"), compact=True),
        #: Absent when nobody has stated one, which is an STL and is common. `value: null` with `kind:
        #: assumed` beside an `unsettled` row saying so is the honest form; a unit invented to fill the key is
        #: the error this package exists to avoid.
        "unit": (mk.as_json(given.fact("unit"), compact=True) if given.fact("unit") is not None
                 else {"kind": mk.ASSUMED, "value": None, "field": "unit",
                       "source": "nobody has stated a unit for this file; see unsettled"}),
        #: The legend, in the block. A consumer never has to have read a document to know what a kind means.
        "kinds": dict(mk.KIND_SHORT),
        "measured": measured,
        "confirmed": confirmed,
        "seen": seen,
        #: What nobody settled, named. A builder that knows a role is unsettled can refuse to bind a patch; a
        #: builder handed silence binds whatever it guesses.
        "unsettled": unsettled,
        "looked": survey.looked,
    }
    if survey.looked:
        #: WRITTEN ONLY WHEN THIS BUILDER CAN KNOW IT, which is the half of rule 7 a `Given` can satisfy. A
        #: handoff that looked was a look that came back; a handoff that did not carries one boolean and cannot
        #: say whether the look failed or was never taken, and inventing either would be this block guessing
        #: about the one thing the rule exists to stop it guessing about. `hexera.planner_survey` reads the
        #: document's own look block and states all three, which is why it is the composer on both live paths.
        block["look_state"] = LOOK_OK
    if defaults:
        #: The answers where nobody typed and the default stood, under their own key, where a reader cannot
        #: mistake one for a confirmation. Absent when every answer was a person's, which is the common case.
        block["defaults_taken"] = defaults
    check_survey_block(block)
    return block


def check_survey_block(block: Any) -> None:
    """The validator another agent's block has to pass. Raises on the first violation.

    This is the contract in executable form. It is deliberately a free function over a plain dict so it can be
    run against a block built anywhere, by anyone, without importing the builder of it.
    """
    if not isinstance(block, dict):
        raise ContractError("survey_block", "the block must be a dict; the planner reads it as a dict key and "
                                            "a list or a string arrives as prose that the cut can reach")
    missing = [k for k in SURVEY_BLOCK_REQUIRED if k not in block]
    if missing:
        raise ContractError("survey_block", f"required keys absent: {missing}")
    mk.check_no_forbidden(block, "survey_block")
    # THE TWO REFUSALS THIS CHECK NEVER RAN, and they are the two the Surveyor's own definition turns on: it
    # names places and measurements, never a builder setting, and it describes a part, never how the mesh
    # turns out. `contract.survey.SurveyHandoff` ran them at handoff 1 and this block is not built from that
    # handoff - `agent/hexera.planner_survey` composes it from the document and from `vision.trust.for_model` -
    # so between handoff 1 and the builder there was no boundary that read either rule. A check with the same
    # blind spot as the thing it checks is the pattern this project keeps finding, and this was one.
    refuse_builder_keys(block, "survey_block")
    refuse_outcome_claims(block, "survey_block")
    _walk_marks(block, "survey_block")
    size = len(json.dumps(block, default=str))
    if size > SURVEY_BLOCK_MAX:
        raise ContractError("survey_block", f"{size} characters against a ceiling of {SURVEY_BLOCK_MAX}; a "
                                            f"block that can be cut is a block that can lose the one thing it "
                                            f"was carrying, so this is refused rather than truncated")
    # `confirmed` MEANS A PERSON SAID IT, and this used to admit `assumed` there as well. The platform's planner
    # prompt states that reading to the model in words, so a default under this key was read as a customer's
    # decision on the one thing no instrument can compute. A default rides in `defaults_taken` or it does not
    # ride: there is no kind that is both.
    for key, value in (block.get("confirmed") or {}).items():
        if isinstance(value, dict) and value.get("kind") != mk.CONFIRMED:
            raise ContractError("survey_block", f"{key!r} sits under `confirmed` and its kind is "
                                                f"{value.get('kind')!r}: a default is not a confirmation, and "
                                                f"a default under this key is the builder binding our guess as "
                                                f"if the customer had said it. It belongs in `defaults_taken`",
                                field=key)
    for key, value in (block.get("defaults_taken") or {}).items():
        if isinstance(value, dict) and value.get("kind") != mk.ASSUMED:
            raise ContractError("survey_block", f"{key!r} sits under `defaults_taken` and its kind is "
                                                f"{value.get('kind')!r}; only a default nobody stated belongs "
                                                f"there, and an answer a person gave belongs in `confirmed`",
                                field=key)
    for key, value in (block.get("seen") or {}).items():
        if not isinstance(value, dict):
            continue
        if value.get("kind") != mk.SEEN:
            raise ContractError("survey_block", f"{key!r} sits under `seen` and its kind is "
                                                f"{value.get('kind')!r}", field=key)
        if not value.get("tier"):
            raise ContractError("survey_block", f"{key!r} is a seen claim with no trust tier; a consumer "
                                                f"cannot tell what it is worth", field=key)
    # RULE 7, THREE LOOK STATES AND `looked` IS NOT ONE OF THEM. `looked` answers whether a look's findings are IN
    # this block; it cannot answer why they are not, so a look that FAILED and a look nobody took both arrived as
    # the same False, and the product rule is that those are two different things and neither is a clear passage.
    # `look_state` names which. It is checked and not required, because a block composed from a `Given` alone
    # cannot know (`survey_block` below), and an absent key means THIS BLOCK DOES NOT SAY rather than no look.
    state = block.get("look_state")
    if state is not None and state not in LOOK_STATES:
        raise ContractError("survey_block", f"{state!r} is not one of {LOOK_STATES}: a fourth state is read by a "
                                            f"builder as a look it has no branch for, which is how two of the "
                                            f"three came to be one", field="look_state")
    if block.get("looked") and state is not None and state != LOOK_OK:
        raise ContractError("survey_block", f"this block carries the look's findings and says the look was "
                                            f"{state!r}: one look, one state", field="look_state")
    if state == LOOK_OK and not block.get("looked") and not (block.get("look_refused")
                                                             or block.get("left_out_for_size")):
        raise ContractError("survey_block", "the look came back and none of it is in this block, with nothing "
                                            "saying why; a refusal that is silence is a builder that assumes "
                                            "nothing was there to see", field="look_state")


def _walk_marks(node: Any, where: str, path: str = "") -> None:
    """Every dict that looks like a mark must be a valid one, and no seen mark may carry a digit."""
    if isinstance(node, dict):
        if "kind" in node and "value" in node:
            kind = node.get("kind")
            if kind not in mk.KINDS:
                raise ContractError(where, f"kind {kind!r} is not one of {mk.KINDS}", field=path)
            if kind == mk.SEEN and _digit_in(node.get("value")):
                raise ContractError(where, "a seen claim carries a number; every digit is scrubbed before the "
                                           "model sees a picture, so this means the scrub failed upstream",
                                    field=path)
        for k, v in node.items():
            if k in ("kinds", "why", "read_as"):
                continue
            _walk_marks(v, where, f"{path}.{k}".lstrip("."))
    elif isinstance(node, (list, tuple)):
        for i, v in enumerate(node):
            _walk_marks(v, where, f"{path}[{i}]")


def _digit_in(value: Any) -> bool:
    if isinstance(value, bool):
        return False
    if isinstance(value, (int, float)):
        return True
    if isinstance(value, str):
        return mk.carries_number(value)
    if isinstance(value, dict):
        return any(_digit_in(v) for v in value.values())
    if isinstance(value, (list, tuple)):
        return any(_digit_in(v) for v in value)
    return False


# ---------------------------------------------------------------------------------------------------------
# the whole handoff to the builder: both write-ups, the Surveyor's information inside the geometry agent's
# ---------------------------------------------------------------------------------------------------------

BUILDER_HANDOFF_SCHEMA = "geometry_agent.contract.builder_handoff.v1"

#: The keys the platform's planner keeps out of `metrics["geometry_agent"]`, read on `feat/geometry-agent-pipeline`
#: at `bae0fb2`, `engines/snappy/planner.py:121`, applied at `:189` (synthesis C16). Pinned here as data, read and
#: not assumed, so the handoff can say which of its keys the platform would drop today. The platform tree is not
#: edited from here; adding `survey`, `intake` and `plan_envelope` there is on the NEEDS list.
PLATFORM_BLOCK_KEYS_BAE0FB2: tuple[str, ...] = (
    "status", "missing", "missing_because", "representation", "agent_forecast_cells", "agent_forecast_low",
    "agent_forecast_basis", "forecast_calibration", "customer_cell_cap", "inlet_bore_m", "inlet_opening_id",
    "smallest_port_min_dim_m", "places", "source_sha256", "agent_git_sha", "units", "look")

#: What intake's write-up must carry in the typed block. `confirmed` and `assumed` are TWO keys and are never
#: merged: the moment an answer and a default reach the builder as one dict of roles, the builder acts on our
#: guess believing it was confirmed (`chain/handover.py`).
INTAKE_BLOCK_REQUIRED: tuple[str, ...] = ("read_as", "confirmed", "assumed", "from_the_brief", "still_open")


#: The platform's allowlist on `feat/complete-surveyor` (`e81c55a`): the survey, the refusals, the coverage facts and
#: the chain's three keys are read. `platform_drops_today` is measured against THIS, and the bae0fb2 list above is
#: kept as the record of what the platform used to drop.
PLATFORM_BLOCK_KEYS_COMPLETE: tuple[str, ...] = (
    *PLATFORM_BLOCK_KEYS_BAE0FB2, "survey", "places_refused", "coverage", "intake", "flow_patches", "plan_envelope")


def platform_drops(typed: dict[str, Any], allowlist: tuple[str, ...] = PLATFORM_BLOCK_KEYS_COMPLETE) -> list[str]:
    """The keys of a typed block the platform's planner would drop, given its allowlist."""
    return sorted(k for k in typed if k not in allowlist and k != "schema")


#: Who a flow patch's role came from, in the handoff. `decided_by_agent` is the geometry agent choosing the flow
#: patch where nobody spoke (the design of record, step 5), which the builder builds AND reports back on.
#:
#: A ROLE THE CUSTOMER ACCEPTED FROM OUR OWN PROPOSAL IS NOT A FOURTH KIND HERE. Nobody said which role the
#: mouth has, so the plan's choice is the agent's either way; what the row carries is `intake_default` with
#: `intake_default_from` saying whether intake had a default nobody answered or a proposal they waved through.
FLOW_PATCH_KINDS: tuple[str, ...] = (mk.CONFIRMED, mk.STATED, "decided_by_agent")


def flow_patches(plan_patches: list[dict[str, Any]], given: Given) -> dict[str, dict[str, str]]:
    """The role the builder builds for every mouth the plan cuts as a flow patch, and who that role came from.

    ONE ANSWER PER MOUTH. Intake's write-up says what the customer confirmed, stated or left to a default; the
    plan says which patches it cuts. Where nobody spoke, the plan's choice can differ from intake's default (both
    are guesses between mouths of one bore), and a builder handed both would hold two roles for one mouth. This
    is the one it builds, labelled, with the default beside it when the two differ.
    """
    out: dict[str, dict[str, str]] = {}
    for patch in plan_patches:
        if not isinstance(patch, dict):
            continue
        pid, role = str(patch.get("id") or ""), str(patch.get("role") or patch.get("type") or "")
        if not pid or role in ("", "wall", "opening_unknown"):
            continue
        source = given.role_source(pid)
        row = {"role": role}
        if source is not None and source[0] in given_mod.THEIR_OWN_WORD and source[1] == role:
            row["kind"] = source[0]
        else:
            row["kind"] = "decided_by_agent"
            if source is not None and source[0] in given_mod.OUR_GUESS:
                row["intake_default"] = source[1]
                #: WHICH weak source, because the two are different facts about the customer's turn: `assumed`
                #: is a default nobody answered and `proposed` is our proposal they accepted without naming the
                #: mouth. Neither is their word about this mouth, which is why both land here.
                row["intake_default_from"] = source[0]
        out[pid] = row
    return out


#: The facts-only forecast's basis line at the builder, where a plan exists and its envelope rides as `plan_envelope`.
PLANNED_BASIS_NOTE = ("the builder emulator over the measurement alone, computed before the plan: the plan's own "
                      "envelope is plan_envelope")


def builder_handoff(planner_block: dict[str, Any] | None, given: Given, *, geometry_write_up: dict[str, Any],
                    intake_block: dict[str, Any], plan_envelope: dict[str, Any] | None = None,
                    patches: dict[str, dict[str, str]] | None = None) -> dict[str, Any]:
    """Step 7: what the builder receives, validated before it leaves.

    `geometry_write_up` is `hexera.builder_plan_block(...)`, the geometry agent's instruction sized to ride in
    front of the `request_txt[:2000]` cut. EVERYTHING ELSE rides in the typed block after the cut, where it
    cannot be truncated: the measurement and the look (`planner_block`, including its `look`), the Surveyor's
    marks (`survey`), intake's write-up (`intake`), and the envelope the plan costs (`plan_envelope`). The
    Surveyor's information is inside the geometry agent's half, as the design says, because it is the block the
    geometry agent's instruction is read against.
    """
    typed = attach(planner_block, given)
    if typed is None:
        raise ContractError("builder_handoff", "no planner block: a measurement that failed is not dressed up as a "
                                               "thin one; the job stops before the builder")
    typed["intake"] = {k: intake_block.get(k) for k in (*INTAKE_BLOCK_REQUIRED, "write_up") if k in intake_block}
    if plan_envelope is not None:
        typed["plan_envelope"] = dict(plan_envelope)
        # THE FACTS-ONLY ENVELOPE SAYS WHAT IT IS ONCE A PLAN EXISTS (work/z-chain NEEDS 1). `report_measured` writes
        # "no plan exists" into its basis, which is true at upload and false here, beside the plan's own envelope
        typed["agent_forecast_basis"] = [
            (PLANNED_BASIS_NOTE if str(b).startswith("no plan exists") else b)
            for b in (typed.get("agent_forecast_basis") or [])]
    if patches is not None:
        typed["flow_patches"] = dict(patches)
    out = {
        "schema": BUILDER_HANDOFF_SCHEMA,
        "source_sha256": given.survey.source_sha256,
        "brief_sha256": given.survey.brief_sha256,
        "request_prefix": str(geometry_write_up.get("text") or ""),
        "prefix_budget": int(geometry_write_up.get("budget") or 0),
        "typed": typed,
        "platform_drops_today": platform_drops(typed),
    }
    check_builder_handoff(out, given)
    return out


def check_builder_handoff(handoff: Any, given: Given) -> None:
    """The last boundary. Raises on the first thing the builder must not be handed."""
    if not isinstance(handoff, dict) or not isinstance(handoff.get("typed"), dict):
        raise ContractError("builder_handoff", "the handoff is a dict with a typed block")
    typed = handoff["typed"]
    # THE ONE READER OF `survey_refused`. `hexera.planner_block` writes that key when the survey broke its
    # contract twice, with the look and then without it, and nothing anywhere read it: a job whose survey failed
    # twice reached the builder with no survey and no reason, which is byte for byte what a job that never
    # surveyed looks like. Read here, at the last boundary, so the reason travels with the refusal.
    if not isinstance(typed.get("survey"), dict):
        why = str(typed.get("survey_refused") or "")
        raise ContractError("builder_handoff",
                            f"the typed block carries no survey. The composer said why: {why}" if why else
                            "the typed block carries no survey and nothing said why, which a reader cannot tell "
                            "apart from a job that was never surveyed", field="survey")
    check_survey_block(typed.get("survey"))
    if typed.get("representation") != given.representation:
        raise ContractError("builder_handoff", f"the typed block says {typed.get('representation')!r} and the survey "
                                               f"measured {given.representation!r}: one representation, resolved once",
                            field="representation")
    if typed.get("customer_cell_cap") != given.budget:
        raise ContractError("builder_handoff", f"the builder's cap is {typed.get('customer_cell_cap')!r} and the "
                                               f"resolved budget is {given.budget!r}", field="customer_cell_cap")
    intake = typed.get("intake")
    if not isinstance(intake, dict) or any(k not in intake for k in INTAKE_BLOCK_REQUIRED):
        raise ContractError("builder_handoff", f"intake's write-up must carry {INTAKE_BLOCK_REQUIRED}", field="intake")
    both = sorted(set(intake.get("confirmed") or {}) & set(intake.get("assumed") or {}))
    if both:
        raise ContractError("builder_handoff", f"{both} are under both `confirmed` and `assumed`: an answer and a "
                                               f"default are two things and never one", field="intake")
    mk.check_no_forbidden(typed.get("intake"), "builder_handoff.intake")
    basis = " ".join(str(b) for b in (typed.get("agent_forecast_basis") or []))
    if "refined" in basis.lower():
        raise ContractError("builder_handoff", "the forecast the builder reads names the refinement estimate; the "
                                               "envelope is tools.estimate_builder_cells and nothing else",
                            field="agent_forecast_basis")
    env = typed.get("plan_envelope")
    if isinstance(env, dict) and "estimate_builder_cells" not in str(env.get("source") or ""):
        raise ContractError("builder_handoff", "the plan envelope does not say it is the builder emulator's",
                            field="plan_envelope")
    patches = typed.get("flow_patches")
    if isinstance(patches, dict):
        for oid, row in patches.items():
            if not isinstance(row, dict) or row.get("kind") not in FLOW_PATCH_KINDS:
                raise ContractError("builder_handoff", f"flow patch {oid} does not say who its role came from",
                                    field=f"flow_patches.{oid}")
        # THE ONE AUTHORITY RULE, READ AND NOT RESTATED. This loop used to collect every answer whose
        # `answered_by` was not `default_taken`, which is the rule `given.role_of` no longer uses: an answer
        # that accepted OUR proposal is a person answering with our value, and holding the builder to it here
        # would have refused the whole handoff for building the role the agent decided - the guard cancelling
        # the fix one boundary later. `role_source` is the reader, and `THEIR_OWN_WORD` is the two kinds that
        # are the customer's own.
        for oid in {a.subject for h in (given.intake, given.late) if h is not None for a in h.answers
                    if a.about == "opening.role" and a.their_own_value()} | set(given.stated_roles):
            source = given.role_source(oid)
            built = (patches.get(oid) or {}).get("role")
            if source is not None and source[0] in given_mod.THEIR_OWN_WORD and source[1] not in ("wall",)                     and built != source[1]:
                raise ContractError("builder_handoff", f"{oid} is {source[1]!r} by the customer ({source[0]}) and "
                                                       f"the builder would build {built!r}", field=f"flow_patches.{oid}")
    prefix, budget = str(handoff.get("request_prefix") or ""), int(handoff.get("prefix_budget") or 0)
    if budget and len(prefix) > budget:
        raise ContractError("builder_handoff", f"the geometry agent's write-up is {len(prefix)} characters against "
                                               f"its budget of {budget}; past it the request cut takes the request",
                            field="request_prefix")


#: The sentence a builder reads when the geometry agent made no plan, with the reason in it. Written as one
#: `unsettled` row because that is this block's own channel for what nobody settled, and where the platform put
#: the look's state for the same reason (`application/geometry_survey.with_the_look_state`).
NO_PLAN_BECAUSE = ("the geometry agent made no plan for this part, so nothing in this block says where the cells "
                   "go and no patch here was chosen by a plan: {why}. Read the measurement and the customer's "
                   "own words and decide it yourself")

#: What `unsettled` calls the row. One word, so a reader can find it and the platform's look row cannot collide.
NO_PLAN_ABOUT = "plan"


def with_no_plan(block: dict[str, Any] | None, why: Any) -> dict[str, Any] | None:
    """The block, with ONE `unsettled` row saying the geometry agent made no plan for this part, and why.

    THE JOB THAT LOOKS COMPLETE AND IS MISSING ITS PLAN is what this closes. When the plan cannot be made, the
    builder is handed the measurement's own block: it carries the survey, the places, the look's state and the
    customer's answers, and it is byte for byte the block of a job where the geometry agent never ran at all.
    The platform knows the difference - `application/geometry_step.plan_the_part` stores `status: failed` with
    the reason and `cad/regions.planner_inputs_for_state` writes the same reason to the job's record - and the
    BUILDER, the one reader that acts on it, was told neither. A fault that reaches the builder as silence is
    the failure this whole handoff exists to end.

    IT IS THE BLOCK'S OWN CHANNEL AND NOT A NEW KEY. `unsettled` is what nobody settled, named, with a reason;
    a plan that was attempted and could not be made is exactly that. A new top-level key would have been
    dropped in silence by the platform's own allowlist (`platform_drops`, and `GEOMETRY_AGENT_BLOCK_KEYS` in
    `engines/snappy/planner.py`), which is the same silence one level down.

    `why` is the agent's own reason - `AnalysisResult.reason`, or the platform's stored `geometry_step.reason` -
    passed through `safe_reason`, because an explanation that quotes what it refused is refused again and the
    builder then loses the whole survey over it (see `safe_reason`).

    The row goes FIRST and the list keeps its length, for the reason `with_the_look_state` gives: it changes how
    every other row reads, and appending past `SURVEY_BLOCK_ITEMS` would break this package's own cap. Where the
    block is at its character ceiling the composer's own fitter makes room and counts what left; the contract is
    then run again over the survey, because a row added after the block was validated is otherwise the one thing
    in it nothing checked.
    """
    if not isinstance(block, dict) or not isinstance(block.get("survey"), dict):
        return block
    survey = dict(block["survey"])
    rows = [{"about": NO_PLAN_ABOUT, "subjects": [], "why": NO_PLAN_BECAUSE.format(why=safe_reason(why))},
            *[r for r in (survey.get("unsettled") or [])
              if not (isinstance(r, dict) and r.get("about") == NO_PLAN_ABOUT)]]
    survey["unsettled"] = rows[:SURVEY_BLOCK_ITEMS]
    if len(json.dumps(survey, default=str)) > SURVEY_BLOCK_MAX:
        # ROOM IS MADE BY THE COMPOSER'S OWN FITTER, not by a second one written here: whole items leave, least
        # trusted first, and `left_out_for_size` counts them, so nothing goes silently. A block already at its
        # ceiling must not cost the builder the one row that says there is no plan - and the deep copy is because
        # the fitter pops from the lists it is handed, which this block shares with the caller's.
        from geometry_agent.agent.hexera import _fit
        survey = _fit(copy.deepcopy(survey), SURVEY_BLOCK_MAX)
    check_survey_block(survey)
    return {**block, "survey": survey}


def attach(planner_block: dict[str, Any] | None, given: Given) -> dict[str, Any] | None:
    """Complete the survey inside an existing `hexera.planner_block` with this `Given`'s answers, under one key.

    ONE WRITER, AND IT USED TO BE TWO. `hexera.planner_survey` composes the survey inside the planner block from
    the document and from `vision.trust.for_model`: the measured marks, the look's `seen` findings, the placed
    findings (`at_places`), a digit the scrub let through (`seen_refused`), a look the contract refused
    (`look_refused`) and whatever the ceiling took (`left_out_for_size`). This function used to build a SECOND
    survey out of the `Given` alone and write it straight over that one. A `Given` holds no document and no look,
    so it can compose none of those six, and the platform prefers this path
    (`application/geometry_survey.builder_block`): six composed keys never left the document on either live path.

    Now the composed survey is the survey, and only the two keys that come off intake are filled, by
    `hexera.survey_with_answers`, which is the one implementation of that half. The `Given`-only builder
    `survey_block` is the fallback for a caller that hands over a planner block with no survey in it at all, and
    it is the contract in executable form for anybody composing one somewhere else.

    Returns the block with `survey` completed, or None when there was no planner block: an absent key is what
    makes the platform's fail-open true, and a measurement that failed must never be dressed up as a thin one.
    """
    if not isinstance(planner_block, dict):
        return None
    out = dict(planner_block)
    composed = out.get("survey")
    if isinstance(composed, dict):
        from geometry_agent.agent.hexera import survey_with_answers
        out["survey"] = survey_with_answers(composed, given)
        return out
    out["survey"] = survey_block(given)
    return out


__all__ = ["BUILDER_HANDOFF_SCHEMA", "FLOW_PATCH_KINDS", "INTAKE_BLOCK_REQUIRED", "NO_PLAN_ABOUT",
           "NO_PLAN_BECAUSE", "PLANNED_BASIS_NOTE",
           "PLATFORM_BLOCK_KEYS_BAE0FB2", "PLATFORM_BLOCK_KEYS_COMPLETE", "REFUSAL_REASON_MAX",
           "REFUSAL_UNQUOTABLE", "SURVEY_BLOCK_ITEMS",
           "SURVEY_BLOCK_MAX", "SURVEY_BLOCK_REQUIRED", "SURVEY_BLOCK_SCHEMA", "SURVEY_ROW_IDS_MAX", "attach",
           "builder_handoff", "cap_row_ids", "check_builder_handoff", "check_survey_block", "flow_patches",
           "intake_half", "platform_drops", "refusal_reason", "safe_reason", "survey_block", "with_no_plan"]
