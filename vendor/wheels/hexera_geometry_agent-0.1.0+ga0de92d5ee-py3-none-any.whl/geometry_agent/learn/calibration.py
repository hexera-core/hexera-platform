"""The calibrated tables the channel builder reads: minutes per cells bin, the per-representation cell
correction, and the PER-ENGINE correction of the builder emulator's forecast. All are fitted on LEARNING
records only and written with provenance (n, date, split sha); the readers here never fit, they only look up.

    minutes_for_cells(cells, engine) -> {"typical": median minutes, "p90": ..., "n": ..., "bin": ...}
    cell_correction(representation) -> multiplier on the standard-tier estimate (1.0 when unfitted)
    engine_cell_correction(engine, representation) -> multiplier on the EMULATOR's forecast (1.0 unless admitted)

WHY THE PER-ENGINE TABLE IS A THIRD TABLE AND NOT A COLUMN IN THE SECOND. `cell_correction` is fitted against
the facts layer's standard tier (diagonal/80) and `engine_cell_correction` against
`agent.tools.estimate_builder_cells`. They correct DIFFERENT ESTIMATORS of the same quantity, so one number
cannot serve both: `hexera.correction_info` already refuses to apply the first to the second for exactly that
reason, and pooling them into one file would have made that refusal impossible to express. The basis string on
each table names its estimator and `hexera.EMULATOR_BASIS_WORDS` is the gate.

WHERE A FITTED FACTOR MAY BE READ FROM, AND WHERE IT MAY NOT (docs/cell_forecast_correction.md, section 4).

  MAY:     learning records of the corpus export (`store.record_paths(side="learning")`), whose emulator
           forecast is recomputed from the read-only facts cache because the record does not carry it.
  MAY NOT: the locked half, and the `platform` side. `fit_engine_cell_correction` opens no file at all - the
           caller hands it samples - so the population is chosen at one place, `eval/calib/engine_cell_
           correction.py`, which selects the learning side by name and never touches
           `store.OUTCOMES_PLATFORM_DIR`.
  MONITOR: `monitor_engine_cell_correction` scores an ALREADY SHIPPED table against a fresh population, which
           is the one thing a platform record may be used for here. It returns a verdict and writes no table,
           so a real job can withdraw a factor that has stopped helping and can never set one.

EVERY GATE BELOW CAN REFUSE A FACTOR, AND THE FOUR REFUSE ON DIFFERENT EVIDENCE. The shape gate is about
whether the caller counted INDEPENDENT SHAPES at all; `MIN_RECORDS` is about how many independent shapes spoke;
the median's confidence interval is about whether they agreed on the DIRECTION; the within-factor score
re-scores every shape with the multiplier applied and is the only one that can fail while the other three pass.

WHAT `n` COUNTS, AND WHY IT IS NOT THE FILE COUNT. A factor shipped on 2026-09-25 as "snappy/external x1.8391,
n = 31 geometries, 95% CI [1.609, 1.930]". Measured: those 31 CAD files are SIX shape families (wing 8,
freeform_nacelle 5, bluff_body 5, ahmed_variant 5, rotor_like 5, blade_row_rotor 3), and all ten ahmed files in
the corpus are ONE shape at eight sizes - identical normalised bounding-box aspect 1 : 0.37261 : 0.27586 to five
decimals, longest extent 574.20 to 1357.20, two pairs the same size under different sha256. Their five learning
ratios run 2.1097 to 2.1179, a 0.39 percent spread, because scaling a shape tells the estimator nothing new.
Counting the files as 31 draws narrowed the median's interval to [1.609, 1.930], and the between-shape evidence
already inside the same fit puts blade_row_rotor at 1.2406 - so the shipped factor over-multiplied that shape's
forecast by 1.48x and the truth was OUTSIDE the published interval. Collapsed one sample per shape the fit is
n = 6, which fails this table's own `MIN_RECORDS = 12`, the identical gate that had refused snappy/fluid_domain
at n = 6. The factor is withdrawn (docs/cell_forecast_correction.md, section 3).

So the collapse is TWO levels, and `CellSample` carries both: runs -> geometry (one CAD file measured or run
many times is one geometry) -> shape (parts that differ only by a scale or a sweep of one generator's parameters
are one shape). `n` is the shape count. The geometry and run counts are still reported, beside the median they
would have produced, because the number that was shipped has to stay readable next to the number that replaced
it.
"""
from __future__ import annotations

import math
import statistics
from collections.abc import Iterable
from datetime import UTC, datetime
from functools import lru_cache
from pathlib import Path
from typing import Any, NamedTuple

from geometry_agent.learn import store
from geometry_agent.learn.schema import OutcomeRecord

CELL_BINS: tuple[tuple[str, float, float], ...] = (
    ("under_0.5M", 0.0, 500_000.0),
    ("0.5_to_1M", 500_000.0, 1_000_000.0),
    ("1_to_2M", 1_000_000.0, 2_000_000.0),
    ("over_2M", 2_000_000.0, float("inf")),
)
#: The export names representations carve, fluid_domain and external; the catalog says wall_shell,
#: fluid_domain, annular_fluid and external. Both vocabularies resolve to the fitted key.
REPRESENTATION_ALIASES = {
    "carve": "carve", "wall_shell": "carve", "body_surface": "carve",
    "fluid_domain": "fluid_domain", "fluid": "fluid_domain", "annular_fluid": "fluid_domain",
    "external": "external",
}


def cells_bin(cells: float | int) -> str:
    for name, lo, hi in CELL_BINS:
        if lo <= cells < hi:
            return name
    return CELL_BINS[-1][0]


def _quantile(values: list[float], f: float) -> float:
    xs = sorted(values)
    if len(xs) == 1:
        return xs[0]
    k = f * (len(xs) - 1)
    i = int(k)
    return xs[i] if i + 1 >= len(xs) else xs[i] + (xs[i + 1] - xs[i]) * (k - i)


def _p90(values: list[float]) -> float:
    return _quantile(values, 0.9)


def _summary(values: list[float]) -> dict[str, Any]:
    if not values:
        return {"n": 0, "median": None, "p90": None}
    return {"n": len(values), "median": round(statistics.median(values), 2), "p90": round(_p90(values), 2)}


def fit_minutes_bins(records: list[OutcomeRecord], split_sha256: str | None = None) -> dict[str, Any]:
    """Minutes per dispatched attempt, binned by the cells the attempt delivered, per engine and pooled. Attempts
    that were dispatched but delivered no mesh are their own row (`no_mesh`): the minutes the stack paid for a
    pass that did not succeed. Only learning records are passed in by the caller."""
    per_engine: dict[str, dict[str, list[float]]] = {}
    for rec in records:
        if rec.split != "learning":
            continue
        for a in rec.builder.attempts:
            if not a.dispatched or a.seconds is None or a.seconds <= 0:
                continue
            eng = a.engine or rec.geometry.engine or "unknown"
            minutes = a.seconds / 60.0
            name = cells_bin(a.quality.cells) if a.quality.cells else "no_mesh"
            for key in (eng, "all"):
                per_engine.setdefault(key, {}).setdefault(name, []).append(minutes)
    table = {}
    for eng, bins in per_engine.items():
        table[eng] = {name: _summary(bins.get(name, [])) for name, _, _ in CELL_BINS}
        table[eng]["no_mesh"] = _summary(bins.get("no_mesh", []))
        table[eng]["all_dispatched"] = _summary([m for v in bins.values() for m in v])
    return {
        "version": 1, "date": datetime.now(UTC).date().isoformat(), "split": "learning", "split_sha256": split_sha256,
        "records": sum(1 for r in records if r.split == "learning"),
        "bins": [{"name": n, "cells_min": lo, "cells_max": (None if hi == float("inf") else hi)} for n, lo, hi in CELL_BINS],
        "basis": "minutes = finished_utc - started_utc of each dispatched attempt in runs.json; cells from the attempt's score",
        "table": table,
    }


@lru_cache(maxsize=8)
def _load(path: str) -> dict[str, Any] | None:
    p = Path(path)
    if not p.exists():
        return None
    return store.read_json(p)


def reload() -> None:
    _load.cache_clear()


def minutes_for_cells(cells: float | int, engine: str = "snappy", path: Path = store.MINUTES_BINS) -> dict[str, Any]:
    """The forecast basis for one mesh: typical (median) and p90 minutes of learning-half attempts in the same
    cells bin on the same engine, with n so a thin bin is visible. Falls back to the pooled table when the
    engine has no rows; typical is None when nothing was fitted."""
    doc = _load(str(path))
    name = cells_bin(cells)
    out = {"cells": int(cells), "bin": name, "engine": engine, "typical": None, "p90": None, "n": 0, "basis": None}
    if not doc:
        return out
    table = doc.get("table", {})
    for key in (engine, "all"):
        row = table.get(key, {}).get(name)
        if row and row.get("n"):
            out.update({"typical": row["median"], "p90": row["p90"], "n": row["n"], "engine": key,
                        "basis": f"{doc.get('split')} records, split {str(doc.get('split_sha256'))[:8]}, {doc.get('date')}"})
            return out
    return out


def fit_cell_correction(records: list[OutcomeRecord], split_sha256: str | None = None,
                        label_version: int | None = None) -> dict[str, Any]:
    """The median of the delivered cells over the standard-tier estimate, per representation, on learning
    records that delivered a mesh. The multiplier turns the facts layer's estimate into the builder's count."""
    ratios: dict[str, list[float]] = {}
    for rec in records:
        if rec.split != "learning":
            continue
        est = rec.geometry.tier_estimates.get("standard")
        cells = rec.labels.cells
        rep = REPRESENTATION_ALIASES.get(rec.geometry.representation or "", rec.geometry.representation)
        if not est or not cells or not rep:
            continue
        ratios.setdefault(rep, []).append(cells / est)
    fitted = {}
    for rep, xs in sorted(ratios.items()):
        xs = sorted(xs)
        fitted[rep] = {"multiplier": round(statistics.median(xs), 3), "n": len(xs),
                       "p25": round(xs[len(xs) // 4], 3), "p75": round(xs[(3 * len(xs)) // 4], 3),
                       "min": round(xs[0], 3), "max": round(xs[-1], 3)}
    return {
        "version": 1, "date": datetime.now(UTC).date().isoformat(), "split": "learning", "split_sha256": split_sha256,
        "label_version": label_version, "records": sum(1 for r in records if r.split == "learning"),
        "basis": "median over learning records of delivered cells / standard-tier estimate (facts layer, diagonal/80)",
        "by_representation": fitted,
    }


def cell_correction(representation: str | None, path: Path = store.CELL_CORRECTION) -> float:
    """The multiplier for one representation, 1.0 when nothing was fitted for it."""
    doc = _load(str(path))
    if not doc or not representation:
        return 1.0
    rep = REPRESENTATION_ALIASES.get(representation, representation)
    row = doc.get("by_representation", {}).get(rep)
    return float(row["multiplier"]) if row and row.get("multiplier") else 1.0


def cell_correction_info(representation: str | None, path: Path = store.CELL_CORRECTION) -> dict[str, Any]:
    doc = _load(str(path))
    rep = REPRESENTATION_ALIASES.get(representation or "", representation)
    row = (doc or {}).get("by_representation", {}).get(rep) if doc else None
    return {"representation": rep, "multiplier": float(row["multiplier"]) if row else 1.0, "n": row["n"] if row else 0,
            "date": doc.get("date") if doc else None, "split_sha256": doc.get("split_sha256") if doc else None,
            "source": str(path) if row else "none (unfitted, multiplier 1.0)"}


# ---------------------------------------------------------------------------------------------------------------
# the per-engine correction of the builder emulator's forecast
# ---------------------------------------------------------------------------------------------------------------
#: Where the fitted table lives: INSIDE THE PACKAGE, beside the module that reads it, the way
#: `agent/thresholds.py` holds `thresholds.json` (`Path(__file__).with_name`).
#:
#: NOT under `store.CALIB_DIR`, and this is the difference between a correction that applies and one that only
#: exists. `store.ROOT` is `Path(__file__).resolve().parents[3]`, which is the repository from a source checkout
#: and `/usr/local/lib/python3.11` from the vendored wheel the stack installs, so `store.CALIB_DIR` in the
#: running container is `/usr/local/lib/python3.11/eval/calib`, which does not exist. Measured inside the live
#: api container at platform `3701858` with agent wheel `0.1.0+g1fb530cf5e`:
#:
#:     CALIB_DIR  /usr/local/lib/python3.11/eval/calib False
#:     cell_correction('external') = 1.0
#:     minutes_for_cells(1e6) = {'typical': None, 'n': 0}
#:
#: Both of the older tables are therefore unfitted in production however carefully they were fitted here
#: (docs/cell_forecast_correction.md section 5.3). A table named in `pyproject.toml`'s package-data travels in
#: the wheel and is found by `__file__`, which is why this one lives here.
ENGINE_CELL_CORRECTION = Path(__file__).with_name("engine_cell_correction.json")
#: The basis string, which `hexera.EMULATOR_BASIS_WORDS` checks before applying anything out of this file. Refit
#: against a different estimator and this sentence has to change with it, which turns that refusal back on.
ENGINE_BASIS = ("median over one sample per INDEPENDENT SHAPE (each shape's geometries' median of their runs') "
                "of delivered cells / estimate_builder_cells cells_high, per engine and representation, on "
                "learning records that delivered a mesh")
#: The fewest INDEPENDENT SHAPES a factor may be fitted from. THIS NUMBER IS NOT A ROUND ONE AND IT IS NOT A
#: TASTE. A factor is a median, and the honest bound on a median is the two-sided order-statistic (sign test)
#: interval. At n = 12 the smallest interval reaching 95 percent coverage is [x(3), x(10)]: it drops the two
#: most extreme samples at each end, so no single freak part can be the bound. At n = 11 the same coverage
#: needs [x(2), x(10)], where the second sample IS the bound, and below n = 6 no interval exists at all. 12 is
#: therefore the smallest n at which the interval is a statement about the population rather than about its
#: extremes, and `tests/test_learn_engine_correction.py` proves that property of 12 rather than asserting it.
#:
#: IT IS 12 SHAPES AND NOT 12 FILES, and the difference is the whole of the module docstring's second section:
#: the interval's coverage is a statement about independent draws, so feeding it a shape counted five times at
#: five sizes does not buy coverage, it only narrows the interval around a number five of whose samples are the
#: same number. Nothing about 12 changes; what it counts does.
MIN_RECORDS = 12
#: The coverage the median's interval is computed at.
MEDIAN_CI_LEVEL = 0.95
#: "Close enough" for a cell forecast, and the yardstick the third gate scores with. Cells scale as the cube of
#: the mesh size, so 1.5x in cells is 1.14x in the cell the builder would have to choose to hit it: a forecast
#: inside 1.5x names the same mesh and one outside it does not. It is deliberately tighter than the 2x a reader
#: might reach for: at 2x the external row scored 30 of 31 BEFORE correction and the third gate would have had
#: nothing left to say.
WITHIN_FACTOR = 1.5


class CellSample(NamedTuple):
    """One run's forecast against what the builder delivered, with the two identities the collapse needs.

    `geometry` is the identity of the FILE, and the caller's job is to make it the CAD file's own hash rather
    than the measurement's. Both the fit and the monitor collapse a geometry's runs to one before anything is
    counted, because otherwise one file counts many times, and that is not hypothetical in either direction:

      - of the 8 finished platform jobs in the local database that carry both a forecast and a delivered count,
        all 8 are one part (ahmed_variant_001, sha 9c8b9b95), and `eval/platform/summary_2026-09-25.json`
        published "n 5" for it with nothing saying it was one geometry;
      - `eval/outcomes` holds two records for each of the 322 corpus cases, same file and two measurement
        revisions, so keying on the facts sha doubled every n and moved the carve row's interval from
        [0.967, 1.484], which contains 1.0, to [1.024, 1.321], which does not.

    `shape` is the identity of the SHAPE, and it is what the gates count. Two files are one shape when the
    ratio one of them measures is not new information about the other: the same solid at another size, the same
    generator's parameter sweep, the same part re-exported. A DIFFERENT file is not a different draw - measured
    on the ten ahmed files (module docstring), the same shape at eight sizes returns the same ratio to within
    0.39 percent, and counting them as eight samples narrowed the published interval around a number that five
    of its samples had already fixed.

    WHERE EACH CALLER GETS `shape` FROM, and why neither can be guessed here:

      - `eval/calib/engine_cell_correction.py` takes the corpus family off the record. The 322-case export is 22
        parametric GENERATORS; a family's members are a sweep of one shape's parameters and not a sample of
        parts, which is the structure `eval/split/make_split.py` already stratifies and groups on.
      - the monitor's real jobs take the CAD file's own sha: two customers' parts are not variants of one
        generator, so a real part is its own shape and says so explicitly.

    AN UNDECLARED SHAPE IS REFUSED, NEVER GUESSED. Defaulting it to `geometry` would count files again and read
    as though shapes had been counted, which is the exact failure this field exists for, and defaulting it to a
    single bucket would silently refuse every population. So a row with any sample whose `shape` is empty is
    refused with that as its reason, and `n` is never published for it.
    """

    geometry: str
    engine: str
    representation: str
    forecast: float
    delivered: float
    case: str = ""
    shape: str = ""


def _sign_test_interval(values: list[float], level: float = MEDIAN_CI_LEVEL) -> tuple[float | None, float | None, int | None]:
    """The two-sided order-statistic interval for the median: [x(k+1), x(n-k)] for the largest k whose coverage
    1 - 2 P(Bin(n, 0.5) <= k) still reaches `level`. None when no k reaches it, which is every n under 6."""
    xs = sorted(values)
    n = len(xs)
    if n < 6:
        return None, None, None
    best: int | None = None
    total = 2.0 ** n
    for k in range(n // 2):
        if 1.0 - 2.0 * (sum(math.comb(n, i) for i in range(k + 1)) / total) >= level:
            best = k
        else:
            break
    if best is None:
        return None, None, None
    return xs[best], xs[n - 1 - best], best


#: What a shape is called in a row that has none. It is a sentinel and never a shape: `_engine_row` refuses the
#: row rather than fitting from it, so this string can only ever be read in the reason.
UNDECLARED_SHAPE = "?undeclared"


def _ratios_by_shape(samples: Iterable[CellSample]) -> dict[tuple[str, str], dict[str, dict[str, list[float]]]]:
    """Every run's ratio, grouped by (engine, representation) then SHAPE then geometry. Nothing is collapsed yet.

    A sample with no `shape` lands under `UNDECLARED_SHAPE`, which is one bucket per row on purpose: it makes the
    row's shape count wrong in the safe direction (too few, so the row is refused) rather than in the direction
    that ships a factor.
    """
    per: dict[tuple[str, str], dict[str, dict[str, list[float]]]] = {}
    for s in samples:
        if not s.forecast or not s.delivered or s.forecast <= 0 or s.delivered <= 0:
            continue
        rep = REPRESENTATION_ALIASES.get(s.representation or "", s.representation) or "unknown"
        shape = (s.shape or "").strip() or UNDECLARED_SHAPE
        (per.setdefault((s.engine or "unknown", rep), {}).setdefault(shape, {})
            .setdefault(s.geometry, []).append(s.delivered / s.forecast))
    return per


def _geometry_medians(by_shape: dict[str, dict[str, list[float]]]) -> list[float]:
    """One ratio per FILE across every shape of one row, sorted: the file-level view, reported never fitted."""
    return sorted(statistics.median(rs) for by_geom in by_shape.values() for rs in by_geom.values())


def _runs(by_shape: dict[str, dict[str, list[float]]]) -> list[float]:
    """Every individual run's ratio in one row, sorted. What a reading is; never what a verdict is taken on."""
    return sorted(r for by_geom in by_shape.values() for rs in by_geom.values() for r in rs)


def _one_sample_per_shape(by_shape: dict[str, dict[str, list[float]]]) -> dict[str, float]:
    """One ratio per shape: the median over that shape's geometries of each geometry's own median run.

    Two medians and not one pooled median over the runs, so that a shape whose files were run different numbers
    of times does not weight itself by how often the harness happened to run it.
    """
    return {shape: statistics.median(sorted(statistics.median(rs) for rs in by_geom.values()))
            for shape, by_geom in by_shape.items()}


def _within(ratios: Iterable[float], multiplier: float, factor: float = WITHIN_FACTOR) -> int:
    """How many forecasts land inside `factor` of the delivered count once `multiplier` is applied."""
    return sum(1 for r in ratios if (1.0 / factor) <= (r / multiplier) <= factor)


def _engine_row(by_shape: dict[str, dict[str, list[float]]]) -> dict[str, Any]:
    """One (engine, representation) row: the candidate multiplier, its evidence, and the gate's verdict.

    The four gates in order, each carrying the words that say which one refused. A row is `applied` only when all
    four pass, and a refused row keeps its `candidate` so a reader can see the number that was not shipped.

    `n` IS THE SHAPE COUNT. `per_geometry` carries what the same population looks like one sample per FILE - its
    count, its median and the interval that count would have produced - because a reader comparing this table
    against the one shipped on 2026-09-25 needs to see both numbers to see what changed, and because a row whose
    file count is five times its shape count is telling a reader something about the corpus.
    """
    shapes = _one_sample_per_shape(by_shape)
    xs = sorted(shapes.values())
    n = len(xs)
    geoms = _geometry_medians(by_shape)
    runs = len(_runs(by_shape))
    g_lo, g_hi, _ = _sign_test_interval(geoms)
    median = statistics.median(xs)
    geomean = math.exp(statistics.fmean(math.log(x) for x in xs))
    p10, p90 = _quantile(xs, 0.10), _quantile(xs, 0.90)
    lo, hi, dropped = _sign_test_interval(xs)
    before, after = _within(xs, 1.0), _within(xs, median)
    row: dict[str, Any] = {
        "candidate": round(median, 4), "multiplier": 1.0, "applied": False, "n": n, "shapes": n,
        "geometries": len(geoms), "runs": runs,
        "median": round(median, 4), "geomean": round(geomean, 4), "p10": round(p10, 4), "p90": round(p90, 4),
        "min": round(xs[0], 4), "max": round(xs[-1], 4),
        "dispersion_p90_over_p10": round(p90 / p10, 2) if p10 else None,
        "median_ci": [round(lo, 4), round(hi, 4)] if lo is not None else None,
        "median_ci_level": MEDIAN_CI_LEVEL, "median_ci_drops_each_end": dropped,
        "within_factor": WITHIN_FACTOR, "within_raw": before, "within_corrected": after,
        "shape_medians": {s: round(v, 4) for s, v in sorted(shapes.items(), key=lambda kv: kv[1])},
        "per_geometry": {"n": len(geoms), "median": round(statistics.median(geoms), 4),
                         "min": round(geoms[0], 4), "max": round(geoms[-1], 4),
                         "median_ci": [round(g_lo, 4), round(g_hi, 4)] if g_lo is not None else None,
                         "read_as": "the file-level view of the same population, reported and never fitted from: "
                                    "files of one shape are not independent draws and its interval is narrower "
                                    "than the evidence supports"},
        "why": "",
    }
    if UNDECLARED_SHAPE in by_shape:
        files = len(by_shape[UNDECLARED_SHAPE])
        row.update({"n": 0, "shapes": 0, "candidate": round(median, 4), "median_ci": None})
        row["why"] = (f"{files} of {len(geoms)} geometries reached the fit with no shape declared, so how many "
                      f"INDEPENDENT shapes this population holds is unknown and cannot be guessed: a file count "
                      f"read as a shape count is the defect this gate exists for; 1.0 applied")
        return row
    if n < MIN_RECORDS:
        row["why"] = (f"{n} independent shapes ({len(geoms)} geometries over {runs} runs) is under the minimum of "
                      f"{MIN_RECORDS}, the smallest n whose {MEDIAN_CI_LEVEL:g} interval for the median drops the "
                      f"two most extreme samples at each end; 1.0 applied")
        return row
    if lo is None or hi is None:
        row["why"] = f"no {MEDIAN_CI_LEVEL:g} interval exists at n {n} shapes; 1.0 applied"
        return row
    if lo <= 1.0 <= hi:
        row["why"] = (f"the {MEDIAN_CI_LEVEL:g} interval for the median is [{lo:.3f}, {hi:.3f}], which contains 1.0: "
                      f"these {n} shapes do not agree on the DIRECTION of the error, so there is no bias to "
                      f"correct and a multiplier of {median:.3f} would be a fact that lies; 1.0 applied")
        return row
    if after <= before:
        row["why"] = (f"applying {median:.3f} leaves {after} of {n} shapes' forecasts within {WITHIN_FACTOR:g}x of "
                      f"the delivered count against {before} of {n} raw, so the multiplier does not make the "
                      f"forecast better on the shapes it was fitted from; 1.0 applied")
        return row
    row["multiplier"] = round(median, 4)
    row["applied"] = True
    row["why"] = (f"{n} independent shapes ({len(geoms)} geometries over {runs} runs), median {median:.3f}, "
                  f"{MEDIAN_CI_LEVEL:g} interval [{lo:.3f}, {hi:.3f}] entirely "
                  f"{'above' if lo > 1.0 else 'below'} 1.0, and applying it takes {before} of {n} shapes within "
                  f"{WITHIN_FACTOR:g}x of delivered to {after} of {n}")
    return row


def fit_engine_cell_correction(samples: Iterable[CellSample], split_sha256: str | None = None,
                               label_version: int | None = None, population: str = "learning") -> dict[str, Any]:
    """The per-engine correction of the emulator's forecast, from samples the caller chose.

    THIS FUNCTION OPENS NO FILE. The population is the caller's decision and is named in the document it
    returns, which is how the split stays governed in one place instead of in every reader. The caller also
    decides what a SHAPE is, for the same reason and with the same consequence: it is the one place that knows
    whether two files are variants of one thing, and `CellSample.shape` says where each caller gets it.
    """
    by_key = _ratios_by_shape(samples)
    table = {f"{eng}/{rep}": _engine_row(by_shape) for (eng, rep), by_shape in sorted(by_key.items())}
    return {
        "version": 2, "date": datetime.now(UTC).date().isoformat(), "split": population,
        "split_sha256": split_sha256, "label_version": label_version,
        "shapes": sum(1 for by_shape in by_key.values() for s in by_shape if s != UNDECLARED_SHAPE),
        "geometries": sum(len(by_geom) for by_shape in by_key.values() for by_geom in by_shape.values()),
        "basis": ENGINE_BASIS,
        "gates": {"min_records": MIN_RECORDS, "median_ci_level": MEDIAN_CI_LEVEL, "within_factor": WITHIN_FACTOR,
                  "counts": "INDEPENDENT SHAPES, not files: runs collapse to a geometry and geometries of one "
                            "shape collapse to that shape before anything is counted",
                  "rule": "a factor is applied only when every sample declared its shape, when it is fitted from "
                          "at least min_records INDEPENDENT SHAPES, when its median's interval excludes 1.0, and "
                          "when applying it raises the share of shapes' forecasts within within_factor of the "
                          "delivered count"},
        "by_engine": table,
    }


def engine_cell_correction(engine: str | None, representation: str | None, path: Path | None = None) -> float:
    """The admitted multiplier for one engine and representation, 1.0 when none was admitted."""
    return float(engine_cell_correction_info(engine, representation, path)["multiplier"])


def engine_cell_correction_info(engine: str | None, representation: str | None,
                                path: Path | None = None) -> dict[str, Any]:
    """The multiplier and everything a later reader needs to tell a corrected forecast from a raw one: the n it
    was fitted from, the interval, whether it was applied, and in words why not when it was not.

    An engine with no row at all is reported as such rather than as a bare 1.0: absence of a factor is not
    evidence that the forecast is unbiased for that engine, and the two have to read differently.

    `path` is resolved HERE and not in the signature. A default argument is bound at import, so a table path
    named in the signature cannot be redirected by a test or by a caller that has moved the calib directory, and
    the redirect fails silently by reading the shipped file instead - which is how the first version of
    `tests/test_learn_engine_correction.py` measured the real external multiplier while believing it had set 2.0.
    """
    path = Path(path) if path is not None else ENGINE_CELL_CORRECTION
    rep = REPRESENTATION_ALIASES.get(representation or "", representation)
    doc = _load(str(path))
    out: dict[str, Any] = {"engine": engine, "representation": rep, "multiplier": 1.0, "applied": False, "n": 0,
                           "n_counts": "shapes", "shapes": None, "geometries": None, "runs": None,
                           "basis": None, "why": "no fitted table", "source": "none (unfitted, multiplier 1.0)",
                           "date": None, "split": None, "split_sha256": None}
    if not doc:
        return out
    out.update({"basis": doc.get("basis"), "date": doc.get("date"), "split": doc.get("split"),
                "split_sha256": doc.get("split_sha256")})
    rows = doc.get("by_engine") or {}
    row = rows.get(f"{engine}/{rep}")
    if row is None:
        out["why"] = (f"the table carries no row for {engine}/{rep} (it has {', '.join(sorted(rows)) or 'none'}), "
                      f"so nothing is known about this engine's bias and 1.0 is applied")
        return out
    out.update({"n": row.get("n", 0), "applied": bool(row.get("applied")), "candidate": row.get("candidate"),
                "median_ci": row.get("median_ci"), "dispersion_p90_over_p10": row.get("dispersion_p90_over_p10"),
                "within_raw": row.get("within_raw"), "within_corrected": row.get("within_corrected"),
                #: `n` is the SHAPE count from version 2 on. A reader that quotes it as "n geometries" is
                #: repeating the claim this table was refitted to stop making, so both counts travel and
                #: `n_counts` says in one word which one `n` is.
                "n_counts": "shapes" if row.get("shapes") is not None else "geometries",
                "shapes": row.get("shapes"), "geometries": row.get("geometries"), "runs": row.get("runs"),
                "why": row.get("why") or "", "source": str(path)})
    if row.get("applied"):
        out["multiplier"] = float(row.get("multiplier") or 1.0)
    return out


def monitor_engine_cell_correction(samples: Iterable[CellSample], path: Path | None = None,
                                   population: str = "platform") -> dict[str, Any]:
    """Score the SHIPPED table against a fresh population. Fits nothing and writes nothing.

    This is the only thing a `platform` record may be used for here. A verdict needs `MIN_RECORDS` INDEPENDENT
    SHAPES, on the same collapse and for the same reason as the fit: the local database's 8 finished jobs that
    carry both numbers are one part, and a median over them is a statement about that part. Below the minimum the
    row says `too_few` and still carries the numbers, which is the honest reading and is not a verdict.

    A sample with no shape is refused here as it is in the fit (`no_shape`), because a monitor that guessed the
    independence of its own population could withdraw a factor on a reading it had over-counted.
    """
    path = Path(path) if path is not None else ENGINE_CELL_CORRECTION
    raw_by_key = _ratios_by_shape(samples)
    rows: dict[str, Any] = {}
    for (eng, rep), by_shape in sorted(raw_by_key.items()):
        info = engine_cell_correction_info(eng, rep, path)
        m = float(info["multiplier"])
        xs = sorted(_one_sample_per_shape(by_shape).values())
        geoms = _geometry_medians(by_shape)
        # The collapsed samples are what any verdict is taken on, and the runs behind them are what the reading
        # is. Reporting only the collapsed spread on one part would print min == max == the median and read as
        # five jobs agreeing, when the five ran from 1.492 to 3.649 on the same geometry.
        every = _runs(by_shape)
        before, after = _within(xs, 1.0), _within(xs, m)
        row = {"shapes": len(xs), "geometries": len(geoms), "rows_seen": len(every), "shipped_multiplier": m,
               "shipped_n": info["n"], "applied": info["applied"], "median": round(statistics.median(xs), 4),
               "min": round(xs[0], 4), "max": round(xs[-1], 4),
               "every_run_min": round(every[0], 4), "every_run_max": round(every[-1], 4),
               "within_factor": WITHIN_FACTOR, "within_raw": before, "within_shipped": after}
        if UNDECLARED_SHAPE in by_shape:
            row["verdict"] = "no_shape"
            row["why"] = (f"{len(by_shape[UNDECLARED_SHAPE])} of {len(geoms)} geometries arrived with no shape "
                          f"declared, so how many independent shapes this reading holds is unknown; the numbers "
                          f"are reported and no verdict is published")
        elif len(xs) < MIN_RECORDS:
            row["verdict"] = "too_few"
            row["why"] = (f"{len(every)} runs over {len(geoms)} distinct geometries and {len(xs)} independent "
                          f"shapes, ratios {every[0]:.3f} to {every[-1]:.3f}; {len(xs)} shapes is under the "
                          f"minimum of {MIN_RECORDS}, so the numbers are reported and no verdict is published")
        elif not info["applied"]:
            row["verdict"] = "nothing_shipped"
            row["why"] = f"no multiplier is applied for {eng}/{rep}: {info['why']}"
        elif after >= before:
            row["verdict"] = "still_helps"
            row["why"] = f"the shipped {m:g} takes {before} of {len(xs)} within {WITHIN_FACTOR:g}x to {after}"
        else:
            row["verdict"] = "withdraw"
            row["why"] = (f"the shipped {m:g} takes {before} of {len(xs)} within {WITHIN_FACTOR:g}x DOWN to {after}: "
                          f"it no longer helps on this population and should be refitted or withdrawn")
        rows[f"{eng}/{rep}"] = row
    return {"schema": "geometry_agent.learn.engine_correction_monitor.v2", "population": population,
            "date": datetime.now(UTC).date().isoformat(), "table": str(path), "fits_nothing": True,
            "shapes": sum(1 for bs in raw_by_key.values() for s in bs if s != UNDECLARED_SHAPE),
            "geometries": sum(len(bg) for bs in raw_by_key.values() for bg in bs.values()), "by_engine": rows}
