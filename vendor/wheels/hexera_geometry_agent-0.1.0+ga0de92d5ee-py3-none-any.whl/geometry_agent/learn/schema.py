"""OutcomeRecord v2: what the agent predicted for one geometry, what the builder did, what the reviewer said,
what the CUSTOMER said when we asked, and the labels the label script gave the case (docs/dev_plan.md, P0).

A record is written once per job by an ingester and never edited by hand. Its split is assigned at ingest by
`assign_split` and is the only thing that decides which ledger its post-mortem rows land in: a geometry or a
group already on the locked list is locked whatever source it came from, so a re-export or a harness rerun of a
locked case can never leak into calibration; blind and dose records are never learning.

v3 (2026-09-25, docs/learning_loop.md section 11) added the two measurements that make the SURVEYOR's own value
readable off a real job, both free and both computed rather than surveyed:

  `platform.counterfactual`  what the same survey would have proposed from the MEASUREMENT ALONE, field by
                             field, beside what it proposed with the look. The measurement runs on every
                             upload anyway and the look rides on the same document, so the composition can be
                             run again with the look taken out; the difference is the look's whole
                             contribution, adjudicated by what the customer confirmed or corrected and, on the
                             forecast fields, by the cells the builder delivered. No second arm and no second
                             model call.
  `platform.look.openings`   the look's `openings_seen[].likely_role` scored per MOUTH against the roles the
                             customer confirmed. `LookAgreement.looks_like` is one field a part; this is n a
                             part, on the signal that decides the boundary conditions.

v2 (2026-09-25, docs/learning_loop.md section 10) added three blocks and one source, for the signals that only a
REAL customer job produces and that v1 threw away:

  `answers`   one row per place per survey question: what this platform would have done unasked
              (`proposed`) and what the human said instead (`answer`). `verdict` is `corrected` when they
              differ, which is the highest-value label in the system and the only one that is free.
  `platform`  the job's own outcome: the reviewer's verdict, the quality gate's measured numbers, the cell
              forecast against the cells the builder delivered, and the look against the settled
              representation.
  source `platform`, split `platform`  a THIRD population beside the corpus export's learning and locked
              halves. It is never learning and never locked (`assign_split`), so nothing that calibrates can
              read it and no real job can move the locked half's answer key.

MIGRATION. Nothing is renamed and nothing is removed, and every new field has a default, so a v1 record on disk
validates unchanged and reads back with `schema_version: 1`, empty `answers` and `platform: None`. A reader that
wants to know which shape it has reads `schema_version`; `SCHEMA_HISTORY` says what each version added, and
`tests/test_learn_schema.py` loads a v1 document to hold that promise. Re-ingesting an export rewrites its
records at the current version, which is why `write_record`'s "unchanged" comparison ignores `ingested` only: an
older file is legitimately rewritten once, the first time the ingest runs after a version change.

READ THE VERSION BEFORE POOLING TWO RECORDS. v4 is the one bump that changes what an existing VALUE means rather
than adding a field: see `SCHEMA_HISTORY[4]`. A v3 `representation_verdict` came from a scorer that could not
produce `disagreed` on any input and that read two absent representations as agreement, so a v3 `agreed` and a
v4 `agreed` are not the same claim.
"""
from __future__ import annotations

from datetime import UTC, datetime
from typing import Any, Literal

from pydantic import BaseModel, Field

OUTCOME_SCHEMA_VERSION = 4

#: What each version of this record added. A reader across a version boundary says so out loud, and this is
#: what it reads to know what it is missing.
SCHEMA_HISTORY: dict[int, str] = {
    1: "geometry, agent, builder attempts, reviewer, labels, intake",
    2: "answers (the customer's corrections), platform (the real job's outcome, forecast and look), "
       "source and split `platform`",
    3: "platform.counterfactual (what the survey would have proposed with no look, field by field, "
       "adjudicated) and platform.look.openings (the look's role guess scored per mouth)",
    #: THE ONE VERSION THAT CHANGES WHAT AN EXISTING VALUE MEANS, which is why it is a version and not an
    #: additive field set. On a v3 record `platform.look.representation_verdict` could not be `disagreed` on
    #: any input (the scorer compared a signal NAME to a set of `Alert.kind` CLASSES), and `agreed` counted
    #: the document's `unknown` matching a settled `unknown` - 10 of the 124 records of 2026-09-26. A v3
    #: `agreed` and a v4 `agreed` are not the same claim, and a reader pooling them would average a repaired
    #: scorer with a broken one.
    4: "platform.look.alert_signals and representation_why, the six-value REPRESENTATION_VERDICTS (v3 could "
       "not produce `disagreed` at all and read two blanks as agreement), and answers[].quote_refuses and "
       "quote_names_its_subject with the verdict `quote_refuses_the_option` (v3 read a refusal's own words "
       "as the customer choosing the option they refused)",
}

Split = Literal["learning", "locked", "blind", "dose", "platform", "unassigned"]
#: `live` is a recorded live-model evaluation run (learn/ingest_live.py): the agent's own warnings and questions
#: on a case the corpus export already labelled, with no new mesh. `platform` is a finished job on the real
#: platform (learn/ingest_platform.py), exported by `meshpipeline.application.learning_export`.
Source = Literal["corpus_export", "sample_export", "harness", "dose", "blind", "live", "platform"]
Policy = Literal["live", "heuristic", "replay", "platform", "none"]
Audience = Literal["builder", "user", "note"]

#: What an answer to a survey question is worth as a label, and it is deliberately four values and not two.
#:
#:   confirmed          the human's own words selected the option this platform would have taken unasked. It
#:                      teaches that the proposal was right on this part.
#:   corrected          they selected a different one. THE label: a measured miss of whatever proposed it, on a
#:                      real part, with the measurement and the look attached, at no annotation cost.
#:   not_a_label        nobody chose. A default that stood, a skip, a question never answered - and a
#:                      DELEGATION ("you decide", "your call"), whose stored value is this platform's OWN pick
#:                      wearing the customer's authority. Counting a delegation as a confirmation would report
#:                      "the customer agreed with us" on exactly the jobs where they said nothing about the
#:                      substance, which is a fact that lies, and it would compound invisibly
#:                      (`geometry_agent.ask.record.RATCHET_RULES`, the fourth rule).
#:   unknown_authority  the export did not say whether the words were a delegation. The row cannot be scored
#:                      and is never silently a confirmation: absence of the flag is not evidence of a choice.
#:   quote_does_not_choose
#:                      the customer's own words, as the row stores them, do not name the option the answer
#:                      was recorded as. FOUND BY THIS MODULE ON REAL JOBS: `geometry_survey.said_by_customer`
#:                      only asks whether the quote appears in the customer's message, and `_canonical_option`
#:                      checks the option the MODEL passed - so a model may record "o4 is the inlet" quoting the
#:                      word "go", and the platform accepts it, correctly, as an instruction to proceed.
#:                      MEASURED on the 8 finished jobs in the local database: 16 role answers were recorded on
#:                      the bare quote "go" and 20 on a delegation, and 0 on words that name a mouth and a role.
#:                      Scoring the 16 would have published a port-role correction rate of 0.5 over 16 "labels",
#:                      every one of them the model's own pick.
#:   proposal_not_stored
#:                      the customer answered and the proposal is GONE. It is counted apart from
#:                      `not_a_label` because it is the one of the five that is a platform defect rather than a
#:                      property of the answer, and pooling the two would hide it. `geometry_survey.compose`
#:                      rebuilds the `asking` row on every recomposition and `carry_answers` carries the
#:                      answers but not the record rows, so the moment a question is settled its per-place
#:                      proposals are overwritten. MEASURED on job 489fa1ab: the customer's fluid-side answer
#:                      survives and the `q_fluid_side` record row does not, so that label is lost while all
#:                      four port-role labels are kept. docs/learning_loop.md section 10.5 carries the ask.
#:   quote_refuses_the_option
#:                      the customer's own words REFUSE the option the answer was recorded as. A refusal names
#:                      the thing it refuses, so "o4 is not the inlet" contains the word `inlet` and passed
#:                      `quote_does_not_choose`'s gate, which is a substring test with no reader of negation
#:                      behind it. With a proposal of `outlet` beside it the row was published as
#:                      `corrected`, "we would have said outlet; the customer said inlet" - ground truth
#:                      asserting the customer chose what they had just refused. The reading is now
#:                      `learning_export.quote_reading`'s `refuses`, which is the denial reader
#:                      `geometry_survey.accepts_a_proposal` already consults, and not a second opinion.
ANSWER_VERDICTS: tuple[str, ...] = ("confirmed", "corrected", "not_a_label", "unknown_authority",
                                    "quote_does_not_choose", "quote_refuses_the_option",
                                    "proposal_not_stored")
#: The verdicts that are ground truth about a part. Mirrors `ask.record.LABEL_SOURCES` in intent.
LABEL_VERDICTS: frozenset[str] = frozenset({"confirmed", "corrected"})


class Geometry(BaseModel):
    case: str
    source_path: str
    sha256: str
    facts_sha256: str
    facts_schema_version: int
    family: str | None = None
    group: str | None = None
    representation: str | None = None
    engine: str | None = None
    purpose: str
    unit: str | None = None
    cell_cap: int | None = None
    declared: list[dict[str, Any]] = Field(default_factory=list)
    bbox_extent: tuple[float, float, float] | None = None
    n_openings: int = 0
    #: The facts layer's own count per tier (draft, standard, max) with the standard tier's base and surface
    #: cell, so calibration reads records and never the cache.
    tier_estimates: dict[str, int] = Field(default_factory=dict)
    base_size: float | None = None
    surface_cell: float | None = None


class AgentWarning(BaseModel):
    kind: str
    audience: Audience
    severity: str | None = None
    threshold_key: str | None = None
    measurement: dict[str, Any] = Field(default_factory=dict)
    #: Opening, region or cluster ids the warning is about; empty when it is about the whole case.
    location: list[str] = Field(default_factory=list)
    builder_frame: dict[str, Any] = Field(default_factory=dict)
    effect: str | None = None
    requires_user_decision: bool = False


class AgentQuestion(BaseModel):
    id: str
    kind: str | None = None
    text: str
    default: str | None = None
    effect: str | None = None
    relates_to: list[str] = Field(default_factory=list)


class AgentBlock(BaseModel):
    present: bool = False
    policy: Policy = "none"
    prompt_sha256: str | None = None
    thresholds_sha256: str | None = None
    features_sha256: str | None = None
    model: str | None = None
    rounds: int | None = None
    seconds: float | None = None
    header_keys: dict[str, Any] = Field(default_factory=dict)
    warnings: list[AgentWarning] = Field(default_factory=list)
    questions: list[AgentQuestion] = Field(default_factory=list)


class Quality(BaseModel):
    cells: int | None = None
    max_skewness: float | None = None
    max_non_orthogonality_deg: float | None = None
    skew_fraction: float | None = None
    skew_faces: int | None = None
    layer_coverage: float | None = None
    fatal: bool | None = None
    wall_faces: int | None = None
    failed_gate: str | None = None
    #: The patch carrying the worst skew face, once a harness bundle or step 8 writes it. None until then, and
    #: every hit is grade B while it is None.
    worst_patch: str | None = None


class Attempt(BaseModel):
    index: int
    status: str
    dispatched: bool = False
    engine: str | None = None
    job_id: str | None = None
    episode: str | None = None
    intake: str | None = None
    turns: int | None = None
    started: str | None = None
    finished: str | None = None
    seconds: float | None = None
    strategy: dict[str, Any] | None = None
    prior_feedback: str | None = None
    #: Per header key, whether the builder's authored value matched the agent's (P3); empty until a harness run.
    fidelity: dict[str, Any] = Field(default_factory=dict)
    quality: Quality = Field(default_factory=Quality)


class BuilderBlock(BaseModel):
    platform_revision: str | None = None
    attempts: list[Attempt] = Field(default_factory=list)


class ReviewerBlock(BaseModel):
    verdict: str | None = None
    feedback: str | None = None


class Labels(BaseModel):
    """A copy of the label script's row. Never recomputed here: eval/labels/build_labels.py is the one source."""
    label_version: int | None = None
    split: str | None = None
    final_status: str | None = None
    first_dispatched_status: str | None = None
    first_attempt_failed: bool | None = None
    never_ran: bool | None = None
    ever_succeeded: bool | None = None
    failed: bool | None = None
    cells: int | None = None
    cell_cap: int | None = None
    over_budget: bool | None = None
    max_non_ortho: float | None = None
    max_skewness: float | None = None
    poor_non_ortho: bool | None = None
    poor_skew: bool | None = None
    poor_70_4: bool | None = None
    poor_65_4: bool | None = None
    quality_label_eligible: bool | None = None
    #: Components the export cannot carry yet (wall faces zero, a carve leak); None until a harness bundle.
    wall_faces_zero_or_leak: bool | None = None


class IntakeBlock(BaseModel):
    turns: int | None = None
    first_dispatched_turns: int | None = None
    questions: list[str] = Field(default_factory=list)
    questions_by_topic: dict[str, int] = Field(default_factory=dict)
    brief: str | None = None


class AnswerOutcome(BaseModel):
    """One label: what this platform would have done unasked, and what the human said instead.

    ONE ROW PER PLACE, not per question, for the reason `ask.record.record_for` gives: the role question names
    four mouths and one answer places all four, so a question-shaped row would give one label for four facts
    and lose three of them.

    `proposed` IS THE PER-PLACE PROPOSAL (`ask.record` `targets[].proposed`) AND NEVER THE QUESTION'S OWN
    DEFAULT. On the role question the default is a sentence - "treat o1 as the inlet and the other unplaced
    mouths as outlets" - and the answer is the word "inlet", so comparing the two calls every role answer a
    correction, including the ones the customer confirmed. Measured on job 489fa1ab (ahmed_variant_001, four
    mouths, all four confirmed): `ask.record.answered` reports `default_overturned` True on 4 of 4, and the
    per-place comparison reports 4 confirmed and 0 corrected. That is why this module does not call
    `ask.record.answered`, and `tests/test_learn_ingest_platform.py` pins both numbers.
    """
    question_id: str
    #: `ask.record.question_key`: a pure function of the abstention, so one part uploaded twice is one label.
    question_key: str | None = None
    kind: str = ""
    #: the field the answer sets, in the SURVEYOR's vocabulary (`openings[o1].role`, `representation`)
    field: str = ""
    place: str | None = None
    #: `consequence.tier` - why it was worth asking (`ask.schema.TIERS`)
    tier: str | None = None
    proposed: str | None = None
    answer: str | None = None
    #: customer | operator | defaulted | skipped | delegated | unanswered
    answered_by: str = "unanswered"
    #: whether the quote the answer was recorded on is a standing delegation. None means the export did not
    #: say, and then the row is `unknown_authority` rather than a label.
    delegated: bool | None = None
    #: THE OTHER TWO HALVES OF THAT READING, as `learning_export.quote_reading` wrote them, carried on the row
    #: so a record says what it was scored on and a reader can recount it without the envelope.
    #: `quote_refuses` is the denial reader `geometry_survey.accepts_a_proposal` consults - a quote that
    #: refuses an option is not a choice of it, however many of its words it repeats.
    #: `quote_names_its_subject` is `geometry_survey._mentions` - it is what tells a BLANKET delegation from
    #: one that placed this mouth itself, and without it "o5 is the inlet, the rest you decide" vetoed o5.
    #: None on both means the export predates the reading, and then the row is `unknown_authority`.
    quote_refuses: bool | None = None
    quote_names_its_subject: bool | None = None
    verdict: str = "not_a_label"
    #: which of the `ANSWER_VERDICTS` rules applied, in words, so a row that is not a label says why.
    why: str = ""
    words: str = ""
    at: str | None = None
    #: A retired row, and WHY it was retired, which are two different facts on this platform.
    #: `superseded` means the customer replaced it themselves and `superseded_by` carries what with; empty
    #: means the next composition no longer raises the question, which is what a SETTLED question looks like
    #: and is still the answer the job ran on (`geometry_survey.carry_answers`).
    retired: bool = False
    retired_because: str | None = None
    superseded_by: str | None = None
    options: list[str] = Field(default_factory=list)
    #: what the look said about this place, and the TRUST TIER of each field it said it in, at the time
    look_said: dict[str, Any] = Field(default_factory=dict)
    look_tiers: dict[str, str] = Field(default_factory=dict)
    measurement: dict[str, Any] = Field(default_factory=dict)
    consequence: dict[str, Any] = Field(default_factory=dict)

    @property
    def is_label(self) -> bool:
        return self.verdict in LABEL_VERDICTS


class Forecast(BaseModel):
    """The agent's cell forecast against the cells the builder delivered.

    dev_plan_v3 error 2 measured this on the corpus at median 1.86x the delivered cells, p90 22.9x, max 576x,
    and named it the driver of the most common customer question. Every real job measures the same ratio for
    free, in the other direction too: on job 489fa1ab the forecast was 93,200 and the mesh came in at 258,540,
    so `delivered_over_forecast` is 2.774.

    `delivered_over_forecast` is None when either number is missing. ABSENCE IS NOT 1.0: a job whose viewer
    payload could not be read has no ratio, and averaging it in as agreement is the failure this field exists
    to avoid.
    """
    source: str | None = None
    cells_low: int | None = None
    cells_high: int | None = None
    cap: int | None = None
    proper_cells_across: int | None = None
    delivered: int | None = None
    delivered_over_forecast: float | None = None
    #: delivered against the RESOLVED budget, and None when the job stated none. Never a platform ceiling
    #: standing in for a customer cap (the trap pinned by 57324d2).
    over_cap: bool | None = None


#: WHAT ONE FIELD OF THE PROPOSAL IS WORTH, and the first value is not a failure. A field the look left alone
#: is the commonest outcome and the cheapest thing to know: it says the look is not what decides that field, so
#: a look that went missing would cost nothing there. Pooling it into a per-job "the look changed something"
#: boolean is what this whole block exists to stop.
#:
#:   changed_nothing               the two compositions proposed the same value. Informative, not empty.
#:   look_agreed_with_the_customer the look moved the field TO what the customer then chose, and the
#:                                 composition without it proposed something else. The look earned its cost on
#:                                 this field, on this part, adjudicated by a human who was not asked about the
#:                                 look.
#:   look_disagreed_with_the_customer
#:                                 the look moved the field AWAY from what the customer chose. The bare
#:                                 measurement was right and the look cost the customer a correction.
#:   both_disagreed_with_the_customer
#:                                 the field moved and the customer chose a third thing. It is counted apart
#:                                 because it is evidence about the FIELD and not about the look.
#:   look_closer_to_delivered / look_further_from_delivered / equally_far_from_delivered
#:                                 a forecast field, adjudicated by the cells the builder actually delivered.
#:                                 The only adjudicator on this platform that no model and no default can move.
#:   changed_unadjudicated         the field moved and nothing settled it: no customer LABEL for that field and
#:                                 no delivered mesh to price it against. It is a change of unknown sign and is
#:                                 never counted as the look helping.
#:   not_comparable                the with-the-look recomposition did not reproduce the stored row, so this
#:                                 job's deltas are about two code versions and not about the look.
DELTA_VERDICTS: tuple[str, ...] = (
    "changed_nothing", "look_agreed_with_the_customer", "look_disagreed_with_the_customer",
    "both_disagreed_with_the_customer", "look_closer_to_delivered", "look_further_from_delivered",
    "equally_far_from_delivered", "changed_unadjudicated", "not_comparable")

#: The delta verdicts that say the look was RIGHT or WRONG about a field, as opposed to silent or unjudged.
#: A rate over anything else is a rate over changes of unknown sign.
DELTA_ADJUDICATED: frozenset[str] = frozenset({
    "look_agreed_with_the_customer", "look_disagreed_with_the_customer",
    "look_closer_to_delivered", "look_further_from_delivered"})

#: WHAT THE LOOK'S GUESS AT ONE MOUTH'S ROLE IS WORTH. Five of the six are not evidence about the part, and the
#: two that are name the customer in as many words, because `openings_seen[].likely_role` is the field
#: `vision/trust.py` tiers `recorded` - "it abstains on six of every seven declared mouths, and where it does
#: guess it is right 48 percent of the time, which is a coin flip". A score against the role the job RAN with
#: is a score against this platform's own pick on every job where nobody chose, and scoring that as agreement
#: is the same defect as counting a delegation as a confirmation. So the two populations are never pooled and
#: the name of each verdict says which one it is in.
ROLE_VERDICTS: tuple[str, ...] = (
    "no_claim", "agreed_with_the_customer", "disagreed_with_the_customer",
    "agreed_with_our_own_pick", "disagreed_with_our_own_pick", "nothing_settled")

#: The two role verdicts that are ground truth about a mouth.
ROLE_LABEL_VERDICTS: frozenset[str] = frozenset({"agreed_with_the_customer", "disagreed_with_the_customer"})


#: WHAT THE LOOK'S READING OF THE WHOLE PART IS WORTH, one value a job. Six of them, because the four things
#: that are not agreement are four different things and collapsing any two of them produces a number that lies.
#:
#:   agreed                    the document names the representation the look was taken with, the job settled
#:                             on a representation, and they are the same one.
#:   disagreed                 `reconcile.monitor.the_letters_say_the_representation_is_wrong` fires on the
#:                             stored document. It is the ONE reading in this project measured against a
#:                             held-out ground truth (25 of 25 with no false alarm on four draws,
#:                             `tests/test_chain_reconcile.py`), and it is re-run here rather than restated.
#:   settled_against_the_look  two NAMED representations and they differ, with the letters silent about it.
#:                             This was published as `no_comparable_claim` - the words "nothing to compare"
#:                             over two claims that plainly compare, which is worse than silence.
#:   no_claim_at_the_look      the measurement document records the representation as `unknown`, so the look
#:                             was taken with no representation claim at all. An ABSENT reading is a third
#:                             state: it is not agreement and it is not disagreement, and the one thing it
#:                             must be impossible to do is collapse it into either. `unknown` matching
#:                             `unknown` scored `agreed` on a bare string equality, on 10 of 124 records in
#:                             the batch of 2026-09-26.
#:   nothing_settled           the look named a representation and the job never settled one.
#:   no_comparable_claim       step 4 could not be re-run at all: no impression, no representation on the
#:                             document, no pair, or the run raised. `reconcile_why_not` says which.
REPRESENTATION_VERDICTS: tuple[str, ...] = (
    "agreed", "disagreed", "settled_against_the_look", "no_claim_at_the_look", "nothing_settled",
    "no_comparable_claim")

#: The three verdicts where two NAMED representations were actually put beside each other. Any rate about the
#: look's reading of the part takes its denominator from here and from nowhere else: the other three say that
#: one side or the other never spoke, and a rate that counts them is a rate over silence.
REPRESENTATION_COMPARED: frozenset[str] = frozenset({"agreed", "disagreed", "settled_against_the_look"})

#: The document's words for "nobody named a representation". `unknown` is what `hexera.report_measured` writes
#: when nothing has been settled and what `reconcile.inventory` and `reconcile.profile` both already treat as
#: the absence of one (`profile.NO_PASSAGE_REPRESENTATIONS`, `inventory` line 276). It is a sentinel and never
#: a claim, so it can neither agree nor disagree with anything - including with itself.
NO_REPRESENTATION_CLAIM: frozenset[str] = frozenset({"", "unknown", "none", "null", "unset"})

#: The look's own role words against the survey's role options, and it is a translation and not an opinion.
#: `vision/prompt.ROLES` is ("inlet", "outlet", "not a port", "unsure") and the role question's options are
#: ("inlet", "outlet", "wall", "closed for this run"): "not a port" and "wall" are the same claim in two
#: vocabularies, and without this map every mouth the look correctly called not-a-port would be scored a
#: disagreement with a customer who said "wall". "unsure" is NOT in the map: it is an abstention, which is the
#: product of that field and not a value it can be wrong about.
LOOK_ROLE_WORDS: dict[str, str] = {"inlet": "inlet", "outlet": "outlet", "not a port": "wall"}
#: What the look says when it declines to guess. `openings_seen[].likely_role` absent counts the same way.
LOOK_ROLE_ABSTENTIONS: frozenset[str] = frozenset({"unsure", "", "none", "unknown"})


class ProposalDelta(BaseModel):
    """One field of the proposal, with the look and without it, and what settled it.

    `field` is the SURVEYOR's own spelling and is the same string on both sides of the export: the exporter
    reads `ask.record`'s `targets[].field` for a per-place row, so `openings[o5].role` here and
    `AnswerOutcome.field` for the same mouth join without a translation table.
    """
    field: str
    with_look: str | None = None
    without_look: str | None = None
    changed: bool = False
    verdict: str = "changed_nothing"
    why: str = ""
    #: what the customer said about this field, when a LABEL row exists for it, and the label's own verdict
    customer: str | None = None
    customer_verdict: str | None = None
    #: the cells the builder delivered, on a forecast field adjudicated by the mesh
    delivered: int | None = None


class LookCounterfactual(BaseModel):
    """What the same survey would have proposed from the measurement ALONE, field by field.

    THIS IS THE ANSWER TO "DOES THE LOOK IMPROVE THE PIPELINE" WITHOUT AN A/B. The measurement runs on every
    upload and the look rides on the same document, so the platform can recompose the survey with the look
    taken out and store what that composition proposed beside what the real one did
    (`meshpipeline.application.learning_export.without_the_look`). Both halves are recomposed in one process
    under one build, so a difference between two agent builds cannot be counted as the look's work, and
    `replay_faithful` is the separate check that the with-the-look half reproduces the row that was actually
    stored. When it does not, every delta on the job is `not_comparable` and no rate is computed from it.

    `computed` False carries `why_not` and an EMPTY field list, which is why no rate here is ever taken over
    `len(fields)`: the denominators are the counters, and a job that could not be recomputed adds nothing to
    them rather than adding agreement.
    """
    computed: bool = False
    why_not: str | None = None
    look_status: str | None = None
    #: True, False, or None when the stored row carried no field the replay could be checked on. None is not
    #: faithful: a check that cannot fail is not a check.
    replay_faithful: bool | None = None
    replay_checked: int = 0
    replay_mismatch: list[dict[str, Any]] = Field(default_factory=list)
    #: R2: the build that recomposed, the build the job was measured under, and whether they are the same.
    recomposed_under: dict[str, Any] = Field(default_factory=dict)
    job_measured_under: dict[str, Any] = Field(default_factory=dict)
    same_build_as_the_job: bool | None = None
    seconds: float | None = None
    fields_compared: int = 0
    fields_changed: int = 0
    verdicts: dict[str, int] = Field(default_factory=dict)
    deltas: list[ProposalDelta] = Field(default_factory=list)


class SeenRole(BaseModel):
    """The look's guess at ONE mouth's role, beside the role that mouth settled on.

    n rows a part, on the signal that decides boundary conditions, where `LookAgreement.looks_like` is one row
    a part on the representation. Every row says who settled the role it is scored against, so an agreement
    with the customer and an agreement with this platform's own default are never one number.
    """
    opening: str
    look_said: str | None = None
    #: the look's word translated into the survey's role vocabulary (`LOOK_ROLE_WORDS`), None on an abstention
    look_role: str | None = None
    abstained: bool = True
    settled: str | None = None
    #: customer | operator | defaulted | skipped | delegated | unanswered | proposed
    settled_by: str = "unanswered"
    verdict: str = "no_claim"
    why: str = ""


class LookAgreement(BaseModel):
    """The look's reading against the representation the job settled on, read by the package's own monitor.

    `representation_verdict` is one of `REPRESENTATION_VERDICTS`, which that constant's table spells out. Two
    of its six exist because this block used to publish them as something else:

      - `disagreed` was UNREACHABLE. The verdict was decided by testing a signal NAME against a set built from
        `Alert.kind`, which holds the signal's class and not its name, so no input could reach it. Fixed by
        reading `Alert.signal`, which `alert_signals` now carries beside the classes.
      - `agreed` was a bare string equality, so the document's `unknown` matching a settled `unknown` scored
        agreement: two absences read as two readings that concur. 10 of the 124 records in the batch of
        2026-09-26 were that. An absent reading is a third state (`no_claim_at_the_look`).

    Any rate over these takes its denominator from `REPRESENTATION_COMPARED` and never from the row count:
    three of the six verdicts say one side never spoke.

    `readers` and `contradictions` travel together for the reason `Joint.readers` exists: a channel with no
    reader finds no disagreement, and the number it produces is indistinguishable from the two sources
    agreeing. On the platform's path the stance reader and the axial profile are always absent.
    """
    status: str | None = None
    model: str | None = None
    provider: str | None = None
    seconds: float | None = None
    confidence: str | None = None
    looks_like: str | None = None
    representation_at_look: str | None = None
    settled_representation: str | None = None
    reconcile_ran: bool = False
    reconcile_why_not: str | None = None
    contradictions: int | None = None
    readers: dict[str, bool] = Field(default_factory=dict)
    #: THE SIGNAL NAMES, and they are the field the verdict below is decided from. `Alert.signal` is what
    #: fired; `Alert.kind` is its CLASS (`contradiction`, `gap`, `impossibility`) and there are four of those
    #: over thirty-odd signals. This block read `.kind` and compared it to a signal NAME, so
    #: `representation_verdict` could not be `disagreed` on any input at all: over the 124-record batch of
    #: 2026-09-26 the comparison saw `{'contradiction', 'impossibility'}` and never a signal name.
    alert_signals: list[str] = Field(default_factory=list)
    #: the CLASSES that fired, kept because the operator table is organised by them. Never compared to a name.
    alert_kinds: list[str] = Field(default_factory=list)
    #: one of `REPRESENTATION_VERDICTS`
    representation_verdict: str = "no_comparable_claim"
    #: why it is that and not another, in words, so a row that compared nothing says which side was silent.
    #: A verdict with no sentence beside it is how `no_comparable_claim` came to mean four different things.
    representation_why: str | None = None
    #: THE PER-OPENING HALF, and it is n data points a part where `representation_verdict` is one.
    #: `looks_like` is scored against the settled representation above: one field, one part, and on a part
    #: whose representation the document records as `unknown` it is `no_claim_at_the_look`, so a batch of
    #: those measures the look on nothing - 80 of the 124 records of 2026-09-26 were that. `openings_seen[].likely_role` is the look's guess at every mouth it can
    #: see, on the signal that decides the boundary conditions, and it was never scored. These rows score it,
    #: against the roles the CUSTOMER confirmed where there are any and against this platform's own pick
    #: otherwise - never pooled, because the second is not evidence about the part.
    openings: list[SeenRole] = Field(default_factory=list)
    #: `{ROLE_VERDICTS value: rows}`, so every rate below carries its own denominator (R1)
    role_verdicts: dict[str, int] = Field(default_factory=dict)
    #: mouths the look was shown and DID guess a role for, against the mouths it was shown at all. The
    #: abstention is the product of this field (`vision/trust.py`), so the two numbers travel together.
    role_claims: int = 0
    role_abstentions: int = 0
    #: the ids the look named, against the ids the measurement found. `seen_recall` is None when the
    #: measurement found no opening, because a recall over nought mouths is not 1.0.
    seen_ids: list[str] = Field(default_factory=list)
    measured_ids: int = 0
    seen_recall: float | None = None
    #: entries the look reported with no measured id: the one thing here no measurement can supply
    unlabelled_seen: int = 0


class PlatformBlock(BaseModel):
    """What a finished job on the real platform says, beyond the record's other blocks.

    Every stamp the protocol needs to place a number is here (docs/eval_protocol.md, section 7 and R2): the
    platform sha, the agent sha the measurement was taken under, the facts schema version, the survey row's
    state schema and the planner's model and provider. A record without them cannot be compared to anything
    and is not published as a comparison.
    """
    export_schema: str | None = None
    job_id: str = ""
    session_id: str | None = None
    status: str = ""
    outcome_code: str | None = None
    failure_category: str | None = None
    failed_gate: str | None = None
    attempts: int | None = None
    attempts_max: int | None = None
    review_execution: str | None = None
    engine: str | None = None
    purpose: str | None = None
    fidelity: str | None = None
    created_at: str | None = None
    ended_at: str | None = None
    stage: str | None = None
    survey_state_schema: str | None = None
    step_status: str | None = None
    step_exit: str | None = None
    step_rounds: int | None = None
    step_model: str | None = None
    step_provider: str | None = None
    platform_sha: str | None = None
    agent_git_sha: str | None = None
    facts_schema_version: int | None = None
    measurement_revision: int | None = None
    brief: str | None = None
    brief_sha: str | None = None
    #: how many of this job's stored answers rest on a standing delegation rather than a choice
    delegated_answers: int = 0
    forecast: Forecast = Field(default_factory=Forecast)
    look: LookAgreement = Field(default_factory=LookAgreement)
    #: v3. What this survey would have proposed with no look, field by field. Never None: a job on which it
    #: could not be computed carries `computed: False` and the reason, which is a different fact from a job
    #: where the look changed nothing.
    counterfactual: LookCounterfactual = Field(default_factory=LookCounterfactual)
    #: the quality gate's own measured numbers, `{key: {measured, ok_when, passed, gating}}`, copied from the
    #: delivered payload and never recomputed here
    quality_criteria: dict[str, Any] = Field(default_factory=dict)


class OutcomeRecord(BaseModel):
    schema_version: int = OUTCOME_SCHEMA_VERSION
    job_key: str
    source: Source
    split: Split = "unassigned"
    split_sha256: str | None = None
    ingested: str = Field(default_factory=lambda: datetime.now(UTC).isoformat(timespec="seconds"))
    geometry: Geometry
    agent: AgentBlock = Field(default_factory=AgentBlock)
    builder: BuilderBlock = Field(default_factory=BuilderBlock)
    reviewer: ReviewerBlock = Field(default_factory=ReviewerBlock)
    labels: Labels = Field(default_factory=Labels)
    intake: IntakeBlock = Field(default_factory=IntakeBlock)
    #: v2. One row per place per survey question; empty on every source but `platform` today.
    answers: list[AnswerOutcome] = Field(default_factory=list)
    #: v2. Present only on a `platform` record; None says this record is not about a real job.
    platform: PlatformBlock | None = None

    @property
    def file_stem(self) -> str:
        return f"{self.geometry.facts_sha256[:12]}__{self.geometry.case}"


def job_key(source: str, case: str, facts_sha256: str, job_id: str | None = None) -> str:
    """One key per job: the source, the case, the measurement's identity, and the platform job when there is one
    (a harness rerun of a case is a new job; a second ingest of the same export is the same job)."""
    key = f"{source}/{facts_sha256[:12]}__{case}"
    return f"{key}@{job_id}" if job_id else key


INTAKE_TOPICS = (
    ("seed", ("seed",)),
    ("unit", ("unit", "millimet", "millimeter", " mm ", "inches")),
    ("port", ("inlet", "outlet", "port", "opening", "diameter", "plane")),
    ("engine", ("engine", "snappyhexmesh", "gmsh", "cfmesh", "select")),
)


def intake_topic(question: str) -> str:
    """The topic docs/corpus_export.md counts intake re-asks under: seed, unit, port, engine, other."""
    q = f" {question.lower()} "
    for topic, words in INTAKE_TOPICS:
        if any(w in q for w in words):
            return topic
    return "other"


def assign_split(record: OutcomeRecord, split_file: Any, locked_shas: set[str] | None = None) -> Split:
    """The record's side, and the rule that gave it (written into the record).

    0. Source platform is the platform side, whatever else is true of the geometry. See below.
    1. A geometry sha, a group or a case already on the locked list is locked, whatever the source.
    2. Sources blind and dose are never learning: they keep their own name.
    3. Otherwise the split file's side for the case name.
    4. Unassigned when the split does not know the case.

    WHY RULE 0 COMES BEFORE RULE 1, WHICH LOOKS LIKE A HOLE IN THE LOCKED SET AND IS NOT. Rule 1 exists so a
    re-export or a harness rerun of a locked case cannot leak into calibration. A platform record cannot leak
    into calibration by a different route: nothing that calibrates reads the platform side. The calibration
    tables, the feature bank, the sweeps, the post-mortem's two ledgers and the rule cards all select records
    through `store.record_paths(side="learning"|"locked")`, which matches a case name against the split file's
    two lists, and a platform case name (`platform__<stem>`) is on neither. Platform records are also written
    to their own directory, `eval/outcomes_platform/`, which those readers never open. So a platform record of
    a locked part is read by the platform report and by nothing else, and `tests/test_learn_isolation.py` holds
    that.

    The reverse question - whether a real customer's answer could move the locked half's answer key - is
    answered the same way: the key is `expected.json` in the corpus, this record never touches it, and a
    threshold moved on a platform finding still has to be proved on the learning half before it may be shipped
    (docs/learning_loop.md section 10, the kill criterion).
    """
    from geometry_agent.learn.store import locked_groups, read_split, split_side
    split = read_split(split_file) if not isinstance(split_file, dict) else split_file
    locked_cases = set(split.get("locked", []))
    g = record.geometry
    if record.source == "platform":
        side: Split = "platform"
    elif g.case in locked_cases or (g.group and g.group in locked_groups(split)) or (locked_shas and g.sha256 in locked_shas):
        side = "locked"
    elif record.source in ("blind", "dose"):
        side = record.source  # type: ignore[assignment]
    else:
        side = split_side(g.case, split) or "unassigned"  # type: ignore[assignment]
    record.split = side
    record.split_sha256 = split.get("sha256")
    return side
