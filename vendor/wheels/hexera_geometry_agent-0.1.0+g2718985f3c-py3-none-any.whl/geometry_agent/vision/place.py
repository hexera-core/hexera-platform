"""THE JOIN: a look finding tied to the place the MEASUREMENT put it at.

THE PROBLEM THIS SOLVES, and it is why six of the fifteen impression fields had no consumer. A reconciler joins
on a subject and a consumer addresses a place. Six of the fifteen fields are lists of phrases with no subject at
all: `internal_features`, `sharp_edges`, `attachments`, `thin_parts`, `defects`, `cannot_tell`. There is nothing
in "a baffle across the passage" to join on and nothing in it for a builder to go to. `openings_seen` is the one
field that carries a subject, and it is the one field that survives into every channel this project has built.

THE RECORD SHAPE DOES NOT HAVE TO CHANGE, and that is the finding of this module rather than a convenience. Two
of the fifteen fields already carry a subject and it is one the measurement issued, not one the model invented:

  `marks_seen`   one answer per violet letter. `render.station_marks` chose the places, `render.STATION_COLS`
                 laid them out and `render._place_in_world` put every letter back into world coordinates before
                 the model was ever shown the picture. The letter is the join key and the renderer holds the
                 point.
  `stops_seen`   one answer per panel, in panel order, and panel order IS `terminus.find_stops`'s own output
                 order. Each panel is an opening the detector called a stop, so the answer inherits an opening
                 id and therefore that opening's measured centroid.

So the subject was there the whole time. What was missing is a channel that reads it. Asking the model to write
a place into each phrase would cost a prompt change, a full re-run of the corpus and a new blind spot in a
prompt this project has already measured to be fragile (`internals`, which told the model in words what the
measurement knew, fell from 61 of 72 to 48 at p = 0.001). Reading the place off the measurement costs nothing
and cannot be wrong about where the letter was: the renderer drew it there.

WHAT THIS REFUSES RATHER THAN GUESSES, which is the house rule and is pinned by tests.

  A letter the renderer has no record of drawing gets NO row. The reconciler already calls that a
  contradiction; inventing a place for it would be the failure mode this rule exists for.
  A part whose unit nobody has confirmed gets rows with `where_m: null` and a `where_missing` token saying so.
  Never a number in a field labelled metres.
  A mark answer with no world point in the manifest gets `where_m: null` and NO cut number. The finding is
  delivered and it is not placed. Records written before the renderer exported the point are the whole of
  this case, which on the cached corpus is every letter.
  A reply with more or fewer stop answers than panels gets NO passage-end row. Answers join panels by
  position alone, so after a skipped panel every answer would sit at the wrong opening's coordinate.

WHY THE CUT NUMBER IS NOT A PLACE, found when this module met the measurement's own profile in one tree. The
branch that wrote this module kept `at_cut` as "a place ordinally, cut 3 of 6 along the flow axis". Three things
stop it being one, and all three are the measurement's own numbers, deterministic, one draw of `combo_sa`:

  the axis is not in the document   the strip cuts across `render.flow_axis`, the line through the labelled
                                    mouths. No key of the stored document or the typed block carries it
  its sign is arbitrary             it is an SVD vector, and on 78 of 322 parts it points the negative way
                                    along its own main component, so cut 1 is at the high end of the box
  it is not the flow on 123 parts   `reconcile.profile.axis_trust` refuses that same axis on 123 of 322
                                    (elbows, tees, volutes: a mouth faces more than 50 degrees off it), and
                                    791 of the 2,039 letters a draw sit on those parts

and the cuts are not evenly spaced (`render.choose_stations` picks them by Douglas-Peucker), so even with the
axis a cut number is not a fraction of anything. The profile refused the axis correctly and this module refused
the coordinate correctly, and between them the typed block still said "a place along the flow axis" on 123
parts where the measurement's own gate says there is no such axis. The number stays in the render manifest,
where the reconciler reads it against the picture it belongs to.
  `internal_features`, `sharp_edges`, `attachments`, `thin_parts`, `defects` and `cannot_tell` get no row at
  all. They have no subject, so there is no honest place to put them, and they travel as what they are: a list
  under a tier.

NO DIGIT THE MODEL WROTE REACHES A COORDINATE. `the_look_says` is the answer's own words with the subject
prefix taken off, and every digit was scrubbed before the model saw the picture. `where_m` is the renderer's or
the measurement's. The two never mix and `tests/test_vision_place.py` pins it.
"""
from __future__ import annotations

import re
from typing import Any

PLACE_SCHEMA = "geometry_agent.look_places.v1"

#: A leading subject on an answer: "A: ...", "(B) ...", "end 2: ...". Taken off so the words that follow are
#: the finding and the subject is a field. The model was asked to write the prefix, so a missing one is not an
#: error: `_body` then returns the whole answer.
_MARK_PREFIX = re.compile(r"^\s*\(?([A-Za-z])\)?\s*[:.)\-]\s+")
#: The panel captions are "end 1", "end 2", and the model is asked to begin each answer with the caption. The
#: digit is then removed by `prompt.scrub_numbers`, so what arrives is "end [n]: ...". Matching only a digit
#: here left the marker in the delivered sentence on every stop answer on the corpus, which is a scrub artefact
#: shown to a builder as if it were a word. Both spellings are matched, the scrubbed one because it is the only
#: one that survives storage.
_STOP_PREFIX = re.compile(r"^\s*end\s*\(?(\[n\]|[0-9]+)\)?\s*[:.)\-]\s*", re.IGNORECASE)

#: The words the prompt offers for "I could not read this panel or this letter". An abstention at a NAMED place
#: is a finding and is delivered as one: the look abstains on six of seven port roles and the abstention was
#: measured to be the product, so a channel that dropped it would drop the best-measured thing here.
_DECLINED = re.compile(r"cannot tell|can't tell|cannot be (determined|read)|not (legible|readable)|unclear|"
                       r"too (small|faint)", re.IGNORECASE)


def _body(answer: str, pattern: re.Pattern[str]) -> str:
    return pattern.sub("", str(answer or "")).strip()


def _letter_of(answer: str) -> str:
    m = _MARK_PREFIX.match(str(answer or ""))
    return m.group(1).upper() if m else ""


def _metres(point: Any, scale_to_metres: float | None) -> list[float] | None:
    """A point in the file's own numbers, in metres, or None. THE ONE CONVERSION here, and it is the same rule
    `hexera.planner_block` uses: no scale means no length, never a length in the wrong unit."""
    if scale_to_metres is None or not isinstance(point, (list, tuple)) or len(point) != 3:
        return None
    try:
        return [float(x) * float(scale_to_metres) for x in point]
    except (TypeError, ValueError):
        return None


NO_SCALE = "the unit of this file has not been confirmed, so no coordinate can honestly be given in metres"
NO_POINT = ("this run's render manifest has the letter but not the point it was drawn at, so this finding is "
            "delivered without a place")
NO_OPENINGS = "the measured opening table was not available to this caller"

#: A ROW CARRIES A TOKEN AND THE BLOCK CARRIES THE LEGEND ONCE, which is a character decision with a number
#: behind it. Written into every row, the two sentences saying where a coordinate came from and why one is
#: missing ran to about 200 characters a row on six to eight rows a part: 1,260 characters of a planner prompt
#: spent restating the same two facts. They are also read as prose by anything that walks the document for
#: claims, so the repetition arrived at the metric as well as at the model.
WHERE_FROM = {
    "renderer": "render.station_marks: the point the renderer drew this letter at, before the model saw it",
    "terminus": "vision.terminus.find_stops: the point the panel the model read was centred on",
    "opening_centroid": "the measured centroid of the opening this panel was drawn for",
}
WHERE_MISSING = {"no_scale": NO_SCALE, "no_point": NO_POINT, "no_openings": NO_OPENINGS}


def marked_places(impression: dict[str, Any] | None, marks: Any,
                  scale_to_metres: float | None = None) -> list[dict[str, Any]]:
    """One row per violet letter the look answered, at the point the renderer drew it.

    `marks` is the render manifest's own record, `[{"id": "A", "cut": 1, "kind": "void", "point": [...]}]`.
    `kind` is how the place was FOUND and never reaches a model: `render.station_marks` is explicit that nothing
    downstream tells the model what kind of place a letter is, and a row that handed the kind on would undo
    that. It decides nothing here either; it is not in the output.
    """
    imp = impression if isinstance(impression, dict) else {}
    answers = [str(a) for a in (imp.get("marks_seen") or []) if str(a).strip()]
    if not answers:
        return []
    drawn: dict[str, dict[str, Any]] = {}
    for row in marks or []:
        if isinstance(row, dict) and str(row.get("id") or "").strip():
            drawn[str(row["id"]).strip().upper()] = row
    out: list[dict[str, Any]] = []
    for answer in answers:
        letter = _letter_of(answer)
        place = drawn.get(letter)
        if not letter or place is None:
            # the renderer has no record of drawing this letter, so there is no place to put the finding at.
            # `reconcile.inventory.mark_material_vs_kind` already records it as a contradiction; this channel
            # says nothing rather than inventing a location for it
            continue
        where = _metres(place.get("point"), scale_to_metres)
        row: dict[str, Any] = {
            "at": letter,
            "kind": "marked_place",
            "the_look_says": _body(answer, _MARK_PREFIX),
            "declined": bool(_DECLINED.search(answer)),
            "where_m": where,
            "where_from": "renderer",
        }
        if where is None:
            row["where_from"] = ""
            row["where_missing"] = "no_scale" if place.get("point") is not None else "no_point"
        out.append(row)
    return out


def passage_ends(impression: dict[str, Any] | None, stopped: Any, openings: Any = None,
                 scale_to_metres: float | None = None) -> list[dict[str, Any]]:
    """One row per stops panel the look answered, at the measured opening the panel was drawn for.

    `stopped` is the render manifest's list of opening ids the terminus detector called stops, IN PANEL ORDER,
    which is the order `terminus.find_stops` returned them and the order the panels are captioned. That
    ordering is the whole join and `reconcile.inventory.stop_panel_vs_detector` already reads it the same way.

    `openings` is the measured opening table (`hexera.report_measured(...)["openings"]`), used only for
    `centroid_m`, which is already in metres. A stop whose opening is not in the table keeps its id and gets no
    coordinate.

    A merged stop carries the ids of every face it merged, joined by `+` (`terminus.find_stops`). The first id
    that resolves is the one the coordinate comes from, and `at` keeps the whole name so nothing is hidden.
    """
    imp = impression if isinstance(impression, dict) else {}
    answers = [str(a) for a in (imp.get("stops_seen") or []) if str(a).strip()]
    # two spellings, because two things write this. The render manifest's `stop_places` carries the detector's
    # own point per stop; its older `stopped` carries the ids alone and every cached run has only that
    rows_in = [x for x in (stopped or []) if x]
    ids = [str(x.get("id") if isinstance(x, dict) else x) for x in rows_in]
    points = [x.get("point") if isinstance(x, dict) else None for x in rows_in]
    ids = [i for i in ids if i.strip()]
    if not answers or not ids:
        # answers with no panel is the look inventing a view; panels with no answer is the look skipping one.
        # Both are the reconciler's business and neither is a place
        return []
    if len(answers) != len(ids):
        # THE JOIN IS BY POSITION AND POSITION IS ALL THERE IS: the caption's number is scrubbed to "end [n]"
        # before storage, so nothing in an answer says which panel it read. With one answer too few or too many
        # the answers after the gap sit at the wrong opening, each with that opening's measured coordinate, and
        # a place that is wrong is worse than no place. It never happens on the corpus (32 of 32 parts match on
        # all four draws), which is why nothing measured caught it; the reconciler still counts the mismatch.
        return []
    centroids: dict[str, Any] = {}
    for row in openings or []:
        if isinstance(row, dict) and row.get("id"):
            centroids[str(row["id"])] = row.get("centroid_m")
    out: list[dict[str, Any]] = []
    for i, oid in enumerate(ids):
        if i >= len(answers):
            break
        answer = answers[i]
        # the detector's own point first, because it is where the PANEL was centred and therefore what the
        # model was looking at; the opening's centroid second, because a cached run has no detector point
        where = _metres(points[i], scale_to_metres)
        where_from = "terminus"
        if where is None:
            where = next((centroids[p] for p in oid.split("+") if centroids.get(p) is not None), None)
            where_from = "opening_centroid"
        row: dict[str, Any] = {
            "at": oid,
            "kind": "passage_end",
            "the_look_says": _body(answer, _STOP_PREFIX),
            "declined": bool(_DECLINED.search(answer)),
            "where_m": list(where) if isinstance(where, (list, tuple)) else None,
            "where_from": where_from,
        }
        if row["where_m"] is None:
            row["where_from"] = ""
            row["where_missing"] = "no_scale" if openings else "no_openings"
        out.append(row)
    return out


def places(impression: dict[str, Any] | None, marks: Any = None, stopped: Any = None,
           openings: Any = None, scale_to_metres: float | None = None) -> list[dict[str, Any]]:
    """Every look finding that has a measured place, passage ends first.

    Ends first because a passage that stops is the thing the measurement half of this pipeline could never say
    (driver 5 of the round-five coverage table reads 0 of 322 on both arms) and there are at most four of them,
    while the letters run to six or eight a part.
    """
    return (passage_ends(impression, stopped, openings, scale_to_metres)
            + marked_places(impression, marks, scale_to_metres))


def legend(rows: list[dict[str, Any]] | None) -> dict[str, str]:
    """The sentences behind the tokens these rows actually use, and no others.

    Only the ones in use, because an unused entry is a sentence in a planner prompt explaining a case that did
    not arise. On the corpus this is two entries; on a live run with a known unit it is one."""
    used = {str(r.get(k) or "") for r in (rows or []) if isinstance(r, dict) for k in ("where_from",
                                                                                      "where_missing")}
    out = {k: v for k, v in WHERE_FROM.items() if k in used}
    out.update({k: v for k, v in WHERE_MISSING.items() if k in used})
    return out


__all__ = ["NO_OPENINGS", "NO_POINT", "NO_SCALE", "PLACE_SCHEMA", "WHERE_FROM", "WHERE_MISSING", "legend",
           "marked_places", "passage_ends", "places"]
