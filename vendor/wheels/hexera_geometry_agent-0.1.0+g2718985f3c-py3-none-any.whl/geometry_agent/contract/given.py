"""What the geometry agent is GIVEN, and what it is allowed to decide.

REHAAN'S RULE, and it is the architectural one: the geometry agent decides what to DO, where to spend the
cells. It must NOT re-decide what the geometry IS. The Surveyor's measurements arrive as authoritative facts,
not as suggestions to be re-derived, or the two drift and there are two answers to one question with no way to
choose.

A rule like that does not survive as advice. This file makes it structural in three ways.

  1. `Given` is FROZEN and has no setter for a fact. The agent holds marks it can read and cannot replace. A
     `Given` is built once, from a survey and an intake handoff, and after that nothing can write a fact into
     it: there is no method that does.
  2. The two field lists are DISJOINT and a test asserts it. `FACT_FIELDS` is what only an instrument, a person
     or the eyes can supply, and `DECISION_FIELDS` is the agent's whole vocabulary. A field in both would be
     the drift itself, expressed as a table.
  3. `check_plan` reads a plan and refuses one that states a fact. Not "recomputes it within five percent":
     states it at all. A plan that repeats a bore is a second spelling of a number that already has one place
     to live, and the check does not care whether the second spelling agrees.

WHERE IT COULD RE-DERIVE TODAY, found by reading the tree at 2ddbadbb and listed so the fix is checkable rather
than asserted. `RE_DERIVATION_SITES` below is the machine-readable form; each entry names a file, what the agent
gets to decide there that the measurement already decided, and what closes it.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from geometry_agent.contract import marks as mk
from geometry_agent.contract.intake import IntakeHandoff, LateIntakeHandoff, binds_late, binds_to
from geometry_agent.contract.marks import ContractError, Mark
from geometry_agent.contract.survey import SurveyHandoff

GIVEN_SCHEMA = "geometry_agent.contract.given.v1"

#: A field whose value can only come from an instrument, a person or the eyes: never from a brief and never
#: from a default. Those are the ones a plan restating them is unambiguously wrong about, because there is no
#: reading under which the plan is the source.
#:
#: `unit` is deliberately NOT here. Its row admits `stated` and `assumed`, so a plan naming a unit is not
#: automatically wrong, it is wrong when it names a DIFFERENT one from the resolved value, and `check_plan`
#: has a dedicated check that says which and why. This set is the blunt rule and that check is the sharp one.
#:
#: Note what this set is not: "the fields an agent may not set". The agent is not one of the five kinds at all,
#: so there is no field it may set. `DECISION_FIELDS` is its whole vocabulary.
#:
#: `representation` is here although its row admits `stated` and `assumed` since the fluid-side question
#: (`catalog.side_reading`): those two kinds are the brief and a default settling which side of the surface is the
#: fluid, and a plan is still never the source of what the part is.
FACT_FIELDS: frozenset[str] = frozenset(
    f for f, row in mk.OWNERS.items() if set(row) <= {mk.MEASURED, mk.CONFIRMED, mk.SEEN}) | {"representation"}

#: Fields that belong to a SUBJECT rather than to the part, and so have no single value to resolve to.
PER_SUBJECT_FIELDS: frozenset[str] = frozenset({"opening.role", "opening.bore_m", "opening.tilt_deg",
                                                "opening.centroid_m", "opening.normal", "opening.shape",
                                                "opening.kind", "opening.min_dimension_m",
                                                "opening.mouth_standoff"})

#: What the agent is FOR. Where to spend the cells, and nothing about what the part is. These names are the
#: agent's own vocabulary, not the builder's controls: the agent says "resolve this place at this size" and the
#: builder decides which of its keys delivers that.
DECISION_FIELDS: frozenset[str] = frozenset({
    "where_to_refine", "refinement_size_m", "layer_count", "layer_growth", "fidelity_tier",
    "cells_to_spend", "which_places_matter", "what_to_ask_about", "risk_to_raise", "order_of_work",
})

#: Read at 2ddbadbb. Each is a place the agent's own output can answer a question the measurement already
#: answered, with no reconciliation between the two.
RE_DERIVATION_SITES: tuple[dict[str, str], ...] = (
    {
        "where": "agent/hexera.py:representation_of",
        "what": "the plan's own `mesh_plan.regions[].role == 'wall_shell'` returns `wall_shell` BEFORE "
                "`catalog.representation` is consulted, so one region role the model wrote decides the "
                "representation for everything downstream: the corpus calibration table, the cell correction, "
                "the strategy and the planner block all key off it. It also rewrites `unknown` to "
                "`fluid_domain`, which the survey never measured",
        "closed_by": "`check_plan` refuses a plan whose region roles imply a representation the survey did not "
                     "measure, and `Given.representation` is the only value a caller should pass on",
        "on_the_chain": "CLOSED. The loop sends back a plan whose region roles imply another representation "
                        "(agent/loop.py ChainGiven), and the builder is handed the survey's representation "
                        "explicitly (`hexera.builder_plan_block(representation=...)`), so `representation_of` is "
                        "never consulted on the chain path. `chain.job.builder_representation_differs` counts how "
                        "often it would have handed the builder something else. hexera.handover() still calls "
                        "it: NEEDS FROM OTHERS",
    },
    {
        "where": "agent/hexera.py:representation_of vs report_measured",
        "what": "`report_measured` calls `catalog.representation(facts, purpose, brief, declared=declared)` "
                "and `representation_of` calls `catalog.representation(facts, purpose, brief)` with no "
                "`declared`. Same question, two call sites, two argument lists, and nothing compares the "
                "answers. MEASURED AND IT HAS NEVER FIRED: over 132 corpus parts, 6 per family, the two "
                "argument lists agree 132 times (eval/contract/measure_drift.py). It is a latent hazard, not "
                "an active bug, and saying so is better than implying it is load-bearing",
        "closed_by": "one mark, resolved once, read by both",
        "on_the_chain": "CLOSED on the chain path: the survey resolves the representation once, with the brief "
                        "and the port rows, and the loop refuses to start when its own context reads the part "
                        "differently (`agent/loop.py:given_mismatch`), which covers the fifteen places tools.py "
                        "and grounding.py recompute it from the context",
    },
    {
        "where": "agent/tools.py:estimate_cells",
        "what": "with `refinement_regions` the tool hands the model `refined` from "
                "`tools.refined_cell_estimate`, whose median is 1.86x the delivered cells and whose max is "
                "576x. The envelope the block ships is `estimate_builder_cells`, so the model reasons against "
                "one number and the builder is told another",
        "closed_by": "`forecast.cells_high` is a FACT field: a plan may not state a cell count, and "
                     "`check_plan` refuses one that does",
        "on_the_chain": "PARTLY. The trade and the builder's envelope come from `estimate_builder_cells` alone "
                        "(ask/trade.py, tested with `refined_cell_estimate` made to raise). But the CHECKER writes "
                        "`mesh_plan.cell_estimate_refined` into every plan (grounding._normalise; 187,414,362 on "
                        "bend_elbow_001 against an envelope of 689,900) and raises its own cell_cap question from "
                        "it (R36), so the refused number cannot be a plan gate: `CHECKER_WRITTEN`. NEEDS FROM "
                        "OTHERS: tools.estimate_cells and grounding R36 on estimate_builder_cells",
    },
    {
        "where": "agent/schema.py:UnitCall.assumed",
        "what": "the model writes the unit every size in the plan is in. The unit is contested between the "
                "file, the brief and the customer, and `OWNERS['unit']` already says who wins",
        "closed_by": "`Given.unit` resolves the row once; a plan that names a different unit is refused",
        "on_the_chain": "CLOSED: the loop sends back a plan whose unit differs from the resolved one",
    },
    {
        "where": "agent/schema.py:Patch.role and ObjectIdentity",
        "what": "the model assigns an opening's role and names the part. A role is `confirmed` or unknown, and "
                "a name from the picture alone is capped at 0.6",
        "closed_by": "`check_plan` refuses a role that contradicts a confirmation or the customer's own port "
                     "list, and an identity over the cap; a role nobody spoke about is the agent's flow-patch "
                     "decision (design of record, step 5), reported by `unconfirmed_roles`",
        "on_the_chain": "CLOSED: the loop sends back a contradicting plan, and the builder handoff's "
                        "`flow_patches` names who every role came from and refuses one that overrides a person",
    },
)


@dataclass(frozen=True)
class Given:
    """The survey's facts and the customer's confirmations, resolved once, frozen.

    There is no setter. `facts()` returns marks and `resolve` picks the winner by authority, so a consumer that
    wants the unit asks for the unit and gets one answer with its kind attached.

    ROLES HAVE THREE SOURCES AND THEY ARE KEPT APART. `role_of` is a CONFIRMATION and nothing else: a person
    answered. `stated_roles` is the customer's own port list bound to a measured mouth at the second intake's
    first cut (`ask.settle.declaration_settles`): their words, nobody asked. `assumed_roles` is a default that
    stood because the customer skipped the question: our guess, and it teaches nothing. The builder is told all
    three, labelled; the ledger learns from the first alone.
    """

    survey: SurveyHandoff
    intake: IntakeHandoff | None = None
    #: The third intake, when one fired. Its answers resolve like the second's, by authority.
    late: LateIntakeHandoff | None = None
    stated_roles: dict[str, str] = field(default_factory=dict)
    assumed_roles: dict[str, str] = field(default_factory=dict)
    #: PART-LEVEL fields the customer's own brief settled, `{field: value}`: the unit above all. `stated_roles` is
    #: this for a mouth's role and this is the same thing for a field the part has one of.
    stated_facts: dict[str, Any] = field(default_factory=dict)
    _resolved: dict[str, Mark] = field(default_factory=dict, repr=False)

    @staticmethod
    def of(survey: SurveyHandoff, intake: IntakeHandoff | None = None, *, late: LateIntakeHandoff | None = None,
           stated_roles: dict[str, str] | None = None, assumed_roles: dict[str, str] | None = None,
           stated_facts: dict[str, Any] | None = None) -> Given:
        """`stated_facts` is what the BRIEF settled at intake's first cut, `{field: value}`.

        A question the brief answered is held rather than asked (`ask.settle.brief_settles`) and becomes a
        `Stated` resolution, which is a ledger row and not a claim anybody downstream reads. These are the same
        answers as marks, so the value the customer wrote is the value the geometry agent and the builder get:
        `marks.resolve` already ranks a brief above the file's own reading and below a confirmation, which is the
        order `OWNERS` is written in, and nothing here has to restate that order.

        A field whose row does not admit `stated` is refused here and loudly. Intake has no business turning a
        brief phrase into a measurement, and a silent drop would be the answer written and never read again.
        """
        if intake is not None:
            binds_to(intake, survey)
        if late is not None:
            binds_late(late, survey)
        brief_marks: list[Mark] = []
        for name, value in (stated_facts or {}).items():
            if mk.STATED not in mk.OWNERS.get(name, ()):
                raise ContractError("given.stated", f"the brief cannot state {name!r}: its row admits "
                                                    f"{mk.OWNERS.get(name, ())} and not {mk.STATED!r}", field=name)
            brief_marks.append(mk.stated(name, value, "the customer's brief, read by ask.settle.brief_settles",
                                         why="a question the customer's own words answered is not asked again, "
                                             "and the answer is carried rather than dropped"))
        marks = (list(survey.marks) + (intake.marks() if intake is not None else [])
                 + (late.marks() if late is not None else []) + brief_marks)
        resolved: dict[str, Mark] = {}
        for name in {m.field for m in marks}:
            if name in PER_SUBJECT_FIELDS:
                # A part has one representation and one unit, and four mouths with four roles. Folding a
                # per-subject field into the flat table would hand a caller ONE arbitrary role for the part,
                # which is a wrong answer that looks like a right one. `role_of(opening_id)` is the accessor.
                continue
            winner = mk.resolve(marks, name)
            if winner is not None:
                resolved[name] = winner
        return Given(survey=survey, intake=intake, late=late, stated_roles=dict(stated_roles or {}),
                     assumed_roles=dict(assumed_roles or {}), stated_facts=dict(stated_facts or {}),
                     _resolved=resolved)

    def fact(self, name: str) -> Mark | None:
        """The winning mark on a field, or None. Reading is the only thing a caller can do."""
        if name in self._resolved:
            return self._resolved[name]
        return None

    def value(self, name: str, default: Any = None) -> Any:
        m = self.fact(name)
        return default if m is None else m.value

    def must(self, name: str) -> Mark:
        """The mark, or a loud failure. For a consumer that cannot proceed without it."""
        m = self.fact(name)
        if m is None:
            raise ContractError("given", f"{name!r} has no owner that spoke. It is owned by "
                                         f"{mk.OWNERS.get(name, ('nobody',))}; ask, do not assume", field=name)
        return m

    @property
    def representation(self) -> str:
        return str(self.must("representation").value)

    @property
    def unit(self) -> str:
        return str(self.must("unit").value)

    @property
    def forecast_cells(self) -> int:
        return int(self.must("forecast.cells_high").value)

    @property
    def budget(self) -> int | None:
        m = self.fact("cell_budget")
        return None if m is None else int(m.value)

    def role_of(self, opening_id: str) -> Mark | None:
        """The confirmed role of one mouth, or None. None is a real answer and means nobody has said."""
        for handoff in (self.late, self.intake):
            if handoff is None:
                continue
            answer = handoff.answer_for("opening.role", opening_id)
            if answer is not None and answer.answered_by != "default_taken":
                return answer.as_mark()
        return None

    def role_source(self, opening_id: str) -> tuple[str, str] | None:
        """`(kind, role)` for one mouth: confirmed, then stated, then assumed. None when nobody said anything
        and no default stood, which is a mouth whose role nothing downstream is entitled to invent."""
        confirmed = self.role_of(opening_id)
        if confirmed is not None:
            return mk.CONFIRMED, str(confirmed.value)
        if opening_id in self.stated_roles:
            return mk.STATED, self.stated_roles[opening_id]
        if opening_id in self.assumed_roles:
            return mk.ASSUMED, self.assumed_roles[opening_id]
        return None

    def unanswered(self) -> list[str]:
        """Questions that were put and not settled. A consumer decides what to do about each; nothing here
        quietly fills one in."""
        return list(self.intake.unanswered) if self.intake is not None else [
            u.id for u in self.survey.uncertainties]

    def unsettled(self) -> list[str]:
        """Every uncertainty that changes the mesh and that no person has confirmed: asked and skipped, AND never
        asked. `unanswered` is only the first, and a question held below the budget reached the builder as
        nothing at all through it, which is the builder binding a guess with nobody told it was one."""
        confirmed_ids: set[str] = set()
        for handoff in (self.intake, self.late):
            if handoff is None:
                continue
            for a in handoff.answers:
                if a.answered_by != "default_taken":
                    confirmed_ids.add(a.question_id)
        return [u.id for u in self.survey.uncertainties
                if u.effect != "advisory" and u.id not in confirmed_ids]

    def fits_budget(self) -> bool | None:
        """Whether the measured envelope fits the budget, or None when no budget exists.

        None is the honest answer on a brief that states no budget, and it is not the same as True. A caller
        that treats None as "it fits" has invented a cap the customer never gave.
        """
        cap = self.budget
        return None if cap is None else self.forecast_cells <= cap


# ---------------------------------------------------------------------------------------------------------
# what a plan may and may not say
# ---------------------------------------------------------------------------------------------------------

#: A flow direction in a person's words, as a sign and an axis letter. ONE spelling, here, because two modules
#: read the same answer out of the same free text: `chain.job.flow_axis_of` off the resolutions and
#: `customer_flow_direction` off the mark. The sign is required and that is the whole point: "along x" is an
#: axis and not a direction, and `ask.settle` refuses the unsigned phrase for the same reason.
FLOW_DIRECTION_RE = re.compile(r"([+-])\s*([xyz])\b", re.I)

#: A plan key that names a fact field, so a plan restating a measurement is caught by name rather than by value.
PLAN_KEY_TO_FACT: dict[str, str] = {
    "representation": "representation",
    "unit": "unit",
    "cell_estimate": "forecast.cells_high",
    "cell_estimate_refined": "forecast.cells_high",
    "inlet_bore": "inlet_bore_m",
    "bore_diameter": "opening.bore_m",
    "thickness_min": "thickness.min_m",
    "bbox_extent": "bbox_extent_m",
}


#: The plan keys the CHECKER writes into every plan, whatever the model said (`grounding._normalise`;
#: `tools.py`'s list of fields computed in `_normalise`). A rule about what the plan STATES cannot be a gate on
#: a number the plan never chose: on `bend_elbow_001` the checker writes `cell_estimate_refined` 187,414,362
#: against an envelope of 689,900, and every plan carries one. The chain reports them (`cell_counts`) and makes
#: sure none of them reaches the budget question or the builder's cap; the fix is in `grounding.py`.
CHECKER_WRITTEN: tuple[str, ...] = ("cell_estimate", "cell_estimate_refined")


def _plan_flow_direction(plan: dict[str, Any]) -> str | None:
    """The direction this plan POSES, as `+x` and the rest, or None when it poses none.

    It is `flow.axis` snapped to its dominant axis and then flipped by `direction_sign`, which is exactly what
    `hexera._external_strategy` and `hexera._external_requirements` hand the builder as `flow_axis` and what
    `snappy_runner.py:311-335 domain_from_strategy` reads. Written out here rather than imported so the contract
    package stays free of the agent it constrains, and `0.9` is `hexera._snap_axis`'s own threshold: an axis that
    is not mostly one of the three poses no direction and is not compared to anything.
    """
    flow = plan.get("flow") if isinstance(plan.get("flow"), dict) else {}
    axis = flow.get("axis")
    if not isinstance(axis, (list, tuple)) or len(axis) != 3:
        return None
    try:
        xyz = [float(c) for c in axis]
    except (TypeError, ValueError):
        return None
    k = max(range(3), key=lambda i: abs(xyz[i]))
    if abs(xyz[k]) < 0.9:
        return None
    sign = "+" if xyz[k] > 0 else "-"
    if flow.get("direction_sign") is not None and float(flow["direction_sign"] or 0) < 0:
        sign = "-" if sign == "+" else "+"
    return sign + "xyz"[k]


def customer_flow_direction(given: Given) -> str | None:
    """The flow direction a person gave, as `+x`, or None. A confirmed answer or their own words; never a default.

    `flow_direction`'s row in `OWNERS` admits `confirmed` and `stated` and nothing else, so a mark on it is
    always a person. A brief that settles the flow question arrives here as a `stated` mark through
    `Given.of(stated_facts=...)`, and `check_plan` still takes an override because the CHAIN resolves the same
    answer out of its resolutions as well (`chain.job.flow_axis_of`, which also sees the third intake's rows),
    and the value the plan is checked against has to be the one the builder's block was built from. One value
    is compared, and the caller that holds the fullest view of it says which.
    """
    m = given.fact("flow_direction")
    if m is None:
        return None
    hit = FLOW_DIRECTION_RE.search(str(m.value or ""))
    return f"{hit.group(1)}{hit.group(2).lower()}" if hit else None


def check_plan(plan: dict[str, Any], given: Given, *, builder_representation: str | None = None,
               skip_keys: tuple[str, ...] = (), flow_direction: str | None = None) -> list[str]:
    """Violations of the rule, in words. Empty is a plan that decided what to do and nothing about what it is.

    Each check names a site in `RE_DERIVATION_SITES`:

      * a representation the plan implies that differs from the survey's mark, and, when the caller passes it,
        the representation the BUILDER would be handed for this plan (`hexera.representation_of`), which is
        where one region role the model wrote used to override the measurement;
      * a unit the plan names that differs from the resolved one;
      * a role the plan gives a mouth that CONTRADICTS what the customer confirmed or stated. A role on a mouth
        nobody spoke about is the agent's to decide, because the geometry agent decides the flow patches using
        the confirmations (the design of record, step 5); `unconfirmed_roles` reports every one so the builder
        is told which roles nobody confirmed;
      * a flow direction the plan poses that differs from the one a PERSON gave. `flow_direction` is a
        confirmed-or-stated field: nobody but the customer owns it, so a plan that poses the other way round is
        the same class of mistake as a plan that renames a confirmed role. `flow_direction` is the resolved
        value when the caller holds one the marks cannot (the brief's sentence is a `Stated` resolution), else
        the mark is read;
      * an identity over the vision-only cap with no support but the picture;
      * a mesh key that restates a measured number (`skip_keys` leaves out what the checker itself wrote).

    It reads a plain dict so it can run on a `GeometryPlan.model_dump()` without importing the plan schema,
    which keeps the contract package free of the agent it constrains.
    """
    out: list[str] = []
    mesh = plan.get("mesh_plan") if isinstance(plan.get("mesh_plan"), dict) else {}
    regions = mesh.get("regions") or []
    roles = {str(r.get("role")) for r in regions if isinstance(r, dict)}
    implied = "wall_shell" if "wall_shell" in roles else None
    implied_differs = bool(implied and implied != given.representation)
    if implied_differs:
        out.append(f"the plan's region roles imply representation {implied!r} and the survey measured "
                   f"{given.representation!r}: hexera.representation_of lets one region role the model wrote "
                   f"override catalog.representation, and then two answers exist to one question")
    builder_differs = builder_representation is not None and builder_representation != given.representation
    if builder_differs and not implied_differs:
        out.append(f"the builder would be handed representation {builder_representation!r} for this plan and the "
                   f"survey measured {given.representation!r}: the representation is the survey's, resolved once")
    unit = plan.get("unit")
    unit_mark = given.fact("unit")
    names_unit = isinstance(unit, dict) and bool(unit.get("assumed"))
    if names_unit and unit_mark is not None and str(unit["assumed"]) != str(unit_mark.value):
        out.append(f"the plan calls the unit {unit['assumed']!r} and the resolved unit is {unit_mark.value!r} "
                   f"({unit_mark.kind}, from {unit_mark.source}); the unit is contested between the file, the "
                   f"brief and the customer and OWNERS['unit'] already says who wins")
    for patch in (plan.get("patches") or []):
        if not isinstance(patch, dict):
            continue
        role, pid = str(patch.get("type") or patch.get("role") or ""), str(patch.get("id") or "")
        source = given.role_source(pid)
        if source is None or source[0] == mk.ASSUMED:
            continue
        kind, said = source
        if role != said:
            who = "the customer confirmed" if kind == mk.CONFIRMED else "the customer's own port list states"
            out.append(f"the plan calls {pid} {role!r} and {who} {said!r}: the agent decides what to do with a "
                       f"role, never which role a mouth has once a person has said")
    said_flow = flow_direction or customer_flow_direction(given)
    if said_flow:
        posed = _plan_flow_direction(plan)
        if posed is not None and posed != said_flow:
            out.append(f"the plan poses the flow along {posed!r} and a person gave {said_flow!r}: "
                       f"flow.axis times flow.direction_sign is what the builder is handed as flow_axis, and the "
                       f"direction is the customer's, owned by them alone (OWNERS['flow_direction'] admits "
                       f"confirmed and stated and no default)")
    obj = plan.get("object") if isinstance(plan.get("object"), dict) else {}
    evidence = " ".join(str(e) for e in (obj.get("evidence") or []))
    conf = obj.get("confidence")
    if isinstance(conf, (int, float)) and float(conf) > mk.IDENTITY_CONFIDENCE_MAX:
        supported = any(word in evidence.lower() for word in ("measur", "opening", "facts.", "declared",
                                                              "confirmed", "brief"))
        if not supported:
            out.append(f"the plan names the object at confidence {float(conf):.2f} with no support but the "
                       f"picture; the cap is {mk.IDENTITY_CONFIDENCE_MAX}")
    for key, fact in PLAN_KEY_TO_FACT.items():
        if key in skip_keys:
            continue
        if key in mesh and mesh[key] is not None and fact in FACT_FIELDS:
            out.append(f"mesh_plan.{key} restates {fact}, which is a fact the survey owns; a second spelling of "
                       f"a number is a second thing to keep in step")
    return out


def unconfirmed_roles(plan: dict[str, Any], given: Given) -> dict[str, dict[str, str]]:
    """Every flow role the plan gives a mouth nobody confirmed, with what the intake default was.

    Not a violation: deciding the flow patches is the geometry agent's job where nobody has spoken. It is what
    the builder must be told is an assumption, and what the ledger must never read as an answer.
    """
    out: dict[str, dict[str, str]] = {}
    for patch in (plan.get("patches") or []):
        if not isinstance(patch, dict):
            continue
        role, pid = str(patch.get("type") or patch.get("role") or ""), str(patch.get("id") or "")
        if role not in ("inlet", "outlet"):
            continue
        source = given.role_source(pid)
        if source is None or source[0] == mk.ASSUMED:
            out[pid] = {"role": role, "intake_default": source[1] if source else ""}
    return out


def cell_counts(plan: dict[str, Any]) -> dict[str, int]:
    """The cell counts a plan carries, which are NOT the envelope and reach neither the trade nor the cap."""
    mesh = plan.get("mesh_plan") if isinstance(plan.get("mesh_plan"), dict) else {}
    return {k: int(mesh[k]) for k in CHECKER_WRITTEN if isinstance(mesh.get(k), (int, float))}


def refuse_plan(plan: dict[str, Any], given: Given) -> None:
    """`check_plan`, raised. For a caller that wants the boundary to stop the run rather than log it."""
    problems = check_plan(plan, given)
    if problems:
        raise ContractError("given.plan", "the plan re-decides what the geometry is: " + "; ".join(problems))


__all__ = ["CHECKER_WRITTEN", "DECISION_FIELDS", "FACT_FIELDS", "FLOW_DIRECTION_RE", "GIVEN_SCHEMA", "Given",
           "PER_SUBJECT_FIELDS", "PLAN_KEY_TO_FACT", "RE_DERIVATION_SITES", "cell_counts", "check_plan",
           "customer_flow_direction", "refuse_plan",
           "unconfirmed_roles"]
