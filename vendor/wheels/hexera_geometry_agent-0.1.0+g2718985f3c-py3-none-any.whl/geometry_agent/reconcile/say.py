"""Turning a measured passage shape into words, and into statements in the shared topic space.

WHY A MEASUREMENT NEEDS WORDS AT ALL. The document that reaches the builder is read by a planner and by an
intake agent, and every ruler this project owns reads English: `vocab.accept` is a regex over a reply,
`document.prose_statements` is an extractor over any string in the document, and `truth.brief_atoms` reads the
brief with that same extractor. A measured fact that stays a float is invisible to all three. So the shape is
computed as a number and then said in one fixed sentence per shape, and the sentence goes into the document as
prose exactly as the look's does, so the same extractor reads both halves and the measurement gets no private
channel the look does not have.

THE RULE THIS FILE OBEYS, and it is the only thing keeping it honest: ONE SENTENCE PER SHAPE. The templates
below are the whole vocabulary. Nothing is said about a mouth whose march was unreadable, nothing is said
about a shape the measurement did not find, and there is no branch anywhere that consults a family, a brief,
a file name or a part count. A reader who wants to know whether these words were fitted to a scorer can read
all of them in one screen, which is the point of their being few.

WHAT IS NOT SAID, deliberately:

- A STRAIGHT run says nothing. `straight` is a real measured finding and saying it out loud would be the
  measurement writing "the passage is plain", which is the exact false statement this round exists to stop the
  look making. The measurement's silence there is not a gap, it is a refusal: a single mouth's run being
  straight for as far as it was followed is not evidence that nothing stands in the passage further in.
- An UNREADABLE run says nothing, and `why_not` is carried beside the words for a human, never as a claim.
- No number appears in any sentence. Not because the measurement lacks one, but because the document already
  carries the numbers in its typed tables and a number repeated in prose is the same statement twice.

TWO PHRASINGS, and the second one is an experiment on the RULER rather than on the geometry. `plain` says the
finding the way an engineer would write it in a note. `mouth_first` says the identical finding with the mouth
as the grammatical subject. They are the same measurement; `eval/vision/form.py` scores the diffuser row under
both, and the gap between them is how much of that row is about finding the cone and how much is about the
word order the accept pattern was written around.
"""
from __future__ import annotations

from typing import Any

#: The shapes `entry.MouthRun.kind` can carry that this file will speak for. `straight` and `unreadable` are
#: absent on purpose and their absence is argued in the module docstring.
SPOKEN_KINDS = ("widens", "narrows", "waist", "bulge")
#: The shapes `entry.MouthRun.beyond` can carry. Each is a second, separate finding about the same mouth: what
#: the passage does past the stretch the mouth itself opens into.
SPOKEN_BEYOND = ("notch", "step_up", "step_down")

#: What each shape is said in, per phrasing. `{o}` is the opening id and nothing else is ever substituted.
#:
#: THE WORDS ARE CHOSEN TO BE THE PLAINEST ENGLISH FOR THE MEASURED FACT, and then checked against
#: `meaning.CONCEPTS` so that what they say lands somewhere in the shared vocabulary rather than in `other`.
#: That check moved two of them and the moves are recorded here rather than quietly made:
#:   `notch` was "shuts down to a fraction of its size", which matches no atom in `meaning.CONCEPTS` at all,
#:            so the finding was true, in the document, and invisible to every metric. `restricted` is the
#:            same claim in a word the shared vocabulary has (`throat`).
#:   `bulge`  was "opens out and closes again", same problem, and `expands`/`contracts` is the same claim in
#:            words the vocabulary has (`taper`).
#: Changing a word so a real finding is legible is not the same as changing a word so a scorer fires, and the
#: difference is checkable: both replacements are ordinary synonyms of what was already written, and neither
#: was chosen after seeing a score.
TEMPLATES: dict[str, dict[str, str]] = {
    "plain": {
        "widens": "the bore at {o} widens steadily inward from the mouth",
        "narrows": "the bore at {o} narrows steadily inward from the mouth",
        "waist": "the bore at {o} narrows to a waist and opens out again further in",
        "bulge": "the bore at {o} expands and contracts again further in",
        "notch": "further in from {o} the passage is restricted to a fraction of its bore and opens out again",
        "step_up": "further in from {o} the passage opens abruptly into a larger space",
        "step_down": "further in from {o} the passage drops abruptly to a smaller section",
    },
    "mouth_first": {
        "widens": "the mouth at {o} widens inward, toward the body of the part",
        "narrows": "the mouth at {o} narrows inward, toward the body of the part",
        "waist": "the passage in from the mouth at {o} narrows to a waist and opens out again further in",
        "bulge": "the passage in from the mouth at {o} expands and contracts again further in",
        "notch": "further in from the mouth at {o} the passage is restricted to a fraction of its bore "
                 "and opens out again",
        "step_up": "further in from the mouth at {o} the passage opens abruptly into a larger space",
        "step_down": "further in from the mouth at {o} the passage drops abruptly to a smaller section",
    },
}

#: The whole-part shape, said about the part rather than about a mouth. The axial channel speaks only when
#: `profile.restriction_verdict` and the axis gate let it, so there is no phrasing here for a refusal.
AXIAL_TEMPLATES: dict[str, str] = {
    "throat": "the passage narrows to a throat partway along and opens out again beyond it",
    "taper_out": "the passage tapers open along its length",
    "taper_in": "the passage tapers down along its length",
}

#: Where each shape lands in `document.TOPICS`, stated here as the AUTHOR'S intent rather than used as a
#: channel. `eval/vision/form.py` reads the sentences with `document.prose_statements`, the same extractor the
#: look is read with, and this table is what that reading is CHECKED against: a template whose words no longer
#: land where this says they do is a template that has drifted, and `tests/test_reconcile_say.py` fails on it.
#: Nothing in the pipeline consults this dict to make a statement.
EXPECTED_TOPICS: dict[str, tuple[tuple[str, str], ...]] = {
    "widens": (("form", "taper"),),
    "narrows": (("form", "taper"),),
    "waist": (("form", "taper"), ("form", "throat")),
    "bulge": (("form", "taper"),),
    "notch": (("form", "throat"),),
    "step_up": (("form", "step"),),
    "step_down": (("form", "step"),),
}


def mouth_lines(runs, phrasing: str = "plain") -> list[dict[str, Any]]:
    """One record per thing the measurement has to say about a mouth, in the order the mouths are measured.

    A record and not a bare string, because `document.walk_strings` joins a dict whose values name a place into
    one fragment about that place, which is how the look's own opening records are read. The measurement is
    handed to the reader in the same shape for the same reason.
    """
    table = TEMPLATES[phrasing]
    out: list[dict[str, Any]] = []
    for run in runs:
        oid = str(getattr(run, "opening_id", "") or "")
        if not oid:
            continue
        said = [table[k].format(o=oid) for k in (getattr(run, "kind", ""), getattr(run, "beyond", ""))
                if k in table]
        if said:
            out.append({"opening_id": oid, "passage": "; ".join(said)})
    return out


def axial_line(verdict: str, taper: dict | None) -> str | None:
    """What the whole-part axial channel has to say, or None when it is not entitled to speak."""
    if verdict == "restricted":
        return AXIAL_TEMPLATES["throat"]
    if verdict == "clear" and taper:
        return AXIAL_TEMPLATES["taper_out" if taper.get("opens_towards_end") else "taper_in"]
    return None


def block(runs, verdict: str = "unreadable", taper: dict | None = None,
          phrasing: str = "plain", representation: str = "") -> dict[str, Any] | None:
    """The whole measured-shape section of one document, or None when the measurement found nothing to say.

    None and not an empty section: a heading with nothing under it is characters the reader pays for and no
    statement, and the character rate this round reports would then charge the measurement for its own
    silence.

    THE REPRESENTATION GATE, and it is here because a hand check caught it saying otherwise. An external body
    has no passage: a wing, a bluff body, an Ahmed variant is a SOLID to mesh around, and its `openings` are
    faces of the bounding surface and not ways in. The per-mouth march will happily follow a plane across one
    of them and report that the section drops, and on `ahmed_variant_005` it did: "further in from o4 the
    passage drops abruptly to a smaller section", about a car body with no passage in it at all. The axial
    channel already refuses these through `profile.NO_PASSAGE_REPRESENTATIONS`; the per-mouth channel had no
    such rule, and it is the same rule.
    """
    from geometry_agent.reconcile.profile import NO_PASSAGE_REPRESENTATIONS
    if representation and representation in NO_PASSAGE_REPRESENTATIONS:
        return None
    mouths = mouth_lines(runs, phrasing)
    along = axial_line(verdict, taper)
    if not mouths and not along:
        return None
    out: dict[str, Any] = {}
    if along:
        out["along_the_flow"] = along
    if mouths:
        out["at_each_mouth"] = mouths
    return out
