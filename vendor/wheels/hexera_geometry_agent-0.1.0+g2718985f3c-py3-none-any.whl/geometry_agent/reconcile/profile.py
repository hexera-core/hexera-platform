"""THE AREA PROFILE, AND ITS ONE OWNER: the numbers along the flow axis and the refusal that says when they mean
nothing, in one place.

WHY ONE OWNER. `vision.render.station_frame` measures the cross-section at 41 stations along the flow axis to
decide where to cut, and five modules read a profile off that same axis (`inventory`, `joint`, `monitor`,
`verdict`, `walk`). Before this file owned it they held five opinions about when it meant anything: `inventory`'s
taper claim read only `usable`, so on an elbow it compared two oblique slices of one bore and called the ratio a
taper; `monitor` and `verdict` read `usable and axis_trusted`; `walk` imported a wider gate from `axis.py` that
nothing else used. Now:

    the numbers    `material_profile` is the one function that cuts the stations. `render.station_profile`
                   delegates to it, and `flow_profile` calls it, so the strip and every reader of the profile
                   are the same array by construction and not by a comment.
    the frame      `profile_frame` is the one place the axis, the screen frame, the probe scale and the stations
                   are worked out for a reader. It is `render.station_frame`'s own arithmetic, imported.
    the refusal    `trust` is the one gate. A profile is refused when the mouths do not FACE along the fitted
                   axis (`axis_trust`, the elbow) or do not LIE on it (`collinear`, the manifold and the wye),
                   and `FlowProfile` folds that refusal into `usable` at construction. Every reading method
                   (`dip`, `taper`, `narrowing`, `steps`) refuses on its own, so a consumer that forgets to
                   check cannot read a refused profile as a clear or straight one.

`reconcile/axis.py` used to hold the wider gate and was imported by nothing on the shipping path. Its code lives
here now, the checker (`walk.py`) and the eval scripts import it from here, and that module is deleted.

THE ONE THING THAT MAKES THIS HARDER THAN IT LOOKS, and it is the difference between a useful signal and a
sign error. `material_profile` returns how much MATERIAL each station cuts through. On a fluid domain the
material IS the fluid, so material area is flow area and a dip is a throat. On a wall shell the material is the
pipe wall, and the flow is the hole in the middle of it: a plug dropped into the bore makes the material area
go UP, and reading the material profile there would report a restriction as a widening and a widening as a
restriction. So the profile this file reads is chosen by the measured representation:

    fluid_domain, annular_fluid   flow area = material the cut passes through
    wall_shell                    flow area = the empty regions the material closes around
    external, unknown             there is no passage in the file; this file returns nothing and says so

`enclosed_regions` already separates those two for the lettered marks, on the same mask, and it is reused here
rather than rewritten so a mark and a profile station cannot disagree about what a void is.

WHAT THIS CANNOT DO, measured in `eval/vision/inventory.py` rather than asserted here:

- It is one profile along ONE axis. On a tee, a wye, a manifold or an elbow there is no single axis and the
  refusal says so; a restriction inside a branch is read by `entry.mouth_runs`, one curve per mouth, and by the
  centreline march in `facts/coverage.py`, which follows the bend.
- The probe is 72 px. A plate thinner than a station spacing can fall between two stations and a feature
  narrower than a pixel of the probe does not appear. The 41 stations are half a step in from each end, so the
  last 1/82 of the part at each end is never probed.
- On a wall shell, an enclosed void is only enclosed IN THAT PLANE. A bore that opens sideways out of the cut
  plane reads as open room and contributes nothing, so the flow area can read zero on a passage that is there.
- A sealed internal cavity that carries no flow is an enclosed void like any other and is counted as flow area.

Nothing here reads a brief, a family, a file name or an answer key. It is given a mesh and a representation.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

#: Representations whose material is the fluid: the cut's filled area is the flow area.
FLUID_REPRESENTATIONS = ("fluid_domain", "annular_fluid")
#: Representations whose material is the wall: the flow area is the void the material closes around.
WALL_REPRESENTATIONS = ("wall_shell",)
#: Representations with no passage in the file at all. The profile exists but means nothing about flow.
NO_PASSAGE_REPRESENTATIONS = ("external", "unknown")

#: A station whose flow area is below this fraction of the profile's own largest is a NARROWING.
#: This is NOT the restriction column and the difference cost a rewrite. Measured over the corpus, a plain
#: narrowing fires on 118 of the 151 parts whose brief names nothing in the passage: every straight reducer,
#: every transition, every mini housing. A reducer narrows for its whole length and nothing stands in it. A
#: number that calls a reducer obstructed is measuring "does the section change", which the look is not being
#: asked about and which cannot contradict a denial.
NARROWING_FRACTION = 0.65
#: THE RESTRICTION: how deep the passage narrows AND RECOVERS, as a fraction of the peak flow area. The
#: valley's prominence, not its depth and not its departure from a chord; `FlowProfile.dip` carries why both of
#: those failed and what they called obstructed. The level is an order of magnitude above `STATION_FLAT`
#: (0.02), which is where the renderer's own code stops believing a change of area at all, so it is taken from
#: the existing rule rather than fitted. The runner prints the whole corpus at 0.10, 0.20 and 0.30.
DIP_FRACTION = 0.20
#: A taper: the flow area at one end over the flow area at the other. A diffuser cone opens out, so its two
#: ends differ by more than this. Same treatment, same sensitivity table.
TAPER_RATIO = 1.60
#: Stations at each end that a restriction may not be found in. The first and last station sit half a step
#: inside the part, and on a fluid domain the end station of a bell mouth or a chamfered mouth is genuinely
#: smaller than the bore without anything standing in the passage.
END_GUARD = 2
#: Below this many stations carrying any flow at all, there is no profile to read and the answer is "nothing
#: to say" rather than "no restriction". A wall shell whose bore leaves the cut plane hits this.
MIN_LIVE_STATIONS = 8


# ---------------------------------------------------------------------------------------------------------------
# THE GATE. One test in two halves, and the only place either half is decided.
# ---------------------------------------------------------------------------------------------------------------
#: How far a mouth's normal may lie from the fitted flow axis before the single-axis profile stops meaning
#: anything. cos 50 degrees: a straight run's two mouths both face along the axis, an elbow's second mouth is
#: at ninety degrees to it, and a tee's branch is at ninety or forty-five. Set from the geometry of the failure
#: and not from a sweep: at any cutoff between 30 and 60 degrees the same families fall on the same side.
AXIS_COS = 0.643
#: How far off a straight line the mouths may sit before a SINGLE profile across them is a sum over more than
#: one passage. The test is the second singular value of the mouth points over the first, which is the width
#: of the mouth cloud over its length: zero for a straight run, 0.5 for a right-angled elbow, and about 0.3 or
#: more for every tee, wye and manifold in the corpus. 0.15 is below the elbow and well above the numerical
#: noise of three mouths on one line, and the families fall on the same side anywhere between 0.08 and 0.30.
#:
#: WHY NOT JUST COUNT THE MOUTHS. A straight run measured as a wall shell has FOUR openings, an outer ring and
#: an inner ring at each end, and they are all on the line; a wye has three and they are not. Counting would
#: refuse every wall shell in the corpus and pass the wye.
#:
#: WHAT IT COSTS, measured by `eval/vision/form.py axis` over 322 parts: the normals half refuses 151, and this
#: half refuses 20 more, every one of them `tee_wye`. A wye whose two branches both lean 25 degrees off the run
#: passes the normals test and its profile is the run and both branches summed at every station past the
#: take-off, which is not the area of any passage.
SPREAD = 0.15


@dataclass
class AxisVerdict:
    """Whether one fitted axis may be profiled along, and why not when it may not.

    `trusted` is the answer. `gate` names which test refused, so the cost of each can be counted separately:
    `normals` is the mouths facing off the axis, `spread` is the mouths lying off a line, and "" is a pass.
    """
    trusted: bool
    gate: str = ""
    note: str = ""
    #: The width of the mouth cloud over its length. Reported whether or not it refused.
    spread: float = 0.0


def axis_trust(axis: np.ndarray, mouth_normals: np.ndarray | None) -> tuple[bool, str]:
    """The NORMALS half of the gate: whether every mouth faces along the axis the profile is cut across.

    A mouth is where the passage meets the outside, so a mouth's normal is the passage's own direction at that
    end. When every mouth faces along the fitted axis the cuts are across the flow. When one does not, the cut
    plane leaves the bore somewhere in between, the flow area falls for a geometric reason and the profile
    reports a restriction that is not there. That is this measurement's largest single failure mode and it has
    a whole family behind it, so it is gated here rather than noted in a docstring."""
    if mouth_normals is None or len(mouth_normals) < 2:
        return True, ""
    n = np.asarray(mouth_normals, dtype=np.float64)
    norms = np.linalg.norm(n, axis=1)
    keep = norms > 0
    if keep.sum() < 2:
        return True, ""
    cos = np.abs((n[keep] / norms[keep, None]) @ np.asarray(axis, dtype=np.float64))
    off = int((cos < AXIS_COS).sum())
    if off:
        worst = float(np.degrees(np.arccos(np.clip(cos.min(), 0, 1))))
        return False, (f"{off} of {int(keep.sum())} mouths face more than "
                       f"{np.degrees(np.arccos(AXIS_COS)):.0f} degrees off the fitted flow axis "
                       f"(worst {worst:.0f}): the cuts are not across the flow")
    return True, ""


def collinear(points: np.ndarray | None) -> tuple[bool, float, str]:
    """The SPREAD half of the gate: `(are the mouths on one line, the spread, the reason they are not)`.

    Fewer than three mouths cannot be off a line: two points define one. That is not a loophole, it is the
    geometry, and an elbow with two mouths is caught by the NORMALS half instead.
    """
    if points is None or len(points) < 3:
        return True, 0.0, ""
    pts = np.asarray(points, dtype=np.float64)
    rel = pts - pts.mean(axis=0)
    try:
        s = np.linalg.svd(rel, compute_uv=False)
    except np.linalg.LinAlgError:
        return True, 0.0, ""
    if not len(s) or s[0] <= 0:
        return True, 0.0, ""
    spread = float(s[1] / s[0]) if len(s) > 1 else 0.0
    if spread <= SPREAD:
        return True, spread, ""
    return False, spread, (f"the {len(pts)} mouths are {spread:.2f} as wide as they are long, so no one line "
                           f"runs through them and a section across any line is a sum over more than one "
                           f"passage")


def trust(axis: np.ndarray, mouth_points: np.ndarray | None,
          mouth_normals: np.ndarray | None) -> AxisVerdict:
    """THE gate: the mouths must both FACE along the fitted axis and LIE on it.

    Order is deliberate. The normals test is checked first because it is the one with a measured failure behind
    it (the elbow) and because its note names an angle, which is the more useful thing to read in a refusal.
    """
    ok_normals, note = axis_trust(axis, mouth_normals)
    on_line, spread, line_note = collinear(mouth_points)
    if not ok_normals:
        return AxisVerdict(False, "normals", note, spread)
    if not on_line:
        return AxisVerdict(False, "spread", line_note, spread)
    return AxisVerdict(True, "", "", spread)


def degrees_off() -> float:
    """The angle `AXIS_COS` is, for a report that wants to print it rather than the cosine."""
    return float(np.degrees(np.arccos(AXIS_COS)))


# ---------------------------------------------------------------------------------------------------------------
# THE NUMBERS. One frame, one cut per station, one function that does it.
# ---------------------------------------------------------------------------------------------------------------

@dataclass
class ProfileFrame:
    """Where a profile is cut: the fitted axis, the screen frame across it, the part centre, the half extent
    that sets the probe scale, and the station points. `render.station_frame` works out the same numbers for
    the strip from the same functions; this is that arithmetic for a reader that has no strip."""
    axis: np.ndarray
    r: np.ndarray
    u: np.ndarray
    centre: np.ndarray
    half: float
    probes: list[np.ndarray]


def profile_frame(vertices: np.ndarray, mouth_points: np.ndarray | None = None) -> ProfileFrame | None:
    """The frame a profile of this part is cut in, or None when the part has no extent along its axis.

    Every choice is imported from `vision.render`: the same flow axis, the same screen frame, the same fill
    fraction and the same stations. A reader that chose its own would be measuring a different part from the
    one the model was shown."""
    from geometry_agent.vision.render import STATION_FILL, _panel_frame, flow_axis, station_points
    v = np.asarray(vertices, dtype=np.float64)
    if not len(v):
        return None
    bounds = np.array([v.min(axis=0), v.max(axis=0)])
    axis = flow_axis(bounds, mouth_points)
    r, u = _panel_frame(axis)
    centre = bounds.mean(axis=0)
    rel = v - centre
    half = max(float(np.ptp(rel @ r)), float(np.ptp(rel @ u))) / 2.0 / STATION_FILL or 1.0
    probes = station_points(v, axis)
    if not probes:
        return None
    return ProfileFrame(axis=axis, r=r, u=u, centre=centre, half=half, probes=probes)


def _station_masks(vertices: np.ndarray, faces: np.ndarray, axis: np.ndarray, r: np.ndarray, u: np.ndarray,
                   centre: np.ndarray, half: float, probes: list[np.ndarray], px: int):
    """The material each station cuts through, as a `px` square boolean image per station, one at a time."""
    from geometry_agent.vision.render import section_fill
    per = 2.0 * half / px
    a = np.stack([r / per, -u / per])
    b = np.array([px / 2.0, px / 2.0]) - a @ centre
    for p in probes:
        yield section_fill(vertices, faces, p, axis, a, b, px, px)


def material_profile(vertices: np.ndarray, faces: np.ndarray, axis: np.ndarray, r: np.ndarray, u: np.ndarray,
                     centre: np.ndarray, half: float, probes: list[np.ndarray], px: int | None = None) -> np.ndarray:
    """How much material each station cuts through, as a fraction of the probe square.

    THE one cut. `render.station_profile` is this function, so the array the strip chooses its cuts from and the
    array every reader of the profile reads are the same array. Coarse on purpose: the probe is only good enough
    to compare one station with the next."""
    from geometry_agent.vision.render import STATION_PROBE_PX
    px = int(px or STATION_PROBE_PX)
    return np.array([float(m.mean()) for m in _station_masks(np.asarray(vertices, dtype=np.float64),
                                                              np.asarray(faces), axis, r, u, centre, half,
                                                              probes, px)])


def station_areas(vertices: np.ndarray, faces: np.ndarray, frame: ProfileFrame, wall: bool,
                  px: int | None = None) -> tuple[np.ndarray, np.ndarray, list[int]]:
    """`(material, flow, passages)` per station, from ONE cut each. On a fluid domain material and flow are the
    same array; on a wall shell the flow is the void the material closes around (`void_area`). `passages` is how
    many separate flow regions each cut crosses (`facts.passages.count_passages`, on the same mask)."""
    from geometry_agent.facts.passages import count_passages
    from geometry_agent.vision.render import STATION_PROBE_PX
    px = int(px or STATION_PROBE_PX)
    material = np.zeros(len(frame.probes))
    flow = np.zeros(len(frame.probes))
    counts: list[int] = []
    masks = _station_masks(np.asarray(vertices, dtype=np.float64), np.asarray(faces), frame.axis, frame.r,
                           frame.u, frame.centre, frame.half, frame.probes, px)
    for i, mask in enumerate(masks):
        material[i] = float(mask.mean())
        flow[i] = void_area(mask) if wall else material[i]
        counts.append(count_passages(mask, material_is_flow=not wall))
    return material, flow, counts


# ---------------------------------------------------------------------------------------------------------------
# THE PROFILE AND ITS REFUSAL
# ---------------------------------------------------------------------------------------------------------------

@dataclass
class FlowProfile:
    """The flow area at each of the 41 stations, and what that says about the passage.

    `usable` is THE flag, and it is false whenever this file has nothing to offer: no passage in the
    representation, no mesh, too few live stations, OR an axis the gate refused. The axis refusal is folded in
    at construction (`__post_init__`), so a consumer that checks `usable` alone, as `inventory`'s taper claim
    did, can no longer read a refused profile. `refused_by` says which of those it was and `why_not` says it in
    words. Every reading method checks `readable`, which also looks at `axis_trusted`, so a profile whose axis
    is marked untrusted after construction refuses too."""
    representation: str
    #: What the cut passes through, station by station: the raw `material_profile` output. Material, always.
    material: np.ndarray = field(default_factory=lambda: np.zeros(0))
    #: The flow area, chosen by representation. On a fluid domain this is `material`.
    flow: np.ndarray = field(default_factory=lambda: np.zeros(0))
    usable: bool = False
    why_not: str = ""
    #: Positions along the axis, 0 at the first station and 1 at the last.
    t: np.ndarray = field(default_factory=lambda: np.zeros(0))
    #: Whether the passage actually runs along the axis the profile was cut across. False on an elbow, a tee,
    #: a wye, a volute, a manifold: there the profile is a picture of the cut plane leaving the bore, or of two
    #: passages summed, and not of the flow.
    axis_trusted: bool = True
    axis_note: str = ""
    #: Which refusal applies: "" when the profile is readable, else one of `representation`, `no_mesh`,
    #: `no_extent`, `few_live`, `normals`, `spread`, `axis`, `bores`, `passages`.
    refused_by: str = ""
    #: The gate's own reading, kept whether or not it refused.
    gate: str = ""
    spread: float = 0.0
    #: How many separate passages the cuts cross (`facts.passages.passage_count`), None when no station carries
    #: flow. More than one is a refusal: the profile is then the SUM of several passages, and a block with two
    #: parallel bores and one with three give byte-identical profiles.
    passages: int | None = None
    #: The most bores any ring used as a mouth has through it (`facts.schema.Opening.bore_count`), None when
    #: the caller did not say. More than one is a refusal for the same reason.
    bores: int | None = None

    def __post_init__(self) -> None:
        if not self.axis_trusted and self.usable:
            self.usable = False
            self.why_not = self.why_not or self.axis_note or "the passage does not run along the fitted axis"
            self.refused_by = self.refused_by or self.gate or "axis"
        from geometry_agent.facts import passages as _passages
        if self.usable and self.bores is not None and self.bores > 1:
            self.usable = False
            self.why_not = (f"a ring at a mouth has {self.bores} bores through it: the part has more than one "
                            "passage and a verdict about one cannot be read from their sum")
            self.refused_by = "bores"
        elif self.usable and _passages.refuses(self.passages):
            self.usable = False
            self.why_not = (f"the cuts cross {self.passages} separate passages: a verdict about one passage cannot "
                            "be read from their sum")
            self.refused_by = "passages"

    @property
    def readable(self) -> bool:
        """The one test every reading applies: numbers exist AND they are across the flow."""
        return bool(self.usable and self.axis_trusted)

    def refusal(self) -> str | None:
        """None when the profile may be read, else why it may not, in words."""
        if self.readable:
            return None
        return self.why_not or self.axis_note or "the profile could not be read"

    @property
    def live(self) -> np.ndarray:
        """The stations that carry any flow at all. A station of exact zero on a wall shell is the cut plane
        leaving the bore, not a blocked passage, and averaging it in would invent a restriction."""
        return self.flow > 0.0

    def peak(self) -> float:
        return float(self.flow.max()) if len(self.flow) else 0.0

    def interior(self) -> np.ndarray:
        """The stations a restriction may be found in: everything but `END_GUARD` at each end."""
        keep = np.zeros(len(self.flow), dtype=bool)
        if len(self.flow) > 2 * END_GUARD:
            keep[END_GUARD:len(self.flow) - END_GUARD] = True
        return keep & self.live

    def narrowing(self, fraction: float = NARROWING_FRACTION) -> dict | None:
        """The narrowest interior station, when it is narrow enough to be a feature.

        Kept and reported because it is the obvious reading of the profile and it is WRONG for the question
        this file is asked, and a reader who does not see the wrong answer beside the right one will write it
        again. It calls a straight reducer obstructed."""
        if not self.readable:
            return None
        inner = self.interior()
        if not inner.any():
            return None
        peak = self.peak()
        if peak <= 0:
            return None
        idx = int(np.argmin(np.where(inner, self.flow, np.inf)))
        value = float(self.flow[idx]) / peak
        if value >= fraction:
            return None
        return {"station": idx, "at": float(self.t[idx]), "open_fraction": value,
                "blocked": bool(self.flow[idx] <= 0.0)}

    def dip(self, fraction: float = DIP_FRACTION) -> dict | None:
        """THE RESTRICTION: the deepest place the passage narrows AND RECOVERS, as a fraction of the peak.

        This is the valley's prominence, which is the standard way to ask how much of a dip is a dip rather
        than a slope: for each interior station, the smaller of the highest flow area before it and the highest
        after it, less its own. Three readings, and the third is the one that took two rewrites to reach:

            narrowest station        calls a straight reducer obstructed. It narrows for its whole length.
            departure from the chord calls a concentric reducer obstructed. Its shoulder leaves the chord.
            prominence               a reducer never recovers, so its prominence is zero, and a venturi
                                     throat, an orifice plate and a tube bank all recover, so theirs is not.

        "Narrows and recovers" is also exactly what a denial denies. A passage that only gets smaller is still
        a passage the flow goes down; a passage that gets smaller and opens out again has something in it. The
        corpus agrees: at 0.20 this fires on 20 of 20 venturi and orifice runs and 0 of 25 straight reducers."""
        if not self.readable:
            return None
        live = np.flatnonzero(self.live)
        if len(live) < MIN_LIVE_STATIONS:
            return None
        peak = self.peak()
        if peak <= 0:
            return None
        lo, hi = int(live[0]), int(live[-1])
        inner = self.interior()
        inner[:lo + END_GUARD] = False
        inner[hi - END_GUARD + 1:] = False
        if not inner.any():
            return None
        before = np.maximum.accumulate(self.flow)
        after = np.maximum.accumulate(self.flow[::-1])[::-1]
        prominence = (np.minimum(before, after) - self.flow) / peak
        idx = int(np.argmax(np.where(inner, prominence, -np.inf)))
        depth = float(prominence[idx])
        if depth < fraction:
            return None
        return {"station": idx, "at": float(self.t[idx]), "depth": depth,
                "open_fraction": float(self.flow[idx]) / peak,
                "blocked": bool(self.flow[idx] <= 0.0)}

    def taper(self, ratio: float = TAPER_RATIO) -> dict | None:
        """A passage whose two ends are different sizes, and which way round. A diffuser opens out.

        Read off the ends rather than off a fit, because a cone and a step both change the ends and the brief
        calls both a change of section; telling those two apart is `restriction` and `steps` and not this.

        REFUSES ON A REFUSED AXIS, and this is the line that was missing. On a bend the fitted axis is the chord
        across it, so the end stations are oblique slices of the same bore and their areas differ for a
        geometric reason: this read `bend_elbow_021_fluid` at 9.78 to one on a pipe of constant section."""
        if not self.readable:
            return None
        live = np.flatnonzero(self.live)
        if len(live) < MIN_LIVE_STATIONS:
            return None
        a, b = float(self.flow[live[0]]), float(self.flow[live[-1]])
        if a <= 0 or b <= 0:
            return None
        big, small = (max(a, b), min(a, b))
        if big / small < ratio:
            return None
        return {"ratio": big / small, "opens_towards_end": bool(b > a),
                "start": a, "end": b}

    def steps(self, fraction: float = 0.25) -> int:
        """How many times the flow area changes by more than `fraction` of the peak between two neighbouring
        stations: a sudden widening, a shoulder, a plate. Counted, never located."""
        if not self.readable or len(self.flow) < 2:
            return 0
        peak = self.peak() or 1.0
        return int((np.abs(np.diff(self.flow)) > fraction * peak).sum())


def restriction_verdict(prof: FlowProfile, fraction: float = DIP_FRACTION) -> tuple[str, dict | None]:
    """Three answers, not two: `restricted`, `clear`, or `unreadable` with the reason.

    This is the function the headline column runs on, so it returns "unreadable" loudly. A reconciler that sees
    only restricted/clear will read every wall shell whose bore left the cut plane as a clear passage and will
    then contradict a look that was right.

    The axis gate is the second half of that honesty and it is not optional. The profile is cut perpendicular
    to ONE axis, fitted through the mouths. On an elbow the two mouths are at ninety degrees, the fitted axis
    is the chord across the bend, and the middle of the bore leaves the cut plane: the profile then dips in the
    middle of every elbow in the corpus with nothing in the passage at all. That dip is the measurement's own
    artefact and it is reported as unreadable rather than as a restriction."""
    if not prof.usable:
        return "unreadable", {"why": prof.why_not}
    if not prof.axis_trusted:
        return "unreadable", {"why": prof.axis_note or "the passage does not run along the fitted axis"}
    from geometry_agent.facts import passages as _passages
    if (prof.bores is not None and prof.bores > 1) or _passages.refuses(prof.passages):
        return "unreadable", {"why": prof.why_not or "more than one passage crosses the cut"}
    hit = prof.dip(fraction)
    if hit is not None:
        return "restricted", hit
    if int(prof.live.sum()) < MIN_LIVE_STATIONS:
        return "unreadable", {"why": f"only {int(prof.live.sum())} stations carry flow"}
    return "clear", None


#: What a lettered mark is standing on, per representation. The same sign question as the flow area and it has
#: the same answer, and getting it wrong cost this file a whole rewrite: read naively, `kind` reports 542
#: contradictions on one draw of the shipped arm and 444 of them are this table being absent.
#:
#: `render.enclosed_regions` is given a boolean image of MATERIAL and knows nothing about what the material is.
#:
#:   wall shell     material is the wall.  void = the bore (open).  body = something in the bore (SOLID).
#:                                         cut  = the deepest point of the wall itself (solid).
#:   fluid domain   material is the fluid. void = a hole in the fluid, which is a solid object the flow closes
#:                                         around (SOLID).  body = fluid inside that hole, which is the bore of
#:                                         a tube in a bundle or of a cyclone's vortex finder (open).
#:                                         cut  = the deepest point of the fluid (open).
#:
#: So on a fluid domain every one of the three flips, and the obstruction is the `void` and not the `body`.
#: A reconciler that reads `body` as "something in the way" is right on 161 wall shells and wrong on 98 fluid
#: domains, and the corpus's obstructed fluid domains are exactly the ones it would get wrong.
_MARK_IS_SOLID: dict[str, dict[str, bool]] = {
    "wall": {"void": False, "body": True, "cut": True},
    "fluid": {"void": True, "body": False, "cut": False},
}


def mark_is_solid(kind: str, representation: str) -> bool | None:
    """Whether a lettered mark is standing on solid material. None when the representation cannot say."""
    if representation in WALL_REPRESENTATIONS:
        return _MARK_IS_SOLID["wall"].get(kind)
    if representation in FLUID_REPRESENTATIONS:
        return _MARK_IS_SOLID["fluid"].get(kind)
    return None


def obstruction_marks(mark_places: list[dict], representation: str) -> list[dict]:
    """The marks that stand on a solid thing INSIDE the passage: the measurement's per-place obstruction.

    On a wall shell that is the `body` kind, material the bore closes around. On a fluid domain it is the
    `void` kind, a hole in the fluid. The `cut` kind is never one: it is the fallback the renderer uses when a
    cut nominated nothing at all, so it is a place and not a finding."""
    if representation not in WALL_REPRESENTATIONS + FLUID_REPRESENTATIONS:
        return []
    want = "body" if representation in WALL_REPRESENTATIONS else "void"
    return [p for p in mark_places if p.get("kind") == want]


def void_area(mask: np.ndarray) -> float:
    """The fraction of one cut that is empty space the material closes around.

    Reuses `render.enclosed_regions`, which is what the lettered marks are nominated from, so a letter drawn on
    a void and a station counted as flow area agree by construction."""
    from geometry_agent.vision.render import enclosed_regions
    if mask.size == 0:
        return 0.0
    return sum(r.area for r in enclosed_regions(mask) if r.kind == "void") / float(mask.size)


def flow_profile(vertices: np.ndarray, faces: np.ndarray, representation: str,
                 mouth_points: np.ndarray | None = None,
                 mouth_normals: np.ndarray | None = None, ring_bores: int | None = None) -> FlowProfile:
    """The 41-station flow-area profile for one part, in the renderer's own frame, with its refusal.

    The gate is `trust`, both halves. Before this file owned the refusal the profile carried the normals half
    only, so a wye whose branches lean less than fifty degrees off the run came back readable while `walk`,
    reading the same axis, refused it."""
    rep = representation or "unknown"
    if rep in NO_PASSAGE_REPRESENTATIONS:
        return FlowProfile(rep, why_not=f"{rep}: no passage in the file", refused_by="representation")
    v = np.asarray(vertices, dtype=np.float64)
    f = np.asarray(faces)
    if not len(v) or not len(f):
        return FlowProfile(rep, why_not="no mesh", refused_by="no_mesh")
    frame = profile_frame(v, mouth_points)
    if frame is None:
        return FlowProfile(rep, why_not="the part has no extent along its flow axis", refused_by="no_extent")
    from geometry_agent.facts.passages import passage_count
    material, flow, counts = station_areas(v, f, frame, wall=rep in WALL_REPRESENTATIONS)
    t = np.linspace(0.0, 1.0, len(frame.probes))
    verdict = trust(frame.axis, mouth_points, mouth_normals)
    live = int((flow > 0).sum())
    common = {"material": material, "flow": flow, "t": t, "axis_trusted": verdict.trusted,
              "axis_note": verdict.note, "gate": verdict.gate, "spread": verdict.spread,
              "passages": passage_count(counts), "bores": ring_bores}
    if live < MIN_LIVE_STATIONS:
        return FlowProfile(rep, usable=False, why_not=f"only {live} of {len(frame.probes)} stations carry flow",
                           refused_by="few_live", **common)
    return FlowProfile(rep, usable=True, **common)
