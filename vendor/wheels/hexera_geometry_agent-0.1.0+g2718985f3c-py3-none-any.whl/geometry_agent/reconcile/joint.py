"""THE JOINT PIPELINE: step 1 to step 5 in one call, with the four channels' worth of work in one object.

Six branches built six halves of this and none of them joined up. `inventory` says what the measurement is
entitled to say about each look field; `verdict` decides confirmed / suppressed / disputed / passed and recovers
the profile the renderer discards; `block` performs the surgery and writes the typed block; `entry` and `say`
measure the passage shape from each mouth and put it into words; `monitor` reads the reply for the signals that
need no answer key. This file runs them in the order the pipeline runs them and hands back ONE result.

WHAT THIS FILE PUTS DOWN THE TYPED CHANNEL, and it is still only measurements. `hexera.planner_block` is the
typed dict the platform reads out of `metrics["geometry_agent"]`. When this file was written it was
BYTE-IDENTICAL with the look and without it on 322 of 322 parts, and the round that followed closed that:
`planner_block` now composes its own `look` key from `vision.trust.for_model`, with the findings
`vision.place` could join to a measured place. That is the look's channel and it is owned there.

What THIS file adds to the same block is unchanged and is still measurement only: `measured_places` below, the
throat and the taper the profile sized, which contain no word the model wrote. A look statement carries no
coordinate of its own, because every digit is scrubbed before the model sees the picture, so anything located
here is located by the measurement.

THE ORDER IS REHAAN'S AND IS NOT NEGOTIATED HERE. measure, decide what to draw, look, reconcile, deliver. The
one thing this file adds is that the fourth step now has an output and the fifth step has somewhere to put it.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from geometry_agent.reconcile import block as rblock
from geometry_agent.reconcile import inventory as inv
from geometry_agent.reconcile import monitor as rmon
from geometry_agent.reconcile import say as rsay
from geometry_agent.reconcile import verdict as rv

JOINT_SCHEMA = "geometry_agent.joint.v1"

#: `supplies` reports where a throat or a taper is as a fraction of the flow axis, because that is the unit the
#: 41-station profile is computed in and converting it to metres here would invent a precision the station
#: spacing does not have. A consumer that wants metres multiplies by the bbox extent along the flow axis, which
#: is in the same document. The key says so in its name.
PLACE_KIND = {"change_of_section": "measured_taper", "narrowing": "measured_throat"}


@dataclass
class Joint:
    """One part, both sources, everything either of them is entitled to say."""
    case: str
    representation: str
    reconciliation: rv.Reconciliation
    #: the reply as it arrived, never modified
    raw: dict[str, Any] = field(default_factory=dict)
    #: the reply after the surgery `block.reconciled` performs
    reconciled: dict[str, Any] = field(default_factory=dict)
    #: `say.block(...)`: the measured passage shape, or None when the measurement found nothing to say
    shape: dict[str, Any] | None = None
    #: `monitor.run_signals(...)`: the quality signals that need no answer key
    report: Any = None

    @property
    def alerts(self) -> list[Any]:
        return list(getattr(self.report, "alerts", []) or [])

    @property
    def contradictions(self) -> int:
        return self.reconciliation.contradictions

    def typed_block(self, *, rationale: bool = False) -> dict[str, Any]:
        """The typed block step 5 carries, with the measured shape beside the reconciled look and not inside.

        `rationale=False` by default here and True in `block.block`, and the difference is deliberate: that
        function's caller is a developer reading a record, this one's is the document that leaves the agent.
        `block.disagreements` says what travelled into a customer document the one time it was not left out.
        """
        out = rblock.block(self.raw, self.reconciliation, rationale=rationale)
        out["schema"] = JOINT_SCHEMA
        out["measured_passage_shape"] = self.shape
        out["alerts"] = [{"signal": a.signal, "kind": a.kind, "subject": a.subject,
                          "says": a.says, "measured": a.measured} for a in self.alerts]
        return out

    def measured_places(self) -> list[dict[str, Any]]:
        """The recovered profile as PLACES, in the shape `hexera.planner_block` states a place in.

        Every one of these is a measurement. None of them is a builder setting, none predicts anything about
        the mesh, and none carries a word the model wrote: `said` is written by `verdict.supplies` from the
        array, and the array is `render.choose_stations`'s own.
        """
        out: list[dict[str, Any]] = []
        for s in self.reconciliation.supplied:
            kind = PLACE_KIND.get(str(s.get("what") or ""))
            if kind is None:
                continue
            sizes = dict(s.get("sizes") or {})
            out.append({
                "id": kind, "kind": kind, "what": str(s.get("said") or ""),
                "where_fraction_of_flow_axis": sizes.get("at_fraction_of_axis"),
                "measurement": sizes,
                "from": str(s.get("from") or ""),
            })
        return out


def run(m: inv.Measured, impression: dict[str, Any], *, stance: dict[str, Any] | None = None,
        says_solid: bool = False, segments: Any = None, runs: Any = None,
        taper: dict[str, Any] | None = None, phrasing: str = "plain",
        only: set[str] | None = None, costs: tuple[str, ...] = ("free", "measured", "profile"),
        not_asked: tuple[str, ...] = ()) -> Joint:
    """Steps 3 to 5 over one part: reconcile the reply against the measurement and deliver what survives.

    `m` is the measurement (`inventory.Measured`), `impression` the reply as it arrived. `stance` is
    `vision.stance.stance(impression)` and is INJECTED for the reason `verdict.reconcile` states: that question
    has a hand-checked answer against 151 replies read by eye and a second copy of it here would be a second
    blind spot with no hand check behind it. `runs` is `entry.mouth_runs(...)`, the per-mouth march, and is
    optional because it needs the mesh and the reconciliation does not.
    """
    st = stance or {"verdict": "silent", "named": [], "denied": []}
    look = inv.Look(case=m.case, impression=impression, stance=st, says_solid=says_solid, segments=segments,
                    not_asked=tuple(not_asked or ()))
    findings = [f for f in inv.run_claims(m, look) if only is None or f.claim in only]
    r = rv.reconcile(findings, m, impression, denied=st.get("denied") or [])
    shape = rsay.block(runs or [], verdict=_verdict_of(m), taper=taper if taper is not None else _taper_of(m),
                       phrasing=phrasing, representation=m.representation)
    report = rmon.run_signals(m, look, costs=costs)
    return Joint(case=m.case, representation=m.representation, reconciliation=r, raw=impression,
                 reconciled=rblock.reconciled(impression, r), shape=shape, report=report)


def _verdict_of(m: inv.Measured) -> str:
    """The axial channel's own word for this part, or `unreadable` when it is not entitled to speak."""
    if not m.profile.readable:
        return "unreadable"
    return "restricted" if m.profile.dip() else "clear"


def _taper_of(m: inv.Measured) -> dict[str, Any] | None:
    if not m.profile.readable:
        return None
    return m.profile.taper()


#: HOW MUCH OF STEP 4's OWN WORKING TRAVELS WITH THE DOCUMENT.
#:
#:   `full`     every key of the typed block, including `disagreements`, which QUOTES the suppressed sentence
#:   `counts`   the numbers, the question, the confirmed fields, the tiers, and the monitor's firings as
#:              signal ids with no quoted words
#:   `none`     nothing: the surgery happened and the document does not say so
#:
#: WHY THIS IS A SWITCH. `block.disagreements` quotes a suppressed claim in full on purpose, so that a person
#: reading the record can see what was taken out. That is right for a record and wrong for a document, and the
#: difference is measurable: `reconciled` removes "the passage is plain" from the look block and `full` writes
#: it back two keys later, where `document.walk_strings` reads it as prose and `truth.judge` charges it exactly
#: as it charged the original. The reconciler's whole measured win is 14, 6, 0 and 6 false statements a draw and
#: `full` hands most of it back. `counts` keeps the part of the record that is a number about the pair and drops
#: the part that is a re-assertion of what was removed. The quotes are not lost: `block.disagreements(r)` still
#: returns them for the arm that scores the reconciler and for anyone auditing a suppression.
RECORD_MODES = ("full", "counts", "none")
RECORD_DEFAULT = "counts"

#: The keys of the typed block that are about the PAIR rather than about the part: numbers, a question with a
#: default, the fields a consumer may now act on, and the tiers it branches on. None of them restates a claim.
RECORD_COUNTS_KEYS = ("schema", "counts", "contradictions", "confirmed", "question", "tiers", "readable")
RECORD_FULL_KEYS = (*RECORD_COUNTS_KEYS, "disagreements", "alerts")

#: WHAT A MONITOR FIRING MAY SAY IN A DOCUMENT, and it is three typed fields and no prose.
#:
#: `monitor.Alert` carries `says` and `measured`, which are the two sides in the words each side used, and
#: those are the same re-assertion `disagreements` is: quoted into a document they are read as the document's
#: own claims. `signal`, `kind` and `subject` are an id, an enum and a PLACE (an opening id or a mark letter),
#: and none of them is a sentence about the part.
#:
#: The firings have to travel at all because of what the monitor turned out to be for. `gd_monitor` measured
#: `representation_disagrees_with_the_marks` catching a WRONG REPRESENTATION on 25 of 25, with zero false
#: alarms, on four draws, using only the look's lettered answers and no answer key. A wrong representation
#: inverts every lettered mark at once, so it is the one thing in this pipeline a reader most needs told and
#: it is not a statement about the geometry at all. Dropping the alerts with the quotes would have thrown that
#: away to protect against a fault the quotes carry and the ids do not.
ALERT_FIELDS = ("signal", "kind", "subject")


def alert_rows(joint: Joint, quotes: bool = False) -> list[dict[str, Any]]:
    fields = (*ALERT_FIELDS, "says", "measured") if quotes else ALERT_FIELDS
    return [{f: getattr(a, f, "") for f in fields} for a in joint.alerts]


def record_block(joint: Joint, mode: str = RECORD_DEFAULT) -> dict[str, Any] | None:
    if mode not in RECORD_MODES:
        raise ValueError(f"record mode must be one of {RECORD_MODES}, not {mode!r}")
    if mode == "none":
        return None
    keys = RECORD_FULL_KEYS if mode == "full" else RECORD_COUNTS_KEYS
    out = {k: v for k, v in joint.typed_block().items() if k in keys}
    out["alerts"] = alert_rows(joint, quotes=(mode == "full"))
    return out


def document(facts: Any, joint: Joint, *, purpose: str = "internal_cfd", engine: str = "snappy",
             unit: str | None = None, brief: str | None = None, declared: Any = None,
             cell_cap: int | None = None, include_facts: bool = False,
             look_meta: dict[str, Any] | None = None, carry_look: bool = True,
             surgery: bool = True, shape: bool = True, places: bool = True,
             record: str = RECORD_DEFAULT) -> dict[str, Any]:
    """THE DOCUMENT THAT LEAVES THE AGENT: `report_measured` with the reconciled look and the measured shape.

    `carry_look=False` builds the same document with no look at all, which is the control arm every number in
    this round is quoted against. Nothing else differs between the two calls.

    The shape block and the recovered places are written into the MEASURED half, not into the look block. That
    is `gd_research/docs/joint_research.md`'s R2 and it is the whole reason they survive a budget the look does
    not: a measured place is ranked with the measurements and an impression is ranked last.

    `record` decides how much of step 4's own working travels with the document, and it is a switch rather than
    a constant because MEASURING IT CHANGED THE ANSWER. See `RECORD_MODES`.
    """
    from geometry_agent.agent import hexera
    meta = look_meta or {}
    look = None
    if carry_look:
        imp = joint.reconciled if surgery else joint.raw
        look = hexera.look_block(imp, model=str(meta.get("model") or ""),
                                 provider=str(meta.get("provider") or ""), seconds=meta.get("seconds"),
                                 views=list(meta.get("views") or []),
                                 # the renderer's own record of where it drew the letters and which openings
                                 # it drew a stops panel for. It rides with the look because `planner_block`
                                 # cannot place a finding at a letter without the table that says where the
                                 # letter is, and the two halves are useless apart
                                 drawn=meta.get("drawn") or None)
    doc = hexera.report_measured(facts, unit, brief, purpose=purpose, engine=engine, declared=declared,
                                 cell_cap=cell_cap, look=look, include_facts=include_facts)
    if shape:
        doc["measured_passage_shape"] = joint.shape
    if places:
        doc["measured_places"] = joint.measured_places()
    rec = record_block(joint, record)
    if rec is not None:
        doc["reconciliation"] = rec
    doc["planner_block"] = planner_block(doc)
    return doc


def planner_block(doc: dict[str, Any]) -> dict[str, Any] | None:
    """`hexera.planner_block`, with the contradiction count inside its look.

    The measured throat and taper (`doc["measured_places"]`) are NOT appended here any more: `hexera.planner_block`
    reads them itself and ranks them with every other place (work/z-deliver), so an append would list them twice,
    at the tail, behind the wall-side places they rank ahead of. `contradictions` rides in the look because it is
    the one quality number in this pipeline that survives a file nobody has seen, and a planner that gets a
    document with no answer key still gets to know how much the two sources disagreed about it.
    """
    from geometry_agent.agent import hexera
    base = hexera.planner_block(doc)
    if base is None:
        return None
    rec = doc.get("reconciliation")
    if isinstance(rec, dict) and isinstance(base.get("look"), dict):
        # INSIDE `look`, NOT BESIDE IT, and the reason is the boundary rather than taste.
        # `meshpipeline.engines.snappy.planner.GEOMETRY_AGENT_BLOCK_KEYS` is an ALLOWLIST of the keys the
        # planner will put in front of a model, and it names `status`, `places`, `look` and eleven others. A
        # new top-level key is not refused, it is silently dropped, so `look_contradictions` was composed on
        # every joint run and reached nothing. It is the one quality number in this pipeline that survives a
        # file nobody has seen, and a count of how far the two sources disagreed belongs with the source it is
        # about anyway.
        base = {**base, "look": {**base["look"], "contradictions": rec.get("contradictions"),
                                 "contradictions_read_as":
                                     "how many claims the measurement and the picture disagreed about on this "
                                     "part. It needs no answer key, so it is the one quality signal here that "
                                     "survives a file nobody has seen. High is a part to look at, not a part "
                                     "to refuse."}}
    return base


__all__ = ["ALERT_FIELDS", "JOINT_SCHEMA", "RECORD_DEFAULT", "RECORD_MODES", "Joint", "alert_rows",
           "document", "planner_block", "record_block", "run"]
