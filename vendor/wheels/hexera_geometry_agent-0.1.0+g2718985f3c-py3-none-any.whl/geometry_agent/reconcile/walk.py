"""The traversal: one answer per drawn cut, and the checker that grades every one of them against the cut.

WHY THIS FILE EXISTS. The look's worst failure is a clause like "the passage is otherwise clear and
unobstructed". That is a claim about everything the reply did not mention, and a global claim of absence is
unfalsifiable: there is no place anyone can go and check it. Five rounds of attacking it as a wording problem
did not move it.

A traversal changes the shape of the claim rather than its wording. The strip already draws `STATION_COUNT`
cuts across the flow axis and all six of them again, one to an image. Ask for ONE LINE PER CUT and two
things follow:

    it cannot skip      there is no summary slot and no concluding remark, so there is nowhere to put "and
                        that is everything". The line for cut 4 is waiting whether the model looked at cut 4
                        or not.
    every claim is local and checkable
                        "cut 4: a single filled shape; about the same; an open bore" is not unfalsifiable.
                        This file measures the same cut from the same mesh with the same code that drew it,
                        and says whether the two agree, on any file, with no answer key.

WHAT IS GRADED, AND WHY IT IS THE PICTURE AND NOT THE FLOW. A cut is drawn as FILLED MATERIAL on white, and
what the material IS depends on the representation: on a fluid domain the fill is the flow, on a wall shell the
fill is the wall and the flow is the white hole inside it. `reconcile.profile` carries that sign question and
gets it right for FLOW AREA. This file does not repeat it, because it grades what the model was SHOWN: the
shape of the filled area in a panel is the same question whichever the material is, the model is told which it
is looking at (`prompt.MODEL_KIND`) and has nothing to invert, and the checker reads the same boolean image the
painter painted. Reading flow instead would score a wall shell's plain bore as a disagreement every time the
model correctly said it saw a ring.

The obstruction signal survives that choice rather than being lost by it, because it is topological and the
topology flips with the material:

    wall shell      a plug in the bore is a separate piece of material inside the wall's ring   -> ring_with_body
    fluid domain    a plug in the bore is a hole in the fluid                                   -> ring

so on both, a passage with something standing in it stops being `disc`, and neither answer can be reached by
copying the line above it.

THE AXIS TRAP, and the gate is `reconcile.profile`'s and not a second one. `profile.trust` is imported, not
re-derived, and its two halves are used for two different columns because they refuse for two different
reasons:

    normals   the mouths do not FACE along the fitted axis, so the cut plane is oblique to the bore. A round
              bore then cuts as an ellipse, an annulus as a crescent, and every shape this file read would be
              a shape of the measurement's own making. Nothing is graded. The traversal refuses in
              `axis_trust`'s own words.
    spread    the mouths do not LIE on one line, so the part is branched and a section across any single line
              is a sum over more than one passage. The SHAPE is still well posed there and is still graded: a
              cut across a manifold shows two pieces side by side, the model can see that and this file can
              measure it. The SIZE is not, because the areas being compared are sums over different sets of
              passages, so that column alone is withheld.

Splitting them rather than refusing both is the only place this file departs from `profile.restriction_verdict`,
which refuses everything on either gate. It refuses everything because its whole output is one area profile,
and half of this file's output is not an area.

WHAT THIS CANNOT DO, and the first two are why the numbers are reported in more than one column.

- `disc` against `slot` is the one class boundary that is a threshold and not a topology. `WALK_SLOT_ASPECT`
  is read off the second moments of the largest piece, and a square duct, a wide oval and a flattened bore sit
  near it. `check_walk` reports a strict column and a `topology` column with the two merged, and the second is
  the one to believe when they disagree.
- `wider`/`narrower` is a threshold too (`WALK_SAME_BAND`), and it is graded on the area of the FILL, which is
  what the panels draw at one shared scale. On a wall shell a plug in the bore makes the fill grow, so `wider`
  is the true answer about the picture and the wrong answer about the flow. The shape word carries the flow
  question; this one carries only the picture.
- It is one traversal along ONE axis. On a tee, a wye or a manifold the branch is oblique to it. That is what
  the axis gate is for, and where the gate passes anyway the branch still arrives in a frame it does not run
  along.
- A piece of fill smaller than `WALK_MIN_PX` of a `WALK_PROBE_PX` cut is not a piece. A thin plate square to
  the axis is a full disc of fill and not a feature at all; what would show it is a cut BETWEEN two drawn
  stations, and `station_residual` is how far the drawn cuts sit from the profile they were chosen off.

Nothing here reads a brief, a family, a file name or an answer key. It is given a mesh, mouth points and mouth
normals, all three of which the measurement already has on a file nobody has ever seen.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

import numpy as np

#: The shapes a cut can be, as this file measures them. Every one is a property of the filled image alone.
#:
#:   empty           no fill at all: the plane missed the part
#:   disc            one piece of fill, nothing enclosed in it, compact
#:   slot            one piece of fill, nothing enclosed in it, much longer than it is wide
#:   ring            one piece of fill with empty space closed inside it, and nothing standing in that space
#:   ring_with_body  fill with empty space closed inside it and separate fill standing in that space
#:   several         two or more separate pieces of fill side by side, none inside another
SHAPES = ("empty", "disc", "slot", "ring", "ring_with_body", "several")
#: The one class boundary that is a threshold rather than a topology, merged away for the second column.
TOPOLOGY_OF = {"empty": "empty", "disc": "compact", "slot": "compact", "ring": "ring",
               "ring_with_body": "ring_with_body", "several": "several"}

#: How the cut is probed here. About what the model can see and not more: the strip's own panels land at
#: roughly 256 px on the long edge of the final image, and an un-packed panel is drawn larger still.
#: `render.STATION_PROBE_PX` is 72, which is the resolution the cuts are CHOSEN at and is too coarse to tell a
#: ring from a disc.
WALK_PROBE_PX = 256
#: A piece of fill, or a hole inside one, smaller than this many pixels of the probe is tessellation noise and
#: not a place. Eight of 65,536 is one part in eight thousand of the cut; `render.MARK_MIN_PX` is six of a
#: panel about five times the area. The runner prints what the number is worth.
WALK_MIN_PX = 8
#: One piece of fill is a `slot` rather than a `disc` above this ratio of its own two principal extents. A
#: circle is 1.0, a square 1.0, a two-to-one oval 2.0, a duct wall band or a blade section far more. Set above
#: the shapes an ordinary bore takes, so only a plainly long shape crosses it.
WALK_SLOT_ASPECT = 2.5
#: The fill at one cut is `about the same` as at the cut before it while their areas are within this ratio.
#:
#: It was 0.70 and the argument for it was wrong. A thirty per cent change of area is a sixteen per cent change
#: of width, and the reasoning was that anything smaller would not be visible across two panels. Measured on
#: the four screen draws of `walk`, the model sees much less than that: at 0.70 its size answers agree with
#: the cut 74.7 to 77.7 per cent of the time against 86.6 for a reply that never says anything changed, and
#: the whole gap is it calling `narrower` or `wider` where the band called a real change `same`. At 0.90
#: (five per cent of width) the same replies agree 83.9 to 85.1 per cent against a constant of 76.5.
#:
#: That makes 0.90 a number chosen on the screen, so the screen's size column is in sample from here on and
#: is never the number of record. The full pass's 230 parts outside `screen_cases.txt` are the test of it.
WALK_SAME_BAND = 0.90

#: The three words the size comparison can be, and the fourth cut 1 gets because it has nothing before it.
SIZES = ("wider", "same", "narrower", "first")


@dataclass
class WalkStation:
    """One drawn cut, measured. `cut` is numbered from one, as the picture captions it."""
    cut: int
    shape: str
    #: The fraction of the probe the fill covers. Stated to nothing: it is what `size` is read off.
    fill: float
    #: How this cut's fill compares with the one before it, and "first" for cut 1.
    size: str
    #: How many separate pieces of fill, and how many holes closed inside them. For the report, not graded.
    pieces: int = 0
    holes: int = 0


@dataclass
class Walk:
    """The traversal the measurement would write, and whether it may be written at all.

    `usable` is false when this file has nothing to grade against: no mesh, no extent along the axis, or a
    flow axis the mouths say is not the flow. A reply is never wrong against an unusable walk; it is
    ungraded, and the count of those is the first number the report prints."""
    stations: list[WalkStation] = field(default_factory=list)
    usable: bool = False
    why_not: str = ""
    axis_trusted: bool = True
    #: Which of `axis.trust`'s two gates refused, and "" when neither did.
    gate: str = ""
    #: Whether the SIZE column may be graded. False on a branched part, where the shape column still stands.
    size_usable: bool = True
    size_why_not: str = ""
    #: Which of the probed stations each drawn cut is, in `station_points` order. The drawn cuts are NOT
    #: evenly spaced (`choose_stations` puts them where the profile departs), so anything that has to place a
    #: cut against a position along the part needs these and cannot infer them from the count.
    chosen: list[int] = field(default_factory=list)
    #: How many stations were probed, so a `chosen` index can be turned into a position along the part.
    probes: int = 0
    #: How far the drawn cuts sit from the profile they were chosen out of: the largest place a straight line
    #: between the drawn cuts misses the 41-station array, as a fraction of the peak. It is the answer to "why
    #: six and not forty-one", and it is measured rather than asserted. Same quantity `render.choose_stations`
    #: minimises and stops on at `STATION_FLAT`, read out instead of thrown away.
    residual: float = 0.0

    def shapes(self) -> list[str]:
        return [s.shape for s in self.stations]


def _pieces_and_holes(mask: np.ndarray, min_px: int = WALK_MIN_PX):
    """The connected pieces of fill, and the empty space closed inside each one.

    Fill is eight-connected and empty space four-connected, which is the pairing `render.enclosed_regions`
    uses and for its reason: it stops a diagonal line of material from both separating and not separating the
    space either side of it. Empty space that reaches the edge of the probe is the room around the part, and
    `binary_fill_holes` leaves it out of a piece's holes by construction."""
    from scipy import ndimage
    m = np.asarray(mask, dtype=bool)
    cross = np.array([[0, 1, 0], [1, 1, 1], [0, 1, 0]], dtype=bool)
    box = np.ones((3, 3), dtype=bool)
    mlab, mn = ndimage.label(m, structure=box)
    keep = [i for i in range(1, mn + 1) if int((mlab == i).sum()) >= min_px]
    holes: dict[int, np.ndarray] = {}
    for i in keep:
        piece = mlab == i
        inner = ndimage.binary_fill_holes(piece) & ~piece
        if not inner.any():
            continue
        ilab, inn = ndimage.label(inner, structure=cross)
        big = np.zeros(inner.shape, dtype=bool)
        for j in range(1, inn + 1):
            reg = ilab == j
            if int(reg.sum()) >= min_px:
                big |= reg
        if big.any():
            holes[i] = big
    return mlab, keep, holes


def _aspect(piece: np.ndarray) -> float:
    """The ratio of one piece's two principal extents, from its own pixels. One for a circle and for a square."""
    ys, xs = np.nonzero(piece)
    if len(xs) < 3:
        return 1.0
    pts = np.stack([xs.astype(np.float64), ys.astype(np.float64)])
    cov = np.cov(pts)
    if not np.all(np.isfinite(cov)):
        return 1.0
    vals = np.linalg.eigvalsh(cov)
    lo, hi = float(max(vals.min(), 1e-12)), float(max(vals.max(), 1e-12))
    return float(np.sqrt(hi / lo))


def shape_of(mask: np.ndarray, min_px: int = WALK_MIN_PX,
             slot_aspect: float = WALK_SLOT_ASPECT) -> tuple[str, int, int]:
    """What one cut looks like, from the filled image and nothing else.

    The order is the order of what a mesher would do about it. Fill standing inside enclosed space is the
    answer whenever it is there, whatever else the cut also holds, because that is the one reading that says
    something is in the way. Side by side comes next, then enclosed space on its own, and the threshold is
    only reached by a cut that is one plain piece."""
    mlab, keep, holes = _pieces_and_holes(mask, min_px)
    if not keep:
        return "empty", 0, 0
    inside = False
    if holes:
        room = np.zeros(mlab.shape, dtype=bool)
        for h in holes.values():
            room |= h
        for i in keep:
            if i in holes:
                continue
            if bool(((mlab == i) & room).any()):
                inside = True
                break
    if inside:
        return "ring_with_body", len(keep), len(holes)
    if len(keep) > 1:
        return "several", len(keep), len(holes)
    if holes:
        return "ring", len(keep), len(holes)
    return ("slot" if _aspect(mlab == keep[0]) > slot_aspect else "disc"), 1, 0


def size_word(now: float, before: float, band: float = WALK_SAME_BAND) -> str:
    """How one cut's fill compares with the one before it. `band` is a ratio of areas, not of widths."""
    if before <= 0.0 and now <= 0.0:
        return "same"
    if before <= 0.0:
        return "wider"
    if now <= 0.0:
        return "narrower"
    ratio = now / before
    if ratio > 1.0 / band:
        return "wider"
    if ratio < band:
        return "narrower"
    return "same"


def station_residual(profile: np.ndarray, chosen: list[int]) -> float:
    """How much of the profile the drawn cuts miss: the largest departure of the probed array from a straight
    line between the cuts that were drawn, as a fraction of the peak."""
    p = np.asarray(profile, dtype=np.float64)
    idx = np.asarray(sorted({int(c) for c in chosen}), dtype=int)
    if len(p) < 2 or len(idx) < 2:
        return 0.0
    peak = float(p.max()) or 1.0
    approx = np.interp(np.arange(len(p)), idx.astype(float), p[idx])
    return float(np.abs(p - approx).max() / peak)


def measure_walk(vertices: np.ndarray, faces: np.ndarray, mouth_points: np.ndarray | None = None,
                 mouth_normals: np.ndarray | None = None, count: int | None = None,
                 px: int = WALK_PROBE_PX, min_px: int = WALK_MIN_PX,
                 slot_aspect: float = WALK_SLOT_ASPECT, band: float = WALK_SAME_BAND) -> Walk:
    """The traversal for one part: the cuts the strip drew, each one measured.

    Every geometric choice is imported from `vision.render` rather than re-derived, for the reason
    `reconcile.profile.flow_profile` gives: a checker that chose its own axis, frame or stations would be
    grading a reply against a different picture from the one the model was shown."""
    from geometry_agent.reconcile.profile import trust
    from geometry_agent.vision.render import (
        STATION_COUNT,
        STATION_FILL,
        _panel_frame,
        choose_stations,
        flow_axis,
        section_fill,
        station_points,
        station_profile,
    )

    count = STATION_COUNT if count is None else int(count)
    v = np.asarray(vertices, dtype=np.float64)
    f = np.asarray(faces)
    if not len(v) or not len(f):
        return Walk(why_not="no mesh")
    bounds = np.array([v.min(axis=0), v.max(axis=0)])
    axis = flow_axis(bounds, mouth_points)
    r, u = _panel_frame(axis)
    centre = bounds.mean(axis=0)
    rel = v - centre
    half = max(float(np.ptp(rel @ r)), float(np.ptp(rel @ u))) / 2.0 / STATION_FILL or 1.0
    probes = station_points(v, axis)
    if not probes:
        return Walk(why_not="the part has no extent along its flow axis")
    coarse = station_profile(v, f, axis, r, u, centre, half, probes)
    chosen = choose_stations(coarse, count)
    verdict = trust(axis, mouth_points, mouth_normals)
    residual = station_residual(coarse, chosen)
    branched = verdict.gate == "spread"
    # The cuts are measured even where the gate refuses, and `usable` still says no. The refusal is about the
    # PASSAGE: the cuts are not across the flow, so nothing here says anything about what the flow meets. The
    # picture is still a picture and the model still described it, so the stations are kept for the one report
    # that asks what the refusal costs. `check_walk` grades nothing while `usable` is false, whatever is here.
    per = 2.0 * half / px
    a = np.stack([r / per, -u / per])
    b = np.array([px / 2.0, px / 2.0]) - a @ centre
    stations: list[WalkStation] = []
    previous = 0.0
    for k, i in enumerate(chosen):
        mask = section_fill(v, f, probes[i], axis, a, b, px, px)
        shape, pieces, holes = shape_of(mask, min_px, slot_aspect)
        fill = float(mask.mean())
        size = "first" if k == 0 else size_word(fill, previous, band)
        previous = fill
        stations.append(WalkStation(cut=k + 1, shape=shape, fill=fill, size=size, pieces=pieces, holes=holes))
    oblique = verdict.gate == "normals"
    return Walk(stations=stations, usable=not oblique, why_not=verdict.note if oblique else "",
                axis_trusted=not oblique, gate=verdict.gate,
                size_usable=not (branched or oblique),
                size_why_not=verdict.note if (branched or oblique) else "", residual=residual,
                chosen=[int(i) for i in chosen], probes=len(probes))


# ---------------------------------------------------------------------------------------------------------------
# Reading the reply.
#
# The vocabulary the prompt offers is the vocabulary this reads, and nothing else is guessed at. An entry that
# carries none of the offered phrases is reported as UNREAD and never as a disagreement: a parser that scored
# its own failure to read as the model's failure to look would be the eighth time a measuring tool in this
# project had the blind spot of the thing it was measuring.
# ---------------------------------------------------------------------------------------------------------------
#: THE COLLISION BETWEEN THE ANCHOR AND THE SCRUB, and it was found on the first three replies rather than
#: reasoned about. `prompt.scrub_numbers` turns every digit into `[n]` on the way out, so a reply that wrote
#: "cut 4:" reaches this file as "cut [n]:" and its anchor is gone: the one thing a traversal is for, that
#: every answer names a place, is destroyed by the rule that keeps numbers out of the impression. The field
#: therefore asks for the caption as a WORD, which the prompt's own "count in words" rule already asks for
#: everywhere else, and both spellings are read here. An entry whose anchor the scrub ate is not read as the
#: model's failure to anchor; it is recovered by position, and `read_walk` counts every recovery so the number
#: can be read rather than assumed.
_WORDS = ("one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve")
_WORD_NUM = {w: i + 1 for i, w in enumerate(_WORDS)}
_CUT = re.compile(r"^\s*[*\-\s]*cut\s*[_\- ]?(\d{1,2}|" + "|".join(_WORDS) + r")\b", re.I)
#: The same caption with the number scrubbed out of it.
_CUT_SCRUBBED = re.compile(r"^\s*[*\-\s]*cut\s*[_\- ]?\[n\]", re.I)
#: Each shape's phrases, tried in this order. The order is the answer to an entry that carries two of them:
#: "a ring with a piece of material inside it" contains "a ring", and a reader that matched `ring` first would
#: score the one answer that names an obstruction as the one that denies it.
_SHAPE_PATTERNS: tuple[tuple[str, str], ...] = (
    ("ring_with_body", r"ring[^;.]{0,60}?(?:with|around|holding|enclos\w*)[^;.]{0,60}?"
                       r"(?:material|body|bodies|piece|pieces|core|plug|rod|insert)"),
    ("ring_with_body", r"(?:material|body|bodies|piece|pieces|core|plug|rod|insert)[^;.]{0,60}?"
                       r"(?:inside|within|in the middle of|standing in)[^;.]{0,40}?(?:ring|annul\w+)"),
    ("several", r"\b(?:two or more|several|multiple|many)\b[^;.]{0,40}?\bseparate\b"),
    ("several", r"\bseparate\b[^;.]{0,40}?\bpieces?\b"),
    ("several", r"\bside by side\b"),
    ("ring", r"\bring\b|\bannul\w+"),
    ("slot", r"\blong(?:er)?\s+(?:and\s+)?thin\b|\bthin\s+and\s+long\b|\bslot\b|"
             r"\blong\s+narrow\b|\bnarrow\s+and\s+long\b|\belongated\b"),
    ("empty", r"\bnothing\s+(?:filled|at all|there)\b|\bno\s+fill\b|\bempty\s+cut\b|"
              r"\bnothing\s+in\s+the\s+cut\b"),
    ("disc", r"\bsingle\s+filled\b|\bone\s+filled\b|\bsingle\s+(?:solid|compact|round)\b|"
             r"\bfilled\s+(?:disc|disk|circle|shape|area)\b|\bsolid\s+(?:disc|disk|circle)\b|"
             r"\bplain\s+filled\b|\bone\s+piece\s+of\s+fill\b"),
)
#: An entry that says it cannot read the cut. Offered in the same sentence as the vocabulary, on purpose: at a
#: named cut it is an answer and not a hedge, and it is worth more than a guess.
_ABSTAIN = re.compile(r"cannot tell|cannot be (?:told|read)|too (?:small|faint)|"
                      r"not (?:legible|readable)|\bunsure\b", re.I)
_SIZE_PATTERNS: tuple[tuple[str, str], ...] = (
    ("first", r"\bfirst\b|\bnothing before\b|\bno previous\b|\bn/?a\b"),
    ("same", r"\babout the same\b|\bthe same\b|\bunchanged\b|\bno change\b|\bsimilar\b|\bequal\b"),
    ("wider", r"\bwider\b|\blarger\b|\bbigger\b|\bgrows\b|\bopens out\b|\bexpand\w*"),
    ("narrower", r"\bnarrower\b|\bsmaller\b|\bshrink\w*|\btighter\b|\breduc\w*|\bcontract\w*"),
)
_SHAPE_RE = tuple((name, re.compile(pat, re.I)) for name, pat in _SHAPE_PATTERNS)
_SIZE_RE = tuple((name, re.compile(pat, re.I)) for name, pat in _SIZE_PATTERNS)


@dataclass
class Stated:
    """One line of a reply's traversal, read. `shape` and `size` are None when the line carried neither."""
    cut: int
    shape: str | None
    size: str | None
    abstained: bool
    text: str


def _first_match(patterns, places: list[str]) -> str | None:
    """The first pattern that matches, tried against each place in turn, so an earlier place always wins."""
    for where in places:
        for name, rx in patterns:
            if rx.search(where):
                return name
    return None


def _number(token: str) -> int:
    return _WORD_NUM.get(token.lower(), 0) or int(token)


def read_walk(entries) -> tuple[list[Stated], int, int]:
    """A reply's traversal entries read into one `Stated` each, how many named no cut, and how many had their
    caption recovered by position after the scrub ate it.

    An entry that names no cut is not read: a traversal's whole value is that every answer is anchored to a
    place, and an unanchored sentence is the global claim this file exists to replace. An entry whose caption
    reads `cut [n]` DID name a place and the scrub removed it, so it is recovered from its position in the
    list, and only when every entry is in that state, which is what makes the position trustworthy."""
    items = [str(raw or "").strip() for raw in (entries or [])]
    items = [t for t in items if t]
    scrubbed = [bool(_CUT_SCRUBBED.match(t)) for t in items]
    recover = bool(items) and all(scrubbed)
    out: list[Stated] = []
    unanchored = 0
    recovered = 0
    for i, text in enumerate(items):
        m = _CUT.match(text)
        if m:
            cut, body = _number(m.group(1)), text[m.end():]
        elif recover:
            cut, body = i + 1, text[_CUT_SCRUBBED.match(text).end():]
            recovered += 1
        else:
            unanchored += 1
            continue
        # The field asks for three things separated by semicolons, in order, so each is read out of its own
        # segment first and out of the whole entry only when its segment says nothing. Reading the size out of
        # the whole entry was the first version and it was wrong both ways, measured on the first draw: a
        # bare "first" in the size slot was unread 65 times, and a free-text third segment that said "a wider
        # section" would have overridden a size slot that said "about the same".
        parts = [x.strip() for x in body.split(";")]
        shape = _first_match(_SHAPE_RE, parts[:1] + [body])
        size = _first_match(_SIZE_RE, parts[1:2] + [body])
        out.append(Stated(cut=cut, shape=shape, size=size,
                          abstained=bool(_ABSTAIN.search(body)), text=text))
    return out, unanchored, recovered


#: What one station's answer can come to. `agrees` and `contradicts` are the two that count; the other three
#: are the ways an answer can fail to be one of those, and each is printed rather than folded in.
VERDICTS = ("agrees", "contradicts", "abstains", "unread", "missing")


@dataclass
class WalkCheck:
    """One reply's traversal against one measured walk."""
    graded: bool
    why_not: str = ""
    #: (cut, verdict, said, measured) per drawn cut, on the strict six-class reading.
    shape: list[tuple[int, str, str, str]] = field(default_factory=list)
    #: The same on `TOPOLOGY_OF`, where `disc` and `slot` are one class.
    topology: list[tuple[int, str, str, str]] = field(default_factory=list)
    size: list[tuple[int, str, str, str]] = field(default_factory=list)
    #: Entries the reply wrote for a cut that was not drawn: an answer about a place it was not shown.
    extra: list[int] = field(default_factory=list)
    #: Entries that named no cut at all.
    unanchored: int = 0
    #: Entries whose caption the scrub ate and which were recovered from their position in the list.
    recovered: int = 0
    #: How many distinct shape words the reply used across this part's cuts, beside how many the measurement
    #: used. One against three is a reply that wrote the same line every time, which is the failure this shape
    #: of question invites and the reason the number is on the record rather than in a footnote.
    distinct_said: int = 0
    distinct_measured: int = 0


def _verdict(said: str | None, abstained: bool, measured: str) -> tuple[str, str]:
    if said is None:
        return ("abstains", "") if abstained else ("unread", "")
    return ("agrees" if said == measured else "contradicts"), said


def check_walk(stated: list[Stated], walk: Walk, unanchored: int = 0,
                recovered: int = 0) -> WalkCheck:
    """Grade a reply's traversal, cut by cut, against the cuts as measured.

    Three columns and not one, and the reason is in this file's header: the strict shape column carries a
    threshold inside it, the topology column does not, and the size column is about the picture's area and
    says nothing about flow. A reader given one number would not know which of the three had moved."""
    if not walk.usable:
        return WalkCheck(graded=False, why_not=walk.why_not or "the walk could not be measured",
                         unanchored=unanchored, recovered=recovered)
    by_cut = {s.cut: s for s in stated}
    drawn = {s.cut for s in walk.stations}
    out = WalkCheck(graded=True, unanchored=unanchored, recovered=recovered)
    out.extra = sorted(c for c in by_cut if c not in drawn)
    for st in walk.stations:
        said = by_cut.get(st.cut)
        if said is None:
            out.shape.append((st.cut, "missing", "", st.shape))
            out.topology.append((st.cut, "missing", "", TOPOLOGY_OF[st.shape]))
            if walk.size_usable:
                out.size.append((st.cut, "missing", "", st.size))
            continue
        v, s = _verdict(said.shape, said.abstained, st.shape)
        out.shape.append((st.cut, v, s, st.shape))
        tv, ts = _verdict(TOPOLOGY_OF[said.shape] if said.shape else None,
                          said.abstained, TOPOLOGY_OF[st.shape])
        out.topology.append((st.cut, tv, ts, TOPOLOGY_OF[st.shape]))
        if walk.size_usable:
            sv, ss = _verdict(said.size, said.abstained, st.size)
            out.size.append((st.cut, sv, ss, st.size))
    out.distinct_said = len({s.shape for s in stated if s.shape})
    out.distinct_measured = len({s.shape for s in walk.stations})
    return out


def tally(checks, column: str = "shape") -> dict[str, int]:
    """The five verdicts counted over many checks, for one column."""
    counts = dict.fromkeys(VERDICTS, 0)
    for c in checks:
        if not c.graded:
            continue
        for _cut, verdict, _said, _measured in getattr(c, column):
            counts[verdict] = counts.get(verdict, 0) + 1
    return counts
