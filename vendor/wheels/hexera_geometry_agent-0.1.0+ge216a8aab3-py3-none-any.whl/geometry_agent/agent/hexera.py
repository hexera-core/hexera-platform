"""Speak Hexera's vocabulary: turn a GeometryPlan into the exact shapes intake and the builder consume.

Everything here is a pure translation of a confirmed plan. Nothing imports meshpipeline; the identifiers are
copied from `docs/hexera_vocabulary.md` and pinned to the platform revision in `docs/handover_consumers.md`
(PLATFORM_SHA), which maps every field emitted here to the platform line that reads it, or says that none does:

- `patches[{name, type}]` with `type` in the purpose's `boundary_roles`
- `port_declaration` rows `{name, role, diameter_mm | area_mm2 | width_mm+height_mm, near_mm, interchangeable_with}`
  for inlets and outlets, obeying `_validate_internal_ports` (mesh-safe names, one size form, 5/3 size separation
  or a location)
- the domain declaration `{requested_extents, reference_length_m, flow_axis, requirements_strict}`
- `engine_params` hints in each engine's own strategy keys, and which engines can take the file at all
- the strategy header: the planner's own keys with one clause of why each, under 500 characters, placed first
  in the builder block so it survives the planner's 2000-character read of request.txt
- the advisory block: what the plan knows that no platform reader consumes today (seed point, extensions,
  MRF zone, feature edges, per-port layers), kept out of the engine params so nothing pretends to be read
- the triage: the platform's own pre-mesh refusals (bind_ports, tessellate_internal, gmsh's no-solid rule)
  emulated and logged, never enforced
- `report()`: the one JSON the session will store, keyed by the source hash."""
from __future__ import annotations

import json
import math
import re
from pathlib import Path
from typing import Any

from geometry_agent import axis as _axis
from geometry_agent.agent import catalog, tools
from geometry_agent.agent.schema import GeometryPlan
from geometry_agent.agent.tools import PLATFORM_SHA

#: The contract's own limits on the block this module composes, imported at module scope so `SURVEY_SUBJECTS_MAX`
#: below can BE the contract's number rather than a copy of it. `contract.deliver` imports nothing from `agent/`
#: at module scope (its one call into this module, `attach` -> `survey_with_answers`, is inside the function), so
#: this is a one-way edge and both import orders are checked by `test_survey_row_cap.py`.
from geometry_agent.contract import deliver as _deliver

#: The three look states and the outcome rule, bound here as well because this module is the platform's import
#: surface (`application/geometry_survey._package()["hexera"]`). Same objects, one definition: `contract.survey`
#: owns them because they are the Surveyor's own vocabulary and `contract.marks` is a leaf, so neither import
#: reaches back into `agent/`.
from geometry_agent.contract.marks import ContractError
from geometry_agent.contract.survey import LOOK_FAILED, LOOK_NOT_ATTEMPTED, LOOK_OK, LOOK_STATES
from geometry_agent.facts.schema import GeometryFacts
from geometry_agent.vision import place as vplace
from geometry_agent.vision import trust as vtrust

PURPOSE_ROLES: dict[str, tuple[str, ...]] = {
    "structural": ("fixed", "load", "contact", "free"),
    "external_cfd": ("wall", "farfield", "symmetry", "empty"),
    "internal_cfd": ("wall", "inlet", "outlet", "symmetry", "empty"),
    "conjugate_heat_transfer": ("inlet", "outlet", "wall", "external", "symmetry", "empty"),
}
INPUT_KINDS = ("solid-body", "fluid-domain", "body-surface", "solid-assembly", "planar-domain")
RESERVED_PATCH_NAMES = frozenset({"outer", "FoamFile", "farfield"})
PATCH_NAME = re.compile(r"^[A-Za-z][A-Za-z0-9_]*$")
MIN_DECLARED_AREA_SEPARATION = 5.0 / 3.0
EXTENT_DIRECTIONS = ("upstream", "downstream", "lateral", "vertical")
FLOW_AXES = ("+x", "-x", "+y", "-y", "+z", "-z")
BUILDER_BLOCK_MAX_CHARS = 2400
UNIT_TO_M = {"m": 1.0, "mm": 1e-3, "cm": 1e-2, "in": 0.0254, "ft": 0.3048}
MAX_CELLS_CAP = 8_000_000

#: engines/port_binding.py:14-23 at PLATFORM_SHA
AREA_RATIO_LO, AREA_RATIO_HI = 0.75, 1.25
MIN_CLASS_SEPARATION = AREA_RATIO_HI / AREA_RATIO_LO
HINT_MAX_BBOX_FRACTION, HINT_MARGIN = 0.25, 0.5
#: cad/cad_tessellate.py:72-88
SIZE_ERR_QUANTUM, DIST_QUANTUM_M, FILL_CIRCLE, FILL_RECT, FILL_TOL = 0.01, 1e-6, math.pi / 4.0, 1.0, 0.1
#: engines/snappy/planner.py:69 margin 0.85 and :42 "aim 15-20% under": the builder's own budget margin
BUILDER_MARGIN = 0.15
#: engines/snappy/planner.py:69 floor=200_000
PLANNER_BUDGET_FLOOR = 200_000
#: engines/snappy/planner.py:50-61 and :26-36, engines/gmsh/driver.py:16-19
PLANNER_INTERNAL_KEYS = ("cells_across_diameter", "surface_level", "feature_level", "n_layers", "first_layer_rel",
                         "quality", "max_cells")
PLANNER_EXTERNAL_KEYS = ("domain_margin", "reference_length_m", "n_layers", "first_layer_rel", "quality", "max_cells")
MULTIREGION_KEYS = ("regions", "surface_level", "interface_refinement", "n_layers", "first_layer_rel", "quality", "max_cells")
GMSH_KEYS = ("size", "curvature_nodes")
#: the planner's own guidance bands: planner.py:63 (internal) and :38 (external)
FIRST_LAYER_REL_BAND = {"internal": (0.2, 0.4), "external": (0.25, 0.5)}
N_LAYERS_MAX = {"internal": 6, "external": 5}
CELLS_ACROSS_BAND = (16, 40)
HEADER_MAX_CHARS = 500
#: The look, in the handover. The label is the whole point: the builder reads `request.txt` as prose, and the one
#: thing that must never be in doubt is which lines are measurements and which are a description of a picture.
IMPRESSION_LABEL = "VISUAL IMPRESSION (a vision model's words from nine rendered views; not a measurement)"
#: The same label, shortened, for the one line in `builder_block`: every character of it is paid for out of the
#: planner's 2000-character read of `request.txt`.
IMPRESSION_LINE_LABEL = "VISUAL IMPRESSION (words from renders, not a measurement)"
#: The impression's line in `builder_block`, second after the header so it lands inside the planner's own
#: 2000-character read (`engines/snappy/planner.py:186`; docs/handover_consumers.md section 1). This is what the
#: line costs the plan's own lines in that window, and the number was measured rather than picked: at 420 the
#: line ran to 509 characters and cost five of manifold_short's fifteen plan lines and four of naca0012's
#: eighteen. At 300, with the short label, it costs one or two. The whole record is in the handover's own
#: `visual_impression` block either way; this line is the part that reaches a planner reading prose.
IMPRESSION_LINE_MAX_CHARS = 300
LAYER_EXPANSION = tools.LAYER_EXPANSION
#: cad/regions.py:16 names a STEP translator writes when the file named nothing
GENERATED_NAME_PREFIXES = ("open cascade", "opencascade", "step translator")

#: geometry-agent role -> Hexera patch type, per purpose. `None` means the role cannot be handed over as is.
_ROLE_MAP: dict[str, dict[str, str | None]] = {
    "internal_cfd": {"inlet": "inlet", "outlet": "outlet", "wall": "wall", "closed_end": "wall", "symmetry": "symmetry",
                     "farfield": None, "interface": None, "opening_unknown": None},
    "external_cfd": {"wall": "wall", "farfield": "farfield", "symmetry": "symmetry", "closed_end": "wall",
                     "inlet": None, "outlet": None, "interface": None, "opening_unknown": None},
    "conjugate_heat_transfer": {"inlet": "inlet", "outlet": "outlet", "wall": "wall", "closed_end": "wall",
                                "symmetry": "symmetry", "farfield": "external", "interface": None, "opening_unknown": None},
    "structural": {"wall": "free", "closed_end": "free", "inlet": None, "outlet": None, "farfield": None,
                   "symmetry": None, "interface": None, "opening_unknown": None},
}

#: Every platform line the header, the emulator and the triage rely on, at PLATFORM_SHA. tests/test_vocabulary_pin.py
#: reads these files as text and asserts each `text` is still there; docs/handover_consumers.md cites the same lines.
PLATFORM_PINS: tuple[dict[str, Any], ...] = (
    {"file": "engines/snappy/authoring.py", "identifier": "_STRATEGY", "line": 33,
     "text": '_STRATEGY = {"domain_margin", "n_layers", "first_layer_rel", "quality",', "used_by": "header keys"},
    {"file": "engines/snappy/authoring.py", "identifier": "_STRATEGY", "line": 34,
     "text": '"surface_level", "feature_level", "max_cells"}', "used_by": "header keys"},
    {"file": "engines/snappy/authoring.py", "identifier": "AUTHORING_TOOL.first_layer_rel", "line": 22,
     "text": "outer layer thickness vs local cell (default 0.35)", "used_by": "first_layer_rel_outer"},
    {"file": "engines/snappy/planner.py", "identifier": "INTERNAL_PLANNER_SYSTEM", "line": 52,
     "text": '"cells_across_diameter": <int>,', "used_by": "header keys"},
    {"file": "engines/snappy/planner.py", "identifier": "INTERNAL_PLANNER_SYSTEM", "line": 63,
     "text": "cells_across_diameter 16-40", "used_by": "CELLS_ACROSS_BAND"},
    {"file": "engines/snappy/planner.py", "identifier": "INTERNAL_PLANNER_SYSTEM", "line": 63,
     "text": "first_layer_rel 0.2-0.4", "used_by": "FIRST_LAYER_REL_BAND internal"},
    {"file": "engines/snappy/planner.py", "identifier": "PLANNER_SYSTEM", "line": 38,
     "text": "first_layer_rel 0.25-0.5", "used_by": "FIRST_LAYER_REL_BAND external"},
    {"file": "engines/snappy/planner.py", "identifier": "overshoot_corrected_budget", "line": 69,
     "text": "margin: float = 0.85, floor: int = 200_000", "used_by": "BUILDER_MARGIN, PLANNER_BUDGET_FLOOR"},
    {"file": "engines/snappy/planner.py", "identifier": "plan_with_accounting", "line": 390,
     "text": '(request_txt or "").strip()[:2000]', "used_by": "header placed first, under 500 chars"},
    {"file": "engines/snappy/drivers.py", "identifier": "_build_internal_deterministic", "line": 666,
     "text": 'cells_across = max(8, int(strategy.get("cells_across_diameter", 24)))', "used_by": "emulator"},
    {"file": "engines/snappy/drivers.py", "identifier": "_build_internal_deterministic", "line": 672,
     "text": "base_cell = (bore_D / cells_across) * (2 ** surface_level)", "used_by": "emulator, builder frame"},
    {"file": "engines/snappy/drivers.py", "identifier": "_bore_area_m2", "line": 506,
     "text": "def _bore_area_m2(t: dict) -> float:", "used_by": "builder_inlet"},
    {"file": "engines/snappy/snappy_runner.py", "identifier": "render_internal_case", "line": 619,
     "text": "pad = max(2.0 * base_cell, 0.03 * maxext)", "used_by": "emulator"},
    {"file": "engines/snappy/snappy_runner.py", "identifier": "render_internal_case", "line": 624,
     "text": "div = [max(8, min(120, int(round(dext[i] / base_cell)))) for i in range(3)]", "used_by": "emulator"},
    {"file": "engines/snappy/snappy_runner.py", "identifier": "render_internal_case", "line": 636,
     "text": "port_level = max(1, smin - 1)", "used_by": "emulator, tilted mouth mechanism"},
    {"file": "engines/snappy/snappy_runner.py", "identifier": "render_internal_case", "line": 637,
     "text": "near_dist = max(3.0 * base_cell, 0.08 * maxext)", "used_by": "emulator"},
    {"file": "engines/snappy/snappy_runner.py", "identifier": "render_internal_case", "line": 638,
     "text": "near_level = min(_HARD_MAX_LEVEL, smax + 1)", "used_by": "emulator"},
    {"file": "engines/snappy/snappy_runner.py", "identifier": "render_internal_case", "line": 679,
     "text": "nCellsBetweenLevels 3", "used_by": "emulator transitions"},
    {"file": "engines/snappy/snappy_runner.py", "identifier": "render_internal_case", "line": 685,
     "text": "addLayersControls {{ relativeSizes true; layers {{ {wall} {{ nSurfaceLayers {n_layers}; }} }}",
     "used_by": "first_layer_rel_outer, one wall layer entry"},
    {"file": "engines/snappy/snappy_runner.py", "identifier": "render_internal_case", "line": 686,
     "text": "expansionRatio 1.2; finalLayerThickness {first_rel:g}", "used_by": "first_layer_rel_outer"},
    {"file": "engines/snappy/snappy_runner.py", "identifier": "render_snappy_case", "line": 411,
     "text": "_BG_MAX_DIV = 256", "used_by": "emulator external"},
    {"file": "engines/snappy/snappy_runner.py", "identifier": "render_snappy_case", "line": 412,
     "text": "_BG_CELL_BUDGET = 600_000", "used_by": "emulator external"},
    {"file": "engines/snappy/snappy_runner.py", "identifier": "render_snappy_case", "line": 503,
     "text": "near_band_level = min(int(b0l) + deficit, smax + 2)", "used_by": "emulator external"},
    {"file": "engines/snappy/snappy_runner.py", "identifier": "domain_from_strategy", "line": 308,
     "text": 'up, dn = float(m.get("up", 2.0)), float(m.get("down", 4.0))', "used_by": "emulator external"},
    {"file": "cad/analysis.py", "identifier": "recommend_refinement", "line": 160,
     "text": "base_divisions: int = 24, body_cells: int = 150,", "used_by": "emulator external"},
    {"file": "cad/analysis.py", "identifier": "recommend_refinement", "line": 166,
     "text": "base_cell = L / base_divisions", "used_by": "emulator external"},
    {"file": "cad/analysis.py", "identifier": "recommend_refinement", "line": 190,
     "text": "near = round(6.0 * surf_cell, 6)", "used_by": "emulator external"},
    {"file": "cad/analysis.py", "identifier": "recommend_refinement", "line": 191,
     "text": "far = round(max(4.0 * near, 0.04 * L), 6)", "used_by": "emulator external"},
    {"file": "engines/port_binding.py", "identifier": "AREA_RATIO_LO", "line": 14, "text": "AREA_RATIO_LO = 0.75", "used_by": "triage"},
    {"file": "engines/port_binding.py", "identifier": "AREA_RATIO_HI", "line": 15, "text": "AREA_RATIO_HI = 1.25", "used_by": "triage"},
    {"file": "engines/port_binding.py", "identifier": "MIN_CLASS_SEPARATION", "line": 19,
     "text": "MIN_CLASS_SEPARATION = AREA_RATIO_HI / AREA_RATIO_LO", "used_by": "triage"},
    {"file": "engines/port_binding.py", "identifier": "HINT_MAX_BBOX_FRACTION", "line": 22,
     "text": "HINT_MAX_BBOX_FRACTION = 0.25", "used_by": "triage"},
    {"file": "engines/port_binding.py", "identifier": "HINT_MARGIN", "line": 23, "text": "HINT_MARGIN = 0.5", "used_by": "triage"},
    {"file": "engines/port_binding.py", "identifier": "DeclaredPatch.from_intake", "line": 48,
     "text": 'role=entry["type"],', "used_by": "port rows carry type as well as role"},
    {"file": "engines/port_binding.py", "identifier": "bind_ports rule 1", "line": 154,
     "text": "if len(openings) < len(ports):", "used_by": "triage"},
    {"file": "cad/cad_tessellate.py", "identifier": "_AREA_BAND_LO", "line": 61, "text": "_AREA_BAND_LO = 0.75", "used_by": "triage"},
    {"file": "cad/cad_tessellate.py", "identifier": "_SIZE_ERR_QUANTUM", "line": 72, "text": "_SIZE_ERR_QUANTUM = 0.01", "used_by": "triage"},
    {"file": "cad/cad_tessellate.py", "identifier": "_FILL_TOL", "line": 88, "text": "_FILL_TOL = 0.1", "used_by": "triage"},
    {"file": "cad/cad_tessellate.py", "identifier": "tessellate_internal", "line": 498,
     "text": "if not solid_exp.More():", "used_by": "triage no-solid"},
    {"file": "cad/cad_tessellate.py", "identifier": "tessellate_internal", "line": 594,
     "text": "and len(open_idx) > len(declared_ports) >= 2):", "used_by": "triage selection"},
    {"file": "cad/cad_tessellate.py", "identifier": "tessellate_internal", "line": 605,
     "text": "if len(open_idx) < 2:", "used_by": "triage two openings"},
    {"file": "cad/cad_tessellate.py", "identifier": "tessellate_internal seed", "line": 893,
     "text": "step = 0.5 * _m.sqrt(area / _m.pi)", "used_by": "seed point is the platform's, advisory"},
    {"file": "engines/gmsh/driver.py", "identifier": "main size default", "line": 258,
     "text": 'size_spec = spec.get("size") or {"mode": "factor", "value": 0.04}', "used_by": "gmsh header, emulator"},
    {"file": "engines/gmsh/driver.py", "identifier": "main MeshSizeMin", "line": 263,
     "text": 'gmsh.option.setNumber("Mesh.MeshSizeMin", h / 20.0)', "used_by": "emulator gmsh"},
    {"file": "engines/gmsh/driver.py", "identifier": "main curvature", "line": 265,
     "text": 'int(spec.get("curvature_nodes", 24)))', "used_by": "gmsh header, emulator"},
    {"file": "engines/gmsh/driver.py", "identifier": "main no solid", "line": 276,
     "text": 'print("[GMSH] no solid volumes in geometry.step - cannot mesh a "', "used_by": "triage gmsh"},
    {"file": "agents/intake/validation.py", "identifier": "_RESERVED_PATCH_NAMES", "line": 226,
     "text": '_RESERVED_PATCH_NAMES = frozenset({"outer", "FoamFile", "farfield"})', "used_by": "declaration_problems"},
    {"file": "agents/intake/validation.py", "identifier": "_MIN_DECLARED_AREA_SEPARATION", "line": 227,
     "text": "_MIN_DECLARED_AREA_SEPARATION = 5.0 / 3.0", "used_by": "declaration_problems"},
    {"file": "agents/intake/validation.py", "identifier": "_PORT_NAME_RE", "line": 252,
     "text": r'_PORT_NAME_RE = _re.compile(r"^[A-Za-z][A-Za-z0-9_]*$")', "used_by": "PATCH_NAME"},
    {"file": "agents/intake/validation.py", "identifier": "_validate_internal_ports near_mm", "line": 289,
     "text": "near_mm must be [x, y, z] in millimetres", "used_by": "port rows always carry near_mm"},
    {"file": "cad/regions.py", "identifier": "CadRegions.as_facts", "line": 33,
     "text": 'return {"region_names": list(self.names), "region_count": self.count,', "used_by": "report admission_facts"},
)


def mesh_safe_name(name: str, taken: set[str], reserved: bool = True) -> str:
    """A mesh-safe patch name. `reserved` applies the reserved-name suffix, which only port names need: the
    intake patch list itself names the far field 'farfield'."""
    base = re.sub(r"[^A-Za-z0-9_]+", "_", name.strip()).strip("_") or "patch"
    if not base[0].isalpha():
        base = "p_" + base
    if reserved and base in RESERVED_PATCH_NAMES:
        base = base + "_patch"
    out, k = base, 2
    while out in taken:
        out, k = f"{base}_{k}", k + 1
    taken.add(out)
    return out


def _snap_axis(axis) -> str | None:
    """A vector as the signed axis letter the builder reads, or None when it is not mostly one of the three.

    ONE SNAP AND ONE CUTOFF. This was four lines here and four more in `contract.given._plan_flow_direction`,
    each with its own `0.9`, and `given.py`'s docstring said its copy was deliberate so the contract package
    would stay free of the agent. `geometry_agent.axis` is the neutral home: it imports nothing of the package,
    so the boundary holds and the number has one place to live. `test_flow_axis_gate.py` pins that there is one.
    """
    return _axis.snap(axis)


def catalog_filled(plan: GeometryPlan, facts: GeometryFacts | None, *, cell_cap: int | None = None,
                   declared: list[dict[str, Any]] | None = None, brief: str | None = None) -> GeometryPlan:
    """The plan with every catalog-owned risk field filled, for a plan that did not come through the checker.

    P4.3e (R34) made a catalog risk a reference: the plan writes its id and the analyst's decision and the
    checker fills kind, severity, measurement, consequence, recommendation, mechanism and effect from the
    catalog run under the plan's own roles. A plan that reaches the handover from anywhere else still carries
    the short form, and `Risk`'s type defaults then read back as kind '' and severity 'medium' with
    requires_user_decision False: the two warning lists lose the kind that says whose warning it is, and
    `blockers` loses every pending decision, which is the one thing it exists to report. This runs the
    checker's own fill rather than a second copy of it, and returns the plan untouched when nothing is short
    or when the catalog cannot be run (no facts, a plan whose roles the catalog refuses)."""
    short = [r for r in plan.risks if r.detected_by == "catalog" and not (r.kind or "").strip()]
    if not short or facts is None:
        return plan
    from geometry_agent.agent import grounding
    from geometry_agent.agent.tools import ToolContext
    ctx = ToolContext(facts=facts, purpose=plan.purpose, fidelity=plan.mesh_plan.fidelity, cell_cap=cell_cap,
                      declared=declared, brief=brief or "")
    obj = plan.model_dump()
    risks = [r for r in (obj.get("risks") or []) if isinstance(r, dict)]
    try:
        grounding.fill_catalog_risks(obj, ctx, risks)
    except (StopIteration, ValueError, KeyError, TypeError, AttributeError):
        return plan
    obj["risks"] = risks
    return GeometryPlan.model_validate(obj)


def blockers(plan: GeometryPlan, facts: GeometryFacts | None = None, *, cell_cap: int | None = None,
             declared: list[dict[str, Any]] | None = None, brief: str | None = None) -> list[str]:
    """What stops this plan from being handed to intake as it stands. Empty means it can go. With `facts` a plan
    whose catalog risks are still written by reference is filled first (`catalog_filled`), so a decision the user
    has not made is reported instead of being read as the schema's default."""
    plan = catalog_filled(plan, facts, cell_cap=cell_cap, declared=declared, brief=brief)
    out = []
    roles = _ROLE_MAP[plan.purpose]
    for p in plan.patches:
        if roles.get(p.role) is None:
            out.append(f"patch {p.id} ({p.name}) has role {p.role!r}, which {plan.purpose} cannot take; the user must settle it")
    pending = [r for r in plan.risks if r.requires_user_decision and r.user_decision == "pending"
               and r.severity in ("blocking", "high")]
    for r in pending:
        out.append(f"risk {r.id} ({r.kind}, {r.severity}) awaits the user's decision")
    for rr in plan.mesh_plan.regions:
        if rr.role == "not_a_fluid_body":
            out.append(f"region {rr.id} is the solid wall, not a fluid body; the fluid must be extracted before meshing ({rr.reason[:80]})")
    if plan.purpose in ("internal_cfd", "conjugate_heat_transfer"):
        if not any(p.role == "inlet" for p in plan.patches) or not any(p.role == "outlet" for p in plan.patches):
            out.append("internal flow needs at least one inlet and one outlet patch")
    if plan.purpose == "external_cfd" and not any(p.role == "wall" for p in plan.patches):
        out.append("external flow needs a wall patch (the body)")
    return out


GENERIC_WALL_NAMES = {"walls", "wall", "body"}


def wall_patch_name(plan: GeometryPlan, facts: GeometryFacts | None = None) -> str:
    """The name the user gave the wall ('aircraft', 'casing') when the plan carries a named synthetic wall patch;
    otherwise Hexera's plain 'wall'."""
    opening_ids = {o.id for o in facts.openings} if facts is not None else set()
    for p in plan.patches:
        if p.role in ("wall", "closed_end") and p.id not in opening_ids and not re.fullmatch(r"o\d+", p.id) \
                and (p.name or p.id).lower() not in GENERIC_WALL_NAMES and p.id.lower() not in GENERIC_WALL_NAMES:
            return p.name or p.id
    return "wall"


#: The boundaries a purpose has whatever the file measures, and whatever the plan happens to list (P4.4). A CAD
#: file carries faces, not boundary conditions: the wall of an internal case is every surface that is not a port,
#: and an external case's far field is the outer box the builder creates from `domain_declaration`'s
#: `requested_extents`. Neither is a face the model could name and neither is a decision it makes, so the
#: translation names them rather than waiting for the plan to. Evidenced by the export answer key, which is the
#: patch list the platform's own intake produced: all 261 internal cases {inlet, outlet, wall}, all 61 external
#: cases {wall, farfield} (eval/jobs/build_export_key.py). conjugate_heat_transfer takes internal's wall by the
#: same reading `blockers` makes of it; structural is left out for want of a key.
GUARANTEED_PATCHES: dict[str, tuple[str, ...]] = {
    "internal_cfd": ("wall",),
    "conjugate_heat_transfer": ("wall",),
    "external_cfd": ("wall", "farfield"),
}


def intake_patches(plan: GeometryPlan, facts: GeometryFacts | None = None) -> list[dict[str, str]]:
    """`patches[{name, type}]` in the purpose's role vocabulary. Every opening with a wall-like role folds into
    the single wall patch Hexera's port binder wants, under the user's own wall name when the brief gave one;
    ports keep their own mesh-safe names; the far field is 'farfield'.

    The purpose's guaranteed boundaries (`GUARANTEED_PATCHES`) are named whether or not the plan listed a patch
    for them, because the file has no face for them to be listed from: an external case's far field is created
    by the builder, and the wall is whatever is left when the ports are taken out. A plan that does name one
    keeps its own name and its own row."""
    roles = _ROLE_MAP[plan.purpose]
    taken: set[str] = set()
    out: list[dict[str, str]] = []
    wall_added = False
    wall_name = wall_patch_name(plan, facts)
    for p in plan.patches:
        t = roles.get(p.role)
        if t is None:
            continue
        if t in ("wall", "free"):
            if not wall_added:
                out.append({"name": mesh_safe_name(wall_name if t == "wall" else "body", taken, reserved=False), "type": t})
                wall_added = True
            continue
        if t in ("farfield", "external"):
            out.append({"name": mesh_safe_name(p.name or p.id, taken, reserved=False), "type": t})
            continue
        out.append({"name": mesh_safe_name(p.name or p.id, taken), "type": t})
    have = {row["type"] for row in out}
    for t in GUARANTEED_PATCHES.get(plan.purpose, ()):
        if t not in have:
            out.append({"name": mesh_safe_name(wall_name if t == "wall" else t, taken, reserved=False), "type": t})
    return out


def representation_of(plan: GeometryPlan, facts: GeometryFacts, brief: str | None = None) -> str:
    """What the file is, in the catalog's words: the plan's own region roles decide a wall shell, the purpose
    decides external, and the catalog reads the rest (fluid_domain, annular_fluid, unknown)."""
    if any(r.role == "wall_shell" for r in plan.mesh_plan.regions):
        return "wall_shell"
    if plan.purpose == "external_cfd":
        return "external"
    rep = catalog.representation(facts, plan.purpose, brief)
    return "fluid_domain" if rep in ("unknown", "external") else rep


def corpus_representation(representation: str) -> str:
    """The corpus export's word for a representation (carve, fluid_domain, external), the key the calibration
    tables are indexed by."""
    return {"wall_shell": "carve", "annular_fluid": "fluid_domain", "unknown": "fluid_domain"}.get(representation, representation)


def port_declaration(plan: GeometryPlan, facts: GeometryFacts, unit: str) -> list[dict[str, Any]]:
    """Inlet and outlet rows in millimetres, with a location whenever two ports of one role are within a 5/3
    area ratio, so `_validate_internal_ports` and `bind_ports` accept them without a follow-up question. Every
    row carries `near_mm` (the binder's hint) and both `role` and `type` (intake patches and the approved
    intent spell the same field differently: port_binding.py:48 reads `type`, admission_token.py:164 either)."""
    scale_mm = UNIT_TO_M[unit] * 1000.0
    taken: set[str] = set()
    rows = []
    for p in plan.patches:
        if p.role not in ("inlet", "outlet") or p.id not in {o.id for o in facts.openings}:
            continue
        o = facts.opening(p.id)
        row: dict[str, Any] = {"name": mesh_safe_name(p.name or p.id, taken), "role": p.role, "type": p.role,
                               "near_mm": [round(c * scale_mm, 3) for c in o.centroid]}
        if o.kind == "ring" and o.bore_diameter:
            # a pierced wall's port is its bore (with a centre body inside it, the annulus); an annular passage's
            # port is the ring face itself
            rep = "wall_shell" if any(r.role == "wall_shell" for r in plan.mesh_plan.regions) else "annular_fluid"
            if rep == "wall_shell" and not catalog.inner_caps(facts, o):
                row["diameter_mm"] = round(o.bore_diameter * scale_mm, 4)
            else:
                row["area_mm2"] = round(catalog.port_area(facts, o, rep) * scale_mm * scale_mm, 4)
        elif o.shape == "circle":
            row["diameter_mm"] = round(o.equivalent_diameter * scale_mm, 4)
        elif o.shape == "rectangle":
            row["width_mm"] = round(o.width * scale_mm, 4)
            row["height_mm"] = round(o.height * scale_mm, 4)
        else:
            row["area_mm2"] = round(o.area * scale_mm * scale_mm, 4)
        rows.append(row)
    return rows


def _declared_area_mm2(row: dict[str, Any]) -> float:
    if row.get("diameter_mm"):
        return math.pi * (row["diameter_mm"] / 2) ** 2
    if row.get("area_mm2"):
        return float(row["area_mm2"])
    return float(row.get("width_mm", 0.0)) * float(row.get("height_mm", 0.0))


def declaration_problems(rows: list[dict[str, Any]]) -> list[str]:
    """The checks Hexera's `_validate_internal_ports` (agents/intake/validation.py:246-340) would fail, run
    before handing over. These are intake refusals: one question in chat, never a dispatched run."""
    out = []
    for r in rows:
        if not PATCH_NAME.match(r["name"]):
            out.append(f"port {r['name']!r} is not mesh-safe")
        if r["name"] in RESERVED_PATCH_NAMES:
            out.append(f"port {r['name']!r} is a reserved name")
        forms = sum(1 for k in ("diameter_mm", "area_mm2") if r.get(k)) + (1 if r.get("width_mm") or r.get("height_mm") else 0)
        if forms > 1:
            out.append(f"port {r['name']!r} states more than one size form")
        if _declared_area_mm2(r) <= 0 and not r.get("near_mm"):
            out.append(f"port {r['name']!r} has neither a size nor a location")
    for i, a in enumerate(rows):
        for b in rows[i + 1:]:
            aa, bb = _declared_area_mm2(a), _declared_area_mm2(b)
            if aa <= 0 or bb <= 0:
                continue
            if max(aa, bb) / min(aa, bb) < MIN_DECLARED_AREA_SEPARATION and not (a.get("near_mm") and b.get("near_mm")):
                out.append(f"ports {a['name']!r} and {b['name']!r} are too close in size and lack locations")
    return out


def domain_declaration(plan: GeometryPlan, facts: GeometryFacts, unit: str) -> dict[str, Any]:
    """`requested_extents`, `reference_length_m` and `flow_axis` for an external case, from the plan's required
    extents and the body's streamwise length. Absent for internal purposes."""
    if plan.purpose != "external_cfd":
        return {}
    ext = {k: v for k, v in plan.mesh_plan.required_extents.items() if k in EXTENT_DIRECTIONS}
    axis = _flow_axis_signed(plan)
    L = max(facts.bbox.extent) * UNIT_TO_M[unit]
    multiples = {k: round(v * UNIT_TO_M[unit] / L, 3) for k, v in ext.items()} if L > 0 else {}
    return {"requested_extents": multiples, "reference_length_m": round(L, 6), "flow_axis": axis,
            "requirements_strict": False, "reference_length_source": "body_streamwise_extent"}


def engine_admission(plan: GeometryPlan, facts: GeometryFacts) -> dict[str, Any]:
    """Which Hexera engines can take this file, from the contracts in docs/hexera_vocabulary.md. Not a choice,
    a shortlist with the reason each engine is in or out."""
    multi = len(facts.regions) > 1
    verdict: dict[str, str] = {}
    if plan.purpose == "conjugate_heat_transfer":
        verdict["snappy_multiregion"] = "in: multiregion-volume from a solid assembly" if multi and facts.interfaces else \
            "out: needs at least two bodies sharing an interface"
        for e in ("cfmesh", "snappy", "gmsh", "vmtk"):
            verdict[e] = "out: single-region engine"
    elif plan.purpose == "structural":
        verdict["gmsh"] = "in: solid-body -> solid-volume" if facts.watertight else "out: surface is not closed"
        for e in ("cfmesh", "snappy", "vmtk", "snappy_multiregion"):
            verdict[e] = "out: flow engine"
    else:
        topology = "external" if plan.purpose == "external_cfd" else "internal"
        closed = facts.watertight
        for e in ("cfmesh", "snappy"):
            verdict[e] = f"in: body-surface -> fluid-volume, {topology}" if closed else "out: surface is not watertight"
        if plan.purpose == "external_cfd" and "symmetry" in {p.role for p in plan.patches}:
            verdict["cfmesh"] = "out: no symmetry plane support (snappy has it)"
        verdict["vmtk"] = ("in: internal, no self-intersection required" if topology == "internal" and closed
                           else "out: internal-only engine")
        verdict["gmsh"] = "in: fluid-domain -> fluid-volume" if closed else "out: surface is not closed"
        verdict["snappy_multiregion"] = "out: single fluid body"
    return {"admissible": sorted(e for e, v in verdict.items() if v.startswith("in")), "verdicts": verdict}


def default_engine(plan: GeometryPlan, brief: str | None = None) -> str:
    """Which renderer this case goes to: the engine the brief names, else the purpose's default.

    The brief is read first because the customer states it there and the checker already reads it that way
    (`grounding._channel_of` calls `catalog.engine_from_brief`). Without it the two disagree on every case whose
    brief says gmsh under a CFD purpose: the checker admits a `size` directive for gmsh and the block prints it
    under a snappy roster that has no `size` key, which is the one line the builder reads contradicting the one
    line the customer wrote. `bend_elbow_012_fluid` (docs/builder_directives.md 8.5) is exactly that case."""
    if brief:
        return catalog.engine_from_brief(brief, plan.purpose)
    return {"structural": "gmsh", "conjugate_heat_transfer": "snappy_multiregion"}.get(plan.purpose, "snappy")


def _regime(plan: GeometryPlan, representation: str) -> str:
    return "external" if (plan.purpose == "external_cfd" or representation == "external") else "internal"


# ---------------------------------------------------------------------------------------------------------------
# calibration and thresholds, when the learning loop has produced them; the renderer's own defaults otherwise
# ---------------------------------------------------------------------------------------------------------------
EMULATOR_BASIS_WORDS = ("estimate_builder_cells", "emulator", "arm A")


def _engine_correction(engine: str | None, representation: str) -> dict[str, Any] | None:
    """The PER-ENGINE multiplier from `learn.calibration.engine_cell_correction`, or None when that table says
    nothing about this engine.

    Why this is consulted before the per-representation one. The emulator's error is a property of the engine's
    own sizing rules, not of the representation: measured on the 132 learning cases that delivered a mesh, the
    same `external` representation under snappy runs at a delivered/forecast median of 1.84 with the middle 80
    percent inside 1.26 to 2.11, while `fluid_domain` under gmsh runs at a median of 1.69 with the middle 80
    percent spanning 0.13 to 101 (docs/cell_forecast_correction.md, section 3). Pooling those two into one
    representation figure would correct neither.

    A row is used only when the table ADMITTED it, and the table's own gates decide that (n from at least
    `MIN_RECORDS` geometries, the median's interval clear of 1.0, and the forecast measurably closer after). The
    basis gate below applies here too: this table names `estimate_builder_cells`, and a refit against any other
    estimator has to say so in `basis`, which turns the refusal back on.
    """
    try:
        from geometry_agent.learn import calibration
    except ImportError:
        return None
    if not hasattr(calibration, "engine_cell_correction_info"):
        return None
    try:
        info = dict(calibration.engine_cell_correction_info(engine, representation))
    except Exception:  # noqa: BLE001 - a calibration that cannot answer is the same as none
        return None
    if not info.get("n"):
        return None
    basis = str(info.get("basis") or "")
    multiplier = float(info.get("multiplier") or 1.0)
    if multiplier != 1.0 and basis and not any(w in basis for w in EMULATOR_BASIS_WORDS):
        return {"multiplier": 1.0, "representation": info.get("representation"), "engine": engine,
                "fitted": multiplier, "n": info.get("n"), "applied": False, "table": "engine_cell_correction",
                "basis": f"the per-engine multiplier {multiplier:g} was fitted against '{basis[:70]}', not the "
                         f"builder emulator; 1.0 applied"}
    return {"multiplier": multiplier, "representation": info.get("representation"), "engine": engine,
            "n": info.get("n"), "applied": bool(info.get("applied")), "median_ci": info.get("median_ci"),
            "dispersion_p90_over_p10": info.get("dispersion_p90_over_p10"),
            "within_raw": info.get("within_raw"), "within_corrected": info.get("within_corrected"),
            "table": "engine_cell_correction", "split": info.get("split"), "date": info.get("date"),
            "basis": f"{basis} (n {info.get('n')}): {info.get('why')}"}


def correction_info(representation: str, engine: str | None = None) -> dict[str, Any]:
    """The multiplier for the emulator's count and where it came from.

    Two tables, in this order. The per-engine one (`learn.calibration.engine_cell_correction`) is fitted against
    the emulator by construction and is consulted first whenever an engine is known; the per-representation one
    (`learn.calibration.cell_correction`, dev plan P2) is the older table and is applied only when it says it was
    fitted against the builder emulator (arm A), because a multiplier fitted against the facts layer's tier
    estimate (diagonal/80) corrects a DIFFERENT estimator. Either way the returned `basis` says which table
    answered, with the n behind it, so a corrected forecast can be told from a raw one after the fact.
    """
    rep = corpus_representation(representation)
    per_engine = _engine_correction(engine, rep) if engine else None
    if per_engine is not None:
        return per_engine
    try:
        from geometry_agent.learn import calibration
    except ImportError:
        return {"multiplier": 1.0, "representation": rep, "basis": "learn.calibration not importable; 1.0"}
    try:
        fitted = float(calibration.cell_correction(rep) or 1.0)
    except Exception:  # noqa: BLE001 - a calibration that cannot answer is the same as none
        return {"multiplier": 1.0, "representation": rep, "basis": "learn.calibration could not answer; 1.0"}
    basis = ""
    path = getattr(getattr(calibration, "store", None), "CELL_CORRECTION", None)
    try:
        if path is not None and Path(path).exists():
            basis = str(json.loads(Path(path).read_text(encoding="utf-8")).get("basis") or "")
    except Exception:  # noqa: BLE001
        basis = ""
    if fitted != 1.0 and basis and not any(w in basis for w in EMULATOR_BASIS_WORDS):
        return {"multiplier": 1.0, "representation": rep, "fitted": fitted,
                "basis": f"calibration multiplier {fitted:g} was fitted against '{basis[:70]}', not the builder emulator; 1.0 applied"}
    return {"multiplier": fitted, "representation": rep, "basis": basis or "learn.calibration.cell_correction"}


def cell_correction(representation: str, engine: str | None = None) -> float:
    """The multiplier `correction_info` allows here: 1.0 until a table admits one for this engine."""
    return float(correction_info(representation, engine)["multiplier"])


def _minutes_for_cells(cells: int) -> dict[str, Any] | None:
    """{typical, p90, n, bin} from geometry_agent.learn.calibration.minutes_for_cells when importable, else None."""
    try:
        from geometry_agent.learn.calibration import minutes_for_cells
    except ImportError:
        return None
    try:
        out = minutes_for_cells(int(cells))
    except Exception:  # noqa: BLE001
        return None
    if isinstance(out, dict):
        return out
    if isinstance(out, (list, tuple)) and len(out) >= 2:
        return {"typical": out[0], "p90": out[1], "n": out[2] if len(out) > 2 else None}
    return None


def _port_cells_min() -> float:
    """The floor of builder cells across the smallest port: thresholds.PORT_CELLS_MIN when the governed
    thresholds exist (dev plan P2), the catalog's placeholder until then."""
    try:
        from geometry_agent.agent import thresholds
    except ImportError:
        return float(catalog.PORT_CELLS_MIN)
    table = thresholds.current() if hasattr(thresholds, "current") else getattr(thresholds, "DEFAULTS", None)
    value = getattr(table, "PORT_CELLS_MIN", None) if table is not None else getattr(thresholds, "PORT_CELLS_MIN", None)
    return float(value) if value else float(catalog.PORT_CELLS_MIN)


#: R37. `tools.first_cell_of` returns `y1 = yplus * nu / u_tau`: the WALL DISTANCE at which the target y+ is
#: evaluated, which its own formula string ends by saying ("a cell-centred code puts the first centre at half this
#: height"). A layer target's `first_cell_height` is that number, cited from the derivation. The builder is given a
#: layer THICKNESS, and a cell-centred code puts the centre at half of it, so the thickness that puts the centre at
#: y1 is 2 y1. Nothing applied the factor until now and every layered plan delivered half the y+ it stated (median
#: ratio 0.50 over the 103 layered internal cases of the learning-half v3 run).
CENTRE_TO_CELL = 2.0


def first_layer_rel_outer(first_cell: float | None, n_layers: int, wall_cell: float, regime: str = "internal") -> dict[str, Any]:
    """The planner's first_layer_rel is snappy's finalLayerThickness under relativeSizes true (snappy_runner.py:685-686
    and :539-540; authoring.py:22 "outer layer thickness vs local cell"): the OUTER layer over the local wall cell.

    `first_cell` is the plan's `first_cell_height`, the wall distance the y+ target is evaluated at (the tool's own
    `first_cell_height`, and the first cell's CENTRE). The first cell's own height is `CENTRE_TO_CELL` times it; the
    outer layer is that grown n-1 times by expansionRatio 1.2, over the builder's wall cell, clamped to the
    planner's band. `delivered_first_cell` and `delivered_yplus_ratio` report what the clamp then does: the ratio is
    the y+ the builder will deliver over the y+ the plan sized for, 1.0 when nothing clamps."""
    lo, hi = FIRST_LAYER_REL_BAND[regime]
    default = tools.BUILDER_FIRST_LAYER_REL[regime]
    if not first_cell or first_cell <= 0 or not wall_cell or wall_cell <= 0 or n_layers <= 0:
        return {"value": default, "raw": None, "outer_layer": None, "first_cell": first_cell, "wall_cell": wall_cell,
                "first_layer_thickness": None, "delivered_first_cell": None, "delivered_yplus_ratio": None,
                "clamped": False, "basis": "builder default (drivers.py:580 internal 0.3, snappy_runner.py:501 external 0.35)"}
    growth = LAYER_EXPANSION ** (n_layers - 1)
    thickness = CENTRE_TO_CELL * float(first_cell)
    outer = thickness * growth
    raw = outer / float(wall_cell)
    value = round(min(hi, max(lo, raw)), 3)
    delivered = value * float(wall_cell) / growth
    return {"value": value, "raw": round(raw, 4), "outer_layer": outer, "first_cell": float(first_cell),
            "wall_cell": float(wall_cell), "first_layer_thickness": thickness,
            "delivered_first_cell": delivered, "delivered_yplus_ratio": round(delivered / thickness, 4),
            "clamped": abs(value - raw) > 1e-3,
            "basis": (f"first cell height = {CENTRE_TO_CELL:g} x the plan's first_cell_height (the y+ wall distance is the "
                      f"cell centre); outer layer = that x 1.2**(n-1) over the wall cell, clamped to {lo}..{hi} (planner.py)")}


def layer_clamp_note(layer: dict[str, Any], regime: str) -> str | None:
    """What the planner's band costs the y+ target, when it costs anything: the delivered first cell against the
    one the plan sized, and the ratio the delivered y+ lands at. None when the raw ratio is inside the band."""
    ratio = layer.get("delivered_yplus_ratio")
    if ratio is None or abs(float(ratio) - 1.0) <= 0.05:
        return None
    lo, hi = FIRST_LAYER_REL_BAND[regime]
    return (f"first cell clamped: first_layer_rel {layer['raw']:.4g} is outside the planner's band {lo:g} to {hi:g}, so the "
            f"builder's first cell is {layer['delivered_first_cell']:.4g} where the plan sized {layer['first_layer_thickness']:.4g} "
            f"and the delivered y+ is {float(ratio):.2f}x the target")


def budget(estimate_high: int, representation: str, cell_cap: int | None = None,
           engine: str | None = None) -> dict[str, Any]:
    """max_cells = min(the user's cap, the corrected forecast). The forecast is the emulator's high figure times
    the correction `correction_info` admits for this engine and representation; the builder's 15 percent margin
    (planner.py:69) is the room the strategy keeps between the corrected forecast and the cap, so the request
    never sits on the cap."""
    cap = int(cell_cap) if cell_cap else MAX_CELLS_CAP
    corr = cell_correction(representation, engine)
    corrected = int(max(0, estimate_high) * corr)
    return {"max_cells": max(1, min(cap, corrected)) if corrected > 0 else cap, "corrected_estimate": corrected,
            "correction": corr, "cap": cap, "under_margin": corrected <= (1.0 - BUILDER_MARGIN) * cap}


def forecast(facts: GeometryFacts, strategy: dict | None, representation: str, engine: str,
             cell_cap: int | None = None, inlet_id: str | None = None) -> dict[str, Any]:
    """The dev plan's forecast block: cells_low and cells_high from the emulator times the correction, the
    minutes bin, minutes from learn.calibration when it exists (null otherwise), passes expected likewise.

    THE RAW FIGURES STAY IN THE BLOCK. `cells_low_raw` and `cells_high_raw` are the emulator's own numbers before
    the multiplier and `correction` carries the multiplier with its n, its interval and the words that admitted
    it. A reader six months from now can divide one by the other and see exactly which forecast it is holding;
    without them a corrected number and a raw number are the same integer with no way to tell them apart, which
    is the whole reason the correction is worth having and the one thing that could make it worse than nothing.
    """
    est = tools.estimate_builder_cells(facts, strategy, representation, engine, inlet_id=inlet_id)
    info = correction_info(representation, engine)
    corr = float(info["multiplier"])
    low, high = int(est["cells_low"] * corr), int(est["cells_high"] * corr)
    tier = "under 0.5M" if high < 500_000 else "0.5 to 1M" if high < 1_000_000 else "1 to 2M" if high < 2_000_000 else "over 2M"
    minutes = _minutes_for_cells(high)
    basis = list(est["basis"]) + [f"correction x{corr:g} for {engine}/{info['representation']}: {info['basis']}"]
    if minutes is None:
        basis.append("minutes: learn.calibration.minutes_for_cells not available, null")
    cap = int(cell_cap) if cell_cap else None
    return {"cells_low": low, "cells_high": high, "tier": tier,
            "cells_low_raw": int(est["cells_low"]), "cells_high_raw": int(est["cells_high"]),
            "correction": {k: v for k, v in info.items() if k != "basis"} | {"basis": info["basis"],
                                                                            "corrected": corr != 1.0},
            "minutes_typical": minutes.get("typical") if minutes else None,
            "minutes_p90": minutes.get("p90") if minutes else None,
            "passes_expected": minutes.get("passes_expected") if minutes else None,
            "over_cap": (high > cap) if cap else None, "cell_cap": cap,
            "basis": basis, "breakdown": est["breakdown"],
            # WHO CHOSE THE MOUTH THIS SIZED FROM. `builder.inlet_id` is set either way: given a binding it is
            # that opening, and given none `tools.builder_inlet` falls back to the widest planar mouth and
            # reports ITS id. So a reader cannot tell a person's inlet from the emulator's own pick, and
            # `contract.build` read a non-empty id as proof a person had named one: on a block with no declared
            # ports and both role questions skipped, the builder was told "opening o1, the largest mouth the
            # customer called the inlet" when nobody had called anything. `inlet_id` here is the person's one or
            # None (`report_measured`), so this flag is the distinction itself and not a second guess at it.
            "builder": {**{k: v for k, v in est["builder"].items() if k != "ports"},
                        "inlet_from_person": bool(inlet_id)}}


# ---------------------------------------------------------------------------------------------------------------
# the strategy header: the planner's own keys, one clause of why each, under 500 characters
# ---------------------------------------------------------------------------------------------------------------
def _fmt(v: Any) -> str:
    if isinstance(v, bool):
        return str(v).lower()
    if isinstance(v, float):
        return f"{v:.4g}"
    if isinstance(v, dict):
        return "{" + ", ".join(f"{k} {_fmt(x)}" for k, x in v.items()) + "}"
    if isinstance(v, (list, tuple)):
        return "[" + ", ".join(_fmt(x) for x in v) + "]"
    return str(v)


def _short(n: float) -> str:
    return f"{n / 1e6:.2g}M" if n >= 1e6 else f"{n / 1e3:.0f}k"


def _render_header(label: str, keys: dict[str, Any], why: dict[str, str], limit: int = HEADER_MAX_CHARS) -> str:
    """One line per key, `key value: why`, joined by '; ', never over `limit`: clauses are dropped from the end
    first, then the whole text is cut."""
    reasons = dict(why)
    while True:
        text = f"BUILDER HEADER ({label}) " + "; ".join(f"{k} {_fmt(v)}" + (f": {reasons[k]}" if reasons.get(k) else "")
                                                        for k, v in keys.items())
        if len(text) <= limit:
            return text
        dropped = next((k for k in reversed(list(keys)) if reasons.get(k)), None)
        if dropped is None:
            return text[:limit]
        reasons[dropped] = ""


def _plan_layers(plan: GeometryPlan) -> tuple[int, float | None]:
    mp = plan.mesh_plan
    n = max((lt.n_layers for lt in mp.layer_targets), default=0)
    first = min((lt.first_cell_height for lt in mp.layer_targets if lt.n_layers > 0), default=None)
    return n, first


def _internal_strategy(plan: GeometryPlan, facts: GeometryFacts, rep: str, cap: int, engine: str) -> dict[str, Any]:
    inlet_id = next((i for i in plan.flow.inlet_ids if facts.opening(i) is not None), None)
    frame = tools.builder_frame(facts, rep, inlet_id=inlet_id)
    floor = _port_cells_min()
    bore = frame["bore"]
    smallest = frame["smallest_port"]
    need = int(math.ceil(floor * bore / smallest["min_dimension"])) if (smallest and smallest["min_dimension"] > 0 and bore > 0) else tools.BUILDER_CELLS_ACROSS_DEFAULT
    cells_across = max(tools.BUILDER_CELLS_ACROSS_DEFAULT, need)
    n_plan, first = _plan_layers(plan)
    n_layers = min(n_plan, N_LAYERS_MAX["internal"]) if n_plan > 0 else 0
    notes: list[str] = []
    strategy = {"cells_across_diameter": cells_across, "surface_level": tools.BUILDER_SURFACE_LEVEL_DEFAULT,
                "feature_level": tools.BUILDER_SURFACE_LEVEL_DEFAULT + 1, "n_layers": n_layers, "quality": "balanced",
                "max_cells": cap}
    est = tools.estimate_builder_cells(facts, strategy, rep, "snappy", inlet_id=inlet_id)
    b = budget(est["cells_high"], rep, cap, "snappy")
    # walk cells_across down, never below the driver's floor of 8, until the corrected forecast leaves the margin
    while not b["under_margin"] and cells_across > tools.BUILDER_CELLS_ACROSS_MIN:
        cells_across = max(tools.BUILDER_CELLS_ACROSS_MIN, min(cells_across - 1, int(cells_across * 0.9)))
        strategy["cells_across_diameter"] = cells_across
        est = tools.estimate_builder_cells(facts, strategy, rep, "snappy", inlet_id=inlet_id)
        b = budget(est["cells_high"], rep, cap, "snappy")
    wall_cell = bore / cells_across if bore > 0 else 0.0
    layer = first_layer_rel_outer(first, n_layers, wall_cell, "internal")
    clamp_note = layer_clamp_note(layer, "internal")
    if clamp_note:
        notes.append(clamp_note)
    strategy["first_layer_rel"] = layer["value"]
    strategy["max_cells"] = b["max_cells"]
    smallest_cells = (smallest["min_dimension"] / wall_cell) if (smallest and wall_cell > 0) else None
    why = {
        "cells_across_diameter": (f"smallest port {smallest['id']} gets {smallest_cells:.0f} wall cells (floor {floor:g})"
                                  if smallest_cells is not None else "planner default"),
        "surface_level": f"wall cell {_fmt(wall_cell)} = bore/{cells_across}, level sets the background only",
        "feature_level": "rims one level finer than the wall",
        "n_layers": f"plan's wall layers{' capped at the planner band' if n_plan > N_LAYERS_MAX['internal'] else ''}" if n_layers else "no layers in the plan",
        "first_layer_rel": (f"outer layer over wall cell, first cell {_fmt(layer['first_cell'])} x1.2^{max(n_layers - 1, 0)}"
                            + (" clamped" if layer["clamped"] else "")) if layer["raw"] is not None else "builder default",
        "quality": "start balanced, strict only after measured skew",
        "max_cells": f"forecast {_short(b['corrected_estimate'])} vs cap {_short(cap)}" + ("" if b["under_margin"] else " over the 15% margin at the floor"),
    }
    if smallest_cells is not None and smallest_cells + 1e-9 < floor:
        notes.append(f"port floor unmet: {smallest['id']} gets {smallest_cells:.1f} builder cells across {_fmt(smallest['min_dimension'])} "
                     f"at cells_across {cells_across}; the cap {cap} does not allow the floor of {floor:g}")
        why["cells_across_diameter"] = f"cap-limited: smallest port {smallest['id']} gets {smallest_cells:.0f} cells, floor {floor:g} unmet"
    if not b["under_margin"]:
        notes.append(f"corrected forecast {b['corrected_estimate']} exceeds {1 - BUILDER_MARGIN:.2f} x cap {cap} at the driver's floor of "
                     f"{tools.BUILDER_CELLS_ACROSS_MIN} cells across")
    keys = {k: strategy[k] for k in PLANNER_INTERNAL_KEYS}
    label = "snappy internal" if engine == "snappy" else engine
    return {"engine": engine, "regime": "internal", "keys": keys, "why": why, "estimate": est, "budget": b,
            "layer": layer, "frame": frame, "notes": notes, "header": _render_header(label, keys, why)}


def _external_strategy(plan: GeometryPlan, facts: GeometryFacts, rep: str, cap: int, unit: str) -> dict[str, Any]:
    mp = plan.mesh_plan
    ext = [float(v) for v in facts.bbox.extent]
    L = max(ext)
    axis = _flow_axis_signed(plan)
    ref = ext["xyz".index(axis[1])] if axis else L
    ref = ref or L
    req = mp.required_extents
    margins = {"up": req.get("upstream", 5 * L) / ref, "down": req.get("downstream", 15 * L) / ref,
               "side": req.get("lateral", 5 * L) / ref, "vert": req.get("vertical", req.get("lateral", 5 * L)) / ref}
    margins = {k: round(max(v, tools.EXTERNAL_VERT_FLOOR if k == "vert" else 0.0), 2) for k, v in margins.items()}
    n_plan, first = _plan_layers(plan)
    n_layers = min(n_plan, N_LAYERS_MAX["external"]) if n_plan > 0 else 0
    strategy: dict[str, Any] = {"domain_margin": margins, "n_layers": n_layers, "quality": "balanced", "max_cells": cap, "flow_axis": axis}
    est = tools.estimate_builder_cells(facts, strategy, "external", "snappy")
    b = budget(est["cells_high"], "external", cap, "snappy")
    notes: list[str] = []
    # max_cells drives the affordable level (analysis.py:173-175): lower the request until the forecast fits
    request = cap
    while not b["under_margin"] and request > PLANNER_BUDGET_FLOOR:
        request = max(PLANNER_BUDGET_FLOOR, int(request * (1.0 - BUILDER_MARGIN)))
        strategy["max_cells"] = request
        est = tools.estimate_builder_cells(facts, strategy, "external", "snappy")
        b = budget(est["cells_high"], "external", cap, "snappy")
    wall_cell = float(est["builder"].get("wall_cell") or 0.0)
    layer = first_layer_rel_outer(first, n_layers, wall_cell, "external")
    clamp_note = layer_clamp_note(layer, "external")
    if clamp_note:
        notes.append(clamp_note)
    # THE TWO LEVELS THE EXTERNAL RENDERER READS AND THIS ROW DID NOT STATE. `render_snappy_case` reads
    # `strategy["surface_level"]` (snappy_runner.py:448) and `strategy["feature_level"]` (:451), so a block
    # naming six keys was telling the builder about six of the eight settings it is about to use, and
    # `builder_keys_block`'s "every setting the builder reads" was false on this regime.
    #
    # THE VALUES ARE THE RECOMMENDER'S OWN, NOT THE AGENT'S, AND THEY CHANGE NOTHING. The renderer's level with
    # nothing stated is `rec["surface_level"] + deficit`; stating `rec["surface_level"]` gives
    # `max(floor, min(rec + deficit, ceil))`, which is that same floor, so this is a fixed point rather than
    # an override. Stating the emulator's final `feature_level` is a fixed point for the same reason
    # (`min(stated, rec_feature)` is `rec_feature` whenever the stated value is the clamped one). So the
    # roster is complete and the mesh is byte for byte the mesh it was: the agent declares what the builder
    # will do here rather than choosing it, which is the honest entry for a key whose floor is a number about
    # the part and not a value anybody picked.
    #
    # SURFACE LEVEL IS A PAIR ON THIS PATH. External reads `int(so[-1])`, which RAISES on a bare number, while
    # internal takes either (drivers.py:665). Both entries are the recommender's floor because only the last
    # is read and inventing a different first entry would be stating a band nobody measured.
    rec_level = int(est["builder"].get("recommended_surface_level") or est["builder"]["surface_level"])
    keys = {"domain_margin": margins, "reference_length_m": round(ref * UNIT_TO_M[unit], 6),
            "surface_level": [rec_level, rec_level],
            "feature_level": int(est["builder"]["feature_level"]), "n_layers": n_layers,
            "first_layer_rel": layer["value"], "quality": "balanced", "max_cells": min(b["max_cells"], request)}
    why = {
        "domain_margin": f"plan extents over the {'flow-axis' if axis else 'longest'} extent {_fmt(ref)}",
        "reference_length_m": f"body extent along {axis or 'the longest axis'} in metres",
        "surface_level": "the recommender's own body-sealing floor for this part, restated so the block names "
                         "every setting the builder reads; not an override",
        "feature_level": "the level the renderer clamps the recommender's feature level to; not an override",
        "n_layers": f"plan's wall layers{' capped at the planner band' if n_plan > N_LAYERS_MAX['external'] else ''}" if n_layers else "no layers in the plan",
        "first_layer_rel": (f"outer layer over wall cell {_fmt(wall_cell)}, first cell {_fmt(layer['first_cell'])} x1.2^{max(n_layers - 1, 0)}"
                            + (" clamped" if layer["clamped"] else "")) if layer["raw"] is not None else "builder default",
        "quality": "start balanced, strict only after measured skew",
        "max_cells": f"forecast {_short(b['corrected_estimate'])} at level {est['builder']['surface_level']} vs cap {_short(cap)}",
    }
    if not b["under_margin"]:
        notes.append(f"corrected forecast {b['corrected_estimate']} exceeds {1 - BUILDER_MARGIN:.2f} x cap {cap} at the planner's budget floor")
    return {"engine": "snappy", "regime": "external", "keys": keys, "why": why, "estimate": est, "budget": b,
            "layer": layer, "frame": None, "notes": notes, "header": _render_header("snappy external", keys, why)}


def _gmsh_strategy(plan: GeometryPlan, facts: GeometryFacts, rep: str, cap: int) -> dict[str, Any]:
    floor = _port_cells_min()
    diag = float(facts.bbox.diagonal) or 1.0
    ports = catalog.port_openings(facts, tools._rep_key(rep)) if rep != "external" else []
    d_min = min((tools.port_min_dimension(o) for o in ports), default=0.0)
    factor = tools.GMSH_SIZE_FACTOR
    why_size = "gmsh default 0.04 x diagonal"
    if d_min > 0:
        factor = round(min(tools.GMSH_SIZE_FACTOR, d_min / floor / diag), 5)
        why_size = f"h = smallest port {_fmt(d_min)} / {floor:g} elements = {_fmt(factor * diag)}"
    keys = {"size": {"mode": "factor", "value": factor}, "curvature_nodes": tools.GMSH_CURVATURE_NODES}
    est = tools.estimate_builder_cells(facts, keys, rep, "gmsh")
    b = budget(est["cells_high"], rep, cap, "gmsh")
    why = {"size": why_size, "curvature_nodes": f"driver default; forecast {_short(b['corrected_estimate'])} tets vs cap {_short(cap)}"}
    return {"engine": "gmsh", "regime": "gmsh", "keys": keys, "why": why, "estimate": est, "budget": b, "layer": None,
            "frame": None, "notes": [], "header": _render_header("gmsh", keys, why)}


def builder_strategy(plan: GeometryPlan, facts: GeometryFacts, engine: str | None = None, cell_cap: int | None = None,
                     representation: str | None = None, unit: str | None = None, brief: str | None = None) -> dict[str, Any]:
    """The strategy the header states, in the planner's own keys, with the emulator's forecast behind every number:
    internal snappy (cells_across_diameter, surface_level, feature_level, n_layers, first_layer_rel, quality,
    max_cells), external snappy (domain_margin, reference_length_m, n_layers, first_layer_rel, quality, max_cells)
    and gmsh (size {mode, value}, curvature_nodes). cells_across is chosen so the smallest port's min in-plane
    dimension gets at least PORT_CELLS_MIN builder cells, then lowered toward the driver's floor of 8 until the
    corrected forecast sits under the cap by the builder's 15 percent margin; max_cells is min(cap, forecast)."""
    rep = representation or representation_of(plan, facts, brief)
    engine = engine or default_engine(plan, brief)
    cap = int(cell_cap) if cell_cap else MAX_CELLS_CAP
    unit = unit or plan.unit.assumed
    if engine == "gmsh":
        return _gmsh_strategy(plan, facts, rep, cap)
    if _regime(plan, rep) == "external":
        return _external_strategy(plan, facts, rep, cap, unit)
    return _internal_strategy(plan, facts, rep, cap, engine)


def strategy_header(plan: GeometryPlan, facts: GeometryFacts, engine: str | None = None, cell_cap: int | None = None,
                    representation: str | None = None, unit: str | None = None) -> str:
    """The header as text: at most HEADER_MAX_CHARS characters in the planner's keys with one clause of why each."""
    return builder_strategy(plan, facts, engine, cell_cap, representation, unit)["header"]


# ---------------------------------------------------------------------------------------------------------------
# the builder directives: what the builder is told to do, in keys the renderer reads, priced against the cap
#
# The builder-facing list used to be written as a prediction of failure. A prediction is something the builder
# can only disagree with; an instruction is something it can carry out. Every item below answers four questions
# and nothing else: WHERE (an opening id, a patch, a measured point), WHAT TO DO (a key and a value in the
# planner's own vocabulary), WHAT IT COSTS (cells, against the customer's cap), and WHY (the measurement that
# makes it worth doing). No item says what the finished mesh is going to be like, because nothing here knows.
#
# The design and every number behind it is docs/builder_directives.md, written against PLATFORM_SHA.
# ---------------------------------------------------------------------------------------------------------------

#: engines/snappy/planner.py:186 cuts `request_txt` at this many characters before the planner sees it.
#: Everything past it is not read, on the first pass and on each of the 14 possible re-plans.
REQUEST_TXT_READ = 2000
#: The plan block's own character budget, sized per case from what the request text leaves of REQUEST_TXT_READ.
#: 700 is the widest block that still leaves the median brief's quantitative lines inside the read (measured on
#: the 322 corpus briefs, docs/builder_directives.md section 5); 320 is the floor at which the label line and the
#: key roster still fit, so a long request costs the builder evidence and never a key; 40 is the blank line and
#: the separator the assembly puts between the block and the request.
BLOCK_BUDGET_MAX, BLOCK_BUDGET_MIN, BLOCK_BUDGET_SLACK = 700, 320, 40

#: The vocabulary itself lives in `catalog.DIRECTIVE_KEYS`, `catalog.CONDITIONAL_TRIGGERS`,
#: `catalog.OUTCOME_WORDS`, `catalog.ATTENTION` and `catalog.DIRECTIVE_PRICE_FRACTION`, which the content half of
#: this pass owns. Nothing here restates it: two tables of the same bands are two tables that can disagree, and
#: the one that gets edited is never the one a reader checks. This module owns the ARRIVAL - which items are
#: admitted, how they rank, what the block says, how it degrades and what it costs the customer's own request -
#: and reads the vocabulary through the helpers below.


def platform_reads(regime: str) -> tuple[str, ...]:
    """The keys the renderer reads for this regime, in the order the planner declares them."""
    return tuple(catalog.DIRECTIVE_KEYS.get(regime) or ())


def renderer_default(regime: str, key: str) -> Any:
    """What the renderer does with this key when the request says nothing, which is the counterfactual every
    `cost_cells` is measured against: what the builder does if the instruction is not sent.

    THE `size` WRAP STAYS, and it is not the same thing as `_key_problem`'s unwrap, which is gone. The catalog
    row states gmsh's default as the bare factor 0.04 because that is the number
    `engines/gmsh/driver.py:258` reads. This function's one caller feeds what it returns straight into the
    emulator (`builder_plan_block.price` -> `tools.estimate_builder_cells`), and the emulator reads
    `size.get("value")` and `size.get("mode")` (tools.py:3112-3113), so a bare float there is an
    AttributeError and no pricing at all. The wrap is what makes the counterfactual runnable.
    """
    row = (catalog.DIRECTIVE_KEYS.get(regime) or {}).get(key) or {}
    value = row.get("default")
    if key == "size" and isinstance(value, (int, float)):
        return {"mode": "factor", "value": float(value)}
    return value


#: Which tier a key sits in when nothing about the case says otherwise (`catalog.DIRECTIVE_TIERS`). T0 guards
#: cost nothing and lose the whole run when wrong, so they are always in the roster and first in the ranking. T1
#: is a floor: a measured feature under a stated minimum, or a value the customer stated outright. T2 is a margin
#: on a feature already over its floor, and only T2 pays `catalog.price_admits`. The tier follows the unmet
#: floor, never the key, so `surface_level` moves to T1 when a tilted mouth puts the port cap under the wall.
KEY_TIER: dict[str, str] = {
    "max_cells": "T0", "quality": "T0", "domain_margin": "T0", "reference_length_m": "T0",
    "cells_across_diameter": "T1", "first_layer_rel": "T1", "n_layers": "T1", "size": "T1",
    "surface_level": "T2", "feature_level": "T2", "curvature_nodes": "T2",
}
TIER_ORDER = {t: n for n, t in enumerate(catalog.DIRECTIVE_TIERS)}

#: Every OLDER `schema.MeshTarget` field against the key that carries it for a regime, or None when no reader
#: exists at PLATFORM_SHA. Schema 3 now states the instruction as `target.key` and `target.value`, which
#: `catalog.directive_problem` judges directly; this map is what reads the 361 targets of the last recorded run,
#: which were written before that field existed, and it is the only way the "can a builder act on this" number
#: can be computed over the history rather than over the present.
#:
#: `level_delta` on the internal path is the entry this audit changed: the renderer sets
#: `port_level = max(1, smin - 1)` (snappy_runner.py:636) and `smin = min(10, surface_level + deficit)` (:634),
#: so `surface_level 1` at `deficit == 0` puts the port cap at the wall level, which is what `level_delta 0`
#: asks for. It is reachable today through a key already inside the planner's declared band, and `target_reach`
#: says so only when the emulator reports the background clamp cost nothing.
TARGET_READERS: dict[str, dict[str, str | None]] = {
    "snappy_internal": {"cells_across": "cells_across_diameter", "max_cells": "max_cells", "layers": "n_layers",
                        "level_delta": "surface_level", "sphere": None, "box": None, "extension_length": None,
                        "seed_point": None, "gmsh_size_value": None},
    "snappy_external": {"cells_across": None, "max_cells": "max_cells", "layers": "n_layers", "level_delta": None,
                        "sphere": None, "box": None, "extension_length": None, "seed_point": None,
                        "gmsh_size_value": None},
    "snappy_multiregion": {"cells_across": None, "max_cells": "max_cells", "layers": "n_layers",
                           "level_delta": None, "sphere": None, "box": None, "extension_length": None,
                           "seed_point": None, "gmsh_size_value": None},
    "gmsh": {"cells_across": None, "max_cells": "max_cells", "layers": None, "level_delta": None, "sphere": None,
             "box": None, "extension_length": None, "seed_point": None, "gmsh_size_value": "size"},
}
#: The dev plan step that would give an unreadable target a reader, and what it costs there (section 9). A field
#: with no entry has no planned reader at all, and saying so is what sends the item to the user's list or to the
#: session report instead of the builder's.
TARGET_HOOK: dict[str, str] = {
    "seed_point": "8.3 initial-plan hook (about 60 lines, one platform day)",
    "level_delta": "8.3 the port level knob, independent of the background",
    "sphere": "8.3 plus authored refinementRegions (about 40 lines, half a day)",
    "box": "8.3 plus authored refinementRegions (about 40 lines, half a day)",
    "extension_length": "8.8 a new geometry source (about 150 lines, three days, gated on P10)",
}


def block_budget(request_txt: str | None, *, hard_cap: int = BLOCK_BUDGET_MAX, floor: int = BLOCK_BUDGET_MIN) -> int:
    """How many characters the plan block may spend on this case.

    The planner reads `request_txt[:2000]` and nothing else (planner.py:186), so every character the block spends
    is a character of the customer's own request the planner does not read. The rule is therefore not a constant:
    it is what the request leaves, bounded above by 700, past which the block starts displacing lines it does not
    restate, and below by 320, the label plus the key roster, so a long request costs the builder evidence and
    never a key.

    `request_txt` is the platform's own `state["request_txt"]`, the intake model's 4-to-10-sentence summary
    (agents/intake/agent.py:258, floor 80 characters at validation.py:410), not the user's pasted brief. That
    summary is recorded nowhere in the corpus export, so the numbers in docs/builder_directives.md section 5 are
    measured on the brief, which is the text intake is told to summarise and to word identically for every
    quantitative criterion. Pass the real thing where there is one; the brief is the honest stand-in."""
    if not request_txt:
        return hard_cap
    return int(min(hard_cap, max(floor, REQUEST_TXT_READ - len(str(request_txt)) - BLOCK_BUDGET_SLACK)))


def regime_key(engine: str | None, representation: str | None, purpose: str | None = None) -> str:
    """Which renderer reads this case: `catalog.regime_of` with the representation word normalised first and the
    purpose allowed to settle it, because a plan can carry `external_cfd` with a representation the facts named.
    `snappy_multiregion` is this module's own row; the catalog does not carry one and the keys come from
    `MULTIREGION_KEYS`."""
    eng = (engine or "snappy").lower()
    if eng == "snappy_multiregion":
        return "snappy_multiregion"
    rep = corpus_representation(representation or "")
    if purpose == "external_cfd":
        rep = "external"
    return catalog.regime_of(eng, rep)


def target_reach(target: Any, regime: str, *, deficit: int | None = None) -> dict[str, Any]:
    """Can a builder carry this target out with what it receives?

    `reachable`: every field the target names is carried by a key the renderer reads for this regime.
    `hook`: at least one field has no reader today and a named dev plan step would give it one.
    `none`: at least one field has no reader and no step is planned for it.
    `no_target`: the item names nothing to do at all, which is the shape a prediction takes.

    `level_delta` on the internal path counts as reachable only when the emulator says the background clamp cost
    nothing (`deficit == 0`), because that is the condition under which `surface_level 1` and `level_delta 0` are
    the same instruction (snappy_runner.py:634, :636). Pass `deficit` from
    `tools.estimate_builder_cells(...)["builder"]["deficit"]`; without it the field reads as unreachable, which
    is the safe direction."""
    readers = TARGET_READERS.get(regime, TARGET_READERS["snappy_internal"])
    fields: dict[str, Any] = {}
    if target is not None:
        dump = target.model_dump() if hasattr(target, "model_dump") else dict(target)
        fields = {k: v for k, v in dump.items() if v not in (None, {}, [], ())}
    # schema 3: the instruction is `key` and `value`, and `catalog.directive_problem` judges it directly. The
    # geometric fields beside them are then where and how big, not a second instruction, so they do not count
    # against reachability. A target carrying only the geometric fields is the older shape and is read below.
    if fields.get("key"):
        problem = catalog.directive_problem(str(fields["key"]), fields.get("value"), regime)
        return {"verdict": "none" if problem else "reachable", "fields": sorted(fields),
                "keys": [] if problem else [str(fields["key"])], "unreadable": [str(fields["key"])] if problem else [],
                "hook": None, "problem": problem, "regime": regime}
    if not fields:
        return {"verdict": "no_target", "fields": [], "keys": [], "unreadable": [], "hook": None, "regime": regime}
    keys: list[str] = []
    unreadable: list[str] = []
    hooks: list[str] = []
    for name in sorted(fields):
        key = readers.get(name)
        if name == "level_delta" and key == "surface_level" and deficit != 0:
            key = None
        if key:
            keys.append(key)
        else:
            unreadable.append(name)
            if TARGET_HOOK.get(name):
                hooks.append(TARGET_HOOK[name])
    verdict = "reachable" if not unreadable else ("hook" if len(hooks) == len(unreadable) else "none")
    return {"verdict": verdict, "fields": sorted(fields), "keys": sorted(set(keys)), "unreadable": unreadable,
            "hook": hooks[0] if hooks else None, "regime": regime}


def warning_actionability(warnings: Any, regime: str, *, representation: str | None = None,
                          deficit: int | None = None) -> dict[str, Any]:
    """The number that says what this channel is worth: of the items the builder is handed, how many can it carry
    out with what it receives?

    Rows are `{id, kind, audience, reach, keys, unreadable, hook, has_cost}`; the counts are by verdict, by
    catalog audience (a `user` kind sitting in the builder's list is misfiled rather than unactionable), and by
    whether the item priced itself. Takes `plan.mesh_warnings`, or the raw dicts a recording carries."""
    rows: list[dict[str, Any]] = []
    by_verdict: dict[str, int] = {}
    by_audience: dict[str, int] = {}
    outside, costed = 0, 0
    rep = corpus_representation(representation or "") if representation else None
    for w in warnings or []:
        d = w.model_dump() if hasattr(w, "model_dump") else dict(w)
        kind = str(d.get("kind") or "")
        reach = target_reach(d.get("target"), regime, deficit=deficit)
        audience = catalog.audience_of(kind, rep) if kind else "info"
        in_vocab = bool(kind) and kind in catalog.KIND_AUDIENCE
        outside += 0 if in_vocab else 1
        has_cost = d.get("cost_cells") is not None
        costed += 1 if has_cost else 0
        by_verdict[reach["verdict"]] = by_verdict.get(reach["verdict"], 0) + 1
        by_audience[audience] = by_audience.get(audience, 0) + 1
        rows.append({"id": d.get("id"), "kind": kind, "audience": audience, "reach": reach["verdict"],
                     "keys": reach["keys"], "unreadable": reach["unreadable"], "hook": reach["hook"],
                     "has_cost": has_cost, "in_catalog_vocabulary": in_vocab})
    n = len(rows)
    reachable, hooked = by_verdict.get("reachable", 0), by_verdict.get("hook", 0)
    return {"n": n, "rows": rows, "by_verdict": by_verdict, "by_audience": by_audience,
            "outside_vocabulary": outside, "with_cost_cells": costed, "regime": regime,
            "actionable_today": reachable, "actionable_with_hook": hooked,
            "not_actionable": by_verdict.get("none", 0) + by_verdict.get("no_target", 0),
            "fraction_actionable_today": (reachable / n) if n else None,
            "platform_sha": PLATFORM_SHA}


def _tilted_mouth_deg() -> float:
    """thresholds.TILTED_MOUTH_DEG when the governed table exists (dev plan P2), the catalog's value otherwise."""
    try:
        from geometry_agent.agent import thresholds
    except ImportError:
        return float(catalog.TILTED_MOUTH_DEG)
    table = thresholds.current() if hasattr(thresholds, "current") else getattr(thresholds, "DEFAULTS", None)
    value = getattr(table, "TILTED_MOUTH_DEG", None) if table is not None else None
    return float(value) if value else float(catalog.TILTED_MOUTH_DEG)


def _cells_for(facts: GeometryFacts, keys: dict[str, Any], rep: str, engine: str, inlet_id: str | None,
               axis: str | None) -> int:
    """The corrected forecast for a key set: the emulator's high figure times the per-representation correction,
    which is the same number `budget()` and `forecast()` state, so a directive's price and the block's budget
    line can never disagree."""
    strategy = dict(keys)
    if axis:
        strategy.setdefault("flow_axis", axis)
    est = tools.estimate_builder_cells(facts, strategy, rep, engine, inlet_id=inlet_id)
    return int(est["cells_high"] * cell_correction(rep, engine))


def _flow_axis_signed(plan: GeometryPlan) -> str | None:
    """The plan's flow axis WITH its direction sign applied: `-x`, not `+x`, when the flow runs the other way.

    THE ONE READER OF A DIRECTION THAT WAS SPELLED TWO WAYS. `plan.flow.axis` is an unsigned axis and
    `plan.flow.direction_sign` is which way along it, and every consumer that needs the direction has to join
    them. Three places did, one did not: the forecast inside `report_measured` used the unsigned axis, so a
    part whose flow runs along `-x` was priced along `+x` in the same dict that declared `-x` to the builder.
    Written once here so a fourth consumer cannot get it wrong a fourth way.
    """
    axis = _snap_axis(plan.flow.axis)
    if axis and plan.flow.direction_sign < 0:
        axis = ("-" if axis[0] == "+" else "+") + axis[1]
    return axis


def _key_problem(key: str, value: Any, regime: str) -> str:
    """Admission 1 and 2 in one call (`catalog.directive_problem`): the renderer reads this key on this regime
    and does not clamp this value away. A value inside the renderer's range but outside the planner's own
    declared band is admitted and said so, which is where a cap-forced `cells_across_diameter` lives.

    THE GMSH `size` UNWRAP IS GONE. This used to take `{"mode": ..., "value": v}` apart and hand `v` on alone,
    which threw away the mode - so an ABSOLUTE size, a length in the file's own unit, was judged against the
    FACTOR band and refused: `{"mode": "absolute", "value": 5.0}` came back as "size=5 is outside the factor
    range the renderer reads, 1e-06 to 1.0" while `catalog.directive_problem` handed the same value an empty
    string. A correct 5 mm element size, refused for being a large fraction. `catalog` reads the shape itself
    and applies the factor band only in factor mode, so there is one reader of it and this is not it.
    """
    return catalog.directive_problem(key, value, regime)


def _directive_text(item: dict[str, Any]) -> str:
    """`<key> <value>: <measurement>. Costs <n> cells of <headroom> headroom.` (section 6.1).

    An item whose `why` is empty renders nothing at all: it is already in the key roster, and a line that
    restates the roster spends the customer's own 2,000 characters saying what the line above it said. The cost
    clause is dropped on a key that cannot move a cell, because "0 cells" against a key that never costs any is
    noise. The forecast against the cap is on the block's label line, which is the line that never drops."""
    why = (item.get("why") or "").strip()
    if not why:
        return ""
    value = _fmt(item["value"])
    head = f"{item['key']} {value}" if len(value) <= 16 else item["key"]
    if not why.endswith("."):
        why += "."
    cost, c, without = "", int(item.get("cost_cells") or 0), item.get("forecast_without")
    if c < 0 and without:
        # the key SAVES cells against what the renderer would do on its own, and the useful number is that
        # counterfactual, not a headroom which at the default is negative on exactly these cases
        cost = f" Saves {-c:,} cells: at the renderer's own default the forecast is {int(without):,}."
    elif c > 0 and int(item.get("headroom") or 0) > 0:
        cost = f" Costs {c:+,} cells of {int(item['headroom']):,} headroom."
    elif c > 0 and without:
        cost = f" Costs {c:+,} cells; without it the forecast is {int(without):,}."
    return f"{head}: {why}{cost}"


def _conditional_text(item: dict[str, Any]) -> str:
    why = f", {item['why']}" if item.get("why") else ""
    return f"IF the critique says {item['trigger']}: {item['key']} {_fmt(item['value'])}{why}."


def _note_text(item: dict[str, Any]) -> str:
    return f"NOTE {item['where']}: {item['why']}. No key reaches it at {PLATFORM_SHA[:8]}."


def forbidden_words(text: str) -> list[str]:
    """The outcome claims a directive may not make, one entry per offending line (`catalog.outcome_claim`).
    Empty is the passing answer, and `tests/test_channel.py` asserts it over every block the corpus renders."""
    return sorted({c for c in (catalog.outcome_claim(ln) for ln in (text or "").splitlines()) if c})


def _tilted_ports(facts: GeometryFacts, rep: str, frame: dict[str, Any]) -> list[dict[str, Any]]:
    """Circular mouths tilted at or over TILTED_MOUTH_DEG, in the builder's frame, widest tilt first. The
    measurement `surface_level` is argued from, and nothing more: whether the placement moves the delivered skew
    is P10's sweep and no line here claims it."""
    cutoff = _tilted_mouth_deg()
    by_id = {p["id"]: p for p in frame.get("ports") or []}
    out = []
    for o in tools._builder_ports(facts, tools._rep_key(rep)):
        row = by_id.get(o.id)
        if row is None or tools.mouth_shape(o, tools._rep_key(rep)) != "circle":
            continue
        if float(row["tilt_deg"]) >= cutoff:
            out.append(row)
    return sorted(out, key=lambda r: -float(r["tilt_deg"]))


def builder_directives(plan: GeometryPlan, facts: GeometryFacts, engine: str | None = None,
                       cell_cap: int | None = None, representation: str | None = None, unit: str | None = None,
                       brief: str | None = None, strategy: dict[str, Any] | None = None) -> dict[str, Any]:
    """The builder-facing list, rebuilt as instructions rather than as a forecast of trouble.

    Returns `{keys, items, to_user, to_report, cap, forecast, headroom, adjusted, regime, ...}`. `keys` is the
    whole key set the block states, so the builder can take it directly; `items` is the ranked list of
    DIRECTIVE, CONDITIONAL and NOTE rows behind those keys.

    Admission (section 6.3), through `catalog.directive_problem`: the key is one the renderer reads for this
    engine and regime, and the value is one the renderer does not clamp away. A value inside the renderer's range
    but outside the planner's own declared band is admitted and says so in `in_band`, because that is where a
    cap-forced `cells_across_diameter` lives. The forecast with everything applied has to stay under
    `(1 - BUILDER_MARGIN) x cap`, and a floor or a margin names a `where` the facts measured. An item failing the
    key test goes to `to_report` with the dev plan step that would give it a reader; a forecast that does not fit
    the cap is the customer's cell-cap decision and goes to `to_user`. The key is still stated either way: the
    roster is the builder's instruction and the evidence line is the argument for it, and dropping the argument
    must never drop the instruction.

    Ranking (6.4): T0 guards first, then T1 floors by how far the floor is unmet, then T2 margins cheapest first,
    and a T2 item pays `catalog.price_admits`: cost <= 0.10 x (0.85 x cap - the forecast without it).

    One key value can differ from `builder_strategy`'s: on an internal carve carrying a tilted circular mouth,
    when the emulator reports the background clamp cost nothing, `surface_level 1` puts the port cap at the wall
    level (`port_level = max(1, smin - 1)`, snappy_runner.py:636, with `smin = surface_level + deficit`, :634).
    That is the reachable form of the `level_delta 0` target. 75 items of the last live run named `level_delta`;
    9 of them named nothing else and are reachable through this key, and the other 66 also name a sphere or sit
    on a regime with no port level at all, so they stay behind 8.3. The move is taken when the forecast with it
    applied stays under `(1 - BUILDER_MARGIN) x cap`, and `adjusted` records it with its cost, the ports behind
    it, and whether the T2 price rule would have refused it."""
    rep = representation or representation_of(plan, facts, brief)
    engine = engine or default_engine(plan, brief)
    unit = unit or plan.unit.assumed
    cap = int(cell_cap) if cell_cap else MAX_CELLS_CAP
    strat = strategy or builder_strategy(plan, facts, engine, cell_cap, rep, unit, brief)
    regime = regime_key(strat["engine"], rep, plan.purpose)
    rep_key = corpus_representation(rep)
    keys: dict[str, Any] = dict(strat["keys"])
    frame = strat.get("frame") or {}
    inlet_id = frame.get("inlet_id") if frame else None
    # The SIGNED axis, like the forecast above it and the strategy it prices against: this local is
    # handed to the emulator as flow_axis and printed in the prose the customer reads, and both want
    # the direction. The indexing use below reads only the letter, so the sign costs it nothing.
    axis = _flow_axis_signed(plan)
    est_builder = dict((strat.get("estimate") or {}).get("builder") or {})
    deficit = est_builder.get("deficit")
    wall = wall_patch_name(plan, facts)
    n_plan, _first = _plan_layers(plan)
    layer = strat.get("layer") or {}
    reads = platform_reads(regime) or (MULTIREGION_KEYS if regime == "snappy_multiregion" else ())
    ext = [float(v) for v in facts.bbox.extent]
    ref_mm = ((ext["xyz".index(axis[1])] if axis else max(ext)) or max(ext)) * UNIT_TO_M[unit] * 1000.0

    def cells(k: dict[str, Any]) -> int:
        return _cells_for(facts, k, rep, strat["engine"], inlet_id, axis)

    # ---- the tilted-mouth move, priced before anything is written -------------------------------------------
    # It is a T1 floor, not a T2 margin, so it pays the 0.85-cap test and not the 10 percent price rule. A T2
    # margin is a key with no measured feature behind it, and this one has one: a circular mouth measured over
    # TILTED_MOUTH_DEG whose port cap sits a level coarser than the wall. Section 6.4's own words for T1 are "a
    # floor may spend the whole headroom". The difference is 4 cases of the 31 the move lands on in the last
    # live run (27 of 31 pass the 10 percent rule, 31 of 31 stay under 0.85 x cap), and the four it saves are
    # mini_housing_001 and bend_elbow_007 among them, which are two of the design doc's own worked samples.
    adjusted: dict[str, Any] | None = None
    tilted = _tilted_ports(facts, rep, frame) if (regime == "snappy_internal" and frame) else []
    if tilted and deficit == 0 and keys.get("surface_level") != 1:
        here = cells(keys)
        candidate = {**keys, "surface_level": 1, "feature_level": 2}
        there = cells(candidate)
        headroom = (1.0 - BUILDER_MARGIN) * cap - here
        if there <= (1.0 - BUILDER_MARGIN) * cap:
            adjusted = {"key": "surface_level", "from": keys.get("surface_level"), "to": 1,
                        "feature_level": {"from": keys.get("feature_level"), "to": 2},
                        "cost_cells": there - here, "headroom": int(headroom),
                        "ports": [p["id"] for p in tilted], "tilt_deg": float(tilted[0]["tilt_deg"]),
                        "priced_out_by_t2_rule": catalog.price_admits(there - here, here, cap, "T2") is False,
                        "why": ("port_level = max(1, surface_level + deficit - 1) and the emulator reports deficit 0, "
                                "so surface_level 1 puts the port cap at the wall level")}
            keys["surface_level"], keys["feature_level"] = 1, 2
            keys["max_cells"] = max(1, min(cap, there))

    forecast_all = cells(keys)
    headroom_all = (1.0 - BUILDER_MARGIN) * cap - forecast_all
    items: list[dict[str, Any]] = []
    to_user: list[dict[str, Any]] = []
    to_report: list[dict[str, Any]] = []

    def price(key: str) -> tuple[int, int]:
        """(cost of this key over the renderer's own default, headroom without it)."""
        default = renderer_default(regime, key)
        if default is None or key not in keys:
            return 0, int(headroom_all)
        without = cells({**keys, key: default})
        return forecast_all - without, int((1.0 - BUILDER_MARGIN) * cap - without)

    smallest = frame.get("smallest_port") if frame else None
    floor = _port_cells_min()
    smallest_cells = None
    if smallest and keys.get("cells_across_diameter") and frame.get("bore"):
        wall_cell = float(frame["bore"]) / int(keys["cells_across_diameter"])
        smallest_cells = float(smallest["min_dimension"]) / wall_cell if wall_cell > 0 else None

    def add(key: str, where: str, why: str, *, tier: str | None = None, gap: float = 0.0) -> None:
        """`gap` orders the T1 floors and is dimensionless on purpose: it is the fraction of the floor this key
        is closing, in 0 to 1, so a port shortfall, a y+ residual and a level deficit can be compared at all.
        Section 6.4 says "ordered by how far the floor is unmet, descending" and ranking millimetres against
        degrees would not be that."""
        value = keys.get(key)
        if value is None:
            return
        tier = tier or KEY_TIER.get(key, "T2")
        cost, headroom = price(key)
        gap = min(1.0, max(0.0, float(gap)))
        problem = _key_problem(key, value, regime)
        item = {"class": "directive", "tier": tier, "key": key, "value": value, "where": where, "why": why,
                "cost_cells": cost, "headroom": headroom, "forecast": forecast_all, "cap": cap, "gap": gap,
                "reads": key in reads, "in_band": catalog.in_declared_band(key, value, regime),
                "severity": catalog.attention_of("directive", tier),
                "under_margin": forecast_all <= (1.0 - BUILDER_MARGIN) * cap,
                "forecast_without": forecast_all - cost, "priced_out": False, "admitted": True}
        if problem:
            item.update({"admitted": False, "refused": problem})
            to_report.append(item)
            return
        if catalog.price_admits(cost, forecast_all - cost, cap, tier) is False:
            item.update({"admitted": False, "priced_out": True,
                         "refused": (f"a T2 margin may spend {catalog.DIRECTIVE_PRICE_FRACTION:.0%} of the {headroom:,} "
                                     f"cells left under {1 - BUILDER_MARGIN:.2f} x cap and this one costs {cost:,}")})
            to_report.append(item)
            return
        item["text"] = _directive_text(item)
        items.append(item)

    # ---- T0, the guards ------------------------------------------------------------------------------------
    # Their values are always in the roster; only the ones that carry a measurement the roster does not already
    # state earn a line. `max_cells` is the block's own label line, `quality` is argued by its conditional.
    if "max_cells" in keys:
        over = forecast_all > (1.0 - BUILDER_MARGIN) * cap
        add("max_cells", "the whole mesh",
            (f"the keys above forecast {forecast_all:,} cells against your {cap:,} cap and no key the renderer "
             f"reads closes the gap" if over else ""))
        if over:
            to_user.append({"kind": "cell_cap", "measurement": {"forecast": forecast_all, "cap": cap},
                            "question": (f"these keys forecast {forecast_all:,} cells against your {cap:,} cap, and the "
                                         f"keys the renderer reads do not close the gap. Raise the cap or coarsen the wall?"),
                            "why": "admission rule 3: a forecast over 0.85 x cap is the customer's decision, not an instruction"})
    if "quality" in keys:
        add("quality", "every cell", "")
    if "domain_margin" in keys:
        add("domain_margin", f"the far field along {axis or 'the longest axis'}",
            f"your stated multiples of the {ref_mm:.4g} mm {axis or 'longest'} extent, which is the ruler "
            f"domain_from_strategy sizes the box with")
    if "reference_length_m" in keys:
        add("reference_length_m", f"the manifest, along {axis or 'the longest axis'}",
            "the ruler domain_extent_gate.py:87 measures the delivered box with")

    # ---- T1, the floors ------------------------------------------------------------------------------------
    if "cells_across_diameter" in keys and frame:
        # the floor shortfall when there is one, else how far this value sits from the renderer's own 24, which
        # is the size of the argument the line has to make: at 24 there is nothing to argue and the line drops
        # first, at 14 the line carries a factor of four in cells and drops last
        shortfall = max(0.0, (floor - smallest_cells) / floor) if smallest_cells is not None else 0.0
        gap = max(shortfall, min(1.0, abs(price("cells_across_diameter")[0]) / max(forecast_all, 1)))
        bore_mm = float(frame.get("bore") or 0.0) * UNIT_TO_M[unit] * 1000.0
        wall_mm = bore_mm / int(keys["cells_across_diameter"]) if keys["cells_across_diameter"] else 0.0
        why = (f"inlet {frame.get('inlet_id')} bore {bore_mm:.4g} mm, wall cell {wall_mm:.4g} mm"
               + (f"; the smallest port {smallest['id']} spans {smallest_cells:.1f} of them, floor {floor:g}"
                  if smallest_cells is not None else ""))
        add("cells_across_diameter", f"inlet {frame.get('inlet_id')}", why, gap=gap)
        if gap > 0:
            to_user.append({"kind": "cell_cap", "measurement": {"port": smallest["id"] if smallest else None,
                                                               "cells_across_builder": smallest_cells, "floor": floor,
                                                               "cap": cap},
                            "question": (f"your {cap:,} cap holds the smallest port {smallest['id'] if smallest else ''} to "
                                         f"{smallest_cells:.1f} wall cells across where the floor is {floor:g}. Raise the cap?"),
                            "why": "the residual a floor directive could not close inside the cap"})
    if "first_layer_rel" in keys:
        why = ""
        if layer.get("first_cell"):
            why = (f"the outer layer over the wall cell, not a wall distance; it puts the first cell at "
                   f"{float(layer['first_cell']) * CENTRE_TO_CELL * UNIT_TO_M[unit] * 1000.0:.4g} mm, the height your "
                   f"y+ target was sized at")
        ratio = float(layer.get("delivered_yplus_ratio") or 1.0)
        band = FIRST_LAYER_REL_BAND["external" if regime == "snappy_external" else "internal"]
        if layer.get("clamped") and abs(ratio - 1.0) > 0.05:
            why = (f"the outer layer over the wall cell; your y+ asks {float(layer['raw']):.4g}, outside the planner "
                   f"band {band[0]:g} to {band[1]:g}, so the first cell lands at {ratio:.2f}x the one sized")
        add("first_layer_rel", f"patch {wall}", why, gap=abs(1.0 - ratio))
        note = layer_clamp_note(layer, "external" if regime == "snappy_external" else "internal")
        if note:
            to_report.append({"class": "residual", "key": "first_layer_rel", "why": note, "admitted": False,
                              "refused": "the planner's own band does not reach the value the y+ target asks for"})
    if "n_layers" in keys and keys["n_layers"]:
        stated = n_plan > 0
        add("n_layers", f"patch {wall}",
            ("" if stated else f"{keys['n_layers']} on the wall patch; the request names no count"),
            tier="T1" if stated else "T2", gap=1.0 if stated else 0.0)
    if "size" in keys:
        d_min = min((tools.port_min_dimension(o) for o in tools._builder_ports(facts, tools._rep_key(rep))), default=0.0)
        diag = float(facts.bbox.diagonal) or 1.0
        h_mm = float((keys["size"] or {}).get("value", tools.GMSH_SIZE_FACTOR)) * diag * UNIT_TO_M[unit] * 1000.0
        default_h = tools.GMSH_SIZE_FACTOR * diag * UNIT_TO_M[unit] * 1000.0
        why = (f"h = {h_mm:.4g} mm, the smallest port's {d_min * UNIT_TO_M[unit] * 1000.0:.4g} mm minimum dimension over "
               f"{floor:g} elements; the driver default {tools.GMSH_SIZE_FACTOR:g} of the diagonal gives h = {default_h:.4g} mm")
        add("size", "the smallest port", why, gap=(1.0 - h_mm / default_h) if default_h > 0 else 0.0)

    # ---- T2, the margins, and the one T1 the tilted mouth earns ---------------------------------------------
    if "surface_level" in keys and regime == "snappy_internal":
        why = ("the level sets the background cell, never the wall cell, which is bore over cells_across at every "
               "level (drivers.py:584 with snappy_runner.py:634)")
        tier = None
        if adjusted:
            ids = ", ".join(adjusted["ports"][:4])
            why = (f"puts the port cap at the wall level (port_level = smin - 1, deficit 0); {ids} "
                   f"{'is' if len(adjusted['ports']) == 1 else 'are'} up to {adjusted['tilt_deg']:.3g} deg off the grid")
            tier = "T1"
        # the unmet floor here is a factor of two: without it the port cap sits one level, and so one halving of
        # the cell, coarser than the wall the mouth is cut in
        add("surface_level", "the background", why, tier=tier, gap=0.5 if adjusted else 0.0)
    elif "surface_level" in keys:
        add("surface_level", "the wall", "on the external path the level does refine the wall, between the "
                                         "recommender's sealing floor and its affordable ceiling")
    if "feature_level" in keys:
        add("feature_level", "every patch eMesh at once",
            "one level over the wall on every surface at once, each port rim included; it aims at no one rim")
    if "curvature_nodes" in keys:
        add("curvature_nodes", "every curved wall",
            f"elements per turn; the main passage's walls sit at min(h, pi D_h / {keys['curvature_nodes']})")

    # ---- the conditionals, at most two ---------------------------------------------------------------------
    # The plan's own, when the catalog wrote them (`catalog.CONDITIONAL_KINDS`, `skew_repair` and
    # `carve_leak_repair`): the content half of this pass measures and prices them and this half admits and
    # renders them. A plan that predates those kinds falls back to the two this module can derive from the keys
    # it already holds, so the block never comes back without its conditionals on an older plan.
    conds: list[dict[str, Any]] = []
    for w in plan.mesh_warnings or []:
        if (w.item_class or ("conditional" if w.trigger else None)) != "conditional":
            continue
        key, value = w.target.key, w.target.value
        if not key or value is None or catalog.trigger_problem(w.trigger) or _key_problem(key, value, regime):
            to_report.append({"class": "conditional", "id": w.id, "kind": w.kind, "admitted": False,
                              "refused": (catalog.trigger_problem(w.trigger)
                                          or _key_problem(key, value, regime) or "carries no key to set")})
            continue
        conds.append({"class": "conditional", "tier": "T0", "trigger": w.trigger, "key": key, "value": value,
                      "why": (w.why or "")[:90], "kind": w.kind, "source": "catalog",
                      "severity": catalog.attention_of("conditional"), "admitted": True})
    if not conds and strat["engine"] == "snappy":
        conds.append({"class": "conditional", "tier": "T0", "trigger": "WIDESPREAD skewness", "key": "quality",
                      "value": "strict", "why": f"keep n_layers {keys.get('n_layers')}", "source": "derived",
                      "severity": catalog.attention_of("conditional"), "admitted": True})
        if regime == "snappy_internal":
            conds.append({"class": "conditional", "tier": "T0", "trigger": "CARVE LEAKED", "source": "derived",
                          "key": "cells_across_diameter",
                          "value": int(keys.get("cells_across_diameter") or tools.BUILDER_CELLS_ACROSS_DEFAULT) + 4,
                          "why": "render_internal_case reads no domain_margin, so raise this and not that",
                          "severity": catalog.attention_of("conditional"), "admitted": True})
        else:
            conds.append({"class": "conditional", "tier": "T0", "trigger": "TIMEOUT", "key": "max_cells",
                          "value": max(1, int(forecast_all * 0.6)), "source": "derived",
                          "why": "the one case the judge says to reduce the budget",
                          "severity": catalog.attention_of("conditional"), "admitted": True})
    # A conditional that CONTRADICTS the platform's own repair text is worth more than one that repeats it:
    # `judge.py:64` already tells the planner to set quality strict on skew, and `judge.py:42-48` tells an
    # internal carve that leaked to enlarge a `domain_margin` `render_internal_case` never reads. The second is
    # the only one of the two that changes what the planner would otherwise do, so it is the one that survives
    # the budget. Two at most either way (section 6.5).
    conds.sort(key=lambda c: 0 if "CARVE LEAKED" in (c.get("trigger") or "") and regime == "snappy_internal" else 1)
    for c in conds[:2]:
        c["text"] = _conditional_text(c)
        items.append(c)

    # ---- the notes, at most two ----------------------------------------------------------------------------
    notes: list[dict[str, Any]] = []
    for w in plan.mesh_warnings or []:
        if (w.item_class or ("conditional" if w.trigger else None)) == "conditional":
            continue
        reach = target_reach(w.target, regime, deficit=deficit)
        if reach["verdict"] == "reachable":
            continue
        if catalog.audience_of(w.kind, rep_key) != "builder":
            continue
        where = ", ".join(w.location.patch_ids) if w.location.patch_ids else (
            f"[{', '.join(f'{c:.4g}' for c in w.location.point)}]" if w.location.point else "")
        size = {k: v for k, v in w.size.model_dump().items() if v is not None}
        if not where or not size:
            continue
        span = (w.builder_cells.cells_across if w.builder_cells else None)
        measure = "; ".join(f"{k} {v:.4g}" for k, v in size.items())
        notes.append({"class": "note", "tier": "T2", "where": where, "kind": w.kind,
                      "why": f"{measure}" + (f", which is {span:.2f} wall cells across" if span else ""),
                      "span": span if span is not None else 1e9, "hook": reach["hook"], "admitted": True})
    notes.sort(key=lambda r: float(r["span"]))
    for nrow in notes[:2]:
        nrow["text"] = _note_text(nrow)
        items.append(nrow)

    # ---- what the builder cannot act on at all --------------------------------------------------------------
    for w in plan.mesh_warnings or []:
        if (w.item_class or ("conditional" if w.trigger else None)) == "conditional":
            continue
        reach = target_reach(w.target, regime, deficit=deficit)
        audience = catalog.audience_of(w.kind, rep_key)
        if reach["verdict"] == "reachable" and audience == "builder":
            continue
        row = {"class": "unreachable", "id": w.id, "kind": w.kind, "audience": audience,
               "reach": reach["verdict"], "unreadable": reach["unreadable"], "hook": reach["hook"],
               "why": w.why[:160], "admitted": False}
        (to_user if audience == "user" else to_report).append(row)

    ranked = sorted(items, key=lambda r: (TIER_ORDER.get(r.get("tier") or "T2", 2),
                                          0 if r["class"] == "directive" else (1 if r["class"] == "conditional" else 2),
                                          -float(r.get("gap") or 0.0) if r.get("tier") == "T1" else 0.0,
                                          float(r.get("cost_cells") or 0.0) if r.get("tier") == "T2" else 0.0))
    return {"regime": regime, "engine": strat["engine"], "representation": rep, "keys": keys,
            "header_keys": dict(strat["keys"]), "adjusted": adjusted, "items": ranked,
            "to_user": to_user, "to_report": to_report, "cap": cap, "forecast": forecast_all,
            "headroom": int(headroom_all), "under_margin": forecast_all <= (1.0 - BUILDER_MARGIN) * cap,
            "notes": list(strat.get("notes") or []), "platform_sha": PLATFORM_SHA,
            "label": {"snappy_internal": "snappy internal", "snappy_external": "snappy external",
                      "snappy_multiregion": "snappy multiregion", "gmsh": "gmsh"}[regime]}


#: The drop ladder, lowest value first. The label line and the key roster carry rank 0 and are never dropped:
#: the roster IS the instruction, the evidence lines are the argument for it, and a budget that took a key away
#: would leave the builder with an argument and no instruction. Below that the order is the ranking of section
#: 6.4 read backwards: the look, then T2 margins from the most expensive, then the notes, then the conditionals,
#: then T1 floors from the smallest unmet gap, then the T0 guards' own evidence. Every drop is recorded.
#:
#: Two deliberate departures from section 6.5, both visible in the doc's own worked samples. A NOTE outranks a
#: T2 margin, because a T2 margin is a key the roster already states and a note is the only way a measured
#: feature with no reader reaches the builder at all. And a conditional ranks BELOW a T1 floor rather than above
#: every directive: a conditional fires only on a re-plan after a measured failure, a floor acts on the first
#: pass and on all of them, and on the skew trigger the platform's own `judge.py` already issues the same
#: instruction. Sample 8.2 of the design doc, at a 320-character budget, keeps the floor and drops the
#: conditional, which is this order and not 6.5's.
_DROP_RANK = {"roster": 0, "T0": 1, "T1": 2, "conditional": 3, "note": 4, "T2": 5, "impression": 6}
#: Render order, which is not the drop order: the instructions, then what has no key, then what is contingent.
_RENDER_GROUP = {"directive": 0, "note": 1, "conditional": 2}


def _impression_floor(text: str) -> str | None:
    """The impression cut back to the half a builder may act on: the label and every relied-on clause.

    IT USED TO KEEP THE FIRST CLAUSE, WHICH WAS THE IDENTITY, AND THE IDENTITY IS THE LEAST STABLE THING THE
    LOOK PRODUCES: right on 215 of 322 at best and changing its verdict on 9 to 11 of 40 byte-identical repeat
    calls. Under a budget the line therefore threw away 25-of-25 attachments, every answer at a marked place
    and every passage end to keep a guess at the part's name. What survives a cut should be what was measured
    to be worth keeping.

    `impression_clauses` writes the relied-on clauses first and opens the second half with
    `IMPRESSION_ASK_LEAD`, so the boundary is in the line's own words and this function does not need a hidden
    marker to find it. A line with no relied-on clause at all cuts back to nothing and returns None, which is
    the honest answer: there is no floor under a line that is all candidates."""
    label, _, body = text.partition(": ")
    head = body.split("; " + IMPRESSION_ASK_LEAD, 1)[0].strip().rstrip(" ;,")
    if not head or head.startswith(IMPRESSION_ASK_LEAD):
        return None
    return f"{label}: {head}"


def _block_lines(directives: dict[str, Any], impression: str | None = None,
                 carry: str | None = None) -> list[dict[str, Any]]:
    """The block as rows of `{rank, order, text}` before any budget is applied: render order is the ranking,
    drop order is `_DROP_RANK`, and the two are deliberately not the same list."""
    cap, label, fc = directives["cap"], directives["label"], directives["forecast"]
    roster = "; ".join(f"{k} {_fmt(v)}" for k, v in directives["keys"].items())
    rows = [{"rank": 0, "order": 0,
             "text": f"MESH PLAN ({label}): forecast {fc:,} cells of your {cap:,} cap.", "what": "label"},
            {"rank": 0, "order": 1, "text": roster, "what": "roster"}]
    if carry:
        # something the block displaced and does not restate, repeated here rather than lost: rank 0, because a
        # block that pushed the patch names out of the read and then dropped its own copy of them is worse than
        # no block at all (docs/builder_directives.md section 5)
        rows.append({"rank": 0, "order": 1.5, "text": carry, "what": "carry"})
    body = []
    for n, item in enumerate(directives["items"]):
        if not item.get("text"):
            continue
        if item["class"] == "directive":
            rank, what = _DROP_RANK.get(item.get("tier") or "T2", 5), item["key"]
        elif item["class"] == "conditional":
            rank, what = _DROP_RANK["conditional"], f"if:{item['trigger']}"
        else:
            rank, what = _DROP_RANK["note"], f"note:{item.get('kind')}"
        body.append({"rank": rank, "group": _RENDER_GROUP.get(item["class"], 3), "n": n,
                     "text": item["text"], "what": what})
    body.sort(key=lambda r: (r["group"], r["n"]))
    for i, r in enumerate(body):
        r["order"] = 2 + i
        rows.append(r)
    rows.sort(key=lambda r: r["order"])
    if impression:
        rows.append({"rank": _DROP_RANK["impression"], "order": 2 + len(body), "text": impression,
                     "what": "impression"})
    return rows


def _refuse_outcome_lines(rows: list[dict[str, Any]], dropped: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """The rows with every line that predicts the finished mesh taken out, each one named in `dropped`.

    THE GUARD NOW ACTS. `forbidden_words` was computed on every `builder_plan_block` call and read by two tests
    and by nothing else, so a directive that claimed an outcome was measured at test time and shipped at run
    time: the block-level guard existed and did not run. A line `catalog.outcome_claim` condemns is removed
    here, before the budget loop, so the characters it freed are spent on a line that is allowed rather than
    charged to a line that was never going to ship.

    LINE BY LINE, because that is the grain `catalog.outcome_claim` works at and the grain `forbidden_words`
    reports at. A roster line and a directive's reason are separate lines, so one bad reason does not take the
    instruction with it.
    """
    out: list[dict[str, Any]] = []
    for row in rows:
        lines = str(row.get("text") or "").splitlines()
        judged = [(ln, catalog.outcome_claim(ln)) for ln in lines]
        if not any(claim for _, claim in judged):
            out.append(row)
            continue
        for ln, claim in judged:
            if claim:
                dropped.append({"what": f"{row['what']}: outcome claim ({claim})", "rank": row["rank"],
                                "chars": len(ln)})
        row = {**row, "text": "\n".join(ln for ln, claim in judged if not claim)}
        if row["text"].strip():
            out.append(row)
    return out


def builder_plan_block(plan: GeometryPlan, facts: GeometryFacts, engine: str | None = None,
                       cell_cap: int | None = None, representation: str | None = None, unit: str | None = None,
                       brief: str | None = None, request_txt: str | None = None,
                       directives: dict[str, Any] | None = None, impression: str | None = None,
                       max_chars: int | None = None, carry: str | None = None) -> dict[str, Any]:
    """The block the request carries, sized for this case's own room, with what it dropped and why.

    Returns `{text, chars, budget, lines, dropped, keys, cap, forecast}`. `request_txt` sizes the budget
    (`block_budget`); pass the platform's own `state["request_txt"]` where there is one, the brief otherwise. The
    text is the builder's whole instruction: the label with the customer's cap, the key roster, then as much of
    the ranked evidence as the budget holds.

    This block supersedes `strategy_header` in the request. The two must never both be prepended: they state the
    same keys, and a request that states one key twice is a request the planner can read two ways."""
    d = directives or builder_directives(plan, facts, engine, cell_cap, representation, unit, brief)
    budget = max_chars if max_chars is not None else block_budget(request_txt if request_txt is not None else brief)
    rows = _block_lines(d, impression, carry)
    dropped: list[dict[str, Any]] = []
    rows = _refuse_outcome_lines(rows, dropped)
    keep = list(rows)
    while len("\n".join(r["text"] for r in sorted(keep, key=lambda r: r["order"]))) > budget and len(keep) > 2:
        victim = max(keep, key=lambda r: (r["rank"], r["order"]))
        if victim["rank"] == 0:
            break
        if victim["what"] == "impression" and not victim.get("shortened"):
            # the look is on for every run and what it saw is to reach the builder (dev plan P9), so before the
            # description is dropped it is offered at its floor: every clause `vision.trust` relies on, which
            # is what the builder cannot get from any measurement. It is still ranked last, so a budget too
            # tight even for the floor still spends its characters on the keys
            short = _impression_floor(victim["text"])
            if short is not None and len(short) < len(victim["text"]):
                dropped.append({"what": "impression (cut to the clauses the ledger relies on)",
                                "rank": victim["rank"],
                                "chars": len(victim["text"]) - len(short)})
                victim["text"], victim["shortened"] = short, True
                continue
        keep.remove(victim)
        dropped.append({"what": victim["what"], "rank": victim["rank"], "chars": len(victim["text"])})
    ordered = sorted(keep, key=lambda r: r["order"])
    text = "\n".join(r["text"] for r in ordered)
    if len(text) > budget:
        # only the label and the roster are left and they still do not fit: this is one of the two corpus cases
        # with no room at all, and the roster is what survives, because it is the instruction
        text = text[:budget]
        dropped.append({"what": "cut", "rank": 0, "chars": len("\n".join(r["text"] for r in ordered)) - budget})
    return {"text": text, "chars": len(text), "budget": budget, "lines": [r["what"] for r in ordered],
            "dropped": dropped, "keys": d["keys"], "cap": d["cap"], "forecast": d["forecast"],
            "regime": d["regime"], "forbidden_words": forbidden_words(text)}


#: The named lines a corpus request carries, and what it costs the planner to lose each one, so a block that
#: displaces something has to answer for it rather than merely fit. `restated` means the block states the same
#: number in the planner's own key, so losing the sentence costs nothing. `no reader` means nothing downstream
#: of `request.txt` consumes it at PLATFORM_SHA, so losing it costs nothing either. `carry` means the block must
#: repeat it, and today that is only the patch list, which the planner has no other source for.
REQUEST_LINES: tuple[tuple[str, str, str, str], ...] = (
    ("mesh budget", r"Mesh budget|cell count under|under [\d.,]+ ?million", "restated",
     "the block's label line states the forecast against the same cap, and max_cells carries it"),
    ("near-wall", r"Near-wall|Near-surface", "restated", "n_layers and first_layer_rel carry it"),
    ("far-field", r"Far-field", "restated", "domain_margin and reference_length_m carry it"),
    ("patches", r"^Patches:", "carry", "the planner has no other source for the patch names"),
    ("refinement", r"^\s*(Feature-edge r|R)efinement", "no reader",
     "refinementRegions is authored as the wall distance band only (snappy_runner.py:681, :535)"),
    ("wake", r"^\s*Wake:", "no reader", "no box is authored on either path"),
    ("physics tail", r"Steady state|Transient, ", "no reader",
     "the planner sizes cells; the physics reaches the reviewer through review_brief_txt, which is not cut"),
)
_REQUEST_LINE_RES = tuple((name, re.compile(rx, re.I | re.M), status, why) for name, rx, status, why in REQUEST_LINES)


def displaced_lines(request_txt: str | None, block_chars: int) -> list[dict[str, Any]]:
    """Which of the request's named lines start past the planner's cut once a block of `block_chars` sits in
    front of them, and what losing each one costs. This is the audit the sizing rule owes: a block that fits is
    not the same as a block that displaced only what it restates."""
    text = request_txt or ""
    offset = block_chars + 2                                     # the block and the blank line between
    out = []
    for name, rx, status, why in _REQUEST_LINE_RES:
        m = rx.search(text)
        if m and m.start() + offset >= REQUEST_TXT_READ:
            out.append({"line": name, "at": m.start(), "status": status, "why": why})
    return out


def request_assembly(plan: GeometryPlan, facts: GeometryFacts, request_txt: str, engine: str | None = None,
                     cell_cap: int | None = None, representation: str | None = None, unit: str | None = None,
                     brief: str | None = None, directives: dict[str, Any] | None = None,
                     impression: str | None = None) -> dict[str, Any]:
    """What the planner actually reads: the block, a blank line, then the request, cut at 2,000 characters the
    way `planner.py:186` cuts it.

    One function so the harness's arm B1, dev plan 8.2's intake rendering and every test measure the same text.
    `read` is what survives the cut, `lost_chars` is what does not, and `displaced` names the request lines that
    fall past the cut with what losing each one costs. `carried` is the one case the block has to answer for: on
    the 50 corpus requests long enough that even the 320-character floor overflows the read, the block repeats
    the patch names rather than lengthening, which is the rule docs/builder_directives.md section 5 states."""
    block = builder_plan_block(plan, facts, engine, cell_cap, representation, unit, brief, request_txt,
                              directives, impression)
    displaced = displaced_lines(request_txt, block["chars"])
    carried = None
    if any(d["status"] == "carry" for d in displaced):
        names = [p["name"] for p in intake_patches(plan, facts)]
        if names:
            carried = "patches: " + ", ".join(names[:8])
            block = builder_plan_block(plan, facts, engine, cell_cap, representation, unit, brief, request_txt,
                                       directives, impression, carry=carried)
            displaced = displaced_lines(request_txt, block["chars"])
    whole = f"{block['text']}\n\n{request_txt}"
    read = whole[:REQUEST_TXT_READ]
    return {"text": whole, "read": read, "chars": len(whole), "read_chars": len(read),
            "lost_chars": max(0, len(whole) - REQUEST_TXT_READ), "request_chars": len(request_txt or ""),
            "block": block, "request_truncated": len(whole) > REQUEST_TXT_READ,
            "displaced": displaced, "carried": carried,
            "displaced_uncovered": [d for d in displaced if d["status"] == "carry" and not carried]}


# ---------------------------------------------------------------------------------------------------------------
# engine params, the advisory block and the seed check
# ---------------------------------------------------------------------------------------------------------------
def engine_params_hints(plan: GeometryPlan, facts: GeometryFacts, cell_cap: int | None = None,
                        representation: str | None = None, strategy: dict[str, Any] | None = None) -> dict[str, dict[str, Any]]:
    """The plan's mesh decisions in each flow engine's own strategy keys. The snappy block is the header's strategy
    (one source of truth): first_layer_rel is the outer layer over the wall cell, max_cells is min(cap, corrected
    forecast). Keys no platform reader consumes (mrf_zone, port_extensions, seed_point_mm, preserve_features)
    live in `advisory`, not here."""
    mp = plan.mesh_plan
    rep = representation or representation_of(plan, facts)
    strat = strategy or builder_strategy(plan, facts, "snappy", cell_cap, rep)
    layers, first = _plan_layers(plan)
    hints: dict[str, dict[str, Any]] = {}
    snappy: dict[str, Any] = dict(strat["keys"]) if strat["engine"] == "snappy" else {}
    if not snappy:
        snappy = {"n_layers": layers, "first_layer_rel": tools.BUILDER_FIRST_LAYER_REL["internal"],
                  "max_cells": budget(mp.cell_estimate_refined or mp.cell_estimate, rep, cell_cap, "snappy")["max_cells"]}
    if "surface_level" in snappy and not isinstance(snappy["surface_level"], list):
        snappy["surface_level"] = [snappy["surface_level"], snappy["surface_level"]]
    hints["snappy"] = snappy
    cf: dict[str, Any] = {"n_layers": layers, "wall_cell": mp.base_size / 4 if mp.base_size else None,
                          "features": [{"type": "sphere", "center": list(r.anchor), "radius": r.radius, "cell": r.target_size}
                                       for r in mp.refinement_regions if r.anchor is not None and r.radius]}
    if first:
        cf["first_layer_thickness"] = first
    hints["cfmesh"] = cf
    if plan.purpose == "conjugate_heat_transfer":
        declared = {r.id: r.role for r in mp.regions}
        rows = []
        for r in facts.regions:
            role = declared.get(r.id) or ("fluid" if r.nested_in else "solid")
            if role == "void":
                continue
            rows.append({"name": r.id, "type": "fluid" if role in ("fluid", "rotating_zone") else "solid", "solids": [int(r.id[1:]) - 1]})
        hints["snappy_multiregion"] = {"regions": rows, "interface_refinement": 1, "n_layers": layers,
                                       "first_layer_rel": snappy.get("first_layer_rel", tools.BUILDER_FIRST_LAYER_REL["internal"]),
                                       "quality": "balanced", "max_cells": snappy.get("max_cells")}
    return hints


def seed_check(facts: GeometryFacts, seed_point, representation: str, mesh=None) -> dict[str, Any]:
    """Is the seed inside the volume snappy must keep, by ray parity over the nesting rays of facts/regions.py:
    for a wall shell the point must be in the carved cavity (an even hit count on most rays, so not in the
    metal, and the shell seen in at least ENCLOSED_RAY_FRACTION of the directions); for a fluid body it must be
    inside the body (odd). Reported, never enforced: the platform chooses locationInMesh itself
    (cad_tessellate.py:881-929)."""
    if seed_point is None:
        return {"tested": False, "inside": None, "reason": "no seed point in the plan"}
    try:
        import numpy as np

        from geometry_agent.facts.regions import (
            ENCLOSED_RAY_FRACTION,
            ENCLOSURE_DIRECTIONS,
            RAY_OFFSET_OF_DIAG,
            region_meshes,
        )
        if mesh is None:
            from geometry_agent.facts.load import load_mesh
            mesh = load_mesh(Path(facts.source_path))
        parts = region_meshes(mesh)
    except Exception as exc:  # noqa: BLE001 - the check is advisory; an unloadable mesh is reported, not raised
        return {"tested": False, "inside": None, "reason": f"mesh unavailable: {type(exc).__name__}: {str(exc)[:120]}"}
    outer_ids = {r.id for r in facts.regions if not r.nested_in} or {r.id for r in facts.regions}
    point = np.asarray(seed_point, dtype=float)
    best = None
    for k, part in enumerate(parts, start=1):
        if f"r{k}" not in outer_ids or len(part.faces) == 0:
            continue
        diag = float(np.linalg.norm(part.extents)) or 1.0
        dirs = np.asarray(ENCLOSURE_DIRECTIONS, dtype=float)
        origins = np.repeat(point[None, :], len(dirs), axis=0) + dirs * (RAY_OFFSET_OF_DIAG * diag)
        try:
            _, index_ray = part.ray.intersects_location(origins, dirs, multiple_hits=True)[:2]
        except Exception as exc:  # noqa: BLE001
            return {"tested": False, "inside": None, "reason": f"ray test failed: {type(exc).__name__}"}
        counts = np.bincount(np.asarray(index_ray, dtype=int), minlength=len(dirs))
        hit_fraction = float((counts > 0).mean())
        odd_fraction = float((counts % 2 == 1).mean())
        row = {"region": f"r{k}", "hit_fraction": round(hit_fraction, 3), "odd_fraction": round(odd_fraction, 3)}
        if best is None or hit_fraction > best["hit_fraction"]:
            best = row
    if best is None:
        return {"tested": False, "inside": None, "reason": "no outer region to test against"}
    if representation == "wall_shell":
        in_metal = best["odd_fraction"] > 0.5
        enclosed = best["hit_fraction"] >= ENCLOSED_RAY_FRACTION
        inside = enclosed and not in_metal
        rule = ("inside the carved cavity: even parity (not in the metal) and the shell seen in at least "
                f"{ENCLOSED_RAY_FRACTION:g} of the {len(ENCLOSURE_DIRECTIONS)} nesting directions")
        return {"tested": True, "inside": bool(inside), "in_metal": bool(in_metal), "enclosed": bool(enclosed), **best, "rule": rule}
    inside = best["odd_fraction"] > 0.5
    return {"tested": True, "inside": bool(inside), **best,
            "rule": f"inside the fluid body: odd parity on most of the {len(ENCLOSURE_DIRECTIONS)} nesting directions"}


def advisory(plan: GeometryPlan, facts: GeometryFacts, unit: str, representation: str | None = None, mesh=None) -> dict[str, Any]:
    """What the plan knows and no platform reader consumes at PLATFORM_SHA (docs/handover_consumers.md): the
    MRF zone, port extensions, the seed point (cad_tessellate.py:881-929 picks locationInMesh itself), the
    feature edges to preserve (feature extraction is one includedAngle, snappy_runner.py:602-603), per-port
    layer targets (one wall layer entry, snappy_runner.py:685). Kept apart from engine params so nothing in
    the handover pretends to be read, and ready for the step-8 hooks (dev plan section 9)."""
    mp = plan.mesh_plan
    rep = representation or representation_of(plan, facts)
    scale_mm = UNIT_TO_M[unit] * 1000.0
    seed_mm = [round(c * scale_mm, 3) for c in mp.seed_point] if mp.seed_point else None
    return {
        "mrf_zone": next((r.id for r in mp.regions if r.role == "rotating_zone"), None),
        "port_extensions": [{"patch_id": e.patch_id, "length": e.length, "length_mm": round(e.length * scale_mm, 3),
                             "reason": e.reason} for e in mp.port_extensions],
        "seed_point_mm": seed_mm,
        "seed_check": seed_check(facts, mp.seed_point, rep, mesh=mesh),
        "preserve_features": list(mp.preserve_features),
        # R37: `first_cell_height` is the plan's own number, the wall distance the y+ target is evaluated at; the
        # cell whose centre lands there is CENTRE_TO_CELL times as tall, and that is what a builder is handed
        "layer_targets": [{"patch_id": lt.patch_id, "n_layers": lt.n_layers, "first_cell_height": lt.first_cell_height,
                           "first_cell_mm": round(lt.first_cell_height * scale_mm, 5),
                           "first_layer_thickness_mm": round(CENTRE_TO_CELL * lt.first_cell_height * scale_mm, 5),
                           "reason": lt.reason[:120]}
                          for lt in mp.layer_targets],
        "layer_target_frame": (f"first_cell_height is the y+ wall distance (the first cell's centre); the first layer "
                               f"thickness is {CENTRE_TO_CELL:g} x it"),
        "refinement_regions": [r.model_dump() for r in mp.refinement_regions],
        "note": f"no platform reader at {PLATFORM_SHA[:8]}; see docs/handover_consumers.md and dev plan section 9",
    }


def impression_block(plan: GeometryPlan) -> dict[str, Any] | None:
    """The look as its own labelled block of the handover, or None when the run did not look.

    Its own key, its own label, the caveat the tool returned, and the words exactly as the checker filled them
    from the run. Nothing here is a measurement and nothing here is mixed into a field that carries one: a reader
    that wants a number reads `openings`, `strategy` or `forecast`, and a reader that wants to know what the part
    looks like reads this and knows what it is worth."""
    vi = plan.visual_impression
    if vi is None or not vi.impression:
        return None
    return {"label": IMPRESSION_LABEL, "is_measurement": False, "model": vi.model, "provider": vi.provider,
            "caveat": vi.caveat, "impression": dict(vi.impression)}


def _openings_as_they_look(seen: Any) -> str:
    """The openings the look can SEE, as the set of ids and nothing else.

    IT USED TO PRINT WHAT EACH ONE LOOKS LIKE AND WHAT ROLE IT SUGGESTS, and both are recorded fields.
    `vision.trust` says the opening class is a thing the measurement has exactly, and that `likely_role`
    abstains on six of every seven declared mouths and is a coin where it guesses. This line is prepended to
    the request the mesh planner reads, so it is a MODEL, and `trust.for_model` withholds both from a model.
    The line was contradicting the ledger the rest of the package enforces.

    What survives is what the ledger relies on: "the SET of ids it names is the finding", at 91 to 94 per cent
    recall with Jaccard 1.00 on a repeat call. An `unlabelled` entry stays, because it is the look reporting a
    mouth the measurement did not find, which is the one thing here no measurement can supply."""
    rows = [o for o in (seen or []) if isinstance(o, dict)]
    if not rows:
        return ""
    ids: list[str] = []
    for o in rows:
        oid = str(o.get("id") or "unlabelled")
        if oid not in ids:
            ids.append(oid)
    return ", ".join(ids)


#: At most this many distinct answers per placed clause. The line is capped at 300 characters and a clause
#: that fills it leaves no room for the four other relied-on clauses, which is the failure the grouping below
#: exists to avoid and the cap is the backstop for it.
PLACED_GROUPS_MAX = 3


def _placed_clause(rows: list[dict[str, Any]], kind: str) -> str:
    """The placed findings of one kind as one clause: the places, grouped by what was said at them.

    GROUPED FOR THE REASON THE OPENINGS WERE GROUPED, and that reason was measured. One clause per place runs
    to about forty characters, the strip carries up to eight letters, and a real reply gives the same answer at
    every one of them: written out, six identical answers are 240 characters of a 300-character line and the
    truncation then cuts the four relied-on clauses that follow. Grouped, the same reply is "A-F unobstructed
    passage interior", which is the whole finding in fifty.

    Never a coordinate. The line is prose in a request and a number in it would be the one thing this block
    promises is not there; the coordinate rides in the typed block, where a consumer reads it as a number
    instead of parsing it out of a sentence.
    """
    groups: dict[str, list[str]] = {}
    for r in rows:
        if str(r.get("kind")) != kind:
            continue
        said = str(r.get("the_look_says") or "").strip().rstrip(".")
        if said:
            groups.setdefault(said, []).append(str(r.get("at")))
    out = [f"{_run_of(ids)} {said}" for said, ids in list(groups.items())[:PLACED_GROUPS_MAX]]
    if len(groups) > PLACED_GROUPS_MAX:
        out.append(f"and {len(groups) - PLACED_GROUPS_MAX} more in the typed block")
    return "; ".join(out)


def _run_of(ids: list[str]) -> str:
    """Consecutive single letters as a range, anything else as a list. `A, B, C, D, E, F` is six places and
    reads as six findings; `A-F` is the same six and reads as one, which is what it is."""
    if len(ids) > 2 and all(len(i) == 1 and i.isalpha() for i in ids):
        codes = sorted(ord(i.upper()) for i in ids)
        if codes == list(range(codes[0], codes[0] + len(codes))):
            return f"{chr(codes[0])}-{chr(codes[-1])}"
    return ", ".join(ids)


#: The first clause of the candidate half, and the marker `_impression_floor` cuts at. A lead-in and not a
#: hidden sentinel: a reader of the line needs to be told where the half it may act on stops just as much as
#: the budget does, and one string cannot then drift from the other.
IMPRESSION_ASK_LEAD = "to ask about, not to act on"


def _places_of(plan: GeometryPlan) -> list[dict[str, Any]]:
    """The placed findings of a plan that carries the renderer's tables, or none.

    NO SCALE IS PASSED AND NONE IS WANTED. This feeds a PROSE line, which states places by name and never by
    coordinate; the coordinates ride in the typed block, where a consumer reads them as numbers instead of
    parsing them out of a sentence."""
    vi = getattr(plan, "visual_impression", None)
    drawn = dict(getattr(vi, "drawn", None) or {}) if vi is not None else {}
    if not drawn:
        return []
    return vplace.places(dict(getattr(vi, "impression", None) or {}),
                         marks=drawn.get("marks"), stopped=drawn.get("stops"))


def impression_clauses(plan: GeometryPlan, places: list[dict[str, Any]] | None = None
                       ) -> tuple[list[str], list[str]] | None:
    """The line's clauses, split into the half a builder may act on and the half it may only ask about.

    THE ORDER IS THE LEDGER'S, NOT A TUPLE'S. The tail of this line is what the character budget cuts, and it
    used to lead with `defects`, which over 322 parts raised three to five false alarms on clean files and
    caught neither of the two files that have a real defect, so it has never once been right. `symmetry`,
    `orientation` and `notes` were in it too and the measurement has the first two exactly. All four are
    RECORDED in `vision.trust`, which means they may not reach a model, and this line is prepended to the
    request a mesh planner reads. They are gone, not reordered.

    What leads now is what was measured highest and what no measurement can supply:

      attachments        25 of 25 recall at 93 to 100 per cent precision, and no measurement reports one
      passage ends       33 / 36 / 32 / 34 agreements a draw against 0 / 1 / 1 / 3, and the measured document
                         said nothing about where a passage stops on 322 of 322 parts
      marked places      1,524 / 1,476 / 1,517 / 1,481 agreements a draw against 5 / 10 / 8 / 24
      inside             an empty list is 0 false obstructions on 103 plain-passage cases
      openings it sees   91 to 94 per cent recall, Jaccard 1.00 on a repeat

    and the identity, which led the line and was its floor, is now the first thing in the half to ask about:
    right on 215 of 322 at best and flipping on 9 to 11 of 40 byte-identical repeats.
    """
    block = impression_block(plan)
    if block is None:
        return None
    imp = block["impression"]
    rows = [r for r in (places or []) if isinstance(r, dict)]

    def words(key: str) -> str:
        v = imp.get(key)
        if isinstance(v, (list, tuple)):
            return "; ".join(str(x) for x in v if str(x).strip())
        return str(v or "").strip()

    def keep(text: str) -> str:
        return "" if text.lower() in ("unsure", "none", "none apparent", "n/a") else text

    relied: list[str] = []
    for lead, text in (("flanges and fittings", keep(words("attachments"))),
                       ("where each passage ends", _placed_clause(rows, "passage_end")),
                       ("at the marked places", _placed_clause(rows, "marked_place"))):
        if text:
            relied.append(f"{lead}: {text}")
    inside = words("internal_features")
    # the EMPTY list is the relied-on finding and the non-empty one is a candidate, which is the one
    # value-dependent tier in the ledger. `trust.tier_of` owns that rule; this reads it rather than repeating it
    if not (imp.get("internal_features") or []):
        relied.append("inside the passage: plain, nothing across it")
    seen = _openings_as_they_look(imp.get("openings_seen"))
    if seen:
        relied.append("openings it can see: " + seen)

    ask: list[str] = []
    identity = keep(words("looks_like"))
    if identity:
        ask.append(f"{IMPRESSION_ASK_LEAD}: it may be {identity} "
                   f"(the look's own confidence: {words('confidence') or 'unsure'})")
    else:
        ask.append(f"{IMPRESSION_ASK_LEAD}:")
    if inside:
        ask.append("inside the passage: " + inside)
    for lead, text in (("thin walls", keep(words("thin_parts"))),
                       ("sharp edges and lips", keep(words("sharp_edges")))):
        if text:
            ask.append(f"{lead}: {text}")
    return relied, ask


def impression_line(plan: GeometryPlan, max_chars: int = IMPRESSION_LINE_MAX_CHARS,
                    places: list[dict[str, Any]] | None = None) -> str | None:
    """The same block as one labelled line for `builder_block`, or None when the run did not look.

    What a builder can do with it that it cannot do today: the planner reads the request as prose and has no
    picture of the part, so it sizes a duct and a bracket alike. This line tells it what is attached to the
    outside, where each passage ends, what is at each place the measurement marked, whether the passage is
    plain and which mouths the eye can find. Every one of those changes what a person would check before
    meshing, none of them is a number, and each one led the ledger rather than a tuple.

    `places` is `vision.place.places(...)`. A caller that does not pass it gets the places derived from the
    plan's own `visual_impression.drawn`, which the checker fills from the run, so `builder_block` needs to
    know nothing about the join. A plan with no `drawn` table is the line minus the two placed clauses."""
    got = impression_clauses(plan, places if places is not None else _places_of(plan))
    if got is None:
        return None
    relied, ask = got
    body = "; ".join(relied + ask)
    if len(body) > max_chars:
        body = body[:max_chars - 3].rstrip(" ;,") + "..."
    return f"{IMPRESSION_LINE_LABEL}: {body}"


def builder_block(plan: GeometryPlan, facts: GeometryFacts, max_chars: int = BUILDER_BLOCK_MAX_CHARS,
                  engine: str | None = None, cell_cap: int | None = None, representation: str | None = None,
                  header: str | None = None) -> str:
    """A fixed-budget block to prepend to the builder's request: the strategy header first (the planner reads
    request.txt[:2000], planner.py:186), then the look when there was one, then roles, flow, the risks that
    constrain authoring, refinement and layer targets, extents. Never over `max_chars`, so it cannot push the
    report past the tool cap. Lines are cut from the end and say so.

    The impression sits second because the header must stay first (it carries the planner's own keys) and because
    anything past 2000 characters of `request.txt` is not read at all. It is one labelled line, capped at
    IMPRESSION_LINE_MAX_CHARS, so the plan's own lines keep their place in that window."""
    mp = plan.mesh_plan
    head = header or strategy_header(plan, facts, engine, cell_cap, representation)
    look = impression_line(plan)
    lines = [head,
             *([look] if look else []),
             f"GEOMETRY PLAN ({plan.object.type}; purpose {plan.purpose}; confidence {plan.object.confidence:.2f})",
             "roles: " + ", ".join(f"{p.id}={p.role}" for p in plan.patches),
             f"flow: inlets {plan.flow.inlet_ids} outlets {plan.flow.outlet_ids} axis {plan.flow.axis} sign {plan.flow.direction_sign}"]
    decided = [r for r in plan.risks if r.severity in ("blocking", "high", "medium")]
    lines += [f"risk {r.id} {r.kind} [{r.severity}] decision={r.user_decision}: {r.recommendation[:110]}" for r in decided]
    after_plan_line = 2 + (1 if look else 0)
    lines.insert(after_plan_line, f"unit: {plan.unit.assumed} ({plan.unit.basis})")
    if mp.seed_point:
        lines.insert(after_plan_line + 1, f"seed point (inside the fluid): {[round(c, 4) for c in mp.seed_point]}")
    refined = f", refined ~{mp.cell_estimate_refined:,}" if mp.cell_estimate_refined else ""
    # `base_size` and `cell_estimate` are optional in the schema (schema.py:170-171) and a plan loaded from a
    # recording carries neither, so a block that formatted them unconditionally raised on every such plan and
    # took `handover()` down with it
    base = f"{mp.base_size:.4g}" if mp.base_size else "unstated"
    tier = f"~{mp.cell_estimate:,} cells" if mp.cell_estimate else "no tier estimate"
    lines.append(f"mesh: {mp.fidelity}, base {base}, tier {tier}{refined}")
    lines += [f"region {r.id}={r.role}" for r in mp.regions if r.role not in ("fluid", "obstacle", "solid")]
    lines += [f"refine {r.where[:40]} [{r.kind}]: size {r.target_size:.4g}"
              + (f" at {[round(c, 4) for c in r.anchor]} r={r.radius:.4g}" if r.anchor and r.radius else "")
              + (f" box {[round(c, 4) for c in r.box_min]}..{[round(c, 4) for c in r.box_max]}" if r.box_min and r.box_max else "")
              + (f" on {r.patch_ids}" if r.patch_ids else "")
              for r in mp.refinement_regions]
    lines += [f"layers {lt.patch_id}: {lt.n_layers} x first {lt.first_cell_height:.3g}" for lt in mp.layer_targets]
    lines += [f"extend {e.patch_id} by {e.length:.4g} ({e.reason[:60]})" for e in mp.port_extensions]
    if mp.required_extents:
        lines.append("extents: " + ", ".join(f"{k} {v:.4g}" for k, v in mp.required_extents.items()))
    if mp.preserve_features:
        lines.append("preserve: " + ", ".join(mp.preserve_features)[:200])
    if mp.assumptions:
        lines.append("assumptions: " + "; ".join(mp.assumptions)[:300])
    lines.append("builder summary: " + plan.summary_for_builder[:600])
    # the look rides on top of the budget rather than out of it: the plan's own lines are what `max_chars` was
    # sized for, and a block that dropped a layer target to make room for a description would be a bad trade.
    # Measured on manifold_short, whose block sits just under 2400: out of the budget the line cost four lines
    # from the end, the builder summary among them; on top of it, none.
    budget = max_chars + (len(look) + 1 if look else 0)
    out = "\n".join(lines)
    if len(out) <= budget:
        return out
    kept: list[str] = []
    for i, ln in enumerate(lines):
        note = f"[{len(lines) - i} more lines omitted to fit the block budget]"
        if len("\n".join(kept + [ln, note])) > budget:
            kept.append(note)
            break
        kept.append(ln)
    return "\n".join(kept)[:budget]


# ---------------------------------------------------------------------------------------------------------------
# triage: the platform's pre-mesh refusals, emulated on the agent's openings, logged never enforced
# ---------------------------------------------------------------------------------------------------------------
class _Declared:
    """A declared port in file units, whichever shape it arrived in: the corpus rows {name, role, near, area,
    bore_diameter} or the intake rows {name, type|role, diameter_mm | area_mm2 | width_mm+height_mm, near_mm,
    interchangeable_with}."""

    def __init__(self, row: dict[str, Any], to_file: float):
        self.name = str(row.get("name") or "")
        self.role = str(row.get("role") or row.get("type") or "")
        self.interchangeable = tuple(str(x) for x in (row.get("interchangeable_with") or ()))
        self.forms = 0
        self.area: float | None = None
        self.d: float | None = None
        self.wh: tuple[float, float] | None = None
        self.near: tuple[float, float, float] | None = None
        self.near_valid = True
        mm_keys = ("diameter_mm", "area_mm2", "width_mm", "height_mm", "near_mm")
        if any(k in row for k in mm_keys):
            d, a, w, h = row.get("diameter_mm"), row.get("area_mm2"), row.get("width_mm"), row.get("height_mm")
            self.forms = sum((d is not None, a is not None, w is not None or h is not None))
            if d is not None:
                self.d = float(d) * to_file
                self.area = math.pi * (self.d / 2.0) ** 2
            elif a is not None:
                self.area = float(a) * to_file * to_file
            elif w is not None and h is not None:
                self.wh = (float(w) * to_file, float(h) * to_file)
                self.area = self.wh[0] * self.wh[1]
            near = row.get("near_mm")
            if near is not None:
                ok = isinstance(near, (list, tuple)) and len(near) == 3 and all(isinstance(c, (int, float)) and not isinstance(c, bool) for c in near)
                self.near_valid = bool(ok)
                self.near = tuple(float(c) * to_file for c in near) if ok else None
        else:
            bore = row.get("bore_diameter")
            if bore:
                self.d = float(bore)
                self.area = float(row.get("area") or math.pi * (self.d / 2.0) ** 2)
                self.forms = 1
            elif row.get("area"):
                self.area = float(row["area"])
                self.forms = 1
            near = row.get("near")
            if near is not None and len(near) == 3:
                self.near = tuple(float(c) for c in near)

    def mm_row(self, to_mm: float) -> dict[str, Any]:
        row: dict[str, Any] = {"name": self.name, "role": self.role, "type": self.role}
        if self.d is not None:
            row["diameter_mm"] = self.d * to_mm
        elif self.wh is not None:
            row["width_mm"], row["height_mm"] = self.wh[0] * to_mm, self.wh[1] * to_mm
        elif self.area is not None:
            row["area_mm2"] = self.area * to_mm * to_mm
        if self.near is not None:
            row["near_mm"] = [c * to_mm for c in self.near]
        return row


def _planar_candidates(facts: GeometryFacts) -> list[dict[str, Any]]:
    """The faces OCC would call planar openings (cad_tessellate.py:588-591, every planar face is an opening
    candidate): the agent's caps and rings, and its planar_face class. A ring's face is its annulus and its inner
    opening the bore (:565-584); a cap is its own opening. Open rims are not faces."""
    out = []
    for o in facts.openings:
        if not (o.kind in ("cap", "ring") or o.classification == "planar_face"):
            continue
        if o.kind == "ring" and o.bore_area:
            inner = {"area": float(o.bore_area), "wh": (float(o.bore_diameter), float(o.bore_diameter)) if o.shape == "circle" and o.bore_diameter else None}
            face_area = max(0.0, float(o.area) - float(o.bore_area))
        else:
            inner, face_area = None, float(o.area)
        out.append({"id": o.id, "area": face_area, "centroid": tuple(float(c) for c in o.centroid), "inner": inner, "opening": o})
    return out


def _band_ok(measured: float, declared: float) -> bool:
    if declared <= 0:
        return False
    r = measured / declared
    return (AREA_RATIO_LO - 1e-9) <= r <= (AREA_RATIO_HI + 1e-9)


def _shape_agrees(inner: dict[str, Any], port: _Declared) -> bool:
    """cad_tessellate.py:91-113: a declared circle or rectangle must agree with a ring's inner wire in each
    dimension within the linear band and in fill factor within 0.1."""
    wh = inner.get("wh")
    if not wh or not (wh[0] > 0 and wh[1] > 0):
        return True
    if port.d:
        want, fill_want = (port.d, port.d), FILL_CIRCLE
    elif port.wh:
        want, fill_want = port.wh, FILL_RECT
    else:
        return True
    (a, b), (p, q) = sorted(wh), sorted(want)
    lo, hi = AREA_RATIO_LO ** 0.5, AREA_RATIO_HI ** 0.5
    if not (lo <= a / p <= hi and lo <= b / q <= hi):
        return False
    fill = float(inner.get("area") or 0.0) / (wh[0] * wh[1])
    return abs(fill - fill_want) <= FILL_TOL


def _size_agrees(cand: dict[str, Any], declared_area: float, port: _Declared | None = None, shape: bool = False) -> bool:
    """port_binding.py:93-106: the face area or, for a ring, the inner opening, inside the band."""
    if _band_ok(cand["area"], declared_area):
        return True
    inner = cand.get("inner")
    if inner and inner.get("area"):
        if shape and port is not None and not _shape_agrees(inner, port):
            return False
        return _band_ok(float(inner["area"]), declared_area)
    return False


def _select_declared(cands: list[dict[str, Any]], declared: list[_Declared], dist_quantum: float) -> tuple[list[dict[str, Any]], dict[str, Any] | None]:
    """cad_tessellate.py:116-196 select_declared_openings: hinted ports in name order, then sized; the best
    candidate by (hint distance, size error bucket, smallest face, index); a port no face satisfies raises."""
    remaining = dict(enumerate(cands))
    chosen: list[dict[str, Any]] = []
    hinted = sorted((p for p in declared if p.near), key=lambda p: p.name)
    sized = sorted((p for p in declared if not p.near), key=lambda p: p.name)
    for port in hinted + sized:
        best = None
        for idx, c in remaining.items():
            if port.area:
                errs = []
                if _band_ok(c["area"], port.area):
                    errs.append(abs(c["area"] / port.area - 1.0))
                inner = c.get("inner")
                if inner and inner.get("area") and _shape_agrees(inner, port) and _band_ok(float(inner["area"]), port.area):
                    errs.append(abs(float(inner["area"]) / port.area - 1.0))
                if not errs:
                    continue
                bucket, tie = int(min(errs) / SIZE_ERR_QUANTUM), c["area"]
            else:
                bucket, tie = 0, 0.0
            if port.near:
                d = math.dist(port.near, c["centroid"])
                score = (round(d / dist_quantum), bucket, tie, idx)
            else:
                score = (0, bucket, tie, idx)
            if best is None or score < best[0]:
                best = (score, idx)
        if best is None:
            return chosen, {"rule": "cad_tessellate.select_declared_openings", "file": "cad/cad_tessellate.py", "line": 190,
                            "message": f"declared port {port.name!r} matches none of the remaining flat faces by size or location"}
        chosen.append(remaining.pop(best[1]))
    return chosen, None


def _bind_ports(ports: list[_Declared], openings: list[dict[str, Any]], diag: float) -> dict[str, Any] | None:
    """port_binding.py:127-294 bind_ports on the agent's openings: the first BindError the platform would raise,
    as {rule, file, line, message}, or None when every port binds."""
    f = "engines/port_binding.py"
    for p in ports:
        if p.forms > 1:
            return {"rule": "bind_ports rule 0", "file": f, "line": 143, "message": f"port {p.name!r} declares more than one size form"}
        if p.area is None and p.near is None:
            return {"rule": "bind_ports rule 0", "file": f, "line": 146, "message": f"port {p.name!r} has no size and no location"}
    if len(openings) < len(ports):
        return {"rule": "bind_ports rule 1", "file": f, "line": 154,
                "message": f"declared {len(ports)} ports but only {len(openings)} openings were detected"}
    pool = {c["id"]: c for c in openings}
    bound: dict[str, str] = {}
    for p in sorted((q for q in ports if q.near is not None), key=lambda q: q.name):
        ranked = sorted(pool.values(), key=lambda c: math.dist(p.near, c["centroid"]))
        c0 = ranked[0]
        d1 = math.dist(p.near, c0["centroid"])
        d2 = math.dist(p.near, ranked[1]["centroid"]) if len(ranked) > 1 else math.inf
        if d1 > HINT_MAX_BBOX_FRACTION * diag:
            return {"rule": "bind_ports rule 2", "file": f, "line": 177,
                    "message": f"port {p.name!r}'s location is {d1:.4g} from the nearest opening {c0['id']}, over {HINT_MAX_BBOX_FRACTION} x the diagonal"}
        if d1 > HINT_MARGIN * d2:
            return {"rule": "bind_ports rule 2", "file": f, "line": 183,
                    "message": f"port {p.name!r}'s location does not decisively pick one opening ({c0['id']} at {d1:.4g}, {ranked[1]['id']} at {d2:.4g})"}
        if p.area is not None and not _size_agrees(c0, p.area):
            return {"rule": "bind_ports rule 2", "file": f, "line": 191,
                    "message": f"port {p.name!r} points at {c0['id']} by location but its size {p.area:.4g} disagrees with the opening"}
        bound[p.name] = c0["id"]
        del pool[c0["id"]]
    remaining = [p for p in ports if p.name not in bound]
    classes: dict[float, list[_Declared]] = {}
    for p in remaining:
        classes.setdefault(float(p.area), []).append(p)
    areas = sorted(classes)
    for lo, hi in zip(areas, areas[1:]):
        if hi / lo < MIN_CLASS_SEPARATION - 1e-9:
            return {"rule": "bind_ports rule 3b", "file": f, "line": 217,
                    "message": f"declared sizes {[q.name for q in classes[lo]]} and {[q.name for q in classes[hi]]} are closer than 5/3 in area without locations"}
    matches: dict[str, list[float]] = {}
    for key, c in pool.items():
        matches[key] = [a for a in classes if _size_agrees(c, a)]
        if len(matches[key]) > 1:
            return {"rule": "bind_ports band uniqueness", "file": f, "line": 231,
                    "message": f"opening {key} matches more than one declared size"}
    for class_area, class_ports in sorted(classes.items()):
        candidates = [k for k, m in matches.items() if m == [class_area]]
        names = sorted(p.name for p in class_ports)
        if len(candidates) < len(class_ports):
            return {"rule": "bind_ports rule 3", "file": f, "line": 242,
                    "message": f"declared ports {names} ({class_area:.4g}) match only {len(candidates)} opening(s) of that size"}
        if len(candidates) > len(class_ports):
            return {"rule": "bind_ports rule 3", "file": f, "line": 249,
                    "message": f"{len(candidates)} openings match the size of ports {names} but only {len(class_ports)} declared"}
        if len(class_ports) > 1:
            roles = {p.role for p in class_ports}
            confirmed = all(q.name in p.interchangeable and p.name in q.interchangeable
                            for p in class_ports for q in class_ports if p.name != q.name)
            if len(roles) > 1 or not confirmed:
                return {"rule": "bind_ports rule 4", "file": f, "line": 265,
                        "message": f"ports {names} declare the same size and are not mutually interchangeable"}
        for k in candidates:
            del pool[k]
    return None


def triage(facts: GeometryFacts, declared: list[dict[str, Any]] | None, purpose: str, engine: str,
           unit: str | None = None, brief: str | None = None, representation: str | None = None) -> dict[str, Any]:
    """The platform's own pre-mesh refusals, predicted from the agent's measurements: tessellate_internal's
    solid and two-openings rules and its declared-port selection, bind_ports' bands, class separation and hint
    decisiveness, gmsh's no-solid rule. `do_not_dispatch` only when a platform raise is replicated; `needs_fix`
    when intake's own validator would refuse the declaration (one question, no run); statistical warnings never
    block and are listed under `notes`. Logged in the handover, never enforced."""
    unit = unit or facts.units.declared or "mm"
    to_file = 1.0 / (UNIT_TO_M[unit] * 1000.0)
    to_mm = UNIT_TO_M[unit] * 1000.0
    rows = [_Declared(r, to_file) for r in (declared or []) if isinstance(r, dict)]
    ports = [r for r in rows if r.role in ("inlet", "outlet")]
    reasons: list[str] = []
    predicted: list[dict[str, Any]] = []
    notes: list[str] = []
    verdict = "buildable"
    rep = representation or ("external" if purpose == "external_cfd" else catalog.representation(facts, purpose, brief))  # type: ignore[arg-type]
    internal = purpose in ("internal_cfd", "conjugate_heat_transfer") and engine in ("snappy", "cfmesh")
    if internal:
        planar = _planar_candidates(facts)
        if facts.source_format.lower() in ("stl", "obj", "ply"):
            predicted.append({"rule": "internal build needs a CAD solid", "file": "engines/snappy/drivers.py", "line": 456,
                              "message": f"the internal build tessellates a STEP or IGES solid; the file is {facts.source_format}"})
        elif not facts.watertight:
            predicted.append({"rule": "tessellate_internal no solid", "file": "cad/cad_tessellate.py", "line": 498,
                              "message": "internal-flow input is not a watertight solid (the agent's tessellation is open)"})
        # A REFUSED COUNT IS NOT A MEASURED ZERO. Where the opening detector turned flat faces down at its
        # tubularity gate (every mouth of a part whose outer edges are filleted), the measurement says the mouths
        # were refused, not absent (`facts.opening_gate`, the measure warning). Reading that as "the agent
        # measures 0" predicted the platform's two-openings raise and put a send-it-back question to the
        # customer on a part whose mouths are there; the platform's own detector reads B-rep planar faces and is
        # not this one. So with refused candidates and fewer than two found, the rule is not predicted
        refused = int(getattr(getattr(facts, "opening_gate", None), "rejected_by_tubularity", 0) or 0)
        if len(planar) < 2 and refused:
            notes.append(f"the opening detector refused {refused} flat face(s) at its tubularity gate and found "
                         f"{len(planar)}, so whether the platform finds two flat openings cannot be predicted from "
                         "this measurement")
        elif len(planar) < 2:
            predicted.append({"rule": "tessellate_internal two openings", "file": "cad/cad_tessellate.py", "line": 605,
                              "message": f"internal-flow geometry needs >=2 flat openings; the agent measures {len(planar)}"})
        elif not predicted:
            openings = planar
            if ports and len(planar) > len(ports) >= 2:
                chosen, failure = _select_declared(planar, ports, DIST_QUANTUM_M / UNIT_TO_M[unit])
                if failure:
                    predicted.append(failure)
                else:
                    openings = chosen
                    notes.append(f"declaration selects {len(chosen)} of {len(planar)} planar faces as openings (cad_tessellate.py:593-604)")
            elif len(planar) > 2 and not ports:
                notes.append(f"no declaration: all {len(planar)} planar faces become ports and the widest is taken as the inlet "
                             "(cad_tessellate.py:614, :631)")
            if ports and not predicted:
                problems = declaration_problems([r.mm_row(to_mm) for r in ports])
                bad_near = [r.name for r in ports if not r.near_valid]
                if bad_near:
                    problems.append(f"near_mm must be [x, y, z] in millimetres: {bad_near}")
                if problems:
                    verdict = "needs_fix"
                    reasons += [f"intake would refuse (validation.py:246-340): {p}" for p in problems]
                failure = _bind_ports(ports, openings, float(facts.bbox.diagonal))
                if failure:
                    predicted.append(failure)
    if engine == "gmsh":
        if not facts.watertight:
            predicted.append({"rule": "gmsh no solid volumes", "file": "engines/gmsh/driver.py", "line": 275,
                              "message": "no closed body to mesh as a solid (the agent's surface is not watertight)"})
        if facts.source_format.lower() in ("stl", "obj", "ply"):
            predicted.append({"rule": "gmsh needs geometry.step", "file": "engines/gmsh/driver.py", "line": 229,
                              "message": f"the gmsh driver imports geometry.step; the file is {facts.source_format}"})
    if predicted:
        verdict = "do_not_dispatch"
        reasons += [f"{p['rule']} ({p['file']}:{p['line']}): {p['message']}" for p in predicted]
    if internal and rep in ("wall_shell", "carve"):
        tilted = [o.id for o in catalog.port_openings(facts, "wall_shell") if o.shape == "circle" and tools.port_tilt_deg(o) > 0.5]
        if tilted:
            notes.append(f"tilted circular mouths {tilted}: the port cap sits one level coarser than the wall "
                         "(snappy_runner.py:636), a skew risk, not a refusal")
    return {"verdict": verdict, "reasons": reasons, "platform_rule_predicted": predicted, "notes": notes,
            "engine": engine, "purpose": purpose, "representation": rep, "declared_ports": len(ports),
            "planar_openings": len(_planar_candidates(facts)), "platform_sha": PLATFORM_SHA, "enforced": False}


# ---------------------------------------------------------------------------------------------------------------
# who reads each handover field, as a table rather than as a sentence in a document
#
# docs/handover_consumers.md used to state the count of unreadable fields in prose, which goes stale the moment a
# field is added and nobody notices for a run or two. The table below is the source, the document renders from
# it, and `tests/test_channel.py` asserts three things: every field `handover()` emits has a row, every row names
# a field it emits, and the count of fields with no reader is the number the document prints. Adding a field
# without saying who reads it now fails a test.
# ---------------------------------------------------------------------------------------------------------------

#: What each status means.
#:   platform  a named platform reader consumes the field; the `reader` column says which, at PLATFORM_SHA
#:   prose     it reaches the planner only as text inside `request.txt`, cut at 2,000 characters
#:   none      no reader at PLATFORM_SHA, and this package intends one; `hook` names the dev plan step
#:   agent     the agent's own record, never meant for a platform reader, so its absence is not a gap
HANDOVER_READER_STATUS = ("platform", "prose", "none", "agent")

HANDOVER_READERS: dict[str, tuple[str, str, str]] = {
    # field: (status, reader or the reason there is none, dev plan step)
    "purpose": ("platform", "agents/intake/validation.py:_admission:90-101, :423; engines/purposes.py:44", ""),
    "unit": ("none", "intake reads no geometry: executor.py:126-138 reads a staged directory the upload endpoint "
                     "has already deleted; the port rows are already in millimetres (validation.py:289)", "8.2"),
    "unit_basis": ("none", "as unit", "8.2"),
    "representation": ("none", "cad/cad_tessellate.py:tessellate_internal:588-591 decides by itself", "8.2"),
    "engine": ("platform", "agents/intake/agent.py:514 mesh_engine, engine_source; pipeline/data_contract.py:209", ""),
    "seed_point_mm": ("none", "locationInMesh is chosen inside tessellate_internal (cad_tessellate.py:881-929) "
                              "and rendered at snappy_runner.py:682", "8.3"),
    "input_kind": ("platform", "validation.py:508-510 _INPUT_KINDS; data_contract.py:153-154", ""),
    "dimensionality": ("platform", "validation.py:482-484; data_contract.py:91-94; gmsh driver.py:242-252", ""),
    "patches": ("platform", "validation.py:423-456; data_contract.py:84-85; port_binding.py:48; drivers.py:467-473", ""),
    "port_declaration": ("platform", "validation.py:246-340; port_binding.py:46-313; cad_tessellate.py:116-196", ""),
    "declaration_problems": ("agent", "the agent's mirror of validation.py:246-340; a refusal is one chat question", ""),
    "requested_extents": ("platform", "validation.py:346-388; domain_extent_gate.py:153", ""),
    "reference_length_m": ("platform", "planner.py:29, drivers.py:94, :348; snappy_runner.py:140 into the manifest", ""),
    "flow_axis": ("platform", "snappy_runner.py:311-335 domain_from_strategy; domain_extent_gate._axis_margins", ""),
    "requirements_strict": ("platform", "validation.py:346-388; domain_extent_gate FLOOR_FRACTION 0.5, tol 0.15", ""),
    "reference_length_source": ("none", "domain_extent_gate.py:87 reads the manifest the renderer writes, not this "
                                        "field; informational", ""),
    "engine_admission": ("none", "engines/base.py:429 admit; its measured phase :549-556 knows only "
                                 "self_intersecting and thin_gap and no engine declares them", "8.4"),
    "engine_params_hints": ("prose", "the strategy keys come from the planner; snappy declares intake_params=() "
                                     "(spec.py:167), so the only route is text in request.txt", "8.3"),
    "strategy_header": ("prose", "request.txt (workspace.py:27-35), cut at 2,000 by planner.py:186", "8.2"),
    "builder_plan_block": ("prose", "request.txt, the same cut; this is what the request should carry, and never "
                                    "both this and strategy_header", "8.2"),
    "builder_block": ("prose", "request.txt as prose when the harness prepends it; a fixed-budget block for a "
                               "reader that is not the planner", "8.2"),
    "strategy": ("agent", "the ledger's record of what the header states and why", ""),
    "builder_directives": ("agent", "the structured record behind builder_plan_block: what was admitted, what it "
                                    "costs and what was refused", ""),
    "unreachable": ("agent", "every measured item no key reaches at this sha, with the step that would give it "
                             "one; a report row, never a builder instruction", ""),
    "forecast": ("none", "nothing gates on a cell count except CELL_HARD_LIMIT 8e6 (flow_gates.py:85), and intake "
                         "tells the reviewer not to judge cell count at all", "8.5"),
    # `advisory` is one handover key and seven separate asks of the platform, so it is stated at the granularity
    # the platform would have to answer it: each row is one thing that would need a reader, with its own step.
    "advisory.mrf_zone": ("none", "no MRF or cellZone authoring under engines/snappy; cellZone appears only in "
                                  "snappy_multiregion/multiregion_runner.py:134-136", ""),
    "advisory.port_extensions": ("none", "tessellate_internal writes the faces as they are "
                                         "(cad_tessellate.py:606-640)", "8.8"),
    "advisory.seed_point_mm": ("none", "as seed_point_mm", "8.3"),
    "advisory.seed_check": ("none", "as seed_point_mm; the platform chooses the point itself", "8.3"),
    "advisory.preserve_features": ("none", "one includedAngle per surface (snappy_runner.py:602-603) and one "
                                           "features level for every surface (:663, :531)", "8.3"),
    "advisory.layer_targets": ("none", "one wall layers entry (snappy_runner.py:685); external :526-527 one per "
                                       "region name", "8.3"),
    "advisory.refinement_regions": ("none", "refinementRegions is the wall distance band only "
                                            "(snappy_runner.py:681 internal, :535 external): no spheres, no boxes",
                                    "8.3 plus authored refinementRegions"),
    "triage": ("none", "the platform's own admission is engines/base.py:429; the verdict is logged never enforced", "8.4"),
    "visual_impression": ("agent", "a description of nine renders, labelled as not a measurement; the impression "
                                   "line reaches the planner through builder_plan_block when there is room", ""),
    "blockers": ("agent", "the agent's own refusals", ""),
    "questions": ("agent", "the intake conversation's (agents/intake/agent.py)", ""),
    "warnings": ("agent", "the schema 3 lists by audience; the builder half arrives as builder_plan_block", ""),
    "platform_sha": ("agent", "the revision every line above is pinned to", ""),
}


def handover_reader_counts() -> dict[str, int]:
    """How many handover fields each status holds. `none` is the number docs/handover_consumers.md prints and
    `tests/test_channel.py` asserts, so the document cannot drift from the code."""
    out = dict.fromkeys(HANDOVER_READER_STATUS, 0)
    for status, _reader, _hook in HANDOVER_READERS.values():
        out[status] += 1
    return out


def handover_keys() -> set[str]:
    """The top-level handover keys the table covers; `advisory` is stated as its seven members and folds back."""
    return {f.split(".")[0] for f in HANDOVER_READERS}


def unreadable_handover_fields() -> list[str]:
    """The handover fields with no platform reader at PLATFORM_SHA, in the order the table states them."""
    return [f for f, (status, _r, _h) in HANDOVER_READERS.items() if status == "none"]


# ---------------------------------------------------------------------------------------------------------------
# the handover and the session report
# ---------------------------------------------------------------------------------------------------------------
def handover(plan: GeometryPlan, facts: GeometryFacts, unit: str | None = None, *, cell_cap: int | None = None,
             engine: str | None = None, declared: list[dict[str, Any]] | None = None, brief: str | None = None,
             mesh=None, representation: str | None = None) -> dict[str, Any]:
    """Everything intake and the builder need, in their words, plus what still blocks the handover. The unit
    is the plan's own call unless the caller (the confirm step, after the user answered) overrides it. The user's
    cell cap bounds max_cells; the triage runs on `declared` when given, else on the agent's own port rows.

    A plan whose catalog risks are still written by reference is filled once here (P4.4, `catalog_filled`), so
    the readers below that ask a risk what kind it is get the catalog's answer and none of them runs the catalog
    a second time."""
    plan = catalog_filled(plan, facts, cell_cap=cell_cap, declared=declared, brief=brief)
    unit = unit or plan.unit.assumed
    # THE SURVEY'S REPRESENTATION WHEN THERE IS ONE (work/z-chain NEEDS 1). `representation_of` rewrites `unknown`
    # to `fluid_domain` (2 of 322 corpus parts) and lets a plan's region role override the measurement, which is
    # the geometry agent re-deciding what the part IS. The chain resolves it once, with the brief, and passes it
    rep = representation or representation_of(plan, facts, brief)
    engine = engine or default_engine(plan, brief)
    rows = port_declaration(plan, facts, unit)
    strat = builder_strategy(plan, facts, engine, cell_cap, rep, unit, brief)
    directive_pack = builder_directives(plan, facts, engine, cell_cap, rep, unit, brief, strategy=strat)
    scale_mm = UNIT_TO_M[unit] * 1000.0
    return {
        "purpose": plan.purpose,
        "unit": unit,
        "unit_basis": plan.unit.basis,
        "representation": rep,
        "engine": engine,
        "seed_point_mm": [round(c * scale_mm, 3) for c in plan.mesh_plan.seed_point] if plan.mesh_plan.seed_point else None,
        "input_kind": ("solid-assembly" if plan.purpose == "conjugate_heat_transfer" else
                       "solid-body" if plan.purpose == "structural" else "body-surface"),
        "dimensionality": "2D" if min(facts.bbox.extent) <= 1e-9 * max(facts.bbox.extent) else "3D",
        "patches": intake_patches(plan, facts),
        "port_declaration": rows,
        "declaration_problems": declaration_problems(rows),
        **domain_declaration(plan, facts, unit),
        "engine_admission": engine_admission(plan, facts),
        "engine_params_hints": engine_params_hints(plan, facts, cell_cap, rep, strat if strat["engine"] == "snappy" else None),
        "strategy_header": strat["header"],
        "strategy": {"keys": strat["keys"], "why": strat["why"], "notes": strat["notes"], "budget": strat["budget"]},
        # ONE SPELLING OF ONE DIRECTION. This used to pass `_snap_axis(plan.flow.axis)` alone, without the
        # `direction_sign` flip that `domain_declaration` (:434-436) and `_external_strategy` (:746-747) both
        # apply, so one function's output carried the forecast priced along `+x` beside a declaration and a
        # builder strategy that both said `-x`. `_flow_axis_signed` is the one reader, and it is the flipped
        # one because that is what `_external_strategy` hands the builder.
        "forecast": forecast(facts, {**strat["keys"], "flow_axis": _flow_axis_signed(plan)}, rep, strat["engine"], cell_cap,
                             inlet_id=next((i for i in plan.flow.inlet_ids if facts.opening(i) is not None), None)),
        "advisory": advisory(plan, facts, unit, rep, mesh=mesh),
        "triage": triage(facts, declared if declared is not None else rows, plan.purpose, engine, unit=unit, brief=brief,
                         representation=rep),
        "builder_block": builder_block(plan, facts, engine=engine, cell_cap=cell_cap, representation=rep, header=strat["header"]),
        #: The look, on its own, labelled, never mixed into a field that carries a measurement (dev plan P9).
        "visual_impression": impression_block(plan),
        #: The builder-facing output, rebuilt as instructions: the keys the builder can take directly, the ranked
        #: directives behind them with what each costs against the customer's cap, what goes to the user instead
        #: and what has no reader at this sha. `builder_plan_block` is what a request carries; it supersedes
        #: `strategy_header`, and the two are never both prepended (docs/builder_directives.md, section 6).
        "builder_directives": {k: v for k, v in directive_pack.items() if k != "to_report"},
        "builder_plan_block": builder_plan_block(plan, facts, engine=engine, cell_cap=cell_cap, representation=rep,
                                                 unit=unit, brief=brief, request_txt=brief,
                                                 directives=directive_pack, impression=impression_line(plan)),
        "unreachable": directive_pack["to_report"],
        "blockers": blockers(plan, facts, cell_cap=cell_cap, declared=declared, brief=brief),
        "questions": [q.model_dump() for q in plan.questions],
        "warnings": warnings_by_audience(plan, facts, cell_cap=cell_cap, declared=declared, brief=brief),
        "platform_sha": PLATFORM_SHA,
    }


def warnings_by_audience(plan: GeometryPlan, facts: GeometryFacts, *, cell_cap: int | None = None,
                         declared: list[dict[str, Any]] | None = None, brief: str | None = None) -> dict[str, list[dict[str, Any]]]:
    """The schema 3 outputs by audience (dev plan P4.2): `user` is the plan's simulation_warnings (one question
    each, with its default and effect), `builder` its mesh_warnings (in the builder's frame), `info` every other
    risk as a row. A plan that carries the lists is read as it is; one built outside the checker (a schema 2 plan
    loaded from JSON) gets them synthesised from its catalog risks the way grounding._normalise does.

    P4.4: the synthesis reads each risk's kind to decide whose warning it is, so a plan still carrying the P4.3e
    short form is filled from the catalog first (`catalog_filled`). Without that a short-form plan's user list
    comes back with an empty kind on every row and one row short, and the info rows carry the schema's default
    severity instead of the catalog's."""
    from geometry_agent.agent import grounding
    from geometry_agent.agent.tools import ToolContext
    plan = catalog_filled(plan, facts, cell_cap=cell_cap, declared=declared, brief=brief)
    sims, mws = list(plan.simulation_warnings or []), list(plan.mesh_warnings or [])
    if plan.simulation_warnings is None or plan.mesh_warnings is None:
        ctx = ToolContext(facts=facts, purpose=plan.purpose, fidelity=plan.mesh_plan.fidelity, cell_cap=cell_cap,
                          declared=declared, brief=brief or "")
        sims, mws = grounding.warnings_for(plan, ctx)
    covered = set()
    for w in sims:
        covered.add(w.provenance.get("risk_id"))
        covered |= set(w.also_settles)
    for w in mws:
        covered.add(w.provenance.get("risk_id"))
    questions_for: dict[str, Any] = {}
    for q in plan.questions:
        for rid in [q.relates_to, *q.also_settles]:
            questions_for.setdefault(rid, q)
    info = []
    for r in plan.risks:
        if r.id in covered:
            continue
        q = questions_for.get(r.id)
        info.append({"id": r.id, "kind": r.kind, "severity": r.severity, "measurement": r.measurement, "consequence": r.consequence,
                     "recommendation": r.recommendation, "detected_by": r.detected_by, "user_decision": r.user_decision,
                     "mechanism": r.mechanism, "effect": r.effect,
                     "question": ({"id": q.id, "text": q.text, "options": q.options, "default": q.default} if q else None)})
    return {"user": [{**w.model_dump(), "risk_id": w.provenance.get("risk_id")} for w in sims],
            "builder": [{**w.model_dump(), "risk_id": w.provenance.get("risk_id")} for w in mws],
            "info": info}


def handover_json(plan: GeometryPlan, facts: GeometryFacts, unit: str | None = None, **kw) -> str:
    return json.dumps(handover(plan, facts, unit, **kw), indent=1, default=str)


def _region_names(facts: GeometryFacts) -> list[str]:
    """Component names the way cad/regions.py:36-46 keeps them: generated translator names dropped."""
    out = []
    for n in facts.names:
        name = (n.name or "").strip()
        if len(name) < 2 or any(name.lower().startswith(p) for p in GENERATED_NAME_PREFIXES):
            continue
        if name not in out:
            out.append(name)
    return out


def report(plan: GeometryPlan, facts: GeometryFacts, unit: str | None = None, *, cell_cap: int | None = None,
           engine: str | None = None, declared: list[dict[str, Any]] | None = None, brief: str | None = None,
           mesh=None, representation: str | None = None) -> dict[str, Any]:
    """The one JSON step 8 stores on the session (dev plan P4.2 and 8.1), keyed by the source sha256: admission
    facts in the shape of regions_for_session().as_facts() plus watertight and the planar openings; the opening
    table in metres and millimetres; bbox and unit evidence; the port declaration rows (always with near_mm);
    the representation and seed point with its ray-parity check; the forecast; warnings by audience from the
    plan's two lists (schema 3: simulation warnings to the user, mesh warnings to the builder, every other risk
    as info); the header; the triage."""
    h = handover(plan, facts, unit, cell_cap=cell_cap, engine=engine, declared=declared, brief=brief, mesh=mesh,
                 representation=representation)
    unit = h["unit"]
    s_m = UNIT_TO_M[unit]
    s_mm = s_m * 1000.0
    roles = {p.id: p.role for p in plan.patches}
    openings = []
    for o in facts.openings:
        openings.append({
            "id": o.id, "kind": o.kind, "classification": o.classification, "shape": o.shape, "role": roles.get(o.id),
            "region_id": o.region_id, "planar": o.kind in ("cap", "ring") or o.classification == "planar_face",
            "area_m2": o.area * s_m * s_m, "area_mm2": round(o.area * s_mm * s_mm, 3),
            "bore_area_mm2": round(o.bore_area * s_mm * s_mm, 3) if o.bore_area else None,
            "hydraulic_diameter_m": o.hydraulic_diameter * s_m, "hydraulic_diameter_mm": round(o.hydraulic_diameter * s_mm, 4),
            "bore_diameter_mm": round(o.bore_diameter * s_mm, 4) if o.bore_diameter else None,
            "min_dimension_mm": round(tools.port_min_dimension(o) * s_mm, 4),
            "centroid_m": [c * s_m for c in o.centroid], "centroid_mm": [round(c * s_mm, 3) for c in o.centroid],
            "normal": list(o.normal), "tilt_deg": round(tools.port_tilt_deg(o), 3),
            "on_bbox_face": o.on_bbox_face, "bbox_side": o.bbox_side,
        })
    warnings = h["warnings"]
    names = _region_names(facts)
    ext = facts.bbox.extent
    return {
        "schema": "geometry_agent.report.v1",
        "source_sha256": facts.sha256,
        "source": facts.source_path,
        "source_format": facts.source_format,
        "platform_sha": PLATFORM_SHA,
        "purpose": plan.purpose, "engine": h["engine"], "input_kind": h["input_kind"], "dimensionality": h["dimensionality"],
        "representation": h["representation"], "representation_corpus": corpus_representation(h["representation"]),
        "admission_facts": {"region_names": names, "region_count": len(names) if names else 1, "region_source": "geometry_agent.facts.names" if names else "",
                            "connected_components": len(facts.regions), "watertight": facts.watertight,
                            "planar_openings": h["triage"]["planar_openings"], "bodies": facts.bodies,
                            "non_manifold_edges": facts.features.non_manifold_edge_count,
                            "thin_gap_m": (thin_gap_file(facts) * s_m) if thin_gap_file(facts) else None,
                            "self_intersecting": None},
        "unit": {"assumed": unit, "basis": plan.unit.basis, "declared": facts.units.declared, "declared_source": facts.units.declared_source,
                 "candidates": facts.units.candidates, "plausible_for_purpose": facts.units.plausible_for_purpose.get(plan.purpose, [])},
        "bbox": {"extent_m": [e * s_m for e in ext], "extent_mm": [round(e * s_mm, 3) for e in ext],
                 "min_m": [c * s_m for c in facts.bbox.min], "max_m": [c * s_m for c in facts.bbox.max],
                 "diagonal_m": facts.bbox.diagonal * s_m, "diagonal_mm": round(facts.bbox.diagonal * s_mm, 3)},
        "openings": openings,
        "patches": h["patches"],
        "port_declaration": h["port_declaration"],
        "declaration_problems": h["declaration_problems"],
        "domain": {k: h[k] for k in ("requested_extents", "reference_length_m", "flow_axis", "requirements_strict") if k in h},
        "seed_point_mm": h["seed_point_mm"],
        "seed_check": h["advisory"]["seed_check"],
        "forecast": h["forecast"],
        "warnings": warnings,
        "questions": h["questions"],
        #: The look (dev plan P9). Its own key beside the measured tables, never inside one: `openings`, `bbox`,
        #: `forecast` and `strategy` are measured, and this is a description of eight pictures. None when the run
        #: did not look or the look failed, which reads as "there was nothing to see", not "nothing to say".
        "visual_impression": h["visual_impression"],
        "header": h["strategy_header"],
        #: The builder's own instructions and the block a request carries (docs/builder_directives.md). `header`
        #: above is the earlier 500-character shape and is kept for the harness's arm B1 and its fidelity rows;
        #: `builder_plan_block` is what a request should carry, and only ever one of the two.
        "builder_directives": h["builder_directives"],
        "builder_plan_block": h["builder_plan_block"],
        #: Everything the plan measured that no key at this sha can act on, with the dev plan step that would
        #: give it a reader. It is a report row, never a builder instruction.
        "unreachable": h["unreachable"],
        "strategy": h["strategy"],
        "triage": h["triage"],
        "advisory": {k: v for k, v in h["advisory"].items() if k != "seed_check"},
        "engine_admission": h["engine_admission"],
        "blockers": h["blockers"],
        "facts_sha256": plan.facts_sha256,
        "plan_schema_version": plan.schema_version,
    }


def report_json(plan: GeometryPlan, facts: GeometryFacts, unit: str | None = None, **kw) -> str:
    return json.dumps(report(plan, facts, unit, **kw), indent=1, default=str)


# ---------------------------------------------------------------------------------------------------------------
# the measurement-only report (dev plan v3 W5)
#
# `report()` above needs a plan. On the last live run 20 of 105 cases that reached a model ended with no plan and
# 54 more with no model answer at all, and every one of those showed nothing for a measurement that had already
# finished in about four seconds. Everything in this section takes facts and never a plan: the opening table, the
# unit evidence, the bounding box, the representation, the bodies, the thickness, the symmetry, the axes and the
# triage verdict, all of which `triage()` and `forecast()` already compute from facts alone.
#
# It is also the artefact the platform stores at upload, keyed by the file's sha256, so the key names here are the
# ones the stored document carries and the platform's own five `surface_analysis` names are carried verbatim under
# `projection`. Nothing here imports meshpipeline.
# ---------------------------------------------------------------------------------------------------------------

#: The stored measurement's schema name. One artefact: the agent writes every key below, the platform adds
#: `status`, `reason`, `source` and the half of `stamp` only it knows, and nothing else is spelled twice.
MEASUREMENT_SCHEMA = "geometry_agent.measurement.v1"

#: Formats OCC transfers through `xstep.cascade.unit`, which is `MM` in this distribution. For these the numbers
#: in `facts` are millimetres whatever the file's own header declares, so the header is evidence about the text
#: and never about the coordinates (`facts/load.py:434-437` applies no unit transform; the platform states the
#: same rule at `contracts/coordinate_state.py:16-19`). Conflating the two is a silent 1,000x error on a STEP
#: that declares metres, and no corpus file can catch it: `unit_declared` is `mm` on 322 of 322.
OCC_TRANSFER_FORMATS = ("step", "stp", "iges", "igs")
#: What OCC transfers those formats to.
OCC_TRANSFER_UNIT = "mm"
#: Formats that carry no unit at all. Their coordinates mean nothing until a person says what they are, and an
#: absent scale is a legitimate, common outcome rather than a failure.
UNITLESS_FORMATS = ("stl", "vtp", "obj", "ply")

#: What the facts-only forecast has been worth, measured over every corpus case that ever delivered a mesh:
#: `hexera.forecast(facts, None, ...)["cells_high"]` over the cells the real job delivered. It travels with the
#: number because a number this wrong with no error bar is worse than no number. Before a plan exists the
#: envelope under-counts, which is the opposite direction from `cell_estimate_refined`, and the two must never
#: be read as the same kind of figure. Source: docs/pipeline.md sections 0 and 3.4, script `v7.py`, n=263.
FACTS_ONLY_CALIBRATION: dict[str, Any] = {
    "arm": "facts_only",
    "of": "cells_high over the cells the job delivered",
    "median_ratio": 0.52, "p90_ratio": 1.29, "max_ratio": 6.46, "n": 263,
    "by_representation": {"carve": 0.69, "external": 0.42, "fluid_domain": 0.34},
    "read_as": "the upper figure is the one to read: before a plan exists this estimate has come in at 0.52x the "
               "cells actually delivered",
    "source": "docs/pipeline.md sections 0 and 3.4 (v7.py), 263 delivered corpus meshes",
}


def coordinates_block(facts: GeometryFacts, unit: str | None = None, *, scale_to_metres: float | None = None,
                      basis: str | None = None) -> dict[str, Any]:
    """What the numbers in `facts` physically are, kept apart from what the file's text declares.

    `unit` and `scale_to_metres` are the caller's, and for the platform they come from its own
    `GeometryInterpretationRef` rather than from any model output. They are honoured for a format that carries no
    unit of its own; for a format OCC transfers they are recorded as a claim and never applied, because the
    coordinates are already millimetres and a disagreement is the file's text disagreeing with the transfer, not
    a different size. `basis` mirrors `contracts/coordinate_state.py:35-59`."""
    fmt = (facts.source_format or "").lower().lstrip(".")
    declared = {"value": facts.units.declared, "source": facts.units.declared_source}
    candidates = [list(c) for c in facts.units.candidates]
    claimed = unit if unit in UNIT_TO_M else None
    if fmt in OCC_TRANSFER_FORMATS:
        out: dict[str, Any] = {
            "unit": OCC_TRANSFER_UNIT, "basis": "occ_transfer",
            "scale_to_metres": UNIT_TO_M[OCC_TRANSFER_UNIT], "declared_in_file": declared,
            "candidates": candidates, "claimed_unit": claimed, "conflicts": []}
        if claimed and claimed != OCC_TRANSFER_UNIT:
            out["conflicts"] = [f"the caller calls this file {claimed} and the OCC transfer delivers "
                                f"{OCC_TRANSFER_UNIT}: the coordinates are {OCC_TRANSFER_UNIT} and were not rescaled"]
        return out
    if claimed:
        return {"unit": claimed, "basis": basis or "user_confirmed",
                "scale_to_metres": float(scale_to_metres) if scale_to_metres else UNIT_TO_M[claimed],
                "declared_in_file": declared, "candidates": candidates, "claimed_unit": claimed, "conflicts": []}
    return {"unit": None, "basis": "source_file", "scale_to_metres": None, "declared_in_file": declared,
            "candidates": candidates, "claimed_unit": None, "conflicts": []}


def thin_gap_file(facts: GeometryFacts) -> float | None:
    """The smaller of `thickness_min` and `min_gap`, whichever were measured, in the file's own numbers.

    From facts revision 1 `min_gap` is a gap between two DIFFERENT surfaces facing each other and is None on most
    wall shells (it used to be the bore), so a thin-gap figure read off `min_gap` alone went silent exactly where
    the wall is the thin thing. `docs/synthesis.md` C17: the platform's `geometry_unsuitable` wants the thinnest
    thing in the file across either side, and that is this."""
    vals = [v for v in (facts.features.thickness_min, facts.features.min_gap) if v]
    return min(vals) if vals else None


def projection_block(facts: GeometryFacts, scale_to_metres: float | None) -> dict[str, Any]:
    """The keys `engines/base.py` reads off `surface_analysis`, in the platform's own names.

    `region_count` and `region_names` are read at `base.py:172-178`; `self_intersecting` at `:565`; `diag` and
    `thin_gap` at `:573-574`, where `geometry_unsuitable` computes `float(thin) / diag`, so the two need only
    agree with each other and both are given in metres when the scale is known and in file units when it is not.
    `self_intersecting` is the string `unknown` and never `None`, because `None` reads as "not self intersecting"
    to a dict `.get`, and this package does not measure it yet.

    `region_count` IS HOW MANY REGIONS THIS FILE NAMES, AND THE 1 IS A FLOOR RATHER THAN A MEASUREMENT. A file
    that names none of its parts delivers one wall patch however many solids are in it, because the mesher writes
    each patch under its region's NAME, so 1 is the right answer to the platform's question ("how many separately
    named wall patches can this file deliver?") and dropping to None there would let a two-patch declaration
    through on a file that can only ever produce one.

    `connected_components` IS HOW MANY REGIONS THE FILE HAS, and it is here because the two are different numbers
    and the platform was reading the first as if it were the second. MEASURED on the platform's own
    `tests/fixtures/geometry/cht_enclosing_2region.step`: `facts.regions` is 2 (one enclosing the other) and every
    name on it is a generated `Open CASCADE STEP translator` name, which `_region_names` drops - so this block said
    `region_count: 1, region_names: []` and the platform's `engines/base._wall_patch_cause` turned that into "Your
    geometry is one region with no component names". THE DECISION WAS RIGHT AND THE SENTENCE WAS FALSE: the part
    does have two regions, and what it has none of is names. A refusal that misdescribes the file sends the
    customer to fix the wrong thing. With both numbers here the platform can say which of the two it means.
    """
    names = _region_names(facts)
    s = float(scale_to_metres) if scale_to_metres else 1.0
    gap = thin_gap_file(facts)
    return {
        "region_names": names,
        "region_count": len(names) if names else 1,
        "region_source": "geometry_agent.facts.names" if names else "",
        # THE MEASURED COUNT, never a floor: 0 stays 0, because a file nothing could be partitioned out of is
        # not a file with one region in it, and a reader that needs a floor has `region_count` for that.
        "connected_components": len(facts.regions),
        "self_intersecting": "unknown",
        "diag": facts.bbox.diagonal * s,
        "thin_gap": (gap * s) if gap else None,
        "units": "m" if scale_to_metres else "file",
    }


def look_block(impression: Any, *, model: str = "", provider: str = "", seconds: float | None = None,
               views: list[str] | None = None, status: str | None = None, caveat: str = "",
               drawn: dict[str, Any] | None = None, reason: str = "",
               usage: dict[str, Any] | None = None) -> dict[str, Any]:
    """The look as its own block of the stored measurement, never mixed into a field that carries a number.

    `impression` is the record `vision.prompt.normalise_impression` makes, scrubbed of every digit, or None.

    THERE ARE THREE STATUSES, `status` IS ALWAYS PRESENT AND IT IS THE CALLER THAT SAYS WHICH
    (`contract.survey.LOOK_STATES`): `ok` carries words, `failed` is a look that was taken and brought no
    reading back, and `not_attempted` is a look nobody took. AN UNKNOWN VALUE IS REFUSED, because a status a
    reader has no branch for is read as "not ok", which is the collapse below wearing a typo.

    NONE OF THE THREE MAY BE MERGED, and two of them were. A `failed` look with an empty impression and a look
    that saw a clear passage are the same object apart from this field, and a reader that cannot tell them apart
    reads silence as "I looked and there is nothing there", which is the failure that puts a bad mesh on a real
    job. The same sentence is true of `failed` against `not_attempted`, and for a while this docstring said the
    opposite: that the look always runs, so every way of not getting words back is a look that failed and a
    third value was a branch nothing could take. `look_block(None)` and `look_block(None, status="failed")` were
    then byte for byte one dict. Meanwhile `application/geometry_vision.py` passes `not_attempted` on every
    deployment with no vision reader configured, and `application/geometry_measurement.py` calls this with no
    status at all under a comment saying the block it gets back says `not_attempted`, which it did not.

    THE DEFAULT WITH NO IMPRESSION IS STILL `failed` and that is a decision, not an oversight. A caller that
    hands over no impression and no status has not said which of the two it means, and of the two, `failed` is
    the reading that makes a builder careful. So the default is the careful one and a caller that knows better
    says so: `status=LOOK_NOT_ATTEMPTED`.

    `is_measurement` is a constant of the schema rather than a computed field, so no reader has to decide.

    `openings_seen[].id` is in the same id space as `facts.openings[].id`: `tools.py:952` hands the measured
    openings to the renderer as labels and `vision/prompt.py:213` keeps an id only when it matches the id
    pattern, writing `unlabelled` otherwise. An `unlabelled` entry is the look reporting something the
    measurement did not find, which is the most valuable thing it can say and the one place the targeted pass
    has no opening to start from.

    `drawn` IS THE MEASUREMENT'S OWN RECORD AND NOT THE MODEL'S WORDS, and it is the one key in this block that
    is not a description. `{"marks": [{"id": "A", "cut": 1, "kind": "void", "point": [...]}], "stops": ["o2"]}`
    is where the renderer put the violet letters and which openings `terminus.find_stops` drew a panel for. It
    rides here because a look field that carries a subject is worthless without the table that says where the
    subject is, and both halves have to travel together or the join cannot be made downstream. `is_measurement`
    stays False because it describes `impression`, which is what a reader of this block acts on; `drawn`
    carries its own `is_measurement` so a reader cannot be misled by the block's.

    WHO WRITES WHICH, now that every caller on both sides has been read. THE PACKAGE CAN NO LONGER PRODUCE A
    LOOK NOBODY TOOK UNDER THE WORD `failed`, and that list is closed rather than shortened:

      `vision/look.py` says `not_attempted` where there was NO READER: none configured (`NO_CLIENT`) and none
        that could be built. Everything else is `failed`, including a fault of ours, because the sibling of a
        bad argument can only reach the outer net and one class of fault takes one word. The line and its
        evidence are in that module's own docstring.
      `chain/job.py: look()` says `not_attempted` with "no file to render and no stored look", because nothing
        looked at that part and nothing could have.
      `application/geometry_measurement.py` passes `status=LOOK_NOT_ATTEMPTED` at the upload, and
        `application/geometry_vision.py` passes it for a reader that was never configured and for one that
        could not be built. All four paths of one deployment now spell that state the same way.

    NOTHING IN THIS PACKAGE CAN WRITE `refused` OR `error` AS A LOOK'S STATUS, and that is checked rather than
    asserted: this function raises on any value outside `LOOK_STATES`, and it is the only composer of a look
    block in the package (`vision.look._safe_block` and `reconcile.joint` both come through here). No version
    ever wrote either, including the shipped wheel, whose only look statuses are `ok` and `failed`; `refused`
    appears in it as a MEASUREMENT status in `facts/` and never on a look. So a reader that keeps a branch for
    either is keeping it for a value nothing on this side has ever produced.

    TWO MORE KEYS COME AND GO, from work/look-channel, and only when there is something to put in them.
    `reason` says why a look is `failed`, which is how a stored row tells a look that broke from a look that
    could not be started. `usage` is the provider's own token counts, so what a look costs is a
    measurement rather than an estimate; `planner_block` composes the look from `vision.trust.for_model`,
    which never builds either key, so neither reaches a model. So `look_block(None)` is byte for byte the
    dict it was before either key existed.

    NO `trust` KEY, and that is the one part of work/look-channel's block not taken. The tiers reach every
    model consumer already, through `for_model` at the point of use, read off the live ledger. A copy frozen
    into the stored row would go stale the day a tier is demoted (`contract/ratchet.py` exists to demote
    them), and it would put a table of constant sentences into every stored document, which is the thing
    the `drawn` comment below refuses for the same reason.
    """
    imp = dict(impression) if isinstance(impression, dict) and impression else None
    state = status or (LOOK_OK if imp else LOOK_FAILED)
    if state not in LOOK_STATES:
        raise ContractError("look_block", f"{state!r} is not one of the three states a look can be in "
                                          f"{LOOK_STATES}: a look that failed, a look nobody took and a look "
                                          f"that came back are three different things, and a fourth value is "
                                          f"read downstream as 'not ok', which is two of them collapsed",
                            field="status")
    out = {"status": state, "label": IMPRESSION_LABEL,
           "is_measurement": False, "impression": imp, "views": list(views or []),
           "model": model or "", "provider": provider or "", "seconds": seconds, "caveat": caveat}
    if drawn:
        # NO EXPLANATORY SENTENCE IN HERE, and that is deliberate rather than an omission. A constant string in
        # a stored document is read as prose by anything that walks the document for claims, on every part, and
        # this project's own metric does exactly that. The sentence would have said what the docstring above
        # says, to a reader that has the docstring. The keys and `is_measurement` carry the meaning.
        out["drawn"] = {"is_measurement": True,
                        "marks": list(drawn.get("marks") or []), "stops": list(drawn.get("stops") or [])}
    if reason:
        out["reason"] = str(reason)
    if usage:
        out["usage"] = dict(usage)
    return out


#: Which of the facts layer's fidelity tiers is "normal". `facts.estimate.TIERS` defines it; this names it.
DEFAULT_CELL_TIER = "standard"


def _default_cell(facts: GeometryFacts, s_m: float | None) -> dict[str, Any] | None:
    """`facts.cell_estimates[standard].surface_cell`, in the file's numbers and in metres when the scale is known."""
    for est in facts.cell_estimates or []:
        if est.tier == DEFAULT_CELL_TIER and est.surface_cell:
            return {"tier": DEFAULT_CELL_TIER, "surface_cell_file": float(est.surface_cell),
                    "surface_cell_m": float(est.surface_cell) * s_m if s_m else None,
                    "source": "facts.cell_estimates"}
    return None


def _opening_row(o: Any, s_m: float | None) -> dict[str, Any]:
    """One row of the opening table. Every length is in the file's own numbers under `_file` and in metres under
    `_m` only when the scale is known; `_m` is null on a file whose unit nobody has confirmed, which is the
    honest answer and the one that cannot be off by 1,000."""
    s_mm = (s_m * 1000.0) if s_m else None
    min_dim = tools.port_min_dimension(o)

    def m(v: float | None) -> float | None:
        return None if (v is None or s_m is None) else v * s_m

    def mm(v: float | None, nd: int = 4) -> float | None:
        return None if (v is None or s_mm is None) else round(v * s_mm, nd)

    return {
        "id": o.id, "kind": o.kind, "classification": o.classification, "shape": o.shape,
        "region_id": o.region_id, "planar": o.kind in ("cap", "ring") or o.classification == "planar_face",
        "area_file": o.area, "area_m2": (o.area * s_m * s_m) if s_m else None,
        "area_mm2": round(o.area * s_mm * s_mm, 3) if s_mm else None,
        "bore_area_mm2": round(o.bore_area * s_mm * s_mm, 3) if (o.bore_area and s_mm) else None,
        "hydraulic_diameter_file": o.hydraulic_diameter,
        "hydraulic_diameter_m": m(o.hydraulic_diameter), "hydraulic_diameter_mm": mm(o.hydraulic_diameter),
        "bore_diameter_file": o.bore_diameter, "bore_diameter_m": m(o.bore_diameter),
        "bore_diameter_mm": mm(o.bore_diameter),
        "min_dimension_file": min_dim, "min_dimension_m": m(min_dim), "min_dimension_mm": mm(min_dim),
        "centroid_file": list(o.centroid),
        "centroid_m": [c * s_m for c in o.centroid] if s_m else None,
        "centroid_mm": [round(c * s_mm, 3) for c in o.centroid] if s_mm else None,
        "normal": list(o.normal), "tilt_deg": round(tools.port_tilt_deg(o), 3),
        "on_bbox_face": o.on_bbox_face, "bbox_side": o.bbox_side,
        #: how many holes go through a ring and each one's area, largest first (facts revision 1). None on a cap,
        #: a rim, and a ring whose count the adjacency cannot see; `bore_*` above is the LARGEST bore only
        "bore_count": getattr(o, "bore_count", None),
        "bore_areas_m2": ([a * s_m * s_m for a in o.bore_areas] if (getattr(o, "bore_areas", None) and s_m)
                          else None),
        #: Which pass produced this row. Pass 1 measures every opening before anything looks at the part; a
        #: targeted number carries its own derivation id (docs/pipeline.md 2.6).
        "provenance": {"pass": "global", "tool": "facts.measure.measure"},
    }


#: A stated flow direction as a vector, for the coverage places. Only the six axes intake offers.
FLOW_AXIS_VECTOR: dict[str, tuple[float, float, float]] = {
    "+x": (1.0, 0.0, 0.0), "-x": (-1.0, 0.0, 0.0), "+y": (0.0, 1.0, 0.0), "-y": (0.0, -1.0, 0.0),
    "+z": (0.0, 0.0, 1.0), "-z": (0.0, 0.0, -1.0)}

#: Representations whose flow runs inside the file's surfaces, so a centreline marched in from a mouth is a path
#: through the flow. On an external body it is a path through the solid, and on an unknown one nobody has said
#: which side is the flow.
COVERAGE_PASSAGE_REPRESENTATIONS = ("wall_shell", "fluid_domain", "annular_fluid")


#: Why nothing on the flow path is placed while the customer has not said which side of the surface is the fluid
#: (`catalog.side_reading`). Every place a march, a stop or a profile finds on such a part is a place on one of two
#: bodies, and which one is the flow is the question.
SIDE_OPEN_REFUSED = ("which side of the surface is the fluid is not settled: the file reads the same with the flow "
                     "through its bores and with the file itself as the flow, and the customer has not said which")


def _side_open(document: dict[str, Any]) -> bool:
    """Whether the document says which side is the fluid is still open. Absent (the switch off) is never open."""
    side = document.get("fluid_side")
    return isinstance(side, dict) and bool(side.get("open"))


def coverage_block(facts: GeometryFacts, representation: str, s_m: float | None,
                   flow_direction: str | None = None, side_open: bool = False) -> dict[str, Any] | None:
    """`facts.coverage` for the stored document and the typed block, with its places rebuilt for THIS representation.

    The measurement marches centrelines without knowing what the file is (it is not the measurement's to decide),
    so the places are derived here, once the representation is resolved: flow-path places only where the flow is
    inside the file, an external body's flat ends (its base once the customer's flow direction is given), and the
    leak-check points proved against the representation. Every length is metres; `where_file` and `size_file`
    ride beside each place for the typed block's merge and admission rules, which work in the file's own numbers,
    and are stripped before anything leaves the document. None when the facts carry no coverage (a document
    measured before revision 2, or a stage the budget skipped)."""
    cov = getattr(facts, "coverage", None)
    if cov is None:
        return None
    from geometry_agent.facts import coverage as coverage_mod
    if side_open:
        # NOTHING THAT DEPENDS ON WHICH SIDE IS THE FLOW: no centreline is a path through the flow and no point is
        # proved outside it, because either body may be the flow
        representation = "unknown"
    lines = cov.centrelines if representation in COVERAGE_PASSAGE_REPRESENTATIONS else []
    flow_vec = FLOW_AXIS_VECTOR.get(str(flow_direction or "").strip().lower())
    places = coverage_mod.flow_places(lines, cov.partition if representation == "external" else None, facts,
                                      flow_vec, representation)
    sag = getattr(getattr(facts, "chord", None), "sag_max", None)
    outside = coverage_mod.outside_point(facts.bbox.min, facts.bbox.max, representation, sag)
    if side_open:
        outside = outside.model_copy(update={"why": SIDE_OPEN_REFUSED})
    full = cov.model_copy(update={"places": places, "outside": outside})
    block = coverage_mod.planner_coverage(full, s_m)
    for row, place in zip(block["places"], places):
        row["where_file"] = list(place.where)
        row["size_file"] = float(place.scale) if place.scale else None
    if side_open:
        block["places_refused"] = f"{SIDE_OPEN_REFUSED}, so no path through the flow can be placed"
    elif representation not in COVERAGE_PASSAGE_REPRESENTATIONS:
        block["places_refused"] = (
            "the flow is around this body, so no path is marched through it" if representation == "external" else
            f"the representation is {representation}: which side of the surface is the flow is not settled, so no "
            "path through the flow can be placed")
    return block


def passage_ends_block(facts: GeometryFacts, s_m: float | None) -> list[dict[str, Any]] | None:
    """`facts.passage_ends` for the stored document: where a passage stops at a wall with no mouth, measured.

    None on a document measured before the passage-ends stage was hardwired on (its switch and its reader are
    both deleted, so every document measured since carries it),
    and `[]` when it ran and found none, which are two different things to a reader. The points are in the file's
    own numbers and in metres beside them; which of them the builder is handed depends on which side of the surface
    is the flow, and that is decided in `planner_places`, not here."""
    ends = getattr(facts, "passage_ends", None)
    if ends is None:
        return None
    out: list[dict[str, Any]] = []
    for e in ends:
        out.append({"id": e.opening_id, "point_file": list(e.point),
                    "point_m": [c * s_m for c in e.point] if s_m else None,
                    "normal": list(e.normal), "depth_file": e.depth, "diameter_file": e.diameter,
                    "depth_m": e.depth * s_m if s_m else None, "diameter_m": e.diameter * s_m if s_m else None})
    return out


def report_measured(facts: GeometryFacts, unit: str | None = None, brief: str | None = None, *,
                    purpose: str = "internal_cfd", engine: str | None = None,
                    declared: list[dict[str, Any]] | None = None, cell_cap: int | None = None,
                    look: dict[str, Any] | None = None, scale_to_metres: float | None = None,
                    unit_basis: str | None = None, include_facts: bool = True,
                    stamp: dict[str, Any] | None = None, flow_direction: str | None = None,
                    inlet_ids: list[str] | None = None, fluid_side: str | None = None) -> dict[str, Any]:
    """Everything the measurement knows, with no plan argument and no model anywhere in it (dev plan v3 W5).

    `fluid_side` is a person's answer to which side of the surface is the fluid (`catalog.FLUID_SIDES`). With
    The document always carries `fluid_side`, the reading and who settled
    it; while nobody has, the representation is today's and every place that depends on which side is the flow is
    refused (`planner_places`). Off and unanswered, the document is what it always was.

    `inlet_ids` are the mouths a PERSON called the inlet (confirmed, or stated in their own port list and bound
    to a mouth). The builder sizes from the largest declared inlet (drivers.py:422-438), so the forecast and the
    block's `inlet_bore_m` and `inlet_opening_id` are read off that mouth; with none they are the builder's own
    fallback, the widest planar opening. Without this the block named the widest mouth as the inlet on parts
    whose customer had just called it the outlet (the cyclone's overflow, 108 mm, against its 75 mm tangential
    inlet), and the budget trade was priced on it.

    `flow_direction` is the customer's stated direction for an external body (`+x` and the rest of FLOW_AXES),
    from intake, or None. It decides one thing only: whether a flat end of an external body is named its base.

    This is what the product has to show when the reasoning never ran, and it is the artefact the platform stores
    at upload keyed by the file's sha256. `plan` is present and null rather than absent, so a reader learns that
    no plan exists instead of inferring it from a missing key.

    `unit` is the caller's unit call and `scale_to_metres` the platform's own: on a format OCC transfers, both
    are recorded and neither is applied (see `coordinates_block`). `look` is `look_block(...)` or None, and rides
    as its own labelled block, never inside a field carrying a number. `declared` is the customer's port rows
    when intake has them and None at upload, when nobody has said anything about the file yet.

    What needs no plan, and where each comes from: `triage` takes facts, the declared rows, a purpose and an
    engine (`hexera.triage`); `forecast` takes `strategy=None` (`hexera.forecast`); the representation is the
    catalog's own read of the openings; the opening table, unit evidence, bounding box, bodies, thickness,
    symmetry and axes are fields of `GeometryFacts`."""
    coords = coordinates_block(facts, unit, scale_to_metres=scale_to_metres, basis=unit_basis)
    s_m = coords["scale_to_metres"]
    s_mm = (s_m * 1000.0) if s_m else None
    # The unit the triage and the forecast reason in, which is the file's own when nobody has confirmed one.
    # Neither changes a number in the tables above; both change which sizes are called plausible.
    reasoning_unit = coords["unit"] or unit or facts.units.declared or "mm"
    eng = engine or "snappy"
    side = (catalog.side_reading(facts, purpose, brief, declared=declared, answer=fluid_side)  # type: ignore[arg-type]
            if (fluid_side is not None or FLUID_SIDE_READING) else None)
    rep = side.representation if side is not None else \
        catalog.representation(facts, purpose, brief, declared=declared)  # type: ignore[arg-type]
    tri = triage(facts, declared, purpose, eng, unit=reasoning_unit, brief=brief, representation=rep)
    named = [o for o in (facts.opening(str(i)) for i in (inlet_ids or [])) if o is not None]
    inlet_id = max(named, key=lambda o: catalog.port_area(facts, o, rep)).id if named else None
    fc = forecast(facts, None, rep, eng, cell_cap=cell_cap, inlet_id=inlet_id)
    if inlet_id:
        fc["basis"] = list(fc["basis"]) + [f"inlet {inlet_id}: the largest mouth a person called the inlet, which "
                                           "is the one the builder sizes from"]
    fc["strategy"] = None
    fc["basis"] = list(fc["basis"]) + ["no plan exists: this is the builder emulator over the measurement alone, "
                                       "which is not the same figure as a planned estimate"]
    fc["calibration"] = dict(FACTS_ONLY_CALIBRATION)
    ext = facts.bbox.extent
    ft = facts.features
    ax = facts.axes

    def m(v: float | None) -> float | None:
        return None if (v is None or s_m is None) else v * s_m

    def mm(v: float | None, nd: int = 4) -> float | None:
        return None if (v is None or s_mm is None) else round(v * s_mm, nd)

    document = {
        "schema": MEASUREMENT_SCHEMA,
        #: No plan ran. Present and null, never absent: rule 2 of docs/pipeline.md section 4.
        "plan": None,
        "source_sha256": facts.sha256,
        "source": facts.source_path,
        "source_format": facts.source_format,
        "purpose": purpose,
        "engine": eng,
        "engine_source": "declared" if engine else "assumed",
        "representation": rep,
        "representation_corpus": corpus_representation(rep),
        "coordinates": coords,
        "unit": {"assumed": coords["unit"], "basis": coords["basis"], "declared": facts.units.declared,
                 "declared_source": facts.units.declared_source, "candidates": facts.units.candidates,
                 "plausible_for_purpose": facts.units.plausible_for_purpose.get(purpose, [])},
        "bbox": {"extent_file": list(ext),
                 "extent_m": [e * s_m for e in ext] if s_m else None,
                 "extent_mm": [round(e * s_mm, 3) for e in ext] if s_mm else None,
                 "min_file": list(facts.bbox.min), "max_file": list(facts.bbox.max),
                 "min_m": [c * s_m for c in facts.bbox.min] if s_m else None,
                 "max_m": [c * s_m for c in facts.bbox.max] if s_m else None,
                 "diagonal_file": facts.bbox.diagonal, "diagonal_m": m(facts.bbox.diagonal),
                 "diagonal_mm": mm(facts.bbox.diagonal, 3),
                 "longest_axis": facts.bbox.longest_axis, "shortest_axis": facts.bbox.shortest_axis,
                 "aspect": facts.bbox.aspect},
        "bodies": {"count": facts.bodies, "regions": len(facts.regions), "watertight": facts.watertight,
                   "faces": facts.faces, "vertices": facts.vertices,
                   "debris_components": facts.debris_components,
                   "interfaces": [{"region_a": i.region_a, "region_b": i.region_b, "kind": i.kind,
                                   "faces": i.faces, "area_m2": (i.area * s_m * s_m) if s_m else None}
                                  for i in facts.interfaces],
                   "regions_detail": [{"id": r.id, "faces": r.faces, "watertight": r.watertight,
                                       "volume_m3": (r.volume * s_m ** 3) if (r.volume and s_m) else None,
                                       "nested_in": r.nested_in, "contains": list(r.contains)}
                                      for r in facts.regions]},
        #: Wall thickness and the gaps, which is what an engine's `min_thickness_ratio` floor would read if any
        #: engine declared one. None does today (all five specs carry 0.0), so this is a report fact and not a
        #: gate input, and `projection` carries the same two numbers under the platform's own names.
        "thickness": {"min_file": ft.thickness_min, "min_m": m(ft.thickness_min), "min_mm": mm(ft.thickness_min),
                      "p05_m": m(ft.thickness_p05), "median_m": m(ft.thickness_median),
                      "min_gap_file": ft.min_gap,
                      "min_gap_m": m(ft.min_gap), "min_gap_between_regions_m": m(ft.min_gap_between_regions),
                      "closest_regions": list(ft.closest_regions) if ft.closest_regions else None,
                      #: `_file` beside `_m` on each cluster because the typed block's admission rule is a
                      #: RATIO (thickness over the default cell) and a ratio needs no unit: a file nobody has
                      #: confirmed a unit for still has its thin places ranked, with every metre value null.
                      "thin_clusters": [{"id": c.id, "faces": c.faces, "thickness_min_m": m(c.thickness_min),
                                         "thickness_min_file": c.thickness_min,
                                         "thickness_median_m": m(c.thickness_median),
                                         "centroid_file": list(c.centroid),
                                         "centroid_m": [x * s_m for x in c.centroid] if s_m else None,
                                         "extent_m": ([x * s_m for x in c.extent]
                                                      if (getattr(c, "extent", None) and s_m) else None)}
                                        for c in ft.thin_clusters],
                      #: EACH PLACE two different surfaces face each other across less than the near-touching
                      #: threshold (facts revision 1): where and how big, not only the minimum. None on a
                      #: document measured before the chords that prove what they crossed, [] when measured
                      #: and none found
                      "gap_clusters": (None if getattr(ft, "gap_clusters", None) is None else
                                       [{"id": g.id, "faces": g.faces, "gap_min_file": g.gap_min,
                                         "gap_min_m": m(g.gap_min), "gap_median_m": m(g.gap_median),
                                         "gap_max_m": m(g.gap_max), "centroid_file": list(g.centroid),
                                         "centroid_m": [x * s_m for x in g.centroid] if s_m else None,
                                         "extent_m": [x * s_m for x in g.extent] if s_m else None,
                                         "area_m2": (g.area * s_m * s_m) if s_m else None,
                                         "regions": list(g.regions)}
                                        for g in ft.gap_clusters]),
                      "near_touching_pairs": ft.near_touching_pairs,
                      "sharp_edge_count": ft.sharp_edge_count, "knife_edge_count": ft.knife_edge_count,
                      "knife_edge_length_m": m(getattr(ft, "knife_edge_length", None)),
                      "non_manifold_edge_count": ft.non_manifold_edge_count,
                      "winding_consistent": ft.winding_consistent,
                      #: the SHARE of faces that are slivers, which does not move when the file is refined;
                      #: `sliver_faces` was a count of the file (560 to 143,360 on one unchanged shape)
                      #: on a document measured before revision 1 the fraction is the same division over the count
                      #: the old measurement stored, so a stored document reads the same key whatever its revision
                      "sliver_fraction": (ft.sliver_fraction if getattr(ft, "sliver_fraction", None) is not None
                                          else (ft.sliver_faces / facts.faces if facts.faces else None)),
                      "thickness_coverage": (ft.thickness_coverage.model_dump(mode="json")
                                             if getattr(ft, "thickness_coverage", None) is not None else None),
                      "gap_coverage": (ft.gap_coverage.model_dump(mode="json")
                                       if getattr(ft, "gap_coverage", None) is not None else None)},
        "symmetry": {"measured": getattr(ax, "symmetry_measured", True),
                     "scores": None if ax.symmetry_scores is None else list(ax.symmetry_scores),
                     "planes": None if ax.symmetry_planes is None else list(ax.symmetry_planes),
                     "plane_normals": None if ax.symmetry_normals is None else [list(n) for n in ax.symmetry_normals],
                     "rotational_axis": ax.rotational_axis, "rotational_order": ax.rotational_order,
                     "rotational_score": ax.rotational_score},
        "axes": {"principal": [list(v) for v in ax.principal], "variance": list(ax.variance),
                 "slenderness": ax.slenderness, "blunt_end_sign": ax.blunt_end_sign,
                 "blunt_end_confidence": ax.blunt_end_confidence},
        "openings": [_opening_row(o, s_m) for o in facts.openings],
        #: What the opening detector's tubularity gate did, so an empty opening table says which empty it is: a
        #: part whose every outer edge is filleted has every mouth refused, not absent (facts revision 1).
        "opening_gate": (facts.opening_gate.model_dump(mode="json")
                         if getattr(facts, "opening_gate", None) is not None else None),
        #: `end_point` is where the march from the mouth stopped, and for a march that stopped at a junction it is
        #: the one measured position of that junction. It was in `facts` and not here, so the typed block could
        #: say a passage meets another one on 143 corpus parts and could not say where on any of them.
        "stubs": [{"opening_id": s.opening_id, "length_m": m(s.length),
                   "length_over_diameter": s.length_over_diameter, "terminated_by": s.terminated_by,
                   "stations": s.stations,
                   "end_point_file": list(s.end_point) if s.end_point is not None else None,
                   "end_point_m": [x * s_m for x in s.end_point] if (s.end_point is not None and s_m) else None}
                  for s in facts.stubs],
        #: The facts layer's own default wall cell, which the typed block reads ONLY to decide whether a place
        #: needs more attention than normal (the published two-cells-across rule, three in a gap). It is not a
        #: builder setting and it is never written into the block: the builder owns its own cell.
        "default_cell": _default_cell(facts, s_m),
        "names": _region_names(facts),
        "projection": projection_block(facts, s_m),
        #: The look. Its own key beside the measured tables, never inside one. None when nothing looked.
        "look": look,
        #: The second, targeted pass. Not built yet (docs/pipeline.md 6.3 A9), and `skipped` says so rather than
        #: an empty list pretending the pass ran and found nothing.
        "targeted": {"status": "skipped", "places": [],
                     "reason": "the look-driven targeted pass is not built yet"},
        "triage": tri,
        "forecast": fc,
        "warnings": list(facts.warnings),
        "stamp": {"facts_schema_version": facts.schema_version,
                  "measurement_revision": int(getattr(facts, "measurement_revision", 0) or 0),
                  "platform_sha": PLATFORM_SHA,
                  "measure_seconds": facts.timings.get("total"), "occ_unit": OCC_TRANSFER_UNIT,
                  **(stamp or {})},
        #: The facts verbatim, so the row is readable without re-running the measurement and a later reader can
        #: recompute every table above. `GeometryFacts` is already a versioned model; a second spelling of its
        #: 23 fields would be a second thing to keep in step.
        "facts": facts.model_dump(mode="json") if include_facts else None,
    }
    if side is not None:
        #: WHICH SIDE OF THE SURFACE IS THE FLUID, and who settled it: the purpose, the geometry, the brief or a
        #: person, or nobody yet. Absent with the switch off, so an off document is byte for byte what it was.
        document["fluid_side"] = side.as_dict()
    #: WHERE A PASSAGE STOPS WITH NO MOUTH, from the measurement (`facts.passage_ends`, the stops detector run on
    #: the mesh at measure time). Absent when the stage did not run, so a reader can tell "not measured" from none.
    ends = passage_ends_block(facts, s_m)
    if ends is not None:
        document["passage_ends"] = ends
    #: THE COVERAGE FACTS, with the places rebuilt now that the representation is known and with the leak-check
    #: points proved against it. Absent (never null) on a document whose facts predate them.
    cov = coverage_block(facts, rep, s_m, flow_direction, side_open=bool(side is not None and side.open))
    if cov is not None:
        document["coverage"] = cov
    #: The typed block the platform's mesh planner reads, assembled HERE and stored with the measurement, so the
    #: platform reads a value rather than recomputing one out of the tables above. `planner_block` is a pure
    #: function of the document, so it is computed after the document rather than alongside it, and a row written
    #: before this key existed can still be given one by calling the same function on the stored document.
    document["planner_block"] = planner_block(document)
    return document


# ---------------------------------------------------------------------------------------------------------------
# the typed block the platform's mesh planner reads (docs/pipeline.md 2.5, dev plan v3 W12 and B5)
#
# `engines/snappy/planner.py:186` cuts `request_txt[:2000]` and then serialises the measured-geometry dict AFTER
# the cut, so a dict key is the one channel into the planner that is never truncated. This is what goes in it.
#
# It is assembled HERE rather than in the platform for one reason: every number in it is this package's own, and
# a second spelling of the arithmetic on the other side of the boundary is a second thing to keep in step. The
# platform reads the block, checks its status and adds what only it knows; it never recomputes a value.
#
# THE BLOCK IS IN METRES. `facts` is in the file's own numbers and the planner's dict is metres because
# `planner.py:161-162` hands `analyze_surface` a `require_metre_surface(...)`. The conversion is
# `value_file * coordinates.scale_to_metres`, done once, in `_metres` below, and nowhere else. When the scale is
# unknown, which is an STL nobody has confirmed a unit for, every length is null and `status` is `degraded`:
# a length with no unit in a dict labelled metres is the 1,000x error this package exists to avoid.
# ---------------------------------------------------------------------------------------------------------------

#: The block's own name, written into it and checked by the platform's reader.
PLANNER_BLOCK_SCHEMA = "geometry_agent.planner_block.v1"

#: WHAT IS DELIBERATELY NOT IN THE BLOCK, and why, so a later reader does not add it back as an oversight.
#: Each entry is checked by `tests/test_planner_block.py`, so removing a reason means deleting a test.
PLANNER_BLOCK_WITHHELD: dict[str, str] = {
    #: dev_plan_v3 W12 holds the seed until W8 scores its card, which today reads `fires 81, untestable 240`; the
    #: agent's seed differs from the brief's on 46 of 61 cases, median 76.7 mm, and 4 fall outside the part's own
    #: bounding box. The planner prompt also has no seed field at either regime, so no reader is waiting for it.
    "seed_point_m": "the seed check has never run (dev_plan_v3 W8) and neither planner prompt has a seed field",
    #: `cell_estimate_refined` fills a refinement ball whether or not the part is inside it: median 1.86x the
    #: delivered cells, p90 22.9x, max 576x. `agent_forecast_cells` is `forecast()["cells_high"]` and nothing
    #: else, which is Rehaan's scope decision and is asserted by a test.
    "cell_estimate_refined": "it is the refinement-ball estimate, off by a median 1.86x and a max 576x",
    #: THE LOOK'S RECORDED FIELDS. Each is in the stored document under `look.impression`, where a person
    #: reads it, and none of them is in `look` below, where a model would. The tier and the reason are
    #: `vision/trust.py`; the entries here exist so a reader of the planner block learns the omission is a
    #: decision with a measurement behind it rather than a field somebody forgot to map.
    "look.defects": "3 to 5 false alarms on clean files and 0 catches on the two files with a real defect",
    "look.openings_seen[].likely_role": "it guesses on one declared mouth in seven and is right 48 percent "
                                        "of the time, which is a coin flip",
    "look.openings_seen[].looks_like": "opening class is a thing the measurement has exactly",
    "look.orientation": "the measurement has this exactly (axes, opening normals)",
    "look.symmetry": "the measurement has this exactly (symmetry scores, planes, rotational order)",
    "look.notes": "free prose, and the claims that land there held out worst (0 of 13 dead legs, 0 of 18 "
                  "closed headers, 0 to 1 of 13 diffuser cones)",
}

#: How far off the background grid a port mouth has to sit before it is worth the planner's attention. The grid is
#: axis aligned, so a tilted circular mouth is cut by stair-stepped cells: 61 of 64 tilted carves in the corpus are
#: poor against 4 of 78 untilted, and only 2 of the 64 admit a rigid rotation that would fix it. `builder_frame`
#: calls anything over 0.5 degrees not grid aligned; this is the angle at which it has cost a mesh.
PLACE_TILT_DEG = 5.0

#: At most this many places. The block rides in a prompt, and a list of every small opening on a 400-body part
#: buries the two that matter. Ranked before the cut, so the cut takes the least important.
PLACE_LIMIT = 10

#: At most this many places of ONE kind on the first pass, and it is the fix for the ordering being backwards.
#: With one sort key and one cap, eight thin-wall places filled the list on 108 corpus parts and the throat came
#: ninth on the venturi. A kind gets its first three places in rank order before any kind gets a fourth, and the
#: slots left over go to the rest in rank order, so a manifold still gets all six of its junctions when nothing
#: else is competing for the room.
PLACE_PER_KIND = 3

#: Two places of one kind closer together than this fraction of the bounding diagonal are one place: four thin
#: clusters around one shoulder are one thing a builder does something about, and two marches that stop at the
#: same header are one junction. The same fraction the attention metric's truth merges at
#: (`eval/attention/truth.CLUSTER_FRACTION`), so the block and the ruler agree on what "one place" is.
PLACE_MERGE_FRACTION = 0.05

#: THE PUBLISHED RESOLUTION RULE, and the only threshold that decides whether a SIZE place is more than normal:
#: at least two cells across the smallest feature, three across a gap between facing surfaces (OpenFOAM's
#: `gapLevel` note). The cell is the facts layer's own default wall cell (`default_cell` in the document). Places
#: that are there whatever their size (a throat, a junction, a closed end, a tilted mouth) do not pass through it.
MIN_CELLS_ACROSS = 2.0
MIN_CELLS_ACROSS_GAP = 3.0

#: An outward gap within this fraction of a measured opening dimension IS that opening's bore: the ray crossed the
#: passage. On 97 of 161 corpus wall shells `features.min_gap` is within five percent of an opening dimension
#: (0.04989 on a 0.04989 bore), and a narrow gap that is really the bore is a measured fact that lies.
GAP_IS_A_BORE_TOLERANCE = 0.05

#: WHAT `features.min_gap` IS, BY REPRESENTATION, and why it is not one thing. The facts layer fires a ray OUTWARD
#: from sampled faces and keeps the shortest hit. Which space that ray crosses depends on what the mesh is:
#:
#:   external       the body sits in the flow, so outward is INTO THE FLOW: the value is the closest two parts of
#:                  the body come to each other across the fluid. That is a narrow gap.
#:   fluid_domain,  the mesh is the flow, so outward is OUT OF THE FLOW: across a baffle, a tube wall, a vortex
#:   annular_fluid  finder or empty space the file does not model. The value is how close two parts of the flow
#:                  come across something that is not flow. On the corpus cyclone it is 4.98 mm, the finder's wall,
#:                  where the annular gap the brief describes is 70 mm. That is a thin separation, not a gap.
#:   wall_shell     outward from the INNER skin crosses the bore; outward from the OUTER skin crosses the outside
#:                  of the pipe, which a carve never meshes. One number cannot say which, so it is refused.
#:   unknown        which side is the flow is not settled, so nothing can be said about either side.
#:
#: The attention metric's truth reads the field as a narrow gap on every representation, so on fluid domains and
#: wall shells the block is charged for this reading. `eval/deliver/typed_block.py` prints that charge.
MIN_GAP_READS: dict[str, tuple[str, float]] = {
    "external": ("narrow_gap", MIN_CELLS_ACROSS_GAP),
    "fluid_domain": ("thin_separation", MIN_CELLS_ACROSS),
    "annular_fluid": ("thin_separation", MIN_CELLS_ACROSS),
}
#: WHAT THE OUTWARD DISTANCE DOES NOT YET TEST, said on the row. `features.min_gap` keeps the shortest hit of any
#: outward ray with no test that the surface it hit FACES the one it left, so in a concave corner (a blade root on
#: a hub, a branch saddle) it measures how close the ray started to the corner and moves with the sampling. That is
#: not refused, because away from a corner it is the number a builder needs; it is said, so a builder can tell the
#: two apart, which is the whole difference between a caveated fact and one that lies.
MIN_GAP_CAVEAT = ("not yet tested for facing surfaces: in a concave corner this distance is the corner and moves with "
                  "the sampling, not a gap")

#: What a gap cluster IS, by what the space between its two surfaces is (see MIN_GAP_READS). Words about the
#: geometry, never the mesh.
GAP_CLUSTER_WHAT: dict[str, str] = {
    "narrow_gap": "two surfaces of the body face each other across a narrow gap of the surrounding flow here",
    "thin_separation": "two parts of the flow region face each other across a thin piece of something that is not "
                       "flow here, such as a baffle, a wall or a tube",
}

MIN_GAP_REFUSED: dict[str, str] = {
    "wall_shell": ("on a wall shell the outward ray crosses the bore from the inner skin and the unmeshed outside "
                   "from the outer skin, and one distance cannot say which it measured"),
    "unknown": "which side of the surface is the flow is not settled, so the outward distance has no meaning yet",
}

#: THE SAME QUESTION FOR THE INWARD RAY, which is `thickness` and its thin clusters. On a body it crosses the
#: material and a thin cluster is a thin wall. Where the mesh is the flow it crosses the FLOW, and a thin cluster
#: is a narrow passage: on the corpus static mixer the clusters are the crevices where the helical element meets
#: the pipe, which the block used to call "the wall" and which are gaps a builder has to put cells across.
THIN_READS: dict[str, tuple[str, float]] = {
    "wall_shell": ("thin_region", MIN_CELLS_ACROSS),
    "external": ("thin_region", MIN_CELLS_ACROSS),
    "fluid_domain": ("narrow_passage", MIN_CELLS_ACROSS_GAP),
    "annular_fluid": ("narrow_passage", MIN_CELLS_ACROSS_GAP),
}
THIN_REFUSED = ("which side of the surface is the flow is not settled, so a thin place cannot be called a wall or "
                "a gap")

#: THE ORDER, and it is the part's. Tier 0 is the flow path, which is where the customer's own refinement
#: sentence puts the cells ("finer at junctions, bends and area changes than on straight runs", verbatim on 261
#: of 322 corpus briefs) and where the pressure drop is decided. Tier 1 is what limits the cell size. Within tier
#: 0 the restriction comes first because the pressure drop turns on it; within tier 1 the place that needs the
#: smallest cell comes first (its size over the cells the published rule wants across it), because that is the
#: one a cell budget fails first. A kind this table does not name ranks after every kind it does.
PLACE_TIER: dict[str, int] = {
    "measured_throat": 0, "throat": 0, "obstruction": 0, "junction": 0, "measured_taper": 0, "section_change": 0,
    "bend": 0, "closed_end": 0, "blunt_base": 0,
    "narrow_gap": 1, "narrow_passage": 1, "thin_separation": 1, "small_port": 1, "tilted_port": 1,
    "thin_region": 1,
    "flat_end": 2, "path_lost": 2,
}
#: The coverage facts' place kinds (`facts.coverage.PlaceKind`) that sit on the flow path. `blunt_base` and
#: `flat_end` are an external body's and are exempt from the passage gate; `path_lost` is where the measurement
#: could not follow the passage, which is said at the end of the list and never ahead of a measured place.
COVERAGE_FLOW_KINDS = ("throat", "obstruction", "section_change", "bend", "junction", "path_lost")
COVERAGE_BODY_KINDS = ("blunt_base", "flat_end")
PLACE_KIND_ORDER: tuple[str, ...] = tuple(PLACE_TIER)

#: What each kind of place IS, in words about the geometry. Never how the mesh will turn out and never a setting:
#: the Surveyor describes the part and the builder owns its controls. The two sentences this replaced said "the
#: layers collapse there" and "its cap sits one level coarser than the wall", which are predictions of a mesh.
PLACE_WHAT: dict[str, str] = {
    "junction": "a passage meets another passage here, at the end of the run in from the mouth named in "
                "reached_from",
    "closed_end": "a passage stops here at a wall, with no mouth",
    "narrow_gap": "the closest two parts of the body come to each other across the surrounding flow; the "
                  "measurement has this as one distance, with no position",
    "thin_separation": "the closest two parts of the flow region come to each other across something that is not "
                       "flow, such as a baffle, a wall or a tube; the measurement has this as one distance, with "
                       "no position",
    "narrow_passage": "the flow region is narrow here: its two walls are close together",
    "small_port": "a port mouth narrow against the rest of the part",
    #: NOT "thinner here than elsewhere": the cluster is every face under a fraction of the bounding diagonal
    #: (`facts.features.THIN_FRACTION_OF_DIAG`), and on a pipe that is most of the wall (3,180 of the venturi's
    #: 3,432 faces; 7 of 11 thin places on a 40-part sample cover over half the part). `extent_m` says how far
    #: it runs, so a builder can tell a local thin spot from a thin part.
    "thin_region": "a thin wall: the body here is thin for a part of its size, under one and a half per cent of "
                   "its bounding diagonal; extent_m is how far the thin stretch runs, which can be most of the "
                   "part, and where_m is the middle of that stretch",
}

#: Why a place has no coordinate, in words short enough to ride on the row. A null `where_m` is never a guess.
PLACE_WHERE_MISSING: dict[str, str] = {
    "no_scale": "the file's unit is not confirmed",
    "no_point": "measured as one number, with no position",
}


def _num(value: Any) -> float | None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    f = float(value)
    return f if math.isfinite(f) else None


def _cell_file(document: dict[str, Any]) -> float | None:
    """The facts layer's default wall cell, in the file's own numbers.

    Read from the document's `default_cell`, then from the verbatim facts, then worked out from the bounding
    diagonal by `facts.estimate.TIERS` itself for a document stored before `default_cell` existed. All three
    are the same number; none is this module's."""
    got = _num((document.get("default_cell") or {}).get("surface_cell_file"))
    if got:
        return got
    for est in ((document.get("facts") or {}).get("cell_estimates") or []):
        if isinstance(est, dict) and est.get("tier") == DEFAULT_CELL_TIER and _num(est.get("surface_cell")):
            return _num(est.get("surface_cell"))
    diag = _num((document.get("bbox") or {}).get("diagonal_file"))
    if not diag:
        return None
    from geometry_agent.facts.estimate import TIERS
    tier = TIERS[DEFAULT_CELL_TIER]
    return diag / tier["cells_across_diag"] / (2 ** tier["surface_levels"])


def _metres(point: Any, scale: float | None) -> list[float] | None:
    if scale is None or not isinstance(point, (list, tuple)) or len(point) != 3:
        return None
    vals = [_num(x) for x in point]
    return None if any(v is None for v in vals) else [float(v) * scale for v in vals]  # type: ignore[operator]


def _place(kind: str, pid: str, *, where_m: Any, measurement: dict[str, Any], length_file: float | None = None,
           cells: float = MIN_CELLS_ACROSS, at_file: Any = None, what: str | None = None,
           scale: float | None = None, **extra: Any) -> dict[str, Any]:
    """One row, with the private keys the ranking reads. They are stripped before anything leaves."""
    row: dict[str, Any] = {"id": pid, "kind": kind, "what": what or PLACE_WHAT.get(kind, kind), "where_m": where_m,
                           "measurement": measurement, **extra}
    if where_m is None:
        row["where_missing"] = PLACE_WHERE_MISSING["no_scale" if (scale is None and at_file is not None)
                                                   else "no_point"]
    row["_len"] = length_file
    row["_cells"] = cells
    row["_at"] = list(at_file) if isinstance(at_file, (list, tuple)) and len(at_file) == 3 else None
    return row


def _openings_by_id(document: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {str(r.get("id")): r for r in (document.get("openings") or []) if isinstance(r, dict) and r.get("id")}


def _marches_are_metal(document: dict[str, Any], rep: str) -> bool:
    """Whether every mouth march on this part ran through metal. The stub march (`facts.stubs`) follows the file's
    own volume in from a face: a cap's section, a thick ring's annulus. That volume is the flow only when the file
    is the fluid or a thin skin around it. On a wall shell that is a THICK SOLID, which is a wall shell the brief or
    a person named on a reading the geometry could not settle (`catalog.SOLID_BODY_RULES`), the file's volume is
    the metal and a march that stops at a "junction" has found two pieces of metal meeting. Only with `fluid_side`
    in the document, which every document now has: the side is read on every run."""
    side = document.get("fluid_side")
    return (isinstance(side, dict) and rep == "wall_shell"
            and str(side.get("rule") or "") in catalog.SOLID_BODY_RULES)


def _flow_path_places(document: dict[str, Any], rep: str, scale: float | None,
                      refused: list[dict[str, str]], side_open: bool = False) -> list[dict[str, Any]]:
    """Tier 0: the throat and the taper the profile sized, the junctions the mouth marches stopped at, and the
    passage ends the terminus found. Every one is a measurement; none carries a word the look wrote.

    With `fluid_side` in the document, which is every document now, a junction is not placed off a march that ran
    through metal (`_marches_are_metal`), and while which side is the flow is still open nothing on the flow path
    is placed at all."""
    from geometry_agent.reconcile.profile import NO_PASSAGE_REPRESENTATIONS
    from geometry_agent.vision.terminus import FLUID_REPRESENTATIONS as STOPS_BLIND_ON
    openings = _openings_by_id(document)
    metal = _marches_are_metal(document, rep)
    out: list[dict[str, Any]] = []
    through_wall: list[str] = []
    for row in document.get("measured_places") or []:
        # the profile's own rows, passed through whole: `reconcile.joint.Joint.measured_places` writes them and
        # this ranks them. `where_fraction_of_flow_axis` is the profile's unit and is not converted here
        if isinstance(row, dict) and str(row.get("kind") or "") in PLACE_TIER:
            size = _num((row.get("measurement") or {}).get("open_fraction_of_widest"))
            out.append({**row, "_len": size, "_cells": 1.0, "_at": None})
    for stub in document.get("stubs") or []:
        if not isinstance(stub, dict) or stub.get("terminated_by") != "junction":
            continue
        oid = str(stub.get("opening_id") or "")
        mouth = openings.get(oid) or {}
        if metal:
            through_wall.append(oid)
            continue
        out.append(_place("junction", f"junction_from_{oid}", where_m=stub.get("end_point_m"),
                          measurement={"passage_hydraulic_diameter_m": mouth.get("hydraulic_diameter_m")},
                          length_file=_num(mouth.get("hydraulic_diameter_file")), at_file=stub.get("end_point_file"),
                          scale=scale, reached_from=[oid]))
    if through_wall:
        refused.append({"kind": "junction", "why": (
            f"the marches in from {', '.join(sorted(through_wall))} followed the file's own volume, which here is the "
            "solid wall and not the flow, so where they stopped is where two pieces of the wall meet, not two "
            "passages")})
    placed_ends: set[str] = set()
    measured_ends = document.get("passage_ends")
    if isinstance(measured_ends, list) and measured_ends:
        if rep in STOPS_BLIND_ON:
            # `terminus.find_stops`'s own gate, applied to its measured output: where the file is the fluid a
            # closed end and a port face are the same flat disc, and the detector finds neither
            refused.append({"kind": "closed_end", "why": (
                f"the representation is {rep}: where the file is the fluid a closed end and a port face are the "
                "same flat disc, so no measured passage end is placed")})
        else:
            for end in measured_ends:
                if not isinstance(end, dict) or not str(end.get("id") or "").strip():
                    continue
                sid = str(end["id"]).strip()
                mouth = next((openings[p] for p in sid.split("+") if p in openings), {})
                point = end.get("point_file")
                out.append(_place("closed_end", sid, where_m=end.get("point_m"),
                                  measurement={"passage_hydraulic_diameter_m": mouth.get("hydraulic_diameter_m")},
                                  length_file=_num(mouth.get("hydraulic_diameter_file")), at_file=point, scale=scale,
                                  found_by="facts.passage_ends"))
                placed_ends.add(sid)
    drawn = ((document.get("look") or {}).get("drawn") or {}) if isinstance(document.get("look"), dict) else {}
    for stop in (drawn.get("stops") or []) if isinstance(drawn, dict) else []:
        sid = str((stop.get("id") if isinstance(stop, dict) else stop) or "").strip()
        if not sid or sid in placed_ends:
            # the measurement already placed this end; the look drew the same stop off the same detector
            continue
        point = stop.get("point") if isinstance(stop, dict) else None
        mouth = next((openings[p] for p in sid.split("+") if p in openings), {})
        where = _metres(point, scale) if point is not None else mouth.get("centroid_m")
        out.append(_place("closed_end", sid, where_m=where,
                          measurement={"passage_hydraulic_diameter_m": mouth.get("hydraulic_diameter_m")},
                          length_file=_num(mouth.get("hydraulic_diameter_file")),
                          at_file=point if point is not None else mouth.get("centroid_file"), scale=scale,
                          found_by="vision.terminus.find_stops"))
    for row in ((document.get("coverage") or {}).get("places") or []):
        # THE COVERAGE FACTS' PLACES (`facts.coverage.flow_places`): the throat, the step, the taper, the plate, the
        # bend, the divide a centreline marched through, each with its measured coordinate. On the shipping path
        # these are the only throat and section-change places there are: `measured_places` above is written by
        # the reconcile layer, which runs in the evaluation and not in the product
        if not isinstance(row, dict) or str(row.get("kind") or "") not in COVERAGE_FLOW_KINDS:
            continue
        clean = {k: v for k, v in row.items() if k not in ("where_file", "size_file")}
        if clean.get("where_m") is None:
            clean["where_missing"] = PLACE_WHERE_MISSING["no_scale"]
        out.append({**clean, "_len": _num(row.get("size_file")), "_cells": 1.0,
                    "_at": row.get("where_file") if isinstance(row.get("where_file"), list) else None})
    if side_open:
        # WHICH SIDE IS THE FLUID IS A QUESTION TO THE CUSTOMER, and until it is answered a junction, a throat or a
        # passage end is a place on one of two bodies with nobody to say which is the flow. Refused, not assumed:
        # on a solid block with one bore this is what stood between the builder and four junctions on a plate.
        # Said even when nothing was found, because the builder is owed the reason there is no flow path at all
        refused.append({"kind": "flow_path",
                        "why": f"{SIDE_OPEN_REFUSED}, so no throat, junction or passage end is placed"})
        out = []
    elif rep in NO_PASSAGE_REPRESENTATIONS and out:
        # the production passage gate (`reconcile.profile`), applied here too: a part with no passage in the file
        # cannot have a place on one, and a march or a stop that says otherwise is measuring something else
        # external has no passage in the file; unknown may have several (a block with two bores) and says only
        # that which side is the flow is not settled, so the reason names which of the two it is
        why = (f"the representation is {rep}, which has no passage in the file" if rep == "external" else
               f"the representation is {rep}: which side of the surface is the flow is not settled")
        refused.append({"kind": "flow_path", "why": f"{why}, so no throat, junction or passage end is placed"})
        out = []
    for row in ((document.get("coverage") or {}).get("places") or []):
        # an external body's flat ends, and its base once the customer's flow direction named which end is
        # downstream: the one flow place a body with no passage has
        if isinstance(row, dict) and str(row.get("kind") or "") in COVERAGE_BODY_KINDS and rep == "external":
            clean = {k: v for k, v in row.items() if k not in ("where_file", "size_file")}
            out.append({**clean, "_len": _num(row.get("size_file")), "_cells": 1.0,
                        "_at": row.get("where_file") if isinstance(row.get("where_file"), list) else None})
    return out


def _size_places(document: dict[str, Any], rep: str, scale: float | None, cell: float | None,
                 refused: list[dict[str, str]]) -> list[dict[str, Any]]:
    """Tier 1: what limits the cell size, each read by what the ray that measured it actually crossed."""
    out: list[dict[str, Any]] = []
    thickness = document.get("thickness") or {}
    openings = [r for r in (document.get("openings") or []) if isinstance(r, dict)]

    def admitted(length: float | None, cells: float) -> bool:
        # the published rule, as a ratio, so it needs no unit; with no cell to compare against it cannot be
        # applied and the place is kept, because a rule that cannot run is not evidence the place is ordinary
        return length is None or cell is None or length < cells * cell

    clusters = [c for c in (thickness.get("thin_clusters") or []) if isinstance(c, dict)]
    read = THIN_READS.get(rep)
    if clusters and read is None:
        refused.append({"kind": "thin", "why": THIN_REFUSED})
    elif read is not None:
        kind, cells = read
        for c in clusters:
            thin = _num(c.get("thickness_min_file"))
            if not admitted(thin, cells):
                continue
            out.append(_place(kind, str(c.get("id") or ""), where_m=c.get("centroid_m"),
                              # the cluster's extent and not its face count: the count is the tessellation's
                              # (384, 1,536, 6,144 on one pipe subdivided twice) and it reached the builder as
                              # a measurement of the part
                              measurement={"thickness_min_m": c.get("thickness_min_m"),
                                           "extent_m": c.get("extent_m")},
                              length_file=thin, cells=cells, at_file=c.get("centroid_file"), scale=scale))

    gap_clusters = thickness.get("gap_clusters")
    if isinstance(gap_clusters, list):
        # FACTS REVISION 1 AND LATER: every place two DIFFERENT surfaces face each other across less than the
        # near-touching threshold, with where it is and how big. The chords behind these passed a facing test and
        # a ball test and exclude their own surface, so the bore is no longer read as a gap and the caveat the
        # single outward distance carried does not apply. Read by representation exactly as that distance was:
        # the space outside the file's solid is the flow on an external body, is NOT the flow on a fluid domain,
        # and on a wall shell is both the bore and the unmeshed outside, which one number cannot tell apart
        read = MIN_GAP_READS.get(rep)
        if gap_clusters and read is None:
            refused.append({"kind": "gap_clusters", "why": MIN_GAP_REFUSED.get(rep, MIN_GAP_REFUSED["unknown"])})
        elif read is not None:
            kind, cells = read
            for g in gap_clusters:
                if not isinstance(g, dict):
                    continue
                size = _num(g.get("gap_min_file"))
                if not admitted(size, cells):
                    continue
                out.append(_place(kind, str(g.get("id") or ""), where_m=g.get("centroid_m"),
                                  what=GAP_CLUSTER_WHAT[kind],
                                  measurement={"gap_min_m": g.get("gap_min_m"), "gap_median_m": g.get("gap_median_m"),
                                               "extent_m": g.get("extent_m"), "area_m2": g.get("area_m2")},
                                  length_file=size, cells=cells, at_file=g.get("centroid_file"), scale=scale))
        gap = None
    else:
        gap = _num(thickness.get("min_gap_file"))
    if gap:
        read = MIN_GAP_READS.get(rep)
        dims = [d for r in openings for d in (_num(r.get("hydraulic_diameter_file")), _num(r.get("bore_diameter_file")),
                                              _num(r.get("min_dimension_file"))) if d]
        bore = next((d for d in dims if abs(gap - d) <= GAP_IS_A_BORE_TOLERANCE * d), None)
        if read is None:
            refused.append({"kind": "min_gap", "why": MIN_GAP_REFUSED.get(rep, MIN_GAP_REFUSED["unknown"])})
        elif bore is not None:
            refused.append({"kind": "min_gap", "why": "the shortest outward distance is within five percent of a "
                                                      "measured opening's own size, so it is that bore and not a "
                                                      "gap"})
        elif admitted(gap, read[1]):
            out.append(_place(read[0], "min_gap", where_m=None, measurement={"distance_m": thickness.get("min_gap_m")},
                              length_file=gap, cells=read[1], scale=scale, caveat=MIN_GAP_CAVEAT))

    ports = rep != "external"
    for row in openings:
        tilt = _num(row.get("tilt_deg")) or 0.0
        size = _num(row.get("min_dimension_file"))
        oid = str(row.get("id") or "")
        face = f"a {row.get('shape') or 'planar'} {'port mouth' if ports else 'flat face'}"
        if tilt >= PLACE_TILT_DEG:
            out.append(_place("tilted_port", oid, where_m=row.get("centroid_m"),
                              what=f"{face} whose face sits {tilt:.1f} degrees off the file's coordinate axes",
                              measurement={"tilt_deg": tilt, "min_dimension_m": row.get("min_dimension_m")},
                              length_file=size, at_file=row.get("centroid_file"), scale=scale))
        elif ports and size is not None and cell is not None and size < MIN_CELLS_ACROSS * cell:
            out.append(_place("small_port", oid, where_m=row.get("centroid_m"),
                              measurement={"min_dimension_m": row.get("min_dimension_m")},
                              length_file=size, at_file=row.get("centroid_file"), scale=scale))
    return out


def _rank_key(p: dict[str, Any]) -> tuple:
    kind = str(p.get("kind") or "")
    tier = PLACE_TIER.get(kind, 9)
    order = PLACE_KIND_ORDER.index(kind) if kind in PLACE_TIER else len(PLACE_KIND_ORDER)
    size = p.get("_len")
    demand = (float(size) / float(p.get("_cells") or 1.0)) if size is not None else float("inf")
    return (tier, order, demand, str(p.get("id") or "")) if tier == 0 else (tier, demand, order, str(p.get("id") or ""))


def _merge_near(places: list[dict[str, Any]], diagonal_file: float | None) -> list[dict[str, Any]]:
    """Places of one kind within `PLACE_MERGE_FRACTION` of the diagonal of a better-ranked one fold into it. An
    unlocated place never merges: merging it would invent a location for it."""
    if not diagonal_file:
        return places
    radius = PLACE_MERGE_FRACTION * float(diagonal_file)
    kept: list[dict[str, Any]] = []
    for p in places:
        at = p.get("_at")
        host = None
        if at is not None:
            for k in kept:
                if k.get("kind") == p.get("kind") and k.get("_at") is not None and \
                        math.dist(k["_at"], at) <= radius:
                    host = k
                    break
        if host is None:
            kept.append(p)
            continue
        if p.get("kind") == "junction":
            host["reached_from"] = [*host.get("reached_from", []), *p.get("reached_from", [])]
        else:
            host["merged"] = [*host.get("merged", []), str(p.get("id") or "")]
    return kept


def _limit(places: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """The cut: every kind's first `PLACE_PER_KIND`, then the rest in rank order, to `PLACE_LIMIT`."""
    per: dict[str, int] = {}
    first, rest = [], []
    for p in places:
        k = str(p.get("kind") or "")
        per[k] = per.get(k, 0) + 1
        (first if per[k] <= PLACE_PER_KIND else rest).append(p)
    chosen = first[:PLACE_LIMIT]
    chosen += rest[:max(0, PLACE_LIMIT - len(chosen))]
    chosen.sort(key=_rank_key)
    listed: dict[str, int] = {}
    for p in chosen:
        listed[str(p.get("kind") or "")] = listed.get(str(p.get("kind") or ""), 0) + 1
    for k, n in listed.items():
        more = per.get(k, 0) - n
        if more > 0:
            last = [p for p in chosen if p.get("kind") == k][-1]
            last["more_of_this_kind"] = more
    return chosen


def planner_places(document: dict[str, Any]) -> tuple[list[dict[str, Any]], list[dict[str, str]]]:
    """The measured places a mesh builder has to spend attention on, ranked, and what was refused and why.

    RANKED BY WHAT THE PART NEEDS: the flow path first, then what limits the cell size, smallest demand first. The
    list used to be one sort by a severity with no measurement behind its exchange rate between a degree of tilt
    and a millimetre of wall, cut at eight, and on 108 corpus parts eight wall-side places filled it before any
    flow-path place was reached.

    WHAT IT SENDS THAT IT DID NOT: the junction each mouth march stopped at (the march's own end point is its
    position), the passage ends the terminus found, narrow passages where the mesh is the flow, the one outward
    distance read by what it crossed, and the small mouths. Every one was measured before and thrown away here.

    WHAT IT REFUSES, and each refusal travels as a row of `places_refused` rather than as silence: the outward
    distance on a wall shell or an unknown representation, an outward distance that is a measured bore, a thin
    place whose side is not settled, and any flow-path place on a part with no passage."""
    rep = str(document.get("representation") or "unknown")
    scale = _num((document.get("coordinates") or {}).get("scale_to_metres")) or None
    cell = _cell_file(document)
    refused: list[dict[str, str]] = []
    # WHILE WHICH SIDE IS THE FLUID IS OPEN every read that depends on it is taken as `unknown`, which each of them
    # already refuses: the flow path, the thin places (a wall or a gap?) and the gaps (across the flow or across the
    # wall?). The representation the builder is told stays today's, marked a default in the survey
    open_side = _side_open(document)
    read_as = "unknown" if open_side else rep
    places = (_flow_path_places(document, read_as, scale, refused, side_open=open_side)
              + _size_places(document, read_as, scale, cell, refused))
    places.sort(key=_rank_key)
    places = _limit(_merge_near(places, _num((document.get("bbox") or {}).get("diagonal_file"))))
    rows = [{k: v for k, v in p.items() if not k.startswith("_")} for p in places]
    return rows, refused


def _planner_places(document: dict[str, Any]) -> list[dict[str, Any]]:
    """`planner_places` without the refusals, for a caller that wants only the list."""
    return planner_places(document)[0]


#: WHAT A LOOK FINDING WAS REFUSED FOR, by the rule that refused it. Two rules can drop one, and they are
#: different faults about different halves of the pipeline: a digit means the SCRUB failed upstream, before the
#: model was ever shown a picture, and a prediction means the model chose words the Surveyor may not repeat. One
#: sentence covering both would be wrong about whichever one it was not written for.
SEEN_REFUSED_WHY: dict[str, str] = {
    "digit": "a digit the scrub should have removed",
    #: ONE SENTENCE, WRITTEN WHERE THE DROP HAPPENS. `vision.trust.for_model` takes the words out, so it owns the
    #: sentence that says so; a copy here would be a second wording of one fact, free to drift from the rule.
    "predicts": vtrust.PREDICTS_REFUSED_WHY,
}

def _planner_look(document: dict[str, Any], scale_f: float | None) -> dict[str, Any] | None:
    """THE LOOK, TIERED AND PLACED, FOR THE ONE CHANNEL THAT IS NEVER TRUNCATED.

    `engines/snappy/planner.py:186` cuts `request_txt[:2000]` and serialises this dict afterwards, so a key
    here is the only way what the model saw reaches the mesh planner whole. Measured over 322 parts on four
    draws, this block used to be BYTE-IDENTICAL with the look and without it: `planner_block` read `forecast`,
    `openings`, `thickness`, `coordinates` and `stamp` and had no path to `document["look"]` at all. Five
    rounds of measuring what the look is worth were being thrown away at the last step.

    WHAT DECIDES WHAT GOES IN IS `vision.trust` AND NOTHING HERE. `for_model` is the ledger expressed in code:
    the relied-on fields, the candidates marked as candidates, and not one recorded field. `defects`,
    `likely_role`, `orientation`, `symmetry`, the per-opening class and `notes` cannot arrive by accident
    because they are not in the dict it builds. This function chooses no field and softens no tier; it
    supplies the one thing `for_model` cannot compute on its own, which is where each placed finding is.

    THE PLATFORM ALREADY READS THIS KEY. `GEOMETRY_AGENT_BLOCK_KEYS` lists `look`, `planner.py` appends
    `_AGENT_LOOK_NOTE` when it is present, and `agents/intake/geometry_brief.look_at_it` prefers the composed
    block over recomposing one. So the schema string does not move: this fills a key the other side was already
    waiting for, and the key is absent exactly when nothing looked.

    AND A PREDICTION IS ALREADY OUT OF WHAT THIS RETURNS. `contract.survey.refuse_outcome_claims` refused the
    whole survey block for one predicting phrase in the look's free text, and measured on a document whose
    `attachments` carried one, the builder lost the survey outright while the identical words rode on in
    `block["look"]`, which is on the platform's allowlist and which no boundary walks. `vision.trust.for_model`
    takes the words out instead, which is the one composition of what the look may say to a model: the survey's
    `seen` and `at_places` are rendered from this object and `block["look"]` IS this object, so one drop covers
    both and neither can carry what the other refuses. This function did the drop itself for one round and that
    left `for_model`'s three other callers open, including the geometry agent's own prompt. What went is named
    in `seen_refused`, which `planner_survey` passes on, because a list silently shortened reads downstream as a
    complete one.
    """
    look = document.get("look")
    if not isinstance(look, dict) or look.get("status") != LOOK_OK:
        return None
    imp = look.get("impression")
    if not isinstance(imp, dict) or not imp:
        return None
    drawn = look.get("drawn") if isinstance(look.get("drawn"), dict) else {}
    # FAIL OPEN, the one property work/look-channel's version of this function had and this one did not. A
    # description is never worth the planner block: a row the join or the ledger cannot read leaves the
    # block with no `look` key, which is exactly where a planner with the look switched off stands
    try:
        rows = vplace.places(imp, marks=drawn.get("marks"), stopped=drawn.get("stops"),
                             openings=document.get("openings"), scale_to_metres=scale_f)
        return vtrust.for_model(imp, model=str(look.get("model") or ""),
                                provider=str(look.get("provider") or ""), at_places=rows)
    except Exception:  # noqa: BLE001 - a plan is never worth failing over a description
        return None


# ---------------------------------------------------------------------------------------------------------------
# the Surveyor's block inside the typed block: `planner_block["survey"]`, checked by `contract.deliver`
#
# `contract/deliver.py` states the contract for what the Surveyor hands the builder and ships its validator,
# `check_survey_block`: every value a mark that says what kind of claim it is, no digit in anything the look said,
# no field the trust ledger tiers `recorded`, and a ceiling on size that is refused rather than cut. This is the
# block that satisfies it.
#
# ONE PATH FOR THE LOOK. `vision.trust.for_model` is the only thing in this package that decides what of the look
# may reach a model, and `_planner_look` is the only place the typed block calls it. The survey's `seen` and
# `at_places` are a rendering of THAT object into marks and read nothing else: not the impression, not the stored
# look block, not `contract.build`'s own look selector. A test pins it by giving the impression a recorded
# sentinel and a candidate the ledger would drop, and finding neither.
#
# `look` STILL RIDES BESIDE IT, because it is the key the platform's allowlist reads today
# (`GEOMETRY_AGENT_BLOCK_KEYS`). Both are rendered from the one `for_model` object, so neither can say a thing the
# other denies; what they are NOT is the same view. `survey` drops the candidates and the confidence when the
# ceiling bites (`_fit`, `left_out_for_size`) and `look` keeps them, so a reader of one has not read the other.
# This comment used to say they "cannot disagree", which was read as "either will do" and is why a second writer
# of this block went unnoticed for four rounds. The platform should read `survey` and drop `look` in one change.
#
# ONE WRITER PER KEY, and it is the thing this block did not have. `planner_survey` composes every key that comes
# off the DOCUMENT: the measured marks, the look's `seen` and `at_places`, the refusals and what the ceiling took.
# `survey_with_answers` is the only writer of the two keys that come off INTAKE, `confirmed` and `defaults_taken`,
# and `contract.deliver.attach` calls it instead of composing a second block over the top of this one.
# ---------------------------------------------------------------------------------------------------------------

#: What each open question is about, in the Surveyor's words, written here so that no sentence a look contributed
#: to rides into a model with it. `contract.asking` writes its reasons for a person at intake, and one of them says
#: whether the look offered a role, which is information out of `likely_role`, a recorded field.
#: How many subjects one unsettled row names before it starts counting instead. The block has a 4,000-character
#: ceiling (`deliver.SURVEY_BLOCK_MAX`) and one role question can name every mouth on the part, so an uncapped
#: row is the one thing that can push the whole survey over it and cost the builder every confirmed role.
#:
#: IT IS `deliver.SURVEY_ROW_IDS_MAX` AND NOT A SECOND NUMBER. This name was capping one of the block's two
#: lists that grow with the mouth count and `confirmed[...]["applies_to"]` was capping none, so the platform's
#: `application/geometry_survey.block_list_max()`, which reads THIS constant, was right about `subjects` and
#: wrong about `applies_to`. One number, owned where the ceiling it defends is owned.
SURVEY_SUBJECTS_MAX = _deliver.SURVEY_ROW_IDS_MAX

#: WHETHER THE DOCUMENT CARRIES A `fluid_side` BLOCK AT ALL, AND IT IS NOT A SETTING. The reading is on for
#: every run: `GEOMETRY_AGENT_FLUID_SIDE` is deleted and so is `catalog.fluid_side_on`, the function that went on
#: returning True with nothing to read.
#:
#: WHY IT EXISTS ANYWAY. `tests/test_reconcile_scoring.py` replays the PUBLISHED document-scoring table, which was
#: scored before the reading existed, on documents with no `fluid_side` key at all. A key that is absent is not a
#: key that says nothing, so the replay needs a way back to that document and there is no other. This is that way,
#: and it is named for what it is: nothing reads it out of the environment, no platform setting writes it, and the
#: only two places that move it are that replay and `tests/test_dead_package_switches.py`, which pins that no
#: export can.
FLUID_SIDE_READING = True

SURVEY_UNSETTLED_WHY: dict[str, str] = {
    "opening.role": ("no source here owns a role: the measurement has none and the look's word on a role is not "
                     "admissible, so a boundary condition on these mouths waits for a person"),
    "role_count": "the brief and the measurement do not agree on how many ports this part has",
    "unit": "the file states no unit, so no length here can honestly be given in metres",
    "cell_budget": "the measured envelope is larger than the budget the customer stated",
    "unlabelled_mouth": "the look reports a mouth the measurement did not label",
    "representation": ("which side of the surface is the fluid is not in the geometry, so nothing on the flow path "
                       "is placed until a person says"),
}

#: The measured marks the survey carries, by `contract.marks.OWNERS` name. `thickness.min_m` is not one of them:
#: it moves by 35 percent across eight seeds on a byte-identical file, and the places carry the thin walls with
#: their positions instead.
SURVEY_MEASURED: tuple[str, ...] = ("bbox_diagonal_m", "inlet_bore_m", "forecast.cells_high", "cell_budget")

#: An opening id inside a phrase the look wrote. The id is the LABEL the renderer drew from the measurement, not a
#: number the model produced, so it travels beside the words as `applies_to` and the words carry a placeholder.
_OPENING_ID = re.compile(r"\bo\d+\b")
OPENING_PLACEHOLDER = "[opening]"


def _seen_mark(field: str, value: Any, tier: str, source: str, *, ids: set[str]) -> dict[str, Any] | None:
    """One look claim as a mark, or None when it carries a digit the scrub should have removed.

    Refused, not stripped: a digit left in the look's words means the scrub failed upstream, which is the
    contract's rule 2, and a finding with a number in it is not a finding this block may pass on."""
    applies: list[str] = []

    def clean(text: str) -> str:
        def swap(m: re.Match) -> str:
            if m.group(0) in ids:
                applies.append(m.group(0))
                return OPENING_PLACEHOLDER
            return m.group(0)
        return _OPENING_ID.sub(swap, text)

    if isinstance(value, str):
        value = clean(value)
    elif isinstance(value, (list, tuple)):
        # the same phrase twice once its id has moved to `applies_to` ("a sharp rim at [opening]" at two mouths)
        # is one claim at two places, and it is said once
        value = list(dict.fromkeys(clean(str(v)) for v in value))
    from geometry_agent.contract.deliver import _digit_in
    if _digit_in(value):
        return None
    out: dict[str, Any] = {"kind": "seen", "value": value, "field": field, "tier": tier, "source": source}
    if source == f"look.{field}":
        # the key the mark sits under already names the field, so the mark says only where it came from
        out.pop("field")
        out["source"] = "look"
    if applies:
        out["applies_to"] = list(dict.fromkeys(applies))
    return out


def _survey_seen(look: dict[str, Any] | None, ids: set[str]) -> tuple[dict[str, Any], list[str]]:
    """`for_model`'s relied-on and candidate fields as marks, and the names of any refused for a digit."""
    from geometry_agent.vision import trust as T
    seen: dict[str, Any] = {}
    refused: list[str] = []
    if not isinstance(look, dict):
        return seen, refused
    for tier, group in ((T.RELIED_ON, look.get("relied_on") or {}), (T.CANDIDATE, look.get("candidates") or {})):
        for name, value in group.items():
            if name == "openings_seen":
                # THE SET is the finding, and a set of ids carries digits by construction. The ids are the
                # renderer's labels, so they ride as `applies_to` and the claim is the one word it makes
                labelled = [str(v) for v in value if str(v) in ids]
                if labelled:
                    # capped like every other row of this block: `_fit` would otherwise drop this finding WHOLE
                    # to get under the ceiling, and a shortened list that says so keeps the finding
                    seen["openings_seen"] = _deliver.cap_row_ids(
                        {"kind": "seen", "value": "visible in the renders", "tier": tier,
                         "source": "look", "applies_to": labelled}, about="this reading")
                if any(str(v) == "unlabelled" for v in value):
                    seen["unlabelled_mouth"] = {"kind": "seen", "value": "a mouth the measurement did not label",
                                                "tier": tier, "source": "look.openings_seen"}
                continue
            if name == "opening_mouths" and isinstance(value, dict):
                # one entry per WORD with its mouths on it, which is `contract.deliver`'s own form
                by_word: dict[str, list[str]] = {}
                for oid, word in value.items():
                    by_word.setdefault(str(word), []).append(str(oid))
                for word, oids in by_word.items():
                    key = f"opening.mouth_standoff.{word}"
                    mark = _seen_mark("opening.mouth_standoff", word, tier, "look.openings_seen[].mouth", ids=ids)
                    if mark is None:
                        refused.append(key)
                        continue
                    mark["applies_to"] = oids
                    seen[key] = _deliver.cap_row_ids(mark, about="this reading")
                continue
            if name == "looks_like":
                mark = _seen_mark("identity.name", value, tier, "look.looks_like", ids=ids)
                if mark is not None:
                    mark["confidence_max"] = T.IDENTITY_CONFIDENCE_MAX
                    seen["identity.name"] = mark
                else:
                    refused.append("identity.name")
                continue
            mark = _seen_mark(name, value, tier, f"look.{name}", ids=ids)
            if mark is None:
                refused.append(name)
            else:
                seen[name] = mark
    return seen, refused


def _survey_at_places(look: dict[str, Any] | None, quantum: float | None) -> tuple[list[dict[str, Any]], int]:
    """`for_model`'s placed findings as marks: the words are seen, the places are measured, and each says so.

    Grouped by what was said, the way `impression_line` groups them: a real reply gives the same answer at five
    letters, and five copies of one sentence is the block spending its ceiling on repetition. The places of one
    group are ONE measured mark, a list of points with the labels beside them, because a point is the renderer's
    and not the model's. Returns the groups and how many were refused for a digit in the words."""
    rows = [r for r in ((look or {}).get("at_places") or []) if isinstance(r, dict)]
    grouped: dict[tuple[str, str, bool], dict[str, Any]] = {}
    for r in rows:
        field = "stops_seen" if r.get("kind") == "passage_end" else "marks_seen"
        said = str(r.get("the_look_says") or "").strip()
        key = (field, said, bool(r.get("declined")))
        if key not in grouped:
            grouped[key] = {"kind": "seen", "value": said, "field": field, "tier": "relied_on",
                            "at": {"kind": "measured", "value": [], "labels": [],
                                   "source": str(r.get("where_from") or r.get("where_missing") or "unplaced")}}
            if r.get("declined"):
                # the look saying it could not read that place, which is an answer and not a gap
                grouped[key]["declined"] = True
        at = grouped[key]["at"]
        at["value"].append(_round_point(r.get("where_m"), quantum))
        at["labels"].append(str(r.get("at") or ""))
    # ONE DEFINITION OF A NUMBER, and it is the scrub's own. `contract.marks.carries_number` reads
    # `vision.prompt._NUMBER`, the pattern that put `[n]` in place of every numeric token before the model was
    # shown a picture, and it deliberately leaves an identifier alone. Counting any digit here was the bug
    # `carries_number` exists to have removed - it refused a survey the scrub had passed on 11 of 322 parts the
    # first time - restated eighty lines from `_seen_mark`, which already read the right one.
    from geometry_agent.contract import marks as mk
    kept = [g for g in grouped.values() if not mk.carries_number(g["value"])]
    return kept, len(grouped) - len(kept)


def _short_source(mark: dict[str, Any]) -> dict[str, Any]:
    """The mark with its source cut to the name before any gloss: `forecast.builder.bore (the widest planar mouth,
    the builder's own choice)` is `forecast.builder.bore` in a block with a ceiling, and the gloss is in the
    document a person reads."""
    source = str(mark.get("source") or "")
    return {**mark, "source": source.split(" (", 1)[0]} if " (" in source else mark


def _sig(mark: dict[str, Any], digits: int = 6) -> dict[str, Any]:
    """A measured mark with a float value given to six significant figures, which is past anything the facts layer
    resolves (its own thickness moves in the second figure across seeds)."""
    v = mark.get("value")
    if isinstance(v, float) and v and math.isfinite(v):
        mark = {**mark, "value": float(f"{v:.{digits}g}")}
    return mark


def _round_point(point: Any, quantum: float | None) -> Any:
    """A coordinate rounded to a ten-thousandth of the part's own diagonal, which is below anything the facts layer
    resolves and keeps a point from spending sixty characters of a size-capped block on seventeen digits each."""
    if not isinstance(point, (list, tuple)) or quantum is None or quantum <= 0:
        return point
    places = max(0, -int(math.floor(math.log10(quantum))))
    return [round(float(x), places) if isinstance(x, (int, float)) else x for x in point]


def _survey_unsettled(uncertainties: list[Any], answered: set[str]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    grouped: dict[str, dict[str, Any]] = {}
    for u in uncertainties:
        if u.id in answered or u.effect == "advisory" or u.about == "contradiction_resolution":
            # an advisory row is reported to a person and never asked, and a contradiction quotes the look's own
            # words on any field, recorded ones included, so it belongs to intake and not to a model downstream
            continue
        why = SURVEY_UNSETTLED_WHY.get(u.id) or SURVEY_UNSETTLED_WHY.get(u.about) or u.about
        row = grouped.setdefault(u.about + "|" + why, {"about": u.about, "subjects": [], "why": why})
        for s in (u.subjects or ([u.subject] if u.subject else [])):
            if s not in row["subjects"]:
                row["subjects"].append(s)
    # THE ROW NAMES AT MOST `SURVEY_SUBJECTS_MAX` AND SAYS HOW MANY MORE IT STANDS FOR. One role question names
    # every unplaced mouth, so one row carried every id and the block grew 8 characters a mouth: measured at
    # 2,117 characters with 2 mouths and over the 4,000 ceiling between 200 and 300. Past the ceiling
    # `check_survey_block` refuses, the platform's `builder_block` returns None, and the builder silently loses
    # the whole survey - so a long list costs more than a shortened one.
    #
    # It is capped HERE and not by the caller, because the caller can only shorten the list it passes in and
    # this function rewrites the `why` from `SURVEY_UNSETTLED_WHY`, which threw away the sentence saying how
    # many were left out. One implementation, and the count is part of the row rather than lost between two.
    #
    # THE CAP AND THE SENTENCE ARE `deliver.cap_row_ids` NOW, byte for byte what this loop wrote, because the
    # block's other row list (`confirmed[...]["applies_to"]`) needed the same two things and a second spelling of
    # "shorten and say how many" is how the two lists came to be capped differently in the first place.
    for row in grouped.values():
        _deliver.cap_row_ids(row, key="subjects", about="the question")
    out.extend(grouped.values())
    return out


def _survey_confirmed(intake: Any, source_sha256: str,
                      late: Any = None) -> tuple[dict[str, Any], dict[str, Any], set[str], str]:
    """`(confirmed, defaults_taken, settled question ids, why the intake was refused or "")`.

    ONE IMPLEMENTATION, AND IT IS THE CONTRACT'S. `contract.deliver.intake_half` is it; this is the composer's
    call into it, kept as a name because `planner_survey` and `survey_with_answers` both read it and because the
    composer is where the source sha to bind against comes from. It used to be a second implementation, keyed
    `about:subject` where the contract's is keyed `about=value` with the mouths in `applies_to`, so the key names
    of the block the builder read changed with whichever writer won. The contract's grouping is the one that was
    MEASURED: one mark per mouth took an eight-mouth manifold over the block's ceiling on repetition alone.

    A DEFAULT IS NOT A CONFIRMATION. An answer whose default stood is a mark of kind `assumed` and goes under
    `defaults_taken`, never under `confirmed`; on a field that admits no assumption (a port role) it is the
    question still open, and it stays in `unsettled`.

    `late` is the THIRD intake (`contract.intake.LateIntakeHandoff`), the budget trade and nothing else. Its
    answers are answers: reading only the second intake left a confirmed budget out of the block a builder was
    handed, which is the one number the trade exists to settle."""
    from geometry_agent.contract import deliver
    return deliver.intake_half(intake, late, str(source_sha256 or ""))


def _fit(block: dict[str, Any], ceiling: int) -> dict[str, Any]:
    """Whole items off, least trusted first, until the block fits, with a count of what left so nothing leaves
    silently and nothing is ever half a sentence.

    The order is the ledger's: the candidates go first (a name right on 215 of 322, wordings that repeat at
    Jaccard 0.31 to 0.46), then the look's own confidence, then the placed findings from the end of the list (the
    marks before the passage ends, which `vision.place.places` lists first), then the other relied-on words.

    SEEDED FROM WHAT ALREADY LEFT, because `survey_with_answers` fits the block a second time when the answers
    arrive and a count that started again at zero would tell a reader one item had gone when two had."""
    left: dict[str, int] = {str(k): int(v) for k, v in (block.pop("left_out_for_size", None) or {}).items()}

    def over() -> bool:
        probe = dict(block, left_out_for_size=left) if left else block
        return len(json.dumps(probe, default=str)) > ceiling

    def drop_seen(names: list[str]) -> None:
        while over() and names:
            block["seen"].pop(names.pop())
            left["seen"] = left.get("seen", 0) + 1

    seen = block.get("seen") or {}
    drop_seen([k for k, v in seen.items() if isinstance(v, dict) and v.get("tier") == "candidate"])
    drop_seen([k for k in seen if k == "confidence"])
    while over() and block.get("at_places"):
        block["at_places"].pop()
        left["at_places"] = left.get("at_places", 0) + 1
    drop_seen([k for k, v in seen.items() if isinstance(v, dict) and v.get("tier") == "relied_on"])
    if left:
        block["left_out_for_size"] = left
    return block


def _look_state(document: dict[str, Any]) -> str:
    """Which of `contract.survey.LOOK_STATES` this document's look is in.

    No look block at all is a look nobody took: on this package's own path `report_measured` writes `look: None`
    when no look was passed, and there is no queue here that could make it mean "one is on its way". The platform
    has one, which is why `application/geometry_survey.look_state` keeps its own `pending` off the row and out of
    this vocabulary.

    A STORED STATUS THIS PACKAGE DOES NOT KNOW IS `failed`, and that is the careful reading rather than a guess.
    A look block exists at all only because something wrote a look record, so a look was attempted; its status is
    not `ok`, so no reading came back that may be acted on. That is what `failed` means. `look_block` refuses an
    unknown status now, so only a record written before it did can take this branch.
    """
    look = document.get("look")
    if not isinstance(look, dict):
        return LOOK_NOT_ATTEMPTED
    status = str(look.get("status") or "")
    if status in (LOOK_OK, LOOK_NOT_ATTEMPTED):
        return status
    return LOOK_FAILED


def _seen_refused(*, digit: list[str], predicts: list[str]) -> dict[str, Any]:
    """The findings this block will not pass on, with the rule that stopped each one.

    ONE ROW PER REASON WITH THE FIELDS ON IT, which is this block's own shape everywhere else (`unsettled` groups
    by reason, `seen` groups by word). `fields` stays the flat union so a reader that only wants to know what was
    lost still reads one list, and `why` names only the rules that actually fired.

    `by_rule` IS ABSENT WHEN ONE RULE FIRED, because `why` then already says which rule every field went for and a
    key repeating it is a second copy of one fact in a block with a ceiling. With both rules in play there is no
    other way to tell which field went for which, so it rides.
    """
    rules = [(name, names) for name, names in (("digit", digit), ("predicts", predicts)) if names]
    return {"fields": [n for _, names in rules for n in names],
            "why": "; ".join(SEEN_REFUSED_WHY[name] for name, _ in rules),
            **({"by_rule": dict(rules)} if len(rules) > 1 else {})}


#: Why a look that came back is not in this block, when the caller did not say. `planner_survey` is handed the
#: COMPOSED look and the document separately, so it can see that the document's look is `ok` and that nothing of
#: it arrived, which is a real state: `_planner_look` returns None when the reply carried no impression or when
#: the join or the trust ledger could not read a row. Saying nothing there leaves a builder with `looked: false`
#: on a part that WAS looked at, which reads as "there was nothing to see".
LOOK_COMPOSED_NOTHING = ("the look came back and no composed look reached this block: either the reply carried "
                         "no reading, or the join to the measured places could not be made")


def planner_survey(document: dict[str, Any], look: dict[str, Any] | None = None, *,
                   intake: Any = None, look_refused: str = "") -> dict[str, Any]:
    """The Surveyor's block for `planner_block["survey"]`, checked by `contract.deliver.check_survey_block`.

    `look` is `_planner_look(document)`, the one composition of what the look may say to a model; the survey reads
    the look through it and through nothing else. `intake` is a `contract.intake.IntakeHandoff` for the same file,
    or None before intake has run, which is the upload.

    `look_refused` is why the caller is handing over no composed look for a document that HAS one, and it is a
    parameter rather than a key written on afterwards so that the reason is part of the composition: inside the
    block before `_fit` measures it and before the contract checks it, written by the one function that composes
    every other key off the document. And with no reason from the caller this composer states its own
    (`LOOK_COMPOSED_NOTHING`), because it can see that the document looked and that nothing of it arrived, which
    is a real state and one that otherwise reaches a builder as a bare `looked: false`.

    Raises `contract.marks.ContractError` when the block breaks the contract. `planner_block` catches it."""
    from geometry_agent.contract import deliver
    from geometry_agent.contract import marks as mk
    from geometry_agent.contract.build import survey_from

    forecast = document.get("forecast") or {}
    cap = forecast.get("cell_cap") if isinstance(forecast, dict) else None
    # THE LOOK IS TAKEN OUT BEFORE `survey_from` SEES THE DOCUMENT. `contract.build` has a look selector of its
    # own (`_look_marks`), and letting it run would be a second path for the look into this block. What the
    # survey needs from the contract is the measured marks and the questions, and neither needs the look
    #
    # AND AN ENGINE NOBODY DECLARED IS LEFT OUT. `contract.build` marks it `assumed`, and `contract.marks.OWNERS`
    # admits only `confirmed` or `stated` for an engine, so every document whose engine was the default (every
    # upload that does not name one) raised inside `survey_from` and had no survey at all. The survey carries no
    # engine mark, so leaving an undeclared one out costs this block nothing.
    declared_engine = document.get("engine") if document.get("engine_source") == "declared" else None
    handoff = survey_from({**document, "look": None, "engine": declared_engine}, budget=int(cap) if cap else None)
    by_field = {m.field: m for m in handoff.marks if m.kind != mk.SEEN}
    ids = {str(r.get("id")) for r in (document.get("openings") or []) if isinstance(r, dict) and r.get("id")}
    seen, refused = _survey_seen(look, ids) if isinstance(look, dict) else ({}, [])
    diagonal = _num((document.get("bbox") or {}).get("diagonal_m"))
    at_places, at_refused = (_survey_at_places(look, diagonal * 1e-4 if diagonal else None)
                             if isinstance(look, dict) else ([], 0))
    if at_refused:
        refused.append(f"at_places x{at_refused}")
    # WHAT `_planner_look` ALREADY TOOK OUT, carried through rather than restated. It drops a predicting phrase
    # from the one object both renderings are built from, so by the time this composes `seen` the words are gone
    # and only the record of them is left to pass on.
    predicted = list(((look or {}).get("seen_refused") or {}).get("fields") or []) if isinstance(look, dict) else []
    confirmed, defaults, settled, intake_refused = _survey_confirmed(intake, handoff.source_sha256)
    unit = by_field.get("unit")
    block: dict[str, Any] = {
        "schema": deliver.SURVEY_BLOCK_SCHEMA,
        "source_sha256": handoff.source_sha256,
        "facts_sha256": handoff.facts_sha256,
        "representation": mk.as_json(by_field["representation"], compact=True),
        "unit": (mk.as_json(unit, compact=True) if unit is not None else
                 {"kind": mk.ASSUMED, "value": None, "field": "unit",
                  "source": "nobody has stated a unit for this file; see unsettled"}),
        "kinds": dict(mk.KIND_SHORT),
        "measured": {name: _sig(_short_source(mk.as_json(by_field[name], compact=True)))
                     for name in SURVEY_MEASURED if name in by_field},
        "confirmed": confirmed,
        "unsettled": _survey_unsettled(list(handoff.uncertainties), settled),
        "seen": seen,
        "at_places": at_places,
        "looked": isinstance(look, dict),
        #: WHICH OF THE THREE, and not the boolean alone. `looked` says whether a look's findings are IN this
        #: block; it cannot say why they are not, so a look that failed and a look nobody took both reached the
        #: builder as the same False. The builder's own rule is that a failed look is never a clear passage, and
        #: it could not tell. The sentence for each state is the platform's (`LOOK_BECAUSE`), which reads this
        #: token: one wording of one fact, on the side that also knows about its queue.
        "look_state": _look_state(document),
    }
    if defaults:
        block["defaults_taken"] = defaults
    if refused or predicted:
        block["seen_refused"] = _seen_refused(digit=refused, predicts=predicted)
    if look_refused or (look is None and block["look_state"] == LOOK_OK):
        block["look_refused"] = deliver.safe_reason(look_refused or LOOK_COMPOSED_NOTHING)
    if intake_refused:
        block["intake_refused"] = intake_refused
    block = _fit(block, deliver.SURVEY_BLOCK_MAX)
    deliver.check_survey_block(block)
    return block


#: The keys of the survey block that only `planner_survey` can compose, because each of them needs the DOCUMENT
#: or the look and a `contract.given.Given` holds neither. These are the six a second writer over the top of this
#: block threw away on both live paths. `tests/test_survey_one_writer.py` exercises a case for each of the six and
#: asserts it reaches `deliver.builder_handoff`'s typed block with the value the composer gave it.
SURVEY_COMPOSED_KEYS: tuple[str, ...] = ("at_places", "defaults_taken", "seen_refused", "intake_refused",
                                         "look_refused", "left_out_for_size")

#: The keys that come off INTAKE rather than off the document, and the only ones `survey_with_answers` writes.
SURVEY_INTAKE_KEYS: tuple[str, ...] = ("confirmed", "defaults_taken", "intake_refused", "unsettled")


def survey_with_answers(survey: dict[str, Any], given: Any) -> dict[str, Any]:
    """The composed survey with the answers a `Given` holds, refitted and rechecked. One block, one writer a key.

    WHY THIS EXISTS AND WHAT IT REPLACES. The platform composes its planner block at step 2, before intake has
    run (`application/geometry_survey.compose`), and joins the answers at step 7 (`builder_block`). Step 7 used
    to build a SECOND survey out of the `Given` alone and write it over the first. The second cannot compose
    `at_places`, `seen_refused`, `look_refused` or what the ceiling took, because a `Given` has no document and
    no look, so six composed keys never left the document on either live path. This fills the two keys that come
    off intake, rebuilds `unsettled` against the questions those answers settled, and leaves every other key
    byte for byte as it was composed. A `Given` with no answers at all leaves the block untouched, because
    nothing to add is nothing to write.

    A DEFAULT IS NOT A CONFIRMATION here either: the split is `_survey_confirmed`'s, which is the one
    implementation of it, so a default reaches `defaults_taken` and can never land under `confirmed`.
    """
    from geometry_agent.contract import deliver
    from geometry_agent.contract.marks import ContractError
    if not isinstance(survey, dict):
        raise ContractError("survey_block", "there is no composed survey for these answers to go into")
    block = json.loads(json.dumps(survey, default=str))
    want = str(getattr(getattr(given, "survey", None), "source_sha256", "") or "")
    got = str(block.get("source_sha256") or "")
    if want and got and want != got:
        raise ContractError("survey_block", f"the composed survey is about {got[:12]} and these answers were "
                                            f"bound to {want[:12]}: one part, one survey", field="source_sha256")
    # WHAT IS STILL OPEN COMES FROM THE SURVEY, WHATEVER THE ANSWERS ARE, because the composed list was made
    # before any finder ran. `planner_survey` calls `survey_from` with no `uncertainties=`, so the list inside
    # the composed block is `contract.asking.uncertainties_from`'s - the FALLBACK finder, which has no finder
    # for `dispatch_refusal` or `flow_direction` and cannot see that a declared port row already settled a
    # mouth. The survey a `Given` carries is the one the customer was actually asked from (`ask.intake`, the
    # one finder), and `contract.intake.binds_to` refuses an intake whose questions are not that survey's
    # uncertainty ids, so it is the only object that can say what is open and what an answer closed.
    #
    # This runs even with no answers at all: a part nobody has answered anything about still has to reach the
    # builder with the finder's list rather than the fallback's, and without it the builder was told a role was
    # unsettled that the customer had placed in their own port list.
    # AN EMPTY LIST IS AN ANSWER, not an absence: a part whose every question the customer's own port rows
    # settled has NO open uncertainty, and reading that as "nothing to go on" is how the fallback list
    # survived. So the test is whether the `Given` carries a survey at all, never whether it carries rows.
    asked_from = getattr(given, "survey", None)
    asked_survey = list(getattr(asked_from, "uncertainties", []) or []) if asked_from is not None else []
    intake, late = getattr(given, "intake", None), getattr(given, "late", None)
    if intake is None and late is None:
        # NOTHING ELSE TO ADD IS NOTHING ELSE TO WRITE. A `Given` with no answers has no view of the intake
        # half, and rewriting that from it would delete what the composer recorded: on a composed block that
        # refused answers about another file, the refusal is the only record that a mismatched pair was seen.
        if asked_from is not None:
            block["unsettled"] = _survey_unsettled(asked_survey, set())
            block = _fit(block, deliver.SURVEY_BLOCK_MAX)
        deliver.check_survey_block(block)
        return block
    confirmed, defaults, settled, intake_refused = _survey_confirmed(intake, got or want, late=late)
    block["confirmed"] = confirmed
    for key in ("defaults_taken", "intake_refused"):
        block.pop(key, None)
    if defaults:
        block["defaults_taken"] = defaults
    if intake_refused:
        block["intake_refused"] = intake_refused
    if asked_from is not None:
        block["unsettled"] = _survey_unsettled(asked_survey, settled)
    block = _fit(block, deliver.SURVEY_BLOCK_MAX)
    deliver.check_survey_block(block)
    return block


#: The coverage keys the typed block carries. `places` is not one of them: every coverage place that survives the
#: ranking is already a row of `places`, and the same place twice is two things to a reader.
PLANNER_COVERAGE_KEYS = ("version", "outside")
#: What each named wall region keeps in the typed block. The box, the neighbour graph and the per-region reason a
#: radius is not given stay in the stored document for a person: on the venturi they were 2,800 characters of a
#: 8,400-character block for four regions, most of it one constant sentence repeated.
PLANNER_WALL_ROW_KEYS = ("id", "surface", "area_fraction", "radius_m", "half_angle_deg", "centroid_m", "is_opening")


def planner_coverage(document: dict[str, Any]) -> dict[str, Any] | None:
    """The coverage facts the builder's typed block carries beside `places`: the points provably outside the flow
    domain, for the leak check, and the named wall regions. The two refusals ride by name only: what was decided,
    not the paragraph that decided it, which is in the stored document for a person. None when not measured."""
    cov = document.get("coverage")
    if not isinstance(cov, dict):
        return None
    out = {k: cov[k] for k in PLANNER_COVERAGE_KEYS if k in cov}
    wall = cov.get("wall")
    if isinstance(wall, dict):
        if wall.get("status") != "measured":
            out["wall"] = {"status": wall.get("status"), "why": wall.get("why")}
        else:
            out["wall"] = {"status": "measured", "regions_total": wall.get("regions_total"),
                           "regions": [{k: r[k] for k in PLANNER_WALL_ROW_KEYS if k in r}
                                       for r in (wall.get("regions") or []) if isinstance(r, dict)]}
            if wall.get("where_missing"):
                out["wall"]["where_missing"] = wall["where_missing"]
    refused = cov.get("refused")
    if isinstance(refused, dict) and refused:
        out["refused"] = sorted(refused)
    if cov.get("places_refused"):
        out["places_refused"] = cov["places_refused"]
    return out


def planner_block(document: dict[str, Any] | None, *, intake: Any = None) -> dict[str, Any] | None:
    """The typed block for `metrics["geometry_agent"]`, in metres, from a stored measurement document.

    `intake` is the customer's answers (`contract.intake.IntakeHandoff`) for this same file, when intake has run.
    It changes one key, `survey.confirmed`, and nothing a measurement said: a person settles roles, units and a
    budget, never a bore.

    None when there is nothing a planner could read: no document, or one whose `status` is not `ok`. None is what
    makes the platform's fail-open true, because an absent key leaves `planner.py` composing exactly the dict it
    composes today, so a measurement that failed is never dressed up as a thin one.

    `status` is `ok` when every field below carries a number and `degraded` when one does not, and `missing` then
    names them. The most common cause by far is a file whose unit nobody has confirmed: an STL carries no unit, so
    `coordinates.scale_to_metres` is null, and a block of nulls labelled metres would be read as metres."""
    if not isinstance(document, dict) or document.get("status") not in (None, "ok"):
        return None
    forecast = document.get("forecast")
    if not isinstance(forecast, dict):
        return None
    places, refused = planner_places(document)
    scale = (document.get("coordinates") or {}).get("scale_to_metres")
    scale_f = float(scale) if isinstance(scale, (int, float)) and scale else None

    def _metres(value: Any) -> float | None:
        # THE ONE CONVERSION. `facts` and everything derived from it are in the file's own numbers; this dict is
        # metres. Nothing else in this block multiplies by a scale.
        if not isinstance(value, (int, float)) or isinstance(value, bool) or scale_f is None:
            return None
        return float(value) * scale_f

    _builder = forecast.get("builder")
    builder = _builder if isinstance(_builder, dict) else {}
    _smallest = builder.get("smallest_port")
    smallest = _smallest if isinstance(_smallest, dict) else {}
    _cal = forecast.get("calibration")
    calibration = _cal if isinstance(_cal, dict) else {}
    _stamp = document.get("stamp")
    stamp = _stamp if isinstance(_stamp, dict) else {}
    _facts = document.get("facts")

    #: The bore the BUILDER will size from, not a guess at which port the customer calls the inlet. With no
    #: declaration `tools.builder_inlet` takes the widest planar opening, which is what the platform's own
    #: `cad_tessellate.py:614` and `:631` take. The internal planner prompt sets `cells_across_diameter` relative
    #: to this bore, so it is the single most usable number in the block.
    cells_high = forecast.get("cells_high")
    cells_low = forecast.get("cells_low")

    block: dict[str, Any] = {
        "schema": PLANNER_BLOCK_SCHEMA,
        "status": "ok",
        "representation": document.get("representation"),
        #: `forecast()["cells_high"]` and nothing else. Never `mesh_plan.cell_estimate_refined`, which is the
        #: refinement-ball number and is off by a median 1.86x. Asserted by a test.
        "agent_forecast_cells": int(cells_high) if isinstance(cells_high, (int, float)) else None,
        "agent_forecast_low": int(cells_low) if isinstance(cells_low, (int, float)) else None,
        "agent_forecast_basis": list(forecast.get("basis") or []),
        #: The forecast's own measured error, travelling with the number. Before a plan exists the envelope has
        #: come in at 0.52x the cells actually delivered on 263 corpus meshes, and a number that wrong with no
        #: error bar is worse than no number: a planner told "0.9M cells" shaves `max_cells` and the mesh lands
        #: over the ceiling.
        "forecast_calibration": {k: calibration.get(k) for k in ("arm", "median_ratio", "p90_ratio", "n", "read_as")
                                 if k in calibration},
        #: Null, never 0, and null is what it is today: `cell_cap` has no reader anywhere in `src/meshpipeline`,
        #: so nothing on the platform side has a customer cap to hand down. The key is here so that the day one
        #: exists it has a name the planner already reads.
        "customer_cell_cap": int(forecast["cell_cap"]) if forecast.get("cell_cap") else None,
        "inlet_bore_m": _metres(builder.get("bore")),
        "inlet_opening_id": builder.get("inlet_id"),
        "smallest_port_min_dim_m": _metres(smallest.get("min_dimension")),
        #: Ranked by what the part needs: the flow path first, then what limits the cell size. `planner_places`.
        "places": places,
        #: The look, tiered by `vision.trust` and placed by `vision.place`. Absent when nothing looked, which
        #: is what leaves the planner's prompt exactly where it is today.
        "look": _planner_look(document, scale_f),
        "source_sha256": document.get("source_sha256"),
        "facts_sha256": _facts.get("sha256") if isinstance(_facts, dict) else None,
        "agent_git_sha": stamp.get("agent_git_sha") or "",
        "facts_schema_version": stamp.get("facts_schema_version"),
        "units": "m",
    }
    if block["look"] is None:
        # absent, never null. `planner.py` tests `_agent_block.get("look")` to decide whether to send the
        # look's note, and `geometry_brief.look_at_it` tests `isinstance(block.get("look"), dict)`; a null
        # passes neither, but a key that is there and empty invites a reader to print an empty heading
        block.pop("look")
    if refused:
        #: What the measurement has and the block will not state, with the reason. A refusal that travels is a
        #: builder that knows to be careful there; a refusal that is silence is a builder that assumes nothing is.
        block["places_refused"] = refused
    cov = planner_coverage(document)
    if cov is not None:
        block["coverage"] = cov
    # THE SURVEYOR'S BLOCK, checked by `contract.deliver.check_survey_block` before it is attached. It reads the
    # look through `block["look"]` and nothing else, which is the one path. A look the contract refuses is dropped
    # from the survey and the refusal named; the measured half is worth sending without it
    try:
        block["survey"] = planner_survey(document, block.get("look"), intake=intake)
    except Exception as exc:  # noqa: BLE001 - a description is never worth the planner block
        try:
            # A REFUSAL'S EXPLANATION MUST NEVER ITSELF BE REFUSABLE, and for two rounds it was. The reason went
            # in as the refusal's own message, which QUOTES the offending phrase, so a look refused for a word
            # was refused a second time at `look_refused` for the same word quoted back: measured on all eight of
            # `contract.survey.OUTCOME_WORDS` (which is not `catalog.OUTCOME_WORDS`, a different and much broader
            # list about the PLAN's own sentences), the block ended with no survey at all and the builder fell
            # open to a survey
            # composed with no document. `deliver.refusal_reason` names the rule and the place instead of
            # repeating what it refused, and proves the sentence it returns against the same rule.
            #
            # AND IT IS AN ARGUMENT RATHER THAN A KEY WRITTEN ON AFTER, so the reason is part of the composition:
            # one composer, one fit, one check, and `SURVEY_COMPOSED_KEYS` saying that only `planner_survey`
            # composes `look_refused` is true of the code as well as of the comment. Written on afterwards it
            # arrived past `_fit` and was measured only by the check, so the fit could not make room for it.
            block["survey"] = planner_survey(document, None, intake=intake,
                                             look_refused=_deliver.refusal_reason(exc))
        except Exception as again:  # noqa: BLE001 - nor is the survey worth the rest of the block
            # THE KEY THAT NOW HAS A READER. `contract.deliver.check_builder_handoff` reads this when the typed
            # block carries no survey, so a survey that broke its contract twice arrives at the last boundary as
            # a reason rather than as an absence nothing can tell apart from never having surveyed at all. BOTH
            # failures are named, because the one with the look and the one without it are different faults.
            #
            # THROUGH THE SAME SAFE COMPOSER, for the same reason and one more: this key rides in the typed block
            # the platform reads back (`application/geometry_survey` line 1222), so a refusal that quoted a
            # prediction would carry it to a reader by the one route that exists because the survey was refused.
            block["survey_refused"] = _deliver.safe_reason(
                f"with the look: {_deliver.refusal_reason(exc)}; without the look: "
                f"{_deliver.refusal_reason(again)}")
    missing = [k for k in ("representation", "agent_forecast_cells", "inlet_bore_m", "smallest_port_min_dim_m")
               if block.get(k) is None]
    if missing:
        block["status"] = "degraded"
        block["missing"] = missing
        if scale_f is None:
            #: Said in words because a planner reading four nulls cannot tell an unmeasurable part from a file
            #: whose unit nobody has stated, and the second is the common one.
            block["missing_because"] = ("the unit of this file has not been confirmed, so no length in this block "
                                        "can honestly be given in metres")
    return block


def planner_block_json(document: dict[str, Any] | None) -> str:
    return json.dumps(planner_block(document), indent=1, default=str)


def report_measured_json(facts: GeometryFacts, unit: str | None = None, brief: str | None = None, **kw) -> str:
    return json.dumps(report_measured(facts, unit, brief, **kw), indent=1, default=str)
