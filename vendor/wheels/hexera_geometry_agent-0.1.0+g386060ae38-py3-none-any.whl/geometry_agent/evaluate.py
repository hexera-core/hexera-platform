"""Score the agent against a corpus of geometries with known answers. Point it at your real cases.

Every per-case result carries a `stamp` (policy, model, prompt hash, split and key hashes, date, git sha) so a
number can always be traced to what produced it, and a locked-half export case whose answer key changed since
the split was frozen is refused (docs/eval_protocol.md)."""
from __future__ import annotations

import hashlib
import json
import math
import os
import subprocess
import sys
import time
import traceback
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from geometry_agent import observe
from geometry_agent.agent import grounding
from geometry_agent.agent.run import analyze
from geometry_agent.facts.measure import measure

SYNTHETIC_EXPECTED: dict[str, dict[str, Any]] = {
    "manifold_short": {"purpose": "internal_cfd", "cell_cap": 1_000_000, "openings": 4, "regions": 1, "watertight": True, "port_candidates": 4,
                       "roles": {"o1": "inlet", "o3": "outlet", "o4": "outlet"}, "unknown_allowed": ["o2"],
                       "expect_risks": ["short_stub", "velocity_spread", "undeclared_opening"],
                       "forbid_risks": ["not_watertight", "region_purpose_mismatch"], "object_type_contains": "manifold",
                       "stub_over_d": {"o3": 1.5, "o4": 1.5}},
    "manifold_long": {"purpose": "internal_cfd", "openings": 4, "regions": 1, "watertight": True, "port_candidates": 4,
                      "roles": {"o1": "inlet", "o3": "outlet", "o4": "outlet"},
                      "forbid_risks_for": {"short_stub": ["o3", "o4"]}, "stub_over_d": {"o3": 6.0, "o4": 6.0}},
    "pipe": {"purpose": "internal_cfd", "openings": 2, "regions": 1, "watertight": True, "port_candidates": 2,
             "forbid_risks": ["short_stub", "not_watertight", "thin_feature"], "stub_over_d": {"o1": 10.0, "o2": 10.0}},
    "open_pipe_shell": {"purpose": "internal_cfd", "openings": 2, "regions": 1, "watertight": False,
                        "expect_risks": ["not_watertight"], "opening_kinds": {"o1": "rim", "o2": "rim"}},
    "two_regions": {"purpose": "internal_cfd", "regions": 2, "watertight": True,
                    "expect_risks": ["region_purpose_mismatch"]},
    "thin_fin": {"purpose": "external_cfd", "regions": 1, "expect_risks": ["thin_feature", "external_domain"],
                 "thickness_min_between": [0.0018, 0.0022]},
    "naca0012": {"purpose": "external_cfd", "regions": 1, "expect_risks": ["knife_edge", "symmetry_opportunity"],
                 "flow_direction_sign": 1, "object_type_contains": "slender", "symmetry_planes_min": 2},
    "rotor_in_box": {"purpose": "external_cfd", "regions": 1, "watertight": True},
}


HARD_EXPECTED: dict[str, dict[str, Any]] = {
    "manifold_offaxis": {"purpose": "internal_cfd", "cell_cap": 1_000_000, "openings": 4, "regions": 1, "watertight": True, "port_candidates": 4,
                         "brief": "Distribution manifold, exported rotated in space. The large end port is the supply; it feeds "
                                  "the two small branch nozzles. The opposite large end is blanked off.",
                         "roles": {"o1": "inlet", "o3": "outlet", "o4": "outlet"}, "unknown_allowed": ["o2"],
                         "model_roles_any_of": [{"o1": "inlet", "o2": "closed_end"}, {"o2": "inlet", "o1": "closed_end"}],
                         "expect_risks": ["short_stub", "velocity_spread"], "stub_over_d": {"o3": 1.5, "o4": 1.5},
                         "note": "nothing axis-aligned; every number must match the aligned case"},
    "collector": {"purpose": "internal_cfd", "brief": "Return collector: three small branch inlets feed one large outlet at the end of the header. The other big end is capped.",
                  "openings": 5, "regions": 1, "watertight": True, "port_candidates": 5,
                  "roles": {"o3": "inlet", "o4": "inlet", "o5": "inlet"},
                  "model_roles_any_of": [{"o1": "outlet", "o2": "closed_end"}, {"o2": "outlet", "o1": "closed_end"}],
                  "stub_over_d": {"o3": 6.0, "o4": 6.0, "o5": 6.0},
                  "model_required": ["role o3", "role o4", "role o5"],
                  "note": "largest ports are the OUTLET and a blank; the brief does not say which end, so either assignment is right"},
    "pipe_wall_solid": {"purpose": "internal_cfd", "openings": 2, "regions": 1, "watertight": True, "port_candidates": 0,
                        "opening_kinds": {"o1": "ring", "o2": "ring"}, "expect_risks_any": ["wall_shell_to_carve", "solid_wall_representation"],
                        "forbid_risks": ["short_stub"], "note": "the file is metal, not fluid: a wall shell whose open ring ends are the ports of the cavity carved inside"},
    "elbow": {"purpose": "internal_cfd", "openings": 2, "regions": 1, "port_candidates": 2, "stub_over_d": {"o1": 5.5, "o2": 5.5},
              "forbid_risks": ["short_stub"], "unknown_allowed": ["o2"]},
    "pipe_with_drain": {"purpose": "internal_cfd", "openings": 3, "regions": 1, "port_candidates": 3, "expect_risks": ["tiny_port"],
                        "stub_over_d": {"o1": 10.0, "o2": 10.0, "o3": 6.0}, "note": "a D/10 hole must not be missed"},
    "tee_unequal": {"purpose": "internal_cfd", "openings": 4, "regions": 1, "port_candidates": 4, "stub_over_d": {"o2": 1.5, "o3": 6.0},
                    "expect_risks": ["short_stub"], "forbid_risks_for": {"short_stub": ["o3"]}},
    "internal_void": {"purpose": "structural", "regions": 2, "expect_risks": ["internal_void"],
                      "forbid_risks": ["region_purpose_mismatch"], "nested": [["r2", "r1"]]},
    "hairline_gap": {"purpose": "internal_cfd", "watertight": False, "openings": 3, "port_candidates": 2, "opening_kinds": {"o3": "rim"},
                     "expect_risks": ["not_watertight", "surface_holes"], "stub_over_d": {"o1": 10.0, "o2": 10.0},
                     "note": "a pinhole must not become a port, and must not break the stub march"},
    "seam_split": {"purpose": "internal_cfd", "watertight": False, "openings": 3, "port_candidates": 2, "opening_kinds": {"o3": "rim"},
                   "expect_risks": ["not_watertight", "surface_holes"], "stub_over_d": {"o1": 10.0, "o2": 10.0}},
    "sudden_expansion": {"purpose": "internal_cfd", "openings": 3, "port_candidates": 2, "opening_kinds": {"o1": "ring", "o2": "cap", "o3": "cap"},
                         "stub_over_d": {"o2": 3.67, "o3": 7.5}, "expect_risks": ["ring_faces_present"],
                         "forbid_risks_for": {"short_stub": ["o1"]}, "note": "the step shoulder is a wall, not a port"},
    "nested_cht": {"purpose": "conjugate_heat_transfer", "regions": 2, "nested": [["r2", "r1"]],
                   "expect_risks": ["solid_fluid_pair"], "forbid_risks": ["region_purpose_mismatch", "nested_bodies"],
                   "stub_over_d": {"o7": 7.5, "o8": 7.5}, "gap_between_regions_between": [0.00015, 0.00025]},
    "mm_manifold": {"purpose": "internal_cfd", "openings": 4, "port_candidates": 4, "unit_best_guess": "mm", "stub_over_d": {"o3": 1.5, "o4": 1.5},
                    "note": "600 file units: mm is plausible for a manifold, m is not"},
    "flapped_airfoil": {"purpose": "external_cfd", "regions": 2, "expect_risks": ["multi_body_external", "thin_feature"],
                        "forbid_risks": ["region_purpose_mismatch"], "gap_between_regions_between": [0.0035, 0.0045]},
    "brief_conflict": {"purpose": "internal_cfd",
                       "brief": "Manifold with two 40mm inlets on the branches and a single 25mm outlet at the end. Aluminium, water at 2 m/s.",
                       "openings": 4, "regions": 1, "port_candidates": 4, "expect_brief_conflicts_min": 1,
                       "model_required": ["brief conflicts"],
                       "note": "brief says 25mm outlet; the large ends are 100mm. Brief says water at 2 m/s but the file is a fluid volume. The model must flag the size contradiction."},
}


def write_hard_corpus(out: Path) -> Path:
    from geometry_agent.synthetic import HARD_CASES
    out.mkdir(parents=True, exist_ok=True)
    for name, (builder, _purpose) in HARD_CASES.items():
        d = out / name
        d.mkdir(exist_ok=True)
        geo = d / "geometry.stl"
        if not geo.exists():
            builder().export(geo)
        (d / "expected.json").write_text(json.dumps(HARD_EXPECTED[name], indent=1))
    return out


def write_synthetic_corpus(out: Path) -> Path:
    from geometry_agent.synthetic import CASES
    out.mkdir(parents=True, exist_ok=True)
    for name, (builder, _purpose) in CASES.items():
        d = out / name
        d.mkdir(exist_ok=True)
        geo = d / "geometry.stl"
        if not geo.exists():
            builder().export(geo)
        (d / "expected.json").write_text(json.dumps(SYNTHETIC_EXPECTED[name], indent=1))
    return out


def _nearest_opening(facts, near, max_over_d: float = 0.6):
    """The measured opening whose centroid is closest to `near`, if it is within 0.6 of its own hydraulic
    diameter (or 2% of the bounding diagonal for a zero-diameter face)."""
    import math
    best, best_d = None, None
    for o in facts.openings:
        d = math.dist(o.centroid, near)
        if best_d is None or d < best_d:
            best, best_d = o, d
    if best is None:
        return None
    tol = max_over_d * (best.hydraulic_diameter or 0.0) or 0.02 * facts.bbox.diagonal
    return best if best_d <= tol else None


def _match_ports(facts, wanted: list[dict]) -> list[tuple[dict, Any]]:
    """Each wanted port to the nearest measured opening; when a ring and an inner body's cap share a centroid (an
    annular port), the opening whose kind the expectation names wins."""
    out, used = [], set()
    for w in wanted:
        o = _nearest_opening(facts, w["near"])
        if o is not None and w.get("kind") and o.kind != w["kind"]:
            same_spot = [x for x in facts.openings if x.kind == w["kind"] and x.id not in used
                         and math.dist(x.centroid, w["near"]) <= 0.6 * max(x.hydraulic_diameter, 1e-9)]
            if same_spot:
                o = min(same_spot, key=lambda x: math.dist(x.centroid, w["near"]))
        if o is not None and o.id in used:
            o = None
        if o is not None:
            used.add(o.id)
        out.append((w, o))
    return out


def _find_geometry(case_dir: Path, exp: dict[str, Any] | None = None) -> Path | None:
    """The case's geometry file: one in the directory, or the absolute `source` path named in expected.json for
    files too big or too private to copy into the corpus."""
    src = (exp or {}).get("source")
    if src:
        p = Path(src)
        return p if p.exists() else None
    for p in sorted(case_dir.iterdir()):
        if p.suffix.lower() in {".stl", ".step", ".stp", ".obj", ".ply"}:
            return p
    return None


def _role_is_asked(plan, opening_id: str) -> bool:
    """A question asks the role of this opening: it relates to the patch, or to a role risk that names it."""
    role_kinds = {"undeclared_opening", "role_assumed", "declared_port_unmatched", "tiny_port"}
    risk_by_id = {r.id: r for r in plan.risks}
    for q in plan.questions:
        for rid in [q.relates_to, *q.also_settles]:
            if rid == opening_id:
                return True
            r = risk_by_id.get(rid)
            if r is not None and r.kind in role_kinds:
                m = r.measurement
                named = {m.get("opening_id")} | set(m.get("inlet_ids") or []) | set(m.get("outlet_ids") or [])
                if opening_id in named:
                    return True
    return False


def _without_this(plan) -> str:
    """One line: what the builder would have authored blind. The blocking and high risks are exactly the defects
    the validation log recorded on real runs, so they are what a mesh built without the plan would carry."""
    bad = [r for r in plan.risks if r.severity in ("blocking", "high")]
    if not bad:
        return "nothing the catalog or the agent could see"
    parts = []
    for r in bad[:4]:
        where = r.measurement.get("opening_id") or r.measurement.get("cluster_id") or ""
        parts.append(f"{r.kind}{' at ' + where if where else ''}")
    more = f" (+{len(bad) - 4} more)" if len(bad) > 4 else ""
    return "; ".join(parts) + more


def _judgment(plan) -> dict[str, Any]:
    return {
        "without_this": _without_this(plan),
        "object": f"{plan.object.type} (conf {plan.object.confidence:.2f})",
        "intent": plan.object.simulation_intent,
        "roles": {p.id: p.role for p in plan.patches},
        "flow": {"inlets": plan.flow.inlet_ids, "outlets": plan.flow.outlet_ids, "sign": plan.flow.direction_sign,
                 "conf": round(plan.flow.confidence, 2)},
        "brief_conflicts": plan.brief_conflicts,
        "agent_risks": [f"{r.kind} ({r.severity})" for r in plan.risks if r.detected_by == "agent"],
        "questions": [f"[{q.relates_to}{'+' + ','.join(q.also_settles) if q.also_settles else ''}] {q.text[:160]}"
                      + (f" (default: {q.default})" if q.default else "") for q in plan.questions],
        "unit": f"{plan.unit.assumed} ({plan.unit.basis})",
        "regions": {r.id: r.role for r in plan.mesh_plan.regions},
        "assumptions": plan.mesh_plan.assumptions,
        "refined_cells": plan.mesh_plan.cell_estimate_refined,
        "analysis": plan.analysis[:900],
        "for_user": plan.summary_for_user,
        "for_builder": plan.summary_for_builder[:500],
        # the fields the variance panel compares across repeated runs (eval/live/variance_panel.py)
        "representation": ("wall_shell" if any(r.role == "wall_shell" for r in plan.mesh_plan.regions) else
                           "external" if plan.purpose == "external_cfd" else "fluid_domain"),
        "seed_point": list(plan.mesh_plan.seed_point) if plan.mesh_plan.seed_point else None,
        "inlet_bore": next((p.hydraulic_diameter for p in plan.patches if p.id in plan.flow.inlet_ids), None),
        "risk_kinds": sorted({r.kind for r in plan.risks}),
        "question_count": len(plan.questions),
    }


# --- the lock-down: split side, locked key hashes, result stamps -------------------------------------------------

ROOT = Path(__file__).resolve().parents[2]
EXPORT_CASES_DIR = ROOT / "eval" / "corpus_export_cases"
SPLIT_FILE = ROOT / "eval" / "split" / "export_split.json"
LOCKED_HASHES_FILE = ROOT / "eval" / "locked_key_hashes.json"
ALLOW_KEY_CHANGE_ENV = "GEOMETRY_AGENT_ALLOW_KEY_CHANGE"
_JSON_CACHE: dict[tuple[str, float], Any] = {}
_GIT_SHA: list[str | None] = []


class LockedKeyChanged(RuntimeError):
    """A locked-half answer key no longer matches the hash frozen with the split. Scoring it would let an edit to
    the held-out truth pass unnoticed, so the evaluator stops instead of scoring."""


def _read_json_cached(path: Path) -> Any:
    """The split and the locked hashes, read once per file version: keyed on the resolved path and its mtime so a
    rewritten file is seen and the hundreds of cases in one run do not reread it."""
    try:
        p = path.resolve()
        key = (str(p), p.stat().st_mtime)
    except OSError:
        return None
    if key not in _JSON_CACHE:
        try:
            _JSON_CACHE[key] = json.loads(p.read_text(encoding="utf-8"))
        except ValueError:
            _JSON_CACHE[key] = None
    return _JSON_CACHE[key]


def export_split_side(case_dir: Path) -> str | None:
    """'learning', 'locked' or None. Only a case directly under eval/corpus_export_cases is looked up, so every
    other corpus runs without a split file and never touches the hashes."""
    try:
        if case_dir.resolve().parent != EXPORT_CASES_DIR.resolve():
            return None
    except OSError:
        return None
    split = _read_json_cached(SPLIT_FILE)
    if not isinstance(split, dict):
        return None
    if case_dir.name in split.get("locked", []):
        return "locked"
    if case_dir.name in split.get("learning", []):
        return "learning"
    return None


def key_sha256(case_dir: Path) -> str | None:
    """sha256 of the case's expected.json bytes, the same hash eval/split/make_split.py freezes."""
    p = case_dir / "expected.json"
    return hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None


def guard_locked_key(case_dir: Path, key_sha: str | None, side: str | None) -> None:
    """Refuse a locked case whose expected.json differs from the frozen hash (or has none), unless
    GEOMETRY_AGENT_ALLOW_KEY_CHANGE=1 marks a deliberate, ledger-logged key change."""
    if side != "locked":
        return
    hashes = _read_json_cached(LOCKED_HASHES_FILE)
    frozen = hashes.get(case_dir.name) if isinstance(hashes, dict) else None
    if frozen is not None and frozen == key_sha:
        return
    if os.environ.get(ALLOW_KEY_CHANGE_ENV) == "1":
        print(f"WARNING: locked case {case_dir.name}: expected.json sha256 {key_sha} differs from the frozen "
              f"{frozen or 'absent'}; scored anyway because {ALLOW_KEY_CHANGE_ENV}=1. Log it in docs/eval_protocol.md.",
              file=sys.stderr)
        return
    raise LockedKeyChanged(
        f"{case_dir.name} is in the locked half and its expected.json (sha256 {key_sha}) does not match the hash "
        f"frozen in {LOCKED_HASHES_FILE.name} ({frozen or 'absent'}). A locked answer key must not change during "
        f"development. If the change is deliberate, record it in docs/eval_protocol.md and rerun "
        f"eval/split/make_split.py --rehash --force, or set {ALLOW_KEY_CHANGE_ENV}=1 for this one run.")


def agent_git_sha() -> str | None:
    """HEAD of the geometry_agent checkout, resolved once per process; None without git or outside a checkout."""
    if not _GIT_SHA:
        sha = None
        try:
            proc = subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT, capture_output=True, text=True, timeout=10)  # noqa: S603,S607 (fixed argv)
            sha = (proc.stdout.strip() or None) if proc.returncode == 0 else None
        except (OSError, subprocess.TimeoutExpired):
            sha = None
        _GIT_SHA.append(sha)
    return _GIT_SHA[0]


def prompt_sha256() -> str:
    """sha256 of the system prompt in force (the file variant when GEOMETRY_AGENT_PROMPT_FILE is set)."""
    from geometry_agent.agent.prompt import system_prompt
    return hashlib.sha256(system_prompt().encode("utf-8")).hexdigest()


def model_name(client: Any) -> str | None:
    """The model id a client calls: its own `model`, the wrapped client's (RecordingClient), or the one the recording
    names (ReplayClient). None for the reference policy, which calls no model."""
    for obj in (client, getattr(client, "inner", None)):
        m = getattr(obj, "model", None)
        if isinstance(m, str) and m:
            return m
    meta = getattr(client, "meta", None)
    if isinstance(meta, dict) and isinstance(meta.get("model"), str):
        return meta["model"]
    return None


#: The vision tool's name, as the loop's trace records it.
LOOK_TOOL = "look_at_views"


def vision_state(offered: bool, calls: int, failures: int = 0, impression: bool | None = None) -> str:
    """What the stamp's `vision` field says, and it says what happened rather than what was configured.

    `on` meant "a vision client was attached", and that is how every result of every run came to be stamped
    vision on: the tool was offered on 159 of 159 cases of learning_v3_r4 and called on none of them, and on
    322 of 322 of the full run and called on 17. A claim about vision could not be read off the stamp at all.
    So: `off` when no vision model was attached, `offered` when it was and the model never asked, `called`
    when it did, `failed` when it tried and came away with nothing, with `vision_calls` carrying how many
    times and `vision_failures` how many of those failed. `failed` is its own word because a run that tried to
    look and could not is not a run that chose not to look, and reading them as one is how the stamp lied in
    the first place.

    `impression` is the run's own answer to the only question that settles it: does it have a description? The
    counts alone cannot tell, and both ways they were wrong. A render that fails never reaches the model, so
    nothing counted a call and a run that tried and failed stamped `offered`, the word for a model that chose
    not to look. A look abandoned on its deadline was counted going in and never counted as a failure, so a run
    with no description stamped `called`. Pass it and neither can happen; pass None (a caller with no result to
    read, such as the stamp written before the run) and the counts decide as before."""
    if not offered:
        return "off"
    if impression is not None:
        return "called" if impression else "failed"
    if not calls:
        return "offered"
    return "failed" if failures >= calls else "called"


def vision_calls_of(res: Any) -> int:
    """How many times a run really looked. A repeat is answered from the impression the first look fetched
    (tools.look_at_views keeps one per run) and the loop marks it, so it is not counted as a look."""
    return sum(1 for t in getattr(res, "trace", []) or []
               if t.get("tool") == LOOK_TOOL and not t.get("repeated"))


def vision_impression_of(res: Any) -> bool | None:
    """Whether the run came away with a description, or None when the result cannot say.

    Two readings, in this order. The plan carries the impression the checker filled from the run
    (`grounding._fill_visual_impression`), so a plan that has one is proof the run had one. A run that produced
    no plan still has the round-0 trace entry the loop writes whenever a vision client was attached, and that
    entry says whether the opening look came back with words. Where neither exists the answer is None and the
    stamp falls back to the call counts."""
    plan = getattr(res, "plan", None)
    if plan is not None and getattr(plan, "visual_impression", None) is not None:
        return True
    for t in getattr(res, "trace", []) or []:
        if t.get("round") == 0 and isinstance(t.get("vision"), dict):
            return bool(t["vision"].get("looked"))
    return None


@dataclass
class _VisionMeter:
    """Wraps the vision client so the stamp can say what the look actually did, the way `_UsageMeter` wraps the
    text client so the result can say what the model cost.

    The run's own trace says a look was asked for; only the client knows whether one happened, what answered it,
    and why it did not. Nothing else on the path has that: `AnalysisResult` carries a trace of tool names and
    result keys, and the ToolContext that holds the impression is not returned. So the count, the model that
    answered, the provider, and the failures with their reasons are taken here."""
    inner: Any
    calls: int = 0
    failures: int = 0
    seconds: float = 0.0
    model: str = ""
    provider: str = ""
    errors: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        # start from what the adapter is configured with, so `meter.model` reads the same as `client.model`
        # before any call; a reply that names a different model replaces it
        self.model = self.model or str(getattr(self.inner, "model", "") or "")
        self.provider = self.provider or str(getattr(self.inner, "provider", "") or "")

    def describe(self, images, prompt, system=None):
        self.calls += 1
        t0 = time.perf_counter()
        try:
            reply = self.inner.describe(images, prompt, system=system)
        # the same net tools.look_at_views casts, and for the same reason: an adapter reading a provider's JSON
        # can fail in any way, and the reason is the thing the stamp is for. It is recorded and re-raised, so the
        # tool decides what a failed look does to the run and this only writes down that it happened
        except Exception as exc:
            self.failures += 1
            self.seconds += time.perf_counter() - t0
            self.errors.append(f"{type(exc).__name__}: {str(exc)[:200]}")
            raise
        self.seconds += time.perf_counter() - t0
        self.model = str(getattr(reply, "model", "") or self.model)
        self.provider = str(getattr(reply, "provider", "") or self.provider)
        return reply

    def __getattr__(self, name: str) -> Any:
        # `model` and `provider` are fields of this dataclass, so only the rest of the client's surface (the
        # capability probe, the timeout, anything an adapter adds) falls through to it. `inner` is excluded by
        # hand: __getattr__ runs when normal lookup fails, and on a half-built or unpickled meter that would be
        # `inner` itself, which would recurse forever instead of raising
        if name == "inner":
            raise AttributeError(name)
        return getattr(self.inner, name)

    def stamp_fields(self, offered: bool, calls: int, impression: bool | None = None) -> dict[str, Any]:
        """The vision half of the stamp. `calls` is the run's own count of looks from its trace; where the two
        disagree the client's is the one that names a failure, so both are written and the state reads the
        client's. `impression` is the run's own answer to whether it came away with a description, and where it
        is known it settles the state: neither count can see a render that failed before the model was reached
        or a look abandoned while the call was still open."""
        looks = max(int(calls), self.calls)
        return {"vision": vision_state(offered, looks, self.failures, impression), "vision_calls": looks,
                "vision_failures": self.failures, "vision_model": self.model or None,
                "vision_provider": self.provider or None,
                "vision_errors": self.errors[:3] or None, "vision_seconds": round(self.seconds, 1) if self.calls else None}


def _vision_stamp(vision: Any, offered: bool, calls: int, impression: bool | None = None) -> dict[str, Any]:
    """The vision fields for a stamp, whether or not the client is metered (a caller that passes a bare client,
    or a heuristic or replay run that passes none, still gets every key). `impression` is what the run came away
    with, from `vision_impression_of`; None where there is no result to read it off yet."""
    if isinstance(vision, _VisionMeter):
        return vision.stamp_fields(offered, calls, impression)
    return {"vision": vision_state(offered, int(calls), 0, impression), "vision_calls": int(calls), "vision_failures": 0,
            "vision_model": (str(getattr(vision, "model", "")) or None) if offered else None,
            "vision_provider": (str(getattr(vision, "provider", "")) or None) if offered else None,
            "vision_errors": None, "vision_seconds": None}


def result_stamp(policy: str, provider: str | None, model: str | None, case_dir: Path, key_sha: str | None,
                 vision_offered: bool, memory: str = "off", vision_calls: int = 0,
                 vision: Any = None) -> dict[str, Any]:
    """What every result carries so it can be told apart from a result under another policy, prompt, model, split,
    thresholds or key without asking who ran it (dev plan principle 4). thresholds_sha256 is the hash of the
    governed table in force (agent/thresholds.json, or the file $GEOMETRY_AGENT_THRESHOLDS_FILE names).

    The vision fields say what happened rather than what was configured: `vision` off / offered / called /
    failed, `vision_calls`, `vision_failures`, `vision_model`, `vision_provider`, `vision_errors` and
    `vision_seconds`. Pass the metered client as `vision` for the last four."""
    from geometry_agent.agent.thresholds import thresholds_sha256
    side = export_split_side(case_dir)
    split = _read_json_cached(SPLIT_FILE) if side else None
    return {
        "policy": policy, "provider": provider, "model": model, "prompt_sha256": prompt_sha256(),
        "thresholds_sha256": thresholds_sha256(), "split": side,
        "split_sha256": split.get("sha256") if isinstance(split, dict) else None,
        "key_sha256": key_sha, **_vision_stamp(vision, vision_offered, vision_calls), "memory": memory,
        "date": datetime.now(UTC).isoformat(timespec="seconds"), "agent_git_sha": agent_git_sha(),
    }


@dataclass
class _UsageMeter:
    """Wraps any client and adds up the usage each response reports (OpenAI or Anthropic key names) and the wall
    seconds spent inside the model, so a result can carry its token cost without a recording."""
    inner: Any
    prompt_tokens: int = 0
    completion_tokens: int = 0
    seconds: float = 0.0
    turns: int = 0
    reported: bool = False

    def complete(self, messages: list[dict], tools: list[dict], force_tool: str | None = None):
        t0 = time.perf_counter()
        # force_tool is passed on: dropping it made the loop's probe cutoff advice rather than a requirement on
        # every live eval run, which is the opposite of what P4.3 measured (docs/plan_v3_rules.md section 9)
        resp = self.inner.complete(messages, tools, force_tool)
        self.seconds += time.perf_counter() - t0
        self.turns += 1
        # a provider that reports usage as anything but an object is counted as reporting none, rather than
        # raising AttributeError here and losing the case to a crash
        u = resp.usage if isinstance(resp.usage, dict) else {}
        p = u.get("prompt_tokens", u.get("input_tokens"))
        c = u.get("completion_tokens", u.get("output_tokens"))
        if p is not None or c is not None:
            self.reported = True
        try:
            self.prompt_tokens += int(p or 0)
            self.completion_tokens += int(c or 0)
        except (TypeError, ValueError):
            pass
        return resp

    def totals(self) -> dict[str, Any] | None:
        """None when no response carried usage (the reference policy, or a recording made without it)."""
        if not self.reported:
            return None
        return {"prompt_tokens": self.prompt_tokens, "completion_tokens": self.completion_tokens,
                "seconds": round(self.seconds, 1), "turns": self.turns}


def memory_mode(memory: Any) -> str:
    """The stamp's memory field: off, on or shuffled (dev plan P7). A provider carries its own mode; None is off."""
    mode = getattr(memory, "mode", None) if memory is not None else None
    return str(mode) if mode in ("on", "shuffled", "off") else "off"


def case_memory(mode: str = "off", index_path: str | Path | None = None) -> Any:
    """The memory provider for `--memory on|shuffled`, imported lazily so the evaluator runs without the
    learning loop's index on disk. Returns None for off, and raises when the index is missing."""
    if mode == "off":
        return None
    from geometry_agent.learn.memory import INDEX_JSON, CaseMemory, read_index
    path = Path(index_path) if index_path else INDEX_JSON
    if not path.exists():
        raise RuntimeError(f"--memory {mode} needs a built index at {path}: run "
                           "`python -m geometry_agent.learn.memory build --cache-dir <facts cache>` first")
    return CaseMemory(read_index(path), mode=mode)


def vision_client(provider: str = "auto") -> Any:
    """The vision client for `--vision on`, imported lazily so the evaluator runs before the vision package exists.

    One client serves the whole run; `score_case` wraps it in a fresh `_VisionMeter` per case, because the run's
    workers are threads and a shared meter would count every case's looks into every case's stamp."""
    try:
        from geometry_agent.vision.client import vision_client_from_env
    except ImportError as exc:
        raise RuntimeError("--vision on needs geometry_agent.vision.client.vision_client_from_env, which this "
                           "checkout does not have yet") from exc
    client = vision_client_from_env(provider)
    if client is None:
        raise RuntimeError(f"no vision client for provider={provider!r}: set its key, or run with --vision off")
    return client


def score_case(case_dir: Path, heuristic: bool, cache_dir: str | None, provider: str = "auto",
               record_dir: Path | None = None, replay_dir: Path | None = None, isolated: bool = False,
               vision: Any = None, memory: Any = None) -> dict[str, Any]:
    exp = json.loads((case_dir / "expected.json").read_text())
    policy = "replay" if replay_dir is not None else "heuristic" if heuristic else "live"
    key_sha = key_sha256(case_dir)
    guard_locked_key(case_dir, key_sha, export_split_side(case_dir))
    # one meter per case, never per run: the workers are threads over one shared client
    looked_with = _VisionMeter(vision) if vision is not None and not isinstance(vision, _VisionMeter) else vision
    stamp = result_stamp(policy, provider if policy == "live" else None, None, case_dir, key_sha, vision is not None,
                         memory=memory_mode(memory), vision=looked_with)
    geo = _find_geometry(case_dir, exp)
    checks: list[tuple[str, bool, str]] = []
    if geo is None:
        if exp.get("source"):
            return {"case": case_dir.name, "passed": True, "checks": [("source", True, f"{exp['source']} absent on this machine; skipped")],
                    "rounds": 0, "tool_calls": 0, "seconds": 0.0, "skipped": True, "stamp": stamp}
        return {"case": case_dir.name, "passed": False, "checks": [("geometry file", False, "missing")], "stamp": stamp}
    purpose = exp["purpose"]
    t_measure = time.perf_counter()
    if isolated:
        from geometry_agent.facts.measure import measure_isolated
        try:
            facts = measure_isolated(geo, purpose=purpose, cache_dir=cache_dir or ".facts_cache")
        except Exception as exc:
            return {"case": case_dir.name, "passed": False, "checks": [("measurement", False, f"{type(exc).__name__}: {str(exc)[:300]}")],
                    "rounds": 0, "tool_calls": 0, "seconds": 0.0, "exit": "measurement_failed", "reason": str(exc)[:300],
                    "stamp": stamp}
    else:
        facts = measure(geo, purpose=purpose, cache_dir=cache_dir)
    measure_seconds = time.perf_counter() - t_measure

    def chk(name: str, ok: bool, detail: str = ""):
        checks.append((name, bool(ok), detail))

    if "openings" in exp:
        chk("openings", len(facts.openings) == exp["openings"], f"{len(facts.openings)} vs {exp['openings']}")
    if "regions" in exp:
        chk("regions", len(facts.regions) == exp["regions"], f"{len(facts.regions)} vs {exp['regions']}")
    if "bodies" in exp:
        chk("bodies", facts.bodies == exp["bodies"], f"{facts.bodies} vs {exp['bodies']}")
    if "interfaces_min" in exp:
        chk("interfaces >=", len(facts.interfaces) >= exp["interfaces_min"], str(len(facts.interfaces)))
    if "unit_declared" in exp:
        chk("unit declared", facts.units.declared == exp["unit_declared"], str(facts.units.declared))
    if "measure_seconds_max" in exp:
        chk("measure time", measure_seconds <= exp["measure_seconds_max"], f"{measure_seconds:.1f}s vs {exp['measure_seconds_max']}s")
    if "watertight" in exp:
        chk("watertight", facts.watertight == exp["watertight"], str(facts.watertight))
    if exp.get("bbox_extent_mm") and facts.units.declared == "mm":
        want = sorted(exp["bbox_extent_mm"])
        got = sorted(facts.bbox.extent)
        chk("bbox extent", all(abs(g / w - 1) < 0.025 for g, w in zip(got, want) if w > 0), f"{[round(g, 2) for g in got]} vs {want}")
    for oid, kind in (exp.get("opening_kinds") or {}).items():
        o = facts.opening(oid)
        chk(f"kind {oid}", o is not None and o.kind == kind, o.kind if o else "missing")
    for oid, ld in (exp.get("stub_over_d") or {}).items():
        s = facts.stub(oid)
        chk(f"stub {oid}", s is not None and abs(s.length_over_diameter - ld) < 0.25, f"{s.length_over_diameter:.2f} vs {ld}" if s else "missing")
    if "thickness_min_between" in exp:
        lo, hi = exp["thickness_min_between"]
        t = facts.features.thickness_min
        chk("thickness_min", t is not None and lo <= t <= hi, f"{t}")
    if "symmetry_planes_min" in exp:
        chk("symmetry", len(facts.axes.symmetry_planes or []) >= exp["symmetry_planes_min"], str(facts.axes.symmetry_planes))
    if "nested" in exp:
        got = sorted([r.id, r.nested_in] for r in facts.regions if r.nested_in)
        chk("nesting", got == sorted(exp["nested"]), str(got))
    if "gap_between_regions_between" in exp:
        lo, hi = exp["gap_between_regions_between"]
        g = facts.features.min_gap_between_regions
        chk("region gap", g is not None and lo <= g <= hi, str(g))
    if "unit_best_guess" in exp:
        chk("unit guess", facts.units.candidates and facts.units.candidates[0][0] == exp["unit_best_guess"],
            str(facts.units.candidates[:2]))
    if "openings_min" in exp:
        chk("openings >=", len(facts.openings) >= exp["openings_min"], str(len(facts.openings)))
    if "nested_min" in exp:
        chk("nested >=", sum(1 for r in facts.regions if r.nested_in) >= exp["nested_min"], str([(r.id, r.nested_in) for r in facts.regions]))
    if "port_candidates" in exp:
        n_pc = sum(1 for o in facts.openings if o.classification == "port_candidate")
        chk("port candidates", n_pc == exp["port_candidates"], f"{n_pc} vs {exp['port_candidates']}")
    if "planar_faces_min" in exp:
        n_pf = sum(1 for o in facts.openings if o.classification == "planar_face")
        chk("planar faces >=", n_pf >= exp["planar_faces_min"], str(n_pf))
    if "holes_min" in exp:
        n_h = sum(1 for o in facts.openings if o.classification == "hole")
        chk("holes >=", n_h >= exp["holes_min"], str(n_h))
    if "rotational_symmetry_order" in exp:
        got = getattr(facts.axes, "rotational_order", None)
        chk("rotational symmetry", got == exp["rotational_symmetry_order"], f"{got} vs {exp['rotational_symmetry_order']}")
    port_match = _match_ports(facts, exp.get("ports") or [])
    for want, o in port_match:
        tag = f"port@{[round(v, 3) for v in want['near']]}"
        if o is None:
            chk(f"{tag} found", False, "no opening near that point")
            continue
        chk(f"{tag} found", True, o.id)
        if "kind" in want:
            chk(f"{tag} kind", o.kind == want["kind"], f"{o.kind} vs {want['kind']}")
        if "class" in want:
            chk(f"{tag} class", o.classification == want["class"], f"{o.classification} vs {want['class']}")
        if want.get("hydraulic_diameter") and o.kind != "ring":
            chk(f"{tag} D_h", abs(o.hydraulic_diameter / want["hydraulic_diameter"] - 1) < 0.06,
                f"{o.hydraulic_diameter:.4g} vs {want['hydraulic_diameter']:.4g}")
        if want.get("bore_diameter") and o.kind == "ring":
            chk(f"{tag} bore", o.bore_diameter is not None and abs(o.bore_diameter / want["bore_diameter"] - 1) < 0.06,
                f"{o.bore_diameter} vs {want['bore_diameter']}")
        if want.get("stub_over_d") is not None:
            s = facts.stub(o.id)
            tol = want.get("stub_tol") or max(0.3, 0.12 * want["stub_over_d"])
            chk(f"{tag} stub", s is not None and abs(s.length_over_diameter - want["stub_over_d"]) <= tol,
                f"{s.length_over_diameter:.2f} vs {want['stub_over_d']} (tol {tol})" if s else "no stub measured")

    def skipped(note: str) -> dict[str, Any]:
        return {"case": case_dir.name, "passed": all(c[1] for c in checks), "checks": checks + [("replay", True, note)],
                "rounds": 0, "tool_calls": 0, "seconds": 0.0, "skipped": True, "stamp": stamp}

    recorder = None
    if replay_dir is not None:
        from geometry_agent.agent.client import ReplayClient
        rec = replay_dir / f"{case_dir.name}.json"
        if not rec.exists():
            return skipped("no recording; skipped")
        client = ReplayClient(rec)
        if client.exit is not None and client.exit != "submitted":
            return skipped(f"recording ended in {client.exit} after {client.turns} turns; skipped")
        if not client.meta.get("passed"):
            return skipped("recording did not pass its checks when made (or predates the passed flag); skipped")
    elif heuristic:
        from geometry_agent.agent.reference import ReferencePolicy
        client = ReferencePolicy()
    else:
        from geometry_agent.agent.client import client_from_env
        client = client_from_env(provider)
        if record_dir is not None:
            from geometry_agent.agent.client import RecordingClient
            client = recorder = RecordingClient(client, record_dir / f"{case_dir.name}.json")
    stamp["model"] = model_name(client)
    meter = _UsageMeter(client)
    t0 = time.perf_counter()
    # `vision` is passed only when given, so this runs against an analyze() that does not know the argument yet
    res = analyze(geo, purpose=purpose, brief=exp.get("brief", ""), fidelity=exp.get("fidelity", "standard"),
                  cell_cap=exp.get("cell_cap"), declared=exp.get("declared"), client=meter, cache_dir=cache_dir, facts=facts,
                  **({"vision": looked_with} if looked_with is not None else {}),
                  **({"memory": memory} if memory is not None else {}))
    seconds = time.perf_counter() - t0
    # the stamp says what vision did, not what was asked for: offered and never called was the common case, and
    # the meter is the only thing on the path that knows a look failed and why. What the run came away with is
    # the run's own to say, and it is the only reading that separates a look that failed from one never made
    looks = vision_calls_of(res)
    stamp.update(_vision_stamp(looked_with, vision is not None, looks, vision_impression_of(res)))
    if replay_dir is not None and res.exit == "model_error" and "replay exhausted" in res.reason:
        return skipped(f"partial recording ({client.turns} turns, never finished); skipped")
    if heuristic and exp.get("heuristic_plan") is False:
        # a deterministic policy cannot plan this file (hundreds of openings, roles only a brief can settle); the
        # measurement checks above are the point of the case, the plan needs the model
        chk("plan accepted (needs model)", True, f"heuristic gave {res.exit}; skipped")
    else:
        chk("plan accepted", res.ok, res.exit)
    if res.ok and res.plan:
        plan = res.plan
        kinds = {r.kind for r in plan.risks}
        for k in exp.get("expect_risks", []):
            chk(f"risk {k}", k in kinds)
        for k in exp.get("forbid_risks", []):
            chk(f"no risk {k}", k not in kinds)
        for k, ids in (exp.get("forbid_risks_for") or {}).items():
            bad = [r.measurement.get("opening_id") for r in plan.risks if r.kind == k and r.measurement.get("opening_id") in ids]
            chk(f"no {k} on {ids}", not bad, str(bad))
        role_of = {p.id: p.role for p in plan.patches}
        unknown_ok = set(exp.get("unknown_allowed", []))
        model_only = set(exp.get("model_required", []))
        wanted = dict(exp.get("roles") or {})
        if not heuristic:
            wanted.update(exp.get("model_roles") or {})
        for oid, role in wanted.items():
            got = role_of.get(oid)
            ok = got == role or (got == "opening_unknown" and oid in unknown_ok)
            if heuristic and f"role {oid}" in model_only:
                chk(f"role {oid} (needs model)", True, f"heuristic gave {got}; skipped")
            else:
                chk(f"role {oid}", ok, f"{got} vs {role}")
        alternatives = exp.get("model_roles_any_of")
        if alternatives and not heuristic:
            got_all = {k: role_of.get(k) for alt in alternatives for k in alt}
            chk("roles match one alternative", any(all(role_of.get(k) == v for k, v in alt.items()) for alt in alternatives),
                f"{got_all} vs any of {alternatives}")
        for want, o in port_match:
            if o is None or not want.get("role") or want["role"] == "any":
                continue
            tag = f"port@{[round(v, 3) for v in want['near']]}"
            got = role_of.get(o.id)
            if heuristic and want.get("needs_model"):
                chk(f"{tag} role (needs model)", True, f"heuristic gave {got}; skipped")
            else:
                ok = got == want["role"] or (got == "opening_unknown" and want["role"] in ("opening_unknown", "closed_end"))
                if want["role"] == "opening_unknown" and got in ("inlet", "outlet", "closed_end") and _role_is_asked(plan, o.id):
                    # nothing in the file or brief decides it: an assumed role with a defaulted question is the v2 answer
                    ok = True
                chk(f"{tag} role", ok, f"{got} vs {want['role']}")
        by_pos = exp.get("model_roles_any_of_by_position")
        if by_pos and not heuristic:
            found = [(role, _nearest_opening(facts, near)) for near, role in by_pos]
            chk("one of the positioned roles", any(o is not None and role_of.get(o.id) == role for role, o in found),
                str([(role, o.id if o else None, role_of.get(o.id) if o else None) for role, o in found]))
        if exp.get("flow_axis"):
            from geometry_agent.agent.hexera import _snap_axis
            axis = _snap_axis(plan.flow.axis)
            if axis and plan.flow.direction_sign < 0:
                axis = ("-" if axis[0] == "+" else "+") + axis[1]
            if heuristic and "flow axis" in model_only:
                chk("flow axis (needs model)", True, f"heuristic gave {axis}; skipped")
            else:
                chk("flow axis", axis == exp["flow_axis"], f"{axis} vs {exp['flow_axis']}")
        if "flow_direction_sign" in exp:
            if heuristic and "flow sign" in model_only:
                chk("flow sign (needs model)", True, f"heuristic gave {plan.flow.direction_sign}; skipped")
            else:
                chk("flow sign", plan.flow.direction_sign == exp["flow_direction_sign"], str(plan.flow.direction_sign))
        if "object_type_contains" in exp:
            chk("identity", exp["object_type_contains"] in plan.object.type.lower(), plan.object.type)
        pending = [r.id for r in plan.risks if r.requires_user_decision and r.user_decision == "pending"
                   and not any(q.relates_to == r.id or r.id in q.also_settles for q in plan.questions)]
        chk("every decision has a question", not pending, str(pending))
        if "expect_brief_conflicts_min" in exp:
            n = exp["expect_brief_conflicts_min"]
            if heuristic and "brief conflicts" in model_only:
                chk("brief conflicts (needs model)", True, f"heuristic gave {len(plan.brief_conflicts)}; skipped")
            else:
                chk("brief conflicts", len(plan.brief_conflicts) >= n, f"{len(plan.brief_conflicts)} vs >= {n}: {plan.brief_conflicts}")
        if "expect_agent_risks_min" in exp and not heuristic:
            n_agent = sum(1 for r in plan.risks if r.detected_by == "agent")
            chk("agent-found risks", n_agent >= exp["expect_agent_risks_min"], str(n_agent))
        # job-derived answer keys: any of the mapped kinds counts as predicting the recorded failure
        if exp.get("expect_risks_any"):
            hit = sorted(k for k in exp["expect_risks_any"] if k in kinds)
            chk("predicts recorded failure", bool(hit), f"{hit or 'none'} of {exp['expect_risks_any']}")
        if exp.get("forbid_blocking"):
            blocking = sorted(r.kind for r in plan.risks if r.severity == "blocking")
            chk("no blocking risk on a first-time pass", not blocking, str(blocking))
        if "max_questions" in exp:
            chk("question count", len(plan.questions) <= exp["max_questions"], f"{len(plan.questions)} vs <= {exp['max_questions']}")
        if "unit_assumed" in exp:
            chk("unit assumed", plan.unit.assumed == exp["unit_assumed"], f"{plan.unit.assumed} ({plan.unit.basis}) vs {exp['unit_assumed']}")
        if "region_roles" in exp:
            got = {r.id: r.role for r in plan.mesh_plan.regions}
            bad = {k: (got.get(k), v) for k, v in exp["region_roles"].items() if got.get(k) != v}
            chk("region roles", not bad, str(bad))
        if exp.get("forbid_question_kinds"):
            kind_of = {r.id: r.kind for r in plan.risks}
            asked = sorted({kind_of.get(q.relates_to, q.relates_to) for q in plan.questions})
            bad_q = [k for k in asked if k in exp["forbid_question_kinds"]]
            chk("no question on settled kinds", not bad_q, str(bad_q))
        if exp.get("intake_patches"):
            from geometry_agent.agent.hexera import intake_patches
            want = sorted({str(p.get("type")) for p in exp["intake_patches"] if p.get("type")})
            got = sorted({p["type"] for p in intake_patches(plan, facts)})
            missing = [t for t in want if t not in got]
            chk("handover roles cover intake patches", not missing, f"missing {missing}; got {got}")
    out = {"case": case_dir.name, "passed": all(c[1] for c in checks), "checks": checks,
           "rounds": res.rounds, "tool_calls": res.tool_calls, "grounding_rejections": res.grounding_rejections,
           "seconds": round(seconds, 1), "exit": res.exit, "reason": res.reason,
           "rejections": [t.get("errors", []) for t in res.trace
                          if t.get("tool") in ("submit_geometry_plan", "amend_geometry_plan") and not t.get("accepted")],
           "truncated_turns": sum(1 for t in res.trace if t.get("truncated")),
           "prose_guard_hits": sum(1 for t in res.trace if t.get("prose_guard")),
           "amendments": sum(1 for t in res.trace if t.get("tool") == "amend_geometry_plan"),
           "tool_sequence": [t.get("tool") or "text" for t in res.trace],
           # how many times the run really looked at the part (0 with vision off, and 0 on most runs with it on)
           "vision_calls": stamp["vision_calls"],
           # what the look returned, once, in words: the plan carries it and the result repeats it here so a
           # stored result can be read for what was seen without reopening the recording. None when none ran.
           "visual_impression": (res.plan.visual_impression.model_dump()
                                 if res.plan is not None and res.plan.visual_impression is not None else None),
           # what case memory showed this run, without its text (dev plan P7): None when memory was off or silent
           "memory_block": next((t["memory"] for t in res.trace if t.get("memory")), None),
           "stamp": stamp, "usage": meter.totals(),
           # the plan schema the accepted plan was judged under (grounding.plan_version); None without a plan
           "plan_schema_version": grounding.plan_version(res.plan) if res.ok and res.plan else None}
    if res.ok and res.plan:
        out["judgment"] = _judgment(res.plan)
    if recorder is not None:
        recorder.finish(res.exit, reason=res.reason, rounds=res.rounds, tool_calls=res.tool_calls,
                        grounding_rejections=res.grounding_rejections, seconds=round(seconds, 1), case=case_dir.name,
                        passed=out["passed"], failed_checks=[c[0] for c in checks if not c[1]])
    # the one line that says which case a run.start and run.end pair belonged to: with several workers the
    # loop's own lines interleave, and a log of an overnight run is unreadable without the name
    observe.info("case.end", case=case_dir.name, passed=out["passed"], exit=res.exit, rounds=res.rounds,
                 seconds=seconds, measure_seconds=measure_seconds, looks=looks)
    return out


#: Exits a --skip-done rerun retries: a provider that was down, a crash, and a refusal say nothing about the
#: case. A refusal is here because the usual cause is the kill switch, which is how a run is stopped and then
#: resumed, and because a refusal that stands (a file over the ceiling) costs microseconds to reach again. A
#: case that spent its wall clock is not: rerunning it would spend the same hours again.
RETRYABLE_EXITS = ("model_error", "crashed", "refused")
#: Exits the run reports on its own line, because they are the run's fault rather than the plan's and a summary
#: that only counts failures hides them (docs/eval_protocol.md section 9).
UNATTENDED_EXITS = ("time_exhausted", "refused")


def run_corpus(corpus: Path, heuristic: bool = True, cache_dir: str | None = None, provider: str = "auto",
               record_dir: Path | None = None, replay_dir: Path | None = None, verbose: bool = False,
               only: list[str] | None = None, workers: int = 1, results_dir: Path | None = None,
               skip_done: bool = False, isolated: bool = False, vision: Any = None,
               memory: Any = None) -> dict[str, Any]:
    """Score every case. With workers > 1 the cases run concurrently (model calls are network-bound), results
    are printed as each case finishes, and the summary is still in corpus order. With results_dir each case's
    result is written as it finishes; with skip_done, cases whose stored result is not a retryable exit are
    reused instead of rerun, so a run of hundreds survives interruptions and provider errors. `vision` is the
    vision client handed to every analyze call (None keeps vision off)."""
    from concurrent.futures import ThreadPoolExecutor, as_completed

    cases = sorted(d for d in corpus.iterdir() if d.is_dir() and (d / "expected.json").exists())
    if only:
        cases = [c for c in cases if c.name in only]
    policy = "replay" if replay_dir is not None else "heuristic" if heuristic else "live"
    t0 = time.perf_counter()
    if results_dir is not None:
        results_dir.mkdir(parents=True, exist_ok=True)

    def _stored(d: Path) -> dict[str, Any] | None:
        if results_dir is None or not skip_done:
            return None
        p = results_dir / f"{d.name}.json"
        if not p.exists():
            return None
        try:
            r = json.loads(p.read_text(encoding="utf-8"))
        except ValueError:
            return None
        return None if r.get("exit") in RETRYABLE_EXITS else r

    def _one(d: Path) -> dict[str, Any]:
        stored = _stored(d)
        if stored is not None:
            stored["reused"] = True
            return stored
        try:
            r = score_case(d, heuristic, cache_dir, provider, record_dir, replay_dir, isolated=isolated, vision=vision,
                           memory=memory)
        except LockedKeyChanged:
            raise  # a changed locked key stops the run; it is never a per-case crash
        except Exception as exc:
            # The traceback goes into the result. Three cases of the learning-half run exited "list index out of
            # range" with nothing else recorded, and every one of them passed when rerun alone, so the message on
            # its own could not say where to look: a crash has to carry its own evidence.
            r = {"case": d.name, "passed": False, "checks": [("crashed", False, f"{type(exc).__name__}: {exc}")],
                 "rounds": 0, "tool_calls": 0, "seconds": 0.0, "exit": "crashed", "reason": str(exc),
                 "traceback": traceback.format_exc()}
            try:
                r["stamp"] = result_stamp(policy, provider if policy == "live" else None, None, d, key_sha256(d),
                                          vision is not None, memory=memory_mode(memory), vision=vision)
            except Exception:
                r["stamp"] = None
        if results_dir is not None:
            (results_dir / f"{d.name}.json").write_text(json.dumps(r, indent=1, default=str), encoding="utf-8")
        return r

    by_name: dict[str, dict[str, Any]] = {}
    if workers <= 1 or len(cases) <= 1:
        for d in cases:
            by_name[d.name] = _one(d)
            if verbose:
                print(_format_case(by_name[d.name], verbose=True), flush=True)
    else:
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {pool.submit(_one, d): d for d in cases}
            for fut in as_completed(futures):
                r = fut.result()
                by_name[r["case"]] = r
                if verbose:
                    print(_format_case(r, verbose=True), flush=True)
    results = [by_name[d.name] for d in cases]
    failed = sum(1 for r in results if not r["passed"] and not r.get("skipped"))
    lines = [] if verbose else [_format_case(r, verbose=False) for r in results]
    scored = [r for r in results if not r.get("skipped") and r.get("rounds")]
    if scored:
        rounds = [r["rounds"] for r in scored]
        lines.append(f"\nrounds: mean {sum(rounds) / len(rounds):.1f}, p90 {_p90(rounds)}, max {max(rounds)}; "
                     f"seconds/case: mean {sum(r['seconds'] for r in scored) / len(scored):.0f}, max {max(r['seconds'] for r in scored):.0f}; "
                     f"rejections total {sum(r.get('grounding_rejections', 0) for r in scored)}; "
                     f"prose guard hits {sum(r.get('prose_guard_hits', 0) for r in scored)}; "
                     f"wall {time.perf_counter() - t0:.0f}s with {workers} worker(s)")
    n_skipped = sum(1 for r in results if r.get("skipped"))
    for exit_ in UNATTENDED_EXITS:
        hit = [r["case"] for r in results if r.get("exit") == exit_]
        if hit:
            what = "spent the wall-clock budget" if exit_ == "time_exhausted" else "refused before the model ran"
            lines.append(f"\n{len(hit)} case(s) {what} ({exit_}): {', '.join(hit[:12])}"
                         + (f" and {len(hit) - 12} more" if len(hit) > 12 else ""))
    lines.append(f"\n{len(results) - failed - n_skipped}/{len(results)} cases passed" + (f", {n_skipped} skipped" if n_skipped else ""))
    return {"cases": results, "failed": failed, "skipped": n_skipped, "total": len(results),
            "unattended": {e: [r["case"] for r in results if r.get("exit") == e] for e in UNATTENDED_EXITS},
            "text": "\n".join(lines)}


def _p90(values: list) -> Any:
    """Nearest-rank 90th percentile of the rounds a corpus took: the loop's round budget statistic (dev plan P4.1)."""
    if not values:
        return None
    s = sorted(values)
    return s[max(0, -(-9 * len(s) // 10) - 1)]


def _format_case(r: dict[str, Any], verbose: bool) -> str:
    head = f"{'PASS' if r['passed'] else 'FAIL'} {r['case']}  ({sum(c[1] for c in r['checks'])}/{len(r['checks'])} checks)"
    if r.get("rounds"):
        head += f"  {r['rounds']} rounds, {r['tool_calls']} calls, {r.get('grounding_rejections', 0)} rejections, {r.get('seconds', 0):.0f}s"
    if not r.get("judgment") and not r.get("skipped"):
        head += f"  [{r.get('exit')}: {str(r.get('reason', ''))[:160]}]"
    lines = [head]
    for name, ok, detail in r["checks"]:
        if not ok or (verbose and "needs model" in name):
            lines.append(f"       x {name}: {detail}")
    if verbose and r.get("rejections"):
        for k, errs in enumerate(r["rejections"], start=1):
            for e in errs[:6]:
                lines.append(f"       rejected #{k}: {e[:200]}")
    if verbose and r.get("truncated_turns"):
        lines.append(f"       truncated : {r['truncated_turns']} turn(s) hit the output limit")
    if verbose and r.get("judgment"):
        j = r["judgment"]
        lines.append(f"       object   : {j['object']}")
        lines.append(f"       roles    : {j['roles']}")
        lines.append(f"       flow     : {j['flow']}")
        if j["brief_conflicts"]:
            lines.append(f"       conflicts: {j['brief_conflicts']}")
        if j["agent_risks"]:
            lines.append(f"       agent    : {j['agent_risks']}")
        for q in j["questions"]:
            lines.append(f"       q        : {q}")
        lines.append(f"       user     : {j['for_user']}")
        lines.append(f"       unit     : {j.get('unit')}; regions {j.get('regions')}; refined {j.get('refined_cells')}")
        if j.get("assumptions"):
            lines.append(f"       assumes  : {j['assumptions']}")
        lines.append(f"       without  : {j['without_this']}")
        lines.append(f"       analysis : {j['analysis'][:600]}")
    return "\n".join(lines)
