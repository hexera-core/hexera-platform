"""HANDOFF 3: intake and the geometry agent, together, to the builder.

WHERE IT RIDES, and this is the whole reason the block exists. `engines/snappy/planner.py:186` cuts
`request_txt[:2000]` and serialises the measured-geometry dict AFTER the cut. Prose in front of the cut is
subject to it; a dict key is not. So the Surveyor's information rides in the TYPED BLOCK, inside
`metrics["geometry_agent"]`, and cannot be truncated away.

WHAT THE PAIR HANDS OVER:

  the geometry agent's write-up   what to do and where to spend the cells. `hexera.builder_plan_block` already
                                  renders it into the prose in front of the cut.
  intake's write-up               what the customer settled, which is the only source of a role or an intent.
  the Surveyor's information      measurements and places, riding WITH the geometry agent's write-up, in the
                                  typed block after the cut.

THE CONTRACT ANOTHER AGENT HAS TO SATISFY. A separate agent is wiring the look into `metrics["geometry_agent"]`
in `ge_deliver` right now. This file does not do that work and does not duplicate it. It states what that work
must satisfy and ships the validator: `check_survey_block` takes whatever lands at `planner_block["survey"]`
and refuses anything that breaks the four rules below. Their implementation passing this function is what
"done" means; nothing else here needs to change for their block to arrive.

  RULE 1, EVERY VALUE SAYS WHAT KIND IT IS. Each leaf of the block is a mark: `{"kind": ..., "value": ...}`.
    A consumer reading two lines of it already knows whether a claim was computed, seen or confirmed.
  RULE 2, NO DIGIT FROM THE LOOK. A `seen` mark carrying a number means the scrub failed upstream, and the
    scrub is the reason the look may be shown to a builder at all. Refused, not stripped.
  RULE 3, NO RECORDED-TIER FIELD. Read from `vision.trust`: defects, notes, orientation, symmetry, an opening's
    class or the role the look guessed. Those are kept for a person and reach no model.
  RULE 4, THE BLOCK IS SMALL. It rides in a prompt beside everything else the planner reads. `SURVEY_BLOCK_MAX`
    is the ceiling and a block over it is refused rather than silently cut, because a block that can be cut is
    a block that can lose the one thing it was carrying.

WHAT IS FORBIDDEN HERE AND NOWHERE ELSE: a role that is not confirmed. The builder binds patches from what it
is handed, so a guessed role in this block is a guessed boundary condition on a real job.
"""
from __future__ import annotations

import json
from typing import Any

from geometry_agent.contract import marks as mk
from geometry_agent.contract.given import Given
from geometry_agent.contract.marks import ContractError

SURVEY_BLOCK_SCHEMA = "geometry_agent.contract.survey_block.v1"

#: The block rides in a prompt. Over this it is refused, never cut: a block that can be cut is a block that can
#: lose the one thing it was carrying, which is the failure this whole handoff exists to end.
SURVEY_BLOCK_MAX = 4000

#: What the block MUST carry. A missing one is a loud failure at the boundary.
SURVEY_BLOCK_REQUIRED: tuple[str, ...] = ("schema", "source_sha256", "representation", "unit", "kinds",
                                          "confirmed", "unsettled")

#: At most this many confirmed roles and seen findings in the block. Ordered so the cut takes the least
#: important, and the limit is on the LIST rather than on the characters, so nothing is ever half a sentence.
SURVEY_BLOCK_ITEMS = 12


def survey_block(given: Given) -> dict[str, Any]:
    """The Surveyor's information, as it rides with the geometry agent's write-up in the typed block.

    Every value carries its kind. A builder reading `{"kind": "confirmed", "value": "inlet"}` knows a person
    said so; reading `{"kind": "seen", "tier": "relied_on", "value": ["a flange at one end"]}` it knows a model
    said so from pictures and what that is worth. There is no third state where it cannot tell.
    """
    survey = given.survey
    # ONE ENTRY PER ANSWER GIVEN, with the mouths it placed beside it. The first version wrote one mark per mouth,
    # each repeating who answered and when, and on an eight-mouth manifold (`mini_housing_014`) the repetition
    # alone took the block over its ceiling. Who and when stay in every mark's `source`, because a confirmation
    # that loses them is an assumption; what is not repeated is the same sentence eight times.
    confirmed: dict[str, Any] = {}
    answers = ([*given.intake.answers] if given.intake is not None else []) + \
        ([*given.late.answers] if given.late is not None else [])
    for answer in answers:
        mark = mk.as_json(answer.as_mark(), compact=True)
        if not answer.subject:
            confirmed[answer.about] = mark
            continue
        key = f"{answer.about}={answer.value}"
        row = confirmed.get(key)
        if row is None or row.get("source") != mark["source"]:
            key = key if row is None else f"{key}@{answer.question_id}"
            row = confirmed.setdefault(key, {**mark, "applies_to": []})
        row["applies_to"].append(answer.subject)
    confirmed = dict(list(confirmed.items())[:SURVEY_BLOCK_ITEMS])
    seen: dict[str, Any] = {}
    for name in ("attachments", "inside_is_plain", "identity.name"):
        m = survey.mark(name)
        if m is not None and m.kind == mk.SEEN:
            seen[name] = mk.as_json(m, compact=True)
    # one entry per WORD, with the ids on it, not one entry per opening: same reason as `unsettled` below
    standoffs: dict[str, dict[str, Any]] = {}
    for op in survey.openings:
        standoff = op.mark("opening.mouth_standoff")
        if standoff is not None and standoff.kind == mk.SEEN:
            # THE WORD IS THE SEEN VALUE AND THE IDS ARE NOT. An opening id carries a digit, and the ids came
            # off the LABELS the renderer drew from the measurement, not out of the model. Putting them in
            # `value` made this block fail its own no-digit rule, which was the rule working: they travel
            # beside the claim as measured provenance instead.
            row = standoffs.setdefault(str(standoff.value),
                                       {"kind": standoff.kind, "value": str(standoff.value),
                                        "field": standoff.field, "source": "look.openings_seen[].mouth",
                                        "tier": standoff.tier, "applies_to": []})
            row["applies_to"].append(op.id)
    for word, row in list(standoffs.items())[:SURVEY_BLOCK_ITEMS]:
        seen[f"opening.mouth_standoff.{word}"] = row
    measured: dict[str, Any] = {}
    # NOT `thickness.min_m` (the platform fixer's NEEDS 9): the typed block's survey (`hexera.SURVEY_MEASURED`)
    # leaves it out, and two surveys of one part must not disagree about what was measured. The thin places ride
    # in `places`, located, which is what a builder acts on
    for name in ("bbox_diagonal_m", "inlet_bore_m", "forecast.cells_high", "cell_budget"):
        m = given.fact(name)
        if m is not None:
            measured[name] = mk.as_json(m, compact=True)
    # GROUPED BY REASON, not one row per opening. Four mouths nobody has assigned a role to is ONE thing the
    # builder needs to know, said once with the four ids on it; four copies of the same sentence is the block
    # spending its ceiling on repetition and then losing a finding to the cap.
    # EVERYTHING nobody confirmed, asked and skipped AND never asked. `unanswered()` is only the first, and a
    # question held below the budget reached the builder as nothing at all through it (`Given.unsettled`).
    open_ids = set(given.unsettled()) if given.intake is not None else set(given.unanswered())
    grouped: dict[tuple[str, str], list[str]] = {}
    for u in survey.uncertainties:
        if u.id not in open_ids:
            continue
        grouped.setdefault((u.about, u.why), []).extend(u.subjects or [u.subject or u.id])
    unsettled = [{"about": about, "subjects": subjects, "why": why}
                 for (about, why), subjects in list(grouped.items())[:SURVEY_BLOCK_ITEMS]]
    block = {
        "schema": SURVEY_BLOCK_SCHEMA,
        "source_sha256": survey.source_sha256,
        "facts_sha256": survey.facts_sha256,
        "representation": mk.as_json(given.must("representation"), compact=True),
        #: Absent when nobody has stated one, which is an STL and is common. `value: null` with `kind:
        #: assumed` beside an `unsettled` row saying so is the honest form; a unit invented to fill the key is
        #: the error this package exists to avoid.
        "unit": (mk.as_json(given.fact("unit"), compact=True) if given.fact("unit") is not None
                 else {"kind": mk.ASSUMED, "value": None, "field": "unit",
                       "source": "nobody has stated a unit for this file; see unsettled"}),
        #: The legend, in the block. A consumer never has to have read a document to know what a kind means.
        "kinds": dict(mk.KIND_SHORT),
        "measured": measured,
        "confirmed": confirmed,
        "seen": seen,
        #: What nobody settled, named. A builder that knows a role is unsettled can refuse to bind a patch; a
        #: builder handed silence binds whatever it guesses.
        "unsettled": unsettled,
        "looked": survey.looked,
    }
    check_survey_block(block)
    return block


def check_survey_block(block: Any) -> None:
    """The validator another agent's block has to pass. Raises on the first violation.

    This is the contract in executable form. It is deliberately a free function over a plain dict so it can be
    run against a block built anywhere, by anyone, without importing the builder of it.
    """
    if not isinstance(block, dict):
        raise ContractError("survey_block", "the block must be a dict; the planner reads it as a dict key and "
                                            "a list or a string arrives as prose that the cut can reach")
    missing = [k for k in SURVEY_BLOCK_REQUIRED if k not in block]
    if missing:
        raise ContractError("survey_block", f"required keys absent: {missing}")
    mk.check_no_forbidden(block, "survey_block")
    _walk_marks(block, "survey_block")
    size = len(json.dumps(block, default=str))
    if size > SURVEY_BLOCK_MAX:
        raise ContractError("survey_block", f"{size} characters against a ceiling of {SURVEY_BLOCK_MAX}; a "
                                            f"block that can be cut is a block that can lose the one thing it "
                                            f"was carrying, so this is refused rather than truncated")
    for key, value in (block.get("confirmed") or {}).items():
        if isinstance(value, dict) and value.get("kind") not in (mk.CONFIRMED, mk.ASSUMED):
            raise ContractError("survey_block", f"{key!r} sits under `confirmed` and its kind is "
                                                f"{value.get('kind')!r}", field=key)
    for key, value in (block.get("seen") or {}).items():
        if not isinstance(value, dict):
            continue
        if value.get("kind") != mk.SEEN:
            raise ContractError("survey_block", f"{key!r} sits under `seen` and its kind is "
                                                f"{value.get('kind')!r}", field=key)
        if not value.get("tier"):
            raise ContractError("survey_block", f"{key!r} is a seen claim with no trust tier; a consumer "
                                                f"cannot tell what it is worth", field=key)


def _walk_marks(node: Any, where: str, path: str = "") -> None:
    """Every dict that looks like a mark must be a valid one, and no seen mark may carry a digit."""
    if isinstance(node, dict):
        if "kind" in node and "value" in node:
            kind = node.get("kind")
            if kind not in mk.KINDS:
                raise ContractError(where, f"kind {kind!r} is not one of {mk.KINDS}", field=path)
            if kind == mk.SEEN and _digit_in(node.get("value")):
                raise ContractError(where, "a seen claim carries a number; every digit is scrubbed before the "
                                           "model sees a picture, so this means the scrub failed upstream",
                                    field=path)
        for k, v in node.items():
            if k in ("kinds", "why", "read_as"):
                continue
            _walk_marks(v, where, f"{path}.{k}".lstrip("."))
    elif isinstance(node, (list, tuple)):
        for i, v in enumerate(node):
            _walk_marks(v, where, f"{path}[{i}]")


def _digit_in(value: Any) -> bool:
    if isinstance(value, bool):
        return False
    if isinstance(value, (int, float)):
        return True
    if isinstance(value, str):
        return mk.carries_number(value)
    if isinstance(value, dict):
        return any(_digit_in(v) for v in value.values())
    if isinstance(value, (list, tuple)):
        return any(_digit_in(v) for v in value)
    return False


# ---------------------------------------------------------------------------------------------------------
# the whole handoff to the builder: both write-ups, the Surveyor's information inside the geometry agent's
# ---------------------------------------------------------------------------------------------------------

BUILDER_HANDOFF_SCHEMA = "geometry_agent.contract.builder_handoff.v1"

#: The keys the platform's planner keeps out of `metrics["geometry_agent"]`, read on `feat/geometry-agent-pipeline`
#: at `bae0fb2`, `engines/snappy/planner.py:121`, applied at `:189` (synthesis C16). Pinned here as data, read and
#: not assumed, so the handoff can say which of its keys the platform would drop today. The platform tree is not
#: edited from here; adding `survey`, `intake` and `plan_envelope` there is on the NEEDS list.
PLATFORM_BLOCK_KEYS_BAE0FB2: tuple[str, ...] = (
    "status", "missing", "missing_because", "representation", "agent_forecast_cells", "agent_forecast_low",
    "agent_forecast_basis", "forecast_calibration", "customer_cell_cap", "inlet_bore_m", "inlet_opening_id",
    "smallest_port_min_dim_m", "places", "source_sha256", "agent_git_sha", "units", "look")

#: What intake's write-up must carry in the typed block. `confirmed` and `assumed` are TWO keys and are never
#: merged: the moment an answer and a default reach the builder as one dict of roles, the builder acts on our
#: guess believing it was confirmed (`chain/handover.py`).
INTAKE_BLOCK_REQUIRED: tuple[str, ...] = ("read_as", "confirmed", "assumed", "from_the_brief", "still_open")


#: The platform's allowlist on `feat/complete-surveyor` (`e81c55a`): the survey, the refusals, the coverage facts and
#: the chain's three keys are read. `platform_drops_today` is measured against THIS, and the bae0fb2 list above is
#: kept as the record of what the platform used to drop.
PLATFORM_BLOCK_KEYS_COMPLETE: tuple[str, ...] = (
    *PLATFORM_BLOCK_KEYS_BAE0FB2, "survey", "places_refused", "coverage", "intake", "flow_patches", "plan_envelope")


def platform_drops(typed: dict[str, Any], allowlist: tuple[str, ...] = PLATFORM_BLOCK_KEYS_COMPLETE) -> list[str]:
    """The keys of a typed block the platform's planner would drop, given its allowlist."""
    return sorted(k for k in typed if k not in allowlist and k != "schema")


#: Who a flow patch's role came from, in the handoff. `decided_by_agent` is the geometry agent choosing the flow
#: patch where nobody spoke (the design of record, step 5), which the builder builds AND reports back on.
FLOW_PATCH_KINDS: tuple[str, ...] = (mk.CONFIRMED, mk.STATED, "decided_by_agent")


def flow_patches(plan_patches: list[dict[str, Any]], given: Given) -> dict[str, dict[str, str]]:
    """The role the builder builds for every mouth the plan cuts as a flow patch, and who that role came from.

    ONE ANSWER PER MOUTH. Intake's write-up says what the customer confirmed, stated or left to a default; the
    plan says which patches it cuts. Where nobody spoke, the plan's choice can differ from intake's default (both
    are guesses between mouths of one bore), and a builder handed both would hold two roles for one mouth. This
    is the one it builds, labelled, with the default beside it when the two differ.
    """
    out: dict[str, dict[str, str]] = {}
    for patch in plan_patches:
        if not isinstance(patch, dict):
            continue
        pid, role = str(patch.get("id") or ""), str(patch.get("role") or patch.get("type") or "")
        if not pid or role in ("", "wall", "opening_unknown"):
            continue
        source = given.role_source(pid)
        row = {"role": role}
        if source is not None and source[0] in (mk.CONFIRMED, mk.STATED) and source[1] == role:
            row["kind"] = source[0]
        else:
            row["kind"] = "decided_by_agent"
            if source is not None and source[0] == mk.ASSUMED:
                row["intake_default"] = source[1]
        out[pid] = row
    return out


#: The facts-only forecast's basis line at the builder, where a plan exists and its envelope rides as `plan_envelope`.
PLANNED_BASIS_NOTE = ("the builder emulator over the measurement alone, computed before the plan: the plan's own "
                      "envelope is plan_envelope")


def builder_handoff(planner_block: dict[str, Any] | None, given: Given, *, geometry_write_up: dict[str, Any],
                    intake_block: dict[str, Any], plan_envelope: dict[str, Any] | None = None,
                    patches: dict[str, dict[str, str]] | None = None) -> dict[str, Any]:
    """Step 7: what the builder receives, validated before it leaves.

    `geometry_write_up` is `hexera.builder_plan_block(...)`, the geometry agent's instruction sized to ride in
    front of the `request_txt[:2000]` cut. EVERYTHING ELSE rides in the typed block after the cut, where it
    cannot be truncated: the measurement and the look (`planner_block`, including its `look`), the Surveyor's
    marks (`survey`), intake's write-up (`intake`), and the envelope the plan costs (`plan_envelope`). The
    Surveyor's information is inside the geometry agent's half, as the design says, because it is the block the
    geometry agent's instruction is read against.
    """
    typed = attach(planner_block, given)
    if typed is None:
        raise ContractError("builder_handoff", "no planner block: a measurement that failed is not dressed up as a "
                                               "thin one; the job stops before the builder")
    typed["intake"] = {k: intake_block.get(k) for k in (*INTAKE_BLOCK_REQUIRED, "write_up") if k in intake_block}
    if plan_envelope is not None:
        typed["plan_envelope"] = dict(plan_envelope)
        # THE FACTS-ONLY ENVELOPE SAYS WHAT IT IS ONCE A PLAN EXISTS (work/z-chain NEEDS 1). `report_measured` writes
        # "no plan exists" into its basis, which is true at upload and false here, beside the plan's own envelope
        typed["agent_forecast_basis"] = [
            (PLANNED_BASIS_NOTE if str(b).startswith("no plan exists") else b)
            for b in (typed.get("agent_forecast_basis") or [])]
    if patches is not None:
        typed["flow_patches"] = dict(patches)
    out = {
        "schema": BUILDER_HANDOFF_SCHEMA,
        "source_sha256": given.survey.source_sha256,
        "brief_sha256": given.survey.brief_sha256,
        "request_prefix": str(geometry_write_up.get("text") or ""),
        "prefix_budget": int(geometry_write_up.get("budget") or 0),
        "typed": typed,
        "platform_drops_today": platform_drops(typed),
    }
    check_builder_handoff(out, given)
    return out


def check_builder_handoff(handoff: Any, given: Given) -> None:
    """The last boundary. Raises on the first thing the builder must not be handed."""
    if not isinstance(handoff, dict) or not isinstance(handoff.get("typed"), dict):
        raise ContractError("builder_handoff", "the handoff is a dict with a typed block")
    typed = handoff["typed"]
    check_survey_block(typed.get("survey"))
    if typed.get("representation") != given.representation:
        raise ContractError("builder_handoff", f"the typed block says {typed.get('representation')!r} and the survey "
                                               f"measured {given.representation!r}: one representation, resolved once",
                            field="representation")
    if typed.get("customer_cell_cap") != given.budget:
        raise ContractError("builder_handoff", f"the builder's cap is {typed.get('customer_cell_cap')!r} and the "
                                               f"resolved budget is {given.budget!r}", field="customer_cell_cap")
    intake = typed.get("intake")
    if not isinstance(intake, dict) or any(k not in intake for k in INTAKE_BLOCK_REQUIRED):
        raise ContractError("builder_handoff", f"intake's write-up must carry {INTAKE_BLOCK_REQUIRED}", field="intake")
    both = sorted(set(intake.get("confirmed") or {}) & set(intake.get("assumed") or {}))
    if both:
        raise ContractError("builder_handoff", f"{both} are under both `confirmed` and `assumed`: an answer and a "
                                               f"default are two things and never one", field="intake")
    mk.check_no_forbidden(typed.get("intake"), "builder_handoff.intake")
    basis = " ".join(str(b) for b in (typed.get("agent_forecast_basis") or []))
    if "refined" in basis.lower():
        raise ContractError("builder_handoff", "the forecast the builder reads names the refinement estimate; the "
                                               "envelope is tools.estimate_builder_cells and nothing else",
                            field="agent_forecast_basis")
    env = typed.get("plan_envelope")
    if isinstance(env, dict) and "estimate_builder_cells" not in str(env.get("source") or ""):
        raise ContractError("builder_handoff", "the plan envelope does not say it is the builder emulator's",
                            field="plan_envelope")
    patches = typed.get("flow_patches")
    if isinstance(patches, dict):
        for oid, row in patches.items():
            if not isinstance(row, dict) or row.get("kind") not in FLOW_PATCH_KINDS:
                raise ContractError("builder_handoff", f"flow patch {oid} does not say who its role came from",
                                    field=f"flow_patches.{oid}")
        for oid in {a.subject for h in (given.intake, given.late) if h is not None for a in h.answers
                    if a.about == "opening.role" and a.answered_by != "default_taken"} | set(given.stated_roles):
            source = given.role_source(oid)
            built = (patches.get(oid) or {}).get("role")
            if source is not None and source[0] in (mk.CONFIRMED, mk.STATED) and source[1] not in ("wall",)                     and built != source[1]:
                raise ContractError("builder_handoff", f"{oid} is {source[1]!r} by the customer ({source[0]}) and "
                                                       f"the builder would build {built!r}", field=f"flow_patches.{oid}")
    prefix, budget = str(handoff.get("request_prefix") or ""), int(handoff.get("prefix_budget") or 0)
    if budget and len(prefix) > budget:
        raise ContractError("builder_handoff", f"the geometry agent's write-up is {len(prefix)} characters against "
                                               f"its budget of {budget}; past it the request cut takes the request",
                            field="request_prefix")


def attach(planner_block: dict[str, Any] | None, given: Given) -> dict[str, Any] | None:
    """Put the survey block into an existing `hexera.planner_block`, after the truncation, under one key.

    Returns the block with `survey` added, or None when there was no planner block: an absent key is what makes
    the platform's fail-open true, and a measurement that failed must never be dressed up as a thin one.
    """
    if not isinstance(planner_block, dict):
        return None
    out = dict(planner_block)
    out["survey"] = survey_block(given)
    return out


__all__ = ["BUILDER_HANDOFF_SCHEMA", "FLOW_PATCH_KINDS", "INTAKE_BLOCK_REQUIRED", "PLANNED_BASIS_NOTE",
           "PLATFORM_BLOCK_KEYS_BAE0FB2", "PLATFORM_BLOCK_KEYS_COMPLETE", "SURVEY_BLOCK_ITEMS",
           "SURVEY_BLOCK_MAX", "SURVEY_BLOCK_REQUIRED", "SURVEY_BLOCK_SCHEMA", "attach", "builder_handoff",
           "check_builder_handoff", "check_survey_block", "flow_patches", "platform_drops", "survey_block"]
