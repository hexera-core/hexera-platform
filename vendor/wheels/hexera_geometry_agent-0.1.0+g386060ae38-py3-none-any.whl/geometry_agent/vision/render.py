"""Eight canonical views of a part for a vision model, rendered once per file and cached by content hash.

One mesh load, openings detected once for the labels, decimation above a face cap so a million-face export
renders in seconds, vtk offscreen shading (matplotlib when vtk is unavailable), the axis triad (red +X,
green +Y, blue +Z) and the opening ids (o1, o2, ...) drawn over the image at their projected positions, a
grey label when the opening is behind the surface in that view. PNGs are capped at `max_px` on the long
edge. No dimension is ever written into an image: the render is for identity and orientation, never for
measurement.

Plus the cutaway, and, behind a switch, the strip: several cuts taken straight across the flow axis and laid out
in order, which is the only view in the set where a bore is a circle, a wall is a ring and a plate across the
passage is a disc with a hole in it. Both cut faces are computed by parity over the triangles (`section_fill`)
rather than from their winding, because winding is not decidable on the two nested shells every wall shell is
made of, and the drawing that trusted it filled the passage and emptied the wall."""
from __future__ import annotations

import json
import os
import shutil
import threading
import time
import warnings
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np

from geometry_agent.facts.load import load_mesh, sha256_of
from geometry_agent.vision.terminus import (
    STOPS,
    STOPS_CAPTION,
    STOPS_LEGEND,
    STOPS_RULE,
    find_stops,
    stops_frame,
)

EIGHT_VIEWS = ["+x", "-x", "+y", "-y", "+z", "-z", "iso", "iso2"]
#: The cutaway. Its camera is not fixed: the plane is chosen from the part's own bounding box (`section_camera`),
#: so the cut runs along the part rather than across it whatever the file's orientation.
SECTION = "section"
#: The strip: several cuts taken straight across the flow axis and laid out in order, so the view says how the
#: passage CHANGES rather than what one slice of it looks like. Always drawn.
STATIONS = "stations"
#: One cut of the strip on its own canvas, at full size: `panel1`, `panel2`, ... in order along the flow.
#: The NUMBER IN THE NAME IS A SLOT, not the cut number: with fewer panels than cuts the slots hold the cuts
#: that depart most (`panel_cuts`), and which those are depends on the part, while the view list has to be the
#: same for every part because the cache and the prompt are keyed on it. The stable id is the strip's own cut
#: number, which is drawn on the panel's title and in the strip's caption, and the letters, which are the same
#: letters on both. All six are always drawn.
PANEL_VIEW = "panel"
#: The default set: the eight shaded views, the cutaway, and the strip of cross-sections. A part is opaque from
#: outside, and every question about a passage, a wall thickness or a shell is a question about what the outside
#: hides.
#:
#: The name used to be NINE_VIEWS and the set used to be nine. The strip made it ten on 2026-09-15 and a
#: constant that names its own length is a constant that starts lying the first time the set changes, which is
#: the same mistake `views` in a benchmark record made. It is `DEFAULT_VIEWS` and `len()` says how many.
#:
#: Read from the environment once, at import, because that is when every caller reads it: `agent.tools`,
#: `eval/vision/bench.py` and `geometry_agent.render` all import the name rather than call a function, and a
#: process that renders and a process that builds the prompt for that render are the same process. A test that
#: wants the other set calls `default_views()`.
#:
#: One consequence, written down because it has now bitten someone three times: this constant is frozen at
#: import while `default_views()` is read per call, so a shell still holding a `GEOMETRY_AGENT_RENDER_*` switch
#: from a bench run makes the two disagree, and a test that compares them fails on a count with nothing wrong
#: in the code under test. Clearing the switches in an autouse fixture does NOT fix that, because a test module
#: is imported during collection, before any fixture runs. `tests/conftest.py` therefore pops the render and
#: prompt switches at its own import, which is before the modules it collects, as well as per test; and
#: `test_the_import_time_view_set_agrees_with_the_call_time_one` asserts the two agree rather than asserting a
#: number, so it keeps working the next time the set changes.
DEFAULT_VIEWS: list[str]
#: Per view: the direction from the part toward the camera, and the screen-up direction.
VIEW_CAMERAS: dict[str, tuple[tuple[float, float, float], tuple[float, float, float]]] = {
    "+x": ((1.0, 0.0, 0.0), (0.0, 0.0, 1.0)),
    "-x": ((-1.0, 0.0, 0.0), (0.0, 0.0, 1.0)),
    "+y": ((0.0, 1.0, 0.0), (0.0, 0.0, 1.0)),
    "-y": ((0.0, -1.0, 0.0), (0.0, 0.0, 1.0)),
    "+z": ((0.0, 0.0, 1.0), (0.0, 1.0, 0.0)),
    "-z": ((0.0, 0.0, -1.0), (0.0, 1.0, 0.0)),
    "iso": ((0.612, 0.612, 0.5), (0.0, 0.0, 1.0)),
    "iso2": ((-0.612, -0.612, 0.5), (0.0, 0.0, 1.0)),
}
#: Bumped whenever the drawing changes, so stale cache entries re-render instead of misleading the model.
#: 2: the cutaway, and the frame taken from the silhouette rather than the bounding box.
#: 3: the cutaway turns on a plate, so a wing is cut across its chord and not along its span.
#: 4: the capped cutaway (`section_mode` "capped"): the inside of a surface is drawn in its own colour
#:    (`INSIDE_COLOUR`) and the face the plane cut in a third (`CUT_COLOUR`), so a cutaway separates the wall
#:    you are looking through from the body behind it. Off by default and unscored: see `section_mode`.
#: 5: the capped cut face is computed by parity (`section_fill`) instead of by vtk's winding-based clip, which
#:    drew a wall shell inside out; a label whose opening is in the half that was cut away is drawn as hidden
#:    rather than as a confident caption over blank paper; and `stations` exists. The version has to move even
#:    though the switch names did not, because a version 4 manifest that says `section: capped` was written by
#:    the old drawing and says `capped` just the same.
#: 6: the strip's cuts are chosen where the cross-section changes (`choose_stations`) instead of evenly along
#:    the axis. A version 5 manifest that says `stations: true` was written by the even rule and cannot say so.
#: Two switches arrived after version 4 (`paint_mode`, `cut_rule`) and the version did not move for either,
#: which is the opposite of the decision `section_mode` needed and for a reason worth writing down: a version 4
#: manifest with no `paint` key was written by code that had no painting in it, so the key's absence proves the
#: setting, where a version 4 manifest with no `section` key had been written by capped-only code and proved
#: nothing. A cache entry is re-rendered when it cannot say what it is, not when it can.
RENDER_VERSION = 7
CACHE_ENV = "GEOMETRY_AGENT_RENDER_CACHE"
DEFAULT_CACHE = ".render_cache"
MANIFEST = "manifest.json"
#: The cutaway is drawn ONE WAY: the near half cut away and the cut face left empty. The capped cut, which
#: filled the face in and coloured three kinds of surface apart, was read against the benchmark twice and
#: lost both times (49 against 55 on identity and 40 against 48 on what the brief says is inside over 92
#: screened cases, and 46 and 34 in the parity rewrite that fixed the drawing's real errors). Deleted here
#: with `GEOMETRY_AGENT_RENDER_SECTION`, the `capped` prompt variant and the guard that paired them; the
#: tag `surveyor-v1-precleanup` holds all of it. The same round deleted `GEOMETRY_AGENT_RENDER_PAINT`
#: (painting each labelled opening its own colour: opening recall 528 of 589 with it and 528 of 589
#: without, to the case, and identity 49 against 55) and `GEOMETRY_AGENT_RENDER_CUT` (the cutaway plane
#: fitted through the mouths: the same plane on 74 of 92, and worse where it fired).
#: The strip of cross-sections, the lettered marks on it and the six un-packed panels are all DRAWN, always.
#: Each was a switch and each was decided: `GEOMETRY_AGENT_RENDER_STATIONS` on 2026-09-15 (what the brief says
#: is inside, 48 of 72 to 54, and six brief-named features gained and none lost out of sample at p = 0.031),
#: `GEOMETRY_AGENT_RENDER_MARKS=stations` the same day, and `GEOMETRY_AGENT_RENDER_PANELS=apart` on 2026-09-16
#: (a passage asserted plain where the brief puts something, 23, 21, 22, 20 against a band of 24 to 31, a clean
#: sweep at p = 0.002, for six more images and about $0.28 on a 322-part pass). `panels=close`, one tight view
#: of the smallest nominated place, was measured dead in round two and is deleted with them, as is
#: `GEOMETRY_AGENT_RENDER_PANELS_MAX`, whose whole question was how many panels and whose answer is all six.
#: How many cuts the strip takes. Six at three across (`STATION_COLS`) fills a square view with panels big
#: enough that a dozen tube bores are still a dozen circles. Declared up here rather than beside the rest of
#: the strip's constants because `panels_max` clamps to it and runs at import, while `DEFAULT_VIEWS` is built.
STATION_COUNT = 6
#: Labels beyond this many openings are noise on a 768 px image; the largest openings keep theirs.
MAX_LABELS = 24
AXIS_COLOURS = {"X": (215, 40, 40), "Y": (30, 150, 60), "Z": (40, 80, 220)}
#: The skin, one colour inside and out. With the near half gone the camera sees the inside of the far wall,
#: shaded exactly like an outside surface, so a bore, a nested body and a plain lump come back as one smooth
#: field of the same blue. That is the argument the capped cut was built on: a second colour for a face seen
#: from behind, and a third for the face the plane cut. It is measured and it is negative on this reader, in
#: both the vtk drawing and the parity one that fixed its errors (92-part screen, docs/vision.md), so the
#: cutaway has one colour and `INSIDE_COLOUR` is gone with the mode that was its only reader. The best guess
#: at why it loses: a flat filled face covers the shading that was carrying the tube bores and the baffles,
#: and on the arms that lost them the model still saw them and said so somewhere other than
#: `internal_features`.
SURFACE_COLOUR = (0.76, 0.80, 0.90)
#: The face the cutting plane leaves behind where it passed through material (`section_fill`, `paint_section`),
#: and the fill the strip's panels are drawn in. A third colour
#: rather than a shade of the first two, because the question it answers is a different one: blue is a surface
#: the part has, tan is that surface seen from inside, and green is not a surface of the part at all, it is
#: where the plane went through the solid. It is what separates a wall from a rod from a void.
CUT_COLOUR = (0.45, 0.60, 0.42)
#: One colour per labelled opening, and NO TWO LABELLED OPENINGS SHARE ONE. `label_colour` is its only reader
#: now: the dot at an opening's centre and the leader line to its caption. The opening PAINT that also used it,
#: which filled each mouth's own faces in its colour, is deleted with `GEOMETRY_AGENT_RENDER_PAINT`.
#:
#: It was twelve colours cycled over `MAX_LABELS` (24) openings, so o1 and o13 took the same red, o2 and o14 the
#: same blue, and so on: on a part with more than twelve mouths the one thing a distinct colour exists to say,
#: which mark is which caption's, was said twice for every colour. The first twelve are unchanged, so a part
#: with twelve or fewer labels draws exactly the pixels it drew before. The last twelve were picked by a
#: farthest-point search in CIELAB over the mid-lightness, saturated colours (L 35 to 75, chroma 30 or more),
#: away from all twelve above, the surface, the label yellow, the hidden-label grey, black, white and the
#: violet of a mark. Closest pair over all 24: CIE76 delta E 21.8, entries 5 and 9, both from the original
#: twelve; every added colour is at least 30.6 from everything else. `tests/test_look_hardening.py` pins it.
OPENING_PALETTE = (
    (0.85, 0.18, 0.18), (0.13, 0.47, 0.85), (0.16, 0.62, 0.28), (0.95, 0.55, 0.08),
    (0.58, 0.28, 0.76), (0.08, 0.68, 0.68), (0.90, 0.38, 0.66), (0.45, 0.60, 0.15),
    (0.33, 0.33, 0.85), (0.72, 0.42, 0.20), (0.20, 0.40, 0.36), (0.80, 0.48, 0.42),
    (0.05, 0.80, 0.05), (0.35, 0.05, 0.95), (0.45, 0.25, 0.45), (0.95, 0.05, 0.75),
    (0.60, 0.75, 0.55), (0.75, 0.60, 0.90), (0.35, 0.35, 0.10), (0.05, 0.70, 0.95),
    (0.60, 0.15, 0.25), (0.95, 0.05, 0.40), (0.75, 0.65, 0.35), (0.85, 0.05, 0.95),
)
#: The part fills this fraction of the view; the rest is margin for the triad and the labels.
FILL_FRACTION = 0.72
#: Triad arm length as a fraction of the view height, constant on screen in every view.
TRIAD_FRACTION = 0.14
#: A label whose centroid lies deeper than the z-buffer by this much (normalised depth) is behind the surface.
HIDDEN_DEPTH_EPS = 2e-3
#: Rendered at this multiple of the final size, then downscaled: cheap antialiasing on every backend.
SUPERSAMPLE = 2

_VTK_LOCK = threading.Lock()


@dataclass
class ViewFrame:
    """One shaded view plus everything the overlay needs, in final-image pixel coordinates (origin top-left).

    A label is (id, x, y, hidden)."""
    name: str
    rgb: np.ndarray
    labels: list[tuple[str, float, float, bool]] = field(default_factory=list)
    triad: dict[str, tuple[tuple[float, float], tuple[float, float], bool]] = field(default_factory=dict)
    #: Plain text drawn at a point, in the same pixel coordinates: the strip numbers its panels with these and
    #: nothing else uses them. No dot, no leader, no box: a panel number is not an opening.
    captions: list[tuple[str, float, float]] = field(default_factory=list)
    #: The lettered marks (`station_marks`): (letter, x, y, cut, kind), the first three in the same pixel
    #: coordinates. `cut` is which panel the letter is in and `kind` is which rule nominated it; neither is
    #: drawn and neither is ever said to the model, they are in the manifest so an arm can be read afterwards.
    marks: list[tuple[str, float, float, int, str]] = field(default_factory=list)
    #: Extra words for this view's own title line, for a view whose title cannot be written from its name
    #: alone: which cut a panel is, which letter a close view is on. Drawn by `_compose`, never anything the
    #: nomination knows about what is there.
    note: str = ""
    #: What this view's own legend says about its scale, for the views whose scale is decided per part. The
    #: close view zooms only when the place it is drawn for is small enough to need it, so a fixed sentence
    #: about being drawn closer in would be false on the parts where it did not.
    legend: str = ""
    #: The strip's own working, kept so the un-packed panels and the close view can be drawn in the same frame
    #: and at the same scale without choosing the cuts a second time. Only the strip sets it.
    plan: Any = None


def _view_token(view: str) -> str:
    return view.replace("+", "p").replace("-", "m")


def cache_root(root: str | Path | None = None) -> Path:
    """Where the renders live: the caller's directory, else GEOMETRY_AGENT_RENDER_CACHE, else the default.

    A caller may pass one rather than set the variable. A worker process running two looks at once shares
    one environment and cannot use it to mean two different directories, and a caller that sets and unsets
    it around a call is racing itself; an argument cannot be raced. Ported from work/look-channel, where
    `vision.look.look_at_geometry` is the caller that needs it."""
    return Path(root) if root else Path(os.environ.get(CACHE_ENV) or DEFAULT_CACHE)


def _panel_slot(view: str) -> int | None:
    """Which un-packed panel slot a view name is, counted from one, or None when it is not one."""
    if not view.startswith(PANEL_VIEW):
        return None
    tail = view[len(PANEL_VIEW):]
    return int(tail) if tail.isdigit() and int(tail) >= 1 else None


def default_views(env=None) -> list[str]:
    """The seventeen views: the eight shaded, the cutaway, the stops, the strip, and the strip's six cuts again
    one to an image.

    The panels are last because they are enlargements OF the strip, and a reader handed them before the thing
    they enlarge is being shown the detail before the whole. The stops go before the strip and not after it,
    from when the prompt said "on the last view, violet letters ..." and the letters were on the strip; the
    prompt names the strip by name now (`prompt` explains the letters on "the strip of cuts") so the position
    no longer carries meaning, and the order is left alone because moving it would redraw nothing and rewrite
    every view list on record."""
    return ([*EIGHT_VIEWS, SECTION, STOPS, STATIONS]
            + [f"{PANEL_VIEW}{i + 1}" for i in range(STATION_COUNT)])


DEFAULT_VIEWS = default_views()


def cache_dir_for(path: str | Path, root: str | Path | None = None) -> Path:
    return cache_root(root) / sha256_of(Path(path))


def read_manifest(cache_dir: str | Path) -> dict | None:
    p = Path(cache_dir) / MANIFEST
    if not p.is_file():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def _cache_hit(cache_dir: Path, max_px: int, max_faces: int, views: list[str]) -> list[Path] | None:
    m = read_manifest(cache_dir)
    if not m or m.get("version") != RENDER_VERSION or m.get("max_px") != max_px or m.get("max_faces") != max_faces:
        return None
    # An entry drawn by the capped cutaway, the opening paint or the flow cut cannot say so any more, because
    # the manifest keys that said it are gone with them. `RENDER_VERSION` is 7 for exactly that: every entry
    # written by the code that had those modes in it says 6 and is redrawn. A cache entry is re-rendered when
    # it cannot say what it is, which is the rule this file already had.
    # which RULE drew the stops, for the reason `terminus.STOPS_RULE` gives: the detector can change what it
    # finds without any other key in this manifest moving, and an entry that cannot say what it is is not a hit
    if STOPS in views and int(m.get("stops_rule") or 0) != STOPS_RULE:
        return None
    if [v for v in views if v not in (m.get("views") or [])]:
        return None
    paths = [cache_dir / f"{_view_token(v)}.png" for v in views]
    return paths if all(p.is_file() for p in paths) else None


def render_views(path: str | Path, out_dir: str | Path | None = None, max_px: int = 768, max_faces: int = 150_000,
                 views: list[str] | None = None, labels: list[tuple[str, tuple[float, float, float]]] | None = None,
                 mouths=None, solid: bool | None = None,
                 cache_root_dir: str | Path | None = None) -> list[Path]:
    """The views of `path` as PNGs, from the cache when the file, the size and the face cap match.
    With `out_dir` the PNGs are also copied there as <stem>_<view>.png and those paths are returned. `labels`
    (id, centroid) skips the opening detection: the agent passes the measured openings, which carry the same
    ids, so a 400-body assembly is not measured twice.

    `mouths` is the measured openings as `terminus.Mouth` and `solid` says whether the mesh is the wall or the
    fluid, and only the stops view needs either. The detector turns on which of the measured openings the
    measurement calls a way in or out, and `classification` is set in `facts.measure` and nowhere the renderer
    can reach; `solid` is the representation, which is `catalog.representation`'s answer and not a thing a pile
    of triangles knows. A stops view asked for without them is an error rather than a blank panel, because a
    blank panel is what a caller that forgot would never notice.

    `cache_root_dir` overrides where the cache lives for this call only, which is how a worker owns a
    directory without owning the environment."""
    path = Path(path)
    views = list(views or default_views())
    unknown = [v for v in views if v not in VIEW_CAMERAS and v not in (SECTION, STATIONS, STOPS)
               and not _panel_slot(v)]
    if unknown:
        raise ValueError(f"unknown views {unknown}; known: {[*VIEW_CAMERAS, SECTION, STATIONS, STOPS]} "
                         f"and {PANEL_VIEW}1, {PANEL_VIEW}2, ...")
    if STOPS in views and (mouths is None or solid is None):
        raise ValueError("the stops view needs the measured openings and the representation: "
                         "pass mouths= and solid=")
    cache_dir = cache_dir_for(path, cache_root_dir)
    paths = _cache_hit(cache_dir, max_px, max_faces, views)
    if paths is None:
        paths = _render_into(path, cache_dir, max_px, max_faces, views, labels, mouths, solid)
    if out_dir is not None:
        out = Path(out_dir)
        out.mkdir(parents=True, exist_ok=True)
        copies = []
        for v, p in zip(views, paths):
            dst = out / f"{path.stem}_{_view_token(v)}.png"
            shutil.copyfile(p, dst)
            copies.append(dst)
        return copies
    return paths


def _render_into(path: Path, cache_dir: Path, max_px: int, max_faces: int, views: list[str],
                 labels: list[tuple[str, tuple[float, float, float]]] | None, mouths=None,
                 solid: bool | None = None) -> list[Path]:
    t0 = time.perf_counter()
    mesh = load_mesh(path)
    faces_total = int(len(mesh.faces))
    label_warning = None
    if labels is None:
        openings, label_warning = _openings_for_labels(mesh)
        labels = [(o.id, tuple(float(c) for c in o.centroid)) for o in openings]
    n_openings = len(labels)
    labels = [(str(oid), tuple(float(c) for c in cen)) for oid, cen in labels[:MAX_LABELS]]
    vertices, faces, decimation_warning = decimate(np.asarray(mesh.vertices, dtype=np.float64),
                                                    np.asarray(mesh.faces, dtype=np.int64), max_faces)
    # the strip is numpy over the triangles and wants no GL context, so it is drawn outside the shading pass and
    # a vtk failure cannot take it with it; the order the caller asked for is restored afterwards
    shaded_views = [v for v in views if v not in (STATIONS, STOPS) and not _panel_slot(v)]
    backend = "vtk"
    try:
        frames = _shade_vtk(vertices, faces, shaded_views, max_px, labels)
    except Exception as exc:  # noqa: BLE001 - any failure of the offscreen GL path falls back to matplotlib
        backend = f"matplotlib (vtk failed: {type(exc).__name__}: {str(exc)[:80]})"
        frames = _shade_matplotlib(vertices, faces, shaded_views, max_px, labels)
    marks: list[tuple[str, float, float, int, str]] = []
    #: letter -> the point in the FILE's own coordinates that the letter was drawn at. `station_frame` already
    #: works this out (`StationPlan.places`, via `_place_in_world`) so that a panel can be drawn at the same
    #: spot, and it was then thrown away. It is the only thing that lets a finding at a letter be addressed as
    #: a place downstream, so it is written into the manifest beside the letter it belongs to.
    mark_points: dict[str, list[float]] = {}
    stops: list = []
    # the un-packed panels and the close view are drawn from the strip's own plan, so they are the same cuts at
    # the same scale and nothing is chosen a second time. The strip is therefore worked out whenever a panel is
    # asked for, even by a caller that did not ask for the strip itself: the panels are cuts off it, and one
    # drawn from a plan of its own would be a picture that could drift from the one it claims to enlarge
    panels = [v for v in views if _panel_slot(v)]
    if STATIONS in views or panels:
        points = np.array([c for _, c in labels], dtype=np.float64) if labels else None
        strip = station_frame(vertices, faces, max_px, points)
        marks = list(strip.marks)
        mark_points = {letter: [float(c) for c in point]
                       for letter, point, _cut, _kind, _area in (strip.plan.places if strip.plan else [])}
        if STATIONS in views:
            frames.insert(views.index(STATIONS), strip)
        for view, frame in zip(panels, panel_frames(vertices, faces, max_px, strip.plan, panels)):
            frames.insert(views.index(view), frame)
    if STOPS in views:
        # the detector marches rays on the whole mesh, not the decimated one: a wall a decimation moved is a
        # wall drawn in the wrong place, and the march is a few hundred rays either way
        from geometry_agent.facts.openings import detect_openings_with_faces
        _, stop_faces = detect_openings_with_faces(mesh)
        stops = find_stops(mesh, list(mouths), stop_faces, solid=bool(solid))
        frames.insert(views.index(STOPS), stops_frame(vertices, faces, max_px, stops))
    cache_dir.mkdir(parents=True, exist_ok=True)
    paths = []
    for frame in frames:
        img = _compose(frame, path.name, max_px, overlay=backend == "vtk")
        p = cache_dir / f"{_view_token(frame.name)}.png"
        img.save(p, format="PNG", optimize=True)
        paths.append(p)
    warnings = [w for w in (decimation_warning, label_warning) if w]
    # `RENDER_VERSION` DELIBERATELY DOES NOT MOVE FOR `mark_places[].point` OR `stop_places`. The version
    # exists so a cached entry can say which rule drew the PICTURES, and neither key changes a pixel: both are
    # values the renderer already worked out and then discarded. Bumping it would redraw every cached view in
    # the project to add a field nothing looks at with its eyes. A reader that needs the points and finds a
    # manifest without them gets a row with no coordinate and a reason, which is `vision.place`'s own rule.
    manifest = {
        "version": RENDER_VERSION,
        "stops_rule": STOPS_RULE if STOPS in views else None,
        "panel_views": panels,
        "source": str(path), "sha256": cache_dir.name,
        "views": views,
        "max_px": max_px, "max_faces": max_faces, "faces": faces_total, "rendered_faces": int(len(faces)),
        "decimated": int(len(faces)) < faces_total, "backend": backend, "openings": n_openings,
        "labelled": [oid for oid, _ in labels],
        # `marked` is what the prompt is allowed to name: the letters and nothing else. `mark_places` is for
        # reading an arm afterwards and never reaches a prompt, because `kind` is how the mark was found and a
        # model told that would be told half the answer to the question it is being asked
        "stopped": [s.opening_id for s in stops],
        #: The stops the detector found, with the point it found each at. `stopped` above is the ids alone and
        #: is kept because two readers already index into it by panel order.
        "stop_places": [{"id": s.opening_id, "point": [float(c) for c in s.point]} for s in stops],
        "marked": [letter for letter, _x, _y, _cut, _kind in marks],
        #: `point` is in the FILE's own coordinates, never metres: nothing in the renderer knows the scale, and
        #: `hexera.planner_block` owns the one conversion in this package.
        "mark_places": [{"id": letter, "cut": cut, "kind": kind,
                         **({"point": mark_points[letter]} if letter in mark_points else {})}
                        for letter, _x, _y, cut, kind in marks],
        "warning": "; ".join(warnings) or None,
        "seconds": round(time.perf_counter() - t0, 2),
    }
    # The manifest is what a reader trusts, and it is written last and atomically: a second worker rendering the
    # same file must either see no manifest (and render it itself) or a complete one, never a half-written cache.
    tmp = cache_dir / f"{MANIFEST}.{os.getpid()}.part"
    tmp.write_text(json.dumps(manifest, indent=1), encoding="utf-8")
    os.replace(tmp, cache_dir / MANIFEST)
    return paths


def _openings_for_labels(mesh) -> tuple[list, str | None]:
    """The openings, detected once, so every view labels the same ids the measurements use. A failure here
    costs the labels, never the render."""
    from geometry_agent.facts.openings import detect_openings
    try:
        return detect_openings(mesh), None
    except Exception as exc:  # noqa: BLE001 - labels are optional; the shape still renders
        return [], f"openings not labelled ({type(exc).__name__}: {str(exc)[:80]})"


@dataclass
class OpeningPatch:
    """One labelled opening reduced to what a face can be tested against: a plane, a point on it, a radius and
    the area the measurement says it has. `area` is carried only so `paint_faces` can be checked against it,
    never drawn and never stated."""
    id: str
    point: np.ndarray
    normal: np.ndarray
    radius: float
    area: float


def label_colour(index: int) -> tuple[int, int, int]:
    """The 0-255 colour of the opening with this position in the label list, for the overlay's dot and leader.
    Distinct for every index below `MAX_LABELS`, which is every label the renderer ever draws."""
    rgb = OPENING_PALETTE[int(index) % len(OPENING_PALETTE)]
    return tuple(round(255 * c) for c in rgb)


def decimate(vertices: np.ndarray, faces: np.ndarray, max_faces: int) -> tuple[np.ndarray, np.ndarray, str | None]:
    """Down to `max_faces` triangles when the mesh has more, with vtkDecimatePro (1.4 s for 606k to 150k
    faces; vtkQuadricDecimation took 47 s on the same part, longer than rendering all 606k faces); a uniform
    face sample with a warning (expect holes) when vtk is unavailable or its output is unusable. Under the cap
    the mesh passes through untouched."""
    n = int(len(faces))
    if n <= max_faces or max_faces <= 0:
        return vertices, faces, None
    try:
        v, f = _decimate_pro(vertices, faces, max_faces)
        if 0 < len(f) <= int(1.25 * max_faces):
            return v, f, None
        reason = f"decimation returned {len(f)} faces"
    except Exception as exc:  # noqa: BLE001 - the sample fallback must run whatever vtk raises
        reason = f"{type(exc).__name__}: {str(exc)[:80]}"
    rng = np.random.default_rng(0)
    keep = np.sort(rng.choice(n, size=max_faces, replace=False))
    return vertices, faces[keep], f"decimation failed ({reason}); a uniform sample of {max_faces} of {n} faces is shown, expect holes"


def _as_numpy(array) -> np.ndarray:
    """vtk's converter still assigns .shape, which NumPy 2.5 deprecates; the warning is theirs, not a finding."""
    from vtkmodules.util import numpy_support as ns
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", DeprecationWarning)
        return ns.vtk_to_numpy(array)


def _polydata(vertices: np.ndarray, faces: np.ndarray, colours: np.ndarray | None = None):
    from vtkmodules.util import numpy_support as ns
    from vtkmodules.vtkCommonCore import vtkPoints
    from vtkmodules.vtkCommonDataModel import vtkCellArray, vtkPolyData

    pd = vtkPolyData()
    pts = vtkPoints()
    pts.SetData(ns.numpy_to_vtk(np.ascontiguousarray(vertices, dtype=np.float64), deep=True))
    pd.SetPoints(pts)
    cells = vtkCellArray()
    offsets = np.arange(0, 3 * len(faces) + 1, 3, dtype=np.int64)
    conn = np.ascontiguousarray(faces, dtype=np.int64).ravel()
    cells.SetData(ns.numpy_to_vtkIdTypeArray(offsets, deep=True), ns.numpy_to_vtkIdTypeArray(conn, deep=True))
    pd.SetPolys(cells)
    if colours is not None and len(colours) == len(faces):
        # per-triangle colour, carried as cell data so the shading is still the shading: the mapper takes the
        # colour and the lights still decide how the surface turns away, which is what keeps a painted mouth a
        # surface rather than a flat sticker
        arr = ns.numpy_to_vtk(np.ascontiguousarray(colours, dtype=np.uint8), deep=True)
        arr.SetName("opening")
        pd.GetCellData().SetScalars(arr)
    return pd


def _decimate_pro(vertices: np.ndarray, faces: np.ndarray, max_faces: int) -> tuple[np.ndarray, np.ndarray]:
    from vtkmodules.vtkFiltersCore import vtkDecimatePro

    dec = vtkDecimatePro()
    dec.SetInputData(_polydata(vertices, faces))
    dec.SetTargetReduction(1.0 - max_faces / float(len(faces)))
    dec.PreserveTopologyOff()
    dec.SplittingOn()
    dec.BoundaryVertexDeletionOn()
    dec.Update()
    out = dec.GetOutput()
    v = _as_numpy(out.GetPoints().GetData()).astype(np.float64)
    conn = _as_numpy(out.GetPolys().GetConnectivityArray())
    offsets = _as_numpy(out.GetPolys().GetOffsetsArray())
    sizes = np.diff(offsets)
    tri = np.flatnonzero(sizes == 3)
    starts = offsets[tri]
    f = np.column_stack([conn[starts], conn[starts + 1], conn[starts + 2]]).astype(np.int64)
    return v, f


def _camera_frame(direction: np.ndarray, up: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    d = direction / np.linalg.norm(direction)
    u = up - np.dot(up, d) * d
    u = u / np.linalg.norm(u)
    r = np.cross(u, d)
    return d, u, r


#: Below this ratio of smallest to largest bounding-box extent a part is a plate, and the cut turns (see
#: `section_camera`). A wing whose chord and span are tens of times its thickness is the case that set it: cut
#: along the plate the section is its own planform and says nothing, cut across it the section is the aerofoil.
PLATE_ASPECT = 0.15


#: Two mouths and the part's centre are never exactly in a line, and a plane fitted to three nearly collinear
#: points is decided by the rounding. Below this ratio of the second spread to the first the points are read as
#: a line and the plane is chosen by the bounding box instead, which is the answer that opens the most of a
#: straight duct.
COLLINEAR_RATIO = 0.06


def flow_cut_normal(bounds: np.ndarray, points: np.ndarray | None) -> np.ndarray | None:
    """The normal of the plane through the labelled mouths and the part's centre, or None when they name none.

    The cut that opens a passage is the one that contains it, and what is known about the passage at render
    time is where it reaches the surface: the opening centres, which the agent has already measured and hands
    to the renderer as labels. The plane through those points and the part's centre contains every mouth, so it
    contains the passage between them: an elbow is cut in the plane of its own bend whatever the file's
    orientation, and a wye in the plane of its branch.

    The normal is the least-spread direction of those points, which is the plane that fits them. When the second
    spread is small as well the points are a line (a straight duct: two mouths and a centre between them), and a
    line lies in infinitely many planes; the widest of them is the one whose normal is the shortest bounding-box
    axis, so the rule hands back to the bounding box rather than picking one by the rounding. Fewer than two
    points is not a flow path and is None."""
    if points is None or len(points) < 2:
        return None
    pts = np.asarray(points, dtype=np.float64)
    centre = (np.asarray(bounds[0]) + np.asarray(bounds[1])) / 2.0
    stack = np.vstack([pts, centre[None, :]])
    rel = stack - stack.mean(axis=0)
    try:
        _, s, vt = np.linalg.svd(rel, full_matrices=False)
    except np.linalg.LinAlgError:
        return None
    if s[0] <= 0:
        return None
    if s[1] / s[0] < COLLINEAR_RATIO:
        span = np.asarray(bounds[1]) - np.asarray(bounds[0])
        short = np.zeros(3)
        short[int(np.argmin(span))] = 1.0
        line = vt[0]
        n = short - float(short @ line) * line
        norm = float(np.linalg.norm(n))
        if norm < 1e-9:
            return None
        return n / norm
    n = vt[2]
    norm = float(np.linalg.norm(n))
    return n / norm if norm > 0 else None


def section_camera(bounds: np.ndarray, points: np.ndarray | None = None) -> tuple[tuple[float, float, float], tuple[float, float, float]]:
    """The cutaway's camera: the direction to look from, and which way is up.

    Down the shortest bounding-box axis for anything with volume to it, because that is the cut that opens the
    most of the part: a duct long in X and Y and flat in Z is cut by the Z plane and seen from +Z, and the whole
    bore is in one picture, where cutting across it would show one ring.

    Down the LONGEST axis for a plate (`PLATE_ASPECT`), where the same rule inverts. Cutting a wing along its own
    plane shows the planform the +z view already shows; cutting across the chord shows the section, which is the
    only view in the set where a thin trailing edge is a thin trailing edge rather than a line.

    The plane fitted through the mouths instead was `GEOMETRY_AGENT_RENDER_CUT=flow`, and it is deleted with
    the switch: over 92 screened cases it gives the same plane on 74, a tilt under ten degrees on 12 and a
    materially different plane on 6, and where it does fire it is worse. A flanged elbow carries eight labelled
    openings, most of them flange rings rather than ends, so the plane fitted to that scatter is not the bend
    plane, and `bend_elbow_003` came back a featureless slab where the bounding box draws the textbook section.
    The idea is not refuted, it is untested: it wants parts that are not axis-aligned and a flow path taken from
    the measurement rather than from every ring the opening detector found."""
    span = np.asarray(bounds[1]) - np.asarray(bounds[0])
    longest = float(np.max(span)) or 1.0
    plate = float(np.min(span)) / longest < PLATE_ASPECT
    axis = int(np.argmax(span)) if plate else int(np.argmin(span))
    d = [0.0, 0.0, 0.0]
    d[axis] = 1.0
    up = (0.0, 0.0, 1.0) if axis != 2 else (0.0, 1.0, 0.0)
    return tuple(d), up


def camera_for(view: str, bounds: np.ndarray,
               points: np.ndarray | None = None) -> tuple[tuple[float, float, float], tuple[float, float, float]]:
    """The (direction toward the camera, screen up) of one view. Every view but the cutaway is fixed in the
    part's own axes; the cutaway's is read off the bounding box."""
    if view == SECTION:
        return section_camera(bounds, points)
    return VIEW_CAMERAS[view]


def label_is_cut_away(centroid, centre: np.ndarray, d: np.ndarray) -> bool:
    """Whether a labelled opening sits in the half the cutaway removed.

    Its caption is still drawn, because the prompt tells the model which ids exist and a missing one reads as a
    missing opening. But it is drawn as hidden: there is nothing under it in this view. Before this the caption
    was a confident yellow box over blank paper, and on a cyclone with ten mouths three of them sat out over the
    white margin, which says an opening is there and visible when neither is true."""
    return float((np.asarray(centroid, dtype=np.float64) - np.asarray(centre, dtype=np.float64))
                 @ np.asarray(d, dtype=np.float64)) > 0


def near_half_mask(vertices: np.ndarray, faces: np.ndarray, d: np.ndarray, centre: np.ndarray) -> np.ndarray:
    """Which triangles the open cut keeps: the ones behind the plane. Separate from `clip_near_half` so a
    per-face array drawn alongside the triangles (the opening paint) can be cut by the same mask."""
    if len(faces) == 0:
        return np.zeros(0, dtype=bool)
    centroids = vertices[faces].mean(axis=1)
    keep = (centroids - centre) @ d <= 0.0
    if not keep.any():  # a plane through the centre always keeps some, except on degenerate input
        return np.ones(len(faces), dtype=bool)
    return keep


def clip_near_half(vertices: np.ndarray, faces: np.ndarray, d: np.ndarray,
                   centre: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """The half of the part away from the camera: every triangle whose centroid is in front of the plane
    through `centre` with normal `d` is dropped. The cut is left open on purpose, so the camera sees the
    inside faces the outside hides: a bore, a baffle, a wall's thickness, a second shell nested in the first.
    Capping it would hide exactly what the view is for."""
    if len(faces) == 0:
        return vertices, faces
    return vertices, faces[near_half_mask(vertices, faces, d, centre)]


# ---------------------------------------------------------------------------------------------------------------
# The cross-section, by parity rather than by winding.
#
# `clip_capped` asked vtk for the face the plane left behind, and vtk's `vtkClipClosedSurface` decides which side
# of a surface is material from the triangle winding, which vtk decides with `AutoOrientNormalsOn`.
# On one closed shell that works. On two nested shells it does not, and two nested shells is what a wall shell is:
# a pipe with a bore, a duct with a centre body, a housing with a cavity. Drawn that way an annular duct came back
# as a solid green slab with the WALL drawn as the void and the PASSAGE drawn as the material, which is not a
# weaker picture than the open cut, it is a false one, and on some parts the same filter kept the near half
# instead of the far one so the cut face ended up behind the surface and showed only as a rim.
#
# Parity needs no winding. A point on the plane is inside the solid when a ray from it crosses the surface an odd
# number of times, and the plane's intersection with a watertight mesh is a set of closed loops, so a scanline
# across the plane enters and leaves material in pairs whatever order the triangles were written in. A cavity is
# a loop inside a loop and comes out empty, which is the whole of what the old drawing got wrong.
# ---------------------------------------------------------------------------------------------------------------

def plane_segments(vertices: np.ndarray, faces: np.ndarray, point: np.ndarray, normal: np.ndarray) -> np.ndarray:
    """Where a plane crosses the triangles of a mesh, as an (n, 2, 3) array of segment endpoints.

    A triangle is crossed when its vertices do not all lie on one side. The vertex on its own is found, and the
    plane meets the two edges that leave it. A vertex exactly on the plane is pushed to the positive side by a
    hair, which costs nothing and keeps a triangle that only touches the plane from being counted as crossed."""
    v = np.asarray(vertices, dtype=np.float64)
    f = np.asarray(faces, dtype=np.int64)
    if not len(f):
        return np.zeros((0, 2, 3), dtype=np.float64)
    n = np.asarray(normal, dtype=np.float64)
    ln = float(np.linalg.norm(n))
    if ln <= 0:
        return np.zeros((0, 2, 3), dtype=np.float64)
    n = n / ln
    s = (v - np.asarray(point, dtype=np.float64)) @ n
    scale = float(np.max(np.abs(s))) or 1.0
    s = np.where(np.abs(s) < 1e-12 * scale, 1e-12 * scale, s)
    tri = s[f]
    pos = tri > 0
    hits = np.flatnonzero((pos.sum(axis=1) == 1) | (pos.sum(axis=1) == 2))
    if not len(hits):
        return np.zeros((0, 2, 3), dtype=np.float64)
    idx, ss, pp = f[hits], tri[hits], pos[hits]
    rows = np.arange(len(hits))
    # the odd vertex out: the single negative one when two or three are positive, else the single positive one
    odd = np.where(pp.sum(axis=1) >= 2, np.argmin(pp, axis=1), np.argmax(pp, axis=1))
    i0, s0 = idx[rows, odd], ss[rows, odd]
    ends = []
    for step in (1, 2):
        k = (odd + step) % 3
        i1, s1 = idx[rows, k], ss[rows, k]
        t = (s0 / (s0 - s1))[:, None]
        ends.append(v[i0] + (v[i1] - v[i0]) * t)
    return np.stack(ends, axis=1)


def fill_even_odd(seg_xy: np.ndarray, width: int, height: int) -> np.ndarray:
    """The region enclosed by a soup of 2D segments, as a boolean image, by scanline parity.

    One pass, no sorting and no polygon assembly: every segment writes a +1 at the pixel where it crosses a
    scanline, and the running total along the row is odd exactly inside. Segment order does not matter and
    neither does direction, which is the point. A horizontal segment crosses no scanline centre and is skipped,
    which is correct: it is a tangent, not a boundary the row passes through."""
    mask = np.zeros((int(height), int(width)), dtype=bool)
    seg = np.asarray(seg_xy, dtype=np.float64)
    if not len(seg) or width <= 0 or height <= 0:
        return mask
    x0, y0, x1, y1 = seg[:, 0, 0], seg[:, 0, 1], seg[:, 1, 0], seg[:, 1, 1]
    lo = np.ceil(np.minimum(y0, y1) - 0.5)
    hi = np.ceil(np.maximum(y0, y1) - 0.5)
    lo = np.clip(lo, 0, height).astype(np.int64)
    hi = np.clip(hi, 0, height).astype(np.int64)
    counts = np.maximum(hi - lo, 0)
    keep = counts > 0
    if not keep.any():
        return mask
    counts, lo = counts[keep], lo[keep]
    x0, y0, x1, y1 = x0[keep], y0[keep], x1[keep], y1[keep]
    which = np.repeat(np.arange(len(counts)), counts)
    starts = np.repeat(np.cumsum(counts) - counts, counts)
    j = lo[which] + (np.arange(int(counts.sum())) - starts)
    t = ((j + 0.5) - y0[which]) / (y1[which] - y0[which])
    x = x0[which] + (x1[which] - x0[which]) * t
    i = np.clip(np.ceil(x - 0.5), 0, width).astype(np.int64)
    acc = np.zeros((int(height), int(width) + 1), dtype=np.int32)
    np.add.at(acc, (j, i), 1)
    return (np.cumsum(acc, axis=1)[:, :width] & 1).astype(bool)


def section_fill(vertices: np.ndarray, faces: np.ndarray, point: np.ndarray, normal: np.ndarray,
                 to_pixel_a: np.ndarray, to_pixel_b: np.ndarray, width: int, height: int) -> np.ndarray:
    """The material the cutting plane passed through, as a boolean image in the view's own pixels.

    `to_pixel_a` (2 x 3) and `to_pixel_b` (2) are the affine that takes a world point to this view's image
    coordinates, with y counted down from the top. Read off the renderer's own camera rather than rebuilt here,
    so the fill lands exactly on the geometry it belongs to."""
    seg = plane_segments(vertices, faces, point, normal)
    if not len(seg):
        return np.zeros((int(height), int(width)), dtype=bool)
    xy = seg.reshape(-1, 3) @ np.asarray(to_pixel_a, dtype=np.float64).T + np.asarray(to_pixel_b, dtype=np.float64)
    return fill_even_odd(xy.reshape(-1, 2, 2), width, height)


def _dilate(mask: np.ndarray) -> np.ndarray:
    out = mask.copy()
    out[1:, :] |= mask[:-1, :]
    out[:-1, :] |= mask[1:, :]
    out[:, 1:] |= mask[:, :-1]
    out[:, :-1] |= mask[:, 1:]
    return out


def paint_section(rgb: np.ndarray, mask: np.ndarray, colour: tuple[float, float, float] = CUT_COLOUR,
                  outline_px: int = 2) -> np.ndarray:
    """The cut face painted flat over a rendered view, with a darker rim drawn OUTSIDE it.

    Flat on purpose: the face is in the plane of the screen and lit head on, and one even colour is what makes a
    cross-section read as a cross-section rather than as another curved surface. The rim is there because a
    cross-section against a pale surface of similar value is a shape with no edge, and an edge is what separates
    a wall of even thickness from a shaded lump.

    Outside rather than inside, and that is not a taste. A rim drawn inward eats the fill, and the fills that
    matter most are the thin ones: on an annular duct eight hundred long and a hundred across, the wall is three
    pixels of a 768 px view, so a three-pixel rim drawn inward turned the wall into rim and the picture said
    there was no wall. A rim drawn outward cannot consume anything, whatever the feature is worth in pixels."""
    if not mask.any():
        return rgb
    fill = np.array([round(255 * c) for c in colour], dtype=np.uint8)
    edge = (fill * 0.55).astype(np.uint8)
    grown = mask
    for _ in range(max(0, int(outline_px))):
        grown = _dilate(grown)
    rgb[grown & ~mask] = edge
    rgb[mask] = fill
    return rgb


# ---------------------------------------------------------------------------------------------------------------
# The strip of stations.
#
# One cutaway is one frozen slice and every question a mesher has about a passage is a question about how it
# changes: it contracts, it opens into a chamber, it splits, a body stands in the middle of it for part of its
# length, it narrows at the exit. Six cuts taken straight across the flow axis and laid out in order say that in
# one picture, and each of them is the view an engineer draws first: a ring is annular, a disc with a hole in it
# has something down the middle, a shell with a scatter of circles in it is a tube bundle, a big disc that
# becomes a small one and back is an orifice plate.
#
# It needs no renderer. A cross-section is `section_fill` with the camera pointing down the axis, which is two
# numpy passes over the triangles, so the strip costs milliseconds and no GL context.
# ---------------------------------------------------------------------------------------------------------------
#: How the strip lays its cuts out. `STATION_COUNT`, how many there are, is declared with the switches at the
#: top of this file instead of here: `panels_max` clamps to it and is read while `DEFAULT_VIEWS` is being built
#: at import, which is long before this line.
STATION_COLS = 3
#: The part fills this fraction of a panel. Tighter than `FILL_FRACTION` because a panel has no triad in it.
STATION_FILL = 0.82
#: How many places along the axis the cross-section is measured before the cuts are chosen (`choose_stations`),
#: and how coarse that measurement is. Forty-one probes at 72 px is a few milliseconds and is only ever used to
#: decide where to cut, never drawn and never stated.
STATION_PROBES = 41
STATION_PROBE_PX = 72
#: Below this fraction of the largest cross-section, a change in area is rounding and not a feature.
STATION_FLAT = 0.02


def flow_axis(bounds: np.ndarray, points: np.ndarray | None = None) -> np.ndarray:
    """The direction the passage runs in: the line through the labelled mouths, or the longest bounding-box axis.

    The mouths are what the part is for, and the line that fits them is the flow path's own direction: a duct
    lying at forty degrees to every bounding-box axis still has its two mouths on that line. A part with fewer
    than two mouths (an external body, a blind housing) names no path, and there the longest box axis is the
    answer, which on a wing is the span and on a car the length."""
    span = np.asarray(bounds[1]) - np.asarray(bounds[0])
    fallback = np.zeros(3)
    fallback[int(np.argmax(span))] = 1.0
    if points is None or len(points) < 2:
        return fallback
    pts = np.asarray(points, dtype=np.float64)
    rel = pts - pts.mean(axis=0)
    try:
        _, s, vt = np.linalg.svd(rel, full_matrices=False)
    except np.linalg.LinAlgError:
        return fallback
    if not len(s) or s[0] <= 0:
        return fallback
    axis = vt[0]
    norm = float(np.linalg.norm(axis))
    return axis / norm if norm > 0 else fallback


def _panel_frame(axis: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Screen right and screen up for a camera looking down `axis`, chosen the same way every other view chooses
    it: world +Z is up unless the axis is nearly +Z itself, and then +Y is."""
    d = np.asarray(axis, dtype=np.float64)
    d = d / (np.linalg.norm(d) or 1.0)
    up = np.array([0.0, 0.0, 1.0]) if abs(float(d[2])) < 0.9 else np.array([0.0, 1.0, 0.0])
    u = up - float(up @ d) * d
    u = u / (np.linalg.norm(u) or 1.0)
    return np.cross(u, d), u


def station_points(vertices: np.ndarray, axis: np.ndarray, count: int = STATION_PROBES) -> list[np.ndarray]:
    """Where along the axis a cut could be taken: `count` evenly spaced stations, each half a step in from the
    end, so the first is just inside the part and not on the end face, where a cut is a ring of nothing."""
    v = np.asarray(vertices, dtype=np.float64)
    t = v @ np.asarray(axis, dtype=np.float64)
    lo, hi = float(t.min()), float(t.max())
    if not np.isfinite(lo) or not np.isfinite(hi) or hi <= lo:
        return []
    return [np.asarray(axis, dtype=np.float64) * (lo + (i + 0.5) * (hi - lo) / count) for i in range(count)]


def choose_stations(profile: np.ndarray, count: int = STATION_COUNT) -> list[int]:
    """Which of the probed stations to draw: the ones that carry the shape of the profile.

    Evenly spaced cuts were the first rule and they are wrong for half the corpus. Six of them along a venturi
    hit the throat only by luck and six along an orifice run miss a plate that is thinner than a step, so the
    strip drew six identical rings and said, in the clearest picture in the set, that the passage is a plain
    tube. Measured: the evenly spaced strip took `venturi_orifice` identity from four in ten to none in ten.

    So the profile of the cross-section is measured first (cheaply, and never shown), and the cuts are the
    stations that a straight line between the chosen ones would get most wrong. That is ordinary curve
    simplification, the Douglas-Peucker rule: it always keeps both ends, and the first thing it adds is the
    largest departure from them, which on a venturi is the throat and on an orifice run is the plate. On a
    profile that does not change there is nothing to depart from, and the rule falls back to even spacing, which
    is the right answer for a part whose story is not in its cross-section.

    It chooses where to look, never what is there. Nothing measured here is drawn or said. That is also why it
    runs on a profile `reconcile.profile.trust` refuses: a cut across an elbow's chord is still a picture worth
    drawing, and what it may not do is say what the passage does, which is `profile.flow_profile`'s refusal."""
    p = np.asarray(profile, dtype=np.float64)
    n = len(p)
    count = max(1, min(int(count), n))
    if n <= count:
        return list(range(n))
    chosen = [0, n - 1][:count]
    scale = float(np.max(p)) or 1.0
    while len(chosen) < count:
        err = np.abs(p - np.interp(np.arange(n), chosen, p[chosen]))
        err[chosen] = -1.0
        j = int(np.argmax(err))
        if err[j] < STATION_FLAT * scale:
            break
        chosen = sorted([*chosen, j])
    if len(chosen) < count:  # a profile that does not change: spread the rest evenly over what is left
        spare = [i for i in np.linspace(0, n - 1, count).round().astype(int).tolist() if i not in chosen]
        chosen = sorted(chosen + spare[:count - len(chosen)])
    return chosen


def station_profile(vertices: np.ndarray, faces: np.ndarray, axis: np.ndarray, r: np.ndarray, u: np.ndarray,
                    centre: np.ndarray, half: float, probes: list[np.ndarray]) -> np.ndarray:
    """How much material each probed station cuts through, at a resolution that is only good enough to compare
    one station with the next. Coarse on purpose: this decides where to cut and nothing else.

    THE NUMBERS ARE `reconcile.profile`'S. This is `profile.material_profile`, imported, so the array the strip
    chooses its cuts from and the array every reader of the profile reads cannot drift apart. What the array
    MEANS (and when it means nothing) is also owned there: `profile.flow_profile` and its refusal."""
    from geometry_agent.reconcile.profile import material_profile
    return material_profile(vertices, faces, axis, r, u, centre, half, probes, STATION_PROBE_PX)


# ---------------------------------------------------------------------------------------------------------------
# The lettered marks.
#
# A cut is already a place the measurement chose: `choose_stations` puts the cuts where the cross-section
# departs most from a straight line between its ends. What the cut does not do is ask anything. These letters
# do: each one is drawn at a place inside a cut, and the prompt that goes with them asks what is at each
# letter, with "cannot tell from these views" offered in the same sentence.
#
# The nomination is topology and area on the cut image and nothing else. Two things in a cut are worth a
# question and both are properties of the parity fill alone:
#
#   a region of empty space the material closes around   -> "void": a bore, an annular gap, a tube, a cavity
#   a piece of material inside such a region              -> "body": a centre body, a rod, a core, an insert
#
# Neither says what the thing is. A plain fluid-domain tube cuts to a filled disc and nominates neither, and
# its cut still gets a letter at the deepest point of its material, so every cut is asked about and a stretch
# with nothing in it is answered rather than skipped. That is the point: a letter is a place, and a place
# cannot be answered with "the passage is plain".
# ---------------------------------------------------------------------------------------------------------------
#: The letters a mark can carry, in the order they are handed out, and the cap on how many are drawn. Eight is
#: one per cut with two spare for a cut that holds more than one place, and it is as many questions as a reply
#: can answer without padding.
MARK_LETTERS = "ABCDEFGH"
MARKS_MAX = len(MARK_LETTERS)
#: A region smaller than this many pixels of a cut is tessellation noise rather than a place. The cut is drawn
#: at SUPERSAMPLE times the final size, so six pixels here is under two of the picture the model reads.
MARK_MIN_PX = 6
#: The violet a mark is drawn in. Not the yellow of an opening label, which the prompt tells the model means an
#: opening id, and not the green of the fill: a reader who confuses the three learns nothing.
MARK_COLOUR = (150, 55, 200)


@dataclass
class MarkRegion:
    """One place a cut nominates. `kind` is how it was found and is never said to the model."""
    kind: str
    area: int
    point: tuple[float, float]


def _deepest(region: np.ndarray) -> tuple[float, float]:
    """The point of a region furthest from its own edge, as (x, y) in the image's pixels.

    The centroid is the obvious choice and it is wrong here: the centroid of a ring is the hole in the middle
    of it, so a mark on an annular gap or on a thin wall would be drawn over the one thing it is pointing at.
    The distance transform's peak is always inside the region, whatever shape it is."""
    from scipy import ndimage
    d = ndimage.distance_transform_edt(region)
    y, x = np.unravel_index(int(np.argmax(d)), d.shape)
    return float(x), float(y)


def enclosed_regions(mask: np.ndarray) -> list[MarkRegion]:
    """The places one cut nominates, from the cut alone.

    `mask` is `section_fill`'s output: true where the plane passed through material. Empty space is labelled
    four-connected and material eight-connected, which is the pairing that stops a diagonal line of material
    from both separating and not separating the space either side of it. A space that reaches the edge of the
    panel is the room around the part; anything else is a void the material closes around. A piece of material
    that touches none of the outside space is standing inside one of those voids.

    Nothing here reads a brief, a family or a file name: it is given a boolean image."""
    from scipy import ndimage
    m = np.asarray(mask, dtype=bool)
    if m.ndim != 2 or m.size == 0 or not m.any():
        return []
    cross = np.array([[0, 1, 0], [1, 1, 1], [0, 1, 0]], dtype=bool)
    box = np.ones((3, 3), dtype=bool)
    vlab, vn = ndimage.label(~m, structure=cross)
    border = np.concatenate([vlab[0, :], vlab[-1, :], vlab[:, 0], vlab[:, -1]])
    outside = {int(v) for v in np.unique(border) if v}
    out: list[MarkRegion] = []
    for i in range(1, vn + 1):
        if i in outside:
            continue
        reg = vlab == i
        area = int(reg.sum())
        if area >= MARK_MIN_PX:
            out.append(MarkRegion("void", area, _deepest(reg)))
    mlab, mn = ndimage.label(m, structure=box)
    # material is standing inside a void only if it reaches neither the room around the part nor the edge of
    # the panel. The second half is not redundant: a cut wider than its panel has no room around it at all, and
    # without it the part itself comes back as a body standing inside itself
    rooted = {int(v) for v in np.unique(np.concatenate(
        [mlab[0, :], mlab[-1, :], mlab[:, 0], mlab[:, -1]])) if v}
    if outside:
        near = ndimage.binary_dilation(np.isin(vlab, sorted(outside)), structure=box)
        rooted |= {int(v) for v in np.unique(mlab[near & m]) if v}
    for i in range(1, mn + 1):
        if i in rooted:
            continue
        reg = mlab == i
        area = int(reg.sum())
        if area >= MARK_MIN_PX:
            out.append(MarkRegion("body", area, _deepest(reg)))
    return sorted(out, key=lambda r: (-r.area, r.point))


def station_marks(regions_by_cut: list[list[MarkRegion]], origins: list[tuple[int, int]],
                  fallbacks: list[tuple[float, float]]) -> list[tuple[str, float, float, int, str]]:
    """Which nominated places get a letter, and which letter.

    Every cut gets one, so a stretch of passage with nothing in it is still asked about; the cut's largest
    nominated place takes it, and a cut that nominates none takes its fallback point, which is the deepest
    point of its own material. What is left over is ranked by area across the whole strip and the spare letters
    go to the largest, which is how a cut holding two things gets two questions. Letters are then handed out in
    order along the flow axis, so A is nearest one end and the last is nearest the other."""
    chosen: list[tuple[int, MarkRegion]] = []
    spare: list[tuple[int, MarkRegion]] = []
    for cut, regions in enumerate(regions_by_cut):
        if regions:
            chosen.append((cut, regions[0]))
            spare += [(cut, r) for r in regions[1:]]
        else:
            x, y = fallbacks[cut]
            chosen.append((cut, MarkRegion("cut", 0, (x, y))))
    spare.sort(key=lambda cr: (-cr[1].area, cr[0], cr[1].point))
    chosen += spare[:max(0, MARKS_MAX - len(chosen))]
    chosen.sort(key=lambda cr: (cr[0], -cr[1].area, cr[1].point))
    out = []
    for i, (cut, region) in enumerate(chosen[:MARKS_MAX]):
        x0, y0 = origins[cut]
        out.append((MARK_LETTERS[i], x0 + region.point[0], y0 + region.point[1], cut + 1, region.kind))
    return out


def station_frame(vertices: np.ndarray, faces: np.ndarray, max_px: int,
                  points: np.ndarray | None = None, count: int = STATION_COUNT) -> ViewFrame:
    """The strip: `count` cross-sections taken across the flow axis and laid out in order on one canvas.

    Every panel is drawn at the same scale and in the same frame, so a passage that narrows is a shape that
    gets smaller and not a shape that was cropped differently. The material is filled; empty is left white,
    which is the same language the cutaway speaks."""
    px = int(max_px) * SUPERSAMPLE
    frame = ViewFrame(name=STATIONS, rgb=np.full((px, px, 3), 255, dtype=np.uint8))
    v = np.asarray(vertices, dtype=np.float64)
    if not len(v) or not len(faces):
        return frame
    bounds = np.array([v.min(axis=0), v.max(axis=0)])
    axis = flow_axis(bounds, points)
    r, u = _panel_frame(axis)
    rows = int(np.ceil(count / STATION_COLS))
    top, bottom = int(0.10 * px), int(0.09 * px)
    pw, ph = px // STATION_COLS, (px - top - bottom) // rows
    centre = bounds.mean(axis=0)
    rel = v - centre
    half = max(float(np.ptp(rel @ r)), float(np.ptp(rel @ u))) / 2.0 / STATION_FILL or 1.0
    # one scale for every panel: the shrink from one station to the next is the signal
    per_px = 2.0 * half / max(min(pw, ph), 1)
    # world -> panel pixels, y counted down: one affine, reused for every station, which is what holds the scale
    a = np.stack([r / per_px, -u / per_px])
    b = np.array([pw / 2.0, ph / 2.0]) - a @ centre
    probes = station_points(v, axis)
    profile = station_profile(v, faces, axis, r, u, centre, half, probes)
    chosen = choose_stations(profile, count)
    picked = [probes[i] for i in chosen]
    regions_by_cut: list[list[MarkRegion]] = []
    origins: list[tuple[int, int]] = []
    fallbacks: list[tuple[float, float]] = []
    for i, point in enumerate(picked):
        col, row = i % STATION_COLS, i // STATION_COLS
        x0, y0 = col * pw, top + row * ph
        mask = section_fill(v, faces, point, axis, a, b, pw, ph)
        panel = frame.rgb[y0:y0 + ph, x0:x0 + pw]
        # a hairline box round each cut. Without it two shapes side by side read as one cut with two things in
        # it, which is exactly the reading a tee produces: its branch leaves the middle of the frame and the
        # next panel's bore arrives at the edge of it
        rule = np.array([214, 214, 214], dtype=np.uint8)
        panel[0, :] = panel[-1, :] = panel[:, 0] = panel[:, -1] = rule
        paint_section(panel, mask)
        # captions are drawn after the downscale, so they are carried in final-image pixels, as labels are
        frame.captions.append((f"cut {i + 1}", (x0 + 8) / SUPERSAMPLE, (y0 + ph - 0.045 * px) / SUPERSAMPLE))
        regions_by_cut.append(enclosed_regions(mask))
        origins.append((x0, y0))
        fallbacks.append(_deepest(mask) if mask.any() else (pw / 2.0, ph / 2.0))
    placed = station_marks(regions_by_cut, origins, fallbacks) if regions_by_cut else []
    if placed:
        frame.marks = [(letter, x / SUPERSAMPLE, y / SUPERSAMPLE, cut, kind)
                       for letter, x, y, cut, kind in placed]
    frame.plan = StationPlan(axis=axis, r=r, u=u, centre=centre, half=half, per_px=per_px,
                             picked=picked, chosen=chosen, profile=profile,
                             places=[_place_in_world(letter, x, y, cut, kind, origins, regions_by_cut,
                                                     centre, r, u, per_px, pw, ph, picked, axis)
                                     for letter, x, y, cut, kind in placed])
    return frame


@dataclass
class StationPlan:
    """What `station_frame` worked out, kept so another view can be drawn in the same frame.

    Every field is the strip's own: the flow axis and the screen frame around it, the part centre, the half
    extent that sets the one shared scale, the world points the cuts were taken at and which probes they came
    from. A panel drawn from this is the same cut, at the same scale, on more pixels; nothing is chosen twice
    and nothing can drift between the strip and the panel that claims to be it."""
    axis: np.ndarray
    r: np.ndarray
    u: np.ndarray
    centre: np.ndarray
    half: float
    per_px: float
    picked: list[np.ndarray]
    chosen: list[int]
    profile: np.ndarray
    #: One per lettered place: (letter, world point, cut number counted from one, kind, area in the strip's
    #: own pixels). `kind` and `area` are how the place was found and never reach a prompt.
    places: list[tuple[str, np.ndarray, int, str, int]] = field(default_factory=list)


def _place_in_world(letter: str, x: float, y: float, cut: int, kind: str, origins: list[tuple[int, int]],
                    regions_by_cut: list[list[MarkRegion]], centre: np.ndarray, r: np.ndarray, u: np.ndarray,
                    per_px: float, pw: int, ph: int, picked: list[np.ndarray],
                    axis: np.ndarray) -> tuple[str, np.ndarray, int, str, int]:
    """One lettered place put back into world coordinates, so a view at another scale can draw it.

    `station_marks` hands back strip pixels, which are the panel's own pixels plus the panel's origin. Taking
    the origin off and inverting the panel affine gives the point in the plane spanned by `r` and `u`; the
    component along the flow axis is not in the picture at all and is taken from the cut the letter is in."""
    x0, y0 = origins[cut - 1]
    w = centre + (x - x0 - pw / 2.0) * per_px * r - (y - y0 - ph / 2.0) * per_px * u
    point = np.asarray(picked[cut - 1], dtype=np.float64)
    w = w - float(w @ axis) * axis + float(point @ axis) * axis
    # which nominated region this letter is on, by the point it was drawn at rather than by its kind: one cut
    # can hold two voids, and taking the first of a kind would give the letter the other one's size
    local = (x - x0, y - y0)
    same = [g for g in regions_by_cut[cut - 1] if g.kind == kind]
    near = min(same, key=lambda g: (g.point[0] - local[0]) ** 2 + (g.point[1] - local[1]) ** 2, default=None)
    return letter, w, cut, kind, int(near.area) if near is not None else 0


# ---------------------------------------------------------------------------------------------------------------
# The un-packed panels.
#
# The strip packs six cuts into one canvas, so a cut reaches the model at about a third of the width of every
# other view. These draw the same cuts again on a canvas each. Nothing here chooses a cut, a place or a scale:
# all of that is `StationPlan`, which the strip already worked out, so a panel is the strip's own answer with
# more pixels on it and cannot drift from the picture it claims to enlarge.
# ---------------------------------------------------------------------------------------------------------------
#: A panel's drawing area, as the fractions of the canvas left above and below it for the title and the legend.
#: The same bands the strip leaves, so a panel and a strip panel have the same margins around the geometry.
PANEL_TOP, PANEL_BOTTOM = 0.10, 0.09


def station_rank(profile: np.ndarray, chosen: list[int]) -> list[int]:
    """The chosen cuts, most informative first, as positions in `chosen`.

    Same measure `choose_stations` picks by and for the same reason: how far the cross-section at a cut is from
    the straight line between the cuts either side of it. A cut that sits on that line says nothing a
    neighbour does not already say; the throat of a venturi and the plate in an orifice run are the two that
    depart most. The first and last cut have no neighbour on one side and no departure to measure, so they
    rank last: they are near the ends, which is where the mouths are and where the other nine views already
    look. Ties break on the cut number, so the order is the same on every run of the same part.

    It ranks places, never features. It is given a coarse area profile and a list of indices."""
    p = np.asarray(profile, dtype=np.float64)
    n = len(chosen)
    if n <= 2 or not len(p):
        return list(range(n))
    scale = float(np.max(p)) or 1.0
    scores = []
    for k, idx in enumerate(chosen):
        if k == 0 or k == n - 1:
            scores.append((0.0, k))
            continue
        lo, hi = chosen[k - 1], chosen[k + 1]
        span = (hi - lo) or 1
        line = p[lo] + (p[hi] - p[lo]) * (idx - lo) / span
        scores.append((abs(float(p[idx]) - line) / scale, k))
    return [k for _s, k in sorted(scores, key=lambda sk: (-sk[0], sk[1]))]


def panel_cuts(plan, count: int) -> list[int]:
    """Which cut numbers `apart` sends, in cut order. `count` of them, most informative first by
    `station_rank`, then sorted back into the order they lie along the flow so the model reads them as a
    sequence. The numbers are the strip's own, so `cut4` is the strip's fourth panel whatever else is sent."""
    if plan is None or not len(plan.picked):
        return list(range(1, count + 1))
    order = station_rank(plan.profile, plan.chosen)[:max(0, count)]
    return sorted(k + 1 for k in order)


def _panel_affine(half: float, at: np.ndarray, r: np.ndarray, u: np.ndarray, pw: int, ph: int):
    """The world to pixel affine for one panel: `half` of world in the shorter side, centred on `at`."""
    per = 2.0 * float(half) / max(min(pw, ph), 1)
    a = np.stack([r / per, -u / per])
    return a, np.array([pw / 2.0, ph / 2.0]) - a @ np.asarray(at, dtype=np.float64), per


def _panel_canvas(max_px: int, name: str) -> tuple[ViewFrame, int, int, int]:
    """A blank panel canvas and its drawing box: the whole width, with the title and legend bands left clear."""
    px = int(max_px) * SUPERSAMPLE
    frame = ViewFrame(name=name, rgb=np.full((px, px, 3), 255, dtype=np.uint8))
    top = int(PANEL_TOP * px)
    ph = px - top - int(PANEL_BOTTOM * px)
    return frame, top, px, ph


def _panel_box(frame: ViewFrame, top: int, pw: int, ph: int, mask: np.ndarray) -> None:
    """The cut painted into the panel, inside the same hairline box the strip draws round every cut."""
    panel = frame.rgb[top:top + ph, 0:pw]
    rule = np.array([214, 214, 214], dtype=np.uint8)
    panel[0, :] = panel[-1, :] = panel[:, 0] = panel[:, -1] = rule
    paint_section(panel, mask)


def cut_frame(vertices: np.ndarray, faces: np.ndarray, max_px: int, plan, cut: int, name: str) -> ViewFrame:
    """One cut of the strip, alone on its own canvas at the same scale the strip drew it at.

    Same plane, same frame, same half extent, and the fill re-computed from the triangles at the new size
    rather than resampled from the strip's pixels, so the drawing is finer and not bigger. A place that was
    two pixels of a strip panel is about five here, which is the whole of the change.

    The letters that belong to this cut are drawn on it, at the places the strip nominated, so the question the
    prompt asks about a letter can be answered from this view instead of from the strip panel."""
    frame, top, pw, ph = _panel_canvas(max_px, name)
    v = np.asarray(vertices, dtype=np.float64)
    if plan is None or not len(v) or not len(faces) or not (1 <= cut <= len(plan.picked)):
        return frame
    point = plan.picked[cut - 1]
    a, b, _per = _panel_affine(plan.half, plan.centre, plan.r, plan.u, pw, ph)
    _panel_box(frame, top, pw, ph, section_fill(v, faces, point, plan.axis, a, b, pw, ph))
    letters = []
    for letter, w, at_cut, kind, _area in plan.places:
        if at_cut != cut:
            continue
        xy = a @ np.asarray(w, dtype=np.float64) + b
        letters.append((letter, float(xy[0]) / SUPERSAMPLE, (float(xy[1]) + top) / SUPERSAMPLE, cut, kind))
    frame.marks = letters
    # the same caption the strip writes in the corner of its own panel for this cut, in the same words, so the
    # two pictures are tied together by something drawn rather than by something asserted in a prompt
    frame.captions.append((f"cut {cut}", 8 / SUPERSAMPLE, (top + ph - 0.045 * pw) / SUPERSAMPLE))
    frame.note = (f"cut {cut} of the {len(plan.picked)} on the strip, alone at full size"
                  + (f"; letters {_and_list([ltr for ltr, *_ in letters])}" if frame.marks else ""))
    frame.legend = "same scale as the strip and as the other cut views"
    return frame


def _and_list(items: list[str]) -> str:
    """One name, two joined by "and", or a comma list ending in "and". Used in a title."""
    if not items:
        return ""
    if len(items) == 1:
        return items[0]
    return ", ".join(items[:-1]) + " and " + items[-1]


def panel_frames(vertices: np.ndarray, faces: np.ndarray, max_px: int, plan, views: list[str]) -> list[ViewFrame]:
    """One un-packed cut per named panel slot, in the order `views` names them."""
    slots = [v for v in views if v.startswith(PANEL_VIEW)]
    cuts = panel_cuts(plan, len(slots))
    return [cut_frame(vertices, faces, max_px, plan, cuts[slots.index(name)], name) for name in views]


def _parallel_scale(vertices: np.ndarray, bounds: np.ndarray, d: np.ndarray, u: np.ndarray, r: np.ndarray) -> float:
    """Half the view height (vtk's parallel scale) that puts the part at FILL_FRACTION of a square view.

    Measured on the part's own projected points, not on its bounding box. The box is the loose fit: the eight
    corners of a cylinder's box project to a rectangle much wider than the cylinder, and on an isometric view
    of a tall part the difference put the part at under half the frame. Reading the silhouette costs one dot
    product over at most `max_faces` vertices and gives every view the same margin."""
    lo, hi = bounds
    c = (lo + hi) / 2
    if len(vertices):
        rel = np.asarray(vertices, dtype=np.float64) - c
    else:
        rel = np.array([[x, y, z] for x in (lo[0], hi[0]) for y in (lo[1], hi[1]) for z in (lo[2], hi[2])]) - c
    w = np.ptp(rel @ r)
    h = np.ptp(rel @ u)
    return max(float(max(w, h)) / 2 / FILL_FRACTION, 1e-9)


def _shade_vtk(vertices: np.ndarray, faces: np.ndarray, views: list[str], max_px: int,
               labels: list[tuple[str, tuple[float, float, float]]]) -> list[ViewFrame]:
    """Offscreen vtk render of every view with the same camera lights, plus the projected label and triad
    positions read back from the renderer, so the overlay lands exactly where the geometry is."""
    import vtkmodules.vtkRenderingOpenGL2  # noqa: F401 - registers the OpenGL backend
    from vtkmodules.vtkCommonCore import vtkFloatArray
    from vtkmodules.vtkFiltersCore import vtkPolyDataNormals
    from vtkmodules.vtkRenderingCore import (
        vtkActor,
        vtkLight,
        vtkPolyDataMapper,
        vtkRenderer,
        vtkRenderWindow,
        vtkWindowToImageFilter,
    )

    px = max_px * SUPERSAMPLE
    scale_back = 1.0 / SUPERSAMPLE
    lo = vertices.min(axis=0)
    hi = vertices.max(axis=0)
    bounds = np.array([lo, hi])
    centre = (lo + hi) / 2
    diag = float(np.linalg.norm(hi - lo)) or 1.0
    frames: list[ViewFrame] = []

    def shaded(v: np.ndarray, f: np.ndarray):
        n = vtkPolyDataNormals()
        n.SetInputData(_polydata(v, f))
        n.SetFeatureAngle(45.0)
        n.SplittingOn()
        # nothing reads the back face with the cut left open, so the filter is left as it is. The branch that
        # turned consistency off belonged to the capped cutaway, which decided the winding on the closed mesh
        # first and could not then let the filter undo it.
        n.AutoOrientNormalsOff()
        n.Update()
        return n

    with _VTK_LOCK:
        normals = shaded(vertices, faces)
        mapper = vtkPolyDataMapper()
        mapper.SetInputData(normals.GetOutput())
        actor = vtkActor()
        actor.SetMapper(mapper)
        prop = actor.GetProperty()
        prop.SetColor(*SURFACE_COLOUR)
        prop.SetAmbient(0.30)
        prop.SetDiffuse(0.70)
        prop.SetSpecular(0.08)
        ren = vtkRenderer()
        ren.SetBackground(1.0, 1.0, 1.0)
        ren.TwoSidedLightingOn()
        ren.SetAutomaticLightCreation(0)
        for pos, intensity in (((1.0, 1.0, 1.0), 0.85), ((-1.0, -0.4, 1.0), 0.45)):
            light = vtkLight()
            light.SetLightTypeToCameraLight()
            light.SetPosition(*pos)
            light.SetFocalPoint(0.0, 0.0, 0.0)
            light.SetIntensity(intensity)
            ren.AddLight(light)
        ren.AddActor(actor)
        rw = vtkRenderWindow()
        rw.SetOffScreenRendering(1)
        rw.SetSize(px, px)
        rw.AddRenderer(ren)
        cam = ren.GetActiveCamera()
        cam.ParallelProjectionOn()
        # the cutaway is shaded from its own geometry; the eight whole views share one pass. vtk reads a
        # filter's output lazily, so the filter has to outlive the render that uses it: `held` is what holds it.
        held = [normals]
        try:
            label_points = np.array([c for _, c in labels], dtype=np.float64) if labels else None
            for view in views:
                cd, cu = camera_for(view, bounds, label_points)
                d, u, r = _camera_frame(np.array(cd), np.array(cu))
                if view == SECTION:
                    keep = near_half_mask(vertices, faces, d, centre)
                    sv, sf = vertices, faces[keep]
                    cut = shaded(sv, sf)
                    held.append(cut)
                    mapper.SetInputData(cut.GetOutput())
                    shown = sv[np.unique(sf)] if len(sf) else sv
                else:
                    mapper.SetInputData(normals.GetOutput())
                    shown = vertices
                scale = _parallel_scale(shown, bounds, d, u, r)
                cam.SetFocalPoint(*centre)
                cam.SetPosition(*(centre + d * diag * 2.0))
                cam.SetViewUp(*u)
                cam.SetParallelScale(scale)
                cam.SetClippingRange(diag * 0.5, diag * 3.5)
                rw.Render()
                w2i = vtkWindowToImageFilter()
                w2i.SetInput(rw)
                w2i.ReadFrontBufferOff()
                w2i.Update()
                img = w2i.GetOutput()
                w, h, _ = img.GetDimensions()
                rgb = _as_numpy(img.GetPointData().GetScalars()).reshape(h, w, -1)[::-1, :, :3].copy()
                zarr = vtkFloatArray()
                rw.GetZbufferData(0, 0, w - 1, h - 1, zarr)
                zbuf = _as_numpy(zarr).reshape(h, w)

                def project(p, _ren=ren):
                    _ren.SetWorldPoint(float(p[0]), float(p[1]), float(p[2]), 1.0)
                    _ren.WorldToDisplay()
                    dx, dy, dz = _ren.GetDisplayPoint()
                    return dx, dy, dz

                frame = ViewFrame(name=view, rgb=rgb)
                for oid, c in labels:
                    dx, dy, dz = project(c)
                    ix, iy = int(round(dx)), int(round(dy))
                    hidden = view == SECTION and label_is_cut_away(c, centre, d)
                    if not hidden and 0 <= ix < w and 0 <= iy < h:
                        hidden = bool(dz > float(zbuf[iy, ix]) + HIDDEN_DEPTH_EPS)
                    frame.labels.append((oid, dx * scale_back, (h - dy) * scale_back, hidden))
                ox, oy, oz = project(centre)
                ren.SetDisplayPoint(0.11 * w, 0.11 * h, oz)
                ren.DisplayToWorld()
                origin = np.array(ren.GetWorldPoint()[:3])
                arm = TRIAD_FRACTION * 2.0 * scale
                o2 = project(origin)
                tips = {}
                for axis, vec in (("X", (1.0, 0.0, 0.0)), ("Y", (0.0, 1.0, 0.0)), ("Z", (0.0, 0.0, 1.0))):
                    tx, ty, tz = project(origin + np.array(vec) * arm)
                    tips[axis] = (tx - o2[0], ty - o2[1], tz < o2[2] - 1e-6)
                # The projection is parallel, so an arm scales linearly on screen: shrink all three together
                # until the longest tip is inside the frame. An arrow whose head fell off the canvas took its
                # letter with it, and orientation is the one field that has nothing else to read.
                shrink = 1.0
                for dx, dy, _ in tips.values():
                    for pos, delta, lo, hi in ((o2[0], dx, 0.03 * w, 0.97 * w), (o2[1], dy, 0.03 * h, 0.97 * h)):
                        if delta > 0 and pos + delta > hi:
                            shrink = min(shrink, (hi - pos) / delta)
                        elif delta < 0 and pos + delta < lo:
                            shrink = min(shrink, (lo - pos) / delta)
                for axis, (dx, dy, toward) in tips.items():
                    frame.triad[axis] = ((o2[0] * scale_back, (h - o2[1]) * scale_back),
                                         ((o2[0] + dx * shrink) * scale_back, (h - o2[1] - dy * shrink) * scale_back),
                                         toward)
                frames.append(frame)
        finally:
            rw.Finalize()
    return frames


@dataclass
class _Label:
    id: str
    centroid: tuple[float, float, float]


def _shade_matplotlib(vertices: np.ndarray, faces: np.ndarray, views: list[str], max_px: int,
                      labels: list[tuple[str, tuple[float, float, float]]]) -> list[ViewFrame]:
    """The matplotlib fallback: the old renderer's figure (it draws the triad and the labels itself) rasterised
    to an array. Slow above a few tens of thousands of faces, which is why vtk is the first choice."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import trimesh

    from geometry_agent.render import DIRECTIONS, _fig

    openings = [_Label(oid, cen) for oid, cen in labels]
    bounds = np.array([vertices.min(axis=0), vertices.max(axis=0)])
    centre = bounds.mean(axis=0)
    frames = []
    for view in views:
        v, f = vertices, faces
        if view == SECTION:
            points = np.array([c for _, c in labels], dtype=np.float64) if labels else None
            d = np.array(section_camera(bounds, points)[0], dtype=np.float64)
            v, f = clip_near_half(vertices, faces, d, centre)
            elev, azim = _elev_azim(d)
        else:
            elev, azim = DIRECTIONS[view]
        mesh = trimesh.Trimesh(vertices=v, faces=f, process=False)
        fig = _fig(mesh, elev, azim, openings=openings, title="")
        fig.set_size_inches(max_px / 100, max_px / 100)
        fig.set_dpi(100)
        fig.canvas.draw()
        rgba = np.asarray(fig.canvas.buffer_rgba())
        plt.close(fig)
        frames.append(ViewFrame(name=view, rgb=rgba[:, :, :3].copy()))
    return frames


def _elev_azim(d: np.ndarray) -> tuple[float, float]:
    """A camera direction as matplotlib's (elevation, azimuth) in degrees, so the fallback can draw a view
    whose direction is computed rather than tabulated."""
    d = np.asarray(d, dtype=np.float64)
    n = float(np.linalg.norm(d)) or 1.0
    d = d / n
    return float(np.degrees(np.arcsin(np.clip(d[2], -1.0, 1.0)))), float(np.degrees(np.arctan2(d[1], d[0])))


def _font(size: int):
    from PIL import ImageFont
    try:
        return ImageFont.load_default(size=size)
    except TypeError:
        return ImageFont.load_default()


def _compose(frame: ViewFrame, title: str, max_px: int, overlay: bool):
    """Downscale the view to `max_px` and draw the title, the triad, the labels and the legend.

    The title is not decoration. The prompt tells the model that each image's title names the view, so a view
    the prompt does not describe explains itself here, which is how the strip arrived without a prompt change."""
    from PIL import Image, ImageDraw

    img = Image.fromarray(np.ascontiguousarray(frame.rgb, dtype=np.uint8), "RGB")
    if max(img.size) > max_px:
        img = img.resize((max_px, max_px), Image.LANCZOS)
    draw = ImageDraw.Draw(img)
    line_h = max(11, max_px // 60)
    small = _font(line_h)
    label_font = _font(max(12, max_px // 52))
    head = f"{title}   view {frame.name}"
    if frame.name == SECTION:
        head += ": the half nearest you is cut away, so you are looking inside the part"
    elif frame.name == STATIONS:
        head += (f": {STATION_COUNT} cuts straight across the flow axis, in order from one end of it to the "
                 f"other; they are not evenly spaced")
    elif frame.name == STOPS:
        head += f": {STOPS_CAPTION}"
    elif frame.note:
        head += f": {frame.note}"
    draw.text((8, 6), head, fill=(20, 20, 20), font=small)
    for text, x, y in frame.captions:
        draw.text((x, y), text, fill=(60, 60, 60), font=label_font)
    if frame.name == STOPS:
        # no triad and no opening labels, for the strip's reason: these are cuts through the middle of the part
        # and a caption at a mouth's centre would name nothing in the frame. No lettered marks either, and no
        # sentence about the strip's scale: each panel here carries its own scale on purpose (`stops_frame`),
        # so the panel legend below would say something false of this view
        draw.text((8, max_px - line_h - 8), STOPS_LEGEND, fill=(70, 70, 70), font=small)
        return img
    if frame.name != STATIONS and _panel_slot(frame.name):
        # an un-packed panel is a cut, so it is drawn the way the strip's panels are: no triad, no opening
        # label, the letters at the places the strip nominated, and a line saying what the two colours mean
        taken: list[tuple[float, float, float, float]] = []
        for letter, x, y, _cut, _kind in frame.marks:
            _draw_mark(draw, letter, x, y, label_font, taken)
        if frame.marks:
            draw.text((8, max_px - 2 * (line_h + 8)),
                      "violet letters mark places to report on: the same letters, at the same places, as on "
                      "the strip", fill=(70, 70, 70), font=small)
        # both lines are kept under about a hundred and twenty characters on purpose: the legend is drawn at
        # max_px // 60 and a longer line runs off the right edge of the image, which is where the strip's own
        # title already goes and is not a thing to copy
        scale = frame.legend or "same scale as the strip and as the other cut views"
        draw.text((8, max_px - line_h - 8),
                  f"green = material where the cut passed through it, white = empty; {scale}",
                  fill=(70, 70, 70), font=small)
        return img
    if frame.name == STATIONS:
        # the strip carries no triad and no opening labels: an opening is a mouth on the surface and these are
        # cuts through the middle of the part, so a caption at a mouth's centre would name nothing in the frame
        taken: list[tuple[float, float, float, float]] = []
        for letter, x, y, _cut, _kind in frame.marks:
            _draw_mark(draw, letter, x, y, label_font, taken)
        if frame.marks:
            # the picture says what its own marks mean, on its own line, the way the painted openings do. What
            # it must not say is what is at one: the letter is a place and the model is what says what is there
            draw.text((8, max_px - 2 * (line_h + 8)),
                      "violet letters mark places in the cuts to report on, in order along the flow axis",
                      fill=(70, 70, 70), font=small)
        draw.text((8, max_px - line_h - 8),
                  "green = material where that cut passed through it, white = empty; every cut is at the same "
                  "scale", fill=(70, 70, 70), font=small)
        return img
    if overlay:
        for axis, (o, tip, toward) in frame.triad.items():
            _draw_axis(draw, axis, o, tip, toward, label_font, max_px)
        for oid, x, y, hidden in frame.labels:
            _draw_label(draw, oid, x, y, hidden, label_font)
        legend = "red +X  green +Y  blue +Z   yellow = opening id at its centre, grey = behind the surface here"
    else:
        legend = "red X  green Y  blue Z   yellow = opening id"
    draw.text((8, max_px - line_h - 8), legend, fill=(70, 70, 70), font=small)
    return img


def _draw_axis(draw, axis: str, o: tuple[float, float], tip: tuple[float, float], toward: bool, font, max_px: int) -> None:
    """An arrow from the triad origin to the axis tip; an axis pointing at or away from the viewer collapses
    to a marker: a filled dot toward the viewer, a ring away from it."""
    colour = AXIS_COLOURS[axis]
    dx, dy = tip[0] - o[0], tip[1] - o[1]
    length = (dx * dx + dy * dy) ** 0.5
    width = max(2, max_px // 300)
    radius = max(4, max_px // 110)
    if length < 3 * radius:
        box = (o[0] - radius, o[1] - radius, o[0] + radius, o[1] + radius)
        if toward:
            draw.ellipse(box, fill=colour)
        else:
            draw.ellipse(box, outline=colour, width=width)
        draw.text((o[0] - radius, o[1] + radius + 3), f"{axis} {'toward you' if toward else 'away from you'}", fill=colour, font=font)
        return
    draw.line([o, tip], fill=colour, width=width)
    ux, uy = dx / length, dy / length
    head = max(6, max_px // 70)
    left = (tip[0] - head * ux + 0.5 * head * uy, tip[1] - head * uy - 0.5 * head * ux)
    right = (tip[0] - head * ux - 0.5 * head * uy, tip[1] - head * uy + 0.5 * head * ux)
    draw.polygon([tip, left, right], fill=colour)
    draw.text((tip[0] + 6 * ux + 2, tip[1] + 6 * uy - 6), axis, fill=colour, font=font)


#: Where a mark's letter box is tried, in order, relative to the place it points at. Two places in one cut can
#: be a couple of pixels apart (a wall between two passages, a core inside a bore), and two boxes drawn at the
#: same offset would sit on top of each other and neither letter would be readable.
MARK_OFFSETS = ((9, -17), (9, 5), (-26, -17), (-26, 5), (9, -31), (9, 19), (-26, -31), (-26, 19))


def _overlaps(box, taken) -> bool:
    return any(box[0] < t[2] and t[0] < box[2] and box[1] < t[3] and t[1] < box[3] for t in taken)


def _draw_mark(draw, letter: str, x: float, y: float, font, taken: list | None = None) -> None:
    """One lettered mark: a ring at the place and the letter in a box beside it, joined by a leader.

    A ring and not a filled dot, and the letter beside the place and not over it, because the places that
    matter most are the small ones: a wall between two passages is a couple of pixels of a cut, and a mark
    drawn on top of it would hide the only evidence the question is about."""
    r = 4
    draw.ellipse((x - r, y - r, x + r, y + r), outline=MARK_COLOUR, width=2)
    taken = taken if taken is not None else []
    box, bx, by = None, x, y
    for dx, dy in MARK_OFFSETS:
        bx, by = x + dx, y + dy
        left, top, right, bottom = draw.textbbox((bx, by), letter, font=font)
        box = (left - 4, top - 2, right + 4, bottom + 2)
        if not _overlaps(box, taken):
            break
    draw.line([(x, y), (bx, (box[1] + box[3]) / 2)], fill=MARK_COLOUR, width=1)
    draw.rounded_rectangle(box, radius=3, fill=MARK_COLOUR, outline=(255, 255, 255))
    draw.text((bx, by), letter, fill=(255, 255, 255), font=font)
    taken.append(box)


def _draw_label(draw, text: str, x: float, y: float, hidden: bool, font) -> None:
    """The caption for one opening. The box stays yellow and the text stays black whatever else changes: that
    is what the prompt tells the model to read."""
    fill = (235, 235, 235) if hidden else (255, 235, 90)
    ink = (120, 120, 120) if hidden else (0, 0, 0)
    mark = ink
    r = 3
    draw.ellipse((x - r, y - r, x + r, y + r), fill=mark)
    bx, by = x + 7, y - 16
    left, top, right, bottom = draw.textbbox((bx, by), text, font=font)
    draw.line([(x, y), (bx, by + (bottom - top) / 2)], fill=mark, width=1)
    draw.rounded_rectangle((left - 3, top - 2, right + 3, bottom + 2), radius=3, fill=fill, outline=ink)
    draw.text((bx, by), text, fill=ink, font=font)
