"""Everything the agent is allowed to know about a geometry. Numbers originate here and nowhere else."""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field, model_serializer

from geometry_agent.facts.coverage import Coverage

FACTS_SCHEMA_VERSION = 3


def _drop_unmeasured(data: dict, keys: tuple[str, ...]) -> dict:
    """Leave out the fields added in revision 1 when they hold None. A document measured before they existed
    then serialises exactly as it did, instead of carrying a row of nulls for facts it never measured, and a
    reader gets the same None back from the default."""
    for k in keys:
        if k in data and data[k] is None:
            del data[k]
    return data
#: WHICH MEASUREMENT WROTE A DOCUMENT, separate from its shape. The cache is keyed by the schema version, and a
#: fix to how a field is measured does not change the shape, so without this a cached document written by the
#: old code is served forever with the old numbers in it: `min_gap` as the bore, `thickness_median` as half a
#: pipe's length. `measure` recomputes any cached document whose revision is older than this one. The file name
#: of the cache entry does not change, so every reader that builds the path itself still finds it.
#:
#:   0  everything written before revision 1 existed
#:   1  chords that prove what they crossed (facing, ball, self-exclusion), gap clusters, feature lines, sliver
#:      fraction, bore counts on rings, the opening gate, and symmetry left None when its stage did not run
#:   2  the coverage facts (`facts/coverage.py`): centrelines and bends, the wall partition, the flow places.
#:      A revision-1 document has no `coverage`, and serving it would read as "measured, none found"
MEASUREMENT_REVISION = 2

Vec3 = tuple[float, float, float]
Purpose = Literal["internal_cfd", "external_cfd", "conjugate_heat_transfer", "structural"]
Fidelity = Literal["draft", "standard", "max"]

#: What a planar end or open loop most likely is, from geometry alone. The model may still assign any role.
#: port_candidate: a tube runs behind the face. planar_face: a flat side of a block or body, not a port unless
#: the brief says so. hole: a pinhole, slit or unstitched seam. ring: a face with a hole through it (a shoulder,
#: or the end of a solid wall). interface: a face shared with another body (the solid/fluid boundary of CHT).
OpeningClass = Literal["port_candidate", "planar_face", "hole", "ring", "interface"]


class BBox(BaseModel):
    min: Vec3
    max: Vec3
    extent: Vec3
    diagonal: float
    longest_axis: int
    shortest_axis: int
    aspect: float


class Opening(BaseModel):
    id: str
    kind: Literal["rim", "cap", "ring"]
    centroid: Vec3
    normal: Vec3
    area: float
    perimeter: float
    hydraulic_diameter: float
    equivalent_diameter: float
    width: float
    height: float
    shape: Literal["circle", "rectangle", "irregular"]
    tubularity: float
    on_bbox_face: bool
    region_id: str = "r1"
    bore_diameter: float | None = None
    bore_area: float | None = None
    classification: OpeningClass = "port_candidate"
    area_fraction_of_region: float = 0.0
    face_count: int = 0
    #: Which side of the body's bounding box the face lies on, when it does (a face at z_min facing -z on a
    #: vehicle is the underside; naming it by position keeps identity claims honest).
    bbox_side: Literal["x_min", "x_max", "y_min", "y_max", "z_min", "z_max"] | None = None
    #: HOW MANY HOLES GO THROUGH A RING, and every one of their areas, largest first. `bore_diameter` and
    #: `bore_area` are the LARGEST bore only: a block with two parallel bores and one with three have the same
    #: `bore_area`, and a reader that takes it as "the bore" has one passage where the part has two or three.
    #: None when the ring's hole was inferred from missing area behind a seam the adjacency cannot see, where
    #: the count is not in the geometry this reads, and on every cap and rim.
    bore_count: int | None = None
    bore_areas: list[float] | None = None

    @model_serializer(mode="wrap")
    def _serialise(self, handler):
        return _drop_unmeasured(handler(self), ("bore_count", "bore_areas"))


class Stub(BaseModel):
    opening_id: str
    length: float
    length_over_diameter: float
    terminated_by: Literal["junction", "area_change", "drift", "end_of_body", "exit", "max_march"]
    stations: int
    end_point: Vec3 | None = None
    inward_direction: Vec3 | None = None
    entry_loops: int = 0
    entry_area_ratio: float | None = None


class Interface(BaseModel):
    """Faces two bodies share (coincident, opposite normals): where a solid meets a fluid in CHT. `shared` means
    the same triangles appear in both bodies (a glued assembly); `coincident` means each body carries its own
    copy of one surface with no gap (a plain compound export), which a multi-region mesher cannot use until
    the bodies are glued in CAD."""
    region_a: str
    region_b: str
    area: float
    faces: int
    kind: Literal["shared", "coincident"] = "shared"


class Region(BaseModel):
    id: str
    faces: int
    watertight: bool
    volume: float | None
    bbox_extent: Vec3
    bbox_min: Vec3 = (0.0, 0.0, 0.0)
    bbox_max: Vec3 = (0.0, 0.0, 0.0)
    surface_area: float
    nested_in: str | None = None
    #: Regions whose innermost container is this one (the inverse of nested_in).
    contains: list[str] = Field(default_factory=list)
    rotational_order: int | None = None
    rotational_axis: int | None = None


class ThinCluster(BaseModel):
    id: str
    faces: int
    thickness_min: float
    thickness_median: float
    centroid: Vec3
    area: float
    #: The bounding-box extent of the cluster's triangles: a thin web the length of the part and a thin lip at
    #: one mouth have the same minimum and very different extents. None on documents written before revision 1.
    extent: Vec3 | None = None


class GapCluster(BaseModel):
    """ONE PLACE where two different surfaces face each other across less than the near-touching threshold.

    WHERE and HOW BIG, because the minimum alone cannot say either: an annular gap running the whole length of
    a part and a single pinch point between two bodies produce the same `min_gap`, and a mesher's gap control
    needs a region, not a number. `extent` is the bounding box of the cluster's triangles on both sides of the
    gap; `area` is the facing surface summed over both walls. `regions` is the pair of bodies the chords ran
    between, the same body twice for a gap inside one part. Distances, never a mesh setting."""
    id: str
    faces: int
    gap_min: float
    gap_median: float
    gap_max: float
    centroid: Vec3
    extent: Vec3
    area: float
    regions: tuple[str, str]


class ChordCoverage(BaseModel):
    """What a chord measurement actually covered, so a minimum over part of a file never reads as one over all.

    `faces_cast` faces cast the chords the minimum was taken over, out of `faces_total`; `minimum_exhaustive`
    is False when that was a stride over the faces or the ascending search was cut short, and the minimum is
    then an upper bound. `every_face_tested` says whether the percentiles and clusters are over every face or a
    systematic area-proportional sample (the same faces every run: nothing is drawn). `rejected_fraction` is the
    share of area whose chord met a facing surface and then failed the ball test (it ran along a wall, not
    across it); `passage_fraction`, for gaps, the share whose chord crossed a passage the surface closes round
    (a bore, a duct), which is not a gap between two surfaces. `oblique_fraction` is the share whose chord met a
    surface that did not face it: at a concave corner that is right (a corner is not a gap), and between two
    tubes tessellated coarsely for how far apart they stand it is a gap the chords cannot see square on (a
    tubesheet of 24-sided nozzles three radii apart meets its neighbours 45 degrees off). A `min_gap` of None
    with a large oblique share is "not found square on", not "nothing there"."""
    faces_total: int
    faces_cast: int
    every_face_tested: bool
    minimum_exhaustive: bool
    rejected_fraction: float
    passage_fraction: float = 0.0
    oblique_fraction: float = 0.0


class Features(BaseModel):
    """Local scales and surface defects.

    FROM REVISION 1 (see MEASUREMENT_REVISION), five fields changed what they measure, and each was a fact that
    lied. The names are kept because readers use them; the meanings below are the measured ones.

      sharp_edge_count, knife_edge_count  how many feature LINES, not how many mesh edges: chains of edges
          over the angle, joined end to end where they turn less than 45 degrees. A box has twelve at any
          triangle count. The mesh-edge count went from 528 to 4,224 on one unchanged part refined 64 times.
      thickness_min  the shortest accepted inward chord over every face (or `thickness_coverage` says it was
          not), never a draw from a seeded sample.
      thickness_p05, thickness_median  AREA-weighted, over chords that crossed the solid: a chord must meet a
          surface that faces back and a ball whose radius is a quarter of the chord must fit at its midpoint. The chords
          down the length of a pipe's wall from its end annuli fail that and are gone; they made the median
          half the pipe's length.
      min_gap  the shortest outward chord between two DIFFERENT surfaces facing each other within 30 degrees.
          A bore's far side is the same surface curving round, and so is a duct's; neither is a gap. None when
          no two different surfaces face each other, and `gap_clusters` is then an empty list (measured, none).
      near_touching_pairs  how many separate PLACES two surfaces face each other closer than 2 per cent of the
          diagonal: the number of `gap_clusters`. It used to be how many sampled faces did.

    THICKNESS AND GAP ARE ABOUT SIDES, NOT MEANINGS. `thickness_*` is across the file's solid and `min_gap`
    across the space outside it. On a wall shell that is wall and passage; on a fluid domain it is passage and
    the space where the wall would be. Which is which is the representation's to say, and this record never
    guesses it."""
    edge_length_min: float
    edge_length_median: float
    sharp_edge_count: int
    sharp_edge_length: float
    knife_edge_count: int
    thickness_min: float | None
    thickness_p05: float | None
    thickness_median: float | None
    thin_clusters: list[ThinCluster]
    near_touching_pairs: int
    min_gap: float | None
    min_gap_between_regions: float | None = None
    closest_regions: tuple[str, str] | None = None
    #: Edges with one face are open rims; edges with three or more faces are non-manifold (an internal baffle,
    #: a duplicated patch, two bodies welded along a seam). A mesher sees both.
    non_manifold_edge_count: int = 0
    winding_consistent: bool = True
    #: Triangles whose longest edge is over SLIVER_ASPECT times their height. A COUNT OF THE FILE, NOT OF THE
    #: PART: it is proportional to the triangle count on an unchanged shape (560 to 143,360 over a 256x
    #: refinement). `sliver_fraction` is the share of faces, which does not move when the file is refined.
    sliver_faces: int = 0
    #: The rest is additive and None on a document written before revision 1: None means NOT MEASURED.
    sliver_fraction: float | None = None
    knife_edge_length: float | None = None
    gap_clusters: list[GapCluster] | None = None
    thickness_coverage: ChordCoverage | None = None
    gap_coverage: ChordCoverage | None = None

    @model_serializer(mode="wrap")
    def _serialise(self, handler):
        return _drop_unmeasured(handler(self), ("sliver_fraction", "knife_edge_length", "gap_clusters",
                                                "thickness_coverage", "gap_coverage"))


class EdgeAngleBin(BaseModel):
    """One bucket of the included-angle spectrum. `included` is the unsigned angle between the two faces: 180
    degrees is flat, 90 is a square corner, convex or re-entrant alike, small is a fold back on itself. It is
    `180 - the angle between the face normals`, which is the convention a feature-edge extractor reads."""
    included_lo: float
    included_hi: float
    edges: int
    length: float


class FeatureEdgeSpectrum(BaseModel):
    """How many edges a feature-edge extractor would take, as a function of the angle it is given.

    A count and a total length cannot answer that question: on a tessellated export a curved surface carries
    thousands of edges a degree or two off flat, so one threshold returns forty edges and a slightly looser one
    returns forty thousand. The spectrum is the distribution itself.

    WHAT IT DROPS, and it is the whole of one population. `bins` and `cumulative` cover the MANIFOLD edges, the
    ones with exactly two faces, because those are the only ones that have an angle at all. An open edge has one
    face and a non-manifold edge has three or more, and an extractor takes both whatever angle it is given.
    They are counted separately and never inside a bin.

    A THIRD POPULATION, AND IT IS A REFUSAL. `inconsistent_edges` are two-face edges whose faces are wound
    against each other, so one normal is reversed and the angle between the normals is the complement of the
    angle between the faces: flat surface reads as a fold. Which face is reversed is not in the file, so they
    are counted inside `manifold_edges` and never binned, and the bins hold `manifold_edges - inconsistent_edges`.
    Zero on every STEP, whose tessellation is wound by its solid; it is the STL export fault this catches."""
    manifold_edges: int
    open_edges: int
    non_manifold_edges: int
    inconsistent_edges: int = 0
    bins: list[EdgeAngleBin]
    #: (included angle, edges at or below it, their total length): what an extractor set to that angle returns.
    cumulative: list[tuple[float, int, float]]
    #: The widest run of included angle carrying no edge at all, inside the range a threshold can sit in. A wide
    #: band means the answer is insensitive to where the line is drawn; a narrow one means it is not. It is a
    #: property of this surface and it is NOT a recommended setting: the builder owns that choice.
    widest_empty_band: tuple[float, float] | None = None


class ChordDeviation(BaseModel):
    """How far the triangles sit from the surface they stand for, which is what turns a radius into a hexagon.

    THE CASE MATTERS MORE THAN THE NUMBER. When the file carries the true surface (STEP, IGES, BREP) the
    deviation is measurable against it. When the file carries triangles only (STL, OBJ, PLY) the surface they
    approximate IS NOT IN THE FILE, so no measurement, no estimate and no rule of thumb can recover it, and the
    honest answer is that the question cannot be asked of this input. `computable` says which case this is."""
    computable: bool
    reason: str
    #: Whether the file carries a surface at all, which is the thing that decides the question. It is the FORMAT
    #: that settles this, not the part: no STL of any part has one and every readable STEP does.
    surface_available: bool = False
    #: What this measurement asked the tessellator for, so the numbers below can be read against it. A different
    #: deflection gives a different surface mesh and different sag; this is not a property of the CAD alone.
    requested_linear: float | None = None
    requested_angular_deg: float | None = None
    sag_max: float | None = None
    sag_p95: float | None = None
    sag_median: float | None = None
    #: Sag over the local chord length, which is the scale-free form and the one that compares across parts.
    sag_over_chord_max: float | None = None
    chords_sampled: int = 0
    faces_with_surface: int = 0
    #: How many sampled chords depart further than the deflection the tessellation was built to. Each is
    #: measured from points ON the chord to the surface, so it is a lower bound on how far the chord departs
    #: and not an artefact of the parameterisation: on a sphere written to STEP it is the closed form exactly,
    #: and OCCT's own triangulation there misses the deflection it was asked for.
    chords_over_requested: int = 0
    #: Chords dropped because no point on them could be projected onto the face's surface. They are in no
    #: number above, and a count here that is not small says the numbers describe part of the surface only.
    chords_unprojected: int = 0


class InterfaceThickness(BaseModel):
    """How thick one body is at ONE interface, which is what sets the cells across it in a conjugate run. A
    global `thickness_min` cannot answer it: a part with a 20 mm flange and a 1 mm liner has one thickness at
    each interface and neither of them is the global minimum.

    ONE ROW PER SIDE, AND THE SIDE IS THE ANSWER. An interface has a body on each side and they are not the
    same thickness: at a pipe wall's bore the solid is 4 mm and the fluid is a 50 mm passage. `through_region`
    says which body the rays crossed, so a row is never read as the other one. Which of the two is the solid is
    the customer's word and not the geometry's, so both are reported and neither is labelled.

    `reason` is filled and every number is None when the row cannot be measured honestly, which is a result and
    not a failure: a body an inward ray leaves without meeting a second surface has no thickness here."""
    region_a: str
    region_b: str
    #: The body the rays travelled through: one of `region_a`, `region_b`.
    through_region: str
    faces_measured: int = 0
    faces_in_interface: int = 0
    thickness_min: float | None = None
    thickness_p05: float | None = None
    thickness_median: float | None = None
    reason: str = ""


class Axes(BaseModel):
    """Principal axes, mirror and rotational symmetry, the blunt end.

    `symmetry_measured` False means the symmetry stage did not run (the time budget skipped it), and then
    `symmetry_scores`, `symmetry_planes` and `symmetry_normals` are None: NOT MEASURED. An empty list is a
    measured "no mirror plane". Before this the skip wrote `[]` and scores of zero, which read as a part with
    no symmetry at all, on a part with a plane of symmetry at every other refinement of the same file. The
    rotational fields and the blunt end are not measured on a skip either: `rotational_order` None is ambiguous
    by itself, so read it with `symmetry_measured`."""
    principal: tuple[Vec3, Vec3, Vec3]
    variance: Vec3
    slenderness: float
    symmetry_scores: Vec3 | None
    symmetry_planes: list[int] | None
    blunt_end_sign: int
    blunt_end_confidence: float
    #: N-fold rotational symmetry about a principal axis (blades, bolt patterns, nozzle arrays). None when none.
    rotational_axis: int | None = None
    rotational_order: int | None = None
    rotational_score: float = 0.0
    #: World-space normals of the mirror planes actually found (one per entry in symmetry_planes, in order), so
    #: a plane found by sweeping a degenerate principal frame is usable, not just counted.
    symmetry_normals: list[Vec3] | None = Field(default_factory=list)
    symmetry_measured: bool = True


class UnitEvidence(BaseModel):
    declared: str | None
    declared_source: Literal["step_header", "step_body", "none"]
    candidates: list[tuple[str, float]]
    plausible_for_purpose: dict[str, list[str]]


class NamedEntity(BaseModel):
    name: str
    entity: str
    implied_role: str | None


class CellEstimate(BaseModel):
    tier: Fidelity
    base_size: float
    #: The cell the tier already puts on every surface (base_size / 2**surface_levels). Cells-across arithmetic
    #: divides by this, never by base_size.
    surface_cell: float = 0.0
    cells: int
    surface_cells: int
    volume_cells: int
    layer_cells: int
    domain_volume: float
    assumptions: list[str]


class OpeningGate(BaseModel):
    """What the opening detector's tubularity gate did, so an empty `openings` list says which empty it is.

    `candidates` counts the flat facets and smooth patches the gate judged: every one that passed it, and every
    one it turned down that was above the area floor and compact enough to be a port (perimeter squared over
    area within what MAX_ASPECT allows; the long strips a tessellated cylinder is made of are not counted). That
    includes the small flat pieces a tessellated fillet is made of, so the count is a count of evaluations and
    not of faces a person would name. `rejected_by_tubularity` of them failed because too little of their outer
    boundary meets a wall. When every candidate was rejected there are flat faces on this part and none of them
    met a wall squarely enough to read as a tube's end: on a part whose every outer edge carries a fillet the wall arrives through the fillet
    and the gate sees none of it (measured 0.000 to 0.116 on a filleted bracket, 1.000 on its sharp twin). That
    is a refusal with a reason, not a part with no mouths, and `measure` warns so."""
    candidates: int
    rejected_by_tubularity: int
    best_rejected_tubularity: float | None = None


class PassageEnd(BaseModel):
    """Where a passage stops at a wall with no mouth: `vision.terminus.find_stops` run on the measured openings and
    the mesh at measure time, with the mesh read as the material. MEASUREMENT, not a look: the look only draws it.

    `opening_id` is the measured face (two faces of one wall joined by `+`), `point` the middle of the wall on the
    passage's axis and `normal` the wall's outward normal, both in the file's own numbers; `depth` is how much
    open passage runs into it and `diameter` that passage's hydraulic diameter. Which of these a builder is told
    about depends on which side of the surface is the flow, which the measurement does not decide: where the file
    is the fluid a closed end and a port face are the same disc, and `hexera.planner_places` places none."""
    opening_id: str
    point: Vec3
    normal: Vec3
    depth: float
    diameter: float


class GeometryFacts(BaseModel):
    schema_version: int = FACTS_SCHEMA_VERSION
    #: Which measurement wrote this document; see MEASUREMENT_REVISION. 0 on everything written before it.
    measurement_revision: int = 0
    source_path: str
    source_format: str
    sha256: str
    faces: int
    vertices: int
    watertight: bool
    total_surface_area: float
    total_volume: float | None
    bbox: BBox
    bodies: int = 1
    regions: list[Region]
    interfaces: list[Interface] = Field(default_factory=list)
    openings: list[Opening]
    stubs: list[Stub]
    features: Features
    axes: Axes
    units: UnitEvidence
    names: list[NamedEntity]
    cell_estimates: list[CellEstimate]
    warnings: list[str] = Field(default_factory=list)
    timings: dict[str, float] = Field(default_factory=dict)
    #: Connected components too small to be a body (a stray triangle, a folded sliver) that the loader dropped
    #: before measuring; they are export debris, not regions, holes or openings.
    debris_components: int = 0
    #: THREE FACTS THAT ARRIVED AFTER SCHEMA 3, AND `None` MEANS NOT MEASURED, NEVER NONE FOUND. The facts cache
    #: is keyed by schema version, and bumping it would orphan 321 measured corpus entries and buy nothing, so
    #: these are additive and default to None. A document written before they existed carries None; a document
    #: written after carries the object, and an EMPTY spectrum or an EMPTY list inside it is a measured zero. A
    #: reader that cannot tell those two apart will read a silence as an answer, which is the failure this
    #: project has made eight times.
    feature_edges: FeatureEdgeSpectrum | None = None
    chord: ChordDeviation | None = None
    interface_thickness: list[InterfaceThickness] | None = None
    opening_gate: OpeningGate | None = None
    #: The coverage facts (`facts/coverage.py`): what the flow path does between the mouths (centrelines, bends,
    #: throats, steps, tapers, plates, chambers), the named wall partition, and the two refusals. None means NOT
    #: MEASURED (a document from before revision 2, or a stage the time budget skipped), never "nothing there".
    #: Measured without a representation: `hexera.report_measured` re-derives the places once the
    #: representation and the customer's flow direction are known.
    coverage: Coverage | None = None
    #: Where a passage stops with no mouth (`PassageEnd`), measured when `facts.measure.MEASURED_STOPS_ENV` is on.
    #: None means NOT MEASURED (the switch off, or a document from before it), `[]` measured and none found. Left
    #: out of the serialised document when None, so a measurement with the switch off is byte for byte the same.
    passage_ends: list[PassageEnd] | None = None

    @model_serializer(mode="wrap")
    def _serialise(self, handler):
        return _drop_unmeasured(handler(self), ("coverage", "passage_ends"))

    def opening(self, opening_id: str) -> Opening | None:
        return next((o for o in self.openings if o.id == opening_id), None)

    def stub(self, opening_id: str) -> Stub | None:
        return next((s for s in self.stubs if s.opening_id == opening_id), None)

    def region(self, region_id: str) -> Region | None:
        return next((r for r in self.regions if r.id == region_id), None)

    def interface_area(self, region_a: str, region_b: str) -> float:
        return sum(i.area for i in self.interfaces if {i.region_a, i.region_b} == {region_a, region_b})
