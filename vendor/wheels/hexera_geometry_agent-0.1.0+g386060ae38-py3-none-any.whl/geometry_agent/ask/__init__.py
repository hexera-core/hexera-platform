"""The surveyor's abstentions are intake's questions.

The look already declines to name a role on six of every seven mouths, the measurement never names a role at
all, and the two lists of things nobody is sure about have never been connected to the list of things the
customer is asked. This package is that connection, and nothing in the shipping path imports it yet.

    ask.uncertainty   what the surveyor declined to settle, read out of `hexera.report_measured`
    ask.settle        what already answered it: a declared port at the mouth, or a phrase that selects an option
    ask.consequence   whether the answer would change what the builder does, worked out by branching
    ask.say           the question written the way a person asks it, one question and one default
    ask.record        what has to be stored for the answer to come back as a label
    ask.intake        the four cuts, in order, and the short list that comes out

ONE OF THREE `Uncertainty` TYPES IN THIS TREE (`contract/survey.py`, `ask/schema.py`, `chain/schema.py`), and they
were left separate on purpose when work/complete was integrated: none is on the shipped path, and merging them
means choosing the question budget and when a monitor alert becomes a question, which are defaults. The merged
record is `docs/synthesis.md` appendix B; `docs/integration.md` section 3 says what must survive building it.
"""
from geometry_agent.ask.intake import Asked, ask_intake
from geometry_agent.ask.schema import ASK_SCHEMA, Consequence, Question, Uncertainty

__all__ = ["ASK_SCHEMA", "Asked", "Consequence", "Question", "Uncertainty", "ask_intake"]
