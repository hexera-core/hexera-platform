"""Whether an answer would change what the builder does, worked out by giving the builder both answers.

THE RULE IS REHAAN'S AND THE WHOLE MODULE IS ITS IMPLEMENTATION: a question is worth asking only if the answer
changes what the builder does. Everything else is a form nobody fills in. So the estimate is not a heuristic
about how interesting a field looks. It is a COUNTERFACTUAL: take the surveyor's own document, feed the
surveyor's own derivation each branch of the answer in turn, and diff the builder inputs that come out. A
question whose branches produce the same builder inputs is not asked.

WHAT THE BUILDER INPUTS ARE is not a matter of opinion either. `hexera.DIRECTIVE_KEYS` enumerates every key the
renderer consumes from the planner's reply (seven on snappy internal, six external, two gmsh),
`hexera.HANDOVER_READERS` names the platform file and line that reads each handover field, and
`hexera.planner_block` is the typed dict the planner actually receives. `schema.BUILDER_FIELDS` is drawn from
those three and nothing else.

HOW WELL THIS WORKS, said plainly, because the honest answer is "on two of the three kinds".

  COMPUTED   port_role, flow_direction, budget_envelope, unit. The branch is expressible as an input to
             `hexera.forecast` / `tools.estimate_builder_cells` / `tools._external_domain`, so the diff is a
             real diff of real values and `Consequence.evidence` carries them.
  DECLARED   dispatch_refusal, unlabelled_mouth, look_dispute. The branch is not an input to any derivation we
             have: there is no function that takes "the customer says there is an opening there" and returns a
             mesh. The tier is then asserted from the argument in `DECLARED_TIER` below, `computed` is False,
             and nothing pretends otherwise. An uncomputable consequence is never read as no consequence.

WHAT THIS INSTRUMENT SILENTLY DROPS, which has to be written down before any number it produces is trusted,
because a measuring tool in this project has had the same blind spot as the thing it measured eight times.

  1. It is built out of the emulator. `tools.estimate_builder_cells` reproduces the builder's SIZING. It does
     not model a boundary condition's VALUE, so swapping an inlet for an outlet at the same bore moves not one
     cell. If the ranking were the cell count, every inlet-outlet swap on a symmetric part would score zero and
     be deleted, which is the most consequential question in the product. That is why `patch_roles` is a field
     in its own right at its own tier and is not inferred from cells.
  2. The same trap, again, on the external path: reversing the flow axis moves the domain box and leaves its
     extent alone, so the cell count is identical to the cell. `domain_box` is compared corner by corner for
     exactly that reason.
  3. `dispatch` is `hexera.triage`, which is this package's MIRROR of the platform's own pre-mesh rules at a
     pinned sha. If the platform changes a rule, this tier goes stale and nothing here will notice.
  4. The external path is scored inert for port roles because `uncertainty.builder_ports` returns nothing there and
     `tools._estimate_external` takes no inlet id. Both are true of the emulator. If the real builder ever grew
     a patch reader on the external path, the emulator and this ranker would be wrong together and neither
     would flag it.
"""
from __future__ import annotations

import time
from typing import Any

from geometry_agent.agent import catalog, hexera, tools
from geometry_agent.ask.schema import FIELD_TIER, TIERS, Consequence

#: The tier asserted for a kind whose branches no derivation here can take, and the argument for each. These
#: are DECISIONS, not measurements, and they are stated as values so a reader can disagree with the value.
DECLARED_TIER: dict[str, tuple[str, str]] = {
    "dispatch_refusal": (
        "dispatch",
        "the surveyor predicts a named platform raise; the answer is whether there is a job at all, and no "
        "mesh is produced under one of the branches"),
    "unlabelled_mouth": (
        "domain",
        "if the mouth is real the measurement is incomplete, and on a carve that is a fluid volume with a hole "
        "in it: what gets meshed changes, not how finely"),
    "look_dispute": (
        "resolution",
        "the dispute is whether a feature is there to resolve, and `reconcile.verdict.question` already frames "
        "the answer as resolve it or do not, which is a resolution decision"),
}

#: THE BUILDER FIELD each computable kind's answer moves, worst case, and so the tier its question keeps when
#: the counterfactual was NOT run. It is the argument `DECLARED_TIER` makes, one level down: the tier is read off
#: `FIELD_TIER` rather than restated, so a field that moves tier moves these with it. Each entry is the field
#: named in that kind's own brancher below:
#:
#:    port_role        `patch_roles`: the role is written into the patch list the renderer reads
#:    fluid_side       `representation`: the branch IS the representation the builder is handed
#:    unit             `scale_to_metres`: the one number every length in the planner block is multiplied by
#:    flow_direction   `domain_box`: the corners the axis builds, which move even where the extent does not
#:    budget_envelope  `max_cells`: the ceiling the strategy is fitted to
#:
#: WHY THE WORST CASE AND NOT THE LIKELY ONE. An unmeasured consequence is only ever used to decide whether a
#: question is put and where it ranks. Over-ranking puts a question that might not have been needed; under-
#: ranking drops one that was, and on `unit` that is the 1,000x error the package exists to prevent. So the
#: floor is the worst field the branch can reach, and `computed` is False wherever it is used so that no reader
#: takes it for a diff.
FLOOR_FIELD: dict[str, str] = {
    "port_role": "patch_roles",
    "fluid_side": "representation",
    "unit": "scale_to_metres",
    "flow_direction": "domain_box",
    "budget_envelope": "max_cells",
}

#: How many mouths of one role group are branched. The group is ONE question (intake's cut 3) and its text names
#: at most `say.NAMED_IN_TEXT` of them, so on a large group the only thing a per-mouth counterfactual decides is
#: which few the sentence names. Sixteen is four times what it shows.
#:
#: MEASURED, so a reader can see what it costs and what it leaves alone. `catalog.port_area` calls inside one
#: `ask_intake` went as about 3 x mouths squared on the tubesheet ladder (586 at 13 mouths, 7,801 at 50, 43,921 at
#: 120, 126,073 at 204), because every mouth ran two `hexera.forecast` calls and every forecast sums the port area
#: over every port. They are now about 34 a mouth, flat. The largest role group on the 322-part export corpus is 8
#: mouths, so NO corpus part takes the cheap path; on `eval/hard_real` only the four tubesheets (13, 50, 120 and
#: 204) and the strut lattice (1,231) do. On the four tubesheets the question's text, its tier and the set of
#: mouths it covers come out the same either way; on the 204-mouth one the ORDER of `places` below rank 12 differs,
#: because an unbranched mouth has no cell ratio to tie-break on (`eval/ask/intake_cost.py --branched`,
#: docs/fluid_side.md).
GROUP_BRANCHED = 16


def floor_tier(kind: str) -> str:
    """The tier a question of this kind keeps when its branches were never evaluated."""
    if kind in FLOOR_FIELD:
        return FIELD_TIER[FLOOR_FIELD[kind]]
    return DECLARED_TIER.get(kind, ("resolution", "no argument was recorded for this kind"))[0]


def not_branched(kind: str, why: str) -> Consequence:
    """A consequence nothing was branched for, with the reason. Never read as no consequence: the tier is the
    kind's floor, `computed` is False, and the question is put rather than settled."""
    return Consequence(tier=floor_tier(kind), changes=[], computed=False,
                       why=f"the branches were not evaluated: {why}. The tier is this kind's floor, "
                           f"{FLOOR_FIELD.get(kind) or 'the declared one'}, and it is an argument and not a diff")


def deadline_in(seconds: float | None) -> float | None:
    """A `time.perf_counter` stamp `seconds` from now, or None for no ceiling."""
    return None if seconds is None else time.perf_counter() + float(seconds)


def past(deadline: float | None) -> bool:
    return deadline is not None and time.perf_counter() > deadline


#: The margins `snappy_runner.py` uses when the plan declares none, so the box a branch builds is the box the
#: builder would build. Read from the emulator rather than restated here.
_NO_MARGINS: dict[str, float] = {}


def _worst(tiers: list[str]) -> str:
    """The worst tier in a list, where worst is earliest in `TIERS`."""
    rank = {t: i for i, t in enumerate(TIERS)}
    return min(tiers, key=lambda t: rank.get(t, len(TIERS))) if tiers else "none"


def _port_area(facts: Any, o: Any, rep: str) -> float:
    try:
        return float(catalog.port_area(facts, o, rep))
    except Exception:  # noqa: BLE001 - a port the catalog cannot area is a port with no area for ranking
        return float(getattr(o, "area", 0.0) or 0.0)


def builder_inputs(document: dict[str, Any], facts: Any, *, inlet_id: str | None = None,
                   role_of: dict[str, str] | None = None, flow_axis: str | None = None,
                   cell_cap: int | None = -1, scale_to_metres: float | None = -1.0,
                   representation: str | None = None) -> dict[str, Any]:
    """The builder's inputs under one branch, from the surveyor's own derivation.

    Every value here is produced by a function this package already ships and the platform already reads.
    Nothing is recomputed a second way: `cells_high` is `hexera.forecast`, `max_cells` is `hexera.budget`, the
    inlet is `tools.builder_inlet`, the box is `tools._external_domain`. The point of the function is to run
    them with a hypothetical answer in place, not to have its own opinion. `representation` is the one a branch
    of the fluid-side question would set; None is the document's.
    """
    rep = str(representation or document.get("representation") or "")
    engine = str(document.get("engine") or "snappy")
    coords = document.get("coordinates") or {}
    fc_doc = document.get("forecast") or {}
    cap = fc_doc.get("cell_cap") if cell_cap == -1 else cell_cap
    scale = coords.get("scale_to_metres") if scale_to_metres == -1.0 else scale_to_metres

    strategy: dict[str, Any] | None = {"flow_axis": flow_axis} if flow_axis else None
    fc = hexera.forecast(facts, strategy, rep, engine, cell_cap=int(cap) if cap else None, inlet_id=inlet_id)
    cells_high = int(fc["cells_high"])
    bud = hexera.budget(cells_high, rep, int(cap) if cap else None)
    o, _area = tools.builder_inlet(facts, rep, inlet_id)

    box = None
    if rep == "external":
        dmin, dmax, _ref = tools._external_domain(facts, _NO_MARGINS, flow_axis)
        box = [round(v, 9) for v in (*dmin, *dmax)]

    bore = getattr(o, "bore_diameter", None) or getattr(o, "hydraulic_diameter", None)
    return {
        "dispatch": str((document.get("triage") or {}).get("verdict") or "buildable"),
        "patch_roles": dict(sorted((role_of or {}).items())),
        "representation": rep,
        "flow_axis": flow_axis or None,
        "domain_box": box,
        "scale_to_metres": scale,
        "inlet_opening_id": getattr(o, "id", None),
        "inlet_bore": round(float(bore), 9) if bore else None,
        "max_cells": int(bud["max_cells"]),
        "cells_high": cells_high,
    }


def diff(branches: dict[str, dict[str, Any]]) -> tuple[list[str], dict[str, Any]]:
    """Which builder fields differ across a set of branches, and the values that differ."""
    changed, evidence = [], {}
    names = list(branches)
    for fieldname in FIELD_TIER:
        values = [branches[n].get(fieldname) for n in names]
        first = values[0]
        if any(v != first for v in values[1:]):
            changed.append(fieldname)
            evidence[fieldname] = dict(zip(names, values))
    return changed, evidence


def _cells_ratio(branches: dict[str, dict[str, Any]]) -> float | None:
    cells = [b.get("cells_high") for b in branches.values()]
    cells = [float(c) for c in cells if isinstance(c, (int, float)) and c and c > 0]
    if len(cells) < 2:
        return None
    return round(max(cells) / min(cells), 4)


def _declared(kind: str) -> Consequence:
    tier, why = DECLARED_TIER.get(kind, ("resolution", "no argument was recorded for this kind"))
    return Consequence(tier=tier, changes=[], computed=False,
                       why=f"declared, not computed: {why}. No derivation here takes this branch as an input.")


def _role_branches(document: dict[str, Any], facts: Any, opening_id: str, *, ports: list[Any] | None = None,
                   widest_other: str | None = None) -> dict[str, dict[str, Any]]:
    """Two branches for one mouth: this mouth carries the incoming flow, or another one does.

    The second branch is the widest OTHER port, because that is what `tools.builder_inlet` falls back to with no
    declaration (`cad_tessellate.py:614` and `:631`), so the comparison is against what the builder would
    actually do rather than against nothing.

    `ports` and `widest_other` are those same two things worked out once for a whole group by
    `role_consequences`. Passed in, they change nothing about the branches; left out they are worked out here,
    which is what a caller branching one mouth on its own does. Finding the widest other port costs a
    `catalog.port_area` on every port, so rescanning it per mouth was 1.5 million of those calls on its own on a
    group of 1,231.
    """
    from geometry_agent.ask.uncertainty import builder_ports
    rep = str(document.get("representation") or "")
    #: The same set the enumerator uses, read from the same function, so the question and its counterfactual
    #: cannot disagree about which faces the builder cuts.
    ports = list(builder_ports(facts, rep)) if ports is None else ports
    if opening_id not in {p.id for p in ports}:
        #: THE FACE IS NOT ONE THE BUILDER CUTS AS A PORT under this representation, so no answer about it
        #: reaches any builder input and both branches have to be the same object. Writing a role into a map
        #: the builder never reads and then diffing the map is the instrument talking to itself, and it is what
        #: this function did until `eval/ask/corpus.py:audit_cuts` fed it 278 external faces and got 278
        #: "this changes something" back. Every one of those was a role written into a patch list an external
        #: job never has.
        same = {p.id: "outlet" for p in ports}
        base = builder_inputs(document, facts, inlet_id=None, role_of=same)
        return {"it carries the incoming flow": base, "it does not": dict(base)}
    if widest_other is None:
        others = [p for p in ports if p.id != opening_id]
        widest_other = max(others, key=lambda p: _port_area(facts, p, rep)).id if others else None
    as_inlet = {p.id: ("inlet" if p.id == opening_id else "outlet") for p in ports}
    as_not = {p.id: ("inlet" if p.id == widest_other else "outlet") for p in ports}
    as_not[opening_id] = "wall"
    return {
        "it carries the incoming flow": builder_inputs(document, facts, inlet_id=opening_id, role_of=as_inlet),
        "it does not": builder_inputs(document, facts, inlet_id=widest_other, role_of=as_not),
    }


def _flow_branches(document: dict[str, Any], facts: Any, u: Any) -> dict[str, dict[str, Any]]:
    """The builder's own default (no axis, which is +x) against its reversal and against the long axis both ways,
    because those are the answers a customer is likely to give and the ones that move the box."""
    letter = str(u.measurement.get("longest_axis") or "x").lower()[-1:] or "x"
    out = {"the builder's default": builder_inputs(document, facts, flow_axis=None),
           "-x": builder_inputs(document, facts, flow_axis="-x")}
    if letter != "x":
        out[f"+{letter}"] = builder_inputs(document, facts, flow_axis=f"+{letter}")
        out[f"-{letter}"] = builder_inputs(document, facts, flow_axis=f"-{letter}")
    return out


def _budget_branches(document: dict[str, Any], facts: Any, u: Any) -> dict[str, dict[str, Any]]:
    cap = u.measurement.get("cell_cap")
    high = u.measurement.get("cells_high")
    return {"hold the budget": builder_inputs(document, facts, cell_cap=int(cap) if cap else None),
            "raise the budget": builder_inputs(document, facts, cell_cap=int(high) if high else None)}


def _unit_branches(document: dict[str, Any], facts: Any, u: Any) -> dict[str, dict[str, Any]]:
    """Two candidate units as the scale the whole planner block is multiplied by.

    The cell count does not move: `cells_across_diameter` is a ratio and the emulator works in the file's own
    numbers, so the mesh is the same mesh. What moves is `scale_to_metres`, and with it every length the
    platform reads in metres: the reference length, the domain box, the first layer. A thousandfold.
    """
    from geometry_agent.facts.units import UNIT_TO_M
    cands = [str(c[0]) for c in (u.measurement.get("candidates") or []) if c]
    assumed = str(u.measurement.get("assumed") or "mm")
    pick = [c for c in cands if c != assumed][:1] or [c for c in ("m", "mm", "in") if c != assumed][:1]
    out = {assumed: builder_inputs(document, facts, scale_to_metres=UNIT_TO_M.get(assumed))}
    for c in pick:
        out[c] = builder_inputs(document, facts, scale_to_metres=UNIT_TO_M.get(c))
    return out


def _fluid_side_branches(document: dict[str, Any], facts: Any, u: Any) -> dict[str, dict[str, Any]]:
    """Each reading of which side is the fluid, as the representation the builder would be handed. The builder's
    inlet, its bore and the emulator's envelope all move with it, because a ring's port area is its bore on a wall
    shell and its annulus on an annular passage (`catalog.port_area`)."""
    readings = (u.measurement or {}).get("readings") or {}
    return {k: builder_inputs(document, facts, representation=str(v)) for k, v in readings.items()}


#: kind -> the function that builds its branches. A kind not here is declared, not computed.
BRANCHERS = {
    "flow_direction": _flow_branches,
    "budget_envelope": _budget_branches,
    "unit": _unit_branches,
    "fluid_side": _fluid_side_branches,
}


def consequence_of(u: Any, document: dict[str, Any], facts: Any, *, ports: list[Any] | None = None,
                   widest_other: str | None = None) -> Consequence:
    """What the answer to one uncertainty would change in the builder's inputs."""
    if u.kind in DECLARED_TIER:
        return _declared(u.kind)
    try:
        if u.kind == "port_role":
            branches = _role_branches(document, facts, u.places[0], ports=ports, widest_other=widest_other)
        else:
            brancher = BRANCHERS.get(u.kind)
            if brancher is None:
                return _declared(u.kind)
            branches = brancher(document, facts, u)
    except Exception as exc:  # noqa: BLE001 - a branch that will not evaluate is reported, never scored zero
        return Consequence(tier=DECLARED_TIER.get(u.kind, ("resolution", ""))[0], changes=[], computed=False,
                           why=f"the branches would not evaluate ({type(exc).__name__}: {exc}); the tier is the "
                               "kind's floor and not a measurement")
    changes, evidence = diff(branches)
    tier = _worst([FIELD_TIER[c] for c in changes]) if changes else "none"
    return Consequence(
        tier=tier, changes=changes, evidence=evidence, computed=True,
        cells_ratio=_cells_ratio(branches),
        why=("the branches give the builder the same inputs in every field it reads"
             if not changes else "the branches differ in " + ", ".join(changes)),
    )


def role_consequences(us: list[Any], document: dict[str, Any], facts: Any, *, branched: int | None = None,
                      deadline: float | None = None) -> dict[str, Consequence]:
    """The consequence of every mouth's role in ONE grouped question, at a cost that stops growing with the group.

    WHY THIS IS NOT `consequence_of` IN A LOOP, which is what it replaced. The open mouths of a part are one
    question (intake's cut 3): one text, one default, one record with a row per place. The text names at most
    `say.NAMED_IN_TEXT` of them and counts the rest. So on a large group the per-mouth counterfactual decides
    which few are named, and nothing else, and it was paying two `hexera.forecast` calls per mouth plus a scan of
    every port to find the widest other one to do it. Measured on the tubesheet ladder: `catalog.port_area` calls
    per `ask_intake` went 586 at 13 mouths, 7,801 at 50, 43,921 at 120 and 126,073 at 204, a slope of 1.92, 1.97
    and 1.99, and on the 1,231-mouth strut lattice `ask_intake` did not finish in 900 s while measuring the same
    part takes a minute.

    WHAT IS EXACT HERE AND WHAT IS ASSERTED, because the difference is the whole honesty of it.

      EXACT     the mouths the builder does NOT cut as a port under this representation. `_role_branches` builds
                the same object for both branches of every one of them, from the same `role_of` map, so the diff
                is empty for all of them by construction and one evaluation settles the lot. Nothing is assumed
                and nothing is skipped: each still gets its own `Consequence` with the same `why`.
      ASSERTED  on a group over `branched`, the mouths outside the widest `branched` by measured area are not
                branched at all. `not_branched` gives them `port_role`'s floor tier, `computed` False and a `why`
                that says which they are and why. They are still ASKED, still in the question's `places`, still
                in its `covers` and still get their own record row. What they lose is the cell-ratio tie-break,
                so inside the group they are ordered by the measured area they were selected on.

    The ports and the widest other port are worked out ONCE here and handed to every branch, which is exact: both
    are properties of the part and the representation, not of the mouth being asked about.

    `branched` is read off `GROUP_BRANCHED` when it is not given, at CALL time rather than at import time, so
    `eval/ask/intake_cost.py` can time the shipped limit and the limit lifted in one process under one load. A
    limit above the group size is the old per-mouth loop, value for value.
    """
    branched = GROUP_BRANCHED if branched is None else branched
    from geometry_agent.ask.uncertainty import builder_ports
    rep = str(document.get("representation") or "")
    ports = list(builder_ports(facts, rep))
    #: one `catalog.port_area` per port, once. `tools.builder_inlet` picks the widest port when nobody has named
    #: an inlet, so the widest other port is the first of these two that is not the mouth being asked about, and
    #: the order here is the order `max` would have walked so the pick is the same one
    area = {pt.id: _port_area(facts, pt, rep) for pt in ports}
    widest = sorted(area, key=lambda i: -area[i])[:2]
    port_ids = set(area)

    out: dict[str, Consequence] = {}
    inert = [u for u in us if not (u.places and u.places[0] in port_ids)]
    live = [u for u in us if u.places and u.places[0] in port_ids]
    if inert:
        once = consequence_of(inert[0], document, facts, ports=ports)
        for u in inert:
            out[u.id] = Consequence(**once.as_dict())
    for i, u in enumerate(sorted(live, key=lambda x: (-float(x.measurement.get("area_mm2") or 0.0), x.id))):
        oid = u.places[0]
        other = next((w for w in widest if w != oid), None)
        if i >= branched:
            out[u.id] = not_branched(
                "port_role", f"this part has {len(live)} mouths with an open role, and the one question they "
                             f"become names only the first few, so the counterfactual was run on the widest "
                             f"{branched} by measured area and this mouth is number {i + 1}")
        elif past(deadline):
            out[u.id] = not_branched("port_role", "question building passed its wall-clock ceiling")
        else:
            out[u.id] = consequence_of(u, document, facts, ports=ports, widest_other=other)
    return out


def rank_key(u: Any, c: Consequence) -> tuple[int, float, float, str]:
    """The order questions are put in: tier first, then how far apart the branches are, then size.

    The TIER ORDER is a decision and is argued in `schema.TIER_WHY`. Within a tier the sort is by measured
    quantities only: how far apart the two branches leave the cell count, and then the mouth's own area, so the
    port that carries most of the flow is asked about before a bleed hole.
    """
    rank = {t: i for i, t in enumerate(TIERS)}
    area = float(u.measurement.get("area_mm2") or 0.0)
    return (rank.get(c.tier, len(TIERS)), -(c.cells_ratio or 1.0), -area, u.id)


__all__ = ["BRANCHERS", "Consequence", "DECLARED_TIER", "FLOOR_FIELD", "GROUP_BRANCHED", "builder_inputs",
           "consequence_of", "deadline_in", "diff", "floor_tier", "not_branched", "past", "rank_key",
           "role_consequences"]
