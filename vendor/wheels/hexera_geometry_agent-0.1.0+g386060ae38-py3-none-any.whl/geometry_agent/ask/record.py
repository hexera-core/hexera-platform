"""What has to be stored for the customer's answer to be a LABEL, and not a line in a chat log.

THE POINT, and it is the part that makes the whole chain pay for itself. The survey says "o3, I cannot tell".
Intake asks. The customer says "that is a drain". We now have a labelled example, on a real part, from a
question we were going to ask anyway, at zero annotation cost. Do that on every job and the hard set builds
itself out of the work.

It only works if the answer can be JOINED BACK to the abstention that produced it, months later, by somebody
who was not there. That is a storage problem, not a modelling one, and this file is the storage contract.

THE FIVE THINGS, and dropping any one of them turns the label back into a chat log:

  1. WHICH PART       `source_sha256` and `facts_sha256`. The file, and the measurement of the file. Two
                      uploads of one file must collapse to one label; a re-measurement that changed the answer
                      must be visible as a different measurement of the same file.
  2. WHICH QUESTION   a `question_key` that is a pure function of the abstention, so the same abstention on the
                      same part re-derives the same key on a re-run and two runs do not produce two labels for
                      one fact. `question_key` below is that function.
  3. WHAT WAS UNSURE  the abstention itself: which field, what the measurement said, what the look said, and
                      the look field's TRUST TIER at the time. Without the tier a later reader cannot tell a
                      relied-on field's mistake from a recorded field's noise.
  4. WHAT PRODUCED IT the exact inputs. Agent sha, facts schema version, thresholds version, platform sha,
                      render version, vision prompt sha, reader model and provider. A label is about the part
                      forever; whether it is still reachable from the same abstention depends on all of these,
                      and a run that cannot say which it had cannot be replayed.
  5. WHO ANSWERED     `customer`, `operator`, or `defaulted`. SILENCE IS NOT AGREEMENT. A default applied
                      because nobody replied is not the customer saying anything, and recording it as one
                      would poison the set with our own priors, which is the worst possible failure here
                      because it is invisible and it compounds.

WHAT THIS IS NOT. Nothing here is model training. The labels are for measuring: a held-out set of real parts
with real answers, against which a rule, a threshold or a reader can be scored. `docs/learning_loop.md` owns
what is done with them.

THE RATCHET. `RATCHET_RULES` states the monotonicity the ledger has to enforce. A trust tier that gets demoted
stays demoted; a computation that gets added stays added; neither regresses on a later run that saw less. It is
here rather than in the ledger because it is a property of the LABELS, and the ledger is where it is enforced.

DIVISION OF LABOUR WITH gg_ledger: this file says WHAT must be stored and in what shape. It does not write a
row, open a store or decide a retention policy. `LEDGER_REQUIREMENTS` is the ask, in a form that can be read by
a test rather than by a person reading a paragraph.
"""
from __future__ import annotations

import hashlib
import json
from typing import Any

RECORD_SCHEMA = "geometry_agent.ask_record.v1"

#: Who the answer came from. `defaulted` is a first-class value and not an absence, because the difference
#: between "the customer told us" and "nobody replied and we went ahead" is the difference between a label and
#: a fabrication.
ANSWERED_BY: tuple[str, ...] = ("customer", "operator", "defaulted", "unanswered")

#: The answers that are labels. `defaulted` and `unanswered` are not, and `is_label` is what enforces it.
LABEL_SOURCES: frozenset[str] = frozenset({"customer", "operator"})


def question_key(kind: str, places: list[str], facts_sha256: str | None) -> str:
    """A stable id for one abstention on one measurement.

    A pure function of what the abstention IS: its kind, the measured places it names, and the measurement it
    was read from. It must not include a timestamp, a run id, a session id or a model name, or the same fact
    asked twice becomes two labels and the set silently double counts a part that was uploaded twice.
    """
    payload = json.dumps({"kind": kind, "places": sorted(str(p) for p in places or []),
                          "facts_sha256": str(facts_sha256 or "")}, sort_keys=True)
    return "qk_" + hashlib.sha256(payload.encode("utf-8")).hexdigest()[:16]


def provenance(document: dict[str, Any]) -> dict[str, Any]:
    """Everything about the run that would have to be the same for this abstention to arise again.

    Read off the document the surveyor already stamps (`report_measured`'s `stamp`, `look` and `triage` blocks).
    A key that is absent is written as None rather than left out, because a reader has to be able to tell "this
    run had no look" from "this row predates the field".
    """
    stamp = document.get("stamp") if isinstance(document.get("stamp"), dict) else {}
    look = document.get("look") if isinstance(document.get("look"), dict) else {}
    tri = document.get("triage") if isinstance(document.get("triage"), dict) else {}
    return {
        "agent_git_sha": stamp.get("agent_git_sha") or None,
        "facts_schema_version": stamp.get("facts_schema_version"),
        "measure_seconds": stamp.get("measure_seconds"),
        "occ_unit": stamp.get("occ_unit"),
        "platform_sha": tri.get("platform_sha") or stamp.get("platform_sha"),
        "look_status": look.get("status") or "failed",
        "look_model": look.get("model") or None,
        "look_provider": look.get("provider") or None,
        "look_views": len(look.get("views") or []) or None,
        #: filled by the caller when it has them; named here so a store that wants them has the column
        "render_version": stamp.get("render_version"),
        "vision_prompt_sha256": stamp.get("vision_prompt_sha256"),
        "thresholds_version": stamp.get("thresholds_version"),
    }


def _look_view(document: dict[str, Any], places: list[str]) -> dict[str, Any]:
    """What the look said about these places, WITH the trust tier of each field it said it in.

    The tiers come from `vision.trust`, which is the module that holds what five rounds measured, so a later
    reader does not have to know that `likely_role` is a coin flip: the row says so.
    """
    from geometry_agent.vision import trust
    look = document.get("look") if isinstance(document.get("look"), dict) else {}
    imp = look.get("impression") if isinstance(look.get("impression"), dict) else {}
    if not imp:
        return {"status": look.get("status") or "failed", "said": None, "tiers": {}}
    entries = {str(e.get("id") or "unlabelled"): e for e in (imp.get("openings_seen") or []) if isinstance(e, dict)}
    said = {p: entries.get(p) for p in (places or []) if p in entries}
    fields = ("openings_seen[].id", "openings_seen[].likely_role", "openings_seen[].looks_like",
              "openings_seen[].mouth")
    return {
        "status": look.get("status"),
        #: FOR THE LEDGER AND A PERSON, NEVER A MODEL (work/z-deliver NEEDS 7). `said` keeps each mouth's guessed
        #: role and class, which `vision/trust.py` tiers `recorded`: the answer record needs them to score the
        #: look against the answer, and no prompt is built from this row. Every model channel is `trust.for_model`
        #: or `trust.model_safe`, and `tests/test_complete_chain.py` pins that this row reaches neither
        "audience": "ledger",
        "said": said or None,
        "seen_set": sorted(entries),
        "tiers": {f: trust.tier_of(f, imp) for f in fields},
        #: the ledger stores this so a reader can see the abstention rate the round measured, beside the one
        #: instance in front of them
        "ledger": trust.LEDGER,
    }


def record_for(question: Any, document: dict[str, Any],
               uncertainties: list[Any] | dict[str, Any]) -> dict[str, Any]:
    """The row a question carries from the moment it is asked, before anybody has answered.

    ONE ROW PER PLACE, not per question. The role question names four mouths and one answer places all four, so
    `targets` has four entries and each becomes its own label. A question-shaped row would give one label for
    four facts and lose three of them.

    `uncertainties` is the list, or the `{id: uncertainty}` index of it. A caller writing a row for every
    question on a part builds the index once and passes it: rebuilding it per question was an index of every
    mouth per mouth, which on a part with 1,231 of them is 1.5 million inserts for one part's records.
    """
    facts_sha = (document.get("facts") or {}).get("sha256") if isinstance(document.get("facts"), dict) else None
    by_id = uncertainties if isinstance(uncertainties, dict) else {u.id: u for u in uncertainties}
    targets = []
    for uid in question.covers or []:
        u = by_id.get(uid)
        if u is None:
            continue
        for place in (u.places or [None]):
            targets.append({
                "uncertainty_id": u.id,
                #: the field this answer sets, in the SURVEYOR's vocabulary, so the label is joinable to the
                #: measurement and not only to the conversation
                "field": (f"openings[{place}].role" if place and u.kind == "port_role"
                          else _FIELD_OF.get(u.kind, u.kind)),
                "place": place,
                "proposed": u.fallback,
                "branches": list(u.branches),
                "abstention": u.abstention,
                "measurement": u.measurement,
            })
    return {
        "schema": RECORD_SCHEMA,
        "question_key": question_key(question.kind, question.places, facts_sha),
        "question_id": question.id,
        "kind": question.kind,
        "asked": question.asked,
        "settled_by": question.settled_by or None,
        "settled_quote": question.settled_quote or None,
        "text": question.text,
        "options": list(question.options),
        "default": question.default,
        "default_is": question.default_is,
        "source_sha256": document.get("source_sha256"),
        "facts_sha256": facts_sha,
        "representation": document.get("representation"),
        "purpose": document.get("purpose"),
        "engine": document.get("engine"),
        "targets": targets,
        "consequence": dict(question.consequence or {}),
        "look": _look_view(document, question.places),
        "provenance": provenance(document),
        #: filled when an answer arrives. Present and null so a reader can tell an unanswered row from an old one.
        "answer": None,
        "answered_by": "unanswered",
        "answered_at": None,
        "default_overturned": None,
    }


#: The field an answer sets for a kind that names no opening.
_FIELD_OF: dict[str, str] = {
    "unit": "unit.assumed",
    "fluid_side": "representation",
    "flow_direction": "flow.axis",
    "budget_envelope": "forecast.cell_cap",
    "dispatch_refusal": "triage.accepted",
    "unlabelled_mouth": "openings.complete",
    "look_dispute": "reconcile.disputed_claim",
    "opening_unseen": "look.openings_seen",
    "identity": "look.looks_like",
}


def answered(row: dict[str, Any], answer: str, *, by: str, at: str) -> dict[str, Any]:
    """The same row with an answer on it, and `default_overturned` computed.

    `by` must be one of `ANSWERED_BY`. A row whose `by` is `defaulted` or `unanswered` is NOT a label and
    `is_label` says so: the default being applied is this pipeline acting, not the customer speaking.
    """
    if by not in ANSWERED_BY:
        raise ValueError(f"answered_by must be one of {ANSWERED_BY}, not {by!r}")
    out = dict(row)
    out["answer"] = answer
    out["answered_by"] = by
    out["answered_at"] = at
    out["default_overturned"] = (by in LABEL_SOURCES
                                 and _norm(answer) != _norm(row.get("default") or ""))
    return out


def _norm(s: Any) -> str:
    return " ".join(str(s or "").strip().lower().replace("_", " ").split())


def is_label(row: dict[str, Any]) -> bool:
    """Whether this row is ground truth about a real part, or only a record of what we did."""
    return str(row.get("answered_by")) in LABEL_SOURCES and bool(row.get("answer"))


# -----------------------------------------------------------------------------------------------------------
# what gg_ledger has to provide. Stated as data so a test can check the ask has not drifted from what is built.
# -----------------------------------------------------------------------------------------------------------

#: The columns a store has to carry for a row here to be joinable later. `why` is the failure that happens
#: without the column, not a description of it, because a column with a description gets dropped in a migration
#: and a column with a named failure does not.
LEDGER_REQUIREMENTS: dict[str, str] = {
    "question_key": "the join key. Without it a part uploaded twice is two labels and the set double counts.",
    "source_sha256": "the file. Without it a label cannot be found again from the customer's own upload.",
    "facts_sha256": "the measurement. Without it a re-measurement that changed the answer is invisible.",
    "targets[].field": "what the answer sets, in the measurement's vocabulary. Without it the answer joins to "
                       "the conversation and not to the geometry, which is a chat log.",
    "targets[].proposed": "what we would have done unasked. Without it `default_overturned` cannot be "
                          "computed, and that flag is the entire signal: an answer that agrees with the "
                          "default teaches nothing, an answer that overturns it is the finding.",
    "answered_by": "customer, operator, defaulted or unanswered. Without it a default applied in silence is "
                   "indistinguishable from a customer agreeing, and the set fills with our own priors.",
    "provenance.agent_git_sha": "which code asked. Without it the run cannot be replayed.",
    "provenance.facts_schema_version": "which measurement asked.",
    "provenance.look_model": "which reader looked, if one did. A tier measured on gpt-5.6-luna is not a claim "
                             "about another reader.",
    "look.tiers": "the trust tier of every look field the abstention rests on, AT THE TIME. Without it a later "
                  "reader cannot tell a relied-on field's mistake from a recorded field's noise.",
    "consequence.tier": "why it was worth asking. Without it we cannot later ask whether we asked the right "
                        "questions, which is the only way this list gets shorter.",
}

#: What the ledger must refuse to do. Each is a monotonicity: it may move one way and not back.
RATCHET_RULES: tuple[dict[str, str], ...] = (
    {"on": "trust tier of a look field",
     "rule": "a demotion is permanent. A field demoted from relied_on to candidate may be promoted again only "
             "by a later measurement with strictly more evidence than the one that demoted it.",
     "because": "the demotion was paid for with a measured failure. A single later run that happens to look "
                "clean is not evidence against it, and eight byte-identical passes of one configuration span "
                "94 to 104 on the old hold-out, so one run cannot be significant (four draws)."},
    {"on": "a computation added because an answer contradicted us",
     "rule": "once a check is added it is not removed by a run that does not fire it.",
     "because": "a check that never fires is cheap; a check removed because it was quiet is the failure "
                "returning."},
    {"on": "a question demoted to settled",
     "rule": "the question is never deleted. It is carried with asked False, its options and its default, and "
             "an answer to it still overrules whatever settled it.",
     "because": "R9 deleted a real question on 261 of 322 briefs and no instrument noticed for two rounds "
                "(docs/audit_2026-09-11.md section 9). Demote, record the quote, keep the override."},
    {"on": "a label whose answer came from a default",
     "rule": "it never becomes a label later. `answered_by` is set once, at the time, and is not revised.",
     "because": "silence is not agreement, and a set that quietly promotes its own defaults measures itself."},
)


__all__ = ["ANSWERED_BY", "LABEL_SOURCES", "LEDGER_REQUIREMENTS", "RATCHET_RULES", "RECORD_SCHEMA", "answered",
           "is_label", "provenance", "question_key", "record_for"]
