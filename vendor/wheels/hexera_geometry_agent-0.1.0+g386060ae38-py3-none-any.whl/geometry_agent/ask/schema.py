"""The three objects the bridge from the surveyor to intake is made of, and nothing else.

    Uncertainty   what the surveyor is honestly unsure about, in the surveyor's own vocabulary
    Consequence   what the answer would change in the builder's inputs, computed by branching
    Question      the uncertainty said the way a person asks it, with one default

They are separate on purpose. An `Uncertainty` is a reading of the measurement document and is true whether or
not anybody is ever asked. A `Consequence` is a counterfactual over the builder's own inputs and is the only
thing entitled to decide that a question is not worth asking. A `Question` is prose for a customer. Collapsing
the three into one record is how a list of forty field dumps gets built.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Literal

ASK_SCHEMA = "geometry_agent.ask.v1"

#: The kinds of uncertainty the surveyor already produces. Each one names a thing the surveyor DECLINED to
#: decide, never a thing it got wrong: the abstention is the input, and a kind that cannot point at an
#: abstention in `report_measured` does not belong here.
KINDS: tuple[str, ...] = (
    #: the measurement finds a mouth and nothing settles what it is for
    "port_role",
    #: the look reports a mouth under the id `unlabelled`, which is the one thing no measurement here supplies
    "unlabelled_mouth",
    #: external: which way the flow comes at the body. The measurement has a blunt end and a confidence in it
    "flow_direction",
    #: the file settles no length unit and nothing else has
    "unit",
    #: which side of the surface is the fluid: the geometry reads the same both ways (`catalog.side_reading`)
    "fluid_side",
    #: the builder emulator's envelope does not fit the cell budget the customer already stated
    "budget_envelope",
    #: the platform's own pre-mesh rules, as the surveyor predicts them, would refuse this file as declared
    "dispatch_refusal",
    #: the look and the measurement give two readings of the same place and neither outranks the other
    "look_dispute",
    #: a measured mouth the look never named. RECORDED, never asked: the measurement already has it
    "opening_unseen",
    #: a name resting on the picture alone, capped at 0.6. ADVISORY, never asked: a name drives no builder input
    "identity",
)

#: WHAT THE ANSWER CHANGES, in the builder's own inputs. This is the whole ranking and it is a LEXICOGRAPHIC
#: ORDER, not a score: there is no measured exchange rate between a wrong boundary condition and a coarse mesh,
#: and inventing one would be a magic number. The order is Rehaan's rule read literally, worst consequence
#: first, and `TIER_WHY` states each one's argument so a reader can disagree with the order rather than with a
#: number that hides it.
TIERS: tuple[str, ...] = ("dispatch", "boundary", "domain", "resolution", "none")

TIER_WHY: dict[str, str] = {
    "dispatch": "the answer decides whether the job runs at all; nothing below this matters if it does not",
    "boundary": "the answer decides which face carries which boundary condition, which is a wrong answer "
                "rather than a coarse one",
    "domain": "the answer decides what volume is meshed: the representation, the flow axis or the domain box",
    "resolution": "the answer decides how finely it is meshed: the bore the cell size is set against, or the "
                  "cell ceiling",
    "none": "every branch of this question produces the same builder inputs, so it is not asked",
}

#: The builder input fields a branch is compared on. Every one is something a named platform reader consumes
#: (`hexera.HANDOVER_READERS`, `hexera.DIRECTIVE_KEYS`, `hexera.planner_block`); a field no reader consumes
#: cannot carry a consequence and is not in this list.
BUILDER_FIELDS: tuple[str, ...] = (
    "dispatch",           # triage.verdict: buildable / needs_fix / do_not_dispatch
    "patch_roles",        # opening id -> inlet / outlet / wall / closed_end
    "representation",     # carve / fluid_domain / wall_shell / external
    "flow_axis",          # snappy_runner.py:311-335 domain_from_strategy
    "domain_box",         # the box that axis builds, corner by corner, not its volume
    "scale_to_metres",    # the one number every length in planner_block is multiplied by
    "inlet_opening_id",   # the opening cells_across_diameter is set against
    "inlet_bore",         # its bore, in the file's own numbers
    "max_cells",          # hexera.budget: min(the customer's cap, the corrected envelope)
    "cells_high",         # the emulator's own upper figure
)

#: Which tier a difference in each builder field lands in.
#:
#: `domain_box` IS ON THIS LIST BECAUSE OF A BLIND SPOT THIS PROJECT HAS BEEN CAUGHT BY EIGHT TIMES. Reverse the
#: flow axis on an external body and `tools._external_domain` swaps the up and down margins: the box moves, the
#: wake refinement lands upstream, and the box's EXTENT does not change, so the cell count does not move by a
#: single cell. A ranker built on the emulator's cell count alone would score that answer as changing nothing
#: and delete the question, because the emulator counts cells and the mistake is not a cell mistake. The box
#: corners are compared, not the count. `tests/test_ask_consequence.py` holds that case.
FIELD_TIER: dict[str, str] = {
    "dispatch": "dispatch",
    "patch_roles": "boundary",
    "representation": "domain",
    "flow_axis": "domain",
    "domain_box": "domain",
    "scale_to_metres": "domain",
    "inlet_opening_id": "resolution",
    "inlet_bore": "resolution",
    "max_cells": "resolution",
    "cells_high": "resolution",
}

#: How a question stopped being asked. NEVER deleted: a settled question keeps its text, its options and its
#: default, and is carried with `asked` False so the summary can name the assumption and an answer can still
#: overrule it. This is `confirm.overrulable`'s contract and the reason P4.4 exists.
#:
#: The first three are SOMEBODY ELSE answering: the declaration, the brief, the file. The last two are US
#: deciding not to ask, which is a different thing and is spelled differently on purpose. A reader auditing
#: whether the product over-asks wants the first three; a reader auditing whether it under-asks wants the last
#: two, and a single word for both would hide the second reader's question entirely.
SETTLED_BY: tuple[str, ...] = ("declaration", "brief", "file", "no_consequence", "below_the_cap")

#: The two of those that are this pipeline's own choice rather than an answer from outside.
OUR_CHOICE: frozenset[str] = frozenset({"no_consequence", "below_the_cap"})


@dataclass
class Uncertainty:
    """One thing the surveyor declined to decide.

    `places` are ids in the measurement's own vocabulary (opening ids), never coordinates and never a builder
    setting. `abstention` quotes what the surveyor actually said, so a reader can check that the uncertainty is
    the surveyor's and not this module's invention.
    """
    id: str
    kind: str
    places: list[str]
    #: what is unknown, in one clause, for a developer
    unknown: str
    #: where in the measurement document this was read from
    source: str
    #: what the surveyor said, verbatim where it said anything
    abstention: str = ""
    #: the branches an answer could take, in the surveyor's vocabulary
    branches: list[str] = field(default_factory=list)
    #: the branch taken when nobody answers, which must be what the pipeline does today
    fallback: str = ""
    #: the measured numbers behind it, for the record and for the wording
    measurement: dict[str, Any] = field(default_factory=dict)
    #: other uncertainty ids this one answer settles (four unassigned legs are one question, not four)
    also: list[str] = field(default_factory=list)

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class Consequence:
    """What the answer changes in the builder's inputs, by actually branching and diffing.

    `changes` is the set of `BUILDER_FIELDS` that differ between branches, `tier` the worst of their tiers, and
    `evidence` the differing values themselves so a reader can see the counterfactual rather than trust it.
    `computed` is False when a branch could not be evaluated, and then the tier is the declared floor for the
    kind rather than a measurement: an uncomputable consequence is never silently read as no consequence.
    """
    tier: str
    changes: list[str]
    evidence: dict[str, Any] = field(default_factory=dict)
    computed: bool = True
    why: str = ""
    #: the widest ratio between branches on `cells_high`, when the branches differ there. A real number, and the
    #: only quantity in this object that is one.
    cells_ratio: float | None = None

    @property
    def worth_asking(self) -> bool:
        return self.tier != "none"

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class Question:
    """One question for one customer, in prose, with one default.

    THE DEFAULT RULE, which is the one dev_plan_v3 finding 10 was about: a default is either an acceptance the
    reader can give or an operation this pipeline performs. It is never an instruction to change the CAD, and
    never a control the reader does not have. `default_is` says which of the two it is, and a test asserts that
    every question carries one.
    """
    id: str
    kind: str
    text: str
    options: list[str]
    default: str
    default_is: Literal["acceptance", "operation"]
    #: why this is worth a customer's attention, in the builder's terms
    because: str
    tier: str
    effect: str
    places: list[str]
    #: the uncertainty ids this question covers, its own first
    covers: list[str] = field(default_factory=list)
    #: True when the question is put; False when something settled it and it rides along demoted
    asked: bool = True
    settled_by: str = ""
    settled_quote: str = ""
    consequence: dict[str, Any] = field(default_factory=dict)
    #: everything needed for the answer to become a label; `ask.record` builds it
    record: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


__all__ = ["ASK_SCHEMA", "BUILDER_FIELDS", "Consequence", "FIELD_TIER", "KINDS", "OUR_CHOICE", "Question",
           "SETTLED_BY", "TIERS", "TIER_WHY", "Uncertainty"]
