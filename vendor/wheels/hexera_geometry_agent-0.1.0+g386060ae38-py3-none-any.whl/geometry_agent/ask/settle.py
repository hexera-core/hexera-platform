"""What already answers a question, so it is not put to the customer again.

THE RULE THIS FILE EXISTS FOR, and the whole reason it is a separate module with a test of its own.

A phrase settles a question ONLY WHEN IT SELECTS ONE OF THAT QUESTION'S OWN OPTIONS. A phrase that merely
mentions the question's subject settles nothing.

That is not a style preference, it is the shape of a bug this project has already paid for. Checker R9 read
"fixed pressure outlet" as settling the short-outlet question on 261 of the 322 export briefs and deleted the
warning that mattered on every one of them, and no instrument said so until `eval/live/question_scorer.py` was
written specifically to audit it (docs/audit_2026-09-11.md section 9, docs/dev_plan_v3.md finding 9). "Fixed
pressure outlet" is a boundary condition value. The question was "extend the run, or accept it". The phrase
answers neither option, so under the rule below it cannot be a settle pattern at all, and
`tests/test_ask_settle.py` asserts that every pattern here names an option its question actually offers.

The consequence of the rule is that most brief prose settles nothing, which is correct and is why there are
only three patterns in this file. The strong settle test is not a phrase at all: it is a DECLARED PORT AT THE
MEASURED OPENING, which is structural, needs no natural language, and works on a stranger's file the moment
intake has a port row. `declaration_settles` is that test.

NOTHING IS EVER DELETED. `settled(...)` reports WHAT settled a question and WHICH option it selected; the
caller keeps the question, marks it `asked=False` and records the quote, so the summary can name the assumption
and `confirm.apply_answers` can still take an answer that overrules it. That is P4.4's contract and this module
does not get to break it.
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass
from typing import Any

#: A declared port matches a measured opening when its point is within this fraction of the opening's own
#: hydraulic diameter, or 2 percent of the bounding diagonal for a face with no diameter. The same band
#: `evaluate._nearest_opening` uses, which is the band the corpus expectations were matched under.
NEAR_OVER_D = 0.6
NEAR_OVER_DIAGONAL = 0.02


@dataclass(frozen=True)
class SettlePattern:
    """One brief phrase that answers one question, and the option it selects.

    `selects` is the field every pattern here has to fill and the field that makes the rule enforceable: if you
    cannot name the option the phrase chooses, the phrase is not an answer and the pattern does not go in.
    """
    kind: str
    #: the option this phrase selects, spelled exactly as the question's own option list spells it. It may be a
    #: template over the pattern's named groups (`along {sign}{axis}`), filled lower-case from the match, for a
    #: phrase whose option depends on what it says; the filled option is still checked against the offer list.
    selects: str
    pattern: str
    why: str

    def search(self, text: str) -> str:
        """The matched phrase, verbatim, so the record can quote what settled it. Empty when it does not match."""
        hit = re.search(self.pattern, text or "", re.I)
        return hit.group(0).strip() if hit else ""

    def selected(self, text: str) -> str:
        """The option this phrase selects in `text`, template filled, or empty when it does not match."""
        hit = re.search(self.pattern, text or "", re.I)
        if not hit:
            return ""
        if "{" not in self.selects:
            return self.selects
        groups = {k: (v or "").lower() for k, v in hit.groupdict().items()}
        try:
            return self.selects.format(**groups)
        except (KeyError, IndexError):
            return ""


#: Every pattern, and there are deliberately few. Each states the option it selects; a pattern that cannot is
#: not a settle pattern.
PATTERNS: tuple[SettlePattern, ...] = (
    SettlePattern(
        kind="port_role", selects="wall",
        pattern=r"all remaining surfaces are (?:the )?wall|remaining surfaces are (?:the )?walls?|"
                r"everything else is (?:the )?wall",
        why="the question is 'what is this opening for', and `wall` is one of its options. A brief that says "
            "every surface it has not named is wall selects that option for every opening no declaration "
            "names. It is a blanket answer and a weak one, which is why the question is kept and demoted "
            "rather than deleted: a customer who forgot a drain can still overrule it.",
    ),
    SettlePattern(
        kind="port_role", selects="closed for this run",
        pattern=r"(?:blank(?:ed)?|cap(?:ped)?|plug(?:ged)?|closed) (?:off )?for th(?:is|e) run",
        why="selects the `closed for this run` option by name.",
    ),
    #: THE FLOW DIRECTION, and the pattern that used to stand here settled nothing on any part. It selected "keep
    #: the measured direction", which no flow question offers (`say.flow_direction` offers `along +x`, `along
    #: -x` and "it does not matter"), so the rule at the point of use refused it every time; and it did not
    #: match "Flow is along +X.", which is how all 61 external corpus briefs say it. So the brief that states the
    #: direction was asked the direction anyway. The sign is required: "along X" is an axis and not a direction,
    #: and "flow comes from +x" is left out on purpose, because "from +x" reads as either travelling along +x or
    #: arriving from the +x side, and a phrase with two readings is not an answer.
    SettlePattern(
        kind="flow_direction", selects="along {sign}{axis}",
        pattern=r"\bflow (?:is |runs |travels |goes )?along (?:the )?(?P<sign>[+-])\s?(?P<axis>[xyz])\b",
        why="the question is which way the flow comes at the body, and a brief that names the axis AND the sign "
            "selects the option that says the same thing.",
    ),
    SettlePattern(
        kind="flow_direction", selects="along {sign}{axis}",
        pattern=r"\bfree ?stream (?:is |runs )?along (?:the )?(?P<sign>[+-])\s?(?P<axis>[xyz])\b",
        why="the same answer in the other common phrasing.",
    ),
)

#: Phrases that have been mistaken for settle patterns here and are NOT, kept in code so the next person does
#: not add them back. `tests/test_ask_settle.py` asserts none of them settles anything.
NOT_SETTLES: dict[str, str] = {
    "fixed pressure outlet": "a boundary condition value. It says which condition an outlet carries, not which "
                             "opening is the outlet, and not whether a short run may be extended. It cost 261 "
                             "of 322 briefs a deleted warning at R9.",
    "mesh budget: under 2 million cells": "the sentence the cap was READ FROM. It is the question's input, not "
                                          "its answer: the question is whether to drop the tier or raise the "
                                          "cap, and the budget sentence chooses neither "
                                          "(docs/audit_2026-09-11.md section 8).",
    "steady state, incompressible": "a physics setting. It selects no option of any question in this module.",
    "geometry is in millimetres": "this settles the UNIT question and nothing else; it is listed here because "
                                  "it has been read as settling a role question, which it does not.",
}


def _dist(a: Any, b: Any) -> float:
    try:
        return math.dist([float(x) for x in a], [float(y) for y in b])
    except (TypeError, ValueError):
        return float("inf")


def declaration_settles(opening: dict[str, Any], declared: list[dict[str, Any]] | None,
                        diagonal_mm: float | None = None) -> dict[str, Any] | None:
    """The declared port row that sits at this measured opening, or None.

    THE STRONG TEST, and the only one that needs no natural language. `opening` is a row of the measurement
    document's own opening table (`hexera._opening_row`), so its point is `centroid_mm`; a declared row's point
    is `near`, which intake already holds in millimetres (`validation.py:289`). Both sides are the surveyor's
    and intake's own numbers and neither is a model's.

    It returns the ROW, not a verdict, so the caller can record which declaration settled which opening and, if
    the row carries no role, still know that the customer has spoken about this place.
    """
    point = opening.get("centroid_mm")
    if not point or not declared:
        return None
    tol = _band_mm(opening, diagonal_mm)
    if tol <= 0:
        return None
    best, best_d = None, None
    for row in declared:
        if not isinstance(row, dict):
            continue
        near = row.get("near") or row.get("near_mm")
        if not near:
            continue
        d = _dist(point, near)
        if best_d is None or d < best_d:
            best, best_d = row, d
    return best if (best is not None and best_d is not None and best_d <= tol) else None


def _band_mm(opening: dict[str, Any], diagonal_mm: float | None) -> float:
    """How close a declared point must sit to this mouth to be AT it.

    A RING'S BAND IS ITS BORE. `hydraulic_diameter_mm` on a ring is the ring FACE's own, which for a flanged mouth
    is the flange annulus: 233 mm on `mini_housing_008`'s o1 against a 72.9 mm bore, so a band of 0.6 of it
    reached a declared outlet 96 mm away that belongs to another mouth.
    """
    d = (opening.get("bore_diameter_mm") if opening.get("kind") == "ring" else None) \
        or opening.get("hydraulic_diameter_mm") or 0.0
    return (NEAR_OVER_D * float(d)) or (NEAR_OVER_DIAGONAL * float(diagonal_mm or 0.0))


def bind_declared(openings: list[dict[str, Any]], declared: list[dict[str, Any]] | None,
                  diagonal_mm: float | None = None) -> dict[str, dict[str, Any]]:
    """`{opening_id: declared row}`, ONE TO ONE: every row sits at one mouth at most, and every mouth takes one row.

    `declaration_settles` asks each mouth in turn for the nearest row within its band, and nothing stopped one
    row answering for several mouths. On the export corpus that settled 5 extra mouths on 2 of the 261 parts with
    rows (`eval/chain/run_chain.py` era, measured, deterministic): on `mini_housing_008` the customer's `outlet_1`
    settled o1, o3 and o6, and o1 and o3 are the housing's own flanged ends. The plan, binding one to one,
    called them walls, and the chain's check then refused the plan for contradicting a statement the customer
    never made. Here the pairs are taken nearest first, as a fraction of the mouth's own band, and a row or a
    mouth once taken is not offered again.
    """
    if not declared:
        return {}
    pairs: list[tuple[float, int, str, dict[str, Any]]] = []
    for i, row in enumerate(declared):
        if not isinstance(row, dict):
            continue
        near = row.get("near") or row.get("near_mm")
        if not near:
            continue
        for o in openings:
            point = o.get("centroid_mm")
            band = _band_mm(o, diagonal_mm)
            if not point or band <= 0:
                continue
            dist = _dist(point, near)
            if dist <= band:
                pairs.append((dist / band, i, str(o.get("id")), row))
    out: dict[str, dict[str, Any]] = {}
    used: set[int] = set()
    for _score, i, oid, row in sorted(pairs, key=lambda p: (p[0], p[1], p[2])):
        if i in used or oid in out:
            continue
        out[oid] = row
        used.add(i)
    return out


def brief_settles(kind: str, options: list[str], brief: str | None) -> tuple[str, str] | None:
    """`(option, quote)` when a phrase in the brief selects one of this question's own options, else None.

    The option is checked against `options` before it is returned. A pattern whose `selects` is not on offer
    cannot settle the question it was filed under, which is the rule stated at the top of this file enforced at
    the point of use as well as in the test.
    """
    if not brief:
        return None
    offered = {str(o).strip().lower(): str(o) for o in options or []}
    for pat in PATTERNS:
        if pat.kind != kind:
            continue
        chosen = pat.selected(brief).lower()
        if not chosen or chosen not in offered:
            continue
        return offered[chosen], pat.search(brief)
    return None


#: The blanket answer. It says "every surface the brief did not name is wall", which settles a mouth only once
#: the named ports are ACCOUNTED FOR. With no port rows, or with a named port that binds to no measured mouth,
#: "remaining" has no referent: the brief's prose names an inlet and an outlet that nothing here has placed, so
#: reading the blanket over every mouth would settle the inlet itself as wall. That is what `ask_intake` did on a
#: brief with no rows, and the corpus arms never showed it because one arm had rows and the other had no brief.
BLANKET_WALL = "wall"


def blanket_applies(bound: dict[str, dict[str, Any]], declared: list[dict[str, Any]] | None) -> bool:
    """Whether a blanket "remaining surfaces are wall" may settle the mouths no declaration named.

    `bound` is `{opening_id: declared row}` for every measured mouth a row sits at. The blanket applies only when
    there are roled rows and every one of them is bound to a mouth: then "remaining" means exactly the unbound
    mouths. Otherwise a named port is somewhere this measurement has not placed, and the blanket would bury it.
    """
    roled = [d for d in (declared or []) if isinstance(d, dict)
             and str(d.get("role") or d.get("type") or "") in ("inlet", "outlet")]
    if not roled:
        return False
    placed = [id(row) for row in bound.values()]
    return all(id(d) in placed for d in roled)


def unit_settled_by_file(document: dict[str, Any]) -> tuple[bool, str]:
    """Whether the FILE settles its own unit, and what said so.

    The file settles it when the transfer read a unit out of the file itself (`step_header`, `step_body`). It
    does not when the format carries none, which is every STL, OBJ and PLY, and then `coordinates.scale_to_metres`
    is null and every length in the planner block is null with it (`hexera.planner_block`). That is the one
    place where an unanswered question stops the builder from being given a number at all.
    """
    unit = document.get("unit") or {}
    src = str(unit.get("declared_source") or "none")
    if src in ("step_header", "step_body") and unit.get("declared"):
        return True, f"the file's own {src.replace('_', ' ')} declares {unit.get('declared')}"
    return False, ""


__all__ = ["BLANKET_WALL", "NEAR_OVER_D", "NEAR_OVER_DIAGONAL", "NOT_SETTLES", "PATTERNS", "SettlePattern",
           "bind_declared", "blanket_applies", "brief_settles",
           "declaration_settles", "unit_settled_by_file"]
