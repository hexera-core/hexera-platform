"""The surveyor's abstentions, turned into the short list of questions intake puts to the customer.

WHERE THIS SITS IN REHAAN'S CHAIN.

    SURVEYOR understands the CAD and hands it to INTAKE.
    INTAKE asks the customer "I noticed this, this and this", and confirms.
    THE GEOMETRY AGENT then decides everything it needs, using the confirmations intake got.
    Intake's write-up and the geometry agent's write-up both go to the BUILDER,
    and the surveyor's information goes in WITH the geometry agent's write-up.

This module is the arrow from the first box to the second, and it is the only one of the four arrows that did
not exist. `hexera.report_measured` is the surveyor's document. `ask_intake` turns it into questions.
`ask.record` says what to store so the answers come back as labels. `confirm.apply_answers` already takes the
answers and produces the confirmed plan the geometry agent works from, so the arrow from the second box to the
third is built: `as_user_questions` below hands this module's questions to it in the shape it already reads.

THE ARCHITECTURAL RULE, and it is Rehaan's call, not a preference. The geometry agent decides what to DO and
where to spend the cells. It must NOT re-decide what the geometry IS. So nothing this module produces is a
suggestion for the geometry agent to re-derive: the measurements arrive as facts, and what travels forward is
the customer's ANSWER to a thing the measurement was honestly silent about. There is one answer to one
question and no second place to look it up.

OFF BY DEFAULT. Nothing in the shipping path imports this package. `report_measured` does not call it,
`planner_block` does not carry it, and no default anywhere changes because these files exist. It is called by
`eval/ask/corpus.py` and by tests, and it is wired into the product the day somebody decides to wire it in.

THE FOUR CUTS between "everything the surveyor is unsure about" and "the two questions the customer sees", in
the order they are applied, because the order is the design:

    1. SOMEBODY ALREADY ANSWERED IT      a declared port at the mouth, or a brief phrase that selects one of
                                         this question's own options (`ask.settle`, and the rule there is what
                                         stops the R9 class of mistake)
    2. THE ANSWER CHANGES NOTHING        both branches give the builder the same inputs (`ask.consequence`)
    3. IT IS THE SAME QUESTION           four unplaced mouths are one question naming four mouths
    4. IT IS BELOW THE CAP               ranked by consequence, the rest held back

NOTHING IS DELETED BY ANY OF THE FOUR. Every question survives in `held`, with its text, options and default
intact and `settled_by` naming which cut it fell to, so the summary can state the assumption and an answer to
it still overrules whatever settled it.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from geometry_agent.ask import consequence as conseq
from geometry_agent.ask import record as arecord
from geometry_agent.ask import say, settle, uncertainty
from geometry_agent.ask.schema import ASK_SCHEMA, TIER_WHY, TIERS, Question, Uncertainty

#: How many questions are put at once. FIVE. It was THREE, which was the bar the corpus expectations set
#: (`max_questions 3` on a clean first-time pass, `docs/corpus_export.md`) and the bar the live intake is scored
#: against. A median above about three is still a product problem, not a tuning problem, and the median does not
#: move: `eval/ask/corpus.py` reports it so the claim can be checked rather than asserted.
#:
#: WHY IT MOVED, and the number that decided it. On the 322-part export corpus three held nothing back at all
#: (cut 4 fired 0 times, docs/asking.md) and five holds nothing back either, because no corpus part has more
#: than three questions to put. What three was wrong about is a file with no unit. `eval/hard_real` is STL, so
#: the unit question is live, and with the fluid-side question asked as well the budget of three was already
#: full: `fluid_side` is tier `domain` ("the answer decides what volume is meshed") and `unit` is tier
#: `resolution` ("how finely"), domain outranks resolution, and the unit question went below the cap on 6 of the
#: 19 parts. The ranking was right by its own tiers and the outcome was still wrong, because a guessed unit is
#: the 1,000x error this package exists to prevent and its absence ships the handoff `degraded` with every
#: length null. At five those six get their unit question back, the most any part is asked is four, and nothing
#: anywhere else changes. The tier order is untouched: what changed is how many of the ranked list are put, not
#: which comes first.
#:
#: THE ONE QUESTION BUDGET ON THE LIVE CHAIN (synthesis C18: one constant in one place, both numbers beside it).
#: `chain/bridge.QUESTION_LIMIT = 5` counted role questions PER MOUTH, and at 5 its replay left 483 role
#: questions unasked, 145 of them with an answer in the brief. Here a role question is ONE question naming every
#: open mouth, so one grouped question carries more mouths than 5 per-mouth ones ever did. Five is also the
#: faster learning rate (C18: a two-job shop reaches 282 answers on one topic in 113 months at 5 against 188 at
#: 3, PAPER); ties inside a tier still go to the topic the ledger has seen least (`asked_before`), which is what
#: mattered most while the cap was the binding constraint. What five costs is two more of a customer's answers,
#: and no study I could find prices that for an engineer mid-upload (research_learning_from_answers.md section
#: 6.3). `chain/job.py` reads this constant and no other.
MAX_ASKED = 5

#: THE WALL CLOCK QUESTION BUILDING IS GIVEN, in seconds, and why there is one at all. `ask_intake` is step 4 of
#: the chain with a person waiting, and it used to have no ceiling: on a part with 1,231 open mouths it did not
#: finish in 900 s, while measuring the same part takes a minute. `consequence.role_consequences` made the cost
#: linear in the mouths and that part now runs in under five, so this is a BACKSTOP against a part bigger than
#: anything measured, not a latency target. Past it, no further branch is evaluated: every question is still put,
#: with `consequence.not_branched`'s floor tier and a `why` that names the ceiling, so a run that hits it says so
#: instead of stopping.
#:
#: IT IS THE ONE THING IN THIS MODULE THAT IS NOT DETERMINISTIC, so it is set where nothing measured can reach it
#: and a firing is a real event rather than a slow afternoon. That is why it is not 60: the same 1,231-mouth part
#: read 4.65 s and 4.84 s on two quiet passes of four draws, and 57.8 s with the test suite running beside it,
#: because almost every second here is `catalog.port_area` paying `agent.thresholds.current()` for a file stat
#: and a path resolve, and that cost moves with the OS file cache. A ceiling a twelvefold load can cross would
#: rewrite an eval's answers and call it a timeout. Five minutes is 60 times the quiet figure and five times the
#: loaded one, and it still turns a 900 s hang into an answer. If it ever does fire the ranking under it depends
#: on the clock and the run is no longer reproducible; the `why` on every affected question is what tells a
#: reader that happened, and `None` turns it off.
QUESTION_SECONDS: float | None = 300.0


@dataclass
class Asked:
    """What intake puts to the customer, and everything it decided not to put, with the reason for each."""
    schema: str
    case: str
    uncertainties: list[Uncertainty] = field(default_factory=list)
    questions: list[Question] = field(default_factory=list)
    held: list[Question] = field(default_factory=list)

    @property
    def count(self) -> int:
        return len(self.questions)

    def summary(self) -> dict[str, Any]:
        """The counts, and why each held question is held. The shape `eval/ask/corpus.py` aggregates."""
        reasons: dict[str, int] = {}
        for q in self.held:
            reasons[q.settled_by or "unknown"] = reasons.get(q.settled_by or "unknown", 0) + 1
        return {"case": self.case, "uncertainties": len(self.uncertainties), "asked": len(self.questions),
                "held": len(self.held), "held_because": reasons,
                "tiers": [q.tier for q in self.questions],
                "kinds": [q.kind for q in self.questions]}

    def as_dict(self) -> dict[str, Any]:
        return {"schema": self.schema, "case": self.case,
                "uncertainties": [u.as_dict() for u in self.uncertainties],
                "questions": [q.as_dict() for q in self.questions],
                "held": [q.as_dict() for q in self.held]}


def bound_declarations(roles: list[Uncertainty], document: dict[str, Any],
                       declared: list[dict[str, Any]] | None) -> dict[str, dict[str, Any]]:
    """`{opening_id: declared row}` for every role mouth a customer's port row sits at (cut 1's strong test), one
    to one (`settle.bind_declared`): a row answers for one mouth, never for every mouth within reach of it."""
    rows = {str(r.get("id")): r for r in (document.get("openings") or []) if isinstance(r, dict)}
    diag = (document.get("bbox") or {}).get("diagonal_mm")
    mouths = [rows[u.places[0]] for u in roles if u.places and u.places[0] in rows]
    return settle.bind_declared(mouths, declared, diag)


def _settle_role(u: Uncertainty, bound: dict[str, dict[str, Any]], blanket_ok: bool,
                 brief: str | None) -> tuple[str, str]:
    """`(settled_by, quote)` for one mouth, or `("", "")`.

    A brief phrase about port roles is a BLANKET ("all remaining surfaces are the wall"), and it settles a mouth
    only when every roled port row is bound to a measured mouth, so "remaining" means the unbound ones
    (`settle.blanket_applies`). Without that gate a brief with no port rows settled every mouth as wall,
    including the inlet it names in prose.
    """
    hit = bound.get(u.places[0]) if u.places else None
    if hit is not None:
        role = str(hit.get("role") or hit.get("type") or "named")
        return "declaration", f"your port list names this mouth as {role}"
    if not blanket_ok:
        return "", ""
    got = settle.brief_settles("port_role", list(u.branches), brief)
    if got:
        return "brief", got[1]
    return "", ""


def _hold(q: Question, why: str, quote: str = "") -> Question:
    q.asked = False
    q.settled_by = why
    q.settled_quote = quote
    return q


def ask_intake(document: dict[str, Any], *, case: str = "", declared: list[dict[str, Any]] | None = None,
               brief: str | None = None, reconciliation: Any = None, max_asked: int = MAX_ASKED,
               alerts: Any = None, asked_before: dict[str, int] | None = None,
               seconds: float | None = QUESTION_SECONDS) -> Asked:
    """The questions for one part, from the surveyor's own document.

    `declared` is intake's port rows when it has them, and None at upload when nobody has said anything about
    the file yet. `brief` is the customer's own words. On a stranger's file both are absent, which is the case
    this whole module is designed for: nothing here needs an answer key, a corpus label or a template.

    `alerts` are `reconcile/monitor.py`'s, and only a signal whose hand verdicts are MIXED becomes a question
    (`uncertainty.MIXED_SIGNALS`, synthesis C20). `asked_before` is `{kind: times this topic was asked}` read off
    the job ledger, and it breaks ties INSIDE a tier, lowest count first (gr_learn 5.7): at a fixed question
    budget it is the one change that makes the ledger learn faster, and it never moves a question across a tier.

    `seconds` is the wall clock question building gets (`QUESTION_SECONDS`). Past it no further branch is
    evaluated and every remaining question is put with its kind's floor tier and a `why` that says the ceiling
    was hit. Nothing on disk reaches it.
    """
    deadline = conseq.deadline_in(seconds)
    facts = uncertainty._facts_of(document)
    us = uncertainty.enumerate_uncertainty(document, reconciliation=reconciliation, alerts=alerts)
    out = Asked(schema=ASK_SCHEMA, case=case or str(document.get("source_sha256") or ""), uncertainties=us)

    roles = [u for u in us if u.kind == "port_role"]
    others = [u for u in us if u.kind != "port_role"]
    fallback_inlet = next((u.places[0] for u in roles if u.fallback == "inlet"), "")
    #: The count the customer is told is the count of MOUTHS THAT COULD CARRY FLOW, which is
    #: `uncertainty.builder_ports` under this representation and is what `roles` already is. It is not
    #: `len(document["openings"])`: on a wall shell that table also holds the shoulder rings and the inner
    #: body's caps, and telling a customer "I can see eleven openings" about a part with two mouths and nine
    #: excluded ring faces is a sentence that reads as the machine not understanding the part.
    mouth_count = len(roles)

    # --- cut 1 and 2 on the role mouths, then cut 3: one question for whatever is left -----------------------
    bound = bound_declarations(roles, document, declared)
    blanket_ok = settle.blanket_applies(bound, declared)
    open_roles, settled_roles = [], []
    #: cut 1 first, on every mouth, because it is a lookup; then cut 2 on what is left, for the WHOLE GROUP in
    #: one call. `role_consequences` is what stops the cost growing with the mouth count: these mouths are one
    #: question naming the first few, so branching every one of them to order the rest was work nobody reads.
    verdicts = [(u, *_settle_role(u, bound, blanket_ok, brief)) for u in roles]
    cons = conseq.role_consequences([u for u, why, _q in verdicts if not why], document, facts, deadline=deadline)
    for u, why, quote in verdicts:
        if why:
            settled_roles.append((u, why, quote))
            continue
        c = cons[u.id]
        if not c.worth_asking:
            settled_roles.append((u, "no_consequence", c.why))
            continue
        u.measurement["consequence"] = c.as_dict()
        open_roles.append(u)

    ranked_roles = sorted(open_roles,
                          key=lambda u: conseq.rank_key(u, conseq.Consequence(**u.measurement["consequence"])))
    if ranked_roles:
        q = say.port_roles(ranked_roles, len(settled_roles), mouth_count, fallback_inlet)
        worst = min((u.measurement["consequence"]["tier"] for u in ranked_roles), key=TIERS.index)
        q.tier = worst
        q.consequence = {"tier": worst, "per_place": {u.places[0]: u.measurement["consequence"]
                                                      for u in ranked_roles},
                         "tier_why": TIER_WHY[worst]}
        out.questions.append(q)
    for u, why, quote in settled_roles:
        #: the count, not the list. Every settled mouth but this one, which is one fewer than all of them, and
        #: rebuilding that list per mouth was a second quadratic for a number `say.port_roles` only takes the
        #: length of
        held = say.port_roles([u], len(settled_roles) - 1, mouth_count, fallback_inlet)
        held.id = f"q_port_role_{u.places[0]}"
        held.covers = [u.id]
        out.held.append(_hold(held, why, quote))

    # --- the rest, one question each --------------------------------------------------------------------------
    for u in others:
        q = say.write(u)
        if q is None:
            continue
        c = (conseq.not_branched(u.kind, "question building passed its wall-clock ceiling")
             if conseq.past(deadline) else conseq.consequence_of(u, document, facts))
        q.consequence = {**c.as_dict(), "tier_why": TIER_WHY.get(c.tier, "")}
        q.tier = c.tier
        if not c.worth_asking:
            out.held.append(_hold(q, "no_consequence", c.why))
            continue
        got = settle.brief_settles(u.kind, list(q.options), brief)
        if got:
            out.held.append(_hold(q, "brief", got[1]))
            continue
        out.questions.append(q)

    # --- cut 4: rank, then hold everything below the cap --------------------------------------------------------
    seen_before = _asked_before_by_kind(asked_before)
    out.questions.sort(key=lambda q: (TIERS.index(q.tier), seen_before.get(q.kind, 0), q.id))
    if len(out.questions) > max_asked:
        for q in out.questions[max_asked:]:
            out.held.append(_hold(q, "below_the_cap",
                                  f"ranked {out.questions.index(q) + 1} of {len(out.questions)} by consequence, "
                                  f"and at most {max_asked} are put at once"))
        out.questions = out.questions[:max_asked]

    by_id = {u.id: u for u in us}
    for q in [*out.questions, *out.held]:
        q.record = arecord.record_for(q, document, by_id)
    return out


def _asked_before_by_kind(counts: dict[str, int] | None) -> dict[str, int]:
    """The ledger's topic counts keyed by THIS package's kind names, so the tie-break reads one vocabulary."""
    if not counts:
        return {}
    from geometry_agent.ask.schema import KINDS
    from geometry_agent.chain.schema import canonical_kind
    out: dict[str, int] = {}
    for kind in KINDS:
        try:
            topic = canonical_kind(kind)
        except ValueError:
            continue
        out[kind] = int(counts.get(topic, counts.get(kind, 0)) or 0)
    return out


def as_user_questions(asked: Asked) -> list[Any]:
    """The asked questions in the shape `confirm.apply_answers` already reads.

    The arrow from intake to the geometry agent was already built: `agent/confirm.py` takes `UserQuestion`s and
    answers and produces the confirmed plan, with a `Correction` for every place the customer disagreed with
    what was proposed. This function is the adapter, so intake's answers reach the geometry agent through the
    machinery that exists rather than through a second one.
    """
    from geometry_agent.agent.schema import UserQuestion
    out = []
    for q in asked.questions:
        out.append(UserQuestion(id=q.id, text=q.text, options=list(q.options),
                                relates_to=(q.places[0] if q.places else q.kind),
                                default=q.default, also_settles=list(q.places[1:]), effect=q.effect))
    return out


__all__ = ["Asked", "MAX_ASKED", "QUESTION_SECONDS", "as_user_questions", "ask_intake"]
