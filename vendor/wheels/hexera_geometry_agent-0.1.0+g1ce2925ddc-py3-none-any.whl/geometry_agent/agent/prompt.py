"""The system prompt, v3 (dev plan P4.2): under 9,000 characters in nine sections, generated where a list has a
source of truth elsewhere so nothing is typed twice.

Section 2 (identity hypotheses) is one line per object type from `agent/identity_tests.json`; section 3
(mechanisms) one line per `schema.MECHANISMS` entry (the catalog kinds carrying each are `catalog.KIND_MECHANISM`,
and every list_risks result stamps `mechanism` on its risks, so the prompt need not repeat the map); section 6
(the second look) the items the checker recomputes (`grounding.SECOND_LOOK_ITEMS`) plus at most two declarative
lines per purpose; section 8 the threshold sentences from `rule_sentences(thresholds.current())`. Every number in
the prompt is a catalog threshold (from the same file the catalog reads, principle 6) or a structural constant of
the checker and the loop listed in `STRUCTURAL` (pinned to the code by tests/test_prompt_v3.py). The v2 prompt's
inline exceptions are `_normalise` repairs or checker messages now; docs/plan_v3_rules.md section 7 maps every
deleted v2 sentence to its new home. `SYSTEM` is the prompt at the dataclass defaults; `system_prompt()` is the
prompt in force (or $GEOMETRY_AGENT_PROMPT_FILE for an A/B)."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from geometry_agent.agent import thresholds as _thresholds
from geometry_agent.agent.schema import MECHANISMS
from geometry_agent.agent.thresholds import Thresholds

IDENTITY_TESTS_FILE = Path(__file__).resolve().parent / "identity_tests.json"

#: The nine section headings, in order; `sections()` splits a prompt on them for the per-section size caps.
SECTION_HEADINGS = ("0 ROLE", "1 HOW TO WORK", "2 IDENTITY HYPOTHESES", "3 MECHANISMS", "4 THE TWO LISTS",
                    "5 THE PLAN", "6 SECOND LOOK", "7 EXEMPLARS", "8 THRESHOLDS")
#: Size caps (dev plan P4.2): the whole prompt, and sections 2, 3 and 6 together.
PROMPT_MAX_CHARS = 9_000
GENERATED_SECTIONS_MAX_CHARS = 4_000
GENERATED_SECTIONS = ("2 IDENTITY HYPOTHESES", "3 MECHANISMS", "6 SECOND LOOK")
ROLE_LINES = 3

#: Numbers in the prompt that are not catalog thresholds: constants of the checker, the loop and the builder
#: frame, each pinned to the code it mirrors by tests/test_prompt_v3.py so the prompt and the code say the same
#: thing (CLAUDE.md, non-negotiable 8).
STRUCTURAL: dict[str, float | int] = {
    "nominal_rounds": 4,                # loop.LoopConfig.nominal_rounds
    "prose_words": 150,                 # loop.PROSE_NUDGE: at most 150 words between tool calls
    "prose_chars": 1500,                # loop.LoopConfig.prose_guard_chars
    "analysis_max_chars": 1500,         # grounding.ANALYSIS_MAX_CHARS (R12)
    "builder_prose_max_chars": 600,     # grounding.BUILDER_PROSE_MAX_CHARS; hexera.builder_block keeps 600
    "identity_tested_above": 0.8,       # grounding.IDENTITY_TESTED_ABOVE (R2)
    "identity_refuted_above": 0.9,      # grounding.IDENTITY_REFUTED_ABOVE (R2)
    "vision_only_confidence_max": 0.6,  # grounding.VISION_ONLY_CONFIDENCE_MAX (R38)
    "counterfactual_below": 0.9,        # grounding.COUNTERFACTUAL_BELOW (R11)
    "asked_confidence_max": 0.5,        # grounding.ASKED_CONFIDENCE_MAX
    "cells_across": 24,                 # tools.BUILDER_CELLS_ACROSS_DEFAULT (the builder's wall cell)
    "first_cell_over_bore_lo": 1e-4,    # grounding.FIRST_CELL_OVER_BORE[0]
    "first_cell_over_bore_hi": 5e-2,    # grounding.FIRST_CELL_OVER_BORE[1]
    "hypotheses_min": 2,                # R2: two or three hypotheses
    "hypotheses_max": 3,
    "considered_min": 2,                # R5: at least two mechanisms considered when no agent risk
    "extent_over_l_lo": 1,              # grounding.EXTENT_OVER_L[0] (R35)
    "extent_over_l_hi": 50,             # grounding.EXTENT_OVER_L[1]
}

#: The surface cell is diagonal / ESTIMATE_DIVISIONS / 2**STANDARD_LEVEL (facts/estimate.py and the standard tier),
#: so bore / PORT_CELLS_MIN is coarser than it unless the bore is under that many-th of the diagonal.
ESTIMATE_DIVISIONS = 80
STANDARD_SURFACE_FACTOR = 4
_FRACTION_WORDS = {10: "a tenth", 16: "a sixteenth", 20: "a twentieth", 32: "a thirty-second", 40: "a fortieth",
                   64: "a sixty-fourth", 80: "an eightieth", 160: "a hundred-and-sixtieth"}

#: Each mechanism a risk may name (schema.MECHANISMS): the measurement that carries it, and what acting on it
#: reaches. The second column used to name spheres, boxes and extensions; 283 of the 361 mesh-warning targets in
#: the live run before that named a field the platform cannot read, and this column is where the prompt was
#: asking for them. It is now the REACH of a mechanism and not the key row: which keys a renderer consumes is a
#: fact about the engine and the representation of THIS part, and a static line that answers it for every part
#: answered it for none. On snappy_external, the regime every external case runs under, none of the six keys with
#: a reader appeared anywhere in this prompt, and not one of the 57 keys written on an external draw in the
#: 176-draw run was a key the renderer reads. The row now travels with the request (`builder_keys_block`), where
#: it can be the regime's own, and this column says whether a mechanism reaches a key at all.
MECHANISM_LINES: dict[str, tuple[str, str]] = {
    "separation": ("taper half angle, area ratio", "note"),
    "recirculation_at_outlet": ("outlet run over D", "user question"),
    "dean_secondary_flow": ("bend radius over bore", "note"),
    "jet_impingement": ("branch bore, run to the facing wall", "note"),
    "dead_leg_stagnation": ("dead_leg over D, never upstream", "note"),
    "tilted_mouth_skew": ("tilt over <<tilt>> deg on a carve", "surface_level 1"),
    "layer_collision": ("gap in builder cells", "note"),
    "cell_starvation": ("cells across the smallest port at <<cells_across>>", "cells_across_diameter, or size"),
    "swirl_no_symmetry": ("rotational order, a tangential inlet", "no half model"),
    "wake": ("body length L", "note"),
    "ground_effect": ("a planar face on the bbox floor", "note"),
    "tip_gap": ("gap between regions in builder cells", "note"),
    "thermal_interface_unshared": ("coincident unshared interfaces", "glue in CAD"),
    "other": ("any ledger number and a refuting test", "a BUILDER KEYS key, or note"),
}

#: The second-look items per purpose: the checker's items first (grounding.SECOND_LOOK_ITEMS, matched by these
#: words), then at most DECLARATIVE_LINES_MAX declarative lines per purpose. Thresholds enter through tokens.
SECOND_LOOK_LINES: dict[str, list[str]] = {
    "internal": ["mouths grid-aligned (tilt under <<tilt>> deg) or warned tilted_circular_mouth",
                 "outlet runs <<stub_ok>> D or more, or short_stub decided, or extended",
                 "seed inside by ray parity, within half a bore of the inlet",
                 "smallest port <<port_cells>> builder cells across or more",
                 "no region on a wall shell's metal",
                 "flow axis a principal axis or a unit vector",
                 "first cell <<first_cell_lo>> to <<first_cell_hi>> of the smallest bore, equal to its reason"],
    "external": ["four extents, <<ext_lo>> to <<ext_hi>> L (<<ext_up>>, <<ext_down>>, <<ext_lat>>)",
                 "ground contact stated for a planar face on the bbox floor",
                 "wake box finer than base, or absent",
                 "knife edges preserved",
                 "freestream nose to tail from the blunt end"],
    "cht": ["interfaces shared, none coincident and unglued",
            "fluid regions with ports or declared sealed (natural convection)"],
    "structural": ["no flow fields",
                   "no layers"],
}
DECLARATIVE_LINES_MAX = 2
SECOND_LOOK_KINDS = ("internal", "external", "cht", "structural")

TEMPLATE = """0 ROLE
You are the geometry analyst for a meshing pipeline: a CAD file, its purpose, a brief and the measurements arrive together.
You return one plan with two outputs: simulation_warnings for the user and mesh_warnings for the builder, in its frame.
Every number you write is cited from a tool result or the brief; the checker rejects the rest and names what to amend.

1 HOW TO WORK
Round 1, one turn: <<hyp_min>> or <<hyp_max>> identity hypotheses, the probes you need and list_risks with your roles. Round 2: submit_geometry_plan. Rounds 3 and <<rounds>>: amend_geometry_plan at the rejection's pointers, never a resubmission; a changed role means list_risks again. At most <<prose_words>> words between tool calls, reasoning in the plan's fields; a turn over <<prose_chars>> characters with no tool call is dropped. No arithmetic by hand: derived_geometry records each value under an id (d1, d2...) you cite. The checker fills patch numbers, facts_sha256, base size, cell estimate, the flow-axis snap, region roles, the seed point, a unit the file or brief pins, catalog risk fields, identity readings, question effects, and both lists when omitted.

2 IDENTITY HYPOTHESES (type: signature | tool: refuting reading)
<<identity_lines>>

3 MECHANISMS (name: carrying measurement | what reaches it)
<<mechanism_lines>>

4 THE TWO LISTS
A simulation warning (user): measurement, threshold crossed, one question with options, a default and an effect, also_settles. A question exists only when its effect is not advisory and the brief has not answered it, options the confirm step can apply; a brief settles a question by answering it, not by naming its subject: a fixed pressure outlet does not decide whether to extend a short run. A mesh warning (builder) answers five: WHERE (location), HOW BIG (size, off that place), WHAT TO DO (target {key, value}, one key BUILDER KEYS lists: now, on a trigger the critique says, or no key and it is a note), WHAT IT COSTS (cost_cells vs the cap), WHY (the measurement, never how the mesh turns out). Use the catalog's kind when it has one; a kind of your own carries every field itself.

5 THE PLAN
- object.confidence over <<tested_above>> needs a refuting test called, over <<refuted_above>> the chosen type's own (object.identity is filled); the look alone caps it at <<vision_max>> - but the look is not your only support: if the CUSTOMER named the part, or a measurement or a declared fact bears the identity out, SAY SO in object.evidence (name the brief, the measurement or the opening it rests on) and the cap does not apply. What is capped is a name taken ONLY from the picture; at least <<considered_min>> agent_risks_considered with a ledger number when you add no risk.
- patches: the wall patch takes the user's name when they gave one; rings and holes are walls unless the catalog says wall shell or annular passage; a planar face is a port only on the brief's word (confirmed_by_user).
- flow: counterfactual {swap, what_breaks} citing compare_roles when role_assumed fires, a role is asked, or a port role is under <<cf_below>> with no declared ports; fewer high risks wins unless the brief decides; an asked role is at most <<asked_max>> confidence.
- risks: one {id, user_decision} per list_risks entry, nothing else (the checker fills the rest); one the file, brief or catalog settles: continue or fix, the reason in derivation. Yours (detected_by agent): kind, consequence, recommendation, mechanism, effect, a target when changes_mesh, refuted_by (a tool and a number), a measured number, derived values by id; never a restatement of a catalog risk on the same subject, never solver setup (an assumptions line).
- mesh_plan: regions only where the geometry needs cells finer than the surface cell, sized by section 8, under the wall cell, at a measured anchor; one layer target on the wall patch, first cell = derived_geometry first_cell, the y+ wall distance not the cell height (id in reason).
- analysis at most <<analysis_max>> characters; summary_for_user opens "Proceeding with:" when the brief says not to ask; summary_for_builder: at most <<builder_max>> characters of prose after the unit (header generated).

6 SECOND LOOK (filled last; the checker recomputes these)
<<second_look_lines>>

7 EXEMPLARS
Good: kind jet_on_far_wall, mechanism jet_impingement, measurement {opening_id: o3, hydraulic_diameter: ledger value}, derived {run_over_d, derivation_id: d2}, effect changes_mesh, target {sphere at o3's stub end}: a note, no key reaches it, refuted_by "section_profile(o3): area ratio at one past the junction".
Rejected: kind exit_recirculation on o2, mechanism recirculation_at_outlet, while short_stub k3 names o2: a restatement; put the reasoning into k3's question.

8 THRESHOLDS (from thresholds.json)
<<threshold_sentences>>
"""

#: Section 8: one sentence per token, in this order.
THRESHOLD_SENTENCE_KEYS = ("stub_rule", "port_extension", "diffuser", "tiny_port", "same_bore", "refinement_sizing",
                           "surface_cell_rule", "bore_spread", "tilted_mouth", "seed_inset", "external_extents")

#: The rule that rides with a memory block (dev plan P7), and only when there is one. It is not a section of the
#: system prompt: memory speaks about this part or it says nothing, so a standing paragraph about remembered cases
#: would be dead text on every run memory is silent on, and the prompt has little room to spare. Keeping it
#: out also keeps `prompt_sha256` identical across the three memory arms, so the arms differ in one thing.
#: `loop.opening_messages` appends it under the block; `learn.memory.HEADER` is the block's own first line.
MEMORY_RULE = ("Those are other parts, matched on shape ratios alone. They are evidence about what to check on this "
               "one, never a measurement of it: no number above may appear anywhere in your plan, and the checker "
               "rejects it by name if it does. Measure this part for every number you write.")


def _num(x: float) -> str:
    return f"{x:g}"


def _fraction_word(k: float) -> str:
    n = int(round(k))
    if abs(k - n) < 1e-9 and n in _FRACTION_WORDS:
        return _FRACTION_WORDS[n]
    return f"1/{k:g}"


def rule_sentences(thresholds: Thresholds | None = None) -> dict[str, str]:
    """Every sentence of the prompt that carries a catalog threshold, generated from the thresholds so the
    prompt and the catalog cannot disagree. Keys are the section 8 sentences in THRESHOLD_SENTENCE_KEYS order."""
    T = thresholds if thresholds is not None else _thresholds.current()
    ok, block, dev = _num(T.STUB_OK_OVER_D), _num(T.STUB_BLOCKING_OVER_D), _num(T.INLET_DEVELOPED_OVER_D)
    bore, gap, thick = _num(T.PORT_CELLS_MIN), _num(T.GAP_TARGET_DIVISOR), _num(T.THIN_CELLS_MIN)
    fortieth = _fraction_word(ESTIMATE_DIVISIONS * STANDARD_SURFACE_FACTOR / T.PORT_CELLS_MIN)
    return {
        "stub_rule": (f"Outlet run under {ok} D: short_stub (blocking under {block}); inlet run under {ok} D: short_inlet_run, to {dev} D "
                      "inlet_run_developing; never re-grade a stub the catalog passed."),
        "port_extension": f"A short port is extended by {ok} x its hydraulic diameter unless the user chose otherwise.",
        "diffuser": f"A cone half angle over {_num(T.DIFFUSER_ANGLE_MAX_DEG)} degrees is diffuser_angle.",
        "tiny_port": f"A port under {_num(T.TINY_PORT_FRACTION)} of the largest bore is tiny_port.",
        "same_bore": f"Bores within {_num(T.SAME_BORE_BAND)} of each other are interchangeable: role_assumed.",
        "refinement_sizing": (f"Regions: bore/{bore} across a small branch, gap/{gap} across a gap, thickness/{thick} across a thin "
                              f"cluster, the smaller bore/{bore} within a bore of a junction."),
        "surface_cell_rule": f"bore/{bore} is coarser than surface_cell unless the bore is under {fortieth} of the diagonal; then write no region.",
        "bore_spread": f"Bores over {_num(T.VELOCITY_RATIO_MAX)}x apart: one global layer spec and a surface region on the small bore.",
        "tilted_mouth": (f"A circular mouth tilted {_num(T.TILTED_MOUTH_DEG)} degrees or more off its grid axis on a carve is "
                         "tilted_circular_mouth."),
        "seed_inset": f"The seed sits {_num(T.SEED_INSET_OVER_BORE)} bores inside the inlet.",
        "external_extents": (f"External extents: {_num(T.EXTERNAL_UPSTREAM_OVER_L)} L upstream, {_num(T.EXTERNAL_DOWNSTREAM_OVER_L)} L "
                             f"downstream, {_num(T.EXTERNAL_LATERAL_OVER_L)} L lateral."),
    }


def _inline_tokens(T: Thresholds) -> dict[str, str]:
    """The threshold values sections 2, 3 and 6 quote inline (the same values section 8 states in sentences)."""
    return {"tilt": _num(T.TILTED_MOUTH_DEG), "stub_ok": _num(T.STUB_OK_OVER_D), "port_cells": _num(T.PORT_CELLS_MIN),
            "ext_up": _num(T.EXTERNAL_UPSTREAM_OVER_L), "ext_down": _num(T.EXTERNAL_DOWNSTREAM_OVER_L),
            "ext_lat": _num(T.EXTERNAL_LATERAL_OVER_L), "rotor_blades": _num(T.ROTOR_MIN_BLADES)}


def _structural_tokens() -> dict[str, str]:
    S = STRUCTURAL
    return {"rounds": _num(S["nominal_rounds"]), "prose_words": _num(S["prose_words"]), "prose_chars": _num(S["prose_chars"]),
            "analysis_max": _num(S["analysis_max_chars"]), "builder_max": _num(S["builder_prose_max_chars"]),
            "tested_above": _num(S["identity_tested_above"]), "refuted_above": _num(S["identity_refuted_above"]),
            "vision_max": _num(S["vision_only_confidence_max"]),
            "cf_below": _num(S["counterfactual_below"]), "asked_max": _num(S["asked_confidence_max"]),
            "cells_across": _num(S["cells_across"]), "first_cell_lo": _num(S["first_cell_over_bore_lo"]),
            "first_cell_hi": _num(S["first_cell_over_bore_hi"]), "hyp_min": _num(S["hypotheses_min"]),
            "hyp_max": _num(S["hypotheses_max"]), "considered_min": _num(S["considered_min"]),
            "ext_lo": _num(S["extent_over_l_lo"]), "ext_hi": _num(S["extent_over_l_hi"])}


def _fill(text: str, tokens: dict[str, str]) -> str:
    for key, value in tokens.items():
        text = text.replace(f"<<{key}>>", value)
    return text


def identity_config(path: Path | None = None) -> dict:
    return json.loads((path or IDENTITY_TESTS_FILE).read_text(encoding="utf-8"))


def identity_line(entry: dict, thresholds: Thresholds | None = None) -> str:
    """The prompt line for one identity_tests.json entry: the signature and the refuting tool with its reading;
    a threshold key written in the config (ROTOR_MIN_BLADES) is replaced by its value in force."""
    T = thresholds if thresholds is not None else _thresholds.current()
    rt = entry["refuting_test"]
    line = f"{entry['type']}: {entry['signature']} | {rt['tool']}: {rt['would_refute_if']}"
    return line.replace("ROTOR_MIN_BLADES", _num(T.ROTOR_MIN_BLADES))


def identity_lines(config: dict | None = None, thresholds: Thresholds | None = None) -> list[str]:
    """One line per object type from agent/identity_tests.json."""
    cfg = config or identity_config()
    return [identity_line(t, thresholds) for t in cfg["types"]]


def mechanism_lines(thresholds: Thresholds | None = None) -> list[str]:
    """One line per mechanism in schema.MECHANISMS: the measurement and the builder-frame target."""
    T = thresholds if thresholds is not None else _thresholds.current()
    tokens = {**_inline_tokens(T), **_structural_tokens()}
    return [_fill(f"{m}: {MECHANISM_LINES[m][0]} | {MECHANISM_LINES[m][1]}", tokens) for m in MECHANISMS]


def second_look_lines(thresholds: Thresholds | None = None) -> list[str]:
    """The second-look checklist per purpose: the checker's items first, then the declarative lines."""
    T = thresholds if thresholds is not None else _thresholds.current()
    tokens = {**_inline_tokens(T), **_structural_tokens()}
    return [f"{kind}: " + "; ".join(_fill(ln, tokens) for ln in SECOND_LOOK_LINES[kind]) + "." for kind in SECOND_LOOK_KINDS]


def system_prompt_for(thresholds: Thresholds | None = None) -> str:
    """The prompt with its generated sections and rule sentences from `thresholds` (the values in force when None)."""
    T = thresholds if thresholds is not None else _thresholds.current()
    sentences = rule_sentences(T)
    tokens = {**_inline_tokens(T), **_structural_tokens(),
              "identity_lines": "\n".join(identity_lines(None, T)),
              "mechanism_lines": "\n".join(mechanism_lines(T)),
              "second_look_lines": "\n".join(second_look_lines(T)),
              "threshold_sentences": " ".join(sentences[k] for k in THRESHOLD_SENTENCE_KEYS)}
    text = _fill(TEMPLATE, tokens)
    if "<<" in text:
        raise RuntimeError("prompt template has an unfilled token")
    return text


def sections(text: str) -> dict[str, str]:
    """The prompt split by its section headings: heading -> the section's text (heading line included)."""
    out: dict[str, str] = {}
    current = None
    for line in text.split("\n"):
        head = next((h for h in SECTION_HEADINGS if line.startswith(h)), None)
        if head is not None:
            current = head
            out[current] = line
        elif current is not None:
            out[current] += "\n" + line
    return {k: v.strip() for k, v in out.items()}


#: The prompt at the dataclass defaults (the hand-written v3 text plus the generated lines, byte for byte).
SYSTEM = system_prompt_for(_thresholds.DEFAULTS)

PROMPT_FILE_ENV = "GEOMETRY_AGENT_PROMPT_FILE"


def system_prompt() -> str:
    """The system prompt in force (its generated lines from the thresholds in force), or the contents of
    $GEOMETRY_AGENT_PROMPT_FILE when set, so a prompt variant can be A/B tested on a corpus without editing code."""
    import os
    override = os.environ.get(PROMPT_FILE_ENV)
    if override:
        p = Path(override)
        if p.is_file():
            return p.read_text(encoding="utf-8")
    return system_prompt_for(None)


def prompt_sha256(thresholds: Thresholds | None = None) -> str:
    """sha256 of the prompt as generated from `thresholds` (in force when None); the file override is ignored
    here because it is what the ship command compares before and after a threshold move."""
    return hashlib.sha256(system_prompt_for(thresholds).encode("utf-8")).hexdigest()


#: The heading the request's key row carries. Section 4 and the checker's own rejection both point at it by name,
#: so all three say one thing.
BUILDER_KEYS_HEADING = "BUILDER KEYS"


def _key_value_word(v: Any) -> str:
    if isinstance(v, dict):
        return " ".join(f"{k} {_key_value_word(x)}" for k, x in v.items())
    if isinstance(v, bool) or v is None:
        return str(v)
    if isinstance(v, float):
        return f"{v:g}"
    return str(v)


def builder_keys_block(regime: str, platform_sha: str = "") -> str:
    """The keys a renderer consumes on THIS part, generated from `catalog.DIRECTIVE_KEYS`.

    It rides with the request and not with the system prompt because the row is a fact about this case's engine
    and representation (`catalog.regime_of`), and one static line cannot be true of all three regimes: the old
    section 3 column reached two of snappy_internal's seven keys, one of gmsh's two and NONE of the six a case on
    snappy_external reads. Over 176 draws the model wrote 197 target keys; on the external draws not one of the
    57 was a key with a reader, and 93 of the 197 were a field name of `MeshTarget` written in the key slot,
    which is what the rejection's own sentence was offering there.

    The range printed is the one `catalog.directive_problem` enforces, and the default is what the renderer does
    when the plan says nothing: a default is a fact about the platform and never a confirmation of anything.

    The wording avoids the phrase "nothing else", which `tests/test_vision_always.py` reserves: it is a note the
    look writes and the opening message must never carry, and the test finds it by the words. That is the fourth
    vocabulary collision recorded on this side of the project (CLAUDE.md's junction_to_outlet against short_stub
    is the first), so it is worth saying out loud that a phrase added to this message is added to a namespace."""
    from geometry_agent.agent import catalog
    rows = catalog.key_row(regime)
    if not rows:
        return ""
    sha = f" at platform {platform_sha[:8]}" if platform_sha else ""
    lines = [f"{BUILDER_KEYS_HEADING} ({regime}{sha}): every setting the builder reads on this part, the range it keeps, "
             "and what it does when the plan says nothing. A mesh_warnings target {key, value} names exactly one of "
             "these and no other word. A feature no key here reaches is still worth measuring: the item is a note, which carries "
             "its location and its size and sets nothing, and its extent goes in target's own fields (level_delta, "
             "sphere, box, extension_length, seed_point, layers, gmsh_size_value, cells_across, max_cells), never in "
             "`key`. Two things these keys are NOT: the item's `kind`, which names the feature you measured and "
             "never the setting you are changing (`wake_layer_starvation`, not `n_layers`), and its `size`, which "
             "is that feature's own measurement in the file's unit and never a copy of the value you are setting."]
    for r in rows:
        lo, hi = r["renderer"]
        shaped = catalog.shape_words(r["key"], regime)
        if shaped:
            # a key whose value is not a scalar says its shape here, in `catalog.directive_problem`'s own words,
            # because the roster is the only place the model is told what to write. There are three of them now:
            # `domain_margin`, `surface_level` on the external path (a [min, max] pair, because the renderer
            # reads its last entry) and gmsh `size` (a {mode, value} object at the driver)
            rng = shaped
        elif isinstance(lo, str):
            rng = f"{_key_value_word(lo)} or {_key_value_word(hi)}"
        else:
            rng = f"{_key_value_word(lo)} to {_key_value_word(hi)}"
        default = "no default" if r["default"] is None else f"default {_key_value_word(r['default'])}"
        lines.append(f"- {r['key']}: {rng}, {default}")
    return "\n".join(lines)


def user_prompt(purpose: str, brief: str, fidelity: str, cell_cap: int | None, declared: list[dict] | None) -> str:
    parts = [f"Purpose: {purpose}", f"Requested fidelity: {fidelity}"]
    if cell_cap:
        parts.append(f"Cell cap: {cell_cap:,}")
    if declared:
        parts.append(f"Ports the user declared: {json.dumps(declared)}")
    parts.append(f"User's brief: {brief.strip() or '(none)'}")
    return "\n".join(parts)
