"""What the surveyor is honestly uncertain about, read out of the document it already writes.

THE INSIGHT THIS FILE IS, in one line: the surveyor's abstentions are intake's questions. The look declines to
name a role on six of every seven mouths, and where it does guess it is right 48 percent of the time, which is
a coin (`vision/trust.py`, `docs/vision.md`). That abstention is not a defect to be fixed by a better prompt.
It is the input. "I can see four openings, two are clearly through-flow, o3 I cannot tell" IS the question
"which of these is the inlet", and the two lists have never been connected.

NOTHING HERE DECIDES ANYTHING. This module reads `hexera.report_measured`'s own document and returns what the
surveyor DECLINED to settle. It does not re-measure, it does not re-derive a measured quantity, and it does not
form an opinion the surveyor did not already state. The one place it touches `facts` is to hand the surveyor's
own facts back to the surveyor's own helpers (`tools._builder_ports`, `tools.builder_inlet`), because those
helpers take a model rather than a dict. The measurements are AUTHORITATIVE and arrive as facts.

WHAT IS NOT IN HERE, and why. The look's `likely_role`, `looks_like`, `defects`, `orientation`, `symmetry` and
`notes` are the RECORDED tier: they reach a person and nothing else, and `vision/trust.py:for_model` is what
makes that true in code. So this module never turns a look role into a role. It uses the look for exactly two
things, both of which are the relied-on tier and both of which no measurement here supplies:

    openings_seen         WHICH labelled mouths the look could see: 91 to 94 percent recall, Jaccard 1.00 on a
                          repeat call. A mouth the look could not see is a mouth a picture of the part does not
                          explain, which is worth saying to a customer and is not a claim about the mouth.
    openings_seen[].id    an id of `unlabelled` is the look reporting a mouth the MEASUREMENT did not find, and
                          that is the one thing in this whole pipeline the pictures supply and no measurement
                          does.
"""
from __future__ import annotations

import math
from typing import Any

from geometry_agent.agent import tools
from geometry_agent.ask.schema import Uncertainty

#: A mouth whose normal sits within this angle of the part's longest axis is "at an end of the body"; anything
#: else is "on the side". Purely for the wording, and purely from the measurement's own normal and principal
#: axes, so the words a customer reads are a measurement and not an impression.
END_CONE_DEG = 35.0

#: Below this, the measurement's own blunt-end reading is not a reading. `facts.axes.blunt_end_confidence` is
#: 0.0 on 138 of the 322 export parts and under 0.5 on 42 of the 61 external ones, so on an external part this
#: is a frequent and honest abstention rather than a rare one.
BLUNT_END_CONFIDENT = 0.5

#: `bbox.longest_axis` and `axes` are indices; a customer reads letters.
AXIS_LETTER: dict[int, str] = {0: "x", 1: "y", 2: "z"}

#: `hexera.forecast` with no plan has come in at a median 0.52x the cells the job actually delivered over 263
#: corpus meshes (`hexera.FACTS_ONLY_CALIBRATION`). The envelope therefore READS LOW, and the only honest use
#: of it as a question trigger is the one-sided one: when a number that reads low still exceeds the cap, the
#: part does not fit. The other side carries no claim and this module never says "it fits".
ENVELOPE_READS_LOW = ("the no-plan envelope has come in at a median 0.52x the cells delivered on 263 corpus "
                      "meshes, so it reads LOW: an envelope over the cap is a part that does not fit, and an "
                      "envelope under the cap settles nothing")


def builder_ports(facts: Any, representation: str) -> list[Any]:
    """The faces the BUILDER will cut as ports under a representation, which is the set worth asking about.

    One place, read by the enumerator and by `ask.consequence` both, so the question and the counterfactual
    cannot disagree about which faces exist. External is empty because `tessellate_internal` does not run on
    that path; everything else is `tools._builder_ports`, which is the platform's own rule.
    """
    if str(representation) == "external":
        return []
    return list(tools._builder_ports(facts, tools._rep_key(representation)))


def _facts_of(document: dict[str, Any]) -> Any:
    """The surveyor's own facts, as the model its helpers take. None when the document was written without them."""
    raw = document.get("facts")
    if not isinstance(raw, dict):
        return None
    from geometry_agent.facts.schema import GeometryFacts
    return GeometryFacts.model_validate(raw)


def _angle_deg(a: Any, b: Any) -> float:
    try:
        u = [float(x) for x in a]
        v = [float(x) for x in b]
    except (TypeError, ValueError):
        return 90.0
    nu = math.sqrt(sum(x * x for x in u)) or 1.0
    nv = math.sqrt(sum(x * x for x in v)) or 1.0
    dot = sum(x * y for x, y in zip(u, v)) / (nu * nv)
    return math.degrees(math.acos(max(-1.0, min(1.0, abs(dot)))))


def where_is(row: dict[str, Any], document: dict[str, Any]) -> str:
    """Where a mouth is, in words, from the measurement and nothing else.

    A customer cannot act on "o3, centroid (140.2, 0.0, 88.4)". They can act on "the one on the side". The
    phrase comes from the opening's own normal against the body's longest principal axis, and from
    `bbox_side` when the face lies on the bounding box, both of which are measured fields.
    """
    principal = ((document.get("axes") or {}).get("principal") or [None])[0]
    normal = row.get("normal")
    side = row.get("bbox_side")
    at_end = principal is not None and normal is not None and _angle_deg(normal, principal) <= END_CONE_DEG
    if at_end:
        return "at an end of the body"
    if side:
        return f"on the {str(side).replace('_', ' ')} face"
    return "on the side of the body"


def _look_impression(document: dict[str, Any]) -> dict[str, Any]:
    look = document.get("look")
    if not isinstance(look, dict) or look.get("status") != "ok":
        return {}
    imp = look.get("impression")
    return imp if isinstance(imp, dict) else {}


def _seen_ids(impression: dict[str, Any]) -> set[str]:
    """The labelled mouths the look could see. The SET is the finding (relied_on); each field inside an entry is
    tiered on its own and none of them is read here."""
    out = set()
    for entry in impression.get("openings_seen") or []:
        if isinstance(entry, dict):
            oid = str(entry.get("id") or "")
            if oid and oid != "unlabelled":
                out.add(oid)
    return out


def port_role_uncertainties(document: dict[str, Any], facts: Any = None) -> list[Uncertainty]:
    """One entry per measured mouth whose role the surveyor did not settle.

    THE CANDIDATE SET IS WHAT THE BUILDER WILL CUT, which is `tools._builder_ports`: the catalog's port
    openings under this representation, and when it names none, every planar face, because that is what
    `tessellate_internal` takes (`cad_tessellate.py:588-591`). It is NOT `catalog.port_openings` on its own, and
    the difference is two real parts. `volute_scroll_002` and `_012` measure as representation `unknown`, where
    `port_openings` names nothing and the builder cuts five faces and three. Asking about the faces the catalog
    happens to name rather than the faces the builder happens to cut left both parts with no question at all
    while five ports were assigned behind the customer's back, and `eval/ask/corpus.py:audit_cuts` did not catch
    it either because the cut was reading the same predicate.

    ON AN EXTERNAL PART THERE ARE NO CANDIDATES AT ALL, and that is correct rather than a gap: the external
    driver meshes the body in a box and `tessellate_internal` never runs, so no measured face becomes a patch,
    `tools._estimate_external` takes no inlet id, and the 61 external parts of the export corpus hold up to 20
    measured openings each that are surface marks and not mouths. Enumerating them would be the largest single
    source of questions in the product and not one of them would change anything.
    """
    facts = facts if facts is not None else _facts_of(document)
    if facts is None:
        return []
    rep = str(document.get("representation") or "")
    ports = builder_ports(facts, rep)
    if not ports:
        return []
    rows = {str(r.get("id")): r for r in (document.get("openings") or []) if isinstance(r, dict)}
    impression = _look_impression(document)
    seen = _seen_ids(impression)
    inlet, _ = tools.builder_inlet(facts, rep)
    fallback_id = getattr(inlet, "id", None)
    out: list[Uncertainty] = []
    for o in ports:
        row = rows.get(o.id) or {}
        out.append(Uncertainty(
            id=f"u_role_{o.id}",
            kind="port_role",
            places=[o.id],
            unknown=f"what {o.id} is for: nothing in the file says whether it carries flow, and if so which way",
            source="openings[] of the measurement; role is not a measured field",
            abstention=("the measurement names the mouth and its size and stops there; a role comes from the "
                        "customer or from nowhere"
                        + ("" if (o.id in seen or not impression) else "; the look did not report this mouth either")
                        + ("" if impression else "; no look ran on this file")),
            branches=["inlet", "outlet", "wall", "closed for this run"],
            #: What the pipeline does today with no answer: every planar face becomes a port and the widest is
            #: taken as the inlet (`cad_tessellate.py:614` and `:631`, mirrored in `tools.builder_inlet`). The
            #: default has to BE this, or a customer who answers nothing gets a different job from the one they
            #: get now.
            fallback="inlet" if o.id == fallback_id else "outlet",
            measurement={"kind": o.kind, "shape": o.shape,
                         "hydraulic_diameter_mm": row.get("hydraulic_diameter_mm"),
                         "bore_diameter_mm": row.get("bore_diameter_mm"),
                         "area_mm2": row.get("area_mm2"), "tilt_deg": row.get("tilt_deg"),
                         #: None when no look ran: "the look could not see it" is a claim about a look, and a
                         #: look that never happened has made none (`say._blind` reads only False)
                         "where": where_is(row, document),
                         "seen_by_the_look": (o.id in seen) if impression else None},
        ))
    return out


def unlabelled_mouth_uncertainties(document: dict[str, Any]) -> list[Uncertainty]:
    """A mouth the look reports that the measurement did not find.

    `vision/trust.py` puts `openings_seen[].id` in the relied-on tier and says in as many words that an id of
    `unlabelled` is "the look reporting a mouth the measurement did not find, which is the one thing here no
    measurement can supply". It is the only place in this module where the pictures raise a question the
    instrument cannot, and the question is not "is the look right" but "did we miss an opening".
    """
    impression = _look_impression(document)
    entries = [e for e in (impression.get("openings_seen") or [])
               if isinstance(e, dict) and str(e.get("id") or "unlabelled") == "unlabelled"]
    if not entries:
        return []
    return [Uncertainty(
        id="u_unlabelled_mouths",
        kind="unlabelled_mouth",
        places=[],
        unknown=f"the look reports {len(entries)} mouth(s) the measurement did not find",
        source="look.impression.openings_seen[] entries with no measured id",
        abstention="the measurement found no face there; the look says it can see one",
        branches=["there is an opening there", "there is no opening there"],
        fallback="there is no opening there",
        measurement={"count": len(entries),
                     #: `looks_like` and `why` are the RECORDED tier: they are carried so a PERSON can read
                     #: what was said, and `ask.record` keeps them out of anything a model reads.
                     "for_a_person_only": [{"looks_like": e.get("looks_like"), "why": e.get("why")}
                                           for e in entries]},
    )]


def flow_direction_uncertainty(document: dict[str, Any], facts: Any = None) -> list[Uncertainty]:
    """Which way the flow comes at an external body, when the measurement will not say.

    `snappy_runner.py:311-335 domain_from_strategy` builds the domain around `flow_axis`, so this answer moves
    the box and with it the wake. The measurement has a blunt end and a confidence in it, and on 42 of the 61
    external export parts that confidence is under 0.5. This is the external half of the role question and it
    is the reason the external path is not silent in this module even though it carries no patch roles.
    """
    facts = facts if facts is not None else _facts_of(document)
    if facts is None or str(document.get("representation") or "") != "external":
        return []
    ax = facts.axes
    conf = float(getattr(ax, "blunt_end_confidence", 0.0) or 0.0)
    if conf >= BLUNT_END_CONFIDENT:
        return []
    #: `bbox.longest_axis` is an INDEX, and index 0 is the commonest value and is falsy. Read as a truthy
    #: string it silently became "the longest axis" in the question text and a KeyError in the branch
    #: evaluation, so the flow question read as prose and scored as uncomputable on every external part.
    longest = AXIS_LETTER.get(int((document.get("bbox") or {}).get("longest_axis") or 0), "x")
    #: THE DEFAULT IS WHAT THE BUILDER DOES, and the builder does not use the longest axis. With no declared flow
    #: axis `tools._external_domain` puts upstream and downstream along axis 0 (`snappy_runner.py:337-340`), so
    #: a skipped question means flow along +x whatever the shape. This used to offer and default to the longest
    #: axis: on the 32 external corpus parts whose longest axis is y or z (wings spanning y, rotors, bluff
    #: bodies) the default named a direction the builder would not take, and the brief's own "Flow is along
    #: +X." could not settle a question that did not offer x. Every direction is offered now.
    builder_default = "+x"
    return [Uncertainty(
        id="u_flow_direction",
        kind="flow_direction",
        places=[],
        unknown="which way the flow comes at the body",
        source="axes.blunt_end_sign with axes.blunt_end_confidence below the reading threshold",
        abstention=(f"the shape does not settle which end is the blunt one: confidence {conf:.2f} on a 0 to 1 "
                    f"scale, where {BLUNT_END_CONFIDENT:g} is the least this reading is trusted at"),
        branches=[f"along {s}{a}" for a in "xyz" for s in "+-"],
        fallback=f"along {builder_default}",
        measurement={"blunt_end_sign": getattr(ax, "blunt_end_sign", 0), "blunt_end_confidence": round(conf, 3),
                     "longest_axis": longest, "slenderness": round(float(getattr(ax, "slenderness", 0.0)), 3)},
    )]


def plausible_unit(unit: dict[str, Any]) -> str:
    """The unit a skipped unit question stands on: the measurement's own best reading, never a blind `mm`.

    It was `unit.assumed or "mm"`, and on a unitless file `assumed` is null, so every STL defaulted to
    millimetres however the measurement scored them. On the synthetic pipe `facts/units.py` scores `m` 4.0 and
    `mm` 0.0, the agent's own plan calls it `m`, and the question's default said `mm`: the default contradicted
    the measurement it was asking about, and the chain's plan check then refused the plan for agreeing with it.
    """
    if unit.get("assumed"):
        return str(unit["assumed"])
    plausible = [str(u) for u in (unit.get("plausible_for_purpose") or []) if u]
    ranked = [str(c[0]) for c in (unit.get("candidates") or []) if isinstance(c, (list, tuple)) and c]
    for name in ranked:
        if not plausible or name in plausible:
            return name
    return plausible[0] if plausible else "mm"


def unit_uncertainty(document: dict[str, Any]) -> list[Uncertainty]:
    """Whether the length unit is settled by the file.

    On the export corpus this NEVER fires: all 322 parts are STEP and every one carries a header or body unit.
    It is here for the file that is not a STEP, where `coordinates.scale_to_metres` is null, every length in
    `hexera.planner_block` is null with it, and the block ships as `degraded` (`planner_block`'s own
    `missing_because`). That is the one uncertainty in this module that stops the builder being handed a number
    at all, which is why it is not scored on a corpus that cannot produce it.

    A SCALE THAT IS KNOWN IS A UNIT THAT IS KNOWN, whoever settled it, and that is this module's sibling
    finder's own rule (`contract.asking._unit_uncertainty`, which returns None on `coordinates.scale_to_metres`
    and records that the corpus intake conversations asked this 299 times and should not have). This finder read
    only `unit.declared_source`, so a unit the CUSTOMER confirmed - the platform asks for it in its own words
    and records it as a `GeometryInterpretation`, which arrives here as `coordinates.basis=user_confirmed` with
    a real scale - left the question standing. It is not put again (the platform routes `about: unit` to itself)
    and it does not stay harmless: it rides to the builder as an `unsettled` row saying "the file states no
    unit, so no length here can honestly be given in metres" in the same block that carries `unit: {kind:
    confirmed}`, `units: "m"`, `status: ok` and every length in metres, and it spends one of `MAX_ASKED`'s five
    slots on a question nobody will ever be asked. Two facts about one unit, and the false one is the one the
    planner's own note tells the model to read as what nobody settled.
    """
    coords = document.get("coordinates") or {}
    if coords.get("scale_to_metres"):
        return []
    from geometry_agent.ask import settle
    settled, _ = settle.unit_settled_by_file(document)
    if settled:
        return []
    unit = document.get("unit") or {}
    return [Uncertainty(
        id="u_unit",
        kind="unit",
        places=[],
        unknown="what length unit this file is in",
        source="unit.declared_source is neither step_header nor step_body",
        abstention=(f"the format carries no unit of its own ({document.get('source_format')}), so every length "
                    "in the planner block is null and the block ships degraded"),
        branches=[str(c[0]) for c in (unit.get("candidates") or [])] or ["mm", "m", "in"],
        fallback=plausible_unit(unit),
        measurement={"assumed": unit.get("assumed"), "basis": unit.get("basis"),
                     "candidates": unit.get("candidates"),
                     "plausible_for_purpose": unit.get("plausible_for_purpose")},
    )]


def fluid_side_uncertainty(document: dict[str, Any]) -> list[Uncertainty]:
    """Which side of the surface is the fluid, where the geometry reads the same both ways.

    THE SURVEYOR'S ABSTENTION, in its own words. `catalog.side_reading` lands on a thick ring with one hole, a
    block pierced by several bores or a part with no mouth, and the file is then either the solid around the flow
    or the flow itself. Nothing measured tells them apart; on the export corpus without a brief this happens on 39
    parts, and on the 37 of them where today's reading asserts a side (the file is the fluid) it is wrong on 25.
    On eval/hard_real it asserts a side on four solid blocks and brackets and is wrong on all four. The rest read
    `unknown`, which asserts nothing. Every document carries the reading now; a document written before the
    side was hardwired on does not.

    The fallback is today's reading, because a customer who answers nothing gets the job they get now; it stays a
    default and `hexera.planner_places` places nothing on the flow path while it stands.
    """
    side = document.get("fluid_side")
    if not isinstance(side, dict) or not side.get("open"):
        return []
    readings = {str(k): str(v) for k, v in (side.get("readings") or {}).items()}
    if len(readings) < 2:
        return []
    bores = int(side.get("bores") or 0)
    rings = [r for r in (document.get("openings") or []) if isinstance(r, dict) and r.get("kind") == "ring"]
    widest = max((float(r.get("bore_diameter_mm") or 0.0) for r in rings), default=0.0)
    return [Uncertainty(
        id="u_fluid_side",
        kind="fluid_side",
        places=[],
        unknown="which side of the surface is the fluid",
        source="fluid_side of the measurement (catalog.side_reading)",
        abstention=str(side.get("why") or ""),
        branches=list(readings),
        fallback=str(side.get("default") or "is_fluid"),
        measurement={"rule": side.get("rule"), "readings": readings, "bores": bores,
                     "rings": len(rings), "widest_bore_mm": round(widest, 1) if widest else None,
                     "representation_now": document.get("representation")},
    )]


def budget_uncertainty(document: dict[str, Any]) -> list[Uncertainty]:
    """The envelope against the cell budget the customer already stated.

    REHAAN'S DESIGN, and it is not a prediction. Measure the part, work out what resolving it properly costs,
    compare with the budget already in the brief. If it fits, ask nothing. If it genuinely does not, ask ONCE,
    as a real trade. The number is `hexera.forecast`, which is `tools.estimate_builder_cells`, the emulator that
    reproduces the builder's own sizing, and NEVER `tools.refined_cell_estimate`, whose median is 1.86x and
    whose max is 576x (`hexera.PLANNER_BLOCK_WITHHELD` says the same thing to the platform).

    ONE-SIDED, and this is the honest part. The no-plan envelope reads low. It fires on 12 of the 263 export
    parts with a delivered mesh and every one of those 12 did come in over its cap; it stays silent on 54 parts
    that also came in over. So a fire is trustworthy and a silence is not a claim, and no wording here says the
    part fits.
    """
    fc = document.get("forecast")
    if not isinstance(fc, dict) or not fc.get("over_cap"):
        return []
    cap = fc.get("cell_cap")
    high = fc.get("cells_high")
    return [Uncertainty(
        id="u_budget",
        kind="budget_envelope",
        places=[],
        unknown="whether to hold the stated cell budget or raise it",
        source="forecast.over_cap on the builder emulator with no plan",
        abstention=ENVELOPE_READS_LOW,
        branches=["hold the budget and mesh coarser", "raise the budget"],
        fallback="hold the budget and mesh coarser",
        measurement={"cells_high": high, "cells_low": fc.get("cells_low"), "cell_cap": cap,
                     "over_by": (int(high) - int(cap)) if (high and cap) else None,
                     "tier": fc.get("tier"), "minutes_typical": fc.get("minutes_typical"),
                     "calibration": fc.get("calibration")},
    )]


def dispatch_uncertainty(document: dict[str, Any]) -> list[Uncertainty]:
    """What the platform's own pre-mesh rules would refuse, as the surveyor predicts them.

    `hexera.triage` replicates named platform raises at a pinned sha and is logged, never enforced. A predicted
    refusal is the one uncertainty whose answer decides whether there is a job at all, so it outranks
    everything else in this module.
    """
    tri = document.get("triage")
    if not isinstance(tri, dict):
        return []
    verdict = str(tri.get("verdict") or "buildable")
    if verdict == "buildable":
        return []
    return [Uncertainty(
        id="u_dispatch",
        kind="dispatch_refusal",
        places=[],
        unknown="whether this file can be meshed as it stands",
        source=f"triage.verdict {verdict}",
        abstention="; ".join(str(r) for r in (tri.get("reasons") or []))[:600],
        branches=["send it back to be fixed", "try it anyway"],
        fallback="send it back to be fixed",
        measurement={"verdict": verdict, "rules": tri.get("platform_rule_predicted"),
                     "platform_sha": tri.get("platform_sha"), "enforced": tri.get("enforced")},
    )]


def dispute_uncertainty(reconciliation: Any) -> list[Uncertainty]:
    """The look and the measurement reading the same place two ways.

    `reconcile.verdict.question` already builds exactly one of these, picks the highest-ranked dispute and
    states the cautious default, and its wording was reviewed on the corpus
    (`eval/vision/results/reconcile/questions.md`: 72 of 322 parts raise one). This module does not rewrite it;
    it wraps it so it can be ranked against the others and recorded the same way. A dispute is by definition a
    thing neither source outranks the other on, so it never overrules a measurement.
    """
    if reconciliation is None:
        return []
    from geometry_agent.reconcile import verdict as rv
    q = rv.question(reconciliation)
    if not q:
        return []
    return [Uncertainty(
        id="u_dispute",
        kind="look_dispute",
        places=[],
        unknown=f"the look and the measurement disagree about {q.get('about')}",
        source="reconcile.verdict.question over the DISPUTED verdicts",
        abstention=str(q.get("why_not_settled") or ""),
        branches=["treat it as present and resolve it", "treat it as absent"],
        fallback="treat it as present and resolve it",
        measurement={"about": q.get("about"), "claim": q.get("claim"), "ask": q.get("ask"),
                     "because": q.get("because"), "others_on_the_record": q.get("others_on_the_record")},
    )]


#: SYNTHESIS C20, and the table is the hand verdicts committed in this tree, not a judgement. A monitor alert
#: becomes a CUSTOMER question only where its signal's hand-verdict posterior is mixed: where the verdicts already
#: say which side is right, a customer's answer buys nothing and spends a slot of the question budget that a role
#: question (the topic the ledger learns from) would have used. Everything else is a statement with its reason.
#: A signal with no hand verdicts at all is not asked either: an unmeasured signal is not evidence that a person is
#: needed, and `unlabelled_mouth` already asks the one thing (a mouth only the look saw) nobody else can.
MIXED_SIGNALS: dict[str, str] = {
    "asserted_over_a_clear_bore": "measurement blind 9, both right 3, detector wrong 3 of the hand verdicts",
    "stop_panel_denied": "unsettled 2, measurement wrong 1 of the hand verdicts",
}
#: The signals whose verdicts are already settled, and what they say, so the reason is on the record.
SETTLED_SIGNALS: dict[str, str] = {
    "taper_left_unnamed": "look silent on a real taper 17, measurement wrong 4: 17 of 21 known",
    "denied_over_a_restriction": "both right 13, measurement wrong 1: a wording disagreement",
    "mouths_left_unanswered": "a real gap 9 of 9",
    "defect_on_a_file_the_loader_calls_clean": "look wrong 7 of 7, and the field is already withheld",
}


def _alert_field(alert: Any, key: str) -> str:
    value = alert.get(key, "") if isinstance(alert, dict) else getattr(alert, key, "")
    return str(value or "")


def alert_uncertainties(alerts: Any) -> list[Uncertainty]:
    """The monitor's disagreements that a PERSON can usefully settle, and only those (C20)."""
    out: list[Uncertainty] = []
    for a in alerts or []:
        sig = _alert_field(a, "signal")
        if sig not in MIXED_SIGNALS:
            continue
        says, measured = _alert_field(a, "says"), _alert_field(a, "measured")
        if not says or not measured:
            continue
        subject = _alert_field(a, "subject")
        where = f" at {subject}" if subject else ""
        out.append(Uncertainty(
            id=f"u_dispute_{sig}{'_' + subject if subject else ''}",
            kind="look_dispute",
            places=[subject] if subject else [],
            unknown=f"which of the look and the measurement is right{where}",
            source=f"reconcile/monitor.py signal {sig}",
            abstention=MIXED_SIGNALS[sig],
            branches=["the look is right", "the measurement is right"],
            fallback="the measurement is right",
            measurement={"ask": (f"The pictures and the measurement disagree{where}. The look says {says!r} and "
                                 f"the measurement says {measured!r}. Neither can settle the other. Which is it?"),
                         "because": f"the hand verdicts on this signal are mixed ({MIXED_SIGNALS[sig]}), so "
                                    f"neither source outranks the other here",
                         "signal": sig},
        ))
    return out


def unseen_mouth_uncertainties(document: dict[str, Any], facts: Any = None) -> list[Uncertainty]:
    """Measured mouths the look never named. RECORDED AND NEVER ASKED.

    The ninth kind that `ask/` did not have (appendix B). The measurement already has the opening, so an answer
    would confirm something nobody doubts; what the row is worth is the look's miss on a part where the
    measurement checked, which is what the ledger learns the look's recall from. There is no writer for it in
    `say.py`, so `ask_intake` carries it in `uncertainties` and never turns it into a question.
    """
    impression = _look_impression(document)
    if not impression:
        return []
    facts = facts if facts is not None else _facts_of(document)
    if facts is None:
        return []
    ports = builder_ports(facts, str(document.get("representation") or ""))
    seen = _seen_ids(impression)
    missed = sorted(o.id for o in ports if o.id not in seen)
    if not missed:
        return []
    return [Uncertainty(
        id="u_unseen_mouths", kind="opening_unseen", places=missed,
        unknown="why the look did not name these measured mouths",
        source="openings[] of the measurement against look.impression.openings_seen[]",
        abstention="the look did not name these mouths, and its weakest habit is treating what it did not "
                   "mention as not there",
        branches=[], fallback="the measurement's opening list stands",
        measurement={"missed": missed, "seen": sorted(seen)},
    )]


def identity_uncertainty(document: dict[str, Any]) -> list[Uncertainty]:
    """A name resting on the picture alone. ADVISORY, recorded, never asked: a name drives no builder input, and
    it is capped at 0.6 (`vision.trust.IDENTITY_CONFIDENCE_MAX`) because it is right on 215 of 322 at best."""
    name = str(_look_impression(document).get("looks_like") or "").strip()
    if not name:
        return []
    return [Uncertainty(
        id="u_identity", kind="identity", places=[],
        unknown="what the part is", source="look.impression.looks_like",
        abstention="a name from the picture alone is a proposal, capped at 0.6, and never a statement",
        branches=["yes", "no, it is something else"],
        #: NOT the name. A name nobody confirmed is not assumed by anything downstream: it drives no builder
        #: input, and writing the look's word here would carry it into intake's `assumed` block as though the
        #: pipeline had adopted it. The proposal stays in the survey block, as a candidate with its cap.
        fallback="no name is assumed; the look's proposal stays a candidate",
        measurement={"proposed": name},
    )]


def enumerate_uncertainty(document: dict[str, Any], *, reconciliation: Any = None,
                          alerts: Any = None) -> list[Uncertainty]:
    """Everything the surveyor declined to settle, in one list, in no particular order.

    Ranking is `ask.consequence`'s job and is deliberately not done here: this list is what is TRUE about the
    survey, and it stays the same whether or not anybody is ever asked a question about it. The last two kinds,
    `opening_unseen` and `identity`, have no writer and are never asked; they are here so the one record the
    chain keeps (`chain.schema.Uncertainty`) holds all nine kinds.
    """
    facts = _facts_of(document)
    out: list[Uncertainty] = []
    out += dispatch_uncertainty(document)
    out += unit_uncertainty(document)
    out += fluid_side_uncertainty(document)
    out += port_role_uncertainties(document, facts)
    out += flow_direction_uncertainty(document, facts)
    out += unlabelled_mouth_uncertainties(document)
    out += budget_uncertainty(document)
    out += dispute_uncertainty(reconciliation)
    out += alert_uncertainties(alerts)
    out += unseen_mouth_uncertainties(document, facts)
    out += identity_uncertainty(document)
    return out


__all__ = ["BLUNT_END_CONFIDENT", "END_CONE_DEG", "ENVELOPE_READS_LOW", "MIXED_SIGNALS", "SETTLED_SIGNALS",
           "plausible_unit",
           "alert_uncertainties", "budget_uncertainty", "dispatch_uncertainty", "dispute_uncertainty",
           "enumerate_uncertainty", "flow_direction_uncertainty", "fluid_side_uncertainty", "identity_uncertainty",
           "port_role_uncertainties", "unit_uncertainty", "unlabelled_mouth_uncertainties",
           "unseen_mouth_uncertainties", "where_is"]
